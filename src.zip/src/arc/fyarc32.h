//**************************************************************************
//                                                                         
// File Name:      fyarc32.h
//                                                                         
// Description:    Function prototypes and macros for internal use by 
//                 components of 32-bit Finance Architecture API (FY32.DLL) 
//                                                                         
// Programmers:    W. Randy King (WRK) - RTG, Inc.
//                                                                         
// Revision History:
//                                                                         
// $Log:   O:/dmss/rewrite/source/arc/fyarc32.h_v  $ 
// 
//    Rev 1.30   06 Jan 1999 13:39:02   BWalseth
// Added constants for error range constants.
// 
//    Rev 1.29   18 Nov 1998 13:33:18   BWalseth
// Added code for ERR_LogServiceError and #def for INI_SVCMSG_FILE_NAME 
// 
//    Rev 1.28   28 Oct 1998 16:14:34   BWalseth
// Updated the constant for RACF 1134, which was 11034 in error.
// Made corresponding changes in fylogon.cpp to use the new constant, which
// was not being used previously.
// 
//    Rev 1.27   20 Oct 1998 12:34:18   BWalseth
// Added message constant for CANNOT_PREPAR_MSG_FILE
// 
//    Rev 1.26   02 Oct 1998 16:16:22   BWalseth
// Added prototypes for FTP and MAIL.
// 
//    Rev 1.25   24 Sep 1998 16:59:56   BWalseth
// Added FTP function prototypes
// 
//    Rev 1.24   22 Sep 1998 16:33:38   BWalseth
// Added FY32_UTL_WAIT constants, and FY32_SOCKET constants.
// 
//    Rev 1.23   Aug 24 1998 17:27:28   BWalseth
// 
//    Rev 1.22   Jul 21 1998 13:47:18   BWalseth
// Changed INI_FILE_NAME to fy32.ini from finance.ini to eliminate conflicts
// with 16-bit distributions that were overwriting the files.
// Added prototypes for ERR_GetPanelId and ERR_GetSeverity.
// 
//    Rev 1.21   Jul 14 1998 14:04:50   BWalseth
// Added UTL_GetFinancePath proto and error message constant.
// 
//    Rev 1.20   May 18 1998 15:42:02   BWalseth
// Updated FY32_ERR_MAX, so that socket errors around 10000 will also be caught.
// This value is used in the Logon window.
// 
//    Rev 1.19   May 06 1998 16:58:58   BWalseth
// Created FY32_ERR_MIN for errror handling in Logon::OnOk
// 
//    Rev 1.18   May 04 1998 20:22:14   BWalseth
// Updated ERR_DisplayArchMessage proto.
// Added DAA_LUW_TEST #define.
// 
//    Rev 1.17   Apr 16 1998 16:56:12   BWalseth
// Added several messages.
// Modified fuction proto for UTL_StripFileName.
// 
//    Rev 1.16   Apr 06 1998 16:13:52   BWalseth
// Updated message for 10060.
// 
//    Rev 1.15   Apr 01 1998 12:46:50   BWalseth
// Added INI key for PerfData
// 
//    Rev 1.14   Mar 27 1998 16:26:34   BWalseth
// Added message for unknown user.
// Updated ERR_DisplayArcMessage to support optional string parms.
// 
//    Rev 1.13   Mar 27 1998 15:17:36   BWalseth
// No change.
// 
//    Rev 1.12   Mar 20 1998 14:47:24   BWalseth
// No change.
// 
//    Rev 1.11   Mar 20 1998 14:44:46   CMesser
// 
//    Rev 1.10   Mar 19 1998 15:33:56   BWalseth
// Added prototypes for UTL_Wait functions.
// 
//    Rev 1.9   Mar 18 1998 12:38:20   BWalseth
// Updated constants.
// Added UTL_GetLocalPath.
// 
//    Rev 1.8   Mar 18 1998 10:26:38   BWalseth
// Added UTL_GetNetworkPath
// 
//    Rev 1.7   Mar 10 1998 12:34:08   BWalseth
// Updated message constant base to 70000, so that it's distict from VB errors.
// 
//    Rev 1.6   Mar 09 1998 08:46:42   BWalseth
// Added prototype for ERR_HandleSystemError
// Updated prototypes for UTL_Start, Activate and Terminate App.
// Added UTL message constants for Start, Activate and Terminate.
// 
//    Rev 1.5   Mar 05 1998 14:17:20   BWalseth
// Added socket error constants
// 
//    Rev 1.4   Mar 05 1998 11:26:10   BWalseth
// Added #define for ACFAE155, password too short, and #define for the message.
// 
//    Rev 1.3   Mar 02 1998 16:15:46   BWalseth
// Added new message constants.
// Update #defines for consistency.
// 
//    Rev 1.2   Feb 19 1998 15:41:02   BWalseth
// Updated ERR_GetMessageText to use appl id, not filename.
// Updated error constants.
// Updated #defines for *consistency*
// 
//    Rev 1.1   Feb 17 1998 18:00:08   BWalseth
// Updated error structure to include "source".
// Added generated error message component.
// Update ERR_GetMessageText, breaking interface contract.  It now
// requires the file name to be specified.
// Updated FY32_ERR_BASE to be 0x10000.
// Added an application error base of 0x20000.
// Added #defines for .INI file locations and names.
// 
//    Rev 1.0   Feb 16 1998 13:42:44   BWalseth
// Initial revision.
//                                                                         
// Date      Who  Description
// --------  ---  ---------------------------------------------------------  
// 10/13/97  WRK  Adapted from 16-bit architecture   
// 01/30/98  WRK  Moved CNV API declarations from FY32.H
//                                                                         
//***************************************************************************

#if !defined(INCLUDED_FYARC32)
#define INCLUDED_FYARC32

// Don't allow functions that are not compatible with Windows '95
// See Advanced Windows 3rd Edition, Jefferey Richter, p. 998
// With this #define functions that are not available on Windows '95,
// like GetFileAttributesEx will generate compiler errors.
#define _WIN32_WINNT 0x0400


// Determines the communication mechanism
// #define USE_ECA
#define USE_SOCKETS

#define DEFAULT_EMAIL_ERR_ADDRESS "Bill.Walseth@delta-air.com"


//***** ERR error handling macros, structures, and functions
// Macros for error type
#define ERR_ERROR_TYPE_UNKNOWN  85  // 'U'   
#define ERR_ERROR_TYPE_ARCH     69  // 'E'   
#define ERR_ERROR_TYPE_VB       86  // 'V'
// Legacy error types from the SFE
#define ERR_ERROR_TYPE_APPL     65  // 'A'
#define ERR_ERROR_TYPE_DB2      68  // 'D'
#define ERR_ERROR_TYPE_INFO     73  // 'I'
#define ERR_ERROR_TYPE_CICS     67  // 'C'
#define ERR_ERROR_TYPE_SYBASE   83  // 'S'

// Error Types for UNIX and Oracle
#define ERR_ERROR_TYPE_OPERATING_SYSTEM 'O'

// Error severities
#define ERR_SEVERITY_SUCCESS    0
#define ERR_SEVERITY_WARNING    4
#define ERR_SEVERITY_ERROR      8
#define ERR_SEVERITY_FATAL      16

// Error actions
#define ERR_ACTION_END          1
#define ERR_ACTION_RETRY        2
#define ERR_ACTION_SKIP         3

// RACF codes for password expired/pending expired.  These are parsed
// from error data field of error block returned from the service.
// #define SEC_ACF_PASSWORD_EXPIRED    "ACF0117"  -- I got the one below - WAW
#define SEC_ACF_UNKNOWN_ID "ACF01004"
#define SEC_ACF_EXPIRATION_PENDING  "ACF01134"
#define SEC_ACF_PASSWORD_NOT_MATCHED "ACF01012"
#define SEC_ACF_PASSWORD_SUSPENDED "ACF01013"
#define SEC_ACF_PASSWORD_EXPIRED "ACF01017"
#define SEC_ACF_PASSWORD_CANT_CHANGE "ACF01136"
#define SEC_ACF_PASSWORD_TOO_SHORT "ACFAE155"

// Error structure for Finance API calls
typedef struct
{
	DWORD   dwError;          // error code
	LONG    lSeverity;        // error severity (to decide handling procedure)
	LONG    lErrorType;       // type of error that occurred
	char    szErrorText[255]; // text decription of the error
	char    szErrorData[256]; // additional error data
	char    szModule[32];     // module name where error ocurred
	char    szProcedure[32];  // procedure name where error ocurred
	char	szSource[32];	  // source, from the VB error object
	char	szApplicationID[32];	  // source, from the VB error object
	LONG    lLine;            // line number where error ocurred
} ERR_ERROR_INFO;


// Logs errors to FINANCE.ERR
void WINAPI ERR_LogError( ERR_ERROR_INFO *pErrorInfo);    // error block
BOOL ERR_LogServiceError( ERR_ERROR_INFO *pErrorInfo);    // error block

// Get last error that was logged or handled
DWORD WINAPI ERR_GetLastError(void);

// Get the diagnostic level
DWORD WINAPI ERR_GetDebugLevel(void);

LONG WINAPI ERR_GetPanelId( LPSTR szApplId, DWORD dwError );
LONG WINAPI ERR_GetSeverity( LPSTR szApplId, DWORD dwError );

// Decode an error code into a text string explanation
LONG WINAPI ERR_GetMessageText( LPSTR szApplId,
	DWORD   dwError,		// error code
	LPSTR   pszBuffer,      // buffer to hold error text
	LONG    lBufferLen,     // length of buffer
	const char *szParm1,       // parameter string 1
	const char *szParm2);      // parameter string 2

// Base architecture error handler
LONG WINAPI ERR_HandleError(ERR_ERROR_INFO *pErrorInfo); // error block

// Process a windows error from GetLastError()
LONG WINAPI ERR_HandleSystemError(ERR_ERROR_INFO *pErrorInfo, 
	LONG lSeverity,
	char *szErrorData,
	char *szSource,
	char *szModule,
	char *szProcedure,
	LONG lLine);

// Handler service errors
LONG WINAPI ERR_HandleServiceError(ERR_ERROR_INFO *pErrorInfo); // error block

// Simply displays an error, without logging.
LONG WINAPI ERR_DisplayError(ERR_ERROR_INFO *pErrorInfo);

int WINAPI ERR_DisplayArchMessage( HWND hWnd, DWORD dwMessage, 
	const char *szTitle, UINT nType = MB_OK | MB_ICONWARNING, UINT nIDHelp = 0,
	const char *szParm1 = NULL, const char *szParm2 = NULL );

LONG WINAPI ERR_ThrowException(int nErrId, char *szMessage );

//***** DAA macros and functions
// Indicators for LUW functionality
#define DAA_LUW_SINGLE     83   // 'S'
#define DAA_LUW_FIRST      70   // 'F'
#define DAA_LUW_NEXT       78   // 'N'
#define DAA_LUW_LAST       76   // 'L'
#define DAA_LUW_PURGE      80   // 'P'
#define DAA_LUW_RETRY      82   // 'R'
#define DAA_LUW_CHG_PSWD   67   // 'C'
#define DAA_LUW_ASYNCH     65   // 'A'
#define DAA_LUW_TEST	84

// Function specific return codes for ErrorInfo.dwError
#define DAA_SUCCESS         0
#define DAA_END_OF_LIST     23
#define DAA_ROW_NOT_FOUND   27

// Message parameters structure
typedef struct
{
	LONG    lService;               // Service ID
	LONG    lVersion;               // Service version
	LONG    lListBlockNumber;       // List service block number
	LONG    lRowCount;              // Number of rows requested/returned
	LONG    lLUWID;                 // LUW ID for multi-LUW calls
	LONG    lLUWCode;              // LUW mode
	char    szApplicationID[15];    // Data source ID
    char    szRequestFormat[256];   // Request message format string
  	ERR_ERROR_INFO ErrorInfo;       // Error information block
} DAA_MESSAGE_PARMS;

// Perform a synchronous service call
DWORD WINAPI DAA_InvokeService(
    DAA_MESSAGE_PARMS *pMsgParms,   // Parameter block for service call
    LPVOID pRequestMsg,             // Request message structure
    LPVOID pAnswerMsg);             // Answer message structure

DWORD WINAPI DAA_InvokeService_NoThread(
    DAA_MESSAGE_PARMS *pMsgParms,   // Parameter block for service call
    LPVOID pRequestMsg,             // Request message structure
    LPVOID pAnswerMsg);             // Answer message structure

//***** SEC macros and functions
#define SEC_DATA_USER_ID        1
#define SEC_DATA_PASSWORD       2
#define SEC_DATA_LANGUAGE       3

#define SEC_ACCESS_MASK_READ	0X00000001
#define SEC_ACCESS_MASK_ADD		0X00000002
#define SEC_ACCESS_MASK_UPDATE	0X00000004
#define SEC_ACCESS_MASK_DELETE	0X00000008


// Presents user with login screen
BOOL WINAPI SEC_LoginUser(void);
// Presents user with dialog to change password
BOOL WINAPI SEC_ChangePassword(void);
// Returns user specific information 
LONG WINAPI SEC_GetUserString(
    LONG  lDataInd,     // flag indicating which string to return
    LPSTR pszBuffer,    // buffer to contain string value
    LONG  lBufferLen);  // length of string buffer
// Returns access level for client ID
LONG WINAPI SEC_GetClientAccess(
	LPSTR  pszClientID);  // client ID for access level


//***** UTL macros and functions
#define UTL_DATA_ARCH_VERSION       3
#define UTL_DATA_ARCH_DESCRIPTION   4

LONG WINAPI UTL_GetArchString(
    LONG   lDataInd,     // flag indicating which string to return
    LPSTR  pszBuffer,    // buffer to contain string value
    LONG   lBufferLen);  // length of string buffer


LONG WINAPI UTL_GetLocalPath( char *szApplName, char *szLocalPath, int nPathLen );
LONG WINAPI UTL_GetFinancePath( char *szNetworkPath, int nPathLen );
LONG WINAPI UTL_WaitStart( char *szMessage );
LONG WINAPI UTL_WaitMessage( char *szMessage );
LONG WINAPI UTL_WaitStop( void );

LONG WINAPI UTL_SetId( char *szUserId, char *szPassword );
LONG WINAPI UTL_GetId( char *szUserId, int nUserIdLen );

LONG WINAPI UTL_Memcmp( void *pA, void *pB, int nSize );
BOOL WINAPI UTL_FileExists( char *szFileName );

LONG WINAPI UTL_NullTerminate(
    LPSTR pBuffer,       // Space padded string buffer
    LONG  lBufferLen);   // Length of string buffer

LPSTR WINAPI UTL_StripFileName(
    LPSTR pszPathname); // Full path-name containing filename to strip

DWORD WINAPI UTL_StartApp(char *szFileName, 
	char *szCommandLine, BOOL bMultipleInstances );
DWORD WINAPI UTL_ActivateApp( char *szFileName );
DWORD WINAPI UTL_TerminateApp( char *szFileName );

//***** Architecture error messages
#define FY32_SUCCESS 0

#define FY32_ERR_BASE   0   // Base of error archicture error messages
#define FY32_ERR_MIN    10000 // ERR_MIN includes  10000 for socket errors too.

#define ARC_ERR_BASE 30000
#define ARC_ERR_MAX 39999

#define SOCKET_ERR_BASE 10000
#define SOCKET_ERR_MAX 19999

#define APPL_ERR_BASE 512
#define APPL_ERR_MAX 9999


// Generated message constants. DO NOT by hand, update o:\dmss\rewrite\management\arcmsgs.xls
#define FY32_UNKNOWN     FY32_ERR_BASE +  0
#define FY32_ERR_LOADING_MESSAGES      FY32_ERR_BASE +  30001
#define FY32_ERR_DAA_HOST_ENTRIES            FY32_ERR_BASE +  30002
#define FY32_ERR_DAA_HOST_CONNECT     FY32_ERR_BASE +  20003
#define FY32_ERR_DAA_SEND_DATA     FY32_ERR_BASE +  30004
#define FY32_ERR_DAA_RECEIVE_DATA     FY32_ERR_BASE +  30005
#define FY32_ERR_DAA_INIT     FY32_ERR_BASE +  30006
#define FY32_ERR_DAA_SHUTDOWN     FY32_ERR_BASE +  30007
#define FY32_ERR_DAA_INVALID_USER     FY32_ERR_BASE +  30008
#define FY32_ERR_DAA_INVALID_PASSWORD     FY32_ERR_BASE +  30009
#define FY32_ERR_DAA_SERVICE_ERROR     FY32_ERR_BASE +  30010
#define FY32_ERR_CNV_END_FORMAT_STR     FY32_ERR_BASE +  30011
#define FY32_ERR_CNV_INVALID_FMT_STR     FY32_ERR_BASE +  30012
#define FY32_ERR_CNV_END_ENCODE_STR     FY32_ERR_BASE +  30013
#define FY32_LOGON_INVALID_PASSWORD     FY32_ERR_BASE +  30014
#define FY32_LOGON_PASSWORD_EXPIRED     FY32_ERR_BASE +  30015
#define FY32_CHANGE_INVALID_PASSWORD     FY32_ERR_BASE +  30016
#define FY32_CHANGE_RETYPE_ERROR     FY32_ERR_BASE +  30017
#define FY32_CHANGE_INVALID_NEW_PW     FY32_ERR_BASE +  30018
#define FY32_CHANGE_PASSWORD_SUSPENDED     FY32_ERR_BASE +  30019
#define FY32_CHANGE_CANT_CHANGE_TODAY     FY32_ERR_BASE +  30020
#define FY32_CHANGE_SUCCESSFUL     FY32_ERR_BASE +  30021
#define FY32_ERROR_CANT_FIND_ERROR_FILE     FY32_ERR_BASE +  30022
#define FY32_ERROR_CANT_FIND_MESSAGE_FILE_NAME     FY32_ERR_BASE +  30023
#define FY32_ERROR_CANT_SEND_ERROR_INFO     FY32_ERR_BASE +  30024
#define FY32_ERROR_INFORMATION_SENT     FY32_ERR_BASE +  30025
#define FY32_CHANGE_PASSWORD_TOO_SHORT     FY32_ERR_BASE +  30026
#define FY32_UTL_COULDNOT_LOCATE     FY32_ERR_BASE +  30027
#define FY32_UTL_COULDNOT_ACTIVATE     FY32_ERR_BASE +  30028
#define FY32_UTL_COULDNOT_LOCATE_FILE     FY32_ERR_BASE +  30029
#define FY32_UTL_CANNOT_EXECUTE     FY32_ERR_BASE +  30030
#define FY32_UTL_COULD_NOT_TERMINATE     FY32_ERR_BASE +  30031
#define FY32_UTL_PROCESS_IS_RUNNING     FY32_ERR_BASE +  30032
#define FY32_UTL_PROCESS_IS_NOT_RUNNING     FY32_ERR_BASE +  30033
#define FY32_CNV_CONVERSION_OVERFLOW     FY32_ERR_BASE +  30034
#define FY32_UTL_CANT_LOCATE_FINANCE_PATH     FY32_ERR_BASE +  30035
#define FY32_UTL_CANT_LOCATE_LOCAL_PATH     FY32_ERR_BASE +  30036
#define FY32_UTL_ERROR_GETTING_ARCH_STRING     FY32_ERR_BASE +  30037
#define FY32_ERR_UTL_STRING_TOO_LONG     FY32_ERR_BASE +  30038
#define FY32_LOGON_UNKNOWN_USER     FY32_ERR_BASE +  30039
#define FY32_GENERIC_ERROR     FY32_ERR_BASE +  30040
#define FY32_ECA_SAP_SFE_ERROR     FY32_ERR_BASE +  30041
#define FY32_UTL_CANT_START_WAIT     FY32_ERR_BASE +  30042
#define FY32_UTL_CANT_SET_WAIT_MSG     FY32_ERR_BASE +  30043
#define FY32_UTL_CANT_STOP_WAIT     FY32_ERR_BASE +  30044
#define FY32_FTP_CANNOT_CONNECT_TO_SERVER     FY32_ERR_BASE +  30045
#define FY32_FTP_INVALID_URL     FY32_ERR_BASE +  30046
#define FY32_FTP_CANNOT_CREATE_SESSION     FY32_ERR_BASE +  30047
#define FY32_FTP_CANNOT_FIND_REMOTE_FILE     FY32_ERR_BASE +  30048
#define FY32_FTP_CANNOT_CREATE_LOCAL_FILE     FY32_ERR_BASE +  30049
#define FY32_FTP_CANNOT_CREATE_REMOTE_FILE     FY32_ERR_BASE +  30050
#define FY32_FTP_CANNOT_FIND_LOCAL_FILE     FY32_ERR_BASE +  30051
#define FY32_FTP_FATAL_ERROR     FY32_ERR_BASE +  30052
#define FY32_MAIL_CANNOT_LOCATE_ADDRESS     FY32_ERR_BASE +  30053
#define FY32_MAIL_CANNOT_PREPARE_MSG_FILE     FY32_ERR_BASE +  30054
#define FY32_SOCKET_NETDOWN     FY32_ERR_BASE +  10050
#define FY32_SOCKET_CONNABORTED     FY32_ERR_BASE +  10053
#define FY32_SOCKET_SERVICE_ABEND     FY32_ERR_BASE +  10054
#define FY32_SOCKET_NOTCONN     FY32_ERR_BASE +  10057
#define FY32_SOCKET_TIMEDOUT     FY32_ERR_BASE +  10060
#define FY32_SOCKET_CONNREFUSED     FY32_ERR_BASE +  10061
#define FY32_SOCKET_HOSTUNREACH     FY32_ERR_BASE +  10065
#define FY32_SOCKET_BAD_PORT     FY32_ERR_BASE +  10071
#define FY32_ECA_BUSY     FY32_ERR_BASE + -1
#define FY32_ECA_ERROR     FY32_ERR_BASE + -2
#define FY32_ECA_FATAL_ERROR     FY32_ERR_BASE + -3
#define FY32_ECA_COMMAND_ERROR     FY32_ERR_BASE + -4
#define FY32_ECA_INVALID_NAME     FY32_ERR_BASE + -5
#define FY32_ECA_NAME_IN_USE     FY32_ERR_BASE + -6
#define FY32_ECA_NO_SESSION     FY32_ERR_BASE + -7
#define FY32_ECA_CONFIG_ERROR     FY32_ERR_BASE + -8
#define FY32_ECA_SESSION_CREATION_ERROR     FY32_ERR_BASE + -9
#define FY32_ECA_COMMAND_TIME_OUT     FY32_ERR_BASE + -10
#define FY32_ECA_RECEIVE_MORE_DATA     FY32_ERR_BASE + -11
#define FY32_ECA_NO_RESONSE_1     FY32_ERR_BASE + -12
#define FY32_ECA_NO_RESONSE_2     FY32_ERR_BASE + -13
#define FY32_ECA_NOT_LOADED     FY32_ERR_BASE + -14
#define FY32_ECA_LOST_CONNECTION     FY32_ERR_BASE + -15
#define FY32_ECA_BUFFER_TOO_SMALL     FY32_ERR_BASE + -16
#define FY32_ECA_SERVICE_UNAVAILABLE     FY32_ERR_BASE + -17
#define FY32_ECA_EXCLUDED     FY32_ERR_BASE + -18
// End Generated message constants.

//***** Common macros *****
#define NULL_CHAR   '\0' 
#define NULL_STRING ""

#define UNLEN 50    // User name length (should be including ?????.h)

#define FY32_USER_ID "FINARCH" // User ID/Password for arch based service calls

//***** Structures and macros for architecture shared data area
#define DLL_DATA_NAME   "fy32_shared_data"
#define DLL_DATA_VER    1
    
typedef struct {
    char szNetworkDir[256];
    } DLL_ARCH_DATA;

#define DLL_USER_ACCESS_RECORDS 500
#define DLL_USER_ACCESS_CLIENT_SIZE 6

typedef struct {
    char szClientId[DLL_USER_ACCESS_CLIENT_SIZE];
    int  nAccess;
    } DLL_USER_ACCESS_DATA;

typedef struct {
    char szUserID[UNLEN + 1];
    char szPassword[UNLEN + 1];
    char cLanguage;
    DLL_USER_ACCESS_DATA UserAccess[DLL_USER_ACCESS_RECORDS];
	int nAccessRecords;
    } DLL_SECURITY_DATA;

typedef struct {
    int nVersion;
    DLL_ARCH_DATA ArchData;
    DLL_SECURITY_DATA SecurityData;
    } DLL_DATA_STRUCT;


//***** Global variables of DLL 
extern HINSTANCE ghInstance;        // instance handle of DLL
extern DLL_DATA_STRUCT *gpDLLData;  // pointer to shared memory structure

//***** Macros for architecture INI, and error files
// Architecture entries
#define INI_FILE_NAME "fy32.ini" // it's located in the Windows directory
#define INI_SVCMSG_FILE_NAME "svcmsg.ini" // it's located in the arc directory
#define ERR_LOG_FILENAME "finance.err"
#define INI_ARCH_SECTION "32-bit Architecture"

#define INI_MSG_SECTION "ERR_Messages"
#define INI_PANEL_SECTION "ERR_HelpPanel"
#define INI_SEVERITY_SECTION "ERR_Severity"

#define INI_KEY_MSG_FILE "MessageFile"
#define INI_KEY_PERF_DATA "PerfData"
#define INI_KEY_LAST_LOGIN_ID "LastLoginID"
#define INI_KEY_DATABASE_ID "DatabaseID"
#define INI_KEY_DEBUG_LEVEL "DebugLevel"
#define INI_KEY_EMAIL_ERROR "ErrorEmail"
#define INI_KEY_DEV_EMAIL_ERROR "DevEmail"

#define INI_VALUE_TRUE "Y"
#define INI_VALUE_FALSE "N"

// Service call entries per application ID
#define INI_KEY_SVC_TIMEOUT "SvcTimeout" 
#define INI_KEY_ACK_TIMEOUT "AckTimeout" 
#define INI_KEY_SVC_SAP "SAP"  // For ECA
#define INI_KEY_SVC_HOST "SvcHost"  // For Sockets
#define INI_KEY_SVC_PORT "SvcPort"
#define INI_KEY_SVC_HOST_TYPE "SvcHostType"
#define INI_KEY_SVC_NAME "SvcName"  // For connection through SAP (ECA)

// Local directory for components
#define FY32_LOCAL_DIR "C:\\FY32"
#define FY32_ARCH_DIR "\\ARC"


//***** Architecture private function prototypes
BOOL _daaInit(void);        // Initialize DAA communications
BOOL _daaShutdown(void);    // Shutdown DAA communications
BOOL _errInit(void);        // Initializes the error handling components

//***** CNV macros and functions
#define CNV_MAX_ENCODE_STR_LEN 32767

DWORD WINAPI CNV_EncodeStruct(
    LPVOID pStruct,       // Structure to encode
    LPSTR  pszFormatStr,  // Format string describing structure layout
    LPSTR  pszEncodeStr); // String buffer to place encoded string (assumed to be large enough to hold string)
DWORD WINAPI CNV_DecodeStruct(
    LPVOID pStruct,       // Structure to fill with decoded data
    LPSTR  pszFormatStr,  // Format string describing structure layout
    LPSTR  pszEncodeStr); // encoded string to decode
DWORD WINAPI CNV_GetEncodeStringLen(
    LPSTR pszFormatStr);
LPSTR WINAPI CNV_ConvertEBCDICToASCII(
    LPSTR pBuffer,
    LONG  lBufferLen);
LPSTR WINAPI CNV_ConvertASCIIToEBCDIC(
    LPSTR pBuffer,
    LONG  lBufferLen);

int WINAPI CNV_Test( void *pData, int nSize, char *szFileName );

int WINAPI FTP_PutFile( char *szUserId,
	char *szPassword,
	char *szFTPSite,
	char *szLocalFile,
	char *szFTPFile );

int WINAPI FTP_GetFile( char *szUserId,
	char *szPassword,
	char *szFTPSite,
	char *szLocalFile,
	char *szFTPFile );

int  WINAPI MAIL_SendMessageFile( char *szTo, char *szFrom, char *szSubject,  char *szFileName );

// Local MAIL functions, not exported.
int MAIL_GetApplAddress( char *szApplId, char *szAddress );
int MAIL_GetArchAddress( char *szAddress );


#endif // !defined(INCLUDED_FYARC32)
