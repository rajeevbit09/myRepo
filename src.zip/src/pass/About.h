// About.h :		header file
//
// Description:		For displaying Pass 2000 information.
//
// Author:			Joseph Fletcher - DT, Inc.
//
// Date:			4/16/1999

#if !defined(AFX_ABOUT_H__C94B8C14_903C_11D2_A2C3_00104B9856BB__INCLUDED_)
#define AFX_ABOUT_H__C94B8C14_903C_11D2_A2C3_00104B9856BB__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CFYDialog
{
public:
//	CAboutDlg();
	CAboutDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CString	m_strAppVersion;
	CString	m_strArchVersion;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void CAboutDlg::SetVersionInfo();

	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	afx_msg LRESULT OnSetWindowState(  WPARAM wParam, LPARAM lParam );
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ABOUT_H__C94B8C14_903C_11D2_A2C3_00104B9856BB__INCLUDED_)
