// AlertsEmbargoes.cpp : implementation file
//

#include "stdafx.h"
#include "pass.h"
#include "AlertsEmbargoes.h"

#include <fyr04769.h>
#include <fya04769.h>
#include <fyr04770.h>
#include <fya04770.h>
#include <fyr04771.h>
#include <fya04771.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define REQ_4769	AlertList.m_pRequest->R04769_appl_area
#define	ANS_4769	AlertList.m_pAnswer->A04769_appl_area
#define REQ_4770	AlertData.m_pRequest->R04770_appl_area
#define	ANS_4770	AlertData.m_pAnswer->A04770_appl_area
#define REQ_04771	UpdateAlert.m_pRequest->R04771_appl_area
#define ANS_04771	UpdateAlert.m_pAnswer->A04771_appl_area


/////////////////////////////////////////////////////////////////////////////
// CAlertsEmbargoes dialog


CAlertsEmbargoes::CAlertsEmbargoes(CWnd* pParent /*=NULL*/)
	: CFYDialog(CAlertsEmbargoes::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAlertsEmbargoes)
	//}}AFX_DATA_INIT
}


void CAlertsEmbargoes::DoDataExchange(CDataExchange* pDX)
{
	CFYDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAlertsEmbargoes)
	DDX_Control(pDX, IDC_BUTTON_ADDSAVE, m_btnAddSave);
	DDX_Control(pDX, IDC_LIST_ALERT_EMBARGO, m_lstAlertsEmbargoes);
	DDX_Control(pDX, IDC_EDIT_URL, m_edtUrl);
	DDX_Control(pDX, IDC_EDIT_START_DATE, m_edtStartDate);
	DDX_Control(pDX, IDC_EDIT_END_DATE, m_edtEndDate);
	DDX_Control(pDX, IDC_EDIT_ALERT_EMBARGO, m_edtAlertEmbargo);
	DDX_Control(pDX, IDC_COMBO_TYPE, m_cmbType);
	DDX_Control(pDX, IDC_COMBO_STATION, m_cmbStation);
	DDX_Control(pDX, IDC_RADIO_CURRENT, m_optCurrent);
	DDX_Control(pDX, IDC_RADIO_ALL, m_optAll);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAlertsEmbargoes, CDialog)
	//{{AFX_MSG_MAP(CAlertsEmbargoes)
	ON_BN_CLICKED(IDC_RADIO_CURRENT, OnRadioCurrent)
	ON_BN_CLICKED(IDC_RADIO_ALL, OnRadioAll)
	ON_BN_CLICKED(IDC_BUTTON_ADDSAVE, OnButtonAddSave)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_SETWINDOWSTATE, OnSetWindowState)
	ON_MESSAGE(WM_BEFOREROWCHANGE, OnBeforeRowChange)
	ON_MESSAGE(WM_ROWCHANGE, OnRowChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAlertsEmbargoes message handlers
LRESULT CAlertsEmbargoes::OnSetWindowState(WPARAM wParam, LPARAM lParam)
{
	// First call the default handler
	CFYDialog::OnSetWindowState(wParam, lParam);

	// Define BOOL variables for enable/disable flags
	BOOL bModified = IsModified();
	BOOL bSelected = ( m_lstAlertsEmbargoes.GetSelectedIndex() != LB_ERR );
	BOOL bAddSaveEnabled = FALSE;

	if( bModified )
	{
		m_btnAddSave.SetWindowText( "&Save" );
		bAddSaveEnabled = IsValid();
	}
	else
	{
		m_btnAddSave.SetWindowText( "&Add" );
		bAddSaveEnabled = TRUE;
	}


	// Enable disable controls
	m_btnAddSave.EnableWindow( bAddSaveEnabled );
	// Update security settings
	UpdateSecuredObjects();

	return TRUE;
}

BOOL CAlertsEmbargoes::OnInitDialog()
{
	CDialog::OnInitDialog();


	// Add Columns to list control
	m_lstAlertsEmbargoes.InsertColumn( "Station", 50, ARPT_CD, LVCFMT_LEFT );
	m_lstAlertsEmbargoes.InsertColumn( "Alert/Embargo", 50, TRVL_ALRT_CD, LVCFMT_LEFT );
	m_lstAlertsEmbargoes.InsertColumn( "Start Date", 50, TRVL_ALRT_STRT_DT, LVCFMT_LEFT | LVCFMT_SORTDATE );
	m_lstAlertsEmbargoes.InsertColumn( "End Date", 50, TRVL_ALRT_END_DT, LVCFMT_LEFT | LVCFMT_SORTDATE );
	m_lstAlertsEmbargoes.InsertColumn( "Message", 200, TRVL_ALRT_MSG_TXT, LVCFMT_LEFT);
	//m_lstAlertsEmbargoes.InsertColumn( "URL", 100, TRVL_ALRT_URL_ADR, LVCFMT_LEFT);

	// Hide all columns which are just for data storage
	//m_lstAlertsEmbargoes.SetColumnHidden( LST_UPDT_ID, TRUE );
	//m_lstAlertsEmbargoes.SetColumnHidden( LST_UPDT_GTS, TRUE );

	// Set list box column properties
	m_lstAlertsEmbargoes.SetColumnDisplayType( TRVL_ALRT_STRT_DT, STDDATE );
	m_lstAlertsEmbargoes.SetColumnDisplayType( TRVL_ALRT_END_DT, STDDATE );

	// Set the list box row selection style
	m_lstAlertsEmbargoes.SetSelectStyle( FY_ROWONLY );

	// declare empty structure to get field sizes from
	_A04770_APPL_AREA* pStruct = NULL;

	// Set length restrictions here
	//m_edtCurrency.LimitText( sizeof(pStruct->sFltFeeCurrCd) - 1 );
	m_edtAlertEmbargo.LimitText( sizeof(pStruct->sTrvlAlrtMsgTxt) - 1);
	m_edtUrl.LimitText( sizeof(pStruct->sTrvlAlrtUrlAdr) - 1);


	// Set required fields here
	m_cmbStation.SetRequired( TRUE );
	m_cmbType.SetRequired( TRUE );
	m_edtStartDate.SetRequired( TRUE );
	m_edtEndDate.SetRequired( TRUE );
	m_edtAlertEmbargo.SetRequired( TRUE );

	// Set combo box properties
	m_cmbStation.InsertStringMap( MAP(m_mapArpt) );
	m_cmbStation.InsertString( 0, "ALL", "ALL AIRPORTS" );
	m_cmbStation.SetListPropertyType(CFYComboBox::CODE_DECODE);
	m_cmbStation.SetEditPropertyType(CFYComboBox::CODE_DECODE);

	m_cmbType.InsertString(0,"A","A");
	m_cmbType.InsertString(1,"E","E");
	m_cmbType.SetListPropertyType(CFYComboBox::CODE_DECODE);
	m_cmbType.SetEditPropertyType(CFYComboBox::CODE_DECODE);

	m_ShowTypeGroup.AddRadioButton( m_optCurrent );
	m_ShowTypeGroup.AddRadioButton( m_optAll );

	// Set field level security here
	AddSecuredObject( &m_lstAlertsEmbargoes, SEC_ALERTS_EMBARGOES_LIST );
	AddSecuredObject( &m_cmbStation, SEC_ARPT_COMBO );
	AddSecuredObject( &m_cmbType, SEC_TYPE_COMBO );
	AddSecuredObject( &m_edtStartDate, SEC_START_DATE );
	AddSecuredObject( &m_edtEndDate, SEC_END_DATE );
	AddSecuredObject( &m_optCurrent, SEC_CURRENT_OPT );
	AddSecuredObject( &m_optAll, SEC_ALL_OPT );
	AddSecuredObject( &m_edtAlertEmbargo, SEC_ALERT_EMBARGO_EDIT );
	AddSecuredObject( &m_edtUrl, SEC_URL_EDIT );
	AddSecuredObject( &m_btnAddSave , SEC_ADDSAVE_BUTTON );

	// Load List with data
	//FillAlertsEmbargoesList();
	m_optCurrent.SetCheck(BST_CHECKED);
	OnRadioCurrent();

	// Size the columns to fit the data
	m_lstAlertsEmbargoes.AutoSizeColumns();

	m_lstAlertsEmbargoes.SetAllowReorderColumns( TRUE );
	OnSetWindowState( NULL, NULL);

	return TRUE;
}

// This procedure is called by the architecture whenever a user presses OK/Apply on
// a property sheet or answers yes to the save question which is popped up when they
// try to leave a sheet with changes.
BOOL CAlertsEmbargoes::OnCloseAndSave()
{
	// Call the save method
	return PerformSave();
}

// This handler is fired in response to a WM_BEFOREROWCHANGE message from the listbox.
// It is used to make a user save or abandon changes before moving on to another Alerts or Embargoes
LRESULT CAlertsEmbargoes::OnBeforeRowChange(WPARAM wParam, LPARAM lParam)
{
	// Only handle if the row has been modified
	if( IsModified()  )
	{
		// If the fee is not completed
		if( !IsValid() )
		{
			// If the user doesn't confirm the change, don't change the row.
			if( AfxMessageBox( MSG_CONFIRM_INVALID_ROW, MB_YESNO | MB_ICONQUESTION ) == IDNO)
				return TRUE; // Prevent the row change

			return FALSE; // Allow the row change
		}

		// If here, the row is valid so lets confirm they want to change rows without saving
		switch( AfxMessageBox( MSG_CONFIRM_ROW_CHANGE, MB_YESNOCANCEL | MB_ICONQUESTION ) )
		{
		case IDYES:
			// Save the changes, and change the row.
			if( !OnCloseAndSave() )
				return TRUE; // Prevent the row change
			break;

		case IDNO:
			return FALSE; // Allow the row change
			break;

		default:
		case IDCANCEL:
			return TRUE; // Prevent the row change
			break;
		}
	}

	return FALSE; // Allow the row change
}

//  This event handler is fired when a WM_ROWCHANGE message is fired by the listbox.
LRESULT CAlertsEmbargoes::OnRowChange(WPARAM wParam, LPARAM lParam)
{
	FillAlertEmbargoDetail();
	return 0;
}

void CAlertsEmbargoes::OnButtonAddSave()
{
	CString strCaption;
	m_btnAddSave.GetWindowText( strCaption );

	// Try to save the fee if the caption was save
	if( strCaption == "&Save" )
	{
		PerformSave();
	}
	else	// must be add
	{
		// Deselect all rows in the listbox
		m_lstAlertsEmbargoes.SetCurrentCell( -1, -1 );
		// Note: fields will be blanked for new entry by the FillFeeDetail called
		//       from the row change event
	}
}

// Fills the detail fields with the values from the selected row
BOOL CAlertsEmbargoes::FillAlertEmbargoDetail()
{
	int nItem = m_lstAlertsEmbargoes.GetSelectedItem();
	CString tmpArptCd;
	CString strTmp;


	// If no row is selected lets blank out all of the fields
	if( nItem < 0 )
	{
		m_cmbStation.SetCode( "   " );
		m_cmbType.SetCode(" ");
		m_edtStartDate.SetDate( CONST_BLANK_DATE );
		m_edtEndDate.SetDate( CONST_BLANK_DATE );
		m_edtAlertEmbargo.SetText("");
		m_edtUrl.SetText("");

		//Remove read only from fields
		m_cmbStation.SetReadOnly(FALSE);
		m_cmbType.SetReadOnly(FALSE);
		m_edtStartDate.SetReadOnly(FALSE);
		m_edtAlertEmbargo.SetReadOnly(FALSE);
		m_edtUrl.SetReadOnly(FALSE);
		//return TRUE;
	}
	else
	{
		// Fill all detail fields
		TRY
		{
			MESSAGE( AlertData, 4770 );

			// Populate the request
			tmpArptCd = m_lstAlertsEmbargoes.GetSelectedItemText(ARPT_CD);
			tmpArptCd.TrimRight();
			strcpy( REQ_4770.sArptCd,  tmpArptCd);
			REQ_4770.cTrvlAlrtCd = m_lstAlertsEmbargoes.GetSelectedItemText(TRVL_ALRT_CD)[0];
			strcpy( REQ_4770.sTrvlAlrtStrtDt, m_lstAlertsEmbargoes.GetSelectedItemText(TRVL_ALRT_STRT_DT));
			strcpy( REQ_4770.sTrvlAlrtEndDt, m_lstAlertsEmbargoes.GetSelectedItemText(TRVL_ALRT_END_DT));

			AlertData.m_pMsgParms->lService = 4770;

			switch( AlertData.InvokeService() )
			{
			case DAA_SUCCESS:
				m_cmbStation.SetCode(tmpArptCd);
				strTmp = (CString)m_lstAlertsEmbargoes.GetSelectedItemText(TRVL_ALRT_CD);
				m_cmbType.SetCode( strTmp );
				m_edtStartDate.SetDate(  m_lstAlertsEmbargoes.GetSelectedItemText(TRVL_ALRT_STRT_DT) );
				m_edtEndDate.SetDate(  m_lstAlertsEmbargoes.GetSelectedItemText(TRVL_ALRT_END_DT) );
				m_edtAlertEmbargo.SetText( ANS_4770.sTrvlAlrtMsgTxt );
				m_edtUrl.SetText( ANS_4770.sTrvlAlrtUrlAdr );

				//Making fields read only
				m_cmbStation.SetReadOnly(TRUE);
				m_cmbType.SetReadOnly(TRUE);
				//m_edtStartDate.SetReadOnly(TRUE);
				m_edtAlertEmbargo.SetReadOnly(TRUE);
				m_edtUrl.SetReadOnly(TRUE);
				break;

			case DAA_ROW_NOT_FOUND:
				AfxMessageBox("Alert/Embargo detail not found");
				//return FALSE;
				break;

			default:
				// Optionally add context sensitive informtion to the error.
				sprintf( AlertData.m_pMsgParms->ErrorInfo.szErrorText, "Error retrieving Alert/Embargo data" );
				AlertData.ThrowException();
				break;
			}
			UpdateData(FALSE);
		}
		CATCH( CFYException, e )
		{
			e->Display();
		}
		END_CATCH
	}
	// Set modified status to false
	SetControlState(FIELD_CLEAN);

	// Update controls on the form
	OnSetWindowState( NULL, NULL);

	return TRUE;
}

BOOL CAlertsEmbargoes::FillAlertsEmbargoesList(char selTyp)
{
	// Local variables
	int nItem;
	int i;
	CString strTmp;

	// Clear any existing values in the list
	m_lstAlertsEmbargoes.DeleteAllItems();

	CWaitCursor Wait;

	TRY
	{
		MESSAGE ( AlertList, 4769 );

		BOOL		bContinue = TRUE;
		LONG		lBlockNum = 1;
		REQ_4769.cSelectionType = selTyp;
		AlertList.m_pMsgParms->lRowCount = _A04769__A04769_APPL_AREA_SIZE;

		while (bContinue)  //  While we think there is more data to get.
		{
			bContinue = FALSE;  //  Always assume there is no more.
			AlertList.m_pMsgParms->lListBlockNumber = lBlockNum;
			switch ( AlertList.InvokeService() )
			{
			case DAA_SUCCESS:
				//  There IS more data to get after this chunk.
				lBlockNum++;
				bContinue = TRUE;
				//  Flow through to the DAA_END_OF_LIST case.

			case DAA_END_OF_LIST:
				// loop through each row in the answer block
				for (i = 0; i < AlertList.m_pMsgParms->lRowCount; i++)
				{
					// Add the item to the list and set the column values
					nItem = m_lstAlertsEmbargoes.AddItem();

					m_lstAlertsEmbargoes.SetCellText( nItem, ARPT_CD, ANS_4769[i].sArptCd );
					m_lstAlertsEmbargoes.SetCellText( nItem, TRVL_ALRT_CD, (CString)ANS_4769[i].cTrvlAlrtCd  );
					m_lstAlertsEmbargoes.SetCellText( nItem, TRVL_ALRT_STRT_DT, ANS_4769[i].sTrvlAlrtStrtDt  );
					m_lstAlertsEmbargoes.SetCellText( nItem, TRVL_ALRT_END_DT, ANS_4769[i].sTrvlAlrtEndDt  );
					m_lstAlertsEmbargoes.SetCellText( nItem, TRVL_ALRT_MSG_TXT, ANS_4769[i].sTrvlAlrtMsgTxt );

				}
				break;

			case DAA_ROW_NOT_FOUND:
				break;

			default:
				strcpy (AlertList.m_pMsgParms->ErrorInfo.szErrorText,
						"Service 4769 failed.");
				AlertList.ThrowException();
				return FALSE;
				break;
			}
		}
	}

	// Select the first row if there is one
	if( m_lstAlertsEmbargoes.GetItemCount() > 0 )
	{
		m_lstAlertsEmbargoes.SetCurrentCell(0,0);
	}
	else
	{
		FillAlertEmbargoDetail();
	}

	CATCH( CFYException, e )
	{
		e->Display();
	}
	END_CATCH
	return TRUE;
}

// Validate and save the current detail section.
// A single complex service (4771) is called for add/modify (modify is treated as a
// combination of add and insert).
BOOL CAlertsEmbargoes::PerformSave()
{

	int selItem = m_lstAlertsEmbargoes.GetSelectedItem();
	CString tmpArptCd;
	CString strTmp;

	// Verify everything
	if( !ValidateAlertEmbargoData() )
	{
		return FALSE;
	}

	// Complex service 4771 is used for add & modify
	MESSAGE( UpdateAlert, 4771 );

	TRY
	{
		// If no row is selected lets blank out all of the fields
		if( selItem < 0 )
		{
			REQ_04771.cTransType = 'A'; //Set the indicator for Inserting the record
			strcpy(REQ_04771.sPrevArptCd, "     ");
			REQ_04771.cPrevTrvlAlrtCd = ' ';
			strcpy(REQ_04771.sPrevTrvlAlrtStrtDt, CONST_BLANK_DATE);
			strcpy(REQ_04771.sPrevTrvlAlrtEndDt, CONST_BLANK_DATE);
		}
		else
		{
			REQ_04771.cTransType = 'U';//Set the indicator for Updating the record
			tmpArptCd = m_lstAlertsEmbargoes.GetSelectedItemText(ARPT_CD);
			tmpArptCd.TrimRight();
			strcpy( REQ_04771.sPrevArptCd,  tmpArptCd);
			REQ_04771.cPrevTrvlAlrtCd = m_lstAlertsEmbargoes.GetSelectedItemText(TRVL_ALRT_CD)[0];
			strcpy( REQ_04771.sPrevTrvlAlrtStrtDt, m_lstAlertsEmbargoes.GetSelectedItemText(TRVL_ALRT_STRT_DT));
			strcpy( REQ_04771.sPrevTrvlAlrtEndDt, m_lstAlertsEmbargoes.GetSelectedItemText(TRVL_ALRT_END_DT));
		}
		// Fill in the Add section from the edit and combo boxes
		strcpy( REQ_04771.sArptCd,  m_cmbStation.GetCode());
		REQ_04771.cTrvlAlrtCd = m_cmbType.GetCode()[0];
		strcpy( REQ_04771.sTrvlAlrtStrtDt, m_edtStartDate.GetDate());
		strcpy( REQ_04771.sTrvlAlrtEndDt, m_edtEndDate.GetDate());

		m_edtAlertEmbargo.ReplaceCharSpace('\'');
		strcpy( REQ_04771.sTrvlAlrtMsgTxt, m_edtAlertEmbargo.GetText());
		strcpy( REQ_04771.sTrvlAlrtUrlAdr, m_edtUrl.GetText());

		switch( UpdateAlert.InvokeService() )
		{
		case DAA_SUCCESS:
			break;

		default:
			strcpy( UpdateAlert.m_pMsgParms->ErrorInfo.szErrorText, "Error updating Alerts/Embargo." );
			UpdateAlert.ThrowException();
			break;
		}

	}
	CATCH( CFYException, e )
	{
		e->Display();
		return FALSE;
	}
	END_CATCH

	// If here we have successfully saved - we need to save the key
	// values so that we can reposition to the row
	CString strArptCd = REQ_04771.sArptCd;
	CString strAlrtCd  = (CString)REQ_04771.cTrvlAlrtCd;
	CString strBegDate = REQ_04771.sTrvlAlrtStrtDt;
	CString strEndDate = REQ_04771.sTrvlAlrtEndDt;

	// Turn list painting off
	m_lstAlertsEmbargoes.SetRedraw( FALSE );

	// Reload the list
	OnRadioCurrent();

	// Reposition to the added/modified row
	int nItem = -2;
	int nCol = ARPT_CD;
	while( nItem != -1 )
	{
		nItem = m_lstAlertsEmbargoes.Search( strArptCd, &nCol, nItem+1, TRUE, TRUE );

		if( nItem != -1 )
		{
			if( (m_lstAlertsEmbargoes.GetCellText(nItem, TRVL_ALRT_CD) == strAlrtCd) &&
				(m_lstAlertsEmbargoes.GetCellText(nItem, TRVL_ALRT_STRT_DT) == strBegDate) &&
				(m_lstAlertsEmbargoes.GetCellText(nItem, TRVL_ALRT_END_DT) == strEndDate))
			{
				break;
			}
		}
	}

	if( nItem != -1 )
	{
		m_lstAlertsEmbargoes.SetCurrentCell( nItem, 0 );
	}

	// Resort the listbox as it was before the change
	m_lstAlertsEmbargoes.ReapplyLastSort();

	// Turn list painting back on
	m_lstAlertsEmbargoes.SetRedraw( TRUE );

	// Enable/Disable buttons
	OnSetWindowState( NULL, NULL );

	return TRUE;
}


// Function to validate field data before a save.
BOOL CAlertsEmbargoes::ValidateAlertEmbargoData()
{
	// Validate Dates
	long lJulianBeginDate = m_edtStartDate.GetJulianDate();
	long lJulianEndDate = m_edtEndDate.GetJulianDate();

	if( lJulianBeginDate > lJulianEndDate )
	{
		AfxMessageBox(MSG_INTL_FEE_DATERANGE_INVALID);
		m_edtStartDate.SetFocus();
		return FALSE;
	}

	return TRUE;
}


void CAlertsEmbargoes::OnRadioCurrent()
{
	FillAlertsEmbargoesList('C');
	// TODO: Add your control notification handler code here

}

void CAlertsEmbargoes::OnRadioAll()
{
	FillAlertsEmbargoesList('A');

}

