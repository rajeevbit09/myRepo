/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02678                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/13/97                                                */
/*              Time: 13:32:10                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02678                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002489_LEN                                                          
#define   FY002489_LEN                         26                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002838_LEN                                                          
#define   FY002838_LEN                         6                                
#endif                                                                          
#ifndef   FY002839_LEN                                                          
#define   FY002839_LEN                         6                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002794_LEN                                                          
#define   FY002794_LEN                         9                                
#endif                                                                          
#ifndef _A02678_APPL_AREA_z                                                     
#define _A02678_APPL_AREA_z                                                     
typedef struct __A02678_appl_area                                               
{                                                                               
   long                lPassTripNbr;                                            
   char                sPassGrpCd[FY002488_LEN];                                
   char                sPassGrpDs[FY002489_LEN];                                
   char                sPprNbr[FY002479_LEN];                                   
   char                sPprNm[FY002480_LEN];                                    
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevNm[FY002531_LEN];                                   
   char                sFltTripOrigId[FY002838_LEN];                            
   char                sFltTripDestId[FY002839_LEN];                            
   char                sFltDprtDt[FY003584_LEN];                                
   double              fFltImptValAmt;                                          
   float               fNrevPmtAmt;                                             
   double              fFltImptWageAmt;                                         
   char                sPprInttxNbr[FY002794_LEN];                              
   double              fCurrExchgRatNbr;
}  _A02678_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02678_z                                                               
#define _A02678_z                                                               
                                                                                
   typedef struct __A02678                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02678_APPL_AREA A02678_appl_area;                                       
   }  _A02678;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02678_FMT
#define FYA02678_FMT     "k88lz6s3s26s10s31s3s31s6s6s27dw7.2fw5.2dw7.2s9"
#endif
