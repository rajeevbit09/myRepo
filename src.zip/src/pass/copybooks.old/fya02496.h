/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02496                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/25/95                                                */
/*              Time: 11:37:54                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02496                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02496_APPL_AREA_z                                                     
#define _A02496_APPL_AREA_z                                                     
typedef struct __A02496_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02496_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02496_z                                                               
#define _A02496_z                                                               
                                                                                
   typedef struct __A02496                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02496_APPL_AREA A02496_appl_area;                                       
   }  _A02496;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02496_FMT
#define FYA02496_FMT     "k88s27"
#endif
