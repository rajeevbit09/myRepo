/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02635                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 01/11/96                                                */
/*              Time: 09:20:45                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02635                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002778_LEN                                                          
#define   FY002778_LEN                         11                               
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef _A02635_APPL_AREA_z                                                     
#define _A02635_APPL_AREA_z                                                     
typedef struct __A02635_appl_area                                               
{                                                                               
   char                sTktNbr[FY002778_LEN];                                   
   char                sFltNbr[FY002553_LEN];                                   
}  _A02635_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02635_z                                                               
#define _A02635_z                                                               
                                                                                
   typedef struct __A02635                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02635_APPL_AREA A02635_appl_area;                                       
   }  _A02635;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02635_FMT
#define FYA02635_FMT     "k88s11s6"
#endif
