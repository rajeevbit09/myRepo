/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02692                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 03/06/96                                                */
/*              Time: 13:11:01                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02692                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02692__A02692_APPL_AREA_SIZE                                        
#define   _A02692__A02692_APPL_AREA_SIZE       200                              
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002778_LEN                                                          
#define   FY002778_LEN                         11                               
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002631_LEN                                                          
#define   FY002631_LEN                         1                                
#endif                                                                          
#ifndef   FY003210_LEN                                                          
#define   FY003210_LEN                         3                                
#endif                                                                          
#ifndef   FY002703_LEN                                                          
#define   FY002703_LEN                         3                                
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02692_APPL_AREA_z                                                     
#define _A02692_APPL_AREA_z                                                     
typedef struct __A02692_appl_area                                               
{                                                                               
   char                sFltDprtDt[FY003584_LEN];                                
   char                sFltNbr[FY002553_LEN];                                   
   char                sTktNbr[FY002778_LEN];                                   
   char                sFltOrigCtyId[FY002521_LEN];                             
   char                sFltDestCtyId[FY002522_LEN];                             
   short               nFltDprtTm;                                              
   char                cFltMatchInd;                                            
   char                sFltOalFlnInd[FY003210_LEN];                             
   long                lFltChrgRfrnDt;                                          
   char                sFltClsSvcId[FY002703_LEN];                              
   char                sPassTypCd[FY002496_LEN];                                
   char                sArchLastUpdtTs[FY000001_LEN];                           
   double              dCostChrgAmt;                                            
}  _A02692_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02692_z                                                               
#define _A02692_z                                                               
                                                                                
   typedef struct __A02692                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02692_APPL_AREA A02692_appl_area[_A02692__A02692_APPL_AREA_SIZE];       
   }  _A02692;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02692_FMT
#define FYA02692_FMT     "k88r13/200s27s6s11s6s6nw4cs3lz7s3s3s27dw7.2"
#endif
