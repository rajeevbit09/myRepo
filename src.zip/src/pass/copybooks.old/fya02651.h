/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02651                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/03/95                                                */
/*              Time: 10:30:39                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02651                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef   FY003581_LEN                                                          
#define   FY003581_LEN                         27                               
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY002703_LEN                                                          
#define   FY002703_LEN                         3                                
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002778_LEN                                                          
#define   FY002778_LEN                         11                               
#endif                                                                          
#ifndef _A02651_APPL_AREA_z                                                     
#define _A02651_APPL_AREA_z                                                     
typedef struct __A02651_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltDprtDt[FY003584_LEN];                                
   char                sPassRptSortDt[FY003821_LEN];                            
   char                sFltArrDt[FY003581_LEN];                                 
   short               nFltDprtTm;                                              
   char                sFltOrigCtyId[FY002521_LEN];                             
   char                sFltDestCtyId[FY002522_LEN];                             
   char                sPassTypCd[FY002496_LEN];                                
   char                sFltClsSvcId[FY002703_LEN];                              
   char                sFltNbr[FY002553_LEN];                                   
   char                sTktNbr[FY002778_LEN];                                   
   long                lFltChrgRfrnDt;                                          
}  _A02651_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02651_z                                                               
#define _A02651_z                                                               
                                                                                
   typedef struct __A02651                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02651_APPL_AREA A02651_appl_area;                                       
   }  _A02651;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02651_FMT
#define FYA02651_FMT     "k88s10s3s27s27s27nw4s6s6s3s3s6s11lz7"
#endif
