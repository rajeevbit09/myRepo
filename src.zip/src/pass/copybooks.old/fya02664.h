/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02664                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/23/95                                                */
/*              Time: 09:35:29                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02664                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002645_LEN                                                          
#define   FY002645_LEN                         4                                
#endif                                                                          
#ifndef   FY002799_LEN                                                          
#define   FY002799_LEN                         1                                
#endif                                                                          
#ifndef   FY002641_LEN                                                          
#define   FY002641_LEN                         10                               
#endif                                                                          
#ifndef   FY002818_LEN                                                          
#define   FY002818_LEN                         1                                
#endif                                                                          
#ifndef   FY002819_LEN                                                          
#define   FY002819_LEN                         1                                
#endif                                                                          
#ifndef   FY002820_LEN                                                          
#define   FY002820_LEN                         1                                
#endif                                                                          
#ifndef _A02664_APPL_AREA_z                                                     
#define _A02664_APPL_AREA_z                                                     
typedef struct __A02664_appl_area                                               
{                                                                               
   double              dFltFeeAmt;                                              
   char                sFltFeeCurrCd[FY002645_LEN];                             
   char                cFltFeeInd;                                              
   char                sFltFeeAcctNbr[FY002641_LEN];                            
   char                cFltFeeIntraInd;                                         
   char                cFltFeeAgeInd;                                           
   char                cFltFeeMiInd;                                            
   long                lFltFeeMiMinNbr;                                         
   long                lFltFeeMiMaxNbr;                                         
   short               nFltFeeMinNbr;                                           
   short               nFltFeeMaxNbr;                                           
}  _A02664_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02664_z                                                               
#define _A02664_z                                                               
                                                                                
   typedef struct __A02664                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02664_APPL_AREA A02664_appl_area;                                       
   }  _A02664;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02664_FMT
#define FYA02664_FMT     "k88dw10.2s4cs10ccclw6lw6nw2nw2"
#endif
