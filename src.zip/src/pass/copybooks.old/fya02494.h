/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02494                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/25/95                                                */
/*              Time: 11:33:50                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02494                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY003581_LEN                                                          
#define   FY003581_LEN                         27                               
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY002631_LEN                                                          
#define   FY002631_LEN                         1                                
#endif                                                                          
#ifndef   FY002703_LEN                                                          
#define   FY002703_LEN                         3                                
#endif                                                                          
#ifndef   FY002833_LEN                                                          
#define   FY002833_LEN                         3                                
#endif                                                                          
#ifndef   FY002867_LEN                                                          
#define   FY002867_LEN                         1                                
#endif                                                                          
#ifndef   FY002897_LEN                                                          
#define   FY002897_LEN                         1                                
#endif                                                                          
#ifndef   FY003588_LEN                                                          
#define   FY003588_LEN                         27                               
#endif                                                                          
#ifndef   FY003210_LEN                                                          
#define   FY003210_LEN                         3                                
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02494_APPL_AREA_z                                                     
#define _A02494_APPL_AREA_z                                                     
typedef struct __A02494_appl_area                                               
{                                                                               
   short               nFltArrTm;                                               
   char                sFltArrDt[FY003581_LEN];                                 
   char                sFltDestCtyId[FY002522_LEN];                             
   char                sPassTypCd[FY002496_LEN];                                
   char                cFltMatchInd;                                            
   long                lPassTripNbr;                                            
   char                sFltClsSvcId[FY002703_LEN];                              
   char                sFltArptPrTypCd[FY002833_LEN];                           
   char                cFltLegSrcInd;                                           
   char                cFltRptInd;                                              
   char                sProcDt[FY003588_LEN];                                   
   char                sFltOalFlnInd[FY003210_LEN];                             
   short               nFltDprtTm;                                              
   long                lFltChrgRfrnDt;                                          
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02494_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02494_z                                                               
#define _A02494_z                                                               
                                                                                
   typedef struct __A02494                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02494_APPL_AREA A02494_appl_area;                                       
   }  _A02494;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02494_FMT
#define FYA02494_FMT     "k88nw4s27s6s3clz6s3s3ccs27s3nw4lz7s9s27"
#endif
