/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02504                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 07/24/95                                                */
/*              Time: 16:15:08                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02504                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY002645_LEN                                                          
#define   FY002645_LEN                         4                                
#endif                                                                          
#ifndef   FY002799_LEN                                                          
#define   FY002799_LEN                         1                                
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02504_APPL_AREA_z                                                     
#define _A02504_APPL_AREA_z                                                     
typedef struct __A02504_appl_area                                               
{                                                                               
   char                sFltFeeEndDt[FY003586_LEN];                              
   double              dFltFeeAmt;                                              
   char                sFltFeeCurrCd[FY002645_LEN];                             
   char                cFltFeeInd;                                              
   short               nFltFeeMaxNbr;                                           
   long                lFltFeeMiMaxNbr;                                         
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02504_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02504_z                                                               
#define _A02504_z                                                               
                                                                                
   typedef struct __A02504                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02504_APPL_AREA A02504_appl_area;                                       
   }  _A02504;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02504_FMT
#define FYA02504_FMT     "k88s27dw10.2s4cnw2lw6s9s27"
#endif
