/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02359                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/11/95                                                */
/*              Time: 15:38:02                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02359                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02359_APPL_AREA_z                                                     
#define _A02359_APPL_AREA_z                                                     
typedef struct __A02359_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
   long                lPassTripNbr;                                            
}  _A02359_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02359_z                                                               
#define _A02359_z                                                               
                                                                                
   typedef struct __A02359                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02359_APPL_AREA A02359_appl_area;                                       
   }  _A02359;                                                                  
#endif                                                                          
                                                                                


#ifndef FYA02359_FMT
#define FYA02359_FMT     "k88s27lz6"
#endif
