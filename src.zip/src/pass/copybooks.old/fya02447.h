/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02447                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 06/13/95                                                */
/*              Time: 16:04:33                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02447                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02447__A02447_APPL_AREA_SIZE                                        
#define   _A02447__A02447_APPL_AREA_SIZE       10                               
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef _A02447_APPL_AREA_z                                                     
#define _A02447_APPL_AREA_z                                                     
typedef struct __A02447_appl_area                                               
{                                                                               
   char                sPassTypCd[FY002496_LEN];                                
}  _A02447_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02447_z                                                               
#define _A02447_z                                                               
                                                                                
   typedef struct __A02447                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02447_APPL_AREA A02447_appl_area[_A02447__A02447_APPL_AREA_SIZE];       
   }  _A02447;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02447_FMT
#define FYA02447_FMT     "k88r1/10s3"
#endif
