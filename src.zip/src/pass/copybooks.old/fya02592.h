/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02592                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/07/96                                                */
/*              Time: 14:48:58                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02592                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02592__A02592_APPL_AREA_SIZE                                        
#define   _A02592__A02592_APPL_AREA_SIZE       400                              
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002715_LEN                                                          
#define   FY002715_LEN                         16                               
#endif                                                                          
#ifndef   FY002714_LEN                                                          
#define   FY002714_LEN                         15                               
#endif                                                                          
#ifndef   FY002716_LEN                                                          
#define   FY002716_LEN                         1                                
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef _A02592_APPL_AREA_z                                                     
#define _A02592_APPL_AREA_z                                                     
typedef struct __A02592_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sPprLstNm[FY002715_LEN];                                 
   char                sPprFrstNm[FY002714_LEN];                                
   char                cPprMidNm;                                               
   char                sPprNm[FY002480_LEN];                                    
}  _A02592_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02592_z                                                               
#define _A02592_z                                                               
                                                                                
   typedef struct __A02592                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02592_APPL_AREA A02592_appl_area[_A02592__A02592_APPL_AREA_SIZE];       
   }  _A02592;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02592_FMT
#define FYA02592_FMT     "k88r5/400s10s16s15cs31"
#endif
