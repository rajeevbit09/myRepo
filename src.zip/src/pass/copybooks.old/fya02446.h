/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02446                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 11/03/95                                                */
/*              Time: 12:16:01                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02446                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002535_LEN                                                          
#define   FY002535_LEN                         3                                
#endif                                                                          
#ifndef   _A02446_APPL_AREA__REMNALLOT_SIZE                                     
#define   _A02446_APPL_AREA__REMNALLOT_SIZE    5                                
#endif                                                                          
#ifndef _REMNALLOT_z                                                            
#define _REMNALLOT_z                                                            
typedef struct __RemnAllot                                                      
{                                                                               
   char                sPassTypCd[FY002496_LEN];                                
   long                lNrevRemnMiQty;                                          
   short               nNrevRemnDyQty;                                          
}  _REMNALLOT;                                                                  
#endif                                                                          
#ifndef _A02446_APPL_AREA_z                                                     
#define _A02446_APPL_AREA_z                                                     
typedef struct __A02446_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevNm[FY002531_LEN];                                   
   char                sPassStsCd[FY002535_LEN];                                
   _REMNALLOT RemnAllot[_A02446_APPL_AREA__REMNALLOT_SIZE];                     
}  _A02446_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02446_z                                                               
#define _A02446_z                                                               
                                                                                
   typedef struct __A02446                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02446_APPL_AREA A02446_appl_area;                                       
   }  _A02446;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02446_FMT
#define FYA02446_FMT     "k88s10s3s31s3r3/5s3lw7nw3"
#endif
