/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02438                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/22/95                                                */
/*              Time: 17:03:41                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02438                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02438_APPL_AREA_z                                                     
#define _A02438_APPL_AREA_z                                                     
typedef struct __A02438_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02438_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02438_z                                                               
#define _A02438_z                                                               
                                                                                
   typedef struct __A02438                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02438_APPL_AREA A02438_appl_area;                                       
   }  _A02438;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02438_FMT
#define FYA02438_FMT     "k88s27"
#endif
