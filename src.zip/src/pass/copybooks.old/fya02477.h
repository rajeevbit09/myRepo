/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02477                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 07/21/95                                                */
/*              Time: 10:24:37                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02477                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02477_APPL_AREA_z                                                     
#define _A02477_APPL_AREA_z                                                     
typedef struct __A02477_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02477_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02477_z                                                               
#define _A02477_z                                                               
                                                                                
   typedef struct __A02477                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02477_APPL_AREA A02477_appl_area;                                       
   }  _A02477;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02477_FMT
#define FYA02477_FMT     "k88s27"
#endif
