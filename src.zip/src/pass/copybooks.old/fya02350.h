/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02350                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 12/14/95                                                */
/*              Time: 11:40:30                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02350                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef _A02350_APPL_AREA_z                                                     
#define _A02350_APPL_AREA_z                                                     
typedef struct __A02350_appl_area                                               
{                                                                               
   long                lPassTripNbr;                                            
}  _A02350_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02350_z                                                               
#define _A02350_z                                                               
                                                                                
   typedef struct __A02350                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02350_APPL_AREA A02350_appl_area;                                       
   }  _A02350;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02350_FMT
#define FYA02350_FMT     "k88lz6"
#endif
