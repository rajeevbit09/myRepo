/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02481                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/23/95                                                */
/*              Time: 16:43:53                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02481                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003591_LEN                                                          
#define   FY003591_LEN                         27                               
#endif                                                                          
#ifndef   FY002868_LEN                                                          
#define   FY002868_LEN                         27                               
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002530_LEN                                                          
#define   FY002530_LEN                         51                               
#endif                                                                          
#ifndef   FY002535_LEN                                                          
#define   FY002535_LEN                         3                                
#endif                                                                          
#ifndef   FY003593_LEN                                                          
#define   FY003593_LEN                         27                               
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02481_APPL_AREA_z                                                     
#define _A02481_APPL_AREA_z                                                     
typedef struct __A02481_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPassStsChgDt[FY003591_LEN];                             
   char                sPassDtTmTs[FY002868_LEN];                               
   char                sNrevNm[FY002531_LEN];                                   
   char                sNrevCmntTxt[FY002530_LEN];                              
   char                sPassStsCd[FY002535_LEN];                                
   char                sPassSusExpDt[FY003593_LEN];                             
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02481_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02481_z                                                               
#define _A02481_z                                                               
                                                                                
   typedef struct __A02481                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02481_APPL_AREA A02481_appl_area;                                       
   }  _A02481;                                                                  
#endif                                                                          
                                                                                


#ifndef FYA02481_FMT
#define FYA02481_FMT     "k88s10s3s27s27s31s51s3s27s9s27"
#endif
