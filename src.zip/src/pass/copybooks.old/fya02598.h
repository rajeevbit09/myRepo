/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02598                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 03/15/96                                                */
/*              Time: 14:40:05                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02598                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef   FY002631_LEN                                                          
#define   FY002631_LEN                         1                                
#endif                                                                          
#ifndef   FY002838_LEN                                                          
#define   FY002838_LEN                         6                                
#endif                                                                          
#ifndef   FY002839_LEN                                                          
#define   FY002839_LEN                         6                                
#endif                                                                          
#ifndef _A02598_APPL_AREA_z                                                     
#define _A02598_APPL_AREA_z                                                     
typedef struct __A02598_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevNm[FY002531_LEN];                                   
   char                sPassGrpCd[FY002488_LEN];                                
   char                sFltDprtDt[FY003584_LEN];                                
   char                sPassRptSortDt[FY003821_LEN];                            
   long                lPassTripNbr;                                            
   char                cFltMatchInd;                                            
   char                sFltTripOrigId[FY002838_LEN];                            
   char                sFltTripDestId[FY002839_LEN];                            
}  _A02598_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02598_z                                                               
#define _A02598_z                                                               
                                                                                
   typedef struct __A02598                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02598_APPL_AREA A02598_appl_area;                                       
   }  _A02598;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02598_FMT
#define FYA02598_FMT     "k88s10s3s31s3s27s27lz6cs6s6"
#endif
