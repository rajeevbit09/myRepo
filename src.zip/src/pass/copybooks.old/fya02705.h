/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02705                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/30/95                                                */
/*              Time: 15:40:05                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02705                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02705__A02705_APPL_AREA_SIZE                                        
#define   _A02705__A02705_APPL_AREA_SIZE       50                               
#endif                                                                          
#ifndef   FY002495_LEN                                                          
#define   FY002495_LEN                         3                                
#endif                                                                          
#ifndef   FY002494_LEN                                                          
#define   FY002494_LEN                         26                               
#endif                                                                          
#ifndef   FY002492_LEN                                                          
#define   FY002492_LEN                         1                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02705_APPL_AREA_z                                                     
#define _A02705_APPL_AREA_z                                                     
typedef struct __A02705_appl_area                                               
{                                                                               
   char                sNrevTypCd[FY002495_LEN];                                
   char                sNrevTypDs[FY002494_LEN];                                
   char                cPassImptInd;                                            
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02705_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02705_z                                                               
#define _A02705_z                                                               
                                                                                
   typedef struct __A02705                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02705_APPL_AREA A02705_appl_area[_A02705__A02705_APPL_AREA_SIZE];       
   }  _A02705;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02705_FMT
#define FYA02705_FMT     "k88r4/50s3s26cs27"
#endif
