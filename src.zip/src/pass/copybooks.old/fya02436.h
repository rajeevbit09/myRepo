/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02436                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/22/95                                                */
/*              Time: 17:02:19                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02436                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002495_LEN                                                          
#define   FY002495_LEN                         3                                
#endif                                                                          
#ifndef   FY003582_LEN                                                          
#define   FY003582_LEN                         27                               
#endif                                                                          
#ifndef   FY002535_LEN                                                          
#define   FY002535_LEN                         3                                
#endif                                                                          
#ifndef   FY003593_LEN                                                          
#define   FY003593_LEN                         27                               
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002532_LEN                                                          
#define   FY002532_LEN                         16                               
#endif                                                                          
#ifndef   FY002533_LEN                                                          
#define   FY002533_LEN                         15                               
#endif                                                                          
#ifndef   FY002534_LEN                                                          
#define   FY002534_LEN                         1                                
#endif                                                                          
#ifndef   FY002831_LEN                                                          
#define   FY002831_LEN                         3                                
#endif                                                                          
#ifndef   FY002492_LEN                                                          
#define   FY002492_LEN                         1                                
#endif                                                                          
#ifndef   FY002556_LEN                                                          
#define   FY002556_LEN                         1                                
#endif                                                                          
#ifndef   FY002832_LEN                                                          
#define   FY002832_LEN                         1                                
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02436_APPL_AREA_z                                                     
#define _A02436_APPL_AREA_z                                                     
typedef struct __A02436_appl_area                                               
{                                                                               
   char                sNrevTypCd[FY002495_LEN];                                
   char                sNrevBdayDt[FY003582_LEN];                               
   char                sPassStsCd[FY002535_LEN];                                
   char                sPassSusExpDt[FY003593_LEN];                             
   char                sNrevNm[FY002531_LEN];                                   
   char                sNrevLstNm[FY002532_LEN];                                
   char                sNrevFrstNm[FY002533_LEN];                               
   char                cNrevMidNm;                                              
   char                sNrevSrcCd[FY002831_LEN];                                
   char                cPassImptInd;                                            
   char                cNrevDyMiInd;                                            
   char                cNrevDyMiNxtInd;                                         
   short               nPassCardNbr;                                            
   char                cNrevPassChgInd;                                            
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02436_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02436_z                                                               
#define _A02436_z                                                               
                                                                                
   typedef struct __A02436                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02436_APPL_AREA A02436_appl_area;                                       
   }  _A02436;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02436_FMT
#define FYA02436_FMT     "k88s3s27s3s27s31s16s15cs3cccnz2cs9s27"
#endif
