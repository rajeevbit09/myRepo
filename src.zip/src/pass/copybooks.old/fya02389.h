/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02389                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/23/95                                                */
/*              Time: 17:24:00                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02389                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02389_APPL_AREA_z                                                     
#define _A02389_APPL_AREA_z                                                     
typedef struct __A02389_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02389_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02389_z                                                               
#define _A02389_z                                                               
                                                                                
   typedef struct __A02389                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02389_APPL_AREA A02389_appl_area;                                       
   }  _A02389;                                                                  
#endif                                                                          
                                                                                


#ifndef FYA02389_FMT
#define FYA02389_FMT     "k88s27"
#endif
