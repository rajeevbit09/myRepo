/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02710                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 01/03/96                                                */
/*              Time: 18:20:06                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02710                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02710__A02710_APPL_AREA_SIZE                                        
#define   _A02710__A02710_APPL_AREA_SIZE       50                               
#endif                                                                          
#ifndef   FY002833_LEN                                                          
#define   FY002833_LEN                         3                                
#endif                                                                          
#ifndef   FY002834_LEN                                                          
#define   FY002834_LEN                         26                               
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02710_APPL_AREA_z                                                     
#define _A02710_APPL_AREA_z                                                     
typedef struct __A02710_appl_area                                               
{                                                                               
   char                sFltArptPrTypCd[FY002833_LEN];                           
   char                sFltArptPrTypDs[FY002834_LEN];                           
   char                sPassTypCd[FY002496_LEN];                                
   double              dCpYieldAmt;                                             
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02710_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02710_z                                                               
#define _A02710_z                                                               
                                                                                
   typedef struct __A02710                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02710_APPL_AREA A02710_appl_area[_A02710__A02710_APPL_AREA_SIZE];       
   }  _A02710;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02710_FMT
#define FYA02710_FMT     "k88r5/50s3s26s3dw4.5s27"
#endif
