/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02557                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 06/23/95                                                */
/*              Time: 13:22:24                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02557                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02557_APPL_AREA_z                                                     
#define _A02557_APPL_AREA_z                                                     
typedef struct __A02557_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02557_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02557_z                                                               
#define _A02557_z                                                               
                                                                                
   typedef struct __A02557                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02557_APPL_AREA A02557_appl_area;                                       
   }  _A02557;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02557_FMT
#define FYA02557_FMT     "k88s27"
#endif
