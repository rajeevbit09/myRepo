/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02679                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/16/95                                                */
/*              Time: 10:34:22                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02679                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY003390_LEN                                                          
#define   FY003390_LEN                         1                                
#endif                                                                          
#ifndef _A02679_APPL_AREA_z                                                     
#define _A02679_APPL_AREA_z                                                     
typedef struct __A02679_appl_area                                               
{                                                                               
   char                cPassRemnInd;                                            
}  _A02679_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02679_z                                                               
#define _A02679_z                                                               
                                                                                
   typedef struct __A02679                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02679_APPL_AREA A02679_appl_area;                                       
   }  _A02679;                                                                  
#endif                                                                          
                                                                                



#ifndef FYA02679_FMT
#define FYA02679_FMT     "k88c"
#endif
