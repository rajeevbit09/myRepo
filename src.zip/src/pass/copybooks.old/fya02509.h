/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02509                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/25/95                                                */
/*              Time: 11:39:49                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02509                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY003581_LEN                                                          
#define   FY003581_LEN                         27                               
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY002703_LEN                                                          
#define   FY002703_LEN                         3                                
#endif                                                                          
#ifndef   FY003588_LEN                                                          
#define   FY003588_LEN                         27                               
#endif                                                                          
#ifndef   FY002833_LEN                                                          
#define   FY002833_LEN                         3                                
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02509_APPL_AREA_z                                                     
#define _A02509_APPL_AREA_z                                                     
typedef struct __A02509_appl_area                                               
{                                                                               
   short               nFltDprtTm;                                              
   char                sFltArrDt[FY003581_LEN];                                 
   short               nFltArrTm;                                               
   char                sFltDestCtyId[FY002522_LEN];                             
   char                sPassTypCd[FY002496_LEN];                                
   char                sFltClsSvcId[FY002703_LEN];                              
   char                sProcDt[FY003588_LEN];                                   
   char                sFltArptPrTypCd[FY002833_LEN];                           
   long                lFltChrgRfrnDt;                                          
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02509_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02509_z                                                               
#define _A02509_z                                                               
                                                                                
   typedef struct __A02509                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02509_APPL_AREA A02509_appl_area;                                       
   }  _A02509;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02509_FMT
#define FYA02509_FMT     "k88nw4s27nw4s6s3s3s27s3lz7s9s27"
#endif
