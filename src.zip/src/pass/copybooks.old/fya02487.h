/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02487                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 09/18/95                                                */
/*              Time: 16:30:46                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02487                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02487__A02487_APPL_AREA_SIZE                                        
#define   _A02487__A02487_APPL_AREA_SIZE       50                               
#endif                                                                          
#ifndef   FY003591_LEN                                                          
#define   FY003591_LEN                         27                               
#endif                                                                          
#ifndef   FY002530_LEN                                                          
#define   FY002530_LEN                         51                               
#endif                                                                          
#ifndef   FY002535_LEN                                                          
#define   FY002535_LEN                         3                                
#endif                                                                          
#ifndef   FY003593_LEN                                                          
#define   FY003593_LEN                         27                               
#endif                                                                          
#ifndef   FY002868_LEN                                                          
#define   FY002868_LEN                         27                               
#endif                                                                          
#ifndef _A02487_APPL_AREA_z                                                     
#define _A02487_APPL_AREA_z                                                     
typedef struct __A02487_appl_area                                               
{                                                                               
   char                sPassStsChgDt[FY003591_LEN];                             
   char                sNrevCmntTxt[FY002530_LEN];                              
   char                sPassStsCd[FY002535_LEN];                                
   char                sPassSusExpDt[FY003593_LEN];                             
   char                sPassDtTmTs[FY002868_LEN];                               
}  _A02487_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02487_z                                                               
#define _A02487_z                                                               
                                                                                
   typedef struct __A02487                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02487_APPL_AREA A02487_appl_area[_A02487__A02487_APPL_AREA_SIZE];       
   }  _A02487;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02487_FMT
#define FYA02487_FMT     "k88r5/50s27s51s3s27s27"
#endif
