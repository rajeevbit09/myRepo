/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02364                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/04/95                                                */
/*              Time: 17:01:03                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02364                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02364__A02364_APPL_AREA_SIZE                                        
#define   _A02364__A02364_APPL_AREA_SIZE       30                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002495_LEN                                                          
#define   FY002495_LEN                         3                                
#endif                                                                          
#ifndef   FY003582_LEN                                                          
#define   FY003582_LEN                         27                               
#endif                                                                          
#ifndef   FY002535_LEN                                                          
#define   FY002535_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002532_LEN                                                          
#define   FY002532_LEN                         16                               
#endif                                                                          
#ifndef   FY002533_LEN                                                          
#define   FY002533_LEN                         15                               
#endif                                                                          
#ifndef   FY002534_LEN                                                          
#define   FY002534_LEN                         1                                
#endif                                                                          
#ifndef   FY002831_LEN                                                          
#define   FY002831_LEN                         3                                
#endif                                                                          
#ifndef   FY002556_LEN                                                          
#define   FY002556_LEN                         1                                
#endif                                                                          
#ifndef   FY002832_LEN                                                          
#define   FY002832_LEN                         1                                
#endif                                                                          
#ifndef _A02364_APPL_AREA_z                                                     
#define _A02364_APPL_AREA_z                                                     
typedef struct __A02364_appl_area                                               
{                                                                               
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevTypCd[FY002495_LEN];                                
   char                sNrevBdayDt[FY003582_LEN];                               
   char                sPassStsCd[FY002535_LEN];                                
   char                sNrevNm[FY002531_LEN];                                   
   char                sNrevLstNm[FY002532_LEN];                                
   char                sNrevFrstNm[FY002533_LEN];                               
   char                cNrevMidNm;                                              
   char                sNrevSrcCd[FY002831_LEN];                                
   char                cNrevDyMiInd;                                            
   char                cNrevDyMiNxtInd;                                         
}  _A02364_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02364_z                                                               
#define _A02364_z                                                               
                                                                                
   typedef struct __A02364                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02364_APPL_AREA A02364_appl_area[_A02364__A02364_APPL_AREA_SIZE];       
   }  _A02364;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02364_FMT
#define FYA02364_FMT     "k88r11/30s3s3s27s3s31s16s15cs3cc"
#endif
