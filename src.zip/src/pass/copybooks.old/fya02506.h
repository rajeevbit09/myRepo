/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02506                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 07/24/95                                                */
/*              Time: 16:17:02                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02506                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02506_APPL_AREA_z                                                     
#define _A02506_APPL_AREA_z                                                     
typedef struct __A02506_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02506_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02506_z                                                               
#define _A02506_z                                                               
                                                                                
   typedef struct __A02506                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02506_APPL_AREA A02506_appl_area;                                       
   }  _A02506;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02506_FMT
#define FYA02506_FMT     "k88s27"
#endif
