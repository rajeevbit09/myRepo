/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02584                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 03/17/96                                                */
/*              Time: 22:07:57                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02584                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02584__A02584_APPL_AREA_SIZE                                        
#define   _A02584__A02584_APPL_AREA_SIZE       100                              
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002635_LEN                                                          
#define   FY002635_LEN                         3                                
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY003588_LEN                                                          
#define   FY003588_LEN                         27                               
#endif                                                                          
#ifndef   FY002641_LEN                                                          
#define   FY002641_LEN                         10                               
#endif                                                                          
#ifndef   FY002636_LEN                                                          
#define   FY002636_LEN                         16                               
#endif                                                                          
#ifndef _A02584_APPL_AREA_z                                                     
#define _A02584_APPL_AREA_z                                                     
typedef struct __A02584_appl_area                                               
{                                                                               
   long                lFltChrgRfrnDt;                                          
   char                sFltDprtDt[FY003584_LEN];                                
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevNm[FY002531_LEN];                                   
   char                sSvcChrgCd[FY002635_LEN];                                
   double              dCostChrgAmt;                                            
   char                sFltNbr[FY002553_LEN];                                   
   char                sFltOrigCtyId[FY002521_LEN];                             
   char                sFltDestCtyId[FY002522_LEN];                             
   char                sProcDt[FY003588_LEN];                                   
   char                sFltFeeAcctNbr[FY002641_LEN];                            
   char                sSvcChrgDs[FY002636_LEN];                                
}  _A02584_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02584_z                                                               
#define _A02584_z                                                               
                                                                                
   typedef struct __A02584                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02584_APPL_AREA A02584_appl_area[_A02584__A02584_APPL_AREA_SIZE];       
   }  _A02584;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02584_FMT
#define FYA02584_FMT     "k88r12/100lz7s27s3s31s3dw7.2s6s6s6s27s10s16"
#endif
