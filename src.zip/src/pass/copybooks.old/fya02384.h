/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02384                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/20/98                                                */
/*              Time: 15:47:57                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02384                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02384_APPL_AREA_z                                                     
#define _A02384_APPL_AREA_z                                                     
typedef struct __A02384_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02384_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02384_z                                                               
#define _A02384_z                                                               
                                                                                
   typedef struct __A02384                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02384_APPL_AREA A02384_appl_area;                                       
   }  _A02384;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02384_FMT
#define FYA02384_FMT     "k88s27"
#endif
