/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02489                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/16/95                                                */
/*              Time: 10:41:03                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02489                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002641_LEN                                                          
#define   FY002641_LEN                         10                               
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02489_APPL_AREA_z                                                     
#define _A02489_APPL_AREA_z                                                     
typedef struct __A02489_appl_area                                               
{                                                                               
   char                sFltFeeAcctNbr[FY002641_LEN];                            
   double              dCostChrgAmt;                                            
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02489_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02489_z                                                               
#define _A02489_z                                                               
                                                                                
   typedef struct __A02489                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02489_APPL_AREA A02489_appl_area;                                       
   }  _A02489;                                                                  
#endif                                                                          
                                                                                


#ifndef FYA02489_FMT
#define FYA02489_FMT     "k88s10dw7.2s9s27"
#endif
