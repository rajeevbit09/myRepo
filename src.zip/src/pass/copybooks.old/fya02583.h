/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02583                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/27/95                                                */
/*              Time: 15:26:02                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02583                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02583__A02583_APPL_AREA_SIZE                                        
#define   _A02583__A02583_APPL_AREA_SIZE       30                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002495_LEN                                                          
#define   FY002495_LEN                         3                                
#endif                                                                          
#ifndef _A02583_APPL_AREA_z                                                     
#define _A02583_APPL_AREA_z                                                     
typedef struct __A02583_appl_area                                               
{                                                                               
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevNm[FY002531_LEN];                                   
   char                sNrevTypCd[FY002495_LEN];                                
}  _A02583_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02583_z                                                               
#define _A02583_z                                                               
                                                                                
   typedef struct __A02583                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02583_APPL_AREA A02583_appl_area[_A02583__A02583_APPL_AREA_SIZE];       
   }  _A02583;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02583_FMT
#define FYA02583_FMT     "k88r3/30s3s31s3"
#endif
