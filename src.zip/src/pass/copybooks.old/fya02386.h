/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02386                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 06/08/95                                                */
/*              Time: 11:20:32                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02386                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003583_LEN                                                          
#define   FY003583_LEN                         27                               
#endif                                                                          
#ifndef   FY002798_LEN                                                          
#define   FY002798_LEN                         1                                
#endif                                                                          
#ifndef   FY002843_LEN                                                          
#define   FY002843_LEN                         1                                
#endif                                                                          
#ifndef   FY002635_LEN                                                          
#define   FY002635_LEN                         3                                
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02386_APPL_AREA_z                                                     
#define _A02386_APPL_AREA_z                                                     
typedef struct __A02386_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sCardIssDt[FY003583_LEN];                                
   char                cCardStsInd;                                             
   char                cCardProcInd;                                            
   char                sSvcChrgCd[FY002635_LEN];                                
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02386_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02386_z                                                               
#define _A02386_z                                                               
                                                                                
   typedef struct __A02386                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02386_APPL_AREA A02386_appl_area;                                       
   }  _A02386;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02386_FMT
#define FYA02386_FMT     "k88s10s3s27ccs3s9s27"
#endif
