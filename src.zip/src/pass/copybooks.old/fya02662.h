/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02662                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 12/06/95                                                */
/*              Time: 10:25:19                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02662                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002641_LEN                                                          
#define   FY002641_LEN                         10                               
#endif                                                                          
#ifndef _A02662_APPL_AREA_z                                                     
#define _A02662_APPL_AREA_z                                                     
typedef struct __A02662_appl_area                                               
{                                                                               
   double              dCostChrgAmt;                                            
   char                sFltFeeAcctNbr[FY002641_LEN];                            
}  _A02662_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02662_z                                                               
#define _A02662_z                                                               
                                                                                
   typedef struct __A02662                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02662_APPL_AREA A02662_appl_area;                                       
   }  _A02662;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02662_FMT
#define FYA02662_FMT     "k88dw7.2s10"
#endif
