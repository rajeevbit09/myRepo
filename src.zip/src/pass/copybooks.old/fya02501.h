/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02501                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/11/95                                                */
/*              Time: 15:48:35                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02501                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02501_APPL_AREA_z                                                     
#define _A02501_APPL_AREA_z                                                     
typedef struct __A02501_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02501_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02501_z                                                               
#define _A02501_z                                                               
                                                                                
   typedef struct __A02501                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02501_APPL_AREA A02501_appl_area;                                       
   }  _A02501;                                                                  
#endif                                                                          
                                                                                


#ifndef FYA02501_FMT
#define FYA02501_FMT     "k88s27"
#endif
