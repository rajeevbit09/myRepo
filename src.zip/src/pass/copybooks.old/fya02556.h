/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02556                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 06/23/95                                                */
/*              Time: 13:21:30                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02556                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02556_APPL_AREA_z                                                     
#define _A02556_APPL_AREA_z                                                     
typedef struct __A02556_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02556_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02556_z                                                               
#define _A02556_z                                                               
                                                                                
   typedef struct __A02556                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02556_APPL_AREA A02556_appl_area;                                       
   }  _A02556;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02556_FMT
#define FYA02556_FMT     "k88s27"
#endif
