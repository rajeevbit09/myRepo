/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02484                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/23/95                                                */
/*              Time: 16:44:23                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02484                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02484_APPL_AREA_z                                                     
#define _A02484_APPL_AREA_z                                                     
typedef struct __A02484_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02484_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02484_z                                                               
#define _A02484_z                                                               
                                                                                
   typedef struct __A02484                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02484_APPL_AREA A02484_appl_area;                                       
   }  _A02484;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02484_FMT
#define FYA02484_FMT     "k88s27"
#endif
