/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02645                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/30/95                                                */
/*              Time: 15:47:48                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02645                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY002864_LEN                                                          
#define   FY002864_LEN                         1                                
#endif                                                                          
#ifndef _A02645_APPL_AREA_z                                                     
#define _A02645_APPL_AREA_z                                                     
typedef struct __A02645_appl_area                                               
{                                                                               
   char                sPassTypCd[FY002496_LEN];                                
   short               nFltAllotDyNbr;                                          
   long                lFltAllotMiQty;                                          
   char                cPassAddlInd;                                            
}  _A02645_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02645_z                                                               
#define _A02645_z                                                               
                                                                                
   typedef struct __A02645                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02645_APPL_AREA A02645_appl_area;                                       
   }  _A02645;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02645_FMT
#define FYA02645_FMT     "k88s3nz3lw7c"
#endif
