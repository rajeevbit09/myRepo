/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02478                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 07/21/95                                                */
/*              Time: 10:25:15                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02478                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02478_APPL_AREA_z                                                     
#define _A02478_APPL_AREA_z                                                     
typedef struct __A02478_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02478_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02478_z                                                               
#define _A02478_z                                                               
                                                                                
   typedef struct __A02478                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02478_APPL_AREA A02478_appl_area;                                       
   }  _A02478;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02478_FMT
#define FYA02478_FMT     "k88s27"
#endif
