/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02531                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 07/26/95                                                */
/*              Time: 14:02:16                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02531                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02531_APPL_AREA_z                                                     
#define _A02531_APPL_AREA_z                                                     
typedef struct __A02531_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02531_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02531_z                                                               
#define _A02531_z                                                               
                                                                                
   typedef struct __A02531                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02531_APPL_AREA A02531_appl_area;                                       
   }  _A02531;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02531_FMT
#define FYA02531_FMT     "k88s27"
#endif
