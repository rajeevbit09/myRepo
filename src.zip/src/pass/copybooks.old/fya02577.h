/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02577                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 01/09/96                                                */
/*              Time: 11:37:17                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02577                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef _A02577_APPL_AREA_z                                                     
#define _A02577_APPL_AREA_z                                                     
typedef struct __A02577_appl_area                                               
{                                                                               
   double              dCostChrgAmt;                                            
}  _A02577_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02577_z                                                               
#define _A02577_z                                                               
                                                                                
   typedef struct __A02577                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02577_APPL_AREA A02577_appl_area;                                       
   }  _A02577;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02577_FMT
#define FYA02577_FMT     "k88dw7.2"
#endif
