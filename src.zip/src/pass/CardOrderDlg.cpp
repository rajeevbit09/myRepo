// CardOrderDlg.cpp :	implementation file
//
// Description:			Also, Pass Cards are ordered and processed from this window.
//
// Author:				Joseph Fletcher - DT, Inc.
//
// Date:				6/30/1999

#include "stdafx.h"
#include "pass.h"
#include "CardOrderDlg.h"
#include "fyr04188.h"
#include "fya04188.h"
#include "fya02786.h"
#include "fyr02786.h"
#include "fya02788.h"
#include "fyr02788.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCardOrderDlg dialog

CCardOrderDlg::CCardOrderDlg(CWnd* pParent /*=NULL*/)
	: CFYDialog(CCardOrderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCardOrderDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CCardOrderDlg::DoDataExchange(CDataExchange* pDX)
{
	CFYDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCardOrderDlg)
	DDX_Control(pDX, IDC_PROGRESS, m_ProgressText);
	DDX_Control(pDX, IDC_PROGRESS_BAR, m_ProgressBar);
	DDX_Control(pDX, IDC_CARDS_TO_ORDER, m_edtCardsToOrder);
	DDX_Control(pDX, IDC_NOTIFY, m_chkNotify);
	DDX_Control(pDX, IDC_CARDS_THRESHOLD, m_edtCardsThreshold);
	DDX_Control(pDX, IDC_CREATE_CARD_ORDER_FILE, m_btnCreate);
	DDX_Control(pDX, IDC_PROCESS_ORDERED_CARDS, m_btnProcess);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCardOrderDlg, CFYDialog)
	//{{AFX_MSG_MAP(CCardOrderDlg)
	ON_BN_CLICKED(IDC_PROCESS_ORDERED_CARDS, OnProcessOrderedCards)
	ON_BN_CLICKED(IDC_CREATE_CARD_ORDER_FILE, OnCreateCardOrderFile)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_SETWINDOWSTATE, OnSetWindowState)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCardOrderDlg message handlers

LRESULT CCardOrderDlg::OnSetWindowState(WPARAM wParam, LPARAM lParam)
{
	// First call the default handler
	CFYDialog::OnSetWindowState(wParam, lParam);
	
	// set card order threshold field to read only if notify checkbox not checked
	m_edtCardsThreshold.SetReadOnly(!m_chkNotify.GetCheck());
	
	// Enable/Disable the pass card buttons based on existance of file and cards to be ordered
	m_btnCreate.EnableWindow((!FileExists(m_strCardFile)) && (m_edtCardsToOrder.GetNumber() > 0));
	m_btnProcess.EnableWindow(FileExists(m_strCardFile));
	
	UpdateSecuredObjects();

	return 0;
}

BOOL CCardOrderDlg::OnInitDialog()
{
	CFYDialog::OnInitDialog();
	
	// set number of cards to order
	SetPassCardsToOrder();

	// set checkbox for notification of when to order
	m_chkNotify.SetCheck(GetPrivateProfileInt("PASS", "NotifyCardOrder", 0, INI_FILE_NAME));

	// set limit and number of cards for when to notify
	m_edtCardsThreshold.LimitText(5); // set to 5 because 10000 is card limit in FYS02786
	CString strNumber;
	strNumber.Format("%ld", GetPrivateProfileInt("PASS", "OrderThreshold", 1000 /* default value */, INI_FILE_NAME));
	m_edtCardsThreshold.SetText(strNumber);
	
	// hide progress info until creating or processing cards
	m_ProgressText.ShowWindow(FALSE);
	m_ProgressBar.ShowWindow(FALSE);
	m_ProgressBar.SetRange(0, (int)m_edtCardsToOrder.GetNumber());
	
	// set card file to be created
	SetCardFile();
	
	// set up security
	AddSecuredObject(&m_btnCreate, SEC_PASSCARD_ORDER);
	AddSecuredObject(&m_btnProcess, SEC_PASSCARD_PROCESS);

	// Enable/Disable push buttons
	OnSetWindowState(NULL, NULL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
}

void CCardOrderDlg::OnCreateCardOrderFile()
{
	// prompt user to confirm order
	if ( AfxMessageBox(MSG_PASS_CARD_ORDER_NEW, MB_YESNO | MB_ICONQUESTION) == IDNO )
		return; // don't order if not confirmed
	
	// try to create card order file
	WriteCardFile();

	// Enable/Disable push buttons
	OnSetWindowState(NULL, NULL);
}

void CCardOrderDlg::OnProcessOrderedCards()
{
	// prompt user to confirm process card order
	if ( AfxMessageBox(MSG_PASS_CARD_PROCESS, MB_YESNO | MB_ICONQUESTION) == IDNO )
		return; // don't process card order if not confirmed
		
	// try to process card order file
	ProcessCardFile();

	// Enable/Disable push buttons
	OnSetWindowState(NULL, NULL);
}

void CCardOrderDlg::OnOK() 
{
	PerformSave();
	
	CFYDialog::OnOK();
}

BOOL CCardOrderDlg::OnCloseAndSave()
{
	return PerformSave();
}

/////////////////////////////////////////////////////////////////////////////
// CCardOrderDlg private functions

void CCardOrderDlg::SetPassCardsToOrder()
{
	CWaitCursor Wait;
	TRY
	{
		MESSAGE(PassCard, 4188);
		
		// Invoke the service and switch on the return value
		switch(PassCard.InvokeService())
		{
			case DAA_SUCCESS:
			case DAA_ROW_NOT_FOUND:    
				break;
				
			default:
				strcpy (PassCard.m_pMsgParms->ErrorInfo.szErrorText,
						"Service 4188 failed.  Could not retrieve number of pass cards to be ordered.");
				PassCard.ThrowException();
		}
		
		CString strNumber;
		strNumber.Format("%ld", PassCard.m_pAnswer->A04188_appl_area.lPassTyp1Qty);
		m_edtCardsToOrder.SetText(strNumber);
	} // end TRY
	
	CATCH(CFYException, e)
	{
		e->Display();
	}
	END_CATCH
	
	return;
}

void CCardOrderDlg::SetCardFile()
{	
	// Creates the file for use with Kirk Plastic
	CString strPath;
	TCHAR szFullPath[_MAX_PATH];
	GetCurrentDirectory(_MAX_PATH, szFullPath);
	CString strFileName;

	// Create the data directory, to ensure that it exists.
	strPath.Format("%s\\%s", szFullPath, "data");
	CreateDirectory(strPath, NULL);

	// The file will be written out to the current directory.
	m_strCardFile.Format("%s\\%s\\%s", szFullPath, "data", OUTPUT_FILE);
	m_strArchFile.Format("%s\\%s\\%s", szFullPath, "data", KIRKPLASTIC_ARCHIVE);
}

#define REQ_2786 CardOrder.m_pRequest->R02786_appl_area
#define ANS_2786 CardOrder.m_pAnswer->A02786_appl_area

void CCardOrderDlg::WriteCardFile()
{
	CWaitCursor Wait;
	FILE *fh;
	CString strMsg;
	BOOL bContinue = TRUE;
	long lBlockNum = 1;
	int nBlocksLeft, nRow = 0, nTotalRows = 0;
	char szBirthDate[9], szStartDate[9], szIssueDate[9], szBuffer[400];

	// try to open card file for write
	if((fh = fopen(m_strCardFile, "w")) == NULL)
	{
		AfxFormatString1(strMsg, MSG_PASS_CARD_FILE_NOT_CREATED, m_strCardFile);
		AfxMessageBox(strMsg);
		return;
	}

	// show progress info
	m_ProgressText.ShowWindow(TRUE);
	m_ProgressBar.ShowWindow(TRUE);
	
	// write header to file
	memset(szBuffer, NULL, sizeof(szBuffer));
	FormatCardFileHeaderString(szBuffer);
	fprintf(fh, szBuffer);
		
	TRY // to write body to file
	{
		MESSAGE(CardOrder, 2786);
		
		CardOrder.m_pMsgParms->lRowCount = _A02786__A02786_APPL_AREA_SIZE;
		REQ_2786.cPprFlagInd = '1';
		
		// calculate number of blocks service will call to get all cards
		int nCardsToOrder = (int)m_edtCardsToOrder.GetNumber();
		nBlocksLeft = nCardsToOrder / _A02786__A02786_APPL_AREA_SIZE;
		if ( (nCardsToOrder % _A02786__A02786_APPL_AREA_SIZE) > 0 )
			nBlocksLeft++;
		
		while(bContinue) // while we think there is more data to get...
		{
			// calculate time remaining for completion of creating card file
			int nSvcTime = GetPrivateProfileInt("Performance Data", "2786", 30 /* default 30 secs */, "fyperf.ini");
			int nTimeLeft = nBlocksLeft * nSvcTime;
			CString strTimeUnit = "Seconds Remaining...";
			if (nTimeLeft > 59)
			{
				nTimeLeft = nTimeLeft / 60;
				strTimeUnit = "Minutes Remaining...";
				if (nTimeLeft == 1)
					strTimeUnit = "Minute Remaining...";
			}
			CString strTimeLeft;
			strTimeLeft.Format("%d ", nTimeLeft);
			strTimeLeft = strTimeLeft + strTimeUnit;
			
			// update progress info
			m_ProgressText.SetWindowText(strTimeLeft);
			m_ProgressBar.OffsetPos(nRow);
			Invalidate();
			UpdateWindow();

			bContinue = FALSE; // always assume there is no more data
			CardOrder.m_pMsgParms->lListBlockNumber = lBlockNum;
			
			// invoke the service and switch on the return value
			switch(CardOrder.InvokeService())
			{
				case DAA_SUCCESS:
					lBlockNum++;
					bContinue = TRUE;
					
				case DAA_END_OF_LIST:
					break;

				case DAA_ROW_NOT_FOUND:
					fclose(fh);
					DeleteFile(m_strCardFile);
					AfxMessageBox(MSG_PASS_CARD_ORDER_NOT_FOUND);
					return;
					break;
					
				default:
					strcpy(CardOrder.m_pMsgParms->ErrorInfo.szErrorText,
						   "Service 2786 failed.  Could not order cards.");
					CardOrder.ThrowException();
			}
			
			// loop through answer rows of data
			for(nRow = 0; nRow < ANS_2786[0].nPassAnsRowsNbr; nRow++)
			{
				// reformats dates to MMDDCCYY
				FormatCardFileDate(ANS_2786[nRow].sNrevBdayDt, szBirthDate);
				FormatCardFileDate(ANS_2786[nRow].sPprStrtDt, szStartDate);
				FormatCardFileDate(ANS_2786[nRow].sCardIssDt, szIssueDate);				
				
				PadSpace( ANS_2786[nRow].sPprNbr, sizeof (ANS_2786[nRow].sPprNbr) -1);
				PadSpace( ANS_2786[nRow].sNrevNbr, sizeof (ANS_2786[nRow].sNrevNbr) -1);
				PadSpace( ANS_2786[nRow].sNrevNm, sizeof (ANS_2786[nRow].sNrevNm) -1);
				PadSpace( szBirthDate, sizeof (szBirthDate) -1);
				PadSpace( szIssueDate, sizeof (szIssueDate) -1);
				PadSpace( ANS_2786[nRow].sPprNbr, sizeof (ANS_2786[nRow].sPprNbr) -1);
				PadSpace( ANS_2786[nRow].sPpr1Addr, sizeof (ANS_2786[nRow].sPpr1Addr) -1);
				PadSpace( ANS_2786[nRow].sPpr2Addr, sizeof (ANS_2786[nRow].sPpr2Addr) -1);
				PadSpace( ANS_2786[nRow].sPprCtyAddr, sizeof (ANS_2786[nRow].sPprCtyAddr) -1);
				PadSpace( ANS_2786[nRow].sPprStCd, sizeof (ANS_2786[nRow].sPprStCd) -1);
				PadSpace( ANS_2786[nRow].sPprZipAddr, sizeof (ANS_2786[nRow].sPprZipAddr) -1);
				PadSpace( ANS_2786[nRow].sPprCtryCd, sizeof (ANS_2786[nRow].sPprCtryCd) -1);
				PadSpace( ANS_2786[nRow].sPprNm, sizeof (ANS_2786[nRow].sPprNm) -1);
				
				// format card file record string
				memset(szBuffer, NULL, sizeof(szBuffer));
				wsprintf(szBuffer, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
					ANS_2786[nRow].sPprNbr, ANS_2786[nRow].sNrevNbr, ANS_2786[nRow].sNrevNm,
					szBirthDate, szStartDate, szIssueDate, ANS_2786[nRow].sPpr1Addr,
					ANS_2786[nRow].sPpr2Addr, ANS_2786[nRow].sPprCtyAddr, ANS_2786[nRow].sPprStCd,
					ANS_2786[nRow].sPprZipAddr, ANS_2786[nRow].sPprCtryCd, ANS_2786[nRow].sPprNm);
				
				// write record to file, resetting card indicators on failure
				if ( fprintf(fh, szBuffer) < 0 )
				{
					ResetCards();
					AfxFormatString1(strMsg, MSG_PASS_CARD_FILE_NOT_CREATED, m_strCardFile);
					AfxMessageBox(strMsg);
					return;
				}
			}
			
			// decrement number of blocks left to call
			nBlocksLeft--;
			
			// increase value of all rows for all blocks
			nTotalRows += nRow;
			
		} // end while
	
	} // end TRY 
	
	// write footer to file
	memset(szBuffer, NULL, sizeof(szBuffer));
	FormatCardFileFooterString(nTotalRows, szBuffer);
	fprintf(fh, szBuffer);
	fclose(fh);
	
	// refresh number of cards to be ordered
	SetPassCardsToOrder();
	
	// hide progress info
	m_ProgressText.ShowWindow(FALSE);
	m_ProgressBar.ShowWindow(FALSE);
	
	// inform user where file was created
	CString strMsg;
	AfxFormatString1(strMsg, MSG_PASS_CARD_FILE_CREATED, m_strCardFile);
	AfxMessageBox(strMsg, MB_ICONINFORMATION);
	
	CATCH(CFYException, e)
	{
		e->Display();
		fclose(fh);
		DeleteFile(m_strCardFile);
	}
	END_CATCH;

	return;
}

void CCardOrderDlg::FormatCardFileHeaderString(char * szString)
{
	COleDateTime odtTempDate;
	odtTempDate = COleDateTime::GetCurrentTime();

	// 000000 indicates header to KirkPlastic
	// DALPASS indicates Delta Pass Card file to KirkPlastic
	// Note the header date appears in the format CCYYMMDD
	wsprintf(szString, "%s\t%s\t%s\n", "000000", "DALPASS",	odtTempDate.Format("%Y%m%d"));
}

void CCardOrderDlg::FormatCardFileDate(char * szDatabaseDate, char * szExportDate)
{
	// this function reformats the database date to MMDDCCYY
	CString strDate;
	
	// get date into MM/DD/CCYY format
	if ((CString)szDatabaseDate == CONST_BLANK_DATE)
	{
		strDate = CONST_SYBASE_BLANK_DATE_2;
	}
	else
	{
		CFYDateEdit dtTemp;
		dtTemp.SetDate(szDatabaseDate);
		strDate = dtTemp.GetSlashedDate();
	}
	
	// while slash found, remove it from the date
	while (strDate.Find('/') > -1)
	{
		// starting at the slash character, replace each character in the string with the chararcter
		// that follows it, except for the last character to avoid accessing memory outside the string
		int i, nIndex = strDate.Find('/');
		for ( i = nIndex; i < strDate.GetLength() - 1; i++ )
			strDate.SetAt( i, strDate.GetAt( i + 1 ) );
			
		// this will truncate the string by cutting of the last "duplicated" character
		strDate = strDate.Left(i);
	}
	
	strcpy(szExportDate, strDate); // should be in MMDDCCYY format now
}

void CCardOrderDlg::FormatCardFileFooterString( int nRecords, char *szString )
{
	// 999999 indicates footer to KirkPlastic
	wsprintf(szString,"%s\t%06d\n",	"999999", nRecords);
}

void CCardOrderDlg::ProcessCardFile()
{
	CWaitCursor Wait;
	long lBlockNum = 1;
	
	// update pass card table - set rows to Processed, charging psgrs for cards where appropriate
	TRY
	{
		MESSAGE(ProcessCards, 2786);
		
		ProcessCards.SetSvcTimeout(180);		
		ProcessCards.m_pMsgParms->lListBlockNumber = lBlockNum;
		ProcessCards.m_pMsgParms->lRowCount = 1;
		ProcessCards.m_pRequest->R02786_appl_area.cPprFlagInd = '2';		
		
		// invoke the service and switch on the return value
		switch(ProcessCards.InvokeService())
		{
			case DAA_SUCCESS:
				break;
				
			default:
				strcpy (ProcessCards.m_pMsgParms->ErrorInfo.szErrorText,
						"Service 2786 failed.  Could not process cards.");
				ProcessCards.ThrowException();
		}
		
		// inform process successful and delete file
		AfxMessageBox(MSG_PASS_CARD_PROCESS_COMPLETE, MB_ICONINFORMATION);
		DeleteFile(m_strCardFile);
		
	} // end TRY
	
	CATCH(CFYException, e)
	{
		e->Display();
	}
	END_CATCH;
	
	return;
}

BOOL CCardOrderDlg::PerformSave()
{
	// save notification values to .ini file
	CString strNotify;
	strNotify.Format("%d", m_chkNotify.GetCheck());
	WritePrivateProfileString("PASS", "NotifyCardOrder", strNotify, INI_FILE_NAME);
	WritePrivateProfileString("PASS", "OrderThreshold", m_edtCardsThreshold.GetText(), INI_FILE_NAME);
	
	return TRUE;
}

#define REQ_2788 ResetCards.m_pRequest->R02788_appl_area
#define ANS_2788 ResetCards.m_pAnswer->A02788_appl_area

void CCardOrderDlg::ResetCards()
{                                                 
	CWaitCursor Wait;
	
	// rename the pass card file to a .sav file for reference
	CFile::Rename(m_strCardFile, m_strArchFile);
			 			 
	// call advanced service 2788 to reset cards from In Process to Not Processed
	TRY
	{
		MESSAGE(ResetCards, 2788);
		
		REQ_2788.cPassProcInd = NOT_PROCESSED;
		REQ_2788.cProcInd = IN_PROCESS;
		
		// invoke the service and switch on the return value
		switch(ResetCards.InvokeService())
		{
			case DAA_SUCCESS:
				break;
				
			default:
				strcpy (ResetCards.m_pMsgParms->ErrorInfo.szErrorText,
						"Service 2788 failed.  Could not reset cards.");
				ResetCards.ThrowException();
		}
		
	} // end TRY
	
	CATCH(CFYException, e)
	{
		e->Display();
	}
	END_CATCH;
	
	return;
}

void CCardOrderDlg::PadSpace(char * sInput, int iLength)
{

	int i = strlen(sInput);
	while (i < iLength)
	{
		strcat(sInput, " ");
		i = strlen(sInput);
	}
	return;
}
