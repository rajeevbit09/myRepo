// CardOrderDlg.cpp :	header file
//
// Description:			Also, Pass Cards are ordered and processed from this window.
//
// Author:				Joseph Fletcher - DT, Inc.
//
// Date:				6/30/1999

#if !defined(AFX_CARDORDERDLG_H__C5B59053_2F10_11D3_A32E_00104B9822DC__INCLUDED_)
#define AFX_CARDORDERDLG_H__C5B59053_2F10_11D3_A32E_00104B9822DC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define SEC_PASSCARD_ORDER		"EP999"
#define SEC_PASSCARD_PROCESS	"EP999"
#define OUTPUT_FILE				"sendkirk.txt"
#define KIRKPLASTIC_ARCHIVE		"sendkirk.sav"
#define NOT_PROCESSED			'N'
#define IN_PROCESS				'I'

/////////////////////////////////////////////////////////////////////////////
// CCardOrderDlg dialog

class CCardOrderDlg : public CFYDialog
{
// Construction
public:
	CCardOrderDlg(CWnd* pParent = NULL);   // standard constructor
	BOOL OnCloseAndSave();

// Dialog Data
	//{{AFX_DATA(CCardOrderDlg)
	enum { IDD = IDD_PASS_CARD_ORDER };
	CStatic	m_ProgressText;
	CProgressCtrl	m_ProgressBar;
	CFYEdit	m_edtCardsToOrder;
	CFYButton	m_chkNotify;
	CFYEdit	m_edtCardsThreshold;
	CButton	m_btnCreate;
	CButton	m_btnProcess;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCardOrderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCardOrderDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnProcessOrderedCards();
	afx_msg void OnCreateCardOrderFile();
	virtual void OnOK();
	//}}AFX_MSG
	afx_msg LRESULT OnSetWindowState(  WPARAM wParam, LPARAM lParam );
	DECLARE_MESSAGE_MAP()
private:
	void PadSpace( char * sInput, int iLength);
	CString m_strCardFile;
	CString m_strArchFile;
	void SetPassCardsToOrder();
	void SetCardFile();
	void WriteCardFile();
	void FormatCardFileDate(char *szDatabaseDate, char *szExportDate);
	void FormatCardFileFooterString(int nRecords, char *szString);
	void FormatCardFileHeaderString(char *szString);
	void ProcessCardFile();
	void ResetCards();
	BOOL PerformSave();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CARDORDERDLG_H__C5B59053_2F10_11D3_A32E_00104B9822DC__INCLUDED_)
