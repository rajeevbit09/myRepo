// ActivationFeeUpdateDlg.cpp : implementation file
//

#include "stdafx.h"
#include "pass.h"
#include "passdoc.h"
#include "ActivationFeeUpdateDlg.h"

#include "fya02371.h"
#include "fyr02371.h"
#define	REQ_2371	PsgrActv.m_pRequest->R02371_appl_area


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CActivationFeeUpdateDlg dialog


CActivationFeeUpdateDlg::CActivationFeeUpdateDlg(CWnd* pParent /*=NULL*/)
	: CFYDialog(CActivationFeeUpdateDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CActivationFeeUpdateDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CActivationFeeUpdateDlg::DoDataExchange(CDataExchange* pDX)
{
	CFYDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CActivationFeeUpdateDlg)
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDC_CURR_YR_FEE_PD, m_cmbCurrYrFeePd);
	DDX_Control(pDX, IDC_NXT_YR_FEE_PD, m_cmbNextYrFeePd);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CActivationFeeUpdateDlg, CDialog)
	//{{AFX_MSG_MAP(CActivationFeeUpdateDlg)
		ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_MESSAGE( WM_SETWINDOWSTATE, OnSetWindowState )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CActivationFeeUpdateDlg message handlers
LRESULT CActivationFeeUpdateDlg::OnSetWindowState (WPARAM wParam, LPARAM lParam)
{
    // Always call the default handler
    CFYDialog::OnSetWindowState (wParam, lParam);

    return 0;
}

BOOL CActivationFeeUpdateDlg::OnInitDialog()
{
	CFYDialog::OnInitDialog();

	m_pDoc = (CPassDoc *)GetDocument();


	m_btnOK.EnableWindow (TRUE);


	m_cmbCurrYrFeePd.AddString("Y","Y");
	m_cmbCurrYrFeePd.AddString("N","N");
	m_cmbCurrYrFeePd.AddString("E","E");
	m_cmbCurrYrFeePd.SetCode(m_pDoc->xPpr.Psgr[0].m_strCurAtvnFeeCd);

	m_cmbNextYrFeePd.AddString("Y","Y");
	m_cmbNextYrFeePd.AddString("N","N");
	m_cmbNextYrFeePd.AddString("E","E");
	m_cmbNextYrFeePd.SetCode(m_pDoc->xPpr.Psgr[0].m_strNxtAtvnFeeCd);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void CActivationFeeUpdateDlg::OnOK()
{
	if (PerformSave())
	{
		StatusBarMessage ("Activation Fee updated successfully");
		CDialog::OnOK();

	}

	return;

}

BOOL CActivationFeeUpdateDlg::PerformSave()
{
	CWaitCursor Wait;
	TRY
	{
		MESSAGE(PsgrActv, 2371);


		CString strMessage;


		// Populate the following elements of the request from elements on the document.

		strcpy(REQ_2371.sPprNbr, m_pDoc->xPpr.m_strPprNbr);
	    REQ_2371.cCurAtvnFeeCd=m_cmbCurrYrFeePd.GetCode()[0];
		REQ_2371.cNxtAtvnFeeCd=m_cmbNextYrFeePd.GetCode()[0];

			// Invoke the service and switch on the return value
			switch(PsgrActv.InvokeService())
			{
				case DAA_SUCCESS:
					break;

				case MSG_TWO_PARENTS_FOR_PPR:
				// Already two active parents message
				AfxMessageBox(MSG_TWO_ACTIVE_PARENTS);
				return FALSE;

				default:
					strcpy (PsgrActv.m_pMsgParms->ErrorInfo.szErrorText,
							"Service 2371 failed.  Could not update pass status.");
					PsgrActv.ThrowException();
			}


		return TRUE;
	}

	CATCH(CFYException, e)
	{
		e->Display();
		return FALSE;
	}
	END_CATCH

	return FALSE;
}

void CActivationFeeUpdateDlg::OnDestroy()
{
	CFYDialog::OnDestroy();
	SetIsModified (FALSE);
}
void CActivationFeeUpdateDlg::OnCancel()
{
	SetIsModified (FALSE);
	CFYDialog::OnCancel();
}



