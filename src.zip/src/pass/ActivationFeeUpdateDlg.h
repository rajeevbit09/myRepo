#if !defined(AFX_ACTIVATIONFEEUPDATEDLG_H__165EAC0E_6FB6_4F24_952B_A374EE28145A__INCLUDED_)
#define AFX_ACTIVATIONFEEUPDATEDLG_H__165EAC0E_6FB6_4F24_952B_A374EE28145A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ActivationFeeUpdateDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CActivationFeeUpdateDlg dialog

class CActivationFeeUpdateDlg : public CFYDialog
{
// Construction
public:
	CActivationFeeUpdateDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CActivationFeeUpdateDlg)
	enum { IDD = IDD_ACTVN_FEE };
	CButton	m_btnOK;
	CFYComboBox	m_cmbCurrYrFeePd;
	CFYComboBox	m_cmbNextYrFeePd;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CActivationFeeUpdateDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CActivationFeeUpdateDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
    afx_msg LRESULT OnSetWindowState( WPARAM wParam, LPARAM lParam );
	DECLARE_MESSAGE_MAP()

private:
	CPassDoc* m_pDoc;
	BOOL PerformSave();	

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ACTIVATIONFEEUPDATEDLG_H__165EAC0E_6FB6_4F24_952B_A374EE28145A__INCLUDED_)
