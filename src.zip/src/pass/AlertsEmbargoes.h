#if !defined(AFX_ALERTSEMBARGOES_H__539167DC_91D5_43EB_B08D_A81E3B7866FF__INCLUDED_)
#define AFX_ALERTSEMBARGOES_H__539167DC_91D5_43EB_B08D_A81E3B7866FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AlertsEmbargoes.h : header file
//

// define column constants for the list
#define ARPT_CD				0
#define TRVL_ALRT_CD		1
#define TRVL_ALRT_STRT_DT	2
#define TRVL_ALRT_END_DT	3
#define TRVL_ALRT_MSG_TXT	4
#define TRVL_ALRT_URL_ADR	5
#define LST_UPDT_ID			6
#define LST_UPDT_GTS		7

// define security constants
#define SEC_ALERTS_EMBARGOES_LIST "EP400"
#define SEC_ARPT_COMBO "EP400"
#define SEC_TYPE_COMBO "EP400"
#define SEC_START_DATE "EP400"
#define SEC_END_DATE "EP400"
#define SEC_CURRENT_OPT "EP400"
#define SEC_ALL_OPT "EP400"
#define SEC_ALERT_EMBARGO_EDIT "EP400"
#define SEC_URL_EDIT "EP400"
#define SEC_ADDSAVE_BUTTON "EP400"

/////////////////////////////////////////////////////////////////////////////
// CAlertsEmbargoes dialog

class CAlertsEmbargoes : public CFYDialog
{
// Construction
public:
	CAlertsEmbargoes(CWnd* pParent = NULL);   // standard constructor
// Dialog Data
	//{{AFX_DATA(CAlertsEmbargoes)
	enum { IDD = IDD_ALERTS_EMBARGOES };
	CButton	m_btnAddSave;
	CFYListCtrl	m_lstAlertsEmbargoes;
	CFYEdit	m_edtUrl;
	CFYDateEdit	m_edtStartDate;
	CFYDateEdit	m_edtEndDate;
	CFYEdit	m_edtAlertEmbargo;
	CFYComboBox	m_cmbType;
	CFYComboBox	m_cmbStation;
	CFYButton m_optCurrent;
	CFYButton m_optAll;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAlertsEmbargoes)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	BOOL OnCloseAndSave();

// Implementation
protected:
	BOOL ValidateAlertEmbargoData();
	afx_msg LRESULT OnSetWindowState( WPARAM wParam, LPARAM lParam );
	afx_msg LRESULT OnBeforeRowChange(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnRowChange(WPARAM wParam, LPARAM lParam);

	BOOL FillAlertsEmbargoesList(char selTyp);
	BOOL FillAlertEmbargoDetail();
	BOOL ClearAlertEmbargoDetail();
	BOOL PerformSave();
	
	CFYRadioButtonGroup m_ShowTypeGroup;

	// Generated message map functions
	//{{AFX_MSG(CAlertsEmbargoes)
	virtual BOOL OnInitDialog();
	afx_msg void OnRadioCurrent();
	afx_msg void OnRadioAll();
	afx_msg void OnButtonAddSave();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ALERTSEMBARGOES_H__539167DC_91D5_43EB_B08D_A81E3B7866FF__INCLUDED_)
