/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB71203.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Transquest                                             **
**                  Gayle J. Swafford                                      **
**                                                                         **
** Date Written:    November 18, 1996                                      **
**                                                                         **
** Description:     This module gathers imputed wage information in order  **
**                  to produce the Imputed Wage Notifications for German   **
**                  employees and senior officers on a monthly basis; and  **
**                  for Western Early Outs, Voluntary Severance, Former    **
**                  Western and Board Members on a monthly basis.          **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 01/04/96      FFA                      Revised                          **
**                                                                         **
** 02/19/96      KCH              134     Revised (delete trip_hist proc.) **
**                                                                         **
** 03/20/96      JFB                     Added new Senior Officer groups.  **
**                                                                         **
** 04/10/96      JFB                     Added true cursor 4365.           **
**                                                                         **
** 11/18/96      GJS                     Copied EPB71201.c to EPB71203.c   **
**                                       and modified to only report on    **
**                                       Western and VolSev to enable      **
**                                       reports to be produced seperately.**
**                                                                         **
****************************************************************************/
#include "epb71203.h"

main()
{
   BCH_Init("EPB71203", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   char    *pCycle;
   short   nRptIndex,           
           nReqRptInd1 = FALSE;

   /*** Get cycle from script ***/
   pCycle = (char *) getenv("CYCLES");
   strcpy(RS.sCycle, pCycle);

   /**** Initialize Fields with spaces   ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(sSaveNrevNbr, SPACE_CHAR);

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */

   /*** Process  western early outs, Former Western, and voluntary severance. ***/
   strcpy(sSaveNrevNbr, SPACE_CHAR);
   strcpy(sPassGrp1, WESTERN_EARLYOUT);
   strcpy(sPassGrp2, VOL_SEV);
   strcpy(sPassGrp3, FORMER_WESTERN_EMP);
   strcpy(sPassGrp4, SPACE_CHAR);
   strcpy(sPassGrp5, SPACE_CHAR);
   strcpy(sPassGrp6, SPACE_CHAR);
     
   DPM_2050_ProcessPprs();

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2050_ProcessPprs                         **
**                                                               **
** Description:     Process the PPRs.                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/
void DPM_2050_ProcessPprs()
{
   short     nSvcRtnCd;      /* Service return code */

   /*** Get a row from the PPR table whose pass group is Western Early-out, ***/
   /*** Former Western, or Voluntary Severance,                             ***/
   memset(&R02668.R02668_appl_area,LOW_VALUES, sizeof(R02668.R02668_appl_area));
   memset(&A02668,LOW_VALUES,sizeof(A02668));

   R02668.R02668_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   strcpy(R02668.R02668_appl_area.sPassGrpCd1, sPassGrp1);
   strcpy(R02668.R02668_appl_area.sPassGrpCd2, sPassGrp2);
   strcpy(R02668.R02668_appl_area.sPassGrpCd3, sPassGrp3);
   strcpy(R02668.R02668_appl_area.sPassGrpCd4, sPassGrp4);
   strcpy(R02668.R02668_appl_area.sPassGrpCd5, sPassGrp5);
   strcpy(R02668.R02668_appl_area.sPassGrpCd6, sPassGrp6);
   strcpy(R02668.R02668_appl_area.sPprNbr, RS.sPprNbr);

   nSvcRtnCd = BCH_InvokeService(EPBINQ0,
                                 &R02668,
                                 &A02668,
                                 SERVICE_ID_02668,
                                 1,
                                 sizeof(R02668.R02668_appl_area));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
       	 BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2050_ProcessPprs");
       	 break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
       	 BCH_FormatMessage(2,TXT_SVC, "FYS02668");
       	 BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2050_ProcessPprs");
   }

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      DPM_2100_ProcessRows();
      RS.recsproc++;
       
      /**** get another row from the ppr  table  ****/
      R02668.R02668_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A02668.A02668_appl_area, LOW_VALUES, sizeof(_A02668_APPL_AREA));

      nSvcRtnCd = BCH_InvokeService(EPBINQ0,
                                     &R02668,
                                     &A02668,
                                     SERVICE_ID_02668,
                                     1,
                                     sizeof(R02668.R02668_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02668");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2050_ProcessPprs");
      }  
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2100_ProcessRows                         **
**                                                               **
** Description:     Process  each PPR returned from service 02668**
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/
void DPM_2100_ProcessRows()
{
   short     nSvcRtnCd;      /* Service return code */

   strcpy(RS.sPprNbr, A02668.A02668_appl_area.sPprNbr);

   /*** Next, get the sum of the imputed wages from the imputed trip tables ***/
   /*** for the time period entered in the script                          ***/
   DPM_2120_SumImpWges();

   /*** If this PPR had some imputed wages from the imputed trip table, process the imputed trip detail***/
   if (A02869.A02869_appl_area.fFltImptValAmt > 0) /* val not wage  kch */
   {
      strcpy(sSaveNrevNbr, SPACE_CHAR);

      /**** Get imputed trip record for ppr_nbr ****/
      memset(&R04365.R04365_appl_area,LOW_VALUES, sizeof(R04365.R04365_appl_area));
      memset(&A04365,LOW_VALUES,sizeof(A04365));

	  R04365.R04365_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
      strcpy(R04365.R04365_appl_area.sPprNbr, A02668.A02668_appl_area.sPprNbr);

      nSvcRtnCd = BCH_InvokeService(EPBCSR0,
                                    &R04365,
                                    &A04365,
                                    SERVICE_ID_04365,
                                    1,
                                    sizeof(R04365.R04365_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
		    break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
           	BCH_FormatMessage(1,TXT_SVC_UNSUCC);
           	BCH_FormatMessage(2,TXT_SVC, "FYS04365");
           	BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2100_ProcessRows");
         	break;
      }

      while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
	  {
         /*** Process Imputed trip row if imputed wage amt not = 0    ***/
         if (A04365.A04365_appl_area.fFltImptValAmt != 0) /* val not wage kch  */
         {
            lPassTripNbr = A04365.A04365_appl_area.lPassTripNbr;
            fCurrXChgRte = A04365.A04365_appl_area.fCurrExchgRatNbr;
            fNrevPmt = A04365.A04365_appl_area.fNrevPmtAmt;
            fFltImptWage = A04365.A04365_appl_area.fFltImptWageAmt;
            fFltImptVal = A04365.A04365_appl_area.fFltImptValAmt;
            strcpy(sFlightDprtDt, UTL_ConvertDate(A04365.A04365_appl_area.sFltDprtDt,CNV_DB_TO_DD_MMM_YYYY));
            strcpy(sSortDprtDt, UTL_ConvertDate(A04365.A04365_appl_area.sPassRptSortDt,CNV_DB_TO_YYYYMMDD));                            
   	        strcpy(sFltOrig, A04365.A04365_appl_area.sFltTripOrigId);
   		    strcpy(sFltDest, A04365.A04365_appl_area.sFltTripDestId);
   		    strcpy(sNrevNbr, A04365.A04365_appl_area.sNrevNbr);
      		DPM_2200_ProcessTrip();

            /*** After all of the imputed trip items have been processed for this PPR, Update the ***/
            /*** items to show that they have been processed                                      ***/
            DPM_2130_UpdateImputedTrip();
         }

         /*** Get the next Imputed trip row for this PPR ***/
         R04365.R04365_appl_area.cArchCursorOpTxt = FETCH_ROW;
         memset(&A04365.A04365_appl_area, LOW_VALUES, sizeof(_A04365_APPL_AREA));

     	 nSvcRtnCd = BCH_InvokeService(EPBCSR0,
                                       &R04365,
                                       &A04365,
                                       SERVICE_ID_04365,
                                       1,
                                       sizeof(R04365.R04365_appl_area));

      	 switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;

            case ARC_ROW_NOT_FOUND:
               break;

         	default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS04365");
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2100_ProcessRows");
      	 }
      }
      
      R04365.R04365_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;

      nSvcRtnCd = BCH_InvokeService(EPBCSR0,
                                    &R04365,
                                    &A04365,
                                    SERVICE_ID_04365,
                                    1,
                                    sizeof(R04365.R04365_appl_area));

   }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2120_SumImpWges                          **
**                                                               **
** Description:     Sum Imputed wages for period entered in script*
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2120_SumImpWges()           
{
   short     nSvcRtnCd;      /* Service return code */

   /*** get the sum of the imputed wages from the imputed trip table ***/
   /*** for the time period entered in the script                          ***/
   memset(&R02869.R02869_appl_area,LOW_VALUES, sizeof(R02869.R02869_appl_area));
   memset(&A02869,LOW_VALUES,sizeof(A02869));

   strcpy(R02869.R02869_appl_area.sPprNbr, A02668.A02668_appl_area.sPprNbr);

   nSvcRtnCd = BCH_InvokeService(EPBUPD0,
                                 &R02869,
                                 &A02869,
                                 SERVICE_ID_02869,
                                 1,
                                 sizeof(R02869.R02869_appl_area));

   switch (nSvcRtnCd)
   {
    	  case ARC_SUCCESS:\
          break;

          case ARC_ROW_NOT_FOUND: 
          break;

          default:
          BCH_FormatMessage(1,TXT_SVC_UNSUCC);
          BCH_FormatMessage(2,TXT_SVC, "FYS02869");
          BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2120_SumImpWges");
          break;
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2130_UpdateImputedTrip                   **
**                                                               **
** Description:     Update the Imputed Trip, Imputed Trip History**
**                  Tables.  Set match ind to N, notify date to  **
**                  today, and exchange rate.                    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2130_UpdateImputedTrip()
{
   short     nSvcRtnCd;      /* Service return code */

   /*** update the Imputed Trip Table ***/
   R04365.R04365_appl_area.fCurrExchgRatNbr = fCurrXChgRte;
   R04365.R04365_appl_area.cArchCursorOpTxt = UPDATE_ROW;

   nSvcRtnCd = BCH_InvokeService(EPBCSR0,
                                 &R04365,
                                 &A04365,
                                 SERVICE_ID_04365,
                                 1,
                                 sizeof(R04365.R04365_appl_area));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      default:
     	 BCH_FormatMessage(1,TXT_SVC_UNSUCC);
       	 BCH_FormatMessage(2,TXT_SVC, "FYS04365");
         sprintf(sErrorMessage, "sPprNbr = %s",
                                   R04365.R04365_appl_area.sPprNbr); 
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2130_UpdateImputedTrip");
         break;
   }

}
   
/******************************************************************
**                                                               **
** Function Name:   DPM_2200_ProcessTrip                         **
**                                                               **
** Description:     Process imputed trip row                     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2200_ProcessTrip()    
{
   short     nSvcRtnCd;      /* Service return code */

   /**** get mileage for this trip ****/
   memset(&R02576.R02576_appl_area,LOW_VALUES, sizeof(R02576.R02576_appl_area));
   memset(&A02576,LOW_VALUES,sizeof(A02576));

   strcpy(R02576.R02576_appl_area.sFltOrigCtyId, sFltOrig);
   strcpy(R02576.R02576_appl_area.sFltDestCtyId, sFltDest);

   nSvcRtnCd = BCH_InvokeService(EPBINQ1,
                                 &R02576,
                                 &A02576,
                                 SERVICE_ID_02576,
                                 1,
                                 sizeof(R02576.R02576_appl_area));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
 	     BCH_FormatMessage(1,TXT_ARPT_PR_RETRIEVE_ERR, sFltOrig, sFltDest);

         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessTrip");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02576");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessTrip");
         break;
   }

   /*** Next, if this is a different nrev passenger, get the nrev passenger name ***/
   if (strcmp(sNrevNbr, sSaveNrevNbr) != 0)
   {
      memset(&R02730.R02730_appl_area,LOW_VALUES, sizeof(R02730.R02730_appl_area));
      memset(&A02730,LOW_VALUES,sizeof(A02730));

      strcpy(R02730.R02730_appl_area.sPprNbr, A02668.A02668_appl_area.sPprNbr);
      strcpy(R02730.R02730_appl_area.sNrevNbr, sNrevNbr);

      nSvcRtnCd = BCH_InvokeService(EPBINQ1,
                                    &R02730,
                                    &A02730,
                                    SERVICE_ID_02730,
                                    1,
                                    sizeof(R02730.R02730_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            strcpy(sSaveNrevNbr, sNrevNbr);                       
            break;

         case ARC_ROW_NOT_FOUND: 
 	        BCH_FormatMessage(1,TXT_PPR_NREV_NOT_FOUND, R02730.R02730_appl_area.sPprNbr, sNrevNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessTrip");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02730");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessTrip");
            break;
      }
   }

   /**** get ticket or flt nbr from imputed flight leg table  ****/
   strcpy(sFlightNbr, "     ");
   strcpy(sTicketNbr, "          ");
   memset(&R02635.R02635_appl_area,LOW_VALUES, sizeof(R02635.R02635_appl_area));
   memset(&A02635,LOW_VALUES,sizeof(A02635));
   strcpy(R02635.R02635_appl_area.sFltOrigCtyId, sFltOrig);
   R02635.R02635_appl_area.lPassTripNbr =  lPassTripNbr;

   nSvcRtnCd = BCH_InvokeService(EPBUPD1,
                                 &R02635,
                                 &A02635,
                                 SERVICE_ID_02635,
                                 1,
                                 sizeof(R02635.R02635_appl_area));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
   	     strcpy(sTicketNbr, A02635.A02635_appl_area.sTktNbr);
   	     strcpy(sFlightNbr, A02635.A02635_appl_area.sFltNbr);
         break;

      case ARC_ROW_NOT_FOUND: 
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02635");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessTrip");
         break;
   }

   /**** write Western Early Out/Former Western/voluntary severance Notifications ****/
   DPM_5013_GenerateEPB71213();

   /*** Finally, Update the Imputed Flight Leg Table to set the match ind to 'N'***/
   memset(&R02675.R02675_appl_area,LOW_VALUES, sizeof(R02675.R02675_appl_area));
   memset(&A02675,LOW_VALUES,sizeof(A02675));

   R02675.R02675_appl_area.lPassTripNbr = lPassTripNbr;

   nSvcRtnCd = BCH_InvokeService(EPBUPD1,
                                 &R02675,
                                 &A02675,
                                 SERVICE_ID_02675,
                                 1,
                                 sizeof(R02675.R02675_appl_area));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02675");
         sprintf(sErrorMessage, "lPassTripNbr = %d", R02675.R02675_appl_area.lPassTripNbr);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessTrip");
         break;
   }
}
   
/******************************************************************
**                                                               **
** Function Name:   DPM_5013_GenerateEPB71213()                  **
**                                                               **
** Description:     Write Control records for report EPB71213    **
**                  Western Early Out/Formern Western/Voluntary  **
**                  Severence Imputed Wage Notifications         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_5013_GenerateEPB71213()
{
   short nRptIndex;     /* Index into the report control table */

   /**** Initialize report sort and data copybooks ****/
   memset(&EPRF7123.F7123_RptDataStruct, LOW_VALUES, sizeof(_F7123_RPTDATASTRUCT));
   memset(&EPRS7123.S7123_RptDataStruct, LOW_VALUES, sizeof(_S7123_RPTDATASTRUCT));
   
   /*** Fill sort layout structure ***/
   strcpy(EPRF7123.F7123_RptDataStruct.sPprNbr, A02668.A02668_appl_area.sPprNbr);
   strcpy(EPRF7123.F7123_RptDataStruct.sPpr1Addr, A02668.A02668_appl_area.sPpr1Addr);
   strcpy(EPRF7123.F7123_RptDataStruct.sPpr2Addr, A02668.A02668_appl_area.sPpr2Addr);
   strcpy(EPRF7123.F7123_RptDataStruct.sPprCtyAddr, A02668.A02668_appl_area.sPprCtyAddr);
   strcpy(EPRF7123.F7123_RptDataStruct.sPprStCd, A02668.A02668_appl_area.sPprStCd);
   strcpy(EPRF7123.F7123_RptDataStruct.sPprZipAddr, A02668.A02668_appl_area.sPprZipAddr);
   strcpy(EPRF7123.F7123_RptDataStruct.sPprNm, A02668.A02668_appl_area.sPprNm);
   strcpy(EPRF7123.F7123_RptDataStruct.sPprCtryCd, A02668.A02668_appl_area.sPprCtryCd);
   strcpy(EPRF7123.F7123_RptDataStruct.sNrevNm, A02730.A02730_appl_area.sNrevNm);
   strcpy(EPRF7123.F7123_RptDataStruct.sFltNbr, sFlightNbr);
   strcpy(EPRF7123.F7123_RptDataStruct.sFltDprtDt, sFlightDprtDt);
   strcpy(EPRF7123.F7123_RptDataStruct.sFltTripOrigId, sFltOrig);
   strcpy(EPRF7123.F7123_RptDataStruct.sFltTripDestId, sFltDest);

   //EPRF7123.F7123_RptDataStruct.lFltArptPrNbr = A02576.A02576_appl_area.lFltArptPrNbr;
   sprintf(EPRF7123.F7123_RptDataStruct.sFltArptPrNbr, "%ld", A02576.A02576_appl_area.lFltArptPrNbr);
   //EPRF7123.F7123_RptDataStruct.fFltImptWageAmt = fFltImptWage;
   sprintf(EPRF7123.F7123_RptDataStruct.sFltImptWageAmt, "%11.2lf", fFltImptWage);
   //EPRF7123.F7123_RptDataStruct.fFltImptValAmt = fFltImptVal;
   sprintf(EPRF7123.F7123_RptDataStruct.sFltImptValAmt, "%11.2lf", fFltImptVal);
   //EPRF7123.F7123_RptDataStruct.fNrevPmtAmt = fNrevPmt;
   sprintf(EPRF7123.F7123_RptDataStruct.sNrevPmtAmt, "(%9.2f)", fNrevPmt);
   EPRF7123.F7123_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;
   strcpy(EPRS7123.S7123_RptDataStruct.sPprNbr, A02668.A02668_appl_area.sPprNbr);
   strcpy(EPRS7123.S7123_RptDataStruct.sNrevNbr, sNrevNbr);
   strcpy(EPRS7123.S7123_RptDataStruct.sFltDprtDt, sSortDprtDt);
   //EPRS7123.S7123_RptDataStruct.lPassTripNbr = A04365.A04365_appl_area.lPassTripNbr;
   sprintf(EPRS7123.S7123_RptDataStruct.sPassTripNbr, "%10ld", A04365.A04365_appl_area.lPassTripNbr); 


   BCH_WriteRptRec("EPB71213", &EPRS7123, sizeof(EPRS7123), &EPRF7123, sizeof(EPRF7123)); 
}                        


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_9500_ProcessEndOfProgram()
{
   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
