/*##########################################################################*/
/*                                                                          */
/* Copyright 2010 - Delta Air Lines, Inc.                                   */
/*                       All Rights Reserved                                */
/*               Access, Modification, or Use Prohibited                    */
/* Without Express Permission of Delta Air Lines                            */
/*                                                                          */
/*##########################################################################*/
/*                                                                         **
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    epb40002.c                                             **
**                                                                         **
** Program Type:    Transaction Driven Process Module                      **
**                                                                         **
** Author:          Duane Ellis                                            **
**                                                                         **
** Date Written:    Mar 2010                                               **
**                                                                         **
** Description:     Transaction driven process module to create            **
**                  Net Value files for Payroll and other external         **
**                  companies by reading unprocessed Net Value records     **
**                  from the NRAP_TRAP_IMPD_VAL table.                     **
**                                                                         **
**                                                                         **
**        Here's how this works:                                           **
**                                                                         **
**   1. If an Trp_Impd_Vall record has an associated Earning Number        **
**      then it goes to Payroll via GEAC file                              **
**                                                                         **
**   2. If it doesn't then we look up the PPR number in T_NREV_PSGR and    **
**      see if the employee is Mesaba, MLT, or Compass employee.           **
**      T_NREV_PSGR.NREV_SRC_CD = "xx"                                     **
**                                                                         **
**         Mesaba Employee  "XJ" :  Mesaba file                            **
**         MLT Employee     "ML" :  MLT file                               **
**         Compass Employee "CP" :  Compass file                           **
**                                                                         **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by      Description                                  **
** ----       ----------      --------------------                         **
** 03/31/2010 D Ellis         Inital Program Creation                      **
** 10/19/2010 D Ellis         Added nrap_trp_impd_val.Trp_Dprt_Dt Column   **
** 08/12/2011 D Ellis         Removed Export for Mesaba & Compass          **
**                                                                         **
****************************************************************************/
#include "epb40002.h"

char VersionStr[]    = "epb40002 v1.0.0.1";
char gCompile_Date[] = __DATE__;
char gCompile_Time[] = __TIME__;

time_t startupTime_;
time_t endTime_;

void main(int argc, char **argv)
{

   BCH_Init("EPB40002", NUMBER_OF_THREADS);

   TPM_1000_Initialize(argc, argv);

   TPM_2000_Mainline();

   TPM_9000_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);
}


/******************************************************************
**                                                               **
** Function Name:   TPM_1000_Initialize                          **
**                                                               **
** Description:     Performs startup initialization and opens    **
**                  RPAD input file.                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_1000_Initialize(int argc, char **argv)
{
   char *pEnvString;


   /**** Initialize counters, accumulators and other variables ***/

   startupTime_ = time(0);

   // Init Counters
   RS.Tot_Net_Val_Cnt = 0L;
   RS.Payroll_Rec_Cnt = 0L;
   RS.Compass_Rec_Cnt = 0L;
   RS.Mesaba_Rec_Cnt  = 0L;
   RS.MLT_Rec_Cnt     = 0L;
   RS.Ignore_Cnt      = 0L;
   RS.Error_Cnt       = 0L;

   //
   // Company variables
   //
   RS.fDelta    = false;
   RS.fCompass  = false;
   RS.fMesaba   = false;
   RS.fMLT      = false;

   RS.fpPayroll = 0;
   RS.fpCompass = 0;
   RS.fpMesaba  = 0;
   RS.fpMLT     = 0;

   memset(RS.DeltaFilePath,   0, sizeof(RS.DeltaFilePath));
   memset(RS.CompassFilePath, 0, sizeof(RS.CompassFilePath));
   memset(RS.MesabaFilePath,  0, sizeof(RS.MesabaFilePath));
   memset(RS.MLT_FilePath,    0, sizeof(RS.MLT_FilePath));

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, VersionStr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_1000_Initialize");



   // See if any parameters were specified

   if (argc <= 1) {           // No Parm?  Do ALL
      RS.fDelta   = true;
      RS.fCompass = true;
      RS.fMesaba  = true;
      RS.fMLT     = true;
      printf("\n\nProcessing Net Value Amounts for ALL companies\n\n");
   }
   else {
      if (strcmp(argv[1], "DL")==0) {         // Delta?
         RS.fDelta = true;
         printf("\n\nProcessing Net Value Amounts for Delta only\n\n");
      }
      // ** Commented out 8/12/2011 DEllis
      //else if (strcmp(argv[1], "CP")==0) {    // Compass?
      //   RS.fCompass = true;
      //   printf("\n\nProcessing Net Value Amounts for Compass only\n\n");
      //}
      //else if (strcmp(argv[1], "XJ")==0) {    // Mesaba?
      //   RS.fMesaba = true;
      //   printf("\n\nProcessing Net Value Amounts for Mesaba only\n\n");
      //}
      else if (strcmp(argv[1], "ML")==0) {    // MLT?
         RS.fMLT = true;
         printf("\n\nProcessing Net Value Amounts for MLT only\n\n");
      }
      else {
         printf("\n\nInvalid Company Code specified on command line.\nApplication terminating\n\n");
         exit(0);
      }
   }


   /**** Get External Configuration Variables  ****/
   pEnvString = (char *)getenv("DELTA_FILE_PATH");
   if (pEnvString)
      strncpy(RS.DeltaFilePath, pEnvString, sizeof(RS.DeltaFilePath));

   // ** Commented out 8/12/2011 DEllis
   //pEnvString = (char *)getenv("COMPASS_FILE_PATH");
   //if (pEnvString)
   //   strncpy(RS.CompassFilePath, pEnvString, sizeof(RS.CompassFilePath));
   //
   //pEnvString = (char *)getenv("MESABA_FILE_PATH");
   //if (pEnvString)
   //   strncpy(RS.MesabaFilePath, pEnvString, sizeof(RS.MesabaFilePath));

   pEnvString = (char *)getenv("MLT_FILE_PATH");
   if (pEnvString)
      strncpy(RS.MLT_FilePath, pEnvString, sizeof(RS.MLT_FilePath));

}


/******************************************************************
**                                                               **
** Function Name:   TPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                  The main processing thread to processes      **
**                  RPAD data and to reprocess corrected data    **
**                  from the Suspense file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_2000_Mainline()
{

   /*******************************************************************/
   /************     See if there are any Trips to Impute   ***********/
   /*******************************************************************/
   nSvcRtnCd = TPM_8001_GetUnprocessedRecord(OPEN_AND_FETCH);
   if (nSvcRtnCd == ARC_ROW_NOT_FOUND) {
      printf("\nNo Net Value records found to export\n\n");
      return;
   }

   //
   // While there are Net Value Records to export ...
   //
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      RS.Tot_Net_Val_Cnt++;

      // Process current Net Value record
      TPM_3000_ProcessRecord();


      // Go get next Net Value Record
      nSvcRtnCd = TPM_8001_GetUnprocessedRecord(FETCH_ROW);
   }

   // clean up - close the DB cursor
   TPM_8001_GetUnprocessedRecord(CLOSE_CURSOR);
}


/******************************************************************
**                                                               **
** Function Name:   TPM_3000_ProcessRecord                       **
**                                                               **
** Description:     Process and export Net Value record data     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void  TPM_3000_ProcessRecord()
{
   char sCompanyCode[3];
   int nSvcRtnCd;


   // Obtain Company Code for this Employee
   if (TPM_8003_GetCompanyCode(RS.sPprNbr, sCompanyCode))
   {
      if (strcmp(sCompanyCode, "ML")==0)
         nSvcRtnCd = TPM_4040_WriteToMLTFile();

      // ** Commented out 8/12/2011 DEllis
      //else if (strcmp(sCompanyCode, "CP")==0)
      //   nSvcRtnCd = TPM_4020_WriteToCompassFile();
      // 
      //else if (strcmp(sCompanyCode, "XJ")==0)
      //   nSvcRtnCd = TPM_4030_WriteToMesabaFile();
      //
      else
         nSvcRtnCd = TPM_4010_WriteToPayrollFile();

      if (nSvcRtnCd == REC_WRITTEN)
         TPM_8009_UpdateSentToPayroll();
      else
         RS.Ignore_Cnt++;

   }
   else {
      printf("Unable to obtain Company Code for PPR: %s. Record Ignored\n", RS.sPprNbr);
      RS.Ignore_Cnt++;
   }
}

/******************************************************************
**                                                               **
** Function Name:   TPM_4020_WriteToPayrollFile                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   REC_WRITTEN = Record Written                 **
**                  REC_SKIPPED = Record Not Written (skipped)   **
**                                                               **
******************************************************************/

int TPM_4010_WriteToPayrollFile()
{
   if (RS.fDelta)    // Is writing to Delta Payroll file okay?
   {
      // Get Earning Number for current record
      if (TPM_8005_GetEarningNbr())
      {
         if (! RS.fpPayroll)
            TPM_8011_OpenPayrollFile();

         printf("PPR=%s, Amt=%5.2f, File=Payroll\n", RS.sPprNbr, RS.fImpdNetAmt);
         if (writePayrollDetail(RS.sPprNbr, RS.fImpdNetAmt, RS.sEarningNbr, RS.fpPayroll) > 0) {
            RS.Payroll_Rec_Cnt++;
            return REC_WRITTEN;
         }
      }
   }

   return REC_SKIPPED;
}


/******************************************************************
**                                                               **
** Function Name:   TPM_4020_WriteToCompassFile                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   REC_WRITTEN = Record Written                 **
**                  REC_SKIPPED = Record Not Written (skipped)   **
**                                                               **
******************************************************************/

int TPM_4020_WriteToCompassFile()
{

   if (RS.fCompass)    // Is writing to Compass file okay?
   {
      if (! RS.fpCompass)
         TPM_8021_OpenCompassFile();

      printf("PPR=%s, Amt=%5.2f, File=Compass\n", RS.sPprNbr, RS.fImpdNetAmt);
      if (writeDetail(RS.sPprNbr, RS.fImpdNetAmt, RS.fpCompass) > 0) {
         RS.Compass_Rec_Cnt++;
         return REC_WRITTEN;
      }
   }

   return REC_SKIPPED;
}

/******************************************************************
**                                                               **
** Function Name:   TPM_4030_WriteToMesabaFile()                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   REC_WRITTEN = Record Written                 **
**                  REC_SKIPPED = Record Not Written (skipped)   **
**                                                               **
******************************************************************/

int TPM_4030_WriteToMesabaFile()
{

   if (RS.fMesaba)    // Is writing to Mesaba file okay?
   {
      if (! RS.fpMesaba)
         TPM_8031_OpenMesabaFile();

      printf("PPR=%s, Amt=%5.2f, File=Mesaba\n", RS.sPprNbr, RS.fImpdNetAmt);
      if (writeDetail(RS.sPprNbr, RS.fImpdNetAmt, RS.fpMesaba) > 0) {
         RS.Mesaba_Rec_Cnt++;
         return REC_WRITTEN;
      }
   }

   return REC_SKIPPED;
}

/******************************************************************
**                                                               **
** Function Name:   TPM_4040_WriteToMLTFile()                    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   REC_WRITTEN = Record Written                 **
**                  REC_SKIPPED = Record Not Written (skipped)   **
**                                                               **
******************************************************************/

int TPM_4040_WriteToMLTFile()
{

   if (RS.fMLT)    // Is writing to MLT file okay?
   {
      if (! RS.fpMLT)
         TPM_8041_OpenMLTFile();

      printf("PPR=%s, Amt=%5.2f, File=MLT\n", RS.sPprNbr, RS.fImpdNetAmt);
      if (writeDetail(RS.sPprNbr, RS.fImpdNetAmt, RS.fpMLT) > 0) {
         RS.MLT_Rec_Cnt++;
         return REC_WRITTEN;
      }
   }

   return REC_SKIPPED;
}

/******************************************************************
**                                                               **
** Function Name:   TPM_8001_GetUnprocessedRecord                **
**                                                               **
** Description:     Call function to fetch all unprocessed       **
**                  Net Value records.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   Arch Service Return code                     **
**                                                               **
******************************************************************/

short  TPM_8001_GetUnprocessedRecord(char CursorOpTxt)
{
   short svc_rc;


   switch (CursorOpTxt)
   {

      case OPEN_AND_FETCH :

         memset(&R04747, LOW_VALUES, sizeof(R04747));
         memset(&A04747, LOW_VALUES, sizeof(A04747));
         R04747.R04747_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
         svc_rc = BCH_InvokeService(EPBINQ1, &R04747, &A04747, SERVICE_ID_04747, 1, sizeof(R04747.R04747_appl_area));
         break;

      case FETCH_ROW:

         // Get next Ticket Number
         memset(&R04747, LOW_VALUES, sizeof(R04747));
         memset(&A04747, LOW_VALUES, sizeof(A04747));
         R04747.R04747_appl_area.cArchCursorOpTxt = FETCH_ROW;
         svc_rc = BCH_InvokeService(EPBINQ1, &R04747, &A04747, SERVICE_ID_04747, 1, sizeof(R04747));
         break;

      case CLOSE_CURSOR :

         // Close the cursor
         R04747.R04747_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
         svc_rc = BCH_InvokeService(EPBINQ1, &R04747, &A04747, SERVICE_ID_04747, 1, sizeof(R04747));
         return ARC_SUCCESS;

   }

   switch (svc_rc)
   {
      case ARC_SUCCESS:
         strcpy(RS.sPprNbr,         A04747.A04747_appl_area.sPprNbr);
         strcpy(RS.sNrevNbr,        A04747.A04747_appl_area.sNrevNbr);
         strcpy(RS.sNrapCd,         A04747.A04747_appl_area.sNrapCd);
         RS.nNrapSpgmNb           = A04747.A04747_appl_area.nNrapSpgmNb;
         strcpy(RS.sNrapFrstBkgLdt, A04747.A04747_appl_area.sNrapFrstBkgLdt);
         RS.nNrapTrpSqNb          = A04747.A04747_appl_area.nNrapTrpSqNb;
         RS.nImpdValSqlNb         = A04747.A04747_appl_area.nImpdValSqlNb;
         RS.cImpdTrvlBandCd       = A04747.A04747_appl_area.cImpdTrvlBandCd;
         RS.cOwrtCd               = A04747.A04747_appl_area.cOwrtCd;
         RS.fImpdNetAmt           = A04747.A04747_appl_area.fImpdNetAmt;
         strcpy(RS.sSentToPyrlDt,   A04747.A04747_appl_area.sSentToPyrlDt);
         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04747");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8001_GetUnprocessedRecords");
   }

   return svc_rc;

}
/******************************************************************
**                                                               **
** Function Name:   TPM_8003_GetCompanyCode                      **
**                                                               **
** Description:     Call function to obtain the Employee's       **
**                  company code from T_NREV_PSGR table.         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F  (true = Record Found                    **
**                                                               **
**                                                               **
******************************************************************/

int TPM_8003_GetCompanyCode(char *sPPR, char *sCompanyCode)
{
   int employee_found = false;

   memset(&R02436, LOW_VALUES, sizeof(R02436));
   memset(&A02436, LOW_VALUES, sizeof(A02436));

   strcpy(R02436.R02436_appl_area.sPprNbr, sPPR);
   strcpy(R02436.R02436_appl_area.sNrevNbr, "00");

   nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R02436, &A02436, SERVICE_ID_02436, 1, sizeof(R02436.R02436_appl_area));

   if (nSvcRtnCd == ARC_SUCCESS) {
      strcpy(sCompanyCode, A02436.A02436_appl_area.sNrevSrcCd);
      employee_found = true;
   }

   return employee_found;
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8005_GetEarningNbr                       **
**                                                               **
** Description:     Call function to obtain the Delta Earning    **
**                  number for a given award program.            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F  (true = Earning Number returned)        **
**                                                               **
**                                                               **
******************************************************************/

int TPM_8005_GetEarningNbr()
{
   int nbr_found = false;

   // Look up Earning Number for this award program
   memset(&R04753, LOW_VALUES, sizeof(R04753));
   memset(&A04753, LOW_VALUES, sizeof(A04753));

   strcpy(R04753.R04753_appl_area.sNrapCd, RS.sNrapCd);
   R04753.R04753_appl_area.nNrapSpgmNb   = RS.nNrapSpgmNb;
   strcpy(R04753.R04753_appl_area.sNrapFrstBkgLdt, RS.sNrapFrstBkgLdt);
   strcpy(R04753.R04753_appl_area.sNrapParmTypCd, "EARNINGNBR");

   nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04753, &A04753, SERVICE_ID_04753, 1, sizeof(R04753.R04753_appl_area));

   if (nSvcRtnCd == ARC_SUCCESS) {
      strcpy(RS.sEarningNbr, A04753.A04753_appl_area.sNrapParmValTxt);
      nbr_found = true;
   }

   return nbr_found;
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8010_OpenPayrollFile                     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void  TPM_8011_OpenPayrollFile()
{
   if (! RS.fpPayroll)
   {
      RS.fpPayroll = fopen(RS.DeltaFilePath, "w+b");
      if (! RS.fpPayroll) {
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         sprintf(sErrorMessage,"Unable to open Delta Payroll Net Value File: %s\n", RS.DeltaFilePath);
         BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8003_OpenDeltaFile");
      }
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8003_OpenCompassFile                     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void  TPM_8021_OpenCompassFile()
{
   if (! RS.fpCompass)
   {
      RS.fpCompass = fopen(RS.CompassFilePath, "w+b");
      if (! RS.fpCompass) {
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         sprintf(sErrorMessage,"Unable to open Compass Net Value File: %s\n", RS.CompassFilePath);
         BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8003_OpenCompassFile");
      }
      else {
         writeHeader(0L, RS.fpCompass);
      }
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8003_OpenMesabaFile                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void  TPM_8031_OpenMesabaFile()
{
   if (! RS.fpMesaba)
   {
      RS.fpMesaba = fopen(RS.MesabaFilePath, "w+b");
      if (! RS.fpMesaba) {
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         sprintf(sErrorMessage,"Unable to open Mesaba Net Value File: %s\n", RS.MesabaFilePath);
         BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8003_OpenMesabaFile");
      }
      else {
         writeHeader(0L, RS.fpMesaba);
      }
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8003_OpenMLTFile                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void  TPM_8041_OpenMLTFile()
{
   if (! RS.fpMLT)
   {
      RS.fpMLT = fopen(RS.MLT_FilePath, "w+b");
      if (! RS.fpMLT) {
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         sprintf(sErrorMessage,"Unable to open MLT Net Value File: %s\n", RS.MLT_FilePath);
         BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8003_OpenMltFile");
      }
      else {
         writeHeader(0L, RS.fpMLT);
      }
   }
}





/******************************************************************
**                                                               **
** Function Name:   TPM_8009_UpdateTrpImpdValAsSent              **
**                                                               **
** Description:     Call function to set the Snt_to_Pyrl_Dt      **
**                  date field a given NetValue Record           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_8009_UpdateSentToPayroll()
{
   memset(&R04754, LOW_VALUES, sizeof(_R04754));
   memset(&A04754, LOW_VALUES, sizeof(_A04754));

   strcpy(R04754.R04754_appl_area.sPprNbr,         RS.sPprNbr);
   strcpy(R04754.R04754_appl_area.sNrevNbr,        RS.sNrevNbr);
   strcpy(R04754.R04754_appl_area.sNrapCd,         RS.sNrapCd);
   R04754.R04754_appl_area.nNrapSpgmNb           = RS.nNrapSpgmNb;
   strcpy(R04754.R04754_appl_area.sNrapFrstBkgLdt, RS.sNrapFrstBkgLdt);
   R04754.R04754_appl_area.nNrapTrpSqNb          = RS.nNrapTrpSqNb;
   R04754.R04754_appl_area.nImpdValSqlNb         = RS.nImpdValSqlNb;
   strcpy(R04754.R04754_appl_area.sLstUpdtId,      MODULE_NAME);

   /*******Write to RPAD_FLWN_FL_SPNS ***/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0, &R04754, &A04754, SERVICE_ID_04754, 1, sizeof(R04754.R04754_appl_area));

   switch (nSvcRtnCd)
   {
     case ARC_SUCCESS:
        break;
     default:
        RS.Error_Cnt++;   // Log runtime error
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS04754");
        sprintf(sErrorMessage,
           "\n  PPR=%s, NRevNbr=%s",
           RS.sPprNbr,
           RS.sNrevNbr);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8009_UpdateSentToPayroll");
        break;
   }

}


/******************************************************************
**                                                               **
** Function Name:   TPM_9000_ProcessEndOfProgram                 **
**                                                               **
** Description:     Call function to perform end of program      **
**                  housekeeping (close files, print summary)    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void  TPM_9000_ProcessEndOfProgram()
{
   static char totals_buffer[1024];

   endTime_ = time(0);

   /** Include any logic here for final clean-up processing  **/

   // Close files
   if (RS.fpPayroll) {
      fclose(RS.fpPayroll);
   }
   if (RS.fpCompass) {
      writeHeader(RS.Compass_Rec_Cnt, RS.fpCompass);
      fclose(RS.fpCompass);
   }
   if (RS.fpMesaba) {
      writeHeader(RS.Mesaba_Rec_Cnt, RS.fpMesaba);
      fclose(RS.fpMesaba);
   }
   if (RS.fpMLT) {
      writeHeader(RS.MLT_Rec_Cnt, RS.fpMLT);
      fclose(RS.fpMLT);
   }


   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, VersionStr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9000_ProcessEndOfProgram");


   /************************/
   /**    CONTROL TOTALS  **/
   /************************/

   sprintf(totals_buffer,
      "\n********* Module Information **********\n"
      "  Processing Totals:\n"
      "    Total Records Selected : %lu\n"
      "    Export Summary:\n"
      "      DL Payroll           : %lu\n"
      "      Compass              : %lu\n"
      "      Mesaba               : %lu\n"
      "      MLT                  : %lu\n\n"
      "    Records Not Exported   : %lu\n"
      "    Runtime Errors         : %lu\n",
      RS.Tot_Net_Val_Cnt,
      RS.Payroll_Rec_Cnt,
      RS.Compass_Rec_Cnt,
      RS.Mesaba_Rec_Cnt,
      RS.MLT_Rec_Cnt,
      RS.Ignore_Cnt,
      RS.Error_Cnt);
   puts(totals_buffer);        // print totals

   // Print start and end time;
   //     Note: can't call these both in the same call because
   //     time is stored in a static buffer.
   printf("    Time Job started:      %s",   asctime(localtime(&startupTime_)));
   printf("    Time Job completed:    %s\n", asctime(localtime(&endTime_)));

}

//====================================================================================

static int writeHeader(long numrec, FILE *nvalfp)
{
   int written;
   time_t     currentTime;
   struct tm  *tp;
   static char datebuff[] = "YYYYMMDD";
   char outbuff[sizeof(AIRLINKHDR)+10];

   currentTime = time(0);
   tp = localtime(&currentTime);
   strftime(datebuff,sizeof(datebuff),"%Y%m%d",tp);

   sprintf(outbuff, "HDR%8.8s%05.5u    \r\n", datebuff, numrec);

   rewind(nvalfp);
   written = fwrite(outbuff, 1, sizeof(AIRLINKHDR)+2, nvalfp);
   return written;
}

static int writeDetail(char *ppr, float netamt, FILE *nvalfp)
{
   int i, written, len;
   char amtbuff[10];
   char outbuff[sizeof(AIRLINKDETAIL)+10];

   sprintf(amtbuff, "%7.2f", netamt);
   for (i=0; i<7 && amtbuff[i] == ' '; i++) {
        amtbuff[i] = '0';
   }
   sprintf(outbuff, "%9.9s%7.7s    \r\n", ppr, amtbuff);

   len = strlen(outbuff);
   written = fwrite(outbuff, 1, len, nvalfp);
   return written;
}

static int writePayrollDetail(char *ppr, float netamt, char *earnnbr, FILE *nvalfp)
{
   char outbuff[25];
   int written, len;

   sprintf(outbuff, "%9.9s,%5.2f,%s\r\n", ppr, netamt, earnnbr);

   len = strlen(outbuff);
   written = fwrite(outbuff, 1, len, nvalfp);
   return written;

}

