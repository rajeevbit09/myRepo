/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB60002.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Written:    May 1, 1995                                            **
**                                                                         **
** Description:     Database driven programs use, as their primary input,  **
**                  a Sybase database.  The database is scanned and        **
**                  updated and/or transactions are generated for          **
**                  subsequent processing steps.  This module retrieves    **
**                  the Imputed Flight Leg Table and searches the table    **
**                  for items older than 6 months.  It then moves these    **
**                  items to the Pass History Table.                       **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 8/16/96    G. Melton                   Changed to retrieve from the     **
**                                        Imputed Flight Leg Table items   **
**                                        older than one year and move to  **
**                                        the Pass History Table.          **
**                                        Also added a count of rows       **
**                                        archived and corresponding       **
**                                        message to log.                  **
** 12/23/08   Gay Whitman                 Change to older than 3 years     **
**                                                                         **
**                                                                         **
****************************************************************************/


#include "epb60002.h"
#include "epbcmncd.h"

main()
{
   BCH_Init("EPB60002", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{

   /**** Report variables not needed ****/
 
   /****** Format R02791 keys for initial db read *****/
   memset(&RS.sPprNbr, LOW_VALUES, sizeof(RS.sPprNbr));
   memset(&RS.sNrevNbr, LOW_VALUES, sizeof(RS.sNrevNbr));
   memset(&RS.sFltNbr, LOW_VALUES, sizeof(RS.sFltNbr));
   memset(&RS.sFltDprtDt, LOW_VALUES, sizeof(RS.sFltDprtDt));
   memset(&RS.sTktNbr, LOW_VALUES, sizeof(RS.sTktNbr));

   /**** Initialize key in RSAM saved area to space ****/
   strcpy(RS.sPprNbr, " ");
   strcpy(RS.sNrevNbr, " ");
   strcpy(RS.sFltNbr, " ");
   strcpy(RS.sFltDprtDt, " ");
   strcpy(RS.sTktNbr, " ");
 
   /**** Initialize applitecture area of service answer and request blocks ****/    
   memset(&A02872, LOW_VALUES, sizeof(_A02872)); 
   memset(&R02872, LOW_VALUES, sizeof(_R02872)); 
   memset(&A04118, LOW_VALUES, sizeof(_A04118));
   memset(&R04118, LOW_VALUES, sizeof(_R04118));
 
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   /**************************************************/
   /** set up today's date in CCYYMMDD format       **/
   /**************************************************/
   memset(&RS.sTodayDt, LOW_VALUES,     sizeof(RS.sTodayDt));
   strncpy(RS.sTodayDt, sCurrentTsDt,   sizeof(RS.sTodayDt));
   UTL_ZeroDatesTime(RS.sTodayDt);

   /*** Calculate the date one year ago today ***/
   strcpy(R04118.R04118_appl_area.sPassRptSortDt, RS.sTodayDt);
   /******************   change date parm for years to archive ****************/
   R04118.R04118_appl_area.nFltArrTm = -3*365;
   DPM_2100_ConvertDate();

   sprintf(sErrorMessage, "Processing Date: %s", A04118.A04118_appl_area.sFltDprtDt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{
    DPM_2500_ProcessRows();

    DPM_4920_ProcessLUW();

    DPM_9500_ProcessEndOfProgram();

    BCH_Terminate();

    exit(0);
}


 
/******************************************************************
**                                                               **
** Function Name:   DPM_2100_ConvertDate                         **
**                                                               **
** Description:     This function calls the service to add 30    **
**                  days to today's date and return.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   sFltDprtDt                                   **
**                                                               **
**                                                               **
******************************************************************/

int     DPM_2100_ConvertDate()
{
   short   nSvcRtnCd;   /* Service return code */

   /***************************************************/
   /** Call service to add xx days to the given date **/
   /***************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04118,&A04118,SERVICE_ID_04118,1,sizeof(_R04118_APPL_AREA));

   /** Service Return Code Processing **/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04118");
         sprintf(sErrorMessage, "Date: %s", R04118.R04118_appl_area.sPassRptSortDt);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2100_ConvertDate");
      }  
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessRows()
{
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_4920_ProcessLUW()
{
    short     nSvcRtnCd;      /* Service return code */

    /**** Initialize service request and answer blocks ****/
    memset(&R02872, LOW_VALUES, sizeof(_R02872));
    memset(&A02872, LOW_VALUES, sizeof(_A02872));

    /**** Format service request block ****/
    strcpy(R02872.R02872_appl_area.sFltDprtDt, A04118.A04118_appl_area.sFltDprtDt);

    /**** Execute service to perform delete from Imputed Flight Legs Table where departure date > 1 year old ****/
    nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02872,&A02872,SERVICE_ID_02872,1,sizeof(_R02872));   

    /**** Service return code processing ****/
    switch (nSvcRtnCd)
    {
        case ARC_SUCCESS:
            break;

        default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02872");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_9500_ProcessEndOfProgram");
    }  

    /** Write Messages to Log **/
    BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "Rows Archived");
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

    BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{
}
