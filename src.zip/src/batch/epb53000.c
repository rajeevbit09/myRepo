/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB53000.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Faith Ammons                                           **
**                                                                         **
** Date Written:    07/03/96                                               **
**                                                                         **
** Description:     This module reads the T_suspense table and writes all  **
**                  of the items to a file that looks like the interface   **
**                  from Deltamatic so that corrected suspended items may  **
**                  be processed.  All of the items are deleted from the   **
**                  table once processing completes.                       **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/
#include "epb53000.h"

main()
{
   BCH_Init("EPB53000", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   /**** Initialize counters & accumulators ****/
   RS.EPBF010_record_cntr = 0;
   RS.nSuspCnt  = 0;
   strcpy(RS.sPprNbr, "         ");

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_WRITE);

   if (RS.EPBF010 == BCH_FAIL)
   {
      BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
      BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF010");
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */

   /***** Initialize Request and Answer Blocks *****/
   memset(&R04399.R04399_appl_area, LOW_VALUES, sizeof(R04399.R04399_appl_area));
   memset(&A04399.A04399_appl_area, LOW_VALUES, sizeof(A04399.A04399_appl_area));
   R04399.R04399_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   strcpy(R04399.R04399_appl_area.sPprNbr,RS.sPprNbr);

   /***** Execute service to retrieve all items from t_suspense table ***/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04399,&A04399,SERVICE_ID_04399,1,sizeof(R04399.R04399_appl_area));
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         strcpy(RS.sPprNbr, A04399.A04399_appl_area.sPprNbr);
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04399");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process each item from t_suspense ***/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      /*** Process the row that was retreived ***/
      DPM_2500_ProcessRows();
      RS.nSuspCnt++;

      /** get the next t_suspense row ***/
      R04399.R04399_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04399.A04399_appl_area, LOW_VALUES, sizeof(A04399.A04399_appl_area));
         
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04399,&A04399,SERVICE_ID_04399,1,sizeof(R04399.R04399_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04399");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
       }  

       /*** if the ppr number changes, commit ***/
       if (strcmp(A04399.A04399_appl_area.sPprNbr, RS.sPprNbr) != 0)
       {
          strcpy(RS.sPprNbr, A04399.A04399_appl_area.sPprNbr);
       }
   }

   /*** Send message to error log to show T_suspense items processed ***/
   sprintf(sErrorMessage, "Completed processing %d t_suspense rows.", RS.nSuspCnt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");

   /*** Finally, delete items from t_suspense if any were processed ***/
   if (RS.nSuspCnt > 0)
   {
      /*** Send message to error log to show HR client  delete beginning ***/
      sprintf(sErrorMessage, "Deleting  %d t_suspense rows.", RS.nSuspCnt);
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");

      memset(&A04402, LOW_VALUES, sizeof(&A04402));
      
      nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04402,&A04402,SERVICE_ID_04402,1,sizeof(&R04402));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04402");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   char sDprtTm[5];
   char sArrvTm[5];

   /**  Initialize output file record and buffer **/
   memset(&RS.EPBF010_buffer, LOW_VALUES, sizeof(RS.EPBF010_buffer));
   memset(&sDprtTm, LOW_VALUES, sizeof(sDprtTm));
   memset(&sArrvTm, LOW_VALUES, sizeof(sArrvTm));

   /*** Convert the integer departure and arrival time to char ***/
   sprintf(sDprtTm, "%04d", A04399.A04399_appl_area.nFltDprtTm);
   sprintf(sArrvTm, "%04d", A04399.A04399_appl_area.nFltArrTm);
  
   /*** format the record to be written ***/
   sprintf(RS.EPBF010_buffer, INTF_FORMAT,
           "000",                 
           A04399.A04399_appl_area.sPprNbr,
           A04399.A04399_appl_area.sNrevNbr,
           A04399.A04399_appl_area.sFltNbr,
           UTL_ConvertDate(A04399.A04399_appl_area.sFltDprtDt, CNV_DB_TO_YYYYMMDD),
           UTL_ConvertDate(A04399.A04399_appl_area.sFltArrDt, CNV_DB_TO_YYYYMMDD),
           A04399.A04399_appl_area.sFltOrigCtyId,
           A04399.A04399_appl_area.sFltDestCtyId,
           sDprtTm,
           sArrvTm,
           A04399.A04399_appl_area.sFltClsSvcId, 
           A04399.A04399_appl_area.sPassBrdPriId);

   /*** Write formatted record out to the output file ***/
   BCH_WriteRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   RS.EPBF010_record_cntr++;
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   BCH_Close(RS.EPBF010);

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF010");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF010_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
