/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB60001.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Written:    April 28, 1995                                         **
**                                                                         **
** Description:     Database driven programs use, as their primary input,  **
**                  a Sybase database.  The database is scanned and        **
**                  updated and/or transactions are generated for          **
**                  subsequent processing steps.  This module retrieves    **
**                  searches the Flight Leg table for items older than     **
**                  six months and moves them to the Pass History Table.   **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 8/15/96    G. Melton                   Changed to retrieve from the     **
**                                        Flight Leg Table items older     **
**                                        than one year and move them to   **
**                                        the Pass History Table.          **
**                                        Also added a count of rows       **
**                                        archived and corresponding       **
**                                        message to log.                  **
** 7/29/96    RTG                         Conversion to Oracle involving   **
**                                        removal of loop, replaced with   **
**                                        single stored procedure.         **
**                                                                         **
****************************************************************************/


#include "epb60001i.h"
#include "epbcmncd.h"

main()
{
   BCH_Init("EPB60001", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{

   /**** Report variables not needed ****/
 
   /**** Set key of primary database record, Flight Legs, in RSAM saved area to nulls ****/
   memset(&RS.sPprNbr, LOW_VALUES, sizeof(RS.sPprNbr));
   memset(&RS.sNrevNbr, LOW_VALUES, sizeof(RS.sNrevNbr));
   memset(&RS.sFltOrigCtyId, LOW_VALUES, sizeof(RS.sFltOrigCtyId));
   memset(&RS.sFltNbr, LOW_VALUES, sizeof(RS.sFltNbr));
   memset(&RS.sFltDprtDt, LOW_VALUES, sizeof(RS.sFltDprtDt));

   /**** Initialize key in RSAM saved area to space ****/
   strcpy(RS.sPprNbr, " ");
   strcpy(RS.sNrevNbr, " ");
   strcpy(RS.sFltOrigCtyId, " ");
   strcpy(RS.sFltNbr, " ");
   strcpy(RS.sFltDprtDt, " ");
 
   /**** Initialize counters & accumulators ****/
   RS.rows_archived_cntr = 0;

   /**** Initialize flag for all rows processed ****/
   RS.nProcessedAllRows = FALSE;

   /**** Initialize architecture area of service answer and request blocks ****/
   memset(&A02871, LOW_VALUES, sizeof(_A02871));
   memset(&R02871, LOW_VALUES, sizeof(_R02871));
   memset(&A04118, LOW_VALUES, sizeof(_A04118));
   memset(&R04118, LOW_VALUES, sizeof(_R04118));


   /**** Build thread table ***/

   /************** call RSAM to start program ****************/

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");


   /**************************************************/
   /** set up today's date in common format         **/
   /**************************************************/
   memset(&RS.sTodayDt, LOW_VALUES, sizeof(RS.sTodayDt));
   strncpy(RS.sTodayDt, sCurrentTsDt, sizeof(RS.sTodayDt));
   UTL_ZeroDatesTime(RS.sTodayDt);

   /*** Calculate the date one year ago today ***/
   strcpy(R04118.R04118_appl_area.sPassRptSortDt, RS.sTodayDt);
   /***********  change date parm for number of years to archive ********/
   R04118.R04118_appl_area.nFltArrTm = -9*365;
   DPM_2100_ConvertDate();

   sprintf(sErrorMessage, "Processing Date: %s", A04118.A04118_appl_area.sFltDprtDt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
 

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_2000_Mainline()
{
   DPM_2500_ProcessRows();

   DPM_4920_ProcessLUW();
      
   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2100_ConvertDate                         **
**                                                               **
** Description:     This function calls the service to add xx    **
**                  days to today's date and return.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   sFltDprtDt                                   **
**                                                               **
**                                                               **
******************************************************************/

int     DPM_2100_ConvertDate()
{
   short   nSvcRtnCd;   /* Service return code */


   /***************************************************/
   /** Call service to add xx days to the given date **/
   /***************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04118,&A04118,SERVICE_ID_04118,1,sizeof(_R04118_APPL_AREA));

   /** Service Return Code Processing **/
   switch (nSvcRtnCd)   
      {  
      case ARC_SUCCESS:  
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04118");
         sprintf(sErrorMessage, "Date: %s", R04118.R04118_appl_area.sPassRptSortDt);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2100_ConvertDate");
      } 
 
}
 

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessRows()
{
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_4920_ProcessLUW()
{
    short nSvcRtnCd;

    memset(&R02871, LOW_VALUES, sizeof(_R02871));
    memset(&A02871, LOW_VALUES, sizeof(_A02871));

   /**** format request block with specifics ****/
    strcpy(R02871.R02871_appl_area.sFltDprtDt, A04118.A04118_appl_area.sFltDprtDt);

   /**** Execute service to perform delete from Flight Legs Table where departure date > 1 year old ****/
    nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02871,&A02871,SERVICE_ID_02871,1,sizeof(_R02871));   

   /**** Service return code processing ****/
    switch (nSvcRtnCd)
    {
        case ARC_SUCCESS:
            break;

        default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02871");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4920_ProcessLUW");

    }  

   /*** write messages to log ***/
    BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "Rows Archived");
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_4920_ProcessLUW");

    BCH_FormatMessage(2,TXT_PROC_SUCC_COMPL);
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_4920_ProcessLUW");
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{
}
