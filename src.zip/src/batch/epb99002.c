/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB99002.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Delta Technologies                                     **
**                  LaShawnda Walker                                       **
**                                                                         **
** Date Written:    06/18/99                                               **
**                                                                         **
** Description:     This process will write a record out for each manually **
**                  revoked or suspended rider found in the t_cmnt table   **
**                  for the current process month.                         **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
****************************************************************************/
#include "epb99002.h"

main()
{
  BCH_Init("EPB99002", NUMBER_OF_THREADS);
  
  DPM_1000_Initialize();

  DPM_2000_Mainline();

  BCH_Terminate();

  exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short   nRptIndex,                 /** Report index **/
           nReqRptInd1 = FALSE;       /** Required report #1 indicator **/

   char   *pBegDate,                  /** Pointers to reporting dates **/
          *pEndDate;

   /**** Assign pointers for report beginning and ending dates ****/
   pBegDate = (char *) getenv("DATE1");
   pEndDate = (char *) getenv("DATE2");
   strcpy(RS.sBegDt, pBegDate);
   strcpy(RS.sEndDt, pEndDate);

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   /**** set up today's date ****/
   strcpy(RS.sTodayDt, sCurrentTsDt);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Process all ppr_nbr's that have been manually**
**                  revoked or suspended for the current process **
**                  month.                                       **
**                                                               **
** Arguments:       None.                                        **
**                                                               **
** Return Values:   None.                                        **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   int nMonth=0,
       nYear=0,
       nProcessMth=0,
       nProcessYr=0,
       nSvcRtnCd,
       nRecCnt=0;

   short nRptIndex;     /** Index into the report control table **/

   char sYear[5],
        sMonth[3];

   memset(sYear,'\0',sizeof(sYear));
   memset(sMonth,'\0',sizeof(sMonth));

   strncpy(sYear,RS.sTodayDt+DB_TS_POS_YEAR,4);
   strncpy(sMonth,RS.sTodayDt+DB_TS_POS_MON,2);

   nYear = atoi(sYear);
   nMonth = atoi(sMonth);

   if ( nMonth == 1 )
   {
      nProcessMth = 12;
      nProcessYr = (nYear - 1);
   } 
   else 
   {
      nProcessMth = (nMonth - 1);
      nProcessYr = nYear;
   }

   /*** Select each companion add entry from the t_cmnt table ***/
   /*** for the current month ***/
   memset(&R04702.R04702_appl_area,LOW_VALUES,sizeof(R04702.R04702_appl_area));
   memset(&A04702,LOW_VALUES,sizeof(A04702));
   R04702.R04702_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   R04702.R04702_appl_area.nFltArrTm = nProcessMth;
   R04702.R04702_appl_area.nFltDprtTm = nProcessYr;
   
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04702,&A04702,SERVICE_ID_04702,1,sizeof(R04702));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         memset(&EPRF9902.F9902_RptDataStruct, LOW_VALUES, sizeof(_F9902_RPTDATASTRUCT));
         memset(&EPRS9902.S9902_RptDataStruct, LOW_VALUES, sizeof(_S9902_RPTDATASTRUCT));
         strcpy(EPRS9902.S9902_RptDataStruct.sPprNbr,A04702.A04702_appl_area.sPprNbr);
         strcpy(EPRS9902.S9902_RptDataStruct.sNrevNbr,A04702.A04702_appl_area.sNrevNbr);
         strcpy(EPRS9902.S9902_RptDataStruct.sPassDtTmTs,
                UTL_ConvertDate(A04702.A04702_appl_area.sPassStsChgDt,CNV_DB_TO_DD_MMM_YYYY));
         strcpy(EPRS9902.S9902_RptDataStruct.sPassStsCd,A04702.A04702_appl_area.sPassStsCd);
         ++nRecCnt;
         strcpy(EPRF9902.F9902_RptDataStruct.sPprNbr,A04702.A04702_appl_area.sPprNbr);
         strcpy(EPRF9902.F9902_RptDataStruct.sNrevNbr,A04702.A04702_appl_area.sNrevNbr);
         strcpy(EPRF9902.F9902_RptDataStruct.sPassStsChgDt,
                UTL_ConvertDate(A04702.A04702_appl_area.sPassStsChgDt,CNV_DB_TO_DD_MMM_YYYY));
         strcpy(EPRF9902.F9902_RptDataStruct.sArchLastUpdtId,A04702.A04702_appl_area.sArchLastUpdtId);
         strncpy(EPRF9902.F9902_RptDataStruct.sNrevCmntTxt,A04702.A04702_appl_area.sNrevCmntTxt,50);
         strcpy(EPRF9902.F9902_RptDataStruct.sPassSusExpDt,
                UTL_ConvertDate(A04702.A04702_appl_area.sPassSusExpDt,CNV_DB_TO_DD_MMM_YYYY));
         strcpy(EPRF9902.F9902_RptDataStruct.sPassStsCd,A04702.A04702_appl_area.sPassStsCd);
         EPRF9902.F9902_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

         BCH_WriteRptRec("EPB99012",&EPRS9902, sizeof(EPRS9902), &EPRF9902, sizeof(EPRF9902));

         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04702");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      R04702.R04702_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04702,LOW_VALUES,sizeof(A04702));
      memset(&EPRF9902.F9902_RptDataStruct, LOW_VALUES, sizeof(_F9902_RPTDATASTRUCT));
      memset(&EPRS9902.S9902_RptDataStruct, LOW_VALUES, sizeof(_S9902_RPTDATASTRUCT));
    
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04702,&A04702,SERVICE_ID_04702,1,sizeof(R04702));
 
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            strcpy(EPRS9902.S9902_RptDataStruct.sPprNbr,A04702.A04702_appl_area.sPprNbr);
            strcpy(EPRS9902.S9902_RptDataStruct.sNrevNbr,A04702.A04702_appl_area.sNrevNbr);
            strcpy(EPRS9902.S9902_RptDataStruct.sPassDtTmTs,
                   UTL_ConvertDate(A04702.A04702_appl_area.sPassStsChgDt,CNV_DB_TO_DD_MMM_YYYY));
            strcpy(EPRS9902.S9902_RptDataStruct.sPassStsCd,A04702.A04702_appl_area.sPassStsCd);
            ++nRecCnt;
            strcpy(EPRF9902.F9902_RptDataStruct.sPprNbr,A04702.A04702_appl_area.sPprNbr);
            strcpy(EPRF9902.F9902_RptDataStruct.sNrevNbr,A04702.A04702_appl_area.sNrevNbr);
            strcpy(EPRF9902.F9902_RptDataStruct.sPassStsChgDt,
                   UTL_ConvertDate(A04702.A04702_appl_area.sPassStsChgDt,CNV_DB_TO_DD_MMM_YYYY));
            strcpy(EPRF9902.F9902_RptDataStruct.sArchLastUpdtId,A04702.A04702_appl_area.sArchLastUpdtId);
            strncpy(EPRF9902.F9902_RptDataStruct.sNrevCmntTxt,A04702.A04702_appl_area.sNrevCmntTxt,50);
            strcpy(EPRF9902.F9902_RptDataStruct.sPassSusExpDt,
                   UTL_ConvertDate(A04702.A04702_appl_area.sPassSusExpDt,CNV_DB_TO_DD_MMM_YYYY));
            strcpy(EPRF9902.F9902_RptDataStruct.sPassStsCd,A04702.A04702_appl_area.sPassStsCd);
            EPRF9902.F9902_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

            BCH_WriteRptRec("EPB99012",&EPRS9902, sizeof(EPRS9902), &EPRF9902, sizeof(EPRF9902)); 

            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04702");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }
   }

   BCH_FormatMessage(1,TXT_OUT_FILE, "PRAF010");
   BCH_FormatMessage(2,TXT_REC_TTL, nRecCnt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");
}
