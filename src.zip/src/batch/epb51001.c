/*######################################################################*/
/*                                                                      */
/* Copyright [2001] Delta Air Lines, Inc./Delta Technology, Inc.   */
/*                       All Rights Reserved                            */
/*               Access, Modification, or Use Prohibited                */
/* Without Express Permission of Delta Air Lines or Delta Technology.   */
/*                                                                      */
/*######################################################################*/
/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB51001.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Written:    December 10, 1995                                      **
**                                                                         **
** Description:     This module is responsible for performing the          **
**                  following tasks for non-revenue passengers on the      **
**                  anniversary day of the PPR:  updating months of        **
**                  service for PPRs, updating the current days/miles      **
**                  indicator with next year's days/miles indicator,       **
**                  updating the imputed indicator, resetting prior        **
**                  period remaining allotments, resetting pass            **
**                  allotments, assessing a pass card charge for all       **
**                  voluntary severence non-revenue passengers, and        **
**                  revoking pass privileges when appropriate.             **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 03/18/96   JBowser                     1. Use true cursor svcs 4309,    **
**                                           4340, 4341.                   **
**                                        2. Added logic to insert into    **
**                                           Deltamatic table.             **
**                                        3. Added logic to insert Pass    **
**                                           Card charge into Charges      **
**                                           table for all VS non-revs.    **
**                                        4. Added logic for processing    **
**                                           of specific pass groups.      **
**                                                                         **
** 04/11/96   JBowser                     Modified so that only VS PPRs    **
**                                        are charged pass card fees.      **
**                                        Modified initialization of       **
**                                        arch and appl areas on fetch     **
**                                        next row and on restart.         **
** 05/17/96   FFA                         Dont update indicators if revoked**
**                                                                         **
** 06/11/96   FFA                         Added proc msgs and counts.      **
** 06/27/96   FFA                         Added new service to calculate the*
**                                        anniversary date and removed      **
**                                        datediff processing from 4340&4341*
** 07/02/96   FFA                         Removed datepart processing from **
**                                        service 4341.                    **
**                                                                         **
** 07/17/96   FFA                         Added new svc 4341 processing. In**
**                                        order to fix timeout problem, it **
**                                        was necessary to add start month **
**                                        and start day to t_ppr. svc 4341 **
**                                        was changed to select by these new*
**                                        fields, so this module must pass **
**                                        the start month and day separately*
**                                                                         **
**                                        In addition, remove the excessive**
**                                        restart processing.              **
**                                                                         **
** 07/29/96   FFA                         Added service 2561 to write to   **
**                                        Audit Trail table when a person  **
**                                        is revoked.                      **
**                                                                         **
** 08/01/96   FFA                         Set new indicator on t_nrev_psgr **
**                                        to 'Y' when a psgr is revoked.   **
**                                                                         **
** 10/25/96   FFA                         do no exclude the 3 ready reserve**
**                                        groups from normal anniversary   **
**                                        processing.                      **
**                                                                         **
** 08/04/98   SKM                         When resetting allotment, do not **
**                                        create allotments for pass types **
**                                        '70' and '80'. These pass types  **
**                                        are used for Above & Beyond and  **
**                                        Friends & Family certificate     **
**                                        respectively and we do not have  **
**                                        allotments for them.             **
**                                                                         **
** 02/12/01   LSW                         Changes for the S1R reward.      **
**                                                                         **
** 07/25/01   LAS                         When resetting allotments do not **
**                                        remove the S1Rs when the remain- **
**                                        ing days reaches zero.  Let the  **
**                                        process remove them when the     **
**                                        anniversary date rolls around    **
**                                        in 2003 or if a pass group change**
**                                        occurs that doesn't have S1Rs.   **
**
** 10/04/01   LAS                         Added check for "VR" Voluntary   **
**                                        Severance DL Recovery, wherever  **
**                                        "VS" was referenced.             **
**                                                                         **
** 12/18/01   LAS                         Pass card charges for Voluntary  **
**                                        serverance "VS" and "VR" are no  **
**                                        longer valid.  Comment out code. **
**                                                                         **
** 08/21/02   LAS                         Remove code where the intertax   **
**                                        is checked to determine if the   **
**                                        imputed indicator should be set  **
**                                        to "Y" if intertax number exist. **
**                                                                         **
** 08/10/11   LAS                         Added a check to exlude one month**
**                                        anniversaries when resetting     **
**                                        activation fees.                 **
**                                                                         **
** 05/11/12   MLH                         Commented code that resets       **
**                                        imputed indicator                **
**                                                                         **
****************************************************************************/

#include "epb51001.h"


main()
{
   BCH_Init("EPB51001", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}


void writetolog(char x[], char y)
{
   FILE *fp = fopen("GWlog.txt","a");
   fprintf(fp,"%s%c\n",x,y);
   fclose(fp);
}


void writetologX(char x[], char y[])
{
   FILE *fp = fopen("GWlog.txt","a");
   fprintf(fp,"%s%s\n",x,y);
   fclose(fp);
}


/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{
   char   *pEffDt;                /* Pointer to effective date */

   /**** Assign effective date to variable ****/
   pEffDt = (char *) getenv("DATE1");
   strcpy(RS.sEffDt, pEffDt);
   RS.tmDate = UTL_GetTmFromDate(RS.sEffDt);

   /**** Initialize global variables ****/
   nEndOfMoData = FALSE;
   nEndOfYrData = FALSE;
   nOldAllotInd = FALSE;
   nNewAllotInd = FALSE;
   nPriorRemnAllotInd = FALSE;
   nRvkInd = FALSE;
   nRewardInd = FALSE;
   nRemoveRewardInd = FALSE;
   RS.nOneMonthPprCnt = 0;
   RS.nOneMonthNrevCnt = 0;
   RS.nYrPprCnt = 0;
   RS.nYrNrevCnt = 0;
   RS.nMoProc = TRUE;
   strcpy(RS.sPprNbr, SPACE_CHAR);

   /****** Initialize working storage block *****/
   memset(&WS, LOW_VALUES, sizeof(WS));

   /**** Initialize architecture area of service answer and request blocks ****/
   memset(&A02441, LOW_VALUES, sizeof(_A02441));
   memset(&R02441, LOW_VALUES, sizeof(_R02441));
   memset(&A02443, LOW_VALUES, sizeof(_A02443));
   memset(&R02443, LOW_VALUES, sizeof(_R02443));
   memset(&A02444, LOW_VALUES, sizeof(_A02444));
   memset(&R02444, LOW_VALUES, sizeof(_R02444));
   memset(&A02445, LOW_VALUES, sizeof(_A02445));
   memset(&R02445, LOW_VALUES, sizeof(_R02445));
   memset(&A02475, LOW_VALUES, sizeof(_A02475));
   memset(&R02475, LOW_VALUES, sizeof(_R02475));
   memset(&A02483, LOW_VALUES, sizeof(_A02483));
   memset(&R02483, LOW_VALUES, sizeof(_R02483));
   memset(&A02526, LOW_VALUES, sizeof(_A02526));
   memset(&R02526, LOW_VALUES, sizeof(_R02526));
   memset(&A02529, LOW_VALUES, sizeof(_A02529));
   memset(&R02529, LOW_VALUES, sizeof(_R02529));
   memset(&A02662, LOW_VALUES, sizeof(_A02662));
   memset(&R02662, LOW_VALUES, sizeof(_R02662));
   memset(&A02714, LOW_VALUES, sizeof(_A02714));
   memset(&R02714, LOW_VALUES, sizeof(_R02714));
   memset(&A02760, LOW_VALUES, sizeof(_A02760));
   memset(&R02760, LOW_VALUES, sizeof(_R02760));
   memset(&A02762, LOW_VALUES, sizeof(_A02762));
   memset(&R02762, LOW_VALUES, sizeof(_R02762));
   memset(&A02763, LOW_VALUES, sizeof(_A02763));
   memset(&R02763, LOW_VALUES, sizeof(_R02763));
   memset(&A02764, LOW_VALUES, sizeof(_A02764));
   memset(&R02764, LOW_VALUES, sizeof(_R02764));
   memset(&A03270, LOW_VALUES, sizeof(_A03270));
   memset(&R03270, LOW_VALUES, sizeof(_R03270));
   memset(&A04000, LOW_VALUES, sizeof(_A04000));
   memset(&R04000, LOW_VALUES, sizeof(_R04000));
   memset(&A04003, LOW_VALUES, sizeof(_A04003));
   memset(&R04003, LOW_VALUES, sizeof(_R04003));
   memset(&A04119, LOW_VALUES, sizeof(_A04119));
   memset(&R04119, LOW_VALUES, sizeof(_R04119));
   memset(&A04309, LOW_VALUES, sizeof(_A04309));
   memset(&R04309, LOW_VALUES, sizeof(_R04309));
   memset(&A04323, LOW_VALUES, sizeof(_A04323));
   memset(&R04323, LOW_VALUES, sizeof(_R04323));
   memset(&A04325, LOW_VALUES, sizeof(_A04325));
   memset(&R04325, LOW_VALUES, sizeof(_R04325));
   memset(&A04326, LOW_VALUES, sizeof(_A04326));
   memset(&R04326, LOW_VALUES, sizeof(_R04326));
   memset(&A04340, LOW_VALUES, sizeof(_A04340));
   memset(&R04340, LOW_VALUES, sizeof(_R04340));
   memset(&A04341, LOW_VALUES, sizeof(_A04341));
   memset(&R04341, LOW_VALUES, sizeof(_R04341));

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{
   short nDay2;

   /****** First, calculate monthly and yearly anniversary date to be used in processing ***/
   DPM_2100_CalculateStartDate();

   /**** Perform one month processing if it hasnt already been done ****/
   if (RS.nMoProc == TRUE)
      {
      /**************************************/
      /**   Perform one month processing   **/
      /**************************************/

      /**** Set number of days for one month processing ****/
      cProcInd = 'M';

      /**** send message to message log showing one month anniversary processing  ***/
      sprintf(sErrorMessage, "Beginning one month anniversary processing: ");
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
      sprintf(sErrorMessage, "Effective date %s, Start date %s ",
                              RS.sEffDt, A04403.A04403_appl_area.sPprStrtDt);
      BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");

      /****** Initialize working storage block *****/
      memset(&WS, LOW_VALUES, sizeof(WS));

      /****** Initialize Request and Answer Blocks *****/
      memset(&R04340.R04340_appl_area, LOW_VALUES, sizeof(_R04340_APPL_AREA));
      memset(&A04340.A04340_appl_area, LOW_VALUES, sizeof(_A04340_APPL_AREA));

      /**** Format Service Request Copybook for opening the initial DB cursor ****/
      strcpy(R04340.R04340_appl_area.sFltFeeBegDt, A04403.A04403_appl_area.sPprStrtDt);
      strcpy(R04340.R04340_appl_area.sPprNbr, RS.sPprNbr);

      /**** Open the initial DB cursor ****/
      R04340.R04340_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

      /****** Execute service to select records from PPR table where the start date is 29 days before
              the effective date ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04340,&A04340,SERVICE_ID_04340,1,sizeof(_R04340_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            /**** Move values to working storage ****/
            strcpy(WS.sPprNbr, A04340.A04340_appl_area.sPprNbr);
            strcpy(WS.sPassGrpCd, A04340.A04340_appl_area.sPassGrpCd);
            WS.nFltMoSvcNbr = A04340.A04340_appl_area.nFltMoSvcNbr;
            strcpy(WS.sPprRvkDt, A04340.A04340_appl_area.sPprRvkDt);
            strcpy(WS.sPprStrtDt, A04340.A04340_appl_area.sPprStrtDt);

            // Strip any trailing space, so an empty tax Number is NULL
            UTL_StripTrailingSpaces(A04340.A04340_appl_area.sPprInttxNbr);
            strcpy(WS.sPprInttxNbr, A04340.A04340_appl_area.sPprInttxNbr);

            strcpy(WS.sPprRsdncyStsCd, A04340.A04340_appl_area.sPprRsdncyStsCd);
            break;

         case ARC_ROW_NOT_FOUND:
            nEndOfMoData = TRUE;
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_FormatMessage(2,TXT_SVC, "FYS04340");
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT,"No one month processing performed");
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS04340");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
         }

      DPM_2500_ProcessRows();

      /*** after processing all of the rows with a one month anniversary, send a message to ***/
      /*** the log and then commit the changes                                              ***/
      sprintf(sErrorMessage, "End of one month anniversary processing.");
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");
      RS.nMoProc = FALSE;
      strcpy(RS.sPprNbr, SPACE_CHAR);
   }   /*** end of one month processing ***/


   /****************************************/
   /**   Perform anniversary processing   **/
   /****************************************/

   /**** Initialize R04341 key in RSAM area with space ****/
   cProcInd = 'Y';

   /****** Initialize working storage block *****/
   memset(&WS, LOW_VALUES, sizeof(WS));

   /**** Dont perform anniversary processing if the effective date is Feb 29 ****/
   if ((2 == RS.tmDate.tm_mon) && (29 == RS.tmDate.tm_mday))
      {
      sprintf(sErrorMessage, "No yearly anniversary processing on Feb 29");
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");
      }
   /**** Perform anniversary processing if the effective date is not Feb 29 ****/
   else
      {
      /**** If the effective date if Feb 28, assign the 2nd search day to be 29
            otherwise, assign the 2nd search day to effective day    ****/
      if ((2 == RS.tmDate.tm_mon) && (28 == RS.tmDate.tm_mday))
         nDay2 = 29;
      else
         nDay2 = RS.tmDate.tm_mday;

      /**** send message to message log showing yearly anniversary processing  ***/
      sprintf(sErrorMessage, "Beginning yearly anniversary processing for effective date %s ", RS.sEffDt);
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");

      memset(&R04341.R04341_appl_area, LOW_VALUES, sizeof(_R04341_APPL_AREA));
      memset(&A04341.A04341_appl_area, LOW_VALUES, sizeof(_A04341_APPL_AREA));
      R04341.R04341_appl_area.uPprStrtMo = RS.tmDate.tm_mon;
      R04341.R04341_appl_area.uPprStrtDy = RS.tmDate.tm_mday;
      R04341.R04341_appl_area.uPprStrtDy2 = nDay2;
      strcpy(R04341.R04341_appl_area.sPprNbr, RS.sPprNbr);
      R04341.R04341_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

      /****** Execute service to select record from PPR table where start day and month equal the
              effective day and month ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R04341,&A04341,SERVICE_ID_04341,1,sizeof(_R04341_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            /**** Move values to working storage ****/
            strcpy(WS.sPprNbr, A04341.A04341_appl_area.sPprNbr);
            strcpy(WS.sPassGrpCd, A04341.A04341_appl_area.sPassGrpCd);
            WS.nFltMoSvcNbr = A04341.A04341_appl_area.nFltMoSvcNbr;
            strcpy(WS.sPprRvkDt, A04341.A04341_appl_area.sPprRvkDt);
            strcpy(WS.sPprStrtDt, A04341.A04341_appl_area.sPprStrtDt);

            // Strip any trailing space, so an empty tax Number is NULL
            UTL_StripTrailingSpaces(A04341.A04341_appl_area.sPprInttxNbr);
            strcpy(WS.sPprInttxNbr, A04341.A04341_appl_area.sPprInttxNbr);

            strcpy(WS.sPprRsdncyStsCd, A04341.A04341_appl_area.sPprRsdncyStsCd);

            break;

         case ARC_ROW_NOT_FOUND:
               nEndOfYrData = TRUE;
               BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
               BCH_FormatMessage(2,TXT_SVC, "FYS04341");
               BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT,"No anniversary processing performed");
               BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
               break;

         default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC,"FYS04341");
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
         }

      DPM_2500_ProcessRows();

      sprintf(sErrorMessage, "End of yearly anniversary processing.");
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");
      }   /*** end of yearly anniversary processing ***/


   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2100_CalculateStartDate                  **
**                                                               **
** Description:     Calculate the monthly start date to be       **
**                  used in processing.                          **
**                                                               **
** Arguments:       none                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2100_CalculateStartDate()
{
   short nNbrOfDays;


   nNbrOfDays = -29;

   memset(&R04403.R04403_appl_area, LOW_VALUES, sizeof(_R04403_APPL_AREA));
   memset(&A04403.A04403_appl_area, LOW_VALUES, sizeof(_A04403_APPL_AREA));
   strcpy(R04403.R04403_appl_area.sFltFeeBegDt, RS.sEffDt);
   R04403.R04403_appl_area.nPassSeqNbr = nNbrOfDays;

   /****** Execute service to subtract the number of days from the input date to  ****/
   /****** get the start date to be used in processing                            ***/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04403,&A04403,SERVICE_ID_04403,1,sizeof(_R04403_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04403");
         sprintf(sErrorMessage, "Error calculating start date for number of days = %d", nNbrOfDays);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2100_CalculateStartDate");
      }

}
/******************************************************************
**                                                               **
** Function Name:   DPM_2200_ObtainNextDBRow                     **
**                                                               **
** Description:     Obtain the next database row.                **
**                                                               **
** Arguments:       Service number                               **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2200_ObtainNextDBRow(short nSvcNbr)
{

   /****** Open cursor and execute service to retrieve next row of data ****/
   if (nSvcNbr == 4340)
      {
      R04340.R04340_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04340.A04340_appl_area, LOW_VALUES, sizeof(_A04340_APPL_AREA));

      /****** Execute service to select records from PPR table where the start date is 29 days before
              the effective date ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04340,&A04340,SERVICE_ID_04340,1,sizeof(_R04340_APPL_AREA));
      }
   else if (nSvcNbr == 4341)
      {
      R04341.R04341_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04341.A04341_appl_area, LOW_VALUES, sizeof(_A04341_APPL_AREA));

      /****** Execute service to select record from PPR table where start day and month equal the
              effective day and month ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R04341,&A04341,SERVICE_ID_04341,1,sizeof(_R04341_APPL_AREA));
      }
   else if (nSvcNbr == 4309)
      {
      R04309.R04309_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04309.A04309_appl_area, LOW_VALUES, sizeof(_A04309_APPL_AREA));

      /****** Execute service to select records from the Non-revenue Passenger table ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04309,&A04309,SERVICE_ID_04309,1,sizeof(_R04309_APPL_AREA));
      }

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         if (nSvcNbr == 4340)
            {
            /**** Move values to working storage ****/
            strcpy(WS.sPprNbr, A04340.A04340_appl_area.sPprNbr);
            strcpy(WS.sPassGrpCd, A04340.A04340_appl_area.sPassGrpCd);
            WS.nFltMoSvcNbr = A04340.A04340_appl_area.nFltMoSvcNbr;
            strcpy(WS.sPprRvkDt, A04340.A04340_appl_area.sPprRvkDt);
            strcpy(WS.sPprStrtDt, A04340.A04340_appl_area.sPprStrtDt);

            // Strip any trailing space, so an empty tax Number is NULL
            UTL_StripTrailingSpaces(A04340.A04340_appl_area.sPprInttxNbr);
            strcpy(WS.sPprInttxNbr, A04340.A04340_appl_area.sPprInttxNbr);

            strcpy(WS.sPprRsdncyStsCd, A04340.A04340_appl_area.sPprRsdncyStsCd);
            }
         else if (nSvcNbr == 4341)
            {
            /**** Move values to working storage ****/
            strcpy(WS.sPprNbr, A04341.A04341_appl_area.sPprNbr);
            strcpy(WS.sPassGrpCd, A04341.A04341_appl_area.sPassGrpCd);
            WS.nFltMoSvcNbr = A04341.A04341_appl_area.nFltMoSvcNbr;
            strcpy(WS.sPprRvkDt, A04341.A04341_appl_area.sPprRvkDt);
            strcpy(WS.sPprStrtDt, A04341.A04341_appl_area.sPprStrtDt);

            // Strip any trailing space, so an empty tax Number is NULL
            UTL_StripTrailingSpaces(A04341.A04341_appl_area.sPprInttxNbr);
            strcpy(WS.sPprInttxNbr, A04341.A04341_appl_area.sPprInttxNbr);

            strcpy(WS.sPprRsdncyStsCd, A04341.A04341_appl_area.sPprRsdncyStsCd);
            }
         break;

      case ARC_ROW_NOT_FOUND:
         if (nSvcNbr == 4340)
            nEndOfMoData = TRUE;
         else if (nSvcNbr == 4341)
            nEndOfYrData = TRUE;
         else if (nSvcNbr == 4309)
            WS.nEndOfPsgr = TRUE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         if (nSvcNbr == 4340)
            {
            BCH_FormatMessage(2,TXT_SVC,"FYS04340");
            BCH_FormatMessage(3,TXT_PPR,R04340.R04340_appl_area.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ObtainNextDBRow");
            }
         else if (nSvcNbr == 4341)
            {
            BCH_FormatMessage(2,TXT_SVC,"FYS04341");
            BCH_FormatMessage(3,TXT_PPR,R04341.R04341_appl_area.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ObtainNextDBRow");
            }
         else if (nSvcNbr == 4309)
            {
            BCH_FormatMessage(2,TXT_SVC,"FYS04309");
            BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ObtainNextDBRow");
            }
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessRows()
{
   short nStrtYr;

   if (RS.nMoProc == TRUE)
      {
      /**** Process each database row for 1 month anniversary processing ****/
      while ((nSvcRtnCd != ARC_ROW_NOT_FOUND) && (nEndOfMoData == FALSE))
         {
         /**** Set months of service equal to one ****/
         WS.nFltMoSvcNbr = 1;

         if (!strcmp(WS.sPassGrpCd, DISABLED_LIM_WIDOW) || !strcmp(WS.sPassGrpCd, EARLY_THREE_WIDOW) ||
             !strcmp(WS.sPassGrpCd, RETIREE_LIM_WIDOW) || !strcmp(WS.sPassGrpCd, OJI_WIDOW) ||
             !strcmp(WS.sPassGrpCd, THREE_MTH_WIDOW) || !strcmp(WS.sPassGrpCd, UNLIM_WIDOW) ||
             !strcmp(WS.sPassGrpCd, RETIRED_EARLY_SIX) || !strcmp(WS.sPassGrpCd, RETIRED_LIMIT_DELTA) ||
             !strcmp(WS.sPassGrpCd, RETIRED_DELTA) || !strcmp(WS.sPassGrpCd, RETIRED_ASSOCIATE) ||
             !strcmp(WS.sPassGrpCd, TRANSQUEST_FROMDL_RET) || !strcmp(WS.sPassGrpCd, VOL_SEV) ||
             !strcmp(WS.sPassGrpCd, WESTERN_EARLYOUT) || !strcmp(WS.sPassGrpCd, WESTERN_RETIREE) ||
	     !strcmp(WS.sPassGrpCd, VOL_SEV_DL_RECOVERY))
            ;
         else
            DPM_2600_UpdateMonthsService();

         DPM_2650_ProcessPassTypes();

         DPM_2700_ReadNrevPsgr();

         strcpy(RS.sPprNbr, WS.sPprNbr);
         RS.nOneMonthPprCnt++;
         DPM_4920_ProcessLUW();

         /****** Initialize working storage block *****/
         memset(&WS, LOW_VALUES, sizeof(WS));

         DPM_2200_ObtainNextDBRow(4340);
         }
      }

   else    /***  Yearly anniversary processing ***/
      {

      while ((nSvcRtnCd != ARC_ROW_NOT_FOUND) && (nEndOfYrData == FALSE))
         {
         /**** Assign PPR start year ****/
         nStrtYr = atoi(&WS.sPprStrtDt[DB_TS_POS_YEAR]);

         /*** only process this row if the ppr start year not = the processing year ***/
         if (nStrtYr != RS.tmDate.tm_year)
           {
           /**** Calculate months of service ****/
           WS.nFltMoSvcNbr = (RS.tmDate.tm_year - nStrtYr) * 12;

            if (!strcmp(WS.sPassGrpCd, DISABLED_LIM_WIDOW) || !strcmp(WS.sPassGrpCd, EARLY_THREE_WIDOW) ||
                !strcmp(WS.sPassGrpCd, RETIREE_LIM_WIDOW) || !strcmp(WS.sPassGrpCd, OJI_WIDOW) ||
                !strcmp(WS.sPassGrpCd, THREE_MTH_WIDOW) || !strcmp(WS.sPassGrpCd, UNLIM_WIDOW) ||
                !strcmp(WS.sPassGrpCd, RETIRED_EARLY_SIX) || !strcmp(WS.sPassGrpCd, RETIRED_LIMIT_DELTA) ||
                !strcmp(WS.sPassGrpCd, RETIRED_DELTA) || !strcmp(WS.sPassGrpCd, RETIRED_ASSOCIATE) ||
                !strcmp(WS.sPassGrpCd, TRANSQUEST_FROMDL_RET) || !strcmp(WS.sPassGrpCd, VOL_SEV) ||
                !strcmp(WS.sPassGrpCd, WESTERN_EARLYOUT) || !strcmp(WS.sPassGrpCd, WESTERN_RETIREE) ||
		!strcmp(WS.sPassGrpCd, VOL_SEV_DL_RECOVERY))
               ;
            else
               DPM_2600_UpdateMonthsService();

            DPM_2650_ProcessPassTypes();

            DPM_2700_ReadNrevPsgr();

            strcpy(RS.sPprNbr, WS.sPprNbr);
            RS.nYrPprCnt++;
            DPM_4920_ProcessLUW();
            }

         /****** Initialize working storage block *****/
         memset(&WS, LOW_VALUES, sizeof(WS));
         DPM_2200_ObtainNextDBRow(4341);
         }
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2600_UpdateMonthsService                 **
**                                                               **
** Description:     Update the PPR table with the months of      **
**                  service completed.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void DPM_2600_UpdateMonthsService()
{

   if (RS.nMoProc == TRUE)
      {
      /**** Format service request block ****/
      R04340.R04340_appl_area.nFltMoSvcNbr = WS.nFltMoSvcNbr;
      strcpy(R04340.R04340_appl_area.sPprNbr, A04340.A04340_appl_area.sPprNbr);

      /**** Set the cursor to update the DB row ****/
      R04340.R04340_appl_area.cArchCursorOpTxt = UPDATE_ROW;

      /****** Execute service to update PPR table with months of service completed ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04340,&A04340,SERVICE_ID_04340,1,sizeof(_R04340_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS04340");
            BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_UpdateMonthsService");
         }
      }
   else
      {
      /**** Format service request block ****/
      R04341.R04341_appl_area.nFltMoSvcNbr = WS.nFltMoSvcNbr;
      strcpy(R04341.R04341_appl_area.sPprNbr, A04341.A04341_appl_area.sPprNbr);

      /**** Set the cursor to update the DB row ****/
      R04341.R04341_appl_area.cArchCursorOpTxt = UPDATE_ROW;
      /****** Execute service to update PPR table with months of serv.sPprNbr);
      /****** Execute service to update PPR table with months of service completed ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R04341,&A04341,SERVICE_ID_04341,1,sizeof(_R04341_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS04341");
            BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_UpdateMonthsService");
         }
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2650_ProcessPassTypes                    **
**                                                               **
** Description:     Store DISTINCT Pass Type Codes from Pass     **
**                  Allotment table in an array and read pass    **
**                  type codes from array to drive the resetting **
**                  of allotments.                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2650_ProcessPassTypes()
{

   /**** Initialize service request and answer blocks ****/
   memset(&R04003.R04003_appl_area, LOW_VALUES, sizeof(_R04003_APPL_AREA));
   memset(&A04003.A04003_appl_area, LOW_VALUES, sizeof(_A04003_APPL_AREA));

   /**** Open the DB cursor ****/
   R04003.R04003_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /**** Execute DISTINCT cursor service to get the pass type codes from the Pass Allotment table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04003,&A04003,SERVICE_ID_04003,1,sizeof(_R04003_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04003");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2650_ProcessPassTypes");
         break;
      }

   /**** Save each pass type code in an array ****/
   for (nPassTypCtr = 0; nSvcRtnCd != ARC_ROW_NOT_FOUND; nPassTypCtr++)
      {
      /**** Store pass type code in array ****/
      strcpy(pass_type[nPassTypCtr].sPassTypCd, A04003.A04003_appl_area.sPassTypCd);

      R04003.R04003_appl_area.cArchCursorOpTxt = FETCH_ROW;

      /**** Get the next DB row ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04003,&A04003,SERVICE_ID_04003,1,sizeof(_R04003_APPL_AREA));

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS04003");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2650_ProcessPassTypes");
         }
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2700_ReadNrevPsgr                        **
**                                                               **
** Description:     Select records from the Non-revenue          **
**                  Passenger table; update Days/Miles and       **
**                  Imputed indicators and Allotments; evaluate  **
**                  Pass Group/Passenger Type combination.       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

	void DPM_2700_ReadNrevPsgr()
{

   cImputedInd = 'N';
   nRewardInd = FALSE;
   nRemoveRewardInd = FALSE;

   /****** Initialize request and answer blocks *****/
   memset(&R04309.R04309_appl_area, LOW_VALUES, sizeof(_R04309_APPL_AREA));
   memset(&A04309.A04309_appl_area, LOW_VALUES, sizeof(_A04309_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R04309.R04309_appl_area.sPprNbr, WS.sPprNbr);

   /**** Open the initial DB cursor ****/
   R04309.R04309_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to select records from the Non-revenue Passenger table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04309,&A04309,SERVICE_ID_04309,1,sizeof(_R04309_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         WS.nEndOfPsgr = TRUE;
         sprintf(sErrorMessage, "No non-revenue passenger rows found for PPR %s", R04309.R04309_appl_area.sPprNbr);
         BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_FormatMessage(2,TXT_SVC,"FYS04309");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2700_ReadNrevPsgr");

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04309");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2700_ReadNrevPsgr");
      }

   /**** Process non-revenue passenger DB rows ****/
   while ((nSvcRtnCd != ARC_ROW_NOT_FOUND) && (WS.nEndOfPsgr == FALSE))
      {

      /**** Evaluate pass imputed indicator for exempt ****/
         cImputedInd = A04309.A04309_appl_area.cPassImptInd;

      /**** Update indicators if not revoked ****/
      if ((strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) != 0) &&
          (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED_DEATH) != 0))
         DPM_2710_UpdateIndicators();

      /**** Evaluate pass group/passenger type if not suspended or revoked ****/
      if ((strcmp(A04309.A04309_appl_area.sPassStsCd, SUSPENDED) != 0) &&
          (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) != 0) &&
          (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED_DEATH) != 0))
         DPM_2720_EvaluateGroupType();

      /***** PASS CARD CHARGES FOR VOL SERVERANCE "VS" & "VR" ARE NO LONGER VALID  *****/
      /***** SO THE FOLLOWING CODE HAS BEEN COMMENTED OUT AS OF 12/18/01           *****/
      /**********************
      if ((!strcmp(WS.sPassGrpCd, VOL_SEV) || !strcmp(WS.sPassGrpCd, VOL_SEV_DL_RECOVERY)) &&
         !strcmp(A04309.A04309_appl_area.sNrevTypCd, SELF) &&
          (strcmp(A04309.A04309_appl_area.sPassStsCd, SUSPENDED) != 0) &&
          (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) != 0) &&
          (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED_DEATH) != 0) &&
          (nRvkInd == FALSE))
         DPM_2730_ProcessVolSeverance();
	 ****************************/

      /**** If revoked or if the Pass Group is Pan Am Participant, or Ineligible Pass Group, do not reset alloments ****/
      if (!strcmp(WS.sPassGrpCd, PANAM) ||  !strcmp(WS.sPassGrpCd, INELIG_PASS_GRP) ||
          !strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) ||!strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED_DEATH) ||
          (nRvkInd == TRUE))
         ;

      /**** Otherwise, if suspended or if the Pass Group is Military Leave, Disabled Regular (M), Disabled Regular(SDW),
            Retiree Limit Widow, Retired Limit Delta, Ready Rsrv Delta (M), Ready Rsrv (SDW) without kids,
            WS Disable-fmrDL (M), WS Disable-fmrDL (SDW), Ldrshp 7.5 Vol Severance, or Western Early-Out,
            update allotments to the previous year's amount ****/
      else if (!strcmp(A04309.A04309_appl_area.sPassStsCd, SUSPENDED) || !strcmp(WS.sPassGrpCd, MILITARY_LEAVE) ||
               !strcmp(WS.sPassGrpCd, DISABLED_DL_MRD) || !strcmp(WS.sPassGrpCd, DISABLED_DL_SDW) ||
               !strcmp(WS.sPassGrpCd, RETIREE_LIM_WIDOW) || !strcmp(WS.sPassGrpCd, RETIRED_LIMIT_DELTA) ||
               !strcmp(WS.sPassGrpCd, WORLDSPAN_DSABLD_MRD) || !strcmp(WS.sPassGrpCd, WORLDSPAN_DSABLD_SDW) ||
               !strcmp(WS.sPassGrpCd, VOL_SEV) || !strcmp(WS.sPassGrpCd, WESTERN_EARLYOUT) ||
	       !strcmp(WS.sPassGrpCd, VOL_SEV_DL_RECOVERY))
         for (z = 0; z < nPassTypCtr; z++)
               DPM_2800_UpdateToOrigAllot();

      /**** Otherwise, update allotment for each pass type to the new amount ****/
      else
         for (z = 0; z < nPassTypCtr; z++)
         {
            /** Shridev Makim: (7/30/98)                                    **/
            /** Two new pass type codes '70' (Above & Beyond) and '80'      **/
            /** (Friends & Family) certificates. Allotments for this pass   **/
            /** type are not created so omit them.                          **/

           if ( strcmp(pass_type[z].sPassTypCd, "70") != 0 &&
                strcmp(pass_type[z].sPassTypCd, "80") != 0)
               DPM_2900_UpdateToNewAllot();
         }

      if (cProcInd == 'M')
         RS.nOneMonthNrevCnt++;
      else
         RS.nYrNrevCnt++;

      DPM_2200_ObtainNextDBRow(4309);
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2710_UpdateIndicators                    **
**                                                               **
** Description:     Update the Pass Imputed Indicator and        **
**                  Current Days and Miles Indicator on the      **
**                  Non-revenue Passenger table.                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void DPM_2710_UpdateIndicators()
{

      /****** Initialize request and answer blocks *****/
      memset(&R02475.R02475_appl_area, LOW_VALUES, sizeof(_R02475_APPL_AREA));
      memset(&A02475.A02475_appl_area, LOW_VALUES, sizeof(_A02475_APPL_AREA));

      /**** Format service request block ****/
      strcpy(R02475.R02475_appl_area.sPassGrpCd, WS.sPassGrpCd);

      /****** Execute service to select from the Pass Group table ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02475,&A02475,SERVICE_ID_02475,1,sizeof(_R02475_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_FormatMessage(2,TXT_SVC,"FYS02475");
            sprintf(sErrorMessage, "Invalid pass group: PPR %s, Pass grp %s", WS.sPprNbr, WS.sPassGrpCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT,sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2710_UpdateIndicators");

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS02475");
            sprintf(sErrorMessage, "Invalid pass group: PPR %s, Pass grp %s", WS.sPprNbr, WS.sPassGrpCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT,sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2710_UpdateIndicators");
         }

	/*MLH Start */
      /**** Set Imputed Indicator to yes if the Pass Group Imputed Indicator is yes ****/
        if (A02475.A02475_appl_area.cPassImptInd == IMPUTED)
           R04309.R04309_appl_area.cPassImptInd = IMPUTED;

      /**** Set Imputed Indicator to ticketed if the Pass Group Imputed Indicator is ticketed ****/
        else if (A02475.A02475_appl_area.cPassImptInd == TICKETED)
           R04309.R04309_appl_area.cPassImptInd = TICKETED;

        else
           {
         /****** Initialize request and answer blocks *****/
           memset(&R02529.R02529_appl_area, LOW_VALUES, sizeof(_R02529_APPL_AREA));
           memset(&A02529.A02529_appl_area, LOW_VALUES, sizeof(_A02529_APPL_AREA));

         /**** Format service request block ****/
           strcpy(R02529.R02529_appl_area.sNrevTypCd, A04309.A04309_appl_area.sNrevTypCd);

         /****** Execute service to select from the Passenger Type table ****/
           nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(_R02529_APPL_AREA));

         /**** Service return code processing ****/
           switch (nSvcRtnCd)
              
	      {
              case ARC_SUCCESS:
                 break;

              case ARC_ROW_NOT_FOUND:
                 BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
                 BCH_FormatMessage(2,TXT_SVC,"FYS02529");
                 sprintf(sErrorMessage, "Invalid psgr type: PPR %s, nrev %s, type %s",
                         WS.sPprNbr, A04309.A04309_appl_area.sNrevNbr, R02529.R02529_appl_area.sNrevTypCd);
                 BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT,sErrorMessage);
                 BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2710_UpdateIndicators");

              default:
                 BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                 BCH_FormatMessage(2,TXT_SVC,"FYS02529");
                 sprintf(sErrorMessage, "Invalid psgr type: PPR %s, nrev %s, type %s",
                         WS.sPprNbr, A04309.A04309_appl_area.sNrevNbr, R02529.R02529_appl_area.sNrevTypCd);
                 BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT,sErrorMessage);
                 BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2710_UpdateIndicators");
              }

         /**** Set Imputed Indicator to Passenger Type Imputed Indicator ****/
           R04309.R04309_appl_area.cPassImptInd = A02529.A02529_appl_area.cPassImptInd;
           }

	  if (cImputedInd == 'E')
	      R04309.R04309_appl_area.cPassImptInd  = cImputedInd;

	/*MLH END*/


   /**** Set Current Days/Miles Indicator with next year's indicator ****/
   R04309.R04309_appl_area.cNrevDyMiInd = A04309.A04309_appl_area.cNrevDyMiNxtInd;

   /**** Format other request block fields with answer block data ****/
   strcpy(R04309.R04309_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R04309.R04309_appl_area.sNrevNm, A04309.A04309_appl_area.sNrevNm);
   strcpy(R04309.R04309_appl_area.sNrevLstNm, A04309.A04309_appl_area.sNrevLstNm);
   strcpy(R04309.R04309_appl_area.sNrevFrstNm, A04309.A04309_appl_area.sNrevFrstNm);
   if (A04309.A04309_appl_area.cNrevMidNm != LOW_VALUES)
      R04309.R04309_appl_area.cNrevMidNm = A04309.A04309_appl_area.cNrevMidNm;
   else
      R04309.R04309_appl_area.cNrevMidNm = SPACE;
   strcpy(R04309.R04309_appl_area.sNrevSrcCd, A04309.A04309_appl_area.sNrevSrcCd);
   strcpy(R04309.R04309_appl_area.sNrevTypCd, A04309.A04309_appl_area.sNrevTypCd);
   R04309.R04309_appl_area.cNrevDyMiNxtInd = A04309.A04309_appl_area.cNrevDyMiNxtInd;
   strcpy(R04309.R04309_appl_area.sNrevBdayDt, A04309.A04309_appl_area.sNrevBdayDt);
   strcpy(R04309.R04309_appl_area.sPassStsCd, A04309.A04309_appl_area.sPassStsCd);
   strcpy(R04309.R04309_appl_area.sPassSusExpDt, A04309.A04309_appl_area.sPassSusExpDt);
   R04309.R04309_appl_area.nPassCardNbr = A04309.A04309_appl_area.nPassCardNbr;
   strcpy(R04309.R04309_appl_area.sArchLastUpdtTs, sCurrentTsDt);

   /*** if the change indicator = 'Y', leave it as is, otherwise put a space there ***/
   /*** because true cursor 4309 will not accept a null character, which can be    ***/
   /*** placed there by the windows.                                               ***/
   if (A04309.A04309_appl_area.cNrevPassChgInd == 'Y')
      R04309.R04309_appl_area.cNrevPassChgInd = A04309.A04309_appl_area.cNrevPassChgInd;
   else
      R04309.R04309_appl_area.cNrevPassChgInd = ' ';

   /**** Activation Fee fields added ****/

   if (RS.nMoProc == FALSE)
   {
   R04309.R04309_appl_area.cPrvAtvnFeeCd = A04309.A04309_appl_area.cCurAtvnFeeCd;
   strcpy(R04309.R04309_appl_area.sPrvAtvnLupdtLts, A04309.A04309_appl_area.sCurAtvnLupdtLts);
   R04309.R04309_appl_area.cCurAtvnFeeCd = A04309.A04309_appl_area.cNxtAtvnFeeCd;
   strcpy(R04309.R04309_appl_area.sCurAtvnLupdtLts, A04309.A04309_appl_area.sNxtAtvnLupdtLts);
   if (A04309.A04309_appl_area.cNxtAtvnFeeCd == 'E')
      {
       R04309.R04309_appl_area.cNxtAtvnFeeCd = A04309.A04309_appl_area.cNxtAtvnFeeCd;
       strcpy(R04309.R04309_appl_area.sNxtAtvnLupdtLts, LOW_DATE);
      }
   else
      {
       R04309.R04309_appl_area.cNxtAtvnFeeCd = 'N';
       strcpy(R04309.R04309_appl_area.sNxtAtvnLupdtLts, LOW_DATE);
      }
   }

   if (RS.nMoProc == TRUE)
   {
   R04309.R04309_appl_area.cPrvAtvnFeeCd = A04309.A04309_appl_area.cPrvAtvnFeeCd;
   strcpy(R04309.R04309_appl_area.sPrvAtvnLupdtLts, A04309.A04309_appl_area.sPrvAtvnLupdtLts);
   R04309.R04309_appl_area.cCurAtvnFeeCd = A04309.A04309_appl_area.cCurAtvnFeeCd;
   strcpy(R04309.R04309_appl_area.sCurAtvnLupdtLts, A04309.A04309_appl_area.sCurAtvnLupdtLts);
   R04309.R04309_appl_area.cNxtAtvnFeeCd = A04309.A04309_appl_area.cNxtAtvnFeeCd;
   strcpy(R04309.R04309_appl_area.sNxtAtvnLupdtLts, A04309.A04309_appl_area.sNxtAtvnLupdtLts);
   }

  /**** Activation Fee fields added ****/

   /**** Gender field added ***/
   R04309.R04309_appl_area.cGndrTypCd = A04309.A04309_appl_area.cGndrTypCd;

   /**** Set cursor to update the DB row ****/
   R04309.R04309_appl_area.cArchCursorOpTxt = UPDATE_ROW;

   /****** Execute service to update the Pass Imputed Indicator and the Current Days/Miles Indicator
           with next year's indicator on the Non-revenue Passenger table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04309,&A04309,SERVICE_ID_04309,1,sizeof(_R04309_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04309");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2710_UpdateIndicators");
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2720_EvaluateGroupType                   **
**                                                               **
** Description:     Calls service to select from the Pass Group  **
**                  Passenger Type table to determine if the     **
**                  combination is valid.                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void DPM_2720_EvaluateGroupType()
{

   nRvkInd = FALSE;

   /**** Initialize request and answer blocks ****/
   memset(&R03270.R03270_appl_area, LOW_VALUES, sizeof(_R03270_APPL_AREA));
   memset(&A03270.A03270_appl_area, LOW_VALUES, sizeof(_A03270_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R03270.R03270_appl_area.sPassGrpCd, WS.sPassGrpCd);
   strcpy(R03270.R03270_appl_area.sNrevTypCd, A04309.A04309_appl_area.sNrevTypCd);

   /****** Execute service to select from the Pass Group Passenger Type table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03270,&A03270,SERVICE_ID_03270,1,sizeof(_R03270_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         /** Revoke non-revenue passenger and set revoked indicator to true **/
         DPM_2725_RevokeNrevPsgr();
         nRvkInd = TRUE;

         /** Write a Delatmatic delete record for each pass type that exists **/
         for (z = 0; z < nPassTypCtr; z++)
            {
            DPM_2920_ReadRemnAllot();
            if (nOldAllotInd == TRUE)
               DPM_3000_WriteDlmaticRecord(DELETE_REC);
            }
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS03270");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2720_EvaluateGroupType");
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2725_RevokeNrevPsgr                      **
**                                                               **
** Description:     Sets the Pass Status Code to revoked and     **
**                  the Pass Suspension Expiration Date to the   **
**                  default date on the Non-revenue Passenger    **
**                  table, sets the Card Status Indicator to     **
**                  deactivated and the Card Processed Indicator **
**                  writes a comment to the Comments table, and  **
**                  writes to the Audit Trail Table.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void DPM_2725_RevokeNrevPsgr()
{
   char sPassStsCd[3];

   strcpy(sPassStsCd, A04309.A04309_appl_area.sPassStsCd); /** save this nrev's pass status ***/

   /**** Format service request block ****/
   strcpy(R04309.R04309_appl_area.sPassStsCd, REVOKED);
   strcpy(R04309.R04309_appl_area.sPassSusExpDt, LOW_DATE);
   R04309.R04309_appl_area.cNrevPassChgInd = 'Y';

   /**** Format other request block fields with answer block data ****/
   strcpy(R04309.R04309_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R04309.R04309_appl_area.sNrevNm, A04309.A04309_appl_area.sNrevNm);
   strcpy(R04309.R04309_appl_area.sNrevLstNm, A04309.A04309_appl_area.sNrevLstNm);
   strcpy(R04309.R04309_appl_area.sNrevFrstNm, A04309.A04309_appl_area.sNrevFrstNm);
   if (A04309.A04309_appl_area.cNrevMidNm != LOW_VALUES)
      R04309.R04309_appl_area.cNrevMidNm = A04309.A04309_appl_area.cNrevMidNm;
   else
      R04309.R04309_appl_area.cNrevMidNm = SPACE;
   strcpy(R04309.R04309_appl_area.sNrevSrcCd, A04309.A04309_appl_area.sNrevSrcCd);
   strcpy(R04309.R04309_appl_area.sNrevTypCd, A04309.A04309_appl_area.sNrevTypCd);
   R04309.R04309_appl_area.cNrevDyMiInd = A04309.A04309_appl_area.cNrevDyMiInd;
   R04309.R04309_appl_area.cNrevDyMiNxtInd = A04309.A04309_appl_area.cNrevDyMiNxtInd;
   strcpy(R04309.R04309_appl_area.sNrevBdayDt, A04309.A04309_appl_area.sNrevBdayDt);
   R04309.R04309_appl_area.cPassImptInd = A04309.A04309_appl_area.cPassImptInd;
   if (cImputedInd == 'E')
       R04309.R04309_appl_area.cPassImptInd  = cImputedInd;
   R04309.R04309_appl_area.nPassCardNbr = A04309.A04309_appl_area.nPassCardNbr;
   strcpy(R04309.R04309_appl_area.sArchLastUpdtTs, sCurrentTsDt);

   /**** Activation Fee fields added ****/

   R04309.R04309_appl_area.cPrvAtvnFeeCd = A04309.A04309_appl_area.cCurAtvnFeeCd;
   strcpy(R04309.R04309_appl_area.sPrvAtvnLupdtLts, A04309.A04309_appl_area.sCurAtvnLupdtLts);
   R04309.R04309_appl_area.cCurAtvnFeeCd = A04309.A04309_appl_area.cNxtAtvnFeeCd;
   strcpy(R04309.R04309_appl_area.sCurAtvnLupdtLts, A04309.A04309_appl_area.sNxtAtvnLupdtLts);
   if (A04309.A04309_appl_area.cNxtAtvnFeeCd == 'E')
      {
       R04309.R04309_appl_area.cNxtAtvnFeeCd = A04309.A04309_appl_area.cNxtAtvnFeeCd;
       strcpy(R04309.R04309_appl_area.sNxtAtvnLupdtLts, LOW_DATE);
      }
   else
      {
       R04309.R04309_appl_area.cNxtAtvnFeeCd = 'N';
       strcpy(R04309.R04309_appl_area.sNxtAtvnLupdtLts, LOW_DATE);
      }
   /**** Activation Fee fields added ****/


   /**** Set cursor to update the DB row ****/
   R04309.R04309_appl_area.cArchCursorOpTxt = UPDATE_ROW;

   /****** Execute service to update the Pass Status Code to revoked and the Pass Suspension
           Expiration Date to the default date on the Non-revenue Passenger table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04309,&A04309,SERVICE_ID_04309,1,sizeof(_R04309_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04309");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2725_RevokeNrevPsgr");
      }

   /****** Initialize request and answer blocks *****/
   memset(&R04119.R04119_appl_area, LOW_VALUES, sizeof(_R04119_APPL_AREA));
   memset(&R04119.R04119_appl_area, LOW_VALUES, sizeof(_R04119_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R04119.R04119_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R04119.R04119_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);

   /****** Execute service to update the Card Status Indicator to deactivated and the
           Card Processed Indicator to processed on the Pass Card table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R04119,&A04119,SERVICE_ID_04119,1,sizeof(_R04119_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04119");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2725_RevokeNrevPsgr");
      }

   /****** Initialize request and answer blocks *****/
   memset(&R02483.R02483_appl_area, LOW_VALUES, sizeof(_R02483_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R02483.R02483_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R02483.R02483_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02483.R02483_appl_area.sNrevNm, A04309.A04309_appl_area.sNrevNm);
   strcpy(R02483.R02483_appl_area.sPassStsChgDt, sCurrentTsDt);
   strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);
   strcpy(R02483.R02483_appl_area.sPassDtTmTs, sCurrentTsDt);
   strcpy(R02483.R02483_appl_area.sNrevCmntTxt, INELIGIBLE_COMMENT);
   strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);

   /****** Execute service to insert record in the Comments table to log changed pass status ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02483,&A02483,SERVICE_ID_02483,1,sizeof(_R02483_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02483");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2725_RevokeNrevPsgr");
      }


   /****** Finally, insert row in Audit Trail Table  *****/
   memset(&R02561.R02561_appl_area, LOW_VALUES, sizeof(_R02561_APPL_AREA));
   memset(&A02561.A02561_appl_area, LOW_VALUES, sizeof(_A02561_APPL_AREA));
   strcpy(R02561.R02561_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R02561.R02561_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02561.R02561_appl_area.sAudtUserId, "RSALLT");
   strcpy(R02561.R02561_appl_area.sPassGrpCd, WS.sPassGrpCd);
   strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Invalid Grp/Typ");
   strcpy(R02561.R02561_appl_area.sAudtChgFrNm, sPassStsCd);
   strcpy(R02561.R02561_appl_area.sAudtChgToNm, REVOKED);
   strcpy(R02561.R02561_appl_area.sPassTypCd, "  ");

   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02561,&A02561,SERVICE_ID_02561,1,sizeof(_R02561_APPL_AREA));
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02561");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2725_RevokeNrevPsgr");
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2730_ProcessVolSeverance                 **
**                                                               **
** Description:     Inserts a pass card charge record into the   **
**                  Charges table for all Voluntary Severance    **
**                  non-revenue passengers.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void DPM_2730_ProcessVolSeverance()
{

   /**** Initialize service request block ****/
   memset(&A02662.A02662_appl_area, LOW_VALUES, sizeof(_A02662_APPL_AREA));

   /**** Format request block ****/
   strcpy(R02662.R02662_appl_area.sSvcChrgCd, PASSCARD_CHARGE);
   strcpy(R02662.R02662_appl_area.sPassTypCd, STARS);

   /**** Execute service to select pass card charge amount from the Pass Charge Amount table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02662,&A02662,SERVICE_ID_02662,1,sizeof(_R02662));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         sprintf(sErrorMessage, "Pass card charge not found.");
         BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_FormatMessage(2,TXT_SVC,"FYS02662");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2730_ProcessVolSeverance");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02662");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2730_ProcessVolSeverance");
      }

      /**** Initialize service request and answer blocks ****/
      memset(&A02526.A02526_appl_area, LOW_VALUES, sizeof(_A02526_APPL_AREA));
      memset(&R02526.R02526_appl_area, LOW_VALUES, sizeof(_R02526_APPL_AREA));

      /**** Format Request block with specifics ****/
      strcpy(R02526.R02526_appl_area.sPprNbr, WS.sPprNbr);
      strcpy(R02526.R02526_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
      strcpy(R02526.R02526_appl_area.sFltDprtDt, sCurrentTsDt);
      UTL_ZeroDatesTime(R02526.R02526_appl_area.sFltDprtDt);
      strcpy(R02526.R02526_appl_area.sPassDtTmTs, sCurrentTsDt);
      strcpy(R02526.R02526_appl_area.sFltOrigCtyId, SPACE_CHAR);
      strcpy(R02526.R02526_appl_area.sFltDestCtyId, SPACE_CHAR);
      R02526.R02526_appl_area.lPassTripNbr = 0;
      strcpy(R02526.R02526_appl_area.sSvcChrgCd, PASSCARD_CHARGE);
      R02526.R02526_appl_area.dCostChrgAmt = A02662.A02662_appl_area.dCostChrgAmt;
      strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
      strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, A02662.A02662_appl_area.sFltFeeAcctNbr);
      strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
      strcpy(R02526.R02526_appl_area.sSvcChrgDs, SPACE_CHAR);
      R02526.R02526_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(sCurrentTsDt);

      /**** Execute service to insert pass card record into Charges table ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(_R02526_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS02526");
            BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2730_ProcessVolSeverance");
         }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2800_UpdateToOrigAllot                   **
**                                                               **
** Description:     Update allotment according to original       **
**                  days/miles allotment.                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void DPM_2800_UpdateToOrigAllot()
{

   /**** For each pass type code, do the following:                              ****/
   /**** 1. Read the Prior Period Remaining Allotment table.                     ****/
   /**** 2. Read the Remaining Allotment table.                                  ****/
   /**** 3. Process accordingly.                                                 ****/

   nOldAllotInd = FALSE;
   nPriorRemnAllotInd = FALSE;

   DPM_2910_ReadPriorRemnAllot();

   DPM_2920_ReadRemnAllot();

   /**** If remn allot rec exists and prior remn allot rec exists, update prior remn allot rec.
         If remn allot rec exists and prior remn allot rec does not exist, insert prior remn allot rec.
         If remn allot rec does not exist and prior remn allot rec exists, delete prior remn allot rec.
         If remn allot rec does not exist and prior remn allot rec does not exist, do nothing. ****/
   if ((nOldAllotInd == TRUE) && (nPriorRemnAllotInd == TRUE))
      DPM_2940_UpdatePriorRemnAllot();

   else if ((nOldAllotInd == TRUE) && (nPriorRemnAllotInd == FALSE))
      DPM_2950_InsertPriorRemnAllot();

   else if ((nOldAllotInd == FALSE) && (nPriorRemnAllotInd == TRUE))
      DPM_2960_DeletePriorRemnAllot();


   /**** If remn allot rec exists, update allotment to previous year's amount and
         write Deltamatic change record ****/
   if (nOldAllotInd == TRUE)
      {
      if (strncmp(pass_type[z].sPassTypCd, REWARD_PASS_TYPE, 2) != 0)
      {
      /**** Initialize request block ****/
      memset(&R02714.R02714_appl_area, LOW_VALUES, sizeof(_R02714_APPL_AREA));

      /**** Format service request block ****/
      strcpy(R02714.R02714_appl_area.sPprNbr, WS.sPprNbr);
      strcpy(R02714.R02714_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
      strcpy(R02714.R02714_appl_area.sProcDt, sCurrentTsDt);
      strcpy(R02714.R02714_appl_area.sPassTypCd, pass_type[z].sPassTypCd);

      /****** Execute service to update allotment to original days/miles allotment on the Remaining Allotment table ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02714,&A02714,SERVICE_ID_02714,1,sizeof(_R02714_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS02714");
            BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2800_UpdateToOrigAllot");
         }
      }

      /**** Write Deltamatic change record ****/
      DPM_3000_WriteDlmaticRecord(CHANGE_REC);
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2900_UpdateToNewAllot                    **
**                                                               **
** Description:     Reset allotments for a pass rider.           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2900_UpdateToNewAllot()
{

   /**** For each pass type code, do the following:                              ****/
   /**** 1. Read the Prior Period Remaining Allotment table.                     ****/
   /**** 2. Read the Remaining Allotment table.                                  ****/
   /**** 3. Read the Pass Allotment table.                                       ****/
   /**** 4. Process accordingly.                                                 ****/

   nOldAllotInd = FALSE;
   nNewAllotInd = FALSE;
   nPriorRemnAllotInd = FALSE;

   DPM_2910_ReadPriorRemnAllot();

   DPM_2920_ReadRemnAllot();

   DPM_2930_ReadPassAllot();

   if (RS.tmDate.tm_year >= 2003)
     nRemoveRewardInd = TRUE;

   /**** If remn allot rec exists, prior remn allot rec exists, and there are new allotments,
         update prior remn allot rec, update remn allot rec, and write Deltamatic change rec.
         If remn allot rec exists, prior remn allot rec does not exist, and there are new allotments
         insert prior remn allot rec, update remn allot rec, and write Deltamatic change rec ****/
   if ((nOldAllotInd == TRUE) && (nNewAllotInd == TRUE))
      {
      if (nPriorRemnAllotInd == TRUE)
         DPM_2940_UpdatePriorRemnAllot();
      else
         DPM_2950_InsertPriorRemnAllot();

      if (strncmp(pass_type[z].sPassTypCd, REWARD_PASS_TYPE, 2) != 0)
      {
        DPM_2970_UpdateRemnAllot();

        DPM_3000_WriteDlmaticRecord(CHANGE_REC);
      }
      else
      {
        if (nRemoveRewardInd == TRUE)
        {
          DPM_2990_DeleteRemnAllot();

          DPM_3000_WriteDlmaticRecord(DELETE_REC);
        }
	else
          DPM_3000_WriteDlmaticRecord(CHANGE_REC);
      }
      }
   /**** If remn allot rec exists, prior remn allot rec exists, and there are no new allotments,
         update prior remn allot rec, delete remn allot rec, and write Deltamatic delete rec.
         If remn allot rec exists, prior remn allot rec does not exist, and there are no new allotments
         insert prior remn allot rec, delete remn allot rec, and write Deltamatic delete rec ****/
   else if ((nOldAllotInd == TRUE) && (nNewAllotInd == FALSE))
      {
      if (nPriorRemnAllotInd == TRUE)
         DPM_2940_UpdatePriorRemnAllot();
      else
         DPM_2950_InsertPriorRemnAllot();

      if (strncmp(pass_type[z].sPassTypCd, REWARD_PASS_TYPE, 2) == 0)
	nRemoveRewardInd = TRUE;

      DPM_2990_DeleteRemnAllot();

      DPM_3000_WriteDlmaticRecord(DELETE_REC);
         }

  /**** If remn allot rec does not exist, prior remn allot rec exists, and there are new allotments,
        delete prior remn allot rec, insert remn allot rec, and write Deltamatic add rec.
        If remn allot rec does not exist, prior remn allot rec does not exist, and there are new allotments
        insert remn allot rec, and write Deltamatic add rec ****/
   else if ((nOldAllotInd == FALSE) && (nNewAllotInd == TRUE))
      {
      if (strncmp(pass_type[z].sPassTypCd, REWARD_PASS_TYPE, 2) != 0)
      {
      if (nPriorRemnAllotInd == TRUE)
         DPM_2960_DeletePriorRemnAllot();

      DPM_2980_InsertRemnAllot();

      DPM_3000_WriteDlmaticRecord(ADD_REC);
      }
      }

   /**** If remn allot rec does not exist, prior remn allot rec exists, and there are no new allotments
         delete prior remn allot rec.
         If remn allot rec does not exist, prior remn allot rec does not exist, and there are no new
         allotments do nothing ****/
   else if ((nOldAllotInd == FALSE) && (nNewAllotInd == FALSE) && (nPriorRemnAllotInd == TRUE))
      DPM_2960_DeletePriorRemnAllot();

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2910_ReadPriorRemnAllot                  **
**                                                               **
** Description:     For an individual pass rider, reads the      **
**                  Prior Period Remaining Allotment table       **
**                  for a specific pass type.                    **
**                  Executes service 02764.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2910_ReadPriorRemnAllot()
{

   nPriorRemnAllotInd = FALSE;

   /**** Initialize request and answer blocks ****/
   memset(&R02760.R02760_appl_area, LOW_VALUES, sizeof(_R02760_APPL_AREA));
   memset(&A02760.A02760_appl_area, LOW_VALUES, sizeof(_A02760_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R02760.R02760_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R02760.R02760_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02760.R02760_appl_area.sPassTypCd, pass_type[z].sPassTypCd);

   /**** Execute service to select the row for the pass type in the Prior Period Remaining Allotment table for the nrev psgr ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02760,&A02760,SERVICE_ID_02760,1,sizeof(_R02760_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         nPriorRemnAllotInd = TRUE;
         break;

      case ARC_ROW_NOT_FOUND:
         nPriorRemnAllotInd = FALSE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02760");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2910_ReadPriorRemnAllot");
      }

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2920_ReadRemnAllot                       **
**                                                               **
** Description:     For an individual pass rider, reads the      **
**                  Remaining Allotment table for a specific     **
**                  pass type.                                   **
**                  Executes service 02441.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2920_ReadRemnAllot()
{

   nOldAllotInd = FALSE;

   /**** Initialize request and answer blocks ****/
   memset(&R02441.R02441_appl_area, LOW_VALUES, sizeof(_R02441_APPL_AREA));
   memset(&A02441.A02441_appl_area, LOW_VALUES, sizeof(_A02441_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R02441.R02441_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R02441.R02441_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02441.R02441_appl_area.sPassTypCd, pass_type[z].sPassTypCd);

   /**** Execute service to select the row for the pass type in the Remaining Allotment table for the nrev psgr ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02441,&A02441,SERVICE_ID_02441,1,sizeof(_R02441_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         nOldAllotInd = TRUE;
	 if (strncmp(R02441.R02441_appl_area.sPassTypCd,REWARD_PASS_TYPE,2) == 0)
           nRewardInd = TRUE;
         break;

      case ARC_ROW_NOT_FOUND:
         nOldAllotInd = FALSE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02441");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2920_ReadRemnAllot");
         break;
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2930_ReadPassAllot                       **
**                                                               **
** Description:     For an individual pass rider, reads the      **
**                  Pass Allotment table and sets an indicator.  **
**                  Executes service 04000.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2930_ReadPassAllot()
{

   /**** Initialize service request and answer blocks ****/
   memset(&R04000.R04000_appl_area, LOW_VALUES, sizeof(_R04000_APPL_AREA));
   memset(&A04000.A04000_appl_area, LOW_VALUES, sizeof(_A04000_APPL_AREA));

   /**** Format the request block ****/
   strcpy(R04000.R04000_appl_area.sPassGrpCd, WS.sPassGrpCd);
   strcpy(R04000.R04000_appl_area.sPassTypCd, pass_type[z].sPassTypCd);
   strcpy(R04000.R04000_appl_area.sNrevTypCd, A04309.A04309_appl_area.sNrevTypCd);
   R04000.R04000_appl_area.nFltMoSvcNbr = WS.nFltMoSvcNbr;

   /**** Open the DB cursor ****/
   R04000.R04000_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /**** Execute service to read the Pass Allotment table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04000,&A04000,SERVICE_ID_04000,1,sizeof(_R04000_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         nNewAllotInd = TRUE;
         break;

      case ARC_ROW_NOT_FOUND:
         nNewAllotInd = FALSE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04000");
         BCH_FormatMessage(3,TXT_PSGR_TYPE,pass_type[z].sPassTypCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2930_ReadPassAllot");
         break;
      }

   /**** Close the DB cursor ****/
   R04000.R04000_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04000,&A04000,SERVICE_ID_04000,1,sizeof(_R04000_APPL_AREA));
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2940_UpdatePriorRemnAllot                **
**                                                               **
** Description:     Copy all remaining allotment records to      **
**                  prior period remaining allotment table for   **
**                  an individual pass rider.                    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2940_UpdatePriorRemnAllot()
{

   /**** Initialize request block ****/
   memset(&R02763.R02763_appl_area, LOW_VALUES, sizeof(_R02762_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R02763.R02763_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R02763.R02763_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02763.R02763_appl_area.sPassTypCd, pass_type[z].sPassTypCd);
   R02763.R02763_appl_area.nNrevRemnDyQty = A02441.A02441_appl_area.nNrevRemnDyQty;
   R02763.R02763_appl_area.lNrevRemnMiQty = A02441.A02441_appl_area.lNrevRemnMiQty;
   R02763.R02763_appl_area.cPassAddlInd = A02441.A02441_appl_area.cPassAddlInd;
   strcpy(R02763.R02763_appl_area.sArchLastUpdtTs, A02760.A02760_appl_area.sArchLastUpdtTs);

   /**** Execute primitive service to update the pass type row in the Prior Period Remaining Allotment table for the nrev psgr ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02763,&A02763,SERVICE_ID_02763,1,sizeof(_R02763_APPL_AREA));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02763");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2940_UpdatePriorRemnAllot");
      }

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2950_InsertPriorRemnAllot                **
**                                                               **
** Description:     Copy all remaining allotment records to      **
**                  prior period remaining allotment table for   **
**                  an individual pass rider.                    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2950_InsertPriorRemnAllot()
{

   /**** Initialize request block ****/
   memset(&R02762.R02762_appl_area, LOW_VALUES, sizeof(_R02762_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R02762.R02762_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R02762.R02762_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02762.R02762_appl_area.sPassTypCd, pass_type[z].sPassTypCd);
   R02762.R02762_appl_area.nNrevRemnDyQty = A02441.A02441_appl_area.nNrevRemnDyQty;
   R02762.R02762_appl_area.lNrevRemnMiQty = A02441.A02441_appl_area.lNrevRemnMiQty;
   R02762.R02762_appl_area.cPassAddlInd = A02441.A02441_appl_area.cPassAddlInd;

   /**** Execute primitive service to insert the pass type row into the Prior Period Remaining Allotment table for the nrev psgr ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02762,&A02762,SERVICE_ID_02762,1,sizeof(_R02762_APPL_AREA));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02762");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2950_InsertPriorRemnAllot");
      }

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2960_DeletePriorRemnAllot                **
**                                                               **
** Description:     For an individual pass rider, deletes        **
**                  all records from the Prior Period Remaining  **
**                  Allotment table for a specific pass type.    **
**                  Executes service 02764.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2960_DeletePriorRemnAllot()
{

   /**** Initialize request block ****/
   memset(&R02764.R02764_appl_area, LOW_VALUES, sizeof(_R02764_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R02764.R02764_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R02764.R02764_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02764.R02764_appl_area.sPassTypCd, pass_type[z].sPassTypCd);
   strcpy(R02764.R02764_appl_area.sArchLastUpdtTs, A02760.A02760_appl_area.sArchLastUpdtTs);

   /**** Execute service to delete the row from the pass type row from the Prior Period Remaining Allotment table for the nrev psgr ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02764,&A02764,SERVICE_ID_02764,1,sizeof(_R02764_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02764");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2960_DeletePriorRemnAllot");
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2970_UpdateRemnAllot                     **
**                                                               **
** Description:     Update individual record from the remaining  **
**                  allotment table for a pass rider.            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2970_UpdateRemnAllot()
{

   /****** Initialize request block *****/
   memset(&R02444.R02444_appl_area, LOW_VALUES, sizeof(_R02444_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R02444.R02444_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R02444.R02444_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02444.R02444_appl_area.sPassTypCd, pass_type[z].sPassTypCd);

   /**** Domestic and combo domestic/transoceanic pass types can be days or miles, depending on the chosen type ****/
   if ((strcmp(pass_type[z].sPassTypCd, DOMESTIC) == 0) || (strcmp(pass_type[z].sPassTypCd, COMB_DOM_TO) == 0))
      {
      if (A04309.A04309_appl_area.cNrevDyMiInd == MILES)
         {
         R02444.R02444_appl_area.lFltAllotMiQty = A04000.A04000_appl_area.lFltAllotMiQty;
         R02444.R02444_appl_area.lNrevRemnMiQty = A04000.A04000_appl_area.lFltAllotMiQty;
         R02444.R02444_appl_area.nFltAllotDyNbr = 0;
         R02444.R02444_appl_area.nNrevRemnDyQty = 0;
         }
      else
         {
         R02444.R02444_appl_area.nFltAllotDyNbr = A04000.A04000_appl_area.nFltAllotDyNbr;
         R02444.R02444_appl_area.nNrevRemnDyQty = A04000.A04000_appl_area.nFltAllotDyNbr;
         R02444.R02444_appl_area.lFltAllotMiQty = 0;
         R02444.R02444_appl_area.lNrevRemnMiQty = 0;
         }
      }

   /**** All other pass types are days ****/
   else
      {
      /**** Special processing for EXPATS and THIRD COUNTRY NATLS:                          ****/
      /**** If pass type is Transoceanic AND pass group is Active DL (SDW) without kids,    ****/
      /**** Active DL (SDW) with kids, or Active Delta (M) AND the residency status code is ****/
      /**** Expat or Third Country Natl, set allotted days and remaining days to unlimited. ****/
      if (!strcmp(pass_type[z].sPassTypCd, TRANSOCEANIC) &&
         (!strcmp(WS.sPassGrpCd, ACTIVE_DL) || !strcmp(WS.sPassGrpCd, ACTIVE_DL_WK) || !strcmp(WS.sPassGrpCd, ACTIVE_DL_MRD)) &&
         (!strcmp(WS.sPprRsdncyStsCd, EXPAT) || !strcmp(WS.sPprRsdncyStsCd, THIRD_CNTRY_NATL)))
         {
         R02444.R02444_appl_area.nNrevRemnDyQty = UNLIMITED_DAYS;
         R02444.R02444_appl_area.nFltAllotDyNbr = UNLIMITED_DAYS;
         }
      else
         {
         R02444.R02444_appl_area.nFltAllotDyNbr = A04000.A04000_appl_area.nFltAllotDyNbr;
         R02444.R02444_appl_area.nNrevRemnDyQty = A04000.A04000_appl_area.nFltAllotDyNbr;
         }
      R02444.R02444_appl_area.lFltAllotMiQty = 0;
      R02444.R02444_appl_area.lNrevRemnMiQty = 0;
      }

   R02444.R02444_appl_area.cPassAddlInd = A04000.A04000_appl_area.cPassAddlInd;
   strcpy(R02444.R02444_appl_area.sProcDt, sCurrentTsDt);
   strcpy(R02444.R02444_appl_area.sArchLastUpdtTs, A02441.A02441_appl_area.sArchLastUpdtTs);

   /**** Execute service to update the pass type row in the Remaining Allotment table for the nrev psgr ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02444,&A02444,SERVICE_ID_02444,1,sizeof(_R02444_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02444");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2970_UpdateRemnAllot");
         break;
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2980_InsertRemnAllot                     **
**                                                               **
** Description:     Insert a record into the Remaining           **
**                  Allotment table.                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2980_InsertRemnAllot()
{

   /****** Initialize request block *****/
   memset(&R02443.R02443_appl_area, LOW_VALUES, sizeof(_R02443_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R02443.R02443_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R02443.R02443_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02443.R02443_appl_area.sPassTypCd, pass_type[z].sPassTypCd);

   /**** Domestic and combo domestic/transoceanic pass types can be days or miles, depending on the chosen type ****/
   if ((strcmp(pass_type[z].sPassTypCd, DOMESTIC) == 0) ||
       (strcmp(pass_type[z].sPassTypCd, COMB_DOM_TO) == 0))
      {
      if (A04309.A04309_appl_area.cNrevDyMiInd == MILES)
         {
         R02443.R02443_appl_area.lFltAllotMiQty = A04000.A04000_appl_area.lFltAllotMiQty;
         R02443.R02443_appl_area.lNrevRemnMiQty = A04000.A04000_appl_area.lFltAllotMiQty;
         R02443.R02443_appl_area.nFltAllotDyNbr = 0;
         R02443.R02443_appl_area.nNrevRemnDyQty = 0;
         }
      else
         {
         R02443.R02443_appl_area.nFltAllotDyNbr = A04000.A04000_appl_area.nFltAllotDyNbr;
         R02443.R02443_appl_area.nNrevRemnDyQty = A04000.A04000_appl_area.nFltAllotDyNbr;
         R02443.R02443_appl_area.lFltAllotMiQty = 0;
         R02443.R02443_appl_area.lNrevRemnMiQty = 0;
         }
      }

   /**** Special processing for EXPATS and THIRD COUNTRY NATLS:                          ****/
   /**** If pass type is Transoceanic AND pass group is Active DL (SDW) without kids,    ****/
   /**** Active DL (SDW) with kids, or Active Delta (M) AND the residency status code is ****/
   /**** Expat or Third Country Natl, set allotted days and remaining days to unlimited. ****/
   else if (!strcmp(pass_type[z].sPassTypCd, TRANSOCEANIC) &&
           (!strcmp(WS.sPassGrpCd, ACTIVE_DL) || !strcmp(WS.sPassGrpCd, ACTIVE_DL_WK) || !strcmp(WS.sPassGrpCd, ACTIVE_DL_MRD)) &&
         (!strcmp(WS.sPprRsdncyStsCd, EXPAT) || !strcmp(WS.sPprRsdncyStsCd, THIRD_CNTRY_NATL)))
      {
      R02443.R02443_appl_area.nNrevRemnDyQty = UNLIMITED_DAYS;
      R02443.R02443_appl_area.nFltAllotDyNbr = UNLIMITED_DAYS;
      R02443.R02443_appl_area.lFltAllotMiQty = 0;
      R02443.R02443_appl_area.lNrevRemnMiQty = 0;
      }

   /**** All other pass types are days ****/
   else
      {
      R02443.R02443_appl_area.nFltAllotDyNbr = A04000.A04000_appl_area.nFltAllotDyNbr;
      R02443.R02443_appl_area.nNrevRemnDyQty = A04000.A04000_appl_area.nFltAllotDyNbr;
      R02443.R02443_appl_area.lFltAllotMiQty = 0;
      R02443.R02443_appl_area.lNrevRemnMiQty = 0;
      }

   R02443.R02443_appl_area.cPassAddlInd = A04000.A04000_appl_area.cPassAddlInd;
   strcpy(R02443.R02443_appl_area.sProcDt, sCurrentTsDt);

   /**** Execute service to insert the pass type row into the Remaining Allotment table for the nrev psgr ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02443,&A02443,SERVICE_ID_02443,1,sizeof(_R02443_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02443");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2980_InsertRemnAllot");
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2990_DeleteRemnAllot                     **
**                                                               **
** Description:     Delete individual record from the remaining  **
**                  allotment table for a pass rider.            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2990_DeleteRemnAllot()
{

   /**** Initialize request block ****/
   memset(&R02445.R02445_appl_area, LOW_VALUES, sizeof(_R02445_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R02445.R02445_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R02445.R02445_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02445.R02445_appl_area.sPassTypCd, pass_type[z].sPassTypCd);
   strcpy(R02445.R02445_appl_area.sArchLastUpdtTs, A02441.A02441_appl_area.sArchLastUpdtTs);

   /**** Execute service to delete the pass type row from the Remaining Allotment table for the nrev psgr ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R02445,&A02445,SERVICE_ID_02445,1,sizeof(_R02445_APPL_AREA));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02445");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2990_DeleteRemnAllot");
      }

}


/******************************************************************
**                                                               **
** Function Name:   DPM_3000_WriteDlmaticRecord                  **
**                                                               **
** Description:     Write a record to the Deltamatic table.      **
**                                                               **
** Arguments:       Record type                                  **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_3000_WriteDlmaticRecord(char cRecTyp)
{
   short   nSvcRtnCd1;        /** Service return code **/


   /**** Initialize request block ****/
   memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA));

   /**** Format request block ****/
   strcpy(R04325.R04325_appl_area.sPprNbr, WS.sPprNbr);
   strcpy(R04325.R04325_appl_area.sNrevNbr, R04309.R04309_appl_area.sNrevNbr);
   strcpy(R04325.R04325_appl_area.sPassTypCd,  pass_type[z].sPassTypCd);

   if (cRecTyp == ADD_REC)
      R04325.R04325_appl_area.cEmplArRecInd = ADD_REC;
   else if (cRecTyp == CHANGE_REC)
      R04325.R04325_appl_area.cEmplArRecInd = CHANGE_REC;
   else if (cRecTyp == DELETE_REC)
      R04325.R04325_appl_area.cEmplArRecInd = DELETE_REC;

   if ((nRemoveRewardInd == TRUE) && (strncmp(pass_type[z].sPassTypCd, "30", 2) == 0))
   {
     /**** Execute service to insert record into the Deltamatic table ****/
     nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R04325,&A04325,SERVICE_ID_04325,1,sizeof(_R04325_APPL_AREA));
   }
   else
   {
     /**** Execute service to insert record into the Deltamatic table ****/
     if ((strncmp(pass_type[z].sPassTypCd, "30", 2) != 0) || ((strncmp(pass_type[z].sPassTypCd, "30", 2) == 0) && (nRewardInd == FALSE)))
       nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R04325,&A04325,SERVICE_ID_04325,1,sizeof(_R04325_APPL_AREA));
   }

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_DUPLICATE_ROW:
         DPM_3100_ReadDlmaticRecord();

         strcpy(R04326.R04326_appl_area.sPprNbr, R04325.R04325_appl_area.sPprNbr);
         strcpy(R04326.R04326_appl_area.sNrevNbr, R04325.R04325_appl_area.sNrevNbr);
         strcpy(R04326.R04326_appl_area.sPassTypCd, R04325.R04325_appl_area.sPassTypCd);
         R04326.R04326_appl_area.cEmplArRecInd = R04325.R04325_appl_area.cEmplArRecInd;
         strcpy(R04326.R04326_appl_area.sArchLastUpdtTs, A04323.A04323_appl_area.sArchLastUpdtTs);

         /**** Execute service to update record in the Deltamatic table ****/
         nSvcRtnCd1 = BCH_InvokeService(EPBUPD2,&R04326,&A04326,SERVICE_ID_04326,1,sizeof(_R04326_APPL_AREA));

         if (nSvcRtnCd1 != ARC_SUCCESS)
            {
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS04326");
            BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_WriteDlmaticRecord");
            }


         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04325");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_WriteDlmaticRecord");
      }

}


/******************************************************************
**                                                               **
** Function Name:   DPM_3100_ReadDlmaticRecord                   **
**                                                               **
** Description:     Select a record on the Deltamatic table.     **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_3100_ReadDlmaticRecord()
{

   /**** Initialize request and answer blocks ****/
   memset(&R04323.R04323_appl_area, LOW_VALUES, sizeof(_R04323_APPL_AREA));
   memset(&A04323.A04323_appl_area, LOW_VALUES, sizeof(_A04323_APPL_AREA));

   /**** Format request block ****/
   strcpy(R04323.R04323_appl_area.sPprNbr, R04325.R04325_appl_area.sPprNbr);
   strcpy(R04323.R04323_appl_area.sNrevNbr, R04325.R04325_appl_area.sNrevNbr);
   strcpy(R04323.R04323_appl_area.sPassTypCd, R04325.R04325_appl_area.sPassTypCd);
   R04323.R04323_appl_area.cEmplArRecInd = R04325.R04325_appl_area.cEmplArRecInd;

   /**** Execute service to select record on the Deltamatic table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R04323,&A04323,SERVICE_ID_04323,1,sizeof(_R04323_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04323");
         BCH_FormatMessage(3,TXT_PPR,WS.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3100_ReadDlmaticRecord");
      }

}

/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void DPM_4920_ProcessLUW()
{
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{

   sprintf(sErrorMessage, "Processed %d PPRs and %d nrev psgrs with a one month anniversary.",
                           RS.nOneMonthPprCnt, RS.nOneMonthNrevCnt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "Processed %d PPRs and %d nrev psgrs with a yearly anniversary.",
                           RS.nYrPprCnt, RS.nYrNrevCnt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

}
