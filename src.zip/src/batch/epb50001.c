/*######################################################################*/
/*                                                                      */
/* Copyright [2001] Delta Air Lines, Inc./Delta Technology, Inc.        */
/*                       All Rights Reserved                            */
/*               Access, Modification, or Use Prohibited                */
/* Without Express Permission of Delta Air Lines or Delta Technology.   */
/*                                                                      */
/*######################################################################*/
/*                                                                         **
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    <EPB50001.c>                                           **
**                                                                         **
** Shell Used:      <shltmpc.c>                                            **
**                                                                         **
** Program Type:    Transaction Driven Process Module                      **
**                                                                         **
**                  Gayle Melton                                           **
**                                                                         **
** Date Written:    9/95                                                   **
**                                                                         **
** Description:     Transaction driven process modules read an input       **
**                  file record by record.  The module will perform        **
**                  some action on each input record (e.g. update          **
**                  database table).                                       **
**                  This module performs the daily load/update of the      **
**                  daily HR change data into the Pass System database.    **
**                  Data sent from the Delta, TransQuest, and Worldspan    **
**                  HR systems, from the HR Client Interface Table, and    **
**                  the process to detect children changing from dependent **
**                  to nondependent status has been combined into one file **
**                  and sorted by PPR number/nonrev number.                **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 4/15/96    G. Melton          -----    Corrected error in TPM_4535...   **
**                                        the indicator nChgToIneligible   **
**                                        was inadvertently being set to   **
**                                        TRUE, thus causing a record to be**
**                                        written to t_deltamatic when it  **
**                                        shouldn't be.                    **
**                                                                         **
**                                        Also changed processing which    **
**                                        wrote a comment for deceased C2s **
**                                        when the designee status action  **
**                                        code was 'DD'.  This was         **
**                                        originally supposed to indicate  **
**                                        deceased designees, but since    **
**                                        deceased C2s can't be identified **
**                                        as such by the Delta HR interface,*
**                                        the INELIGIBLE_COMMENT will be   **
**                                        written instead.                 ** 
**                                                                         **
** 4/17/96    G. Melton          _____    Now writing Future Dated Records **
**                                        out to a separate file, which    **
**                                        will be reprocessed daily.       **
**                                                                         **
** 4/24/96    G. Melton          _____    Added code to correctly write    **
**                                        comments for deceased designees  **
**                                        when the designee status action  **
**                                        code is "DD", "DS", "PT", "DC".  **
**                                        Also added code to correctly     **
**                                        revoke and write a comment for   **
**                                        someone changing from "SP" to    **
**                                        "XX" - ex-spouses.               **
**                                                                         **
**                                                                         **
** 6/05/96    G. Melton          _____    Corrected processing error in    **
**                                        both places where nonrevs can    **
**                                        be unrevoked - TPM_04530...,     **
**                                        & TPM_04540...  SET PASS STATUS. **
**                                        Program was not always unrevok-  **
**                                        ing all pass riders when chang-  **
**                                        ing back to an active group.     **
**                                        (changed the if.. statement)     **
**                                                                         **
** 6/12/96    G. Melton          _____    Added error reports to be sent   **
**                                        back to each HR system.  The     **
**                                        possible errors are:             **
**                                                                         **
**                                        1 - Incorrect NAME format        **
**                                        2 - Unknown Group or Type        **
**                                        3 - Record Type not A1 or C2     **
**                                        4 - Invalid Start Date           **
**                                        5 - Allotments not set           **
**                                        6 - Invalid Pass Gp/ Psgr Type   **
**                                        7 - PPR Not Found                **
**                                        8 - Nrev Passenger Not Found     **
**                                        9 - Invalid Date of Birth        **
**                                                                         **
**                                        Also made a change so that if    **
**                                        address line 1 is spaces, store  **
**                                        the station code there, and if   **
**                                        address line 2 is spaces, store  **
**                                        the department code there on the **
**                                        PPR record.                      **
**                                                                         **
** 8/08/96    G. Melton          _____    Corrected the following probs:   **
**                                        In TPM_4530..., under SET PASS   **
**                                        STATUS, corrected setting of     **
**                                        nUnRevokedInd.  Under Write      **
**                                        New Pass Card record, if not     **
**                                        TQ or WS, should be set to A/N - **
**                                        not A/P.                         **
**                                                                         **
**                                        Skip name and date audits on     **
**                                        Delete records only.             **
**                                                                         **
**                                        Added logic to write to the Audit**
**                                        Trail table whenever a person is **
**                                        Revoked or UnRevoked.            **
**                                                                         **
**                                        Added logic to set a new field   **
**                                        on the nrev passenger table      **
**                                        (cNrevPassChgInd) to 'Y' when    **
**                                        this process revokes a passenger.**
**                                        If this field is not set to 'Y'  **
**                                        when this process needs to un-   **
**                                        revoke a passenger, the pass     **
**                                        status is not changed.(This means**
**                                        that the Pass Bureau did the     **
**                                        Revoking or Suspending.)         **
**                                                                         **
**                                        When unrevoking a parent, if     **
**                                        there are already two active or  **
**                                        suspended parents, the parent is **
**                                        not unrevoked.  A record is      **
**                                        written to the error report so   **
**                                        the appropriate Pass Bureau can  **
**                                        look at the person.              **
**                                                                         **
**                                        Populate two new fields on the   **
**                                        PPR table (uPprStrtMo,           **
**                                        uPprStrtDy) when inserting or    **
**                                        updating a PPR record.           **
**                                                                         **
**                                        When the input record is for a   **
**                                        deceased PPR (i.e., the status   **
**                                        action code on the detail record **
**                                        is 'TH'), add 30 days to today's **
**                                        date and write that date to the  **
**                                        effective date field on the      **
**                                        detail record.  This will cause  **
**                                        the record to be written to the  **
**                                        future file to wait 30 days to   **
**                                        be processed.                    **
**                                                                         **
**                                        This program will now bypass any **
**                                        records that come across with a  **
**                                        pass group code of 'YY'.         **
**                                                                         **
**                                                                         **
** 9/13/96    G. Melton          _____    Corrected the following probs:   **
**                                                                         **
**                                        TPM_4530...When resetting pass   **
**                                        status, if nPprRevoked was       **
**                                        TRUE, was setting the psgr being **
**                                        processed back to their previous **
**                                        status.  This meant that a       **
**                                        revoked PPR would never be       **
**                                        unrevoked, even when eligible.   **
**                                        This check was removed.          **
**                                                                         **
**                                        TPM_4540...Removed the check for **
**                                        valid pass gp/psgr type.  This   **
**                                        must be true, or you wouldn't    **
**                                        be here.  Removed the correspond-**
**                                        ing else logic.                  **
**                                                                         **
**                                        both functions:  changed the     **
**                                        parent check so that if there    **
**                                        are already two active or sus-   **
**                                        pended parents, and the current  **
**                                        parent is revoked, a record is   **
**                                        written to the error report, and **
**                                        the parent status is unchanged.  **
**                                        (this is a modification of the   **
**                                        change made last time)           **
**                                                                         **
**10/18/96    G. Melton          _____    Corrected the following probs:   **
**                                        TPM_4530, TPM_4540...when someone**
**                                        is unrevoked, and nothing else   **
**                                        changed that affects pass cards, **
**                                        get the most current pass card   **
**                                        record.  If it exists, update    **
**                                        the card_sts_ind to 'A'.         **
**                                        Otherwise, insert a new record   **
**                                        with 'A' and 'N'.                **
**                                                                         **
**                                        Also, in TPM_4540, when checking **
**                                        status, if nPprRevoked is TRUE,  **
**                                        added a check to see if the      **
**                                        record being processed is the    **
**                                        ppr's record.  If so, go to the  **
**                                        else, so the ppr can be un-      **
**                                        revoked.  This was causing these **
**                                        pprs to never be unrevoked.      **
**                                                                         **
**10/22/96    G. Melton          _____    Corrected the following probs:   **
**                                        TPM_4315:    if the pass group   **
**                                        or hire date changed, and the    **
**                                        new group is one of the ready    **
**                                        reserve groups, set the months of**
**                                        service to zero.  If not, re-    **
**                                        calculate the months of service. **
**                                        If the hire date and pass group  **
**                                        did not change, reset the months **
**                                        of service to the previous value.**
**                                                                         **
**10/25/96    G. Melton          _____    Corrected the following probs:   **
**                                        previous change to TPM_4315 -    **
**                                        changed it back so that ready    **
**                                        reserves have their months of    **
**                                        service recalculated like        **
**                                        everyone else.                   **
**                                                                         **
**                                                                         **
**01/22/97    G. Melton          _____    Corrected the following probs:   **
**                                        Added counters for A1 & C2 recs, **
**                                        and write these counts out to    **
**                                        message log.                     **
**                                        Changed ADD processing to not    **
**                                        perform the allotment or pass    **
**                                        card functions if adding someone **
**                                        as revoked (A1 & C2).  This was  **
**                                        causing people who were          **
**                                        originally added as revoked ('XX'**
**                                        pass group) to never get a pass  **
**                                        card, because when a person is   **
**                                        unrevoked, their previous pass   **
**                                        card is reactivated as processed,**
**                                        if it exists.  If it is not      **
**                                        present, a record is inserted,   **
**                                        thus ordering a card.            **
**                                        When a person is unrevoked,      **
**                                        allotments are automatically     **
**                                        recalculated.                    **
**                                                                         **
**                                                                         **
**08/22/97    L. Scott           _____    Corrected the following problem: **
**                                        Added logic to check for less    **
**                                        than 1 year of service when      **
**                                        calculating revoke date of people**
**                                        in pass groups 'MD' and 'DS'.    **
**                                        Also check for source code of    **
**                                        'TQ' when creating future date   **
**                                        records.                         ** 
**                                                                         **
**2/3/98      S. Makim           ------   Changed pass card ordering       **
**                                        process for Delta Technology     **
**                                        employees to be the same as Delta**
**                                        employees. e.g. Current date will**
**                                        be put as card issue date.       **
**                                                                         **
**2/20/98     S. Makim           ------   Do not order any more pass card  **
**                                        for ppr_nbr starting with "TQ".  **
**                                                                         **
**4/22/98     S. Makim           ------   Added processing for Delta       **
**                                        Staffing services employees.     **
**                                        Module now produces error report **
**                                        for this new feed. CSR # is      **
**                                        7981.                            **
**                                                                         **
**7/24/98     S. Makim           ------   Added processing for F&F and A&B **
**                                        certificates. When we receive    **
**                                        add records, we will populate    **
**                                        ppr_ff_ind and ppr_ab_ind fields **
**                                        in ppr table based on the pass   **
**                                        group code. If ppr is elligible  **
**                                        for F&F certificates, records    **
**                                        will be created in t_flt_certft  **
**                                        table.                           **
**                                                                         **
**                                        When we receive records for      **
**                                        deceased employee or terminated  **
**                                        employees, module will blacklist **
**                                        all of the certificates issued   **
**                                        to the employee which are not    **
**                                        yet used.                        **
**                                                                         **
**                                        For pass group change records for**
**                                        employee, module will reset      **
**                                        ppr_ff_ind and ppr_ab_ind in     **
**                                        ppr table for the employee.      **
**                                                                         **
**10/08/98    S. Makim           ------   Bug fixes for Survivors. Issue   **
**                                        certificate for current year if  **
**                                        anniversary date is already      **
**                                        passed or it is comming within   **
**                                        next 30 days. Issue for last year**
**                                        if anniversary is comming after  **
**                                        30 days.                         **
**                                                                         **
**01/20/99    L. Scott           -------  Fix for writing future dated     **
**                                        records for deceased employees.  **
**                                        Added where the effective date   **
**                                        will now be written to buffer    **
**                                        prior to writing to file.        **
**                                                                         **
**02/03/99    LSW                         Removed conditional if statement **
**                                        in TPM_7530_CreateFAndFCertRecord**
**                                        function so processing is done on**
**                                        all groups. Added '=' check for  **
**                                        nDayDiff check.                  ** 
**                                        Also, modified                   **
**                                        TPM_7005_CalculateMonthsSvc and  **
**                                        TPM_7006_CalculateEffMonthsSvc   **
**                                        to use the CCYY value instead of **
**                                        using YY.                        **
**                                                                         **
**02/05/99    LSW                         Move if condition for flight     **
**                                        certificate processing.  Record  **
**                                        will not be processed if start   **
**                                        date is greater than current date**
**                                                                         **
**06/14/99    LAS                         Added code to process companion  **
**                                        non-revenue type passenger codes **
**                                        enabling single pprs to name a   **
**                                        travel companion and allows      **
**                                        married pprs to name a travel    **
**                                        companion in place of a spouse.  **
**                                                                         **
**08/08/99    JPR                         Removed service 2439 (not called)**
**                                                                         **
**08/08/99    JPR                         Removed service 2484 update      **
**                                        comment as SEQ_ID is auto-added  **
**                                        and duplicate cannot happen      **
**                                                                         **
**11/16/99    LAS                         Increased the number of Family   **
**                                        and Friends Certificates for all **
**                                        eligible members from 4 to 8;    **
**                                        also increased extension numbers **
**                                        from 60 - 90.                    **
**                                        Also:                            **
**                                        Removed code that checks intertax**
**                                        number for Furloughed group to   **
**                                        determine if imputed indicator   **
**                                        is set; processing should default**
**                                        to the pass group which is 'T'   **
**                                        for ticketed.                    **
**                                                                         **
**04/05/00    LAS                         For the above intertax number    **
**                                        change added setting cImputedInd **
**                                        to 'N' and also removed an 'if'  **
**                                        statement that was causing nonrev**
**                                        record imputed indicators to be  **
**                                        set to 'Y' when not imputed.     **
**                                                                         **
**                                        Also added code to force nonrev  **
**                                        day mileage and next period day  **
**                                        mileage indicators to 'D' for    **
**                                        days on all companion adds.      **
**                                                                         **
**05/15/00   LAS                          Added code to the furloughed (FU)**
**                                        logic to check the benefit end   **
**                                        date on the input record for a   **
**                                        valid date. If one exist then    **
**                                        use that date for the benefit end**
**                                        date otherwise calculate the     **
**                                        benefit end date.                **
**                                                                         **
**06/27/00   LSW                          Made changes for problem with    **
**                                        allotments for rehires not being **
**                                        reset correctly                  **
**                                        Modified the setting of the      **
**                                        cNrevPassChgInd for the request  **
**                                        block so it would get its value  **
**                                        from its answer block in         **
**                                        TPM_4530_FormatNrevUpdtFromCursor**
**                                        In TPM_7480_UpdateAllotments     **
**                                        added the setting of the         **
**                                        lUsedAllotMi to 0000000 and      **
**                                        nUsedAllotDy to 000 when the     **
**                                        cHireDtChgInd is equal to 'Y'    **
**                                        Added the initializing of the    **
**                                        cCpInd to 'N' in                 **
**                                        TPM_4540_FormatUpdateNrevSinglePsgr**
**                                        In TPM_5505_DetermineTypeOfChange**
**                                        changed memcmp for name change   **
**                                        check to use the DTL_REC.sPsgrNm **
**                                        length in the strlen function    **
**                                                                         **
**                                                                         **
**07/13/00   LSW                          Modified 7005_CalculateMonthsSvc **
**                                        and 7006_CalculateEffMonthsSvc   **
**                                        to check for 30 days of service  **
**                                        and to check for partial month   **
**                                        when calculating months of service**
**                                        completed.                       **
**                                                                         **
**07/26/00   LAS                          Modified statement to prevent ASA**
**                                        companions from being added.     **
**                                                                         **
**08/02/00   LAS                          Added code to process Comair     **
**                                        employees; nonrev source code is **
**                                        "OH"                             **
**                                        Changed code to allow ASA and    **
**                                        Comair to receive Family and     **
**                                        Friends Certifcates, and to have **
**                                        companion and non-dependent pass **
**                                        riders.                          **
**                                                                         **
**08/07/00   LSW                          Modified conditional logic       **
**                                        for if statement in              **
**                                        TPM_4530_FormatNrevUpdtFromCursor**
**                                        and TPM_4540_FormatUpdateNrevSinglePsgr**
**                                        to only use 4309 for checking for**
**                                        Spouse or Companion for the current**
**                                        record being processed.          **
**                                        Added sArchLastUpdtTs parameter  **
**                                        to 4710 service. The time stamp is**
**                                        used to determine whether to keep**
**                                        the Companion as active or to make**
**                                        the Spouse active when both records**
**                                        are processed on the same day.   **
**                                        Added conditional logic to       **
**                                        TPM_4540_FormatUpdateNrevSinglePsgr**
**                                        when checking for a active or    ** 
**                                        revoked Companion or Spouse. To  **
**                                        determine whether to keep the    **
**                                        Companion active.  Also revokes the**
**                                        current active Companion or Spouse**
**                                        if the new Companion or Spouse   **
**                                        will be made active.             **
**                                                                         **
**  08/09/00 LSW                          Remove revoking of Companion and **
**                                        activating of Spouse condition   **
**                                        when processing a Spouse change  **
**                                        record.                          **
**                                        Added condition for activating   **
**                                        Spouse when there is no active   **
**                                        Companion for an existing Spouse.**
**                                                                         **
**  08/17/00 LAS                          Removed code that prevented new  **
**                                        hires and suriviors from getting **
**                                        8 family and friends certificates**
**                                        when they should have only recieved**
**                                        4.   This code is no longer valid**
**                                                                         **
**  10/03/00 LAS                          Removed ! from beginning of strcmp**
**                                        putting !=0 after the comparison  **
**                                        to correct problem where 'FU' recs**
**                                        were not calculating correct      **
**                                        revoke dates.                     **
**                                                                          **
**  11/02/00 LAS                          Changed service number from 2383  **
**                                        to 2384 in line 2190.             **
**                                                                          **
**  02/05/01 LSW			  Added logic for S1R reward        **
**                                        processing. New pass_typ_cd (15). **
**                                                                          **
**  07/24/01 LAS                          When moving from an active pass   **
**                                        group to the retiree group "RR"   **
**                                        remove the S1R allotments.  Those **
**                                        employees retiring before 05/01/01**
**                                        are eligible to keep them.        **
**                                        Also, made changes to keep the S1R**
**                                        allotment type even when the      **
**                                        remaining days go to zero.  They  **
**                                        will only be removed when going   **
**                                        to a pass group without S1Rs or   **
**                                        when the removal date in the year **
**                                        2003 is reached.                  **
**                                                                          **
** 10/02/01 LAS                           Added code to include pass group  **
**                                        "VR" (Voluntary Severance Dl      **
**                                        Recovery) when checking for FU    **
**                                        pass group changes.               **
**                                                                          **
** 11/21/01 LAS                           Updated code that looked at "RR"  **
**                                        pass group when checking S1R days **
**                                        since a decision was made to allow**
**                                        all retirees to keep the S1R days **
**                                        until the 2003 expiration date.   **

** 11/27/01 LAS                           Added code to include pass group  **
**                                        "FP" (Furloughed Pilot) when      **
**                                        checking for "FU" pass group      **
**                                        changes.                          **
**                                                                          **
** 01/02/02 EJS                           Added code to not issue pass      **
**                                        cards for interns - pass group    **
**                                        'IN'                              **
**                                                                          **
** 09/05/02 LAS                           When processing employee revoked  **
**                                        due to death records make the     **
**                                        effective date 30 days greater    **
**                                        than the current date.            **
**                                                                          **
** 02/07/03 LAS                           Corrected logic where a check was **
**                                        done to compare the current year  **
**                                        to 2003 and the start month less  **
**                                        the current month before deleting **
**                                        remaining allotments.             **
**                                                                          **
** 02/10/03 LAS                           Added code for Song employees.    **
**                                                                          **
** 08/06/03 LAS                           Added code for Academy, SkyWest,  **
**                                        ACA and Chautauqua employees.     **
**                                                                          **
** 05/17/04 LAS                           Added furloughed merit "TM" to the**
**                                        furloughed processing.            **
**                                                                          **
** 05/27/04 LAS                           Force all ACA pass cards to show  **
**                                        as processed, so that they are not**
**                                        ordered.                          **
**                                                                          **
** 11/30/04 LAS                           Added code to create revoke dates **
**                                        for people in T8 status based on  **
**                                        the effective date plus the number**
**                                        of years of service.              **
**                                                                          **
** 05/18/05 LAS                           Added code to update the new      **
**                                        buddy pass nonrev records and the **
**                                        buddy pass table.                 **
**                                                                          **
** 01/09/06 EJS                           ESS3A added logic for deactivate  **
**                                        /reactivate                       **
**                                                                          **
** 02/12/07 LAS                           Added code for BigSky and Express **
**                                        Jet employees.                    **
**                                                                          **
** 05/10/07 LAS                           Added code for Domestic Partners  **
**                                                                          **
** 09/18/07 LAS                           Added code for Pinnacle employees.**
**                                                                          **
** 05/06/08 LAS                           For TO pass group if T1 status,   **
**                                        the revoke date is based off years**
**                                        of service, where year is from    **
**                                        Dec 31st of the current year.     **
**                                                                          **
** 05/21/08 LAS                           Make domestic partners of Skywest **
**                                        and ASA ticketed.                 **
**                                                                          **
** 07/11/08 LAS                           Add Northwest employees as        **
**                                        Connection Carrier employees.     **
**                                                                          **
** 11/22/08 LAS                           Added Skywest Non-Delta Dedidcated**
**                                        Employees.  These start with ppr  **
**                                        number "41" and are in pass group **
**                                        "CY".                             **
**                                                                          **
** 12/10/08 LAS                           Added code for Mesaba employees.  **
**                                                                          **
** 03/30/09 LAS                           Added code for new Pass policy    **
**                                        for the combined Delta and NW.    **
**                                        Also added code for Compass and   **
**                                        MLT employees.                    **
**                                                                          **
** 09/08/09 MLL                           Added code for Regional Elite emps**
**                                                                          **
** 12/07/09 LAS                           If changing to a pass group of    **
**                                        one of the retiree, severanced,   **
**                                        furloughed groups or "XX" then the**
**                                        eligibility indicators in the     **
**                                        nrap_ppr_elgy table are set to    **
**                                        "N" and the records in nrap_bkg   **
**                                        table are deleted for the ppr.    **
**                                                                          **
** 01/20/2010 GLW                         Change Skywest DP to imputed      **
**                                                                          **
** 02/10/2010 LAS                         If the employee is an expatriate  **
**                                        and the staion is international   **
**                                        then the domestic partner is      **
**                                        imputed.  Otherwise, all domestic **
**                                        partners of international station **
**                                        employees are neither imputed or  **
**                                        ticketed.                         **
**                                        Also when adding a new ppr record **
**                                        a check was added for a 2/29 hire **
**                                        date in the buddy pass processs.  **
**                                                                          **
**                                        When the last name is only one    **
** 02/25/2010 LAS                         character append "MR" in front of **
**                                        the letter and store in the ppr   **
**                                        and nrev tables.                  **
**                                                                          **
** 03/08/2010 GLW                         Change ASA,Chautauqua,Freedom     **
**                                        Pinnacle,Shuttle DP to imputed    **
**                                                                          **
** 12/08/2010 BBE                         Adding code for Pass Groups "JK", **
**                                        "JM","JS" for Ready Reserves and  **
**                                        "CV" for DLConx retired not owned **
**                                        and not ZED eligible.  No changes **
**                                        were required for Compass and     **
**                                        Mesaba because they were changing **
**                                        pass groups and HR systems.       **
**                                                                          **
** 03/31/2011 GLW                         Adding code so that if imputed    **
**                                        indicator is changed to 'E' using **
**                                        Pass 2000 the HR interface will   **
**                                        not reset.                        **
**                                                                          **
** 11/08/2011 BBE                         Added code for GoJet employees    **
**                                                                          **
** 06/30/2013 GLW                         Add code set DTL_REC.sSlrySclId   **
**                                        to space for Pinnacle, Compass,   **
**                                        GoJet, ExpressJet, Skywest        **
**                                        Chautauqua and Shuttle America.   **
**                                                                          **
**                                        Use only the first 9 digits for   **
**                                        DTL_REC.sAltId                    **
**                                                                          **
** 06/11/2014 BBE                         Commented out code that forces    **
**                                        DP, CD, and SD's for DS and CA    **
**                                        source codes to Ticketed.  Per    **
**                                        Carol Smart, they should be       **
**                                        imputed.                          **
**                                                                          **
**                                        Also commented out code that      **
**                                        forced pprs in the disabled pass  **
**                                        groups of DA,DB,DS,MD to stay in  **
**                                        those groups when a change came   **
**                                        across for a retiree pass group.  **
**                                        Per Carol Smart, they can change  **
**                                        to the retiree groups now.        **
** 10/27/2014 GLW                         Update to process Air Wisonsin    **
**                                        Reuse Song Report module epb50017 **
****************************************************************************/

#include "epb50001.h"


main()
{
   BCH_Init("EPB50001", NUMBER_OF_THREADS);

   TPM_1000_Initialize();

   TPM_2000_Mainline();
}

void writetolog(char x[], char y)
{
   FILE *fp = fopen("GWlog.txt","a");
   fprintf(fp,"%s%c\n",x,y);
   fclose(fp);
}


void writetologX(char x[], char y[])
{
   FILE *fp = fopen("GWlog.txt","a");
   fprintf(fp,"%s%s\n",x,y);
   fclose(fp);
}

/******************************************************************
**                                                               **
** Function Name:   TPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_1000_Initialize()
{

   short    nRptIndex,                 /* Report index */
            nReqRptInd1 = FALSE,       /* Required report #1 indicator */
            nReqRptInd2 = FALSE,       /* Required report #2 indicator */
            nReqRptInd3 = FALSE,       /* Required report #3 indicator */
            nReqRptInd4 = FALSE;       /* Required report #4 indicator */
 
 
 /**** Initialize counters & accumulators ***/


   RS.EPBF010_record_cntr = 0;
   RS.EPBF030_record_cntr = 0;
   RS.A1_record_cntr = 0;
   RS.C2_record_cntr = 0;
   RS.add_ppr_record_cntr = 0;
   RS.add_nrev_record_cntr = 0;
   RS.updt_ppr_record_cntr = 0;
   RS.updt_nrev_record_cntr = 0;
   RS.max_parent_record_cntr = 0;
   RS.records_not_processed = 0;

 /**** Initialize flags ****/

 /**** Initialize RSAM variables ****/
   memset(RS.sLastPprNbr, LOW_VALUES, sizeof(RS.sLastPprNbr)); 

 /**** Initialize Message Request and Answer Copybooks ***/
   memset(&R02383, LOW_VALUES, sizeof(_R02383));
   memset(&A02383, LOW_VALUES, sizeof(_A02383));
   memset(&R02384, LOW_VALUES, sizeof(_R02384));
   memset(&A02384, LOW_VALUES, sizeof(_A02384));
   memset(&R02388, LOW_VALUES, sizeof(_R02388));
   memset(&A02388, LOW_VALUES, sizeof(_A02388));
   memset(&R02389, LOW_VALUES, sizeof(_R02389));
   memset(&A02389, LOW_VALUES, sizeof(_A02389));
   memset(&R02438, LOW_VALUES, sizeof(_R02438));
   memset(&A02438, LOW_VALUES, sizeof(_A02438));
   memset(&R02441, LOW_VALUES, sizeof(_R02441));
   memset(&A02441, LOW_VALUES, sizeof(_A02441));
   memset(&R02443, LOW_VALUES, sizeof(_R02443));
   memset(&A02443, LOW_VALUES, sizeof(_A02443));
   memset(&R02444, LOW_VALUES, sizeof(_R02444));
   memset(&A02444, LOW_VALUES, sizeof(_A02444));
   memset(&R02445, LOW_VALUES, sizeof(_R02445));
   memset(&A02445, LOW_VALUES, sizeof(_A02445));
   memset(&R02475, LOW_VALUES, sizeof(_R02475));
   memset(&A02475, LOW_VALUES, sizeof(_A02475));
   memset(&R02483, LOW_VALUES, sizeof(_R02483));
   memset(&A02483, LOW_VALUES, sizeof(_A02483));
   memset(&R02529, LOW_VALUES, sizeof(_R02529));
   memset(&A02529, LOW_VALUES, sizeof(_A02529));
   memset(&R02561, LOW_VALUES, sizeof(_R02561));
   memset(&A02561, LOW_VALUES, sizeof(_A02561));
   memset(&R02564, LOW_VALUES, sizeof(_R02564));
   memset(&A02564, LOW_VALUES, sizeof(_A02564));
   memset(&R02567, LOW_VALUES, sizeof(_R02567));
   memset(&A02567, LOW_VALUES, sizeof(_A02567));
   memset(&R02645, LOW_VALUES, sizeof(_R02645));
   memset(&A02645, LOW_VALUES, sizeof(_A02645));
   memset(&R02760, LOW_VALUES, sizeof(_R02760));
   memset(&A02760, LOW_VALUES, sizeof(_A02760));
   memset(&R02762, LOW_VALUES, sizeof(_R02762));
   memset(&A02762, LOW_VALUES, sizeof(_A02762));
   memset(&R02763, LOW_VALUES, sizeof(_R02763));
   memset(&A02763, LOW_VALUES, sizeof(_A02763));
   memset(&R02769, LOW_VALUES, sizeof(_R02769));
   memset(&A02769, LOW_VALUES, sizeof(_A02769));
   memset(&R02861, LOW_VALUES, sizeof(_R02861));
   memset(&A02861, LOW_VALUES, sizeof(_A02861));
   memset(&R02865, LOW_VALUES, sizeof(_R02865));
   memset(&A02865, LOW_VALUES, sizeof(_A02865));
   memset(&R03834, LOW_VALUES, sizeof(_R03834));
   memset(&A03834, LOW_VALUES, sizeof(_A03834));
   memset(&R04000, LOW_VALUES, sizeof(_R04000));
   memset(&A04000, LOW_VALUES, sizeof(_A04000));
   memset(&R04003, LOW_VALUES, sizeof(_R04003));
   memset(&A04003, LOW_VALUES, sizeof(_A04003));
   memset(&R04025, LOW_VALUES, sizeof(_R04025));
   memset(&A04025, LOW_VALUES, sizeof(_A04025));
   memset(&R04036, LOW_VALUES, sizeof(_R04036));
   memset(&A04036, LOW_VALUES, sizeof(_A04036));
   memset(&R04118, LOW_VALUES, sizeof(_R04118));
   memset(&A04118, LOW_VALUES, sizeof(_A04118));
   memset(&R04187, LOW_VALUES, sizeof(_R04187));
   memset(&A04187, LOW_VALUES, sizeof(_A04187));
   memset(&R04309, LOW_VALUES, sizeof(_R04309));
   memset(&A04309, LOW_VALUES, sizeof(_A04309));
   memset(&R04323, LOW_VALUES, sizeof(_R04323));
   memset(&A04323, LOW_VALUES, sizeof(_A04323));
   memset(&R04325, LOW_VALUES, sizeof(_R04325));
   memset(&A04325, LOW_VALUES, sizeof(_A04325));
   memset(&R04326, LOW_VALUES, sizeof(_R04326));
   memset(&A04326, LOW_VALUES, sizeof(_A04326));
   memset(&R04477, LOW_VALUES, sizeof(_R04477));
   memset(&A04477, LOW_VALUES, sizeof(_A04477));
   memset(&R04478, LOW_VALUES, sizeof(_R04478));
   memset(&A04478, LOW_VALUES, sizeof(_A04478));
   memset(&R04586, LOW_VALUES, sizeof(_R04586));
   memset(&A04586, LOW_VALUES, sizeof(_A04586));
   memset(&R04603, LOW_VALUES, sizeof(_R04603));
   memset(&A04603, LOW_VALUES, sizeof(_A04603));
   memset(&R04604, LOW_VALUES, sizeof(_R04604));
   memset(&A04604, LOW_VALUES, sizeof(_A04604));
   memset(&R04654, LOW_VALUES, sizeof(_R04654));
   memset(&A04654, LOW_VALUES, sizeof(_A04654));
   memset(&R04710, LOW_VALUES, sizeof(_R04710));
   memset(&A04710, LOW_VALUES, sizeof(_A04710));
   memset(&R04730, LOW_VALUES, sizeof(_R04730));
   memset(&A04730, LOW_VALUES, sizeof(_A04730));
   memset(&R04731, LOW_VALUES, sizeof(_R04731));
   memset(&A04731, LOW_VALUES, sizeof(_A04731));

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_1000_Initialize");

   /**************************************************/ 
   /** set up today's date in CCYYMMDD format       **/ 
   /**************************************************/ 
   memset(&RS.sTodayDt, LOW_VALUES, sizeof(RS.sTodayDt));
   strncpy(RS.sTodayDt, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD), sizeof(RS.sTodayDt));

 /**** Check for Mandatory Report requests ****/
 /**** NOTE: Add an if() for all mandatory reports (the module will not execute ****/
 /**** NOTE:     if all required reports are not present).                      ****/

       writetolog(RS.sTodayDt ,'1');


 /**** EPB50011 - DL Error Report ****/
 /**** EPB50012 - WS Error Report ****/
 /**** EPB50013 - TQ ERror Report ****/
 /**** EPB50014 - DS Error Report ****/
 /**** EPB50015 - AS Error Report ****/
 /**** EPB50016 - OH Error Report ****/
 /**** EPB50017 - ZW Error Report ****/
 /**** EPB50018 - CA Error Report ****/
 /**** EPB50019 - OO Error Report ****/
 /**** EPB50020 - DH Error Report ****/
 /**** EPB50021 - RP Error Report ****/
 /**** EPB50022 - S5 Error Report ****/
 /**** EPB50023 - F8 Error Report ****/
 /**** EPB50024 - GQ Error Report ****/
 /**** EPB50025 - XE Error Report ****/
 /**** EPB50026 - 9E Error Report ****/
 /**** EPB50027 - NW Error Report ****/
 /**** EPB50027 - MN Error Report ****/
 /**** EPB50028 - XJ Error Report ****/
 /**** EPB50029 - CP Error Report ****/
 /**** EPB50030 - ML Error Report ****/
 /**** EPB50031 - RS Error Report ****/
 /**** EPB50032 - G7 Error Report ****/

      writetolog(RS.sTodayDt ,'2');

 /*** Perform any pre-processing on request entries ****/   
 /*** Here is where you would do any pre-processing of request entries ***/
 /*** e.g. validation or substitution of default values, such as  ***/
 /*** current date, for values not filled in in the request, etc. ***/

   /************************************************************************/
   /*********** Call RSAM to open each file that is used for input *********/
   /************************************************************************/

   RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_READ);
   if (RS.EPBF010 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_1000_Initialize");
   }

   /************************************************************************/
   /*********** Call RSAM to open for each file used for output  ********/
   /************************************************************************/

   /*******************************************************************/
   /************     Open file for Future Dated Records     ***********/
   /*******************************************************************/
   RS.EPBF030 = BCH_Open("EPBF030", BCH_FILE_WRITE);
   if (RS.EPBF030 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF030");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_1000_Initialize");
   }

   /*******************************************************************/
   /************     Open file for Report Records           ***********/
   /*******************************************************************/


   /*********** Call RSAM to read first input record ************/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));

   if (BCH_eof(RS.EPBF010))
   {
       BCH_FormatMessage(1,TXT_EMPTY_INPUT_FILE);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_1000_Initialize");
   }

}



/******************************************************************
**                                                               **
** Function Name:   TPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                  The main processing populates the request 	 **
**                  block for the insert into the PPR or Nrev    **
**                  table. Depending on if the record is an      **
**                  'Add' or a 'Change', if the record is an     **
**                  employee (A1) or designee (C2) record, the   **
**                  record will be inserted or updated.          **
**                  Certain fields may have to be derived before **
**                  the record is inserted or updated.  This     **
**                  includes calculating/recalculating the       **
**                  months of service completed, setting the     **
**                  Imputed Travel Indicator, and setting/       **
**                  resetting the current and remaining          **
**                  Allotments.                                  **
**                  If an the record is not valid, it will be    **
**                  posted to an error file.  The errors will    **
**                  be corrected and rerun through the module    **
**                  on the next scheduled run.                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_2000_Mainline()
{


   /*******************************************************************/
   /** Read pass allotment table and store pass type codes in array. **/
   /** These codes will be used to drive the process to make changes **/
   /** to the nonrev passenger records.                              **/
   /*******************************************************************/

   TPM_7470_StorePassTypeCodes();

   while (!BCH_eof(RS.EPBF010))
      {
      TPM_3000_ProcessFileEPBF010();
      }

   TPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);

}



/******************************************************************
**                                                               **
** Function Name:   TPM_3000_ProcessFileEPBF010                  **
**                                                               **
** Description:     Call function to process individual          **
**                  records then read next record from buffer.   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_3000_ProcessFileEPBF010()
{

   TPM_4000_ProcessFileRecords();

 /** read the next record **/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer,sizeof(RS.EPBF010_buffer)); 

 /** increment the input record counter **/
   RS.EPBF010_record_cntr++;

   TPM_8000_ProcessLUW();
}



/******************************************************************
**                                                               **
** Function Name:   TPM_4000_ProcessFileRecords                  **
**                                                               **
** Description:     Analyze record, based on first               **
**                  character of record, to determine the type   **
**                  of record (i.e. header or detail)            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_4000_ProcessFileRecords()
{

   char    cRecType;     /* Record Type Identifier   */
   char    cImputedInd;  /* Imputed Travel Indicator */
   char    sPprLstNm;
   char    sPprFrstNm;
   char    cPprMidNm;

   cPGpChgInd = 'N';
   cHireDtChgInd = 'N';
   cNameChgInd = 'N'; 
   cBdayChgInd = 'N';
   cNrevTypChgInd = 'N';
   cInttxChgInd = 'N';
   cImputedInd = 'N';
   cImputedIndChg = 'N';
   cNameError = 'N';
   cRecType = ' ';
   cErrorCode = ' ';
   cThirdParentAdded = 'N';
   cSavePrvAtvnFeeCd = ' ';
   cSaveCurAtvnFeeCd = ' ';
   cSaveNxtAtvnFeeCd = ' ';
   cServId = '0';

   strncpy(sSavePassGrpCd, "  ",sizeof(sSavePassGrpCd));
   strncpy(sName, "  ",sizeof(sName));
   strncpy(sFrstNmSpace, " ", sizeof(sFrstNmSpace));
   memset(sTempMonth,LOW_VALUES, sizeof(sTempMonth));
   memset(sTempDay,LOW_VALUES, sizeof(sTempDay));
   strncpy(sStrtMo, "  ",sizeof(sStrtMo));
   strncpy(sStrtDy, "  ",sizeof(sStrtDy));
   strncpy(sPcPprNbr, "  ",sizeof(sPcPprNbr));
   strncpy(sPcNrevNbr, "  ",sizeof(sPcNrevNbr));
   strncpy(sPcCardIssDt, "  ",sizeof(sPcCardIssDt));
   strncpy(sSavePrvAtvnLupdtLts, "  ",sizeof(sSavePrvAtvnLupdtLts));
   strncpy(sSaveCurAtvnLupdtLts, "  ",sizeof(sSaveCurAtvnLupdtLts));
   strncpy(sSaveNxtAtvnLupdtLts, "  ",sizeof(sSaveNxtAtvnLupdtLts));

   nPPRPresent = FALSE;
   nNrevPresent = FALSE;
   nValidPgpPtyp = FALSE;
   nEndOfPassType = FALSE;
   nEndOfPassRiders = FALSE;
   nEndOfRemnAllot = FALSE;
   nMaxParentInd = FALSE;
   nUpdateAll = FALSE;
   nResetAll = FALSE;
   nRvkYear = 0;
   nRvkMonth = 0;
   nRvkDay = 0;
   nPprRevoked = FALSE;
   nProcessAsRevoked = FALSE;
   nChgToIneligible = FALSE;
   nUnRevokedInd = FALSE;
   cValidateError = 'N';
   nCardIssDtChg = FALSE;
   nDateFound = TRUE;
   cValidPsgrType = 'N';
   nPcRecFound = FALSE;
   nPprFFElligible = FALSE;
   nPprABElligible = FALSE;
   nCertftQty = 0;
   nSpouseInd = FALSE;
   nCompanionInd = FALSE;
   nDomPartnerInd = FALSE;
   nSpouseRevoked = FALSE;
   nCompanionRevoked = FALSE;
   nRewardInd = FALSE;
   nRemoveRewardInd = FALSE;
   nIntlStation = FALSE;


   /********************************************************************************/
   /** Identify record type - populate RecType with record type from buffer       **/
   /********************************************************************************/
   cRecType = RS.EPBF010_buffer[0];

   /********************************************************************************/
   /** Move the data from the input record into the detail record structure       **/
   /********************************************************************************/
   TPM_4005_FormatDetailRecord();

   /*********************************************************************************************/
   /** If the input record is for a Deceased Employee - add 30 days to today's date and update **/
   /** DTL_REC.sEffDt, so that the record is written to the Future File.  This will give the   **/
   /** employee's family time to fly after the employee's death, in case they need to.         **/
   /*********************************************************************************************/

    if (((strcmp(DTL_REC.sStsActCd, DECEASED_A1) == 0) || (strcmp(DTL_REC.sStsActCd, DECEASED_A1_BG) == 0)) && ((strcmp(DTL_REC.sErrorDt,  "        ") == 0) ||
		  (strcmp(DTL_REC.sErrorDt,  " ") == 0) ||
		  (strcmp(DTL_REC.sErrorDt,  "") == 0)))
       {
    
       /** Black list F&F and A&B certificates issued to the Deceased employee **/ 
       TPM_7535_BlklstCertRecord();

       strcpy(R04118.R04118_appl_area.sPassRptSortDt, sCurrentTsDt);
       R04118.R04118_appl_area.nFltArrTm = 30;
       TPM_7008_ConvertDate();

       /** make effective date 30 days > than today's date **/

      strcpy(DTL_REC.sEffDt, UTL_ConvertDate(A04118.A04118_appl_area.sFltDprtDt, CNV_DB_TO_YYYYMMDD));
          }

   /********************************************************************************/
   /** WS/DL/TQ/DS/AS/OH/AC/OO/DH/RP/S5/F8/GQ/XE/9E/NW/XJ/CP/ML/RS/G7 file:       **/
   /** If the effective date in the input record is after today,                  **/
   /** write the record back out to the error file for processing by tomorrow's   **/
   /** run.  Records should be recycled until the effective date is reached.      **/
   /********************************************************************************/
   if ((strcmp(DTL_REC.sSourceSys, "DL") == 0) || 
       (strcmp(DTL_REC.sSourceSys, "WS") == 0) || 
       (strcmp(DTL_REC.sSourceSys, "TQ") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "DS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "OH") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "CA") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "DH") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "S5") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "GQ") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "XE") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||
     /*(strcmp(DTL_REC.sSourceSys, "NW") == 0) ||*/
       /* PPatnaik */
       (strcmp(DTL_REC.sSourceSys, "MN") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "XJ") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "ML") == 0))
      {
      if (strcmp(DTL_REC.sEffDt, RS.sTodayDt) > 0)
         {
         TPM_7001_WriteFutureDatedRec();
         cValidateError = 'Y';
         }
      }

   /********************************************************************************/
   /** Call service 3834 to read t_ppr, and set indicator                         **/
   /********************************************************************************/
   TPM_7010_CheckForPprRec();

   /********************************************************************************/
   /** Call service 4036 to read t_nrev_psgr for the ppr corresponding to the     **/
   /** input passenger, and then set an indicator to show if the PPR is           **/
   /** revoked or not.                                                            **/
   /** If input record is an A1 record, and the nrev record is found, the         **/
   /** nNrevPresent indicator is set to TRUE. Otherwise, it is set to FALSE.      **/
   /********************************************************************************/
   TPM_7025_CheckPprRevoked();
  
   /********************************************************************************/
   /** If input record is a C2 record, call service 4036 again to read the nrev   **/
   /** psgr record for the input psgr.  If the record is found, the nNrevPresent  **/
   /** indicator is set to TRUE.  Otherwise, it is set to FALSE.                  **/
   /********************************************************************************/
   if (strcmp(DTL_REC.sRecType, C2_REC) == 0)
      {
      TPM_7030_CheckForNrevRecord();
      }

   /********************************************************************************/
   /** Senior Officers come from Tesseract with regular Delta pass groups, so     **/
   /** must reset the input record pass group back to the correct Senior Officer  **/
   /** pass group before processing.                                              **/
   /** Senior Officers coming in with other than regular active pass groups       **/
   /** (AC, AK, MA) will be changed to that group.                                **/
   /*  Added Board Members for the same logic.           
   /********************************************************************************/

   if (nPPRPresent == TRUE)
      {
      if (strcmp(DTL_REC.sSourceSys, "DL") == 0)
         {
         /*******************************************/
         /** If Senior Officers - SDW Without Kids **/
         /*******************************************/
         if ((strcmp(A03834.A03834_appl_area.sPassGrpCd, SENIOR_OFFICERS) == 0) &&
            (strcmp(DTL_REC.sPassGrpCd,ACTIVE_DL_WK ) == 0))
            strcpy(DTL_REC.sPassGrpCd, SENIOR_OFFICERS_WK);
         else
         if ((strcmp(A03834.A03834_appl_area.sPassGrpCd, SENIOR_OFFICERS) == 0) &&
            (strcmp(DTL_REC.sPassGrpCd,ACTIVE_DL_MRD ) == 0))
            strcpy(DTL_REC.sPassGrpCd, SENIOR_OFFICERS_MRD);
         else
         if ((strcmp(A03834.A03834_appl_area.sPassGrpCd, SENIOR_OFFICERS) == 0) &&
            (strcmp(DTL_REC.sPassGrpCd,ACTIVE_DL) == 0))
            strcpy(DTL_REC.sPassGrpCd, SENIOR_OFFICERS);
   
         /****************************************/
         /** If Senior Officers - SDW With Kids **/
         /****************************************/
         if ((strcmp(A03834.A03834_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) == 0) &&
            (strcmp(DTL_REC.sPassGrpCd,ACTIVE_DL) == 0))
            strcpy(DTL_REC.sPassGrpCd, SENIOR_OFFICERS);
         else
         if ((strcmp(A03834.A03834_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) == 0) &&
            (strcmp(DTL_REC.sPassGrpCd,ACTIVE_DL_MRD ) == 0))
            strcpy(DTL_REC.sPassGrpCd, SENIOR_OFFICERS_MRD);
         else
         if ((strcmp(A03834.A03834_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) == 0) &&
            (strcmp(DTL_REC.sPassGrpCd,ACTIVE_DL_WK) == 0))
            strcpy(DTL_REC.sPassGrpCd, SENIOR_OFFICERS_WK);

         /****************************************/
         /** If Senior Officers - Married       **/
         /****************************************/
         if ((strcmp(A03834.A03834_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) == 0) &&
            (strcmp(DTL_REC.sPassGrpCd,ACTIVE_DL_MRD) == 0))
            strcpy(DTL_REC.sPassGrpCd, SENIOR_OFFICERS_MRD);
         else
         if ((strcmp(A03834.A03834_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) == 0) &&
            (strcmp(DTL_REC.sPassGrpCd,ACTIVE_DL ) == 0))
            strcpy(DTL_REC.sPassGrpCd, SENIOR_OFFICERS);
         else
         if ((strcmp(A03834.A03834_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) == 0) &&
            (strcmp(DTL_REC.sPassGrpCd,ACTIVE_DL_WK) == 0))
            strcpy(DTL_REC.sPassGrpCd, SENIOR_OFFICERS_WK);

         /*******************************************/
	 /**  If Board Member                       */
	 /*******************************************/
	 if ((strcmp(A03834.A03834_appl_area.sPassGrpCd, BOARD_MEMBERS) == 0) &&
	    (strcmp(DTL_REC.sPassGrpCd, RETIRED_DELTA) == 0))
             strcpy(DTL_REC.sPassGrpCd,  BOARD_MEMBERS);

/********************************************************************************/
         /** back to group code for the input record is 'WW', change the Detail Record  **/
         /** back to the ppr's current pass group and continue processing.              **/
         /** All A1 Add records for people in the 'WW' group will error out because     **/
         /** a person cannot be added in the 'WW' pass group.                           **/
         /********************************************************************************/
         if (strcmp(DTL_REC.sPassGrpCd, "WW") == 0)
            strcpy(DTL_REC.sPassGrpCd, A03834.A03834_appl_area.sPassGrpCd);

         /********************************************************************************/
         /** If input pass group is 'RR','RE', 'RL', or 'RT', and the previous pass     **/
         /** group was 'DS', or 'MD', or 'DA', 'DB'  change the Detail Record  pass  **/
	 /** group code back to the current ppr pass group and continue processing.     **/
         /********************************************************************************/
	 /*** BBE 06-17-2014 Commented out the below statement.  Per Carol Smart,      ***/
	 /*** pprs in the disabled group can be switched to retirees now.              ***/
         /***  if (((strcmp(DTL_REC.sPassGrpCd, "RR") == 0) ||                         ***/
         /***     (strcmp(DTL_REC.sPassGrpCd, "RE") == 0) ||                           ***/ 
         /***     (strcmp(DTL_REC.sPassGrpCd, "RL") == 0) ||                           ***/
         /***     (strcmp(DTL_REC.sPassGrpCd, "RT") == 0)) &&                          ***/
         /***    ((strcmp(A03834.A03834_appl_area.sPassGrpCd, "DS") == 0) ||           ***/
         /***      (strcmp(A03834.A03834_appl_area.sPassGrpCd, "MD") == 0) ||          ***/
         /***    (strcmp(A03834.A03834_appl_area.sPassGrpCd, "DA") == 0) ||            ***/
         /***      (strcmp(A03834.A03834_appl_area.sPassGrpCd, "DB") == 0)))           ***/
         /***   strcpy(DTL_REC.sPassGrpCd, A03834.A03834_appl_area.sPassGrpCd);        ***/
         }
      }

   /*#                                                                                    ##*/
   /*#                                                                                     #*/
   /*#         > > > > > >          VALIDATE INPUT RECORD          < < < < < <             #*/
   /*#                                                                                     #*/
   /*#######################################################################################*/

   /*****************************************************************************************/
   /** Validate the Pass Group/Passenger Type Code.                                        **/
   /** Initialize Service Request and Answer Blocks to select from Pass Grp/Psgr Type table**/
   /*****************************************************************************************/
   memset(&R02861, LOW_VALUES, sizeof(_R02861));
   memset(&A02861, LOW_VALUES, sizeof(_A02861));
 
   /*****************************************************************************************/
   /** if A1 (add or change or delete), use pass grp and psgr type from incoming record    **/
   /** to validate pass gp/psgr type code.                                                 **/
   /*****************************************************************************************/
   if (strcmp(DTL_REC.sRecType, A1_REC) == 0)
      {
      RS.A1_record_cntr++;
      /***********************************************************************/
      /** Format application request block for pass gp/psgr type validation **/
      /***********************************************************************/
      strcpy(sSavePassGrpCd, DTL_REC.sPassGrpCd);

      /*******************************************************************************************/
      /** initialize and then Format application request block for pass gp/psgr type validation **/
      /*******************************************************************************************/
      memset(&R02861, LOW_VALUES, sizeof(_R02861));
      strcpy(R02861.R02861_appl_area.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   
      /*************************************************/
      /** Validate the Pass Group/Passenger Type Code **/
      /*************************************************/
      TPM_7015_EvalValidPsgrType();
      }
   /*****************************************************************************************/
   /** If C2 (add or change or delete), and ppr is present, use pass grp from ppr record   **/
   /** and psgr type from incoming record to validate pass gp/psgr type code.              **/ 
   /** C2 records with a pass group different from the PPR's pass group will error.        **/
   /*****************************************************************************************/
   else
   if (strcmp(DTL_REC.sRecType, C2_REC) == 0)
      {
      RS.C2_record_cntr++;
      if(nPPRPresent == TRUE)
         {
         /*********************************************/
         /** Save the PPR's current Pass Group Code  **/
         /*********************************************/
         strcpy(sSavePassGrpCd, A03834.A03834_appl_area.sPassGrpCd);

         /**************************************************************************/
         /** If the pass rider's pass group code is the same as the ppr's,        **/
         /** continue, else the pass grp/psgr type is invalid - write to ERROR    **/
         /** REPORT.                                                              **/
         /**************************************************************************/
         if(strcmp(sSavePassGrpCd, DTL_REC.sPassGrpCd) == 0)
            {
            /********************************************************************************/
            /** initialize and then Format application request block for pass gp/psgr type **/
            /** validation                                                                 **/
            /********************************************************************************/
            memset(&R02861, LOW_VALUES, sizeof(_R02861));
            strcpy(R02861.R02861_appl_area.sNrevTypCd, DTL_REC.sPsgrTypeCd);

            /*************************************************/
            /** Validate the Pass Group/Passenger Type Code **/
            /*************************************************/
            TPM_7015_EvalValidPsgrType();
            }
         else
            nValidPgpPtyp = FALSE;
         }
      else
         {
         /************************************************/
         /** ERROR - cannot have C2 record without PPR. **/
         /** Write input record to ERROR REPORT.        **/
         /************************************************/
         cValidateError = 'Y';

         cErrorCode = '7'; 
         if (strcmp(DTL_REC.sSourceSys, DELTA) == 0) 
            {
            TPM_7611_GenerateEPB50011(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)  
            {
            TPM_7612_GenerateEPB50012(); 
            }
         else 
         if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)  
            {
            TPM_7613_GenerateEPB50013(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)  
            {
            TPM_7614_GenerateEPB50014(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, ASA) == 0) 
            {
            TPM_7615_GenerateEPB50015(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMAIR) == 0) 
            {
            TPM_7616_GenerateEPB50016(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0)
            {
            TPM_7617_GenerateEPB50017(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY) == 0) 
            {
            TPM_7618_GenerateEPB50018(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) 
            {
            TPM_7619_GenerateEPB50019(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, ACA) == 0) 
            {
            TPM_7620_GenerateEPB50020(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) 
            {
            TPM_7621_GenerateEPB50021(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) 
            {
            TPM_7622_GenerateEPB50022(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, FREEDOM) == 0) 
            {
            TPM_7623_GenerateEPB50023(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, BIG_SKY) == 0) 
            {
            TPM_7624_GenerateEPB50024(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET) == 0) 
            {
            TPM_7625_GenerateEPB50025(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, PINNACLE) == 0) 
            {
            TPM_7626_GenerateEPB50026(); 
            }
         else
	     //Manual PPR --PPatnaik
         if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0) 
            {
            TPM_7627_GenerateEPB50027(); 
            }
         else
	 
         if (strcmp(DTL_REC.sSourceSys, MESABA) == 0) 
            {
            TPM_7628_GenerateEPB50028(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMPASS) == 0) 
            {
            TPM_7629_GenerateEPB50029(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, MLT) == 0) 
            {
            TPM_7630_GenerateEPB50030(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE) == 0) 
            {
            TPM_7631_GenerateEPB50031(); 
            }
         else
         if (strcmp(DTL_REC.sSourceSys, GOJET) == 0) 
            {
            TPM_7632_GenerateEPB50032(); 
            }
         else
            {
            sprintf(sErrorMessage, "ERROR 7:  PPR must be present for C2 add/change");
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
            sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, RecType = %s",
                                    DTL_REC.cRecordId,
                                    DTL_REC.sPprNbr,
                                    DTL_REC.sDesNrevNbr,
                                    DTL_REC.sRecType);
            BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_4000_ProcessFileRecords");
            } 
         }
      }
   else
      {
      /*********************************************/
      /** Not A1 or C2 record type.               **/
      /** Write record to the ERROR REPORT.       **/
      /*********************************************/
      cValidateError = 'Y';

      cErrorCode = '3';  
      if (strcmp(DTL_REC.sSourceSys, DELTA) == 0) 
         {
         TPM_7611_GenerateEPB50011();  
         }
      else 
      if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)  
         {
         TPM_7612_GenerateEPB50012();  
         }
      else  
      if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)   
         {
         TPM_7613_GenerateEPB50013();  
         }
      else  
      if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)   
         {
         TPM_7614_GenerateEPB50014();  
         }
      else 
      if (strcmp(DTL_REC.sSourceSys, ASA) == 0) 
         {
         TPM_7615_GenerateEPB50015();  
         }
      else 
      if (strcmp(DTL_REC.sSourceSys, COMAIR) == 0) 
         {
         TPM_7616_GenerateEPB50016();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0) 
         {
         TPM_7617_GenerateEPB50017();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY) == 0) 
         {
         TPM_7618_GenerateEPB50018();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) 
         {
         TPM_7619_GenerateEPB50019();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, ACA) == 0) 
         {
         TPM_7620_GenerateEPB50020();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) 
         {
         TPM_7621_GenerateEPB50021();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) 
         {
         TPM_7622_GenerateEPB50022();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, FREEDOM) == 0) 
         {
         TPM_7623_GenerateEPB50023();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, BIG_SKY) == 0) 
         {
         TPM_7624_GenerateEPB50024();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET) == 0) 
         {
         TPM_7625_GenerateEPB50025();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, PINNACLE) == 0) 
         {
         TPM_7626_GenerateEPB50026();  
         }
      else
      
	  //Manual PPR --PPatnaik
      if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0) 
         {
         TPM_7627_GenerateEPB50027(); 
         }
      else
      if (strcmp(DTL_REC.sSourceSys, MESABA) == 0) 
         {
         TPM_7628_GenerateEPB50028();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, COMPASS) == 0) 
         {
         TPM_7629_GenerateEPB50029();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, MLT) == 0) 
         {
         TPM_7630_GenerateEPB50030();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE) == 0) 
         {
         TPM_7631_GenerateEPB50031();  
         }
      else
      if (strcmp(DTL_REC.sSourceSys, GOJET) == 0) 
         {
         TPM_7632_GenerateEPB50032();  
         }
      else
         {
         sprintf(sErrorMessage, "ERROR 3:  Record not type A1 or C2");
         BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
    
         sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, RecType = %s",
                                 DTL_REC.cRecordId,
                                 DTL_REC.sPprNbr,
                                 DTL_REC.sDesNrevNbr,
                                 DTL_REC.sRecType);
         BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_4000_ProcessFileRecords");
         }
      }  

   /************************************************************/
   /** Do not validate NAME, BirthDate, or Start Date for     **/
   /** DELETE records.  This is because audits were added     **/
   /** after the initial data load, so that some records      **/
   /** were loaded with incorrect name format and with default**/
   /** birth dates.  Skipping this audit will allow these     **/
   /** records to be deleted without erroring out.            **/
   /************************************************************/
   if (DTL_REC.cRecordId != DELETE_REC)
      {
      /************************************************************/
      /** Validate the NAME on the input record.                 **/
      /** Break out the name into last, first, middle initial.   **/
      /** Write NAME errors to the ERROR REPORT.                 **/
      /************************************************************/
      TPM_7020_ParseOutName();

      if (cNameError == 'Y')
         {  
         cValidateError = 'Y';
         cErrorCode = '1';
         if (strcmp(DTL_REC.sSourceSys, DELTA) == 0)
            {
            TPM_7611_GenerateEPB50011();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)
            {
            TPM_7612_GenerateEPB50012();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)
            {
            TPM_7613_GenerateEPB50013();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)
            {
            TPM_7614_GenerateEPB50014();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, ASA) == 0)
            {
            TPM_7615_GenerateEPB50015();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMAIR) == 0)
            {
            TPM_7616_GenerateEPB50016();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0) 
            {
            TPM_7617_GenerateEPB50017();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY) == 0)
            {
            TPM_7618_GenerateEPB50018();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0)
            {
            TPM_7619_GenerateEPB50019();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, ACA) == 0)
            {
            TPM_7620_GenerateEPB50020();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0)
            {
            TPM_7621_GenerateEPB50021();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0)
            {
            TPM_7622_GenerateEPB50022();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, FREEDOM) == 0)
            {
            TPM_7623_GenerateEPB50023();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, BIG_SKY) == 0)
            {
            TPM_7624_GenerateEPB50024();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET) == 0)
            {
            TPM_7625_GenerateEPB50025();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, PINNACLE) == 0)
            {
            TPM_7626_GenerateEPB50026();
            }
         else
	 	     //Manual PPR Added data --PPatnaik
         if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0)
            {
            TPM_7627_GenerateEPB50027();
            }
         else
	 
         if (strcmp(DTL_REC.sSourceSys, MESABA) == 0)
            {
            TPM_7628_GenerateEPB50028();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMPASS) == 0)
            {
            TPM_7629_GenerateEPB50029();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, MLT) == 0)
            {
            TPM_7630_GenerateEPB50030();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE) == 0)
            {
            TPM_7631_GenerateEPB50031();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, GOJET) == 0)
            {
            TPM_7632_GenerateEPB50032();
            }
         else
            {
            sprintf(sErrorMessage, "ERROR 1:  Incorrect NAME format");
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
            sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, NAME = %s",
                                    DTL_REC.cRecordId,
                                    DTL_REC.sPprNbr,
                                    DTL_REC.sDesNrevNbr,
                                    DTL_REC.sPsgrNm);
            BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);

            sprintf(sErrorMessage, "RecType = %s, EffDt = %s",
                                    DTL_REC.sRecType,
                                    DTL_REC.sEffDt);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_4000_ProcessFileRecords");
            }
         }   

      /*****************************************************************************************/
      /** Validate the Birth Date on the input record - if it is zeros or spaces, write it    **/
      /** to the ERROR REPORT.                                                                **/
      /*****************************************************************************************/
      if ((strcmp(DTL_REC.sBirthDt, ZERO_DATE) == 0) || 
          (strcmp(DTL_REC.sBirthDt, "") == 0))
         {
         cValidateError = 'Y';

         cErrorCode = '9';
         if (strcmp(DTL_REC.sSourceSys, DELTA) == 0) 
            {
            TPM_7611_GenerateEPB50011();  
            }
         else 
         if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)  
            {
            TPM_7612_GenerateEPB50012();  
            }
         else  
         if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)   
            {
            TPM_7613_GenerateEPB50013();  
            }
         else  
         if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)   
            {
            TPM_7614_GenerateEPB50014();  
            }
         else 
         if (strcmp(DTL_REC.sSourceSys, COMAIR) == 0) 
            {
            TPM_7616_GenerateEPB50016();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0) 
            {
            TPM_7617_GenerateEPB50017();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY) == 0) 
            {
            TPM_7618_GenerateEPB50018();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) 
            {
            TPM_7619_GenerateEPB50019();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, ACA) == 0) 
            {
            TPM_7620_GenerateEPB50020();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) 
            {
            TPM_7621_GenerateEPB50021();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) 
            {
            TPM_7622_GenerateEPB50022();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, FREEDOM) == 0) 
            {
            TPM_7623_GenerateEPB50023();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, BIG_SKY) == 0) 
            {
            TPM_7624_GenerateEPB50024();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET) == 0) 
            {
            TPM_7625_GenerateEPB50025();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, PINNACLE) == 0) 
            {
            TPM_7626_GenerateEPB50026();  
            }
          else
	  	 	     //Manual PPR Added data --PPatnaik
         if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0) 
            {
            TPM_7627_GenerateEPB50027();  
            }
          else
	  
         if (strcmp(DTL_REC.sSourceSys, MESABA) == 0) 
            {
            TPM_7628_GenerateEPB50028();  
            }
          else
         if (strcmp(DTL_REC.sSourceSys, COMPASS) == 0) 
            {
            TPM_7629_GenerateEPB50029();  
            }
          else
         if (strcmp(DTL_REC.sSourceSys, MLT) == 0) 
            {
            TPM_7630_GenerateEPB50030();  
            }
          else
         if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE) == 0) 
            {
            TPM_7631_GenerateEPB50031();  
            }
          else
         if (strcmp(DTL_REC.sSourceSys, GOJET) == 0) 
            {
            TPM_7632_GenerateEPB50032();  
            }
          else
	   {
             sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, BirthDt = %s",
                                     DTL_REC.cRecordId,
                                     DTL_REC.sPprNbr,
                                     DTL_REC.sDesNrevNbr,
                                     DTL_REC.sBirthDt);
             BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
             BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_4000_ProcessFileRecords");
            }
         }
 
      /*****************************************************************************************/
      /** Validate the Start Date on the input record - must not be zeros, nulls, or spaces.  **/
      /** If date is invalid, write the record to the ERROR REPORT.                           **/
      /*****************************************************************************************/
      if ((!strcmp(DTL_REC.sStrtDt, ZERO_DATE)) || 
          (!strcmp(DTL_REC.sStrtDt, "")))
         {  
         TPM_7100_BadDate();
         }  

      /********************************************************************************/
      /** If the PPR's pass group code is 'XX', process the record as REVOKED.       **/
      /********************************************************************************/
      if (strcmp(sSavePassGrpCd, "XX") == 0)
         nProcessAsRevoked = TRUE;

         } /* end if this is not a delete record */
   

   /********************************************************************************/
   /********************************************************************************/
   /** Process only valid records with a valid pass group/passenger type. The     **/
   /** switch is set up to identify the record type based on the first character  **/
   /** of the record.   Possible record types are:  Add, Change, Delete.          **/
   /** If cValidateError == 'Y', then the record has already been written to the  **/
   /** error report.  No further processing will be done.                         **/
   /********************************************************************************/
   /********************************************************************************/
   if (cValidateError == 'N')
      {
      if (nValidPgpPtyp == TRUE)
         {
         switch (cRecType)
            {
            case ADD_REC:
               if (strcmp(DTL_REC.sRecType, A1_REC) == 0)
                  {
                  if (nPPRPresent == FALSE)
                     {
                     TPM_4200_ProcessAddRecord();
                     }
                  else
                     {
                     TPM_5500_ProcessChangeRecord();
                     }
                  }
               else
                  {
                  TPM_4200_ProcessAddRecord();
                  }
               break;
   
            case CHANGE_REC:
               TPM_5500_ProcessChangeRecord();
               break;
   
            case DELETE_REC:
               TPM_6500_ProcessDeleteRecord();
               break;
   
            }
         }
      else  /** pass group/psgr type (PPR group/Nrev type) is not valid **/
         /*************************************************************/
         /** 'YY' is an unknown pass group                           **/
         /** 8/12/96 - these records will now be ignored.            **/
         /*************************************************************/
         {
         if (strcmp(sSavePassGrpCd, "YY") == 0)
            RS.records_not_processed++;
         else
            {
            /************************************************************/
            /** If ADD record, write to error file - records with      **/
            /** invalid pgp/psgr type cannot be added.                 **/
            /** If CHANGE record, revoke.                              **/
            /************************************************************/
            if (DTL_REC.cRecordId  == ADD_REC)
               {
               cErrorCode = '6';  
               if (strcmp(DTL_REC.sSourceSys, DELTA) == 0) 
                  {
                  TPM_7611_GenerateEPB50011();  
                  }
               else 
               if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)  
                  {
                  TPM_7612_GenerateEPB50012();  
                  }
               else  
               if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)   
                  {
                  TPM_7613_GenerateEPB50013();  
                  }
               else  
               if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)   
                  {
                  TPM_7614_GenerateEPB50014();  
                  }
               else 
               if (strcmp(DTL_REC.sSourceSys, ASA) == 0) 
                  {
                  TPM_7615_GenerateEPB50015();  
                  }
               else 
               if (strcmp(DTL_REC.sSourceSys, COMAIR) == 0) 
                  {
                  TPM_7616_GenerateEPB50016();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0) 
                  {
                  TPM_7617_GenerateEPB50017();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY) == 0) 
                  {
                  TPM_7618_GenerateEPB50018();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) 
                  {
                  TPM_7619_GenerateEPB50019();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, ACA) == 0) 
                  {
                  TPM_7620_GenerateEPB50020();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) 
                  {
                  TPM_7621_GenerateEPB50021();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) 
                  {
                  TPM_7622_GenerateEPB50022();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, FREEDOM) == 0) 
                  {
                  TPM_7623_GenerateEPB50023();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, BIG_SKY) == 0) 
                  {
                  TPM_7624_GenerateEPB50024();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET) == 0) 
                  {
                  TPM_7625_GenerateEPB50025();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, PINNACLE) == 0) 
                  {
                  TPM_7626_GenerateEPB50026();  
                  }
               else
	       	 	     //Manual PPR Added data --PPatnaik
               if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0) 
                  {
                  TPM_7627_GenerateEPB50027();  
                  }
               else
	       
               if (strcmp(DTL_REC.sSourceSys, MESABA) == 0) 
                  {
                  TPM_7628_GenerateEPB50028();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, COMPASS) == 0) 
                  {
                  TPM_7629_GenerateEPB50029();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, MLT) == 0) 
                  {
                  TPM_7630_GenerateEPB50030();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE) == 0) 
                  {
               TPM_7631_GenerateEPB50031();  
                  }
               else
               if (strcmp(DTL_REC.sSourceSys, GOJET) == 0) 
                  {
               TPM_7632_GenerateEPB50032();  
                  }
               else
                  {
                  sprintf(sErrorMessage, "ERROR 6:  Invalid Pass Grp/Psgr Type");
                  BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
                  sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, PassGrp = %s, PsgrType = %s, RecType = %s, EffDt = %s",
                                        DTL_REC.cRecordId,
                                        DTL_REC.sPprNbr,
                                        DTL_REC.sDesNrevNbr,
                                        DTL_REC.sPassGrpCd,
                                        DTL_REC.sPsgrTypeCd,
                                        DTL_REC.sRecType,
                                        DTL_REC.sEffDt);
                  BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
                  BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_4000_ProcessFileRecords");
                  }  
               }
            else /* invalid pass group/psgr type on CHANGE record - execute revoke processing */
               {
               TPM_6500_ProcessDeleteRecord();
               }
            }
         } /* endif - valid pgpptyp */
      } /* endif - validate error */
}



/******************************************************************
**                                                               **
** Function Name:   TPM_4005_FormatDetailRecord                  **
**                                                               **
** Description:     Move the data from the input buffer to       **
**                  the Detail Record structure.                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int TPM_4005_FormatDetailRecord()
{
   char dtldata[267];
   int i;
   int length_of_line ;

 /* Initialize detail record with nulls */
   memset(&DTL_REC, LOW_VALUES, sizeof(DTL_REC));
   memset(&dtldata, LOW_VALUES, sizeof(dtldata));

 /*****************************************************************************/
 /* Before moving data, remove any single quotes in the data and replace with */
 /* a single space.  The single quote causes the insert/update cursor service */
 /* 4309 to blow up.                                                          */
 /*****************************************************************************/
   strncpy(dtldata, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   length_of_line = strlen(dtldata);
   for (i = 0; i < length_of_line ; i++)
      {
      if (dtldata[i] == APOSTROPHE)
         dtldata[i] = ' '; 
      }

   strncpy(RS.EPBF010_buffer, dtldata, sizeof(dtldata));

 /* Move buffer into detail record fields */
   DTL_REC.cRecordId = RS.EPBF010_buffer[0]; 
   strncpy(DTL_REC.sPprNbr, (char *)RS.EPBF010_buffer+1,9);
   strncpy(DTL_REC.sDesNrevNbr, (char *)RS.EPBF010_buffer+13,2);
   strncpy(DTL_REC.sPsgrNm, (char *)RS.EPBF010_buffer+15,30);
   strncpy(DTL_REC.sAddrLn1, (char *)RS.EPBF010_buffer+45,24);
   strncpy(DTL_REC.sAddrLn2, (char *)RS.EPBF010_buffer+69,24);
   strncpy(DTL_REC.sCity, (char *)RS.EPBF010_buffer+93,24);
   strncpy(DTL_REC.sState, (char *)RS.EPBF010_buffer+117,2);
   strncpy(DTL_REC.sZip, (char *)RS.EPBF010_buffer+119,9);
   strncpy(DTL_REC.sCtryCd, (char *)RS.EPBF010_buffer+128,3);
   strncpy(DTL_REC.sPhone, (char *)RS.EPBF010_buffer+131,15);
   strncpy(DTL_REC.sDept, (char *)RS.EPBF010_buffer+146,5);
   strncpy(DTL_REC.sStation, (char *)RS.EPBF010_buffer+156,5);
   strncpy(DTL_REC.sEmpCatCd, (char *)RS.EPBF010_buffer+161,2);
   DTL_REC.cStsInd = RS.EPBF010_buffer[+163];
   strncpy(DTL_REC.sStsActCd, (char *)RS.EPBF010_buffer+164,2);
   strncpy(DTL_REC.sAltId, (char *)RS.EPBF010_buffer+166,9);
   strncpy(DTL_REC.sStrtDt, (char *)RS.EPBF010_buffer+178,8);
   strncpy(sStrtMo, (char *)RS.EPBF010_buffer+182,2);
   strncpy(sStrtDy, (char *)RS.EPBF010_buffer+184,2);
   strncpy(DTL_REC.sEmpTermDt, (char *)RS.EPBF010_buffer+186,8);
   strncpy(DTL_REC.sPassRvkDt, (char *)RS.EPBF010_buffer+194,8);
   strncpy(DTL_REC.sInttaxNbr, (char *)RS.EPBF010_buffer+202,8);
   strncpy(DTL_REC.sRecType, (char *)RS.EPBF010_buffer+210,2);
   strncpy(DTL_REC.sBirthDt, (char *)RS.EPBF010_buffer+212,8);
   strncpy(DTL_REC.sPsgrTypeCd, (char *)RS.EPBF010_buffer+220,2);
   strncpy(DTL_REC.sPassGrpCd, (char *)RS.EPBF010_buffer+222,2);
   strncpy(DTL_REC.sCitzCtryCd, (char *)RS.EPBF010_buffer+224,3);
   strncpy(DTL_REC.sResdSts, (char *)RS.EPBF010_buffer+227,2);
   strncpy(DTL_REC.sDesStsActCd, (char *)RS.EPBF010_buffer+229,2);
   strncpy(DTL_REC.sSourceSys, (char *)RS.EPBF010_buffer+231,2);
   strncpy(DTL_REC.sCardIssDt, (char *)RS.EPBF010_buffer+233,8);
   strncpy(DTL_REC.sErrorDt, (char *)RS.EPBF010_buffer+241,8);
   strncpy(DTL_REC.sEffDt, (char *)RS.EPBF010_buffer+249,8);
   strncpy(DTL_REC.sOthrEmptCd, (char *)RS.EPBF010_buffer+257,2);
   strncpy(DTL_REC.cGndr, (char *)RS.EPBF010_buffer+259,1);  
   strncpy(DTL_REC.sSlrySclId, (char *)RS.EPBF010_buffer+260,3);
   strncpy(DTL_REC.sDtlFiller2, (char *)RS.EPBF010_buffer+263,4);

   /**************************************************************************************/
   /** If Pinnacle, Compass, GoJet, ExpressJet, Skywest, Chautauqua or Shuttle America  **/
   /** set DTL_REC.sSlrySclId to space                                                  **/
   /**************************************************************************************/
   if ((strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "EV") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "S5") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "9E") == 0))
	strcpy(DTL_REC.sSlrySclId, GRD_SPACE);
   /**************************************************************************************/
   /** set DTL_REC.sSlrySclId for MLT                                                   **/
   /**************************************************************************************/
   if ((strcmp(DTL_REC.sSourceSys, "ML") == 0) &&
       (strcmp(DTL_REC.sSlrySclId, "MD1") == 0))
       strcpy(DTL_REC.sSlrySclId, "011");
   if ((strcmp(DTL_REC.sSourceSys, "ML") == 0) &&
       (strcmp(DTL_REC.sSlrySclId, "MV1") == 0))
       strcpy(DTL_REC.sSlrySclId, "012");
   if ((strcmp(DTL_REC.sSourceSys, "ML") == 0) &&
	(strcmp(DTL_REC.sSlrySclId, "MX1") == 0))
	strcpy(DTL_REC.sSlrySclId, "012");
   if ((strcmp(DTL_REC.sSourceSys, "ML") == 0) &&
       (strcmp(DTL_REC.sSlrySclId, "020") >= 0))    
        strcpy(DTL_REC.sSlrySclId, "005");       
   /**************************************************************************************/
   /** set DTL_REC.sSlrySclId for Comair "60" numbers                                   **/ 
   /**************************************************************************************/
   if ((strcmp(DTL_REC.sSourceSys, "OH") == 0) &&
      (strncmp(DTL_REC.sPprNbr, "60", 2) == 0))
       strcpy(DTL_REC.sSlrySclId, GRD_SPACE);
    /** writetolog(DTL_REC.sSourceSys ,'0');                                 **/                   
    /** writetologX(DTL_REC.sSourceSys, DTL_REC.sSlrySclId);                 **/

   /***************************************************************************/
   /** If the Effective Date is zeros, or spaces, or nulls, use today's date **/
   /***************************************************************************/
   if ((!strcmp(DTL_REC.sEffDt, ZERO_DATE)) ||
       (!strcmp(DTL_REC.sEffDt, "")))
      strcpy(DTL_REC.sEffDt, RS.sTodayDt);

   // Remove trailing spaces from string variables
   UTL_StripTrailingSpaces(DTL_REC.sPprNbr);
   UTL_StripTrailingSpaces(DTL_REC.sDesNrevNbr);
   UTL_StripTrailingSpaces(DTL_REC.sPsgrNm);
   UTL_StripTrailingSpaces(DTL_REC.sAddrLn1);
   UTL_StripTrailingSpaces(DTL_REC.sAddrLn2);
   UTL_StripTrailingSpaces(DTL_REC.sCity);
   UTL_StripTrailingSpaces(DTL_REC.sState);
   UTL_StripTrailingSpaces(DTL_REC.sZip);
   UTL_StripTrailingSpaces(DTL_REC.sCtryCd);
   UTL_StripTrailingSpaces(DTL_REC.sPhone);
   UTL_StripTrailingSpaces(DTL_REC.sDept);
   UTL_StripTrailingSpaces(DTL_REC.sStation);
   UTL_StripTrailingSpaces(DTL_REC.sEmpCatCd);
   UTL_StripTrailingSpaces(DTL_REC.sStsActCd);
   UTL_StripTrailingSpaces(DTL_REC.sAltId);
   UTL_StripTrailingSpaces(DTL_REC.sStrtDt);
   UTL_StripTrailingSpaces(sStrtMo);
   UTL_StripTrailingSpaces(sStrtDy);
   UTL_StripTrailingSpaces(DTL_REC.sEmpTermDt);
   UTL_StripTrailingSpaces(DTL_REC.sPassRvkDt);
   UTL_StripTrailingSpaces(DTL_REC.sInttaxNbr);
   UTL_StripTrailingSpaces(DTL_REC.sRecType);
   UTL_StripTrailingSpaces(DTL_REC.sBirthDt);
   UTL_StripTrailingSpaces(DTL_REC.sPsgrTypeCd);
   UTL_StripTrailingSpaces(DTL_REC.sPassGrpCd);
   UTL_StripTrailingSpaces(DTL_REC.sCitzCtryCd);
   UTL_StripTrailingSpaces(DTL_REC.sResdSts);
   UTL_StripTrailingSpaces(DTL_REC.sDesStsActCd);
   UTL_StripTrailingSpaces(DTL_REC.sSourceSys);
   UTL_StripTrailingSpaces(DTL_REC.sCardIssDt);
   UTL_StripTrailingSpaces(DTL_REC.sErrorDt);
   UTL_StripTrailingSpaces(DTL_REC.sEffDt);
   UTL_StripTrailingSpaces(DTL_REC.sOthrEmptCd);
   UTL_StripTrailingSpaces(DTL_REC.sSlrySclId);
   UTL_StripTrailingSpaces(DTL_REC.sDtlFiller2);

   // Convert an empty Citizenship & Country codes to USA
   if (0 == DTL_REC.sCitzCtryCd[0])
   {
       strncpy(DTL_REC.sCitzCtryCd, "USA",
	sizeof(DTL_REC.sCitzCtryCd));
   }
   if (0 == DTL_REC.sCtryCd[0])
   {
       strncpy(DTL_REC.sCtryCd, "USA",
	sizeof(DTL_REC.sCtryCd));
   }

   // If department, PprStnId, or City is NULL or InterTax number, then load with space
   if (0 == DTL_REC.sDept[0])
   {
       DTL_REC.sDept[0] = ' ';
   }
   if (0 == DTL_REC.sCity[0])
   {
       DTL_REC.sCity[0] = ' ';
   }
   if (0 == DTL_REC.sInttaxNbr[0])
   {
       DTL_REC.sInttaxNbr[0] = ' ';
   }
   if (0 == DTL_REC.sStation[0])
   {
     DTL_REC.sStation[0] = ' ';
   }


   /** separate the effective date into its parts for later processing **/
   strncpy(sEffdtYr, DTL_REC.sEffDt,4);    /* CCYY */
   strncpy(sEffdtMo, DTL_REC.sEffDt+4,2);  /* MM   */
   strncpy(sEffdtDy, DTL_REC.sEffDt+6,2);  /* DD   */
}



/******************************************************************
**                                                               **
** Function Name:   TPM_4200_ProcessAddRecord                    **
**                                                               **
** Description:     Process detail record to insert into the     **
**                  PPR table.                                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int TPM_4200_ProcessAddRecord()
{
   short   nSvcRtnCd;   /* Service return code */

 
   if(strcmp(DTL_REC.sRecType, A1_REC) == 0)
      {
      TPM_4220_ProcessA1Add();
      }
   else
   if(strcmp(DTL_REC.sRecType, C2_REC) == 0)
      {
      if (nPPRPresent == TRUE)
         {
         if (nNrevPresent == FALSE)
            {
            TPM_4230_ProcessC2Add();
            }
         else
            {
            TPM_5500_ProcessChangeRecord();
            } 
         } 
      } 

} 

 

/******************************************************************
**                                                               **
** Function Name:   TPM_4210_FormatPprInsertArea                 **
**                                                               **
** Description:     Format the application area for the PPR      **
**                  record primitive insert                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int    TPM_4210_FormatPprInsertArea()
{
   short   nSvcRtnCd;        /* Service return code */
   short   nEffMoSvcNbr;     /* Effective months of service */
   short   nYearsSvcNbr;     /* Effective years of service */


   /*** Initialize Service Request and Answer Blocks **/
   memset(&R02383, LOW_VALUES, sizeof(_R02383));
   memset(&A02383, LOW_VALUES, sizeof(_A02383));

   /* Format the request block for the primitive insert */
   strcpy(R02383.R02383_appl_area.sPprNbr, DTL_REC.sPprNbr);
   strcpy(R02383.R02383_appl_area.sPprSocSecNbr, DTL_REC.sAltId);
   writetolog(DTL_REC.sAltId,'9');
   /*******************************************************************************/
   /** If the input address lines 1 and 2 are both empty, populate these fields **/
   /** with the station and department, respectively.                            **/
   /*******************************************************************************/
   if ((strcmp(DTL_REC.sAddrLn1, "") == 0) && (strcmp(DTL_REC.sAddrLn2, "") == 0))
      {
      strcpy(R02383.R02383_appl_area.sPpr1Addr, DTL_REC.sStation);
      strcpy(R02383.R02383_appl_area.sPpr2Addr, DTL_REC.sDept);
      }
   else
      {
      strcpy(R02383.R02383_appl_area.sPpr1Addr, DTL_REC.sAddrLn1);
      strcpy(R02383.R02383_appl_area.sPpr2Addr, DTL_REC.sAddrLn2);
      }

   strcpy(R02383.R02383_appl_area.sPprCtyAddr, DTL_REC.sCity);
   strcpy(R02383.R02383_appl_area.sPprStCd, DTL_REC.sState);
   strcpy(R02383.R02383_appl_area.sPprZipAddr, DTL_REC.sZip);
   strcpy(R02383.R02383_appl_area.sPprPhNbr, DTL_REC.sPhone);
   strcpy(R02383.R02383_appl_area.sPprCtryCd, DTL_REC.sCtryCd);
   if (nOneInitialLstNm == TRUE)
     {
     strcpy(R02383.R02383_appl_area.sPprNm, sFullNm);
     }
     else
     {
     strcpy(R02383.R02383_appl_area.sPprNm, DTL_REC.sPsgrNm);
     }
   strcpy(R02383.R02383_appl_area.sPprFrstNm,sFrstNm);
   strcpy(R02383.R02383_appl_area.sPprLstNm,sLstNm);
   R02383.R02383_appl_area.cPprMidNm = cMidNm;

   strcpy(R02383.R02383_appl_area.sPprStnId, DTL_REC.sStation);
   strcpy(R02383.R02383_appl_area.sPprDeptNbr, DTL_REC.sDept);
   strcpy(R02383.R02383_appl_area.sPassGrpCd, DTL_REC.sPassGrpCd);

   strcpy(R02383.R02383_appl_area.sPprStrtDt, UTL_ConvertDate(DTL_REC.sStrtDt, CNV_YYYYMMDD_TO_DB));
   R02383.R02383_appl_area.uPprStrtMo = atoi(sStrtMo);
   R02383.R02383_appl_area.uPprStrtDy = atoi(sStrtDy);

   /***************************************************/
   /* >>>> Calculate Months of Service Completed <<<< */
   /***************************************************/
   R02383.R02383_appl_area.nFltMoSvcNbr = TPM_7005_CalculateMonthsSvc(DTL_REC.sStrtDt);

   if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) != 0)
      strcpy(R02383.R02383_appl_area.sPprInttxNbr, DTL_REC.sInttaxNbr);

   /******************************************************************************************/
   /** When adding a PPR with a pass group of 'FU', set the revoke date to EFFDT + 5 years. **/
   /** When adding a PPR with a pass group of 'VR', set the revoke date to EFFDT + 5 years. **/
   /** When adding a PPR with a pass group of 'FP', set the revoke date to EFFDT + 10 years.**/
   /***********************************************************************
   /** When adding a PPR with a pass group of 'MD' or 'DS', set the revoke date as follows: **/
   /**   if their months of service completed is < 120 months, divide the months of service **/
   /**   by 12 and drop the remainder.  This gives the years to add to the EFFDT.  This     **/
   /**   date goes into the sPprRvkDt.                                                      **/
   /******************************************************************************************/
   if ((strcmp(DTL_REC.sPassGrpCd, FURL_EMPL) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, VOL_SEV_DL_RECOVERY) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, FURL_PILOT) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, FURL_MERIT) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, TRAVEL_OP_SEV) == 0)) 
      {                           
      if ((strcmp(DTL_REC.sPassRvkDt, ZERO_DATE) != 0)  &&
		(strcmp(DTL_REC.sPassRvkDt, "") != 0)   &&
		(strcmp(DTL_REC.sPassRvkDt, " ") != 0))
         {
         strcpy(R02383.R02383_appl_area.sPprRvkDt, UTL_ConvertDate(DTL_REC.sPassRvkDt, CNV_YYYYMMDD_TO_DB));
         }
       else
       {
      /********************************************************************************/
      /** Must calculate the Revoke Date from the effective date of the input record.**/
      /** Furloughed pilots and furloughed employees with employee status action     **/
      /** codes of T2 and T3 get 1 year, while people in VR pass groups with a status**/
      /** action code of T1 get 5 years.                                             **/
      /**                                                                            **/
      /*** AS OF 6/1/08 employees in TO pass group with T1 staus codes will get to   **/
      /**  fly for the number of years of service completed, where the last day of   **/
      /**  the current year is used to make the calculation.                         **/
     /**  L.Scott  5/20/08                                                          **/
     /**                                                                            **/
     /** add new code of F1 - mirror after T1 Post Merger Invol Pgm M.lewis 01/06/09 **/
      /********************************************************************************/


      if (((strcmp(DTL_REC.sStsActCd, "T1") == 0) || (strcmp(DTL_REC.sStsActCd, "F1") == 0)) &&
         (strcmp(DTL_REC.sPassGrpCd, TRAVEL_OP_SEV) == 0)) 
	 {
      /* calculate the revoke date based on effective year plus the years of service*/

         nYearsSvcNbr = TPM_7007_CalculateYearsSvc(DTL_REC.sStrtDt);
         nRvkYear = (atoi(sEffdtYr) + nYearsSvcNbr);
         nRvkMonth = atoi(sEffdtMo);
         nRvkDay = atoi(sEffdtDy);
         sprintf(R02383.R02383_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, nRvkDay);
	  }
        else
      if ((strcmp(DTL_REC.sStsActCd, "T2") == 0) ||
          (strcmp(DTL_REC.sStsActCd, "T3") == 0) ||
          (strcmp(DTL_REC.sStsActCd, "T5") == 0) ||
          (strcmp(DTL_REC.sStsActCd, "T6") == 0) ||
          (strcmp(DTL_REC.sStsActCd, "T7") == 0) ||
          (strcmp(DTL_REC.sStsActCd, "T9") == 0))
         {
         nRvkYear = atoi(sEffdtYr) + 1;
         nRvkMonth = atoi(sEffdtMo);
         nRvkDay = atoi(sEffdtDy);
         sprintf(R02383.R02383_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, nRvkDay);
         }
      else
      if (strcmp(DTL_REC.sStsActCd, "T8") == 0)
	 {
      /* calculate the revoke date based on effective date plus the number of years of service completed */

         nEffMoSvcNbr = TPM_7006_CalculateEffMonthsSvc(DTL_REC.sStrtDt);
	 if (nEffMoSvcNbr < 12)
	    {
            nRvkYear = atoi(sEffdtYr) + 1;
            nRvkMonth = atoi(sEffdtMo);
            nRvkDay = atoi(sEffdtDy);
            sprintf(R02383.R02383_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, nRvkDay);
	    }
        else
	   {
           nYrSvcCmpl = (nEffMoSvcNbr / 12);
           nRvkYear = (atoi(sEffdtYr) + nYrSvcCmpl);
           sprintf(R02383.R02383_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, atoi(sEffdtMo), atoi(sEffdtDy));
	   }
         } 
      else
      if ((strcmp(DTL_REC.sEmpCatCd, "PI") == 0) || 
          (strcmp(DTL_REC.sEmpCatCd, "PL") == 0)) 
         {
         nRvkYear = atoi(sEffdtYr) + 10;
         nRvkMonth = atoi(sEffdtMo);
         nRvkDay = atoi(sEffdtDy);
         sprintf(R02383.R02383_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, nRvkDay);
         }
      else
      if (((strcmp(DTL_REC.sStsActCd, "T1") != 0) ||
          (strcmp(DTL_REC.sStsActCd, "T2") != 0)  ||
          (strcmp(DTL_REC.sStsActCd, "T3") != 0)  ||
          (strcmp(DTL_REC.sStsActCd, "T5") != 0)  ||
          (strcmp(DTL_REC.sStsActCd, "T6") != 0)  ||
          (strcmp(DTL_REC.sStsActCd, "T7") != 0)  ||
          (strcmp(DTL_REC.sStsActCd, "T8") != 0)  ||
          (strcmp(DTL_REC.sStsActCd, "T9") != 0)  ||
	  (strcmp(DTL_REC.sStsActCd, "F1") != 0)) &&
          ((strcmp(DTL_REC.sEmpCatCd, "PI") != 0) ||
	  (strcmp(DTL_REC.sEmpCatCd, "PL") != 0))) 
         {
         nRvkYear = atoi(sEffdtYr) + 5;
         nRvkMonth = atoi(sEffdtMo);
         nRvkDay = atoi(sEffdtDy);
         sprintf(R02383.R02383_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, nRvkDay);
         }
        }
      }

   /***********************************************************************************/
   /** For Disabled employees with less than 10 years of service, the Revoke Date is **/
   /** calculated from the Effective Date of the input record.                       **/
   /***********************************************************************************/
       else  
   if ((strcmp(DTL_REC.sPassGrpCd, DISABLED_DL_MRD) == 0) || 
       (strcmp(DTL_REC.sPassGrpCd, DISABLED_DL_SDW) == 0))
      {
      /* calculate effective months of service completed */
      nEffMoSvcNbr = TPM_7006_CalculateEffMonthsSvc(DTL_REC.sStrtDt);
 

      if (nEffMoSvcNbr < 120)
         {
         nYrSvcCmpl = (nEffMoSvcNbr / 12);
         nRvkYear = (atoi(sEffdtYr) + nYrSvcCmpl);
         sprintf(R02383.R02383_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, atoi(sEffdtMo), atoi(sEffdtDy));
         } 
      else
         strcpy(R02383.R02383_appl_area.sPprRvkDt, LOW_DATE);
      }
   else
      {
      if ((!strcmp(DTL_REC.sPassRvkDt, ZERO_DATE)) || 
          (!strcmp(DTL_REC.sPassRvkDt, "")))
         strcpy(R02383.R02383_appl_area.sPprRvkDt, LOW_DATE);
      else
         strcpy(R02383.R02383_appl_area.sPprRvkDt, UTL_ConvertDate(DTL_REC.sPassRvkDt, CNV_YYYYMMDD_TO_DB));
      }

   strcpy(R02383.R02383_appl_area.sCtryCtznpCd, DTL_REC.sCitzCtryCd);

   /************************************************************************************/
   /** if the pass group code is AC, AK, or MA, the residency status may be EX or TC, **/
   /** otherwise, set the residency status to "LC".                                   **/
   /************************************************************************************/
   if (((strcmp(DTL_REC.sPassGrpCd, "AC") == 0) || (strcmp(DTL_REC.sPassGrpCd, "AK") == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, "MA") == 0)) && 
       ((strcmp(DTL_REC.sResdSts, "EX") == 0) || (strcmp(DTL_REC.sResdSts, "TC") == 0)))
      strcpy(R02383.R02383_appl_area.sPprRsdncyStsCd, DTL_REC.sResdSts); 
   else
      strcpy(R02383.R02383_appl_area.sPprRsdncyStsCd, "LC");
    /************************************************************************************/
   /** Shridev Makim (7/20/1998)                                                      **/
   /** Check the t_pass_allot table to see if the ppr is eligible for friends &       **/
   /** family and Above & Beyond certificate based on their pass group.               **/
   /************************************************************************************/
   if (nProcessAsRevoked == FALSE)
   {
      TPM_7540_CheckElligibilityForCerts();

    /**  if ((nPprFFElligible == TRUE) && (R02383.R02383_appl_area.nFltMoSvcNbr >= 12)) **/
      if (nPprFFElligible == TRUE) 
         R02383.R02383_appl_area.cPprFFInd = YES_IND;
      else
         R02383.R02383_appl_area.cPprFFInd = NO_IND;

      if (nPprABElligible == TRUE)
         R02383.R02383_appl_area.cPprABInd = YES_IND;
      else
         R02383.R02383_appl_area.cPprABInd = NO_IND;
   }
   else
   {
      R02383.R02383_appl_area.cPprFFInd = NO_IND;
      R02383.R02383_appl_area.cPprABInd = NO_IND;
   }

  /*************************************************************************************/
  /**  Added NW employee number, other employment indicator and salary scale id       **/
  /*************************************************************************************/

     strcpy(R02383.R02383_appl_area.sNwEmplNb, ZERO_EMP);
     strcpy(R02383.R02383_appl_area.sSlrySclIdGrdCd, DTL_REC.sSlrySclId);
     strcpy(R02383.R02383_appl_area.sOthrEmptCd, DTL_REC.sOthrEmptCd);
}      


/******************************************************************
**                                                               **
** Function Name:   TPM_4215_InsertPprRecord                     **
**                                                               **
** Description:     This function calls the service to insert    **
**                  into the PPR table.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_4215_InsertPprRecord()
{
   short   nSvcRtnCd;   /* Service return code */


   /***************************************************************/
   /** Call primitive service to insert a row into the PPR table **/
   /*****************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02383,&A02383,SERVICE_ID_02383,1,sizeof(_R02383_APPL_AREA));

   /** Service Return Code Processing **/

   switch (nSvcRtnCd)
     {
       case ARC_SUCCESS:
          RS.add_ppr_record_cntr++;
          break;
        
       default:
          BCH_FormatMessage(1,TXT_SVC_UNSUCC);
          BCH_FormatMessage(2,TXT_SVC,"FYS02383");
          BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
          BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4215_InsertPprRecord");
          break;  

      }
}



/******************************************************************
**                                                               **
** Function Name:   TPM_4220_ProcessA1Add                        **
**                                                               **
** Description:     This function handles the steps necessary to **
**                  add an A1 record to the database.            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
/* 12/08/2010 BBE    Added code for new "CV" CONN_CARR_NOZED     */
/*                   pass group.                                 */
/*****************************************************************/

int     TPM_4220_ProcessA1Add()
{
   short   nSvcRtnCd;   /* Service return code */


   TPM_4210_FormatPprInsertArea();

   TPM_4215_InsertPprRecord();

   /*** LAS 12-7-2009  ****/
   if ((strcmp(DTL_REC.sPassGrpCd, FURL_EMPL) == 0) ||  
       (strcmp(DTL_REC.sPassGrpCd, VOL_SEV_DL_RECOVERY) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, FURL_PILOT) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, FURL_MERIT) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, TRAVEL_OP_SEV) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, RETIRED_EARLY_SIX) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, RETIRED_LIMIT_DELTA) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, RETIRED_DELTA) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, RETIRED_ASSOCIATE) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, CONN_DELTA_RETIREE) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, CONN_CARR_RETIREE) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, CONN_CARR_NOZED) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, VOL_LEAVE_SDW_WK) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, VOL_LEAVE_SDW) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, VOL_LEAVE_MRD) == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, INELIG_PASS_GRP) == 0))
      {
      TPM_5525_DisableNrap();
      }
   /*** LAS 12-7-2009 - above ****/

   TPM_4400_ProcessNrevRecAdd();

   if (nProcessAsRevoked == FALSE)
      {
      TPM_7400_CreateAllotRecordRider();

      TPM_7310_WriteToPassCardTableRider();

      /** If the ppr is eligible for Friends & Family cert insert cert records **/
      /** into flt_certft table.                                                **/
      /** L.Scott (08/02/200) - Removed code that checked for ASA source code,  **/
      /**                       because ASA is now eligible for F&F certificates**/

      if (nPprFFElligible == TRUE) 
          TPM_7530_CreateFAndFCertRecord();
      }

   /**********************************************************************************************/
   /** If processing as Revoked, must write to the Comments Table and to the Audit Trail Table. **/
   /**********************************************************************************************/
   if (nProcessAsRevoked == TRUE)
      {
      /*** Initialize Service Request and Answer Blocks **/
      memset(&R02483, LOW_VALUES, sizeof(_R02483));
      memset(&A02483, LOW_VALUES, sizeof(_A02483));

      /** format service request copybook **/
      strcpy(R02483.R02483_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02483.R02483_appl_area.sNrevNbr,DTL_REC.sDesNrevNbr);
      strcpy(R02483.R02483_appl_area.sPassStsChgDt,sCurrentTsDt);
      strcpy(R02483.R02483_appl_area.sPassDtTmTs,sCurrentTsDt);
      strcpy(R02483.R02483_appl_area.sNrevNm, DTL_REC.sPsgrNm);

      /** Format comment field **/
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, PROCESSED_REVOKED_COMMENT);
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
      strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);

      TPM_7200_InsertComment();

      /**************************************************/
      /* A1 added as revoked - write Audit Trail Record */
      /**************************************************/

      /*** Initialize Service Request and Answer Blocks **/
      memset(&R02561, LOW_VALUES, sizeof(_R02561));
      memset(&A02561, LOW_VALUES, sizeof(_A02561));

      /** format service request copybook **/
      strcpy(R02561.R02561_appl_area.sAudtUserId, HRUPDATE);
      strcpy(R02561.R02561_appl_area.sNrevNbr,DTL_REC.sDesNrevNbr);
      strcpy(R02561.R02561_appl_area.sPassGrpCd,DTL_REC.sPassGrpCd);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "PPR Added as Revoked");
      strncpy(R02561.R02561_appl_area.sAudtChgFrNm, " ",sizeof(R02561.R02561_appl_area.sAudtChgFrNm));
      strcpy(R02561.R02561_appl_area.sAudtChgToNm, DTL_REC.sPassGrpCd);
      strcpy(R02561.R02561_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strncpy(R02561.R02561_appl_area.sPassTypCd, " ", sizeof(R02561.R02561_appl_area.sPassTypCd));

      TPM_7210_WriteAuditTrail();

      }
}



/******************************************************************
**                                                               **
** Function Name:   TPM_4230_ProcessC2Add                        **
**                                                               **
** Description:     This function handles the steps necessary to **
**                  add a C2  record to the database.            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
int     TPM_4230_ProcessC2Add()
{
   short   nSvcRtnCd;   /* Service return code */

 
   if (strcmp(DTL_REC.sPsgrTypeCd, PARENT) == 0)
      { 
      TPM_5510_CheckForParents();
      }

   if ((strcmp(DTL_REC.sPsgrTypeCd, COMPANION) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, SPOUSE) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0))
      { 
      TPM_5512_CheckForCompanionOrSpouse();
      
      if ((nSpouseInd == TRUE) || (nCompanionInd == TRUE) || (nDomPartnerInd))
         { 
         TPM_6515_RevokeSinglePassRider();
         }
      }

   TPM_4400_ProcessNrevRecAdd();
   
   if (nProcessAsRevoked == FALSE)
      {
      TPM_7400_CreateAllotRecordRider();

      TPM_7310_WriteToPassCardTableRider();
      }

   if ((nMaxParentInd == TRUE) || (nPprRevoked == TRUE) || (nProcessAsRevoked == TRUE) ||
      (strcmp(DTL_REC.sPsgrTypeCd, COMPANION) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, SPOUSE) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0))
      {
      /*** Initialize Service Request and Answer Blocks to Comments Table **/
      memset(&R02483, LOW_VALUES, sizeof(_R02483));
      memset(&A02483, LOW_VALUES, sizeof(_A02483));
 
      /*** Initialize Service Request and Answer Blocks to Audit Trail Table **/
      memset(&R02561, LOW_VALUES, sizeof(_R02561));
      memset(&A02561, LOW_VALUES, sizeof(_A02561));

      /** format service request copybook **/
      strcpy(R02483.R02483_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02483.R02483_appl_area.sNrevNbr,DTL_REC.sDesNrevNbr);
      strcpy(R02483.R02483_appl_area.sPassStsChgDt,sCurrentTsDt);
      strcpy(R02483.R02483_appl_area.sPassDtTmTs,sCurrentTsDt);
      strcpy(R02483.R02483_appl_area.sNrevNm, DTL_REC.sPsgrNm);
 
      /** Format comment field **/
      if ((nProcessAsRevoked == TRUE) || (nMaxParentInd == TRUE))
         {
         strcpy(R02483.R02483_appl_area.sNrevCmntTxt, PROCESSED_REVOKED_COMMENT);
         strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "NRev Added as Revoked    ");
         }
      else
      if (nMaxParentInd == TRUE)
         {
         strcpy(R02483.R02483_appl_area.sNrevCmntTxt, MAX_PARENT_COMMENT);
         strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Parent Added as Revoked  ");
         }
      else
      if (nPprRevoked == TRUE)
         {
         strcpy(R02483.R02483_appl_area.sNrevCmntTxt, PPR_REVOKED_COMMENT);
         strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "PPR Revoked on Nrev Add  ");
         }
           
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
      strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);

      if ((strcmp(DTL_REC.sPsgrTypeCd, COMPANION) == 0) || (strcmp(DTL_REC.sPsgrTypeCd, SPOUSE) == 0) || (strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0))
         {
         if (strcmp(DTL_REC.sPsgrTypeCd, COMPANION) == 0)
            {
            strcpy(R02483.R02483_appl_area.sNrevCmntTxt, COMPANION_ADDED_COMMENT);
            strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Companion Added          ");
            strcpy(R02483.R02483_appl_area.sPassStsCd, ACTIVE);
            TPM_7200_InsertComment(); 
            }
         if (strcmp(DTL_REC.sPsgrTypeCd, SPOUSE) == 0)
            {
            strcpy(R02483.R02483_appl_area.sNrevCmntTxt, SPOUSE_ADDED_COMMENT);
            strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Spouse Added             ");
            strcpy(R02483.R02483_appl_area.sPassStsCd, ACTIVE);
            TPM_7200_InsertComment(); 
            } 
         if (strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0)
            {
            strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DOMPARTNER_ADDED_COMMENT);
            strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Domestic Partner Added   ");
            strcpy(R02483.R02483_appl_area.sPassStsCd, ACTIVE);
            TPM_7200_InsertComment(); 
            } 
         }

      /***************************************/
      /** Write record to Audit Trail Table **/
      /***************************************/

      /** format service request copybook **/
      strcpy(R02561.R02561_appl_area.sAudtUserId, HRUPDATE);
      strcpy(R02561.R02561_appl_area.sNrevNbr,DTL_REC.sDesNrevNbr);
      strcpy(R02561.R02561_appl_area.sPassGrpCd,DTL_REC.sPassGrpCd);
      strncpy(R02561.R02561_appl_area.sAudtChgFrNm, " ",sizeof(R02561.R02561_appl_area.sAudtChgFrNm));
      strcpy(R02561.R02561_appl_area.sAudtChgToNm, DTL_REC.sPassGrpCd);
      strcpy(R02561.R02561_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strncpy(R02561.R02561_appl_area.sPassTypCd, " ", sizeof(R02561.R02561_appl_area.sPassTypCd));

      TPM_7210_WriteAuditTrail();
      }
}



/******************************************************************
**                                                               **
** Function Name:   TPM_4310_ProcessPprUpdate                    **
**                                                               **
** Description:     Update the PPR record                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_4310_ProcessPprUpdate()
{
   short   nSvcRtnCd;        /* Service return code */


   TPM_4315_FormatPprUpdateArea();

   TPM_4320_UpdatePprRecord();
}



/******************************************************************
**                                                               **
** Function Name:   TPM_4315_FormatPprUpdateArea                 **
**                                                               **
** Description:     Update the PPR record                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_4315_FormatPprUpdateArea() { short   nSvcRtnCd;        /* Service return code */
short   nEffMoSvcNbr;     /* Effective months of service for disabled */
short   nYearsSvcNbr;     /* Effective years of service for disabled */

/*** Initialize Service Request and Answer Blocks **/
memset(&R02384, LOW_VALUES, sizeof(_R02384));
memset(&A02384, LOW_VALUES, sizeof(_A02384));
/* Format the request block for the advanced update  */
strcpy(R02384.R02384_appl_area.sPprNbr,DTL_REC.sPprNbr);
strcpy(R02384.R02384_appl_area.sPprSocSecNbr,DTL_REC.sAltId);
nEffMoSvcNbr = TPM_7006_CalculateEffMonthsSvc(DTL_REC.sStrtDt);
  writetolog(DTL_REC.sAltId,'9');
   /***********************************************************************/
   /** If the input address lines 1 and 2 are both spaces, populate them **/
   /** with station and department, respectively.                        **/
   /***********************************************************************/
   if ((strcmp(DTL_REC.sAddrLn1, "") == 0) && (strcmp(DTL_REC.sAddrLn1, "") == 0))
      {
      strcpy(R02384.R02384_appl_area.sPpr1Addr, DTL_REC.sStation);
      strcpy(R02384.R02384_appl_area.sPpr2Addr, DTL_REC.sDept);
      }
   else
      {
      strcpy(R02384.R02384_appl_area.sPpr1Addr, DTL_REC.sAddrLn1);
      strcpy(R02384.R02384_appl_area.sPpr2Addr, DTL_REC.sAddrLn2);
      }

   strcpy(R02384.R02384_appl_area.sPprCtyAddr,  DTL_REC.sCity);
   strcpy(R02384.R02384_appl_area.sPprStCd,     DTL_REC.sState);
   strcpy(R02384.R02384_appl_area.sPprZipAddr,  DTL_REC.sZip);
   strcpy(R02384.R02384_appl_area.sPprPhNbr,    DTL_REC.sPhone);
   strcpy(R02384.R02384_appl_area.sPprCtryCd,   DTL_REC.sCtryCd);
   strcpy(R02384.R02384_appl_area.sCtryCtznpCd, DTL_REC.sCitzCtryCd);

   /************************************************************************************/
   /** if the pass group code is AC, AK, or MA, the residency status may be EX or TC, **/
   /** otherwise, set the residency status to "LC".                                   **/
   /************************************************************************************/
   if (((strcmp(DTL_REC.sPassGrpCd, "AC") == 0) || (strcmp(DTL_REC.sPassGrpCd, "AK") == 0) ||
       (strcmp(DTL_REC.sPassGrpCd, "MA") == 0)) && 
       ((strcmp(DTL_REC.sResdSts, "EX") == 0) || (strcmp(DTL_REC.sResdSts, "TC") == 0)))  
      strcpy(R02384.R02384_appl_area.sPprRsdncyStsCd, DTL_REC.sResdSts); 
   else  
      strcpy(R02384.R02384_appl_area.sPprRsdncyStsCd, "LC");
 
   strcpy(R02384.R02384_appl_area.sPprStnId,DTL_REC.sStation);
   strcpy(R02384.R02384_appl_area.sPprDeptNbr,DTL_REC.sDept);

   /*strcpy(R02384.R02384_appl_area.sPprNm,DTL_REC.sPsgrNm);*/
   if (nOneInitialLstNm == TRUE)
      {
      strcpy(R02384.R02384_appl_area.sPprNm, sFullNm);        
      }
    else
     {
     strcpy(R02384.R02384_appl_area.sPprNm, DTL_REC.sPsgrNm);
     }
   strcpy(R02384.R02384_appl_area.sPprFrstNm,sFrstNm);
   strcpy(R02384.R02384_appl_area.sPprLstNm,sLstNm);
   R02384.R02384_appl_area.cPprMidNm = cMidNm;

   strcpy(R02384.R02384_appl_area.sPassGrpCd,DTL_REC.sPassGrpCd);

   strcpy(R02384.R02384_appl_area.sPprStrtDt, UTL_ConvertDate(DTL_REC.sStrtDt, CNV_YYYYMMDD_TO_DB));
   R02384.R02384_appl_area.uPprStrtMo = atoi(sStrtMo);
   R02384.R02384_appl_area.uPprStrtDy = atoi(sStrtDy);

   /****************************************************************************************/
   /** Reset Months of Service completed if hire date or pass group changes.              **/
   /** If the new pass group is one of the Ready Reserve groups, set the months of service**/
   /** to zero.  Otherwise, recalculate the months of service.                            **/
   /** if neither hire date nor pass group changed, reset the months of service to the    **/
   /** previous value.                                                                    **/
   /**                                                                                    **/
   /** 10/25/96 - changed back so that ready reserves will be treated like everyone else. **/
   /****************************************************************************************/
   if ((cHireDtChgInd ==  'Y') || (cPGpChgInd == 'Y'))
      {
      R02384.R02384_appl_area.nFltMoSvcNbr = TPM_7005_CalculateMonthsSvc(DTL_REC.sStrtDt);
      }
   else
      R02384.R02384_appl_area.nFltMoSvcNbr = A03834.A03834_appl_area.nFltMoSvcNbr;

   if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) != 0)
   strcpy(R02384.R02384_appl_area.sPprInttxNbr,DTL_REC.sInttaxNbr);

    /*****************************************************************/
    /** 12/08/2010 BBE    Added code for new "CV" CONN_CARR_NOZED   **/
    /**                   pass group.                               **/
    /*****************************************************************/
   /******* LAS 12-07-2009    **********/
   if ((cPGpChgInd == 'Y') && 
         ((strcmp(DTL_REC.sPassGrpCd, FURL_EMPL) == 0) ||  
	  (strcmp(DTL_REC.sPassGrpCd, VOL_SEV_DL_RECOVERY) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, FURL_PILOT) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, FURL_MERIT) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, TRAVEL_OP_SEV) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, RETIRED_EARLY_SIX) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, RETIRED_LIMIT_DELTA) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, RETIRED_DELTA) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, RETIRED_ASSOCIATE) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, CONN_DELTA_RETIREE) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, CONN_CARR_RETIREE) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, CONN_CARR_NOZED) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, VOL_LEAVE_SDW_WK) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, VOL_LEAVE_SDW) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, VOL_LEAVE_MRD) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, INELIG_PASS_GRP) == 0)))
	  {
          TPM_5525_DisableNrap();
	  }

   /******* LAS 12-07-2009 - above   **********/

 /******************************************************************************************/
 /**** SOME FURLOUGHED LOGIC IS NO LONGER VALID: COMMENTED OUT AS OF 05/15/2000 ******/
 /** When changing a PPR to a pass group of 'FU', set the revoke date to EFFDT + 5 years  **/
 /** exept for pilots, who get 7 years.  For pass group 'VR' the revoke date is the       **/
 /** EFFDT + 5 years.                                                                     **/
 /******************************************************************************************/
      /*** AS OF 6/1/08 employees in TO pass group with T1 staus codes will get to   **/
      /**  fly for the number of years of service completed, where the last day of   **/
      /**  the current year is used to make the calculation.                         **/
      /**  L.Scott  5/20/08                                                          **/
 /******************************************************************************************/
 /***********************************************************************/
 /** When changing a PPR to a pass group of 'MD' or 'DS', set the revoke date as follows: **/
 /**   If their months of service completed is < 120 months, divide the months of service **/
 /**   by 12 and drop the remainder.  This gives the years to add to the EFFDT.  This     **/
 /**   date goes into the sPprRvkDt.  If their months of service completed is > 120 months,*/
 /**   the revoke date is the default date.                                               **/
 /** If the pass group did not change, move in the pass group from the detail record.     **/
 /******************************************************************************************/

   if (cPGpChgInd == 'Y')
      {
      if ((strcmp(DTL_REC.sPassGrpCd, FURL_EMPL) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, VOL_SEV_DL_RECOVERY) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, FURL_PILOT) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, FURL_MERIT) == 0) ||
	  (strcmp(DTL_REC.sPassGrpCd, TRAVEL_OP_SEV) == 0))
	{
	 /**********************************************************************/
	 /** removed ! before strmcp, adding !=0 after comparison             **/
	 /** L. Scott 10/03/2000                                              **/
	 /**********************************************************************/
         if ((strcmp(DTL_REC.sPassRvkDt, ZERO_DATE) !=0) && 
           (strcmp(DTL_REC.sPassRvkDt, "") !=0)          && 
           (strcmp(DTL_REC.sPassRvkDt, " ") !=0))
          {
	 strcpy(R02384.R02384_appl_area.sPprRvkDt, UTL_ConvertDate(DTL_REC.sPassRvkDt, CNV_YYYYMMDD_TO_DB));

          }
	 else
         /****************************************************************/
         /** Must calculate from the effective date of the input record **/
         /****************************************************************/
    /****************/

        if (((strcmp(DTL_REC.sStsActCd, "T1") == 0) || (strcmp(DTL_REC.sStsActCd, "F1") == 0)) &&
           (strcmp(DTL_REC.sPassGrpCd, TRAVEL_OP_SEV) == 0)) 
	 {
         /* calculate the revoke date based on effective year plus the years of service*/

         nYearsSvcNbr = TPM_7007_CalculateYearsSvc(DTL_REC.sStrtDt);
         nRvkYear = (atoi(sEffdtYr) + nYearsSvcNbr);
         nRvkMonth = atoi(sEffdtMo);
         nRvkDay = atoi(sEffdtDy);
         sprintf(R02384.R02384_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, nRvkDay);
	  }
        else
          if ((strcmp(DTL_REC.sStsActCd, "T2") == 0) ||
	      (strcmp(DTL_REC.sStsActCd, "T3") == 0) ||
	      (strcmp(DTL_REC.sStsActCd, "T5") == 0) ||
	      (strcmp(DTL_REC.sStsActCd, "T6") == 0) ||
	      (strcmp(DTL_REC.sStsActCd, "T7") == 0) ||
	      (strcmp(DTL_REC.sStsActCd, "T9") == 0))
            { 
            nRvkYear = atoi(sEffdtYr) + 1;
            nRvkMonth = atoi(sEffdtMo);
            nRvkDay = atoi(sEffdtDy);
            sprintf(R02384.R02384_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, nRvkDay);
            } 
	  else
          if (strcmp(DTL_REC.sStsActCd, "T8") == 0)
	    {
             /* calculate the revoke date based on effective date + of years of service */
             nEffMoSvcNbr = TPM_7006_CalculateEffMonthsSvc(DTL_REC.sStrtDt);
	     if (nEffMoSvcNbr < 12)
	       {
               nRvkYear = atoi(sEffdtYr) + 1;
               nRvkMonth = atoi(sEffdtMo);
               nRvkDay = atoi(sEffdtDy);
               sprintf(R02384.R02384_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, nRvkDay);
	       }
            else
	       {
               nYrSvcCmpl = (nEffMoSvcNbr / 12);
               nRvkYear = (atoi(sEffdtYr) + nYrSvcCmpl);
               sprintf(R02384.R02384_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, atoi(sEffdtMo), atoi(sEffdtDy));
	       }
            }
	  else
	  if ((strcmp(DTL_REC.sEmpCatCd, "PI") == 0) ||
	      (strcmp(DTL_REC.sEmpCatCd, "PL") == 0))

              { 
              nRvkYear = atoi(sEffdtYr) + 10;
              nRvkMonth = atoi(sEffdtMo);
              nRvkDay = atoi(sEffdtDy);
              sprintf(R02384.R02384_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, nRvkDay);
              } 
          else 
	  if (((strcmp(DTL_REC.sEmpCatCd, "PI") != 0) ||
	      (strcmp(DTL_REC.sEmpCatCd, "PL") != 0)) &&
              ((strcmp(DTL_REC.sStsActCd, "T1") != 0) ||
	       (strcmp(DTL_REC.sStsActCd, "T2") != 0) ||
	       (strcmp(DTL_REC.sStsActCd, "T3") != 0) ||
	       (strcmp(DTL_REC.sStsActCd, "T5") != 0) ||
	       (strcmp(DTL_REC.sStsActCd, "T6") != 0) ||
	       (strcmp(DTL_REC.sStsActCd, "T7") != 0) ||
	       (strcmp(DTL_REC.sStsActCd, "T8") != 0) ||
	       (strcmp(DTL_REC.sStsActCd, "T9") != 0) ||
	       (strcmp(DTL_REC.sStsActCd, "F1") != 0)))
              { 
              nRvkYear = atoi(sEffdtYr) + 5;
              nRvkMonth = atoi(sEffdtMo);  
              nRvkDay = atoi(sEffdtDy); 
              sprintf(R02384.R02384_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, nRvkDay);
              }
           }
      else
      if ((strcmp(DTL_REC.sPassGrpCd, DISABLED_DL_MRD) == 0) || 
          (strcmp(DTL_REC.sPassGrpCd, DISABLED_DL_SDW) == 0))
         {

         nEffMoSvcNbr = TPM_7006_CalculateEffMonthsSvc(DTL_REC.sStrtDt);
         if (nEffMoSvcNbr < 120)
            {
            /** Calculate the Revoke Date for disabled employees with less than 10 years of service **/ 
            nYrSvcCmpl = (nEffMoSvcNbr / 12);
            nRvkYear = (atoi(sEffdtYr) + nYrSvcCmpl);
            nRvkMonth = atoi(sEffdtMo);

            /***********************************************************/
            /** Check for employees with less than 1 year of service  **/
            /***********************************************************/
            if (nEffMoSvcNbr < 12)
               {
               nMthSvcCmpl = (atoi(sEffdtMo) + nEffMoSvcNbr);

               if (nMthSvcCmpl > 12)
                  { 
                  nRvkMonth = nMthSvcCmpl - 12;
                  nRvkYear += 1;
                  }
               else
                  {
                  nRvkMonth = nMthSvcCmpl;
                  }
                }

            sprintf(R02384.R02384_appl_area.sPprRvkDt, "%d-%02d-%02d", nRvkYear, nRvkMonth, atoi(sEffdtDy));
            } 
         else  /**** nEffMoSvcNbr > 120  ****/
	    {
            strcpy(R02384.R02384_appl_area.sPprRvkDt, LOW_DATE);
	    }
          }
       }
      /* else  */
      if ((cPGpChgInd == 'Y') && 
      /* if (((strcmp(DTL_REC.sPassGrpCd, FURL_EMPL) != 0) &&  */
          ((strcmp(DTL_REC.sPassGrpCd, FURL_EMPL) != 0) &&
	  (strcmp(DTL_REC.sPassGrpCd, VOL_SEV_DL_RECOVERY) != 0) &&
	  (strcmp(DTL_REC.sPassGrpCd, FURL_PILOT) != 0) &&
	  (strcmp(DTL_REC.sPassGrpCd, FURL_MERIT) != 0) &&
	  (strcmp(DTL_REC.sPassGrpCd, TRAVEL_OP_SEV) != 0) &&
          (strcmp(DTL_REC.sPassGrpCd, DISABLED_DL_MRD) != 0) && 
          (strcmp(DTL_REC.sPassGrpCd, DISABLED_DL_SDW) != 0)))
	  /** &&  
         ((strcmp(DTL_REC.sPassRvkDt, ZERO_DATE) == 0) || 
	 **/
	  {
          if ((strcmp(DTL_REC.sPassRvkDt, ZERO_DATE) == 0) || 
             (strcmp(DTL_REC.sPassRvkDt, "") == 0)        ||
             (strcmp(DTL_REC.sPassRvkDt, " ") == 0))
	     {
             strcpy(R02384.R02384_appl_area.sPprRvkDt, LOW_DATE);
	     }
          else  
            {
            strcpy(R02384.R02384_appl_area.sPprRvkDt,UTL_ConvertDate(DTL_REC.sPassRvkDt, CNV_YYYYMMDD_TO_DB));
	    }
	  }
   /*}   */
     
   if (cPGpChgInd == 'N') 
       {
       strcpy(R02384.R02384_appl_area.sPprRvkDt,A03834.A03834_appl_area.sPprRvkDt);
       }
   strcpy(R02384.R02384_appl_area.sArchLastUpdtTs,A03834.A03834_appl_area.sArchLastUpdtTs);


 /**********************************************************************************/
 /** Shridev Makim: (7/23/1998)                                                   **/
 /** If pass group has been changed, check the eligibility for F&F and A&B        **/
 /** certificates and change ppr_ff_ind and ppr_ab_ind in ppr table if needs so.  **/
 /** If the pass group has not been chaged, keep those indicators as it is.       **/
 /**********************************************************************************/

   if (cPGpChgInd == 'Y')
   {
      TPM_7540_CheckElligibilityForCerts();

      if (nPprFFElligible == TRUE)
            R02384.R02384_appl_area.cPprFFInd = YES_IND;
      else
            R02384.R02384_appl_area.cPprFFInd = NO_IND;

      if (nPprABElligible == TRUE)
            R02384.R02384_appl_area.cPprABInd = YES_IND;
      else
            R02384.R02384_appl_area.cPprABInd = NO_IND;
   }
   else
   {
      R02384.R02384_appl_area.cPprFFInd = A03834.A03834_appl_area.cPprFFInd;
      R02384.R02384_appl_area.cPprABInd = A03834.A03834_appl_area.cPprABInd;
   }

  /*************************************************************************************/
  /**  Added NW employee number, other employment indicator and salary scale id       **/
  /*************************************************************************************/

     strcpy(R02384.R02384_appl_area.sNwEmplNb,A03834.A03834_appl_area.sNwEmplNb);
     strcpy(R02384.R02384_appl_area.sSlrySclIdGrdCd, DTL_REC.sSlrySclId);
     strcpy(R02384.R02384_appl_area.sOthrEmptCd, DTL_REC.sOthrEmptCd);
}


/******************************************************************
**                                                               **
** Function Name:   TPM_4320_UpdatePprRecord                     **
**                                                               **
** Description:     This function calls the service to insert    **
**                  into the PPR table.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_4320_UpdatePprRecord()
{
   short   nSvcRtnCd;   /* Service return code */


   /***************************************************/
   /** Call service to update a row on the PPR table **/
   /***************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02384,&A02384,SERVICE_ID_02384,1,sizeof(_R02384_APPL_AREA));

   /** Service Return Code Processing **/
   switch (nSvcRtnCd)
     {
       case ARC_SUCCESS:
          RS.updt_ppr_record_cntr++;
          break;
        
       default:
          BCH_FormatMessage(1,TXT_SVC_UNSUCC);
          BCH_FormatMessage(2,TXT_SVC,"FYS02384");
          BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
          BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4320_UpdatePprRecord");
          break;  

      }
}




/******************************************************************
**                                                               **
** Function Name:   TPM_4400_ProcessNrevRecAdd                   **
**                                                               **
** Description:     Format the nonrev record and insert it       **
**                  into the table.                              **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int  TPM_4400_ProcessNrevRecAdd()
{
   short   nSvcRtnCd;   /* Service return code */


   TPM_4405_FormatNrevAddRec();

   TPM_4410_InsertNrevRecord();
}


 
/******************************************************************
**                                                               **
** Function Name:   TPM_4405_FormatNrevAddRec                    **
**                                                               **
** Description:     Add the nonrev record.                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_4405_FormatNrevAddRec()
{
   short   nSvcRtnCd;        /* Service return code */


   /*** Initialize Service Request and Answer Blocks **/
   memset(&R02438, LOW_VALUES, sizeof(_R02438));
   memset(&A02438, LOW_VALUES, sizeof(_A02438));

   /** Format the request block for the advanced update * */
   strcpy(R02438.R02438_appl_area.sPprNbr,DTL_REC.sPprNbr);
   strcpy(R02438.R02438_appl_area.sNrevNbr,DTL_REC.sDesNrevNbr);
   strcpy(R02438.R02438_appl_area.sNrevTypCd,DTL_REC.sPsgrTypeCd);
   strcpy(R02438.R02438_appl_area.sNrevBdayDt, UTL_ConvertDate(DTL_REC.sBirthDt, CNV_YYYYMMDD_TO_DB));

   if ((nMaxParentInd == TRUE) || (nPprRevoked == TRUE) || (nProcessAsRevoked == TRUE))
     {
     strcpy(R02438.R02438_appl_area.sPassStsCd, REVOKED);
     R02438.R02438_appl_area.cNrevPassChgInd = 'Y';
     }
   else
     {
     strcpy(R02438.R02438_appl_area.sPassStsCd, ACTIVE);
     R02438.R02438_appl_area.cNrevPassChgInd = ' ';
     }
   strcpy(R02438.R02438_appl_area.sPassSusExpDt, LOW_DATE);

   /*strcpy(R02438.R02438_appl_area.sNrevNm, DTL_REC.sPsgrNm);*/
    if (nOneInitialLstNm == TRUE)
	 {
	 strcpy(R02438.R02438_appl_area.sNrevNm, sFullNm);        
	 }
     else
         {
	 strcpy(R02438.R02438_appl_area.sNrevNm, DTL_REC.sPsgrNm);
	 }
   strcpy(R02438.R02438_appl_area.sNrevLstNm,sLstNm);
   strcpy(R02438.R02438_appl_area.sNrevFrstNm,sFrstNm);
   R02438.R02438_appl_area.cNrevMidNm = cMidNm;

   strcpy(R02438.R02438_appl_area.sNrevSrcCd,DTL_REC.sSourceSys);

   TPM_7040_DetermineImputedTravelInd();   

   if ((nIntlStation == TRUE) &&
      ((strcmp(DTL_REC.sSourceSys, "DL") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "TQ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OH") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "XJ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "S5") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "ML") == 0)) && 
      ((strcmp(A03834.A03834_appl_area.sPprRsdncyStsCd, "EX") != 0)) &&
      ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_DEP_ADULT) == 0))) 
      cImputedInd = 'N';

   if ((nIntlStation == TRUE) &&
      ((strcmp(DTL_REC.sSourceSys, "DL") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "TQ") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "OH") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "XJ") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "S5") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "MN") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "ML") == 0)) &&
      ((strcmp(A03834.A03834_appl_area.sPprRsdncyStsCd, "EX") == 0)) &&
      ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_DEP_ADULT) == 0)))
       cImputedInd = 'Y';
   
   if ((nIntlStation == FALSE) &&
        (cImputedInd == 'N') &&
      ((strcmp(DTL_REC.sSourceSys, "DL") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "TQ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OH") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "XJ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "S5") == 0) ||
	  (strcmp(DTL_REC.sSourceSys, "MN") == 0) ||
	  (strcmp(DTL_REC.sSourceSys, "ML") == 0)) && 
      ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_DEP_ADULT) == 0))) 
      cImputedInd = 'Y';
   
   /*** DGS , Delta Academy domestic partners ****/
   /*** L. Scott 06-02-09                     ****/

   /***  ASA,Chautauqua,Freedom,Pinnacle and Shuttle America changed to imputed 'Y' 03/08/2010 ***/
   /*** if (((strcmp(DTL_REC.sSourceSys, "AS") == 0) ||        ASA                             ***/
   /*** (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||             Pinnacle                        ***/
   /*** (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||             Chautauqua                      ***/
   /*** (strcmp(DTL_REC.sSourceSys, "S5") == 0) ||             Shuttle                         ***/
   /*** (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||             Freedom                         ***/
   /**********************************************************************************************/
   /*** BBE 06-11-2014 - Commented out the below statement.  Per Carol Smart, the DP, CD, and  ***/
   /*** SD passenger types for CA and DS should not be set to Ticketed. They should be Imputed ***/
   /***  if (((strcmp(DTL_REC.sSourceSys, "CA") == 0) ||                                       ***/
   /***   (strcmp(DTL_REC.sSourceSys, "DS") == 0)) &&                                          ***/
   /***   ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||                             ***/
   /***   (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||                                ***/
   /***   (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0)))                               ***/
   /***   cImputedInd = 'T';                                                                   ***/
   /**********************************************************************************************/

   /***********************************************************/
   
   R02438.R02438_appl_area.cPassImptInd = cImputedInd;

   /********************************************************************/
   /** If A1 record, set the days/miles indicator to 'D' (default)    **/
   /** but if C2 record, set to A1's setting.                         **/
   /********************************************************************/
   if (strcmp(DTL_REC.sRecType, A1_REC) == 0)
      {
      R02438.R02438_appl_area.cNrevDyMiInd = 'D';
      R02438.R02438_appl_area.cNrevDyMiNxtInd = 'D';
      R02438.R02438_appl_area.nPassCardNbr = 00;
      }
   else
      {
      TPM_4415_SelectNrevPprDyMiInd();

/**** Added the following to force nrev_dy_mi_ind and nrev_dy_mi_nxt_ind to 
      days for all companion records.    (L.Scott, 04/05/00)    ******/

      if (strcmp(DTL_REC.sPsgrTypeCd, "CP") == 0)
	 {
	 R02438.R02438_appl_area.cNrevDyMiInd = 'D';
         R02438.R02438_appl_area.cNrevDyMiNxtInd = 'D';
         R02438.R02438_appl_area.nPassCardNbr = 00;
	 }
/***** end of (L.Scott, 04/05/00  ******/
      else
	 {
         R02438.R02438_appl_area.cNrevDyMiInd = A04187.A04187_appl_area.cNrevDyMiInd;
         R02438.R02438_appl_area.cNrevDyMiNxtInd = A04187.A04187_appl_area.cNrevDyMiNxtInd; 
         R02438.R02438_appl_area.nPassCardNbr = 00 ;
	 }
      }

   /*if ((nNrevPresent == FALSE) && (strcmp(DTL_REC.sDesNrevNbr, "00") == 0)) */
      if (strcmp(DTL_REC.sDesNrevNbr, "00") == 0)  
	 {
         if ((strcmp(DTL_REC.sPassGrpCd, "OA") == 0) ||
	     (strcmp(DTL_REC.sPassGrpCd, "OB") == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, "OC") == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, "WG") == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, "WN") == 0) ||
             (strcmp(DTL_REC.sStation, "ABV") == 0) ||
             (strcmp(DTL_REC.sStation, "ACA") == 0) ||
             (strcmp(DTL_REC.sStation, "ACC") == 0) ||
             (strcmp(DTL_REC.sStation, "AGP") == 0) ||
             (strcmp(DTL_REC.sStation, "AMM") == 0) ||
             (strcmp(DTL_REC.sStation, "AMS") == 0) ||
             (strcmp(DTL_REC.sStation, "ANU") == 0) ||
             (strcmp(DTL_REC.sStation, "ARN") == 0) ||
             (strcmp(DTL_REC.sStation, "ATH") == 0) ||
             (strcmp(DTL_REC.sStation, "AUA") == 0) ||
             (strcmp(DTL_REC.sStation, "BCN") == 0) ||
             (strcmp(DTL_REC.sStation, "BEG") == 0) ||
             (strcmp(DTL_REC.sStation, "BER") == 0) ||
             (strcmp(DTL_REC.sStation, "BGI") == 0) ||
             (strcmp(DTL_REC.sStation, "BJS") == 0) ||
             (strcmp(DTL_REC.sStation, "BJX") == 0) ||
             (strcmp(DTL_REC.sStation, "BKK") == 0) ||
             (strcmp(DTL_REC.sStation, "BOG") == 0) ||
             (strcmp(DTL_REC.sStation, "BOM") == 0) ||
             (strcmp(DTL_REC.sStation, "BRU") == 0) ||
             (strcmp(DTL_REC.sStation, "BUD") == 0) ||
             (strcmp(DTL_REC.sStation, "BUH") == 0) ||
             (strcmp(DTL_REC.sStation, "BZE") == 0) ||
             (strcmp(DTL_REC.sStation, "CAI") == 0) ||
             (strcmp(DTL_REC.sStation, "CCS") == 0) ||
             (strcmp(DTL_REC.sStation, "CDG") == 0) ||
             (strcmp(DTL_REC.sStation, "CPH") == 0) ||
             (strcmp(DTL_REC.sStation, "CPT") == 0) ||
             (strcmp(DTL_REC.sStation, "CUL") == 0) ||
             (strcmp(DTL_REC.sStation, "CUN") == 0) ||
             (strcmp(DTL_REC.sStation, "CZM") == 0) ||
             (strcmp(DTL_REC.sStation, "DEL") == 0) ||
             (strcmp(DTL_REC.sStation, "DKR") == 0) ||
             (strcmp(DTL_REC.sStation, "DUB") == 0) ||
             (strcmp(DTL_REC.sStation, "DUS") == 0) ||
             (strcmp(DTL_REC.sStation, "DXB") == 0) ||
             (strcmp(DTL_REC.sStation, "EDI") == 0) ||
             (strcmp(DTL_REC.sStation, "EZE") == 0) ||
             (strcmp(DTL_REC.sStation, "FBU") == 0) ||
             (strcmp(DTL_REC.sStation, "FCO") == 0) ||
             (strcmp(DTL_REC.sStation, "FOR") == 0) ||
             (strcmp(DTL_REC.sStation, "FRA") == 0) ||
             (strcmp(DTL_REC.sStation, "GCM") == 0) ||
             (strcmp(DTL_REC.sStation, "GDL") == 0) ||
             (strcmp(DTL_REC.sStation, "GEO") == 0) ||
             (strcmp(DTL_REC.sStation, "GIG") == 0) ||
             (strcmp(DTL_REC.sStation, "GRU") == 0) ||
             (strcmp(DTL_REC.sStation, "GUA") == 0) ||
             (strcmp(DTL_REC.sStation, "GVA") == 0) ||
             (strcmp(DTL_REC.sStation, "GYE") == 0) ||
             (strcmp(DTL_REC.sStation, "HAM") == 0) ||
             (strcmp(DTL_REC.sStation, "HEL") == 0) ||
             (strcmp(DTL_REC.sStation, "HKG") == 0) ||
             (strcmp(DTL_REC.sStation, "HMO") == 0) ||
             (strcmp(DTL_REC.sStation, "IST") == 0) ||
             (strcmp(DTL_REC.sStation, "IZM") == 0) ||
             (strcmp(DTL_REC.sStation, "JNB") == 0) ||
             (strcmp(DTL_REC.sStation, "KBP") == 0) ||
             (strcmp(DTL_REC.sStation, "KIN") == 0) ||
             (strcmp(DTL_REC.sStation, "KRK") == 0) ||
             (strcmp(DTL_REC.sStation, "KWI") == 0) ||
             (strcmp(DTL_REC.sStation, "LED") == 0) ||
             (strcmp(DTL_REC.sStation, "LGW") == 0) ||
             (strcmp(DTL_REC.sStation, "LHR") == 0) ||
             (strcmp(DTL_REC.sStation, "LIM") == 0) ||
             (strcmp(DTL_REC.sStation, "LIR") == 0) ||
             (strcmp(DTL_REC.sStation, "LIS") == 0) ||
             (strcmp(DTL_REC.sStation, "LMM") == 0) ||
             (strcmp(DTL_REC.sStation, "LON") == 0) ||
             (strcmp(DTL_REC.sStation, "LOS") == 0) ||
             (strcmp(DTL_REC.sStation, "LTO") == 0) ||
             (strcmp(DTL_REC.sStation, "LYS") == 0) ||
             (strcmp(DTL_REC.sStation, "MAA") == 0) ||
             (strcmp(DTL_REC.sStation, "MAD") == 0) ||
             (strcmp(DTL_REC.sStation, "MAN") == 0) ||
             (strcmp(DTL_REC.sStation, "MAO") == 0) ||
             (strcmp(DTL_REC.sStation, "MBJ") == 0) ||
             (strcmp(DTL_REC.sStation, "MEX") == 0) ||
             (strcmp(DTL_REC.sStation, "MGA") == 0) ||
             (strcmp(DTL_REC.sStation, "MID") == 0) ||
             (strcmp(DTL_REC.sStation, "MIL") == 0) ||
             (strcmp(DTL_REC.sStation, "MOW") == 0) ||
             (strcmp(DTL_REC.sStation, "MTY") == 0) ||
             (strcmp(DTL_REC.sStation, "MUC") == 0) ||
             (strcmp(DTL_REC.sStation, "MXP") == 0) ||
             (strcmp(DTL_REC.sStation, "MZT") == 0) ||
             (strcmp(DTL_REC.sStation, "NBO") == 0) ||
             (strcmp(DTL_REC.sStation, "NCE") == 0) ||
             (strcmp(DTL_REC.sStation, "NGO") == 0) ||
             (strcmp(DTL_REC.sStation, "NRT") == 0) ||
             (strcmp(DTL_REC.sStation, "ORY") == 0) ||
             (strcmp(DTL_REC.sStation, "OSL") == 0) ||
             (strcmp(DTL_REC.sStation, "OTP") == 0) ||
             (strcmp(DTL_REC.sStation, "PAR") == 0) ||
             (strcmp(DTL_REC.sStation, "PLS") == 0) ||
             (strcmp(DTL_REC.sStation, "POP") == 0) ||
             (strcmp(DTL_REC.sStation, "POS") == 0) ||
             (strcmp(DTL_REC.sStation, "POZ") == 0) ||
             (strcmp(DTL_REC.sStation, "PRG") == 0) ||
             (strcmp(DTL_REC.sStation, "PSA") == 0) ||
             (strcmp(DTL_REC.sStation, "PTY") == 0) ||
             (strcmp(DTL_REC.sStation, "PUJ") == 0) ||
             (strcmp(DTL_REC.sStation, "PVR") == 0) ||
             (strcmp(DTL_REC.sStation, "REC") == 0) ||
             (strcmp(DTL_REC.sStation, "RIO") == 0) ||
             (strcmp(DTL_REC.sStation, "ROM") == 0) ||
             (strcmp(DTL_REC.sStation, "RTB") == 0) ||
             (strcmp(DTL_REC.sStation, "SAL") == 0) ||
             (strcmp(DTL_REC.sStation, "SAO") == 0) ||
             (strcmp(DTL_REC.sStation, "SAP") == 0) ||
             (strcmp(DTL_REC.sStation, "SCL") == 0) ||
             (strcmp(DTL_REC.sStation, "SDQ") == 0) ||
             (strcmp(DTL_REC.sStation, "SIN") == 0) ||
             (strcmp(DTL_REC.sStation, "SJD") == 0) ||
             (strcmp(DTL_REC.sStation, "SJO") == 0) ||
             (strcmp(DTL_REC.sStation, "SNN") == 0) ||
             (strcmp(DTL_REC.sStation, "STI") == 0) ||
             (strcmp(DTL_REC.sStation, "STO") == 0) ||
             (strcmp(DTL_REC.sStation, "STR") == 0) ||
             (strcmp(DTL_REC.sStation, "SVO") == 0) ||
             (strcmp(DTL_REC.sStation, "SXM") == 0) ||
             (strcmp(DTL_REC.sStation, "SYD") == 0) ||
             (strcmp(DTL_REC.sStation, "TGU") == 0) ||
             (strcmp(DTL_REC.sStation, "TIJ") == 0) ||
             (strcmp(DTL_REC.sStation, "TLV") == 0) ||
             (strcmp(DTL_REC.sStation, "TRC") == 0) ||
             (strcmp(DTL_REC.sStation, "TXL") == 0) ||
             (strcmp(DTL_REC.sStation, "TYO") == 0) ||
             (strcmp(DTL_REC.sStation, "UIO") == 0) ||
             (strcmp(DTL_REC.sStation, "UVF") == 0) ||
             (strcmp(DTL_REC.sStation, "VCE") == 0) ||
             (strcmp(DTL_REC.sStation, "VIE") == 0) ||
             (strcmp(DTL_REC.sStation, "VLC") == 0) ||
             (strcmp(DTL_REC.sStation, "WAW") == 0) ||
             (strcmp(DTL_REC.sStation, "YEG") == 0) ||
             (strcmp(DTL_REC.sStation, "YUL") == 0) ||
             (strcmp(DTL_REC.sStation, "YVR") == 0) ||
             (strcmp(DTL_REC.sStation, "YYC") == 0) ||
             (strcmp(DTL_REC.sStation, "YYZ") == 0) ||
             (strcmp(DTL_REC.sStation, "ZAG") == 0) ||
             (strcmp(DTL_REC.sStation, "ZCL") == 0) ||
             (strcmp(DTL_REC.sStation, "ZIH") == 0) ||
             (strcmp(DTL_REC.sStation, "ZRH") == 0))

	 {
	 R02438.R02438_appl_area.cPrvAtvnFeeCd = 'E';
         cSavePrvAtvnFeeCd = 'E';
	 strcpy(R02438.R02438_appl_area.sPrvAtvnLupdtLts, LOW_DATE);
	 R02438.R02438_appl_area.cCurAtvnFeeCd = 'E';
         cSaveCurAtvnFeeCd = 'E';
	 strcpy(R02438.R02438_appl_area.sCurAtvnLupdtLts, LOW_DATE);
	 R02438.R02438_appl_area.cNxtAtvnFeeCd = 'E';
         cSaveNxtAtvnFeeCd = 'E';
	 strcpy(R02438.R02438_appl_area.sNxtAtvnLupdtLts, LOW_DATE);
	  }
      else
	 {
	 R02438.R02438_appl_area.cPrvAtvnFeeCd = 'N';
         cSavePrvAtvnFeeCd = 'N';
	 strcpy(R02438.R02438_appl_area.sPrvAtvnLupdtLts, LOW_DATE);
	 R02438.R02438_appl_area.cCurAtvnFeeCd = 'N';
         cSaveCurAtvnFeeCd = 'N';
	 strcpy(R02438.R02438_appl_area.sCurAtvnLupdtLts, LOW_DATE);
	 R02438.R02438_appl_area.cNxtAtvnFeeCd = 'N';
         cSaveNxtAtvnFeeCd = 'N';
	 strcpy(R02438.R02438_appl_area.sNxtAtvnLupdtLts, LOW_DATE);
	  }
	  
      }
     /* if (strcmp(DTL_REC.sPsgrTypeCd, "SF") != 0)  */
      else if (strcmp(DTL_REC.sPsgrTypeCd, "SF") != 0)
      {
      R02438.R02438_appl_area.cPrvAtvnFeeCd, cSavePrvAtvnFeeCd;
      strcpy(R02438.R02438_appl_area.sPrvAtvnLupdtLts, sSavePrvAtvnLupdtLts);
      R02438.R02438_appl_area.cCurAtvnFeeCd, cSaveCurAtvnFeeCd;
      strcpy(R02438.R02438_appl_area.sCurAtvnLupdtLts, sSaveCurAtvnLupdtLts);
      R02438.R02438_appl_area.cNxtAtvnFeeCd, cSaveNxtAtvnFeeCd;
      strcpy(R02438.R02438_appl_area.sNxtAtvnLupdtLts, sSaveNxtAtvnLupdtLts);
      }

   /**  Add gender from input record   ***/
   //strcpy(R02438.R02438_appl_area.cGndrTypCd,DTL_REC.cGndr);
   R02438.R02438_appl_area.cGndrTypCd = DTL_REC.cGndr[0];
}


/******************************************************************
**                                                               **
** Function Name:   TPM_4410_InsertNrevRecord                    **
**                                                               **
** Description:     This function calls the service to insert    **
**                  into the Nrev table.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_4410_InsertNrevRecord()
{
   short   nSvcRtnCd;   /* Service return code */


   /******************************************************/
   /** Call service to insert a row into the Nrev table **/
   /******************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R02438,&A02438,SERVICE_ID_02438,1,sizeof(_R02438_APPL_AREA));

   /** Service Return Code Processing **/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         RS.add_nrev_record_cntr++;
         if (cParentChgInd == 'Y')
            RS.max_parent_record_cntr++;

         break;
        
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02438");
         sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, PassGrp = %s, PsgrType = %s, RecType = %s, EffDt = %s",
                                     DTL_REC.cRecordId,
                                     DTL_REC.sPprNbr,
                                     DTL_REC.sDesNrevNbr,
                                     DTL_REC.sPassGrpCd,
                                     DTL_REC.sPsgrTypeCd,
                                     DTL_REC.sRecType,
                                     DTL_REC.sEffDt);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4410_InsertNrevRecord");
         break;  

      }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_4415_SelectNrevPprDyMiInd                **
**                                                               **
** Description:     This function calls the service to insert    **
**                  into the Nrev table.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
int     TPM_4415_SelectNrevPprDyMiInd()
{
   short   nSvcRtnCd;   /* Service return code */
 
 
   /*** Initialize Service Request and Answer Blocks **/
   memset(&R04187, LOW_VALUES, sizeof(_R04187));
   memset(&A04187, LOW_VALUES, sizeof(_A04187));

   /** load service request block                    **/
   strcpy(R04187.R04187_appl_area.sPprNbr, DTL_REC.sPprNbr);

   /******************************************************/
   /** Call service to select a row from the Nrev table **/
   /******************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04187,&A04187,SERVICE_ID_04187,1,sizeof(_R04187_APPL_AREA));
 
   /** Service Return Code Processing **/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;
         
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04187");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4415_SelectNrevPprDyMiInd");
      }

}



/******************************************************************
**                                                               **
** Function Name:   TPM_4510_UpdateNrevRecordCursor              **
**                                                               **
** Description:     This function calls the service to update    **
**                  a record on the Nrev table.                  **
**                  Service = 4309                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_4510_UpdateNrevRecordCursor()
{
   short   nSvcRtnCd;   /* Service return code */


   /****************************************************/
   /** Call service to update a row on the Nrev table **/
   /****************************************************/
   R04309.R04309_appl_area.cArchCursorOpTxt = UPDATE_ROW;


   nSvcRtnCd = BCH_InvokeService(EPBUPD8,&R04309,&A04309,SERVICE_ID_04309,1,sizeof(_R04309_APPL_AREA));


   /** Service Return Code Processing **/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         RS.updt_nrev_record_cntr++;
         break;
        
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04309");
         sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, PassGrp = %s, PsgrType = %s, RecType = %s, EffDt = %s",
                                     DTL_REC.cRecordId,
                                     DTL_REC.sPprNbr,
                                     DTL_REC.sDesNrevNbr,
                                     DTL_REC.sPassGrpCd,
                                     DTL_REC.sPsgrTypeCd,
                                     DTL_REC.sRecType,
                                     DTL_REC.sEffDt);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4510_UpdateNrevRecordCursor");
         break;  

      }

}


/******************************************************************
**                                                               **
** Function Name:   TPM_4520_UpdateAllNrevRecs                   **
**                                                               **
** Description:     This function calls the service to open a    **
**                  cursor of all nonrev records for the         **
**                  current ppr.  Then it updates the nonrev     **
**                  record for each one.                         **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_4520_UpdateAllNrevRecs()
{
   short   nSvcRtnCd;   /* Service return code */
   nEndOfPassRiders = FALSE;


   /*****************************************/
   /** Open Cursor for all Nrev Passengers **/
   /*****************************************/
   TPM_7050_CursorNrevPsgr();

   while ((nSvcRtnCd != ARC_ROW_NOT_FOUND) && (nEndOfPassRiders == FALSE))
      {  
      TPM_4530_FormatNrevUpdtFromCursor();

      if (nChgToIneligible == FALSE)
         {
         TPM_4510_UpdateNrevRecordCursor();
         }

      /******************************************************************/
      /** If the Pass Group or Hire Date changes for the PPR,          **/
      /** or the current psgr is unrevoked,     (added 9/6/96 - GHM)   **/
      /** reset the allotments for all nonrev passengers for this PPR. **/
      /** This section includes writing a record to t_deltamatic       **/
      /** when appropriate.                                            **/
      /******************************************************************/
      if ((cPGpChgInd == 'Y') || (cHireDtChgInd == 'Y') || (nUnRevokedInd == TRUE))
         {
         nResetAll = TRUE;

         TPM_7475_ReadPassTypeCodes();
         }
      else
      /*********************************************************************/
      /** These changes cause a Deltamatic record to be written:          **/
      /**    A1 birthdate change,                                         **/ 
      /**    A1 name change,                                              **/ 
      /**    A1 card issue date change,                                   **/
      /**    current passenger is unrevoked  (removed 9/6/96 - GHM)       **/
      /**                                                                 **/
      /** NOTE:  If changed to ineligible, this was taken care of in      **/
      /** TPM_4530_FormatNrevUpdtFromCursor, above.                       **/
      /**                                                                 **/
      /** NOTE:  If pass group or hire date changed, or current psgr      **/
      /** was unrevoked, this was taken care of in                        **/
      /** TPM_7475_ReadPassTypeCodes(), above.                            **/
      /**                                                                 **/
      /*********************************************************************/
      if ((cImputedIndChg == 'Y') ||
          ((cBdayChgInd == 'Y') && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0)) ||
          ((cNameChgInd == 'Y') && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0)) ||
          ((nCardIssDtChg == TRUE) && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0)))
         {
         /****** Initialize request and answer blocks *****/
         memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA));
         memset(&A04325.A04325_appl_area, LOW_VALUES, sizeof(_A04325_APPL_AREA));

         strcpy(sPprNbr, DTL_REC.sPprNbr);
         strcpy(sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
         R04325.R04325_appl_area.cEmplArRecInd = CHANGE_REC;

         TPM_7520_FormatDlmaticRec(); 
         }

      nChgToIneligible = FALSE;
      nUnRevokedInd = FALSE;

      /********************************************************/
      /** get the next database row from the nrev psgr table **/
      /********************************************************/
      TPM_7055_NextNrevPsgr();
      }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_4530_FormatNrevUpdtFromCursor            **
**                                                               **
** Description:     This function formats the nonrev record      **
**                  update from the nonrev cursor.               **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_4530_FormatNrevUpdtFromCursor()
{
   short   nSvcRtnCd;   /* Service return code */

   cParentChgInd = 'N';
   cCpInd = 'N';
   nValidPgpPtyp = FALSE;


/***********************************************************************************/
/*   if ((strcmp(A04710.A04710_appl_area.sNrevTypCd, COMPANION) == 0) ||
**          (strcmp(A04710.A04710_appl_area.sNrevTypCd, SPOUSE) == 0) ||
**          (strcmp(A04309.A04309_appl_area.sNrevTypCd, SPOUSE) == 0) ||
**          (strcmp(A04309.A04309_appl_area.sNrevTypCd, COMPANION) == 0))
*/          
   if ((strcmp(A04309.A04309_appl_area.sNrevTypCd, SPOUSE) == 0) ||
          (strcmp(A04309.A04309_appl_area.sNrevTypCd, COMPANION) == 0) ||
          (strcmp(A04309.A04309_appl_area.sNrevTypCd, DOMESTIC_PARTNER) == 0))
         cCpInd = 'Y';

   /*********************************************************************************/
   /** If the nonrev type is PARENT, check to see if there are already             **/
   /** two parents on the nrev passenger table.  If so, set nMaxParentInd          **/
   /** to TRUE.                                                                    **/
   /*********************************************************************************/
   if (strcmp(A04309.A04309_appl_area.sNrevTypCd, PARENT) == 0)
      {  
      TPM_5510_CheckForParents();

      /*****************************************************************************************/
      /** If the parent used to be revoked, and is now eligible, this process cannot just     **/
      /** change them back to active if there are already two or more active or suspended     **/
      /** parents.  In that case, set cParentchgInd to 'Y', so the process will leave them    **/
      /** the way they were and put them on the error report to be checked by the Pass Bureau.**/
      /*****************************************************************************************/
      if (strcmp(A04309.A04309_appl_area.sPassStsCd, ACTIVE) == 0)
         cParentChgInd = 'N';
      else
      if ((strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) == 0) && (nMaxParentInd == TRUE))
         cParentChgInd = 'Y';
      else
         cParentChgInd = 'N';
      }  

   /**********************************************************************/
   /** Initialize Service Request Block for cursor update.              **/
   /**********************************************************************/
   memset(&R04309.R04309_appl_area, LOW_VALUES, sizeof(_R04309_APPL_AREA));
/*   R04309.R04309_appl_area.cNrevPassChgInd = ' '; */

   /**********************************************************************/
   /** Validate the pass group/passenger type code for each nonrev      **/
   /**********************************************************************/
   memset(&R02861, LOW_VALUES, sizeof(_R02861));
   strcpy(R02861.R02861_appl_area.sNrevTypCd, A04309.A04309_appl_area.sNrevTypCd);
TPM_7015_EvalValidPsgrType();
   if (nValidPgpPtyp == TRUE)
      {
      strcpy(R04309.R04309_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R04309.R04309_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
      strcpy(R04309.R04309_appl_area.sNrevTypCd, A04309.A04309_appl_area.sNrevTypCd);

      if ((cBdayChgInd == 'Y') && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0))
         strcpy(R04309.R04309_appl_area.sNrevBdayDt, UTL_ConvertDate(DTL_REC.sBirthDt, CNV_YYYYMMDD_TO_DB));
      else
         strcpy(R04309.R04309_appl_area.sNrevBdayDt, A04309.A04309_appl_area.sNrevBdayDt);

      if ((cNameChgInd == 'Y') && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0))
         {
         /*strcpy(R04309.R04309_appl_area.sNrevNm, DTL_REC.sPsgrNm);*/
	  if (nOneInitialLstNm == TRUE)
	       {
	       strcpy(R04309.R04309_appl_area.sNrevNm, sFullNm);        
	       }
	     else
	       {
	       strcpy(R04309.R04309_appl_area.sNrevNm, DTL_REC.sPsgrNm);
	       }
         strcpy(R04309.R04309_appl_area.sNrevLstNm, sLstNm);
         strcpy(R04309.R04309_appl_area.sNrevFrstNm, sFrstNm);
         R04309.R04309_appl_area.cNrevMidNm = cMidNm;
         }
      else
         {
         strcpy(R04309.R04309_appl_area.sNrevNm, A04309.A04309_appl_area.sNrevNm);
         strcpy(R04309.R04309_appl_area.sNrevLstNm, A04309.A04309_appl_area.sNrevLstNm);
         strcpy(R04309.R04309_appl_area.sNrevFrstNm, A04309.A04309_appl_area.sNrevFrstNm);
         if (A04309.A04309_appl_area.cNrevMidNm == '\0')
            R04309.R04309_appl_area.cNrevMidNm = ' ';
         else
            R04309.R04309_appl_area.cNrevMidNm = A04309.A04309_appl_area.cNrevMidNm;
         }

      /*****************************************************************************************/
      /** SET PASS STATUS                                                                     **/
      /** At this point, the pass group/passenger type is valid.                              **/
      /*****************************************************************************************/
      /**                                                                                     **/
      /*****************************************************************************************/
      /** The pass group/passenger type is valid here.                                        **/
      /** If processing as REVOKED (i.e. Pass Group Code is "XX"), must be set to REVOKED.    **/
      /** If Pass Group Changed back to a valid group from REVOKED, reset passenger to ACTIVE **/
      /** EXCEPT in the case where max parents are present - this must be handled manually by **/
      /** by the Delta Pass Bureau or the WS or TQ HR area.                                  **/
      /*****************************************************************************************/

      if (nProcessAsRevoked == TRUE)
         {
         if ((strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) == 0) ||
             (strcmp(A04309.A04309_appl_area.sPassStsCd, SUSPENDED) == 0) ||
             (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED_DEATH) == 0) ||
             (strcmp(A04309.A04309_appl_area.sPassStsCd, EMP_REVOKED) == 0)) 
            {
            if (A04309.A04309_appl_area.cNrevPassChgInd == 'Y')
               {
               strcpy(R04309.R04309_appl_area.sPassStsCd, A04309.A04309_appl_area.sPassStsCd);
               R04309.R04309_appl_area.cNrevPassChgInd = A04309.A04309_appl_area.cNrevPassChgInd;
               strcpy(R04309.R04309_appl_area.sPassSusExpDt, A04309.A04309_appl_area.sPassSusExpDt);
               nUnRevokedInd = FALSE;
               }
            else
               {
               strcpy(R04309.R04309_appl_area.sPassStsCd, A04309.A04309_appl_area.sPassStsCd);
               R04309.R04309_appl_area.cNrevPassChgInd = ' ';  /*this field must be space, not null*/
               strcpy(R04309.R04309_appl_area.sPassSusExpDt, A04309.A04309_appl_area.sPassSusExpDt);
               nUnRevokedInd = FALSE;
               }
            }
         else /* not already revoked - revoke now */
            {
            strcpy(R04309.R04309_appl_area.sPassStsCd,REVOKED);
            R04309.R04309_appl_area.cNrevPassChgInd = 'Y';
            strcpy(R04309.R04309_appl_area.sPassSusExpDt, LOW_DATE);
            nUnRevokedInd = FALSE;
            }
         }
      else /* NOT processing as revoked */
         {
         /**********************************************************************/
         /** If the person was REVOKED, and this program did the revoking     **/
         /** (i.e. cNrevPassChgInd = 'Y'), unrevoke them only if              **/
         /** cParentChgInd = 'N'.                                             **/
         /**********************************************************************/
         if (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) == 0)
            {
            if (A04309.A04309_appl_area.cNrevPassChgInd == 'Y')
               {
               if ((cParentChgInd == 'N') && (cCpInd == 'N'))
                  {
                  strcpy(R04309.R04309_appl_area.sPassStsCd, ACTIVE);
                  R04309.R04309_appl_area.cNrevPassChgInd = ' '; 
                  strcpy(R04309.R04309_appl_area.sPassSusExpDt, LOW_DATE);
                  nUnRevokedInd = TRUE;
                  }
               else
                  {
                  /*****************************************************/
                  /** ERROR - Parent Status Change - handle manually. **/
                  /** Cannot unrevoke when there are max parents.     **/
                  /** Leave them the way they were, and write record  **/
                  /** to ERROR REPORT.                                **/
                  /*****************************************************/
                  strcpy(R04309.R04309_appl_area.sPassStsCd, A04309.A04309_appl_area.sPassStsCd);
                  R04309.R04309_appl_area.cNrevPassChgInd = A04309.A04309_appl_area.cNrevPassChgInd;  
/*                  R04309.R04309_appl_area.cNrevPassChgInd = ' '; */
                  strcpy(R04309.R04309_appl_area.sPassSusExpDt, A04309.A04309_appl_area.sPassSusExpDt);
                  nUnRevokedInd = FALSE;

                  cErrorCode = '2';
                  if (strcmp(DTL_REC.sSourceSys, DELTA) == 0)
                     { 
                     TPM_7611_GenerateEPB50011();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)
                     { 
                     TPM_7612_GenerateEPB50012();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)
                     { 
                     TPM_7613_GenerateEPB50013();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)
                     { 
                     TPM_7614_GenerateEPB50014();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, ASA) == 0)
                     { 
                     TPM_7615_GenerateEPB50015();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, COMAIR) == 0)
                     { 
                     TPM_7616_GenerateEPB50016();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0) 
                     { 
                     TPM_7617_GenerateEPB50017();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY) == 0)
                     { 
                     TPM_7618_GenerateEPB50018();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0)
                     { 
                     TPM_7619_GenerateEPB50019();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, ACA) == 0)
                     { 
                     TPM_7620_GenerateEPB50020();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0)
                     { 
                     TPM_7621_GenerateEPB50021();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0)
                     { 
                     TPM_7622_GenerateEPB50022();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, FREEDOM) == 0)
                     { 
                     TPM_7623_GenerateEPB50023();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, BIG_SKY) == 0)
                     { 
                     TPM_7624_GenerateEPB50024();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET) == 0)
                     { 
                     TPM_7625_GenerateEPB50025();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, PINNACLE) == 0)
                     { 
                     TPM_7626_GenerateEPB50026();
                     } 
                  else
				  //Manual PPR Added data --PPatnaik
				  if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0) 
				  {
					  TPM_7627_GenerateEPB50027();  
				  }
				  else
                  if (strcmp(DTL_REC.sSourceSys, MESABA) == 0)
                     { 
                     TPM_7628_GenerateEPB50028();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, COMPASS) == 0)
                     { 
                     TPM_7629_GenerateEPB50029();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, MLT) == 0)
                     { 
                     TPM_7630_GenerateEPB50030();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE) == 0)
                     { 
                     TPM_7631_GenerateEPB50031();
                     } 
                  else
                  if (strcmp(DTL_REC.sSourceSys, GOJET) == 0)
                     { 
                     TPM_7632_GenerateEPB50032();
                     } 
                  else
                     {
                     sprintf(sErrorMessage, "ERROR 2:  Parent Status Change-handle manually ");
                     BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
                     sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, RecType = %s",
                                             DTL_REC.cRecordId,
                                             DTL_REC.sPprNbr,
                                             DTL_REC.sDesNrevNbr,
                                             DTL_REC.sRecType);
                     BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
                     BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_4530_FormatNrevUpdtFromCursor"); 
                     } 
                  } 
               }
            else
               {
               /******************************************************************************/
               /* leave them the way they were - this person was revoked by the Pass Bureau, */
               /* so must be unrevoked by Pass Bureau                                        */
               /******************************************************************************/
               strcpy(R04309.R04309_appl_area.sPassStsCd, A04309.A04309_appl_area.sPassStsCd);
               R04309.R04309_appl_area.cNrevPassChgInd = A04309.A04309_appl_area.cNrevPassChgInd;  
/*              R04309.R04309_appl_area.cNrevPassChgInd = ' '; */ /* this field must be spaces, not null */
               strcpy(R04309.R04309_appl_area.sPassSusExpDt, A04309.A04309_appl_area.sPassSusExpDt);
               nUnRevokedInd = FALSE;
               }
            }
         else /* not already revoked - no change */
            {
            if (strcmp(A04309.A04309_appl_area.sPassStsCd, SUSPENDED) == 0||
       	    (strcmp(A04309.A04309_appl_area.sPassStsCd, EMP_REVOKED) == 0))
               {
               strcpy(R04309.R04309_appl_area.sPassStsCd,A04309.A04309_appl_area.sPassStsCd);
               R04309.R04309_appl_area.cNrevPassChgInd = A04309.A04309_appl_area.cNrevPassChgInd;  
               strcpy(R04309.R04309_appl_area.sPassSusExpDt, A04309.A04309_appl_area.sPassSusExpDt);
               nUnRevokedInd = FALSE;
               }
            else
               {
               strcpy(R04309.R04309_appl_area.sPassStsCd,A04309.A04309_appl_area.sPassStsCd);
               R04309.R04309_appl_area.cNrevPassChgInd = A04309.A04309_appl_area.cNrevPassChgInd;  
/*              R04309.R04309_appl_area.cNrevPassChgInd = ' '; */ /* this field must be spaces, not null */
               strcpy(R04309.R04309_appl_area.sPassSusExpDt, LOW_DATE);
               nUnRevokedInd = FALSE;
               }
            }
         }
 
      /*************************************************************************************/
      /** When a passenger changes back to active status, or the hire date or birth date  **/
      /** or card issue date changes, a record must be written to the Pass Card Table to  **/
      /** request a new Pass Card.                                                        **/
      /** Any records on the pass card table for this ppr/nrev are deactivated before     **/
      /** the new record is written.                                                      **/
      /*************************************************************************************/
      if ((cHireDtChgInd == 'Y') || (nProcessAsRevoked == TRUE) || 
          ((cNameChgInd == 'Y') && (strcmp(DTL_REC.sRecType, A1_REC) == 0) && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0)) ||
          ((cBdayChgInd == 'Y') && (strcmp(DTL_REC.sRecType, A1_REC) == 0) && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0)) ||
          ((nCardIssDtChg == TRUE) && (strcmp(DTL_REC.sRecType, A1_REC) == 0) && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0)))
         {
         /*****************************************************************************/
         /** First, must deactivate all pass card records on the table for this psgr **/
         /*****************************************************************************/

         /** Initialize Service Request Block **/
         memset(&R02567, LOW_VALUES, sizeof(_R02567));

         /** Format the request block for the update the Pass Card Table **/
         strcpy(R02567.R02567_appl_area.sPprNbr, DTL_REC.sPprNbr);
         strcpy(R02567.R02567_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
         R02567.R02567_appl_area.cCardStsInd = 'D';
         R02567.R02567_appl_area.cCardProcInd = 'P';

         TPM_7330_UpdatePassCardRecord();
         } 

         /*************************************************************************************/
         /**  If not processing as revoked, check to see if a new pass card record is needed **/
         /*************************************************************************************/
         if (nProcessAsRevoked == FALSE)
            {
            if ((cHireDtChgInd == 'Y') ||
                ((cNameChgInd == 'Y') && (strcmp(DTL_REC.sRecType, A1_REC) == 0) && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0)) ||
                ((cBdayChgInd == 'Y') && (strcmp(DTL_REC.sRecType, A1_REC) == 0) && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0)) ||
                ((nCardIssDtChg == TRUE) && (strcmp(DTL_REC.sRecType, A1_REC) == 0) && (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0)))
               {
               /*****************************************/
               /** Now, write the new pass card record **/
               /*****************************************/

               /** Initialize Service Request Block **/
               memset(&R02388, LOW_VALUES, sizeof(_R02388));

               /********************************************************************/
               /** Format the request block for the insert to the Pass Card Table **/
               /********************************************************************/
               strcpy(R02388.R02388_appl_area.sPprNbr, DTL_REC.sPprNbr);
               strcpy(R02388.R02388_appl_area.sNrevNbr, R04309.R04309_appl_area.sNrevNbr);

               if ((strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0) ||
                   (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) ||
                   (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) ||
                   (strcmp(DTL_REC.sSourceSys, ACA) == 0) ||
                   (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) ||
		   (strcmp(DTL_REC.sEmpCatCd, "IN") == 0))
                  {
                  if((strcmp(DTL_REC.sCardIssDt, ZERO_DATE) == 0) || 
                     (strcmp(DTL_REC.sCardIssDt, "") == 0))
                     { 
                     strcpy(R02388.R02388_appl_area.sCardIssDt, LOW_DATE); 
                     R02388.R02388_appl_area.cCardStsInd = 'A';
                     R02388.R02388_appl_area.cCardProcInd = 'P';
                     } 
                  else 
                     { 
                     strcpy(R02388.R02388_appl_area.sCardIssDt, UTL_ConvertDate(DTL_REC.sCardIssDt, CNV_YYYYMMDD_TO_DB)); 
                     R02388.R02388_appl_area.cCardStsInd = 'A';
                     R02388.R02388_appl_area.cCardProcInd = 'P';
                     }   
                  }
               else  
                  { 
                  strcpy(R02388.R02388_appl_area.sCardIssDt, sCurrentTsDt); 
                  R02388.R02388_appl_area.cCardStsInd = 'A';
                  R02388.R02388_appl_area.cCardProcInd = 'N';
                  }

               strcpy(R02388.R02388_appl_area.sSvcChrgCd, NO_CHARGE);

               /**********************************************************************/
               /** call service to write a pass rider record to the pass card table **/
               /**********************************************************************/
               TPM_7320_InsertPassCardTableRider();
               }
            else
            if (nUnRevokedInd == TRUE)
               {
               /**********************************************************************/
               /** Cursor the pass card table for the latest record.  if one exists,**/
               /** get the key information and use service 4478 to update the       **/
               /** pass_sts_ind on this record to 'A'.  If there is no record,      **/
               /** insert a new one with 'A' and 'N'.                               **/
               /** NOTE:  only process the first record (they are brought back in   **/
               /** in descending order)                                             **/
               /**********************************************************************/

               /*** Initialize Service Request and Answer Blocks for Pass Card record cursor **/
               memset(&R04477, LOW_VALUES, sizeof(_R04477));
               memset(&A04477, LOW_VALUES, sizeof(_A04477));

               strcpy(R04477.R04477_appl_area.sPprNbr, DTL_REC.sPprNbr);
               strcpy(R04477.R04477_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);

               TPM_7340_CursorPassCardTable();

               strncpy(sPcPprNbr, "  ",sizeof(sPcPprNbr));
               strncpy(sPcNrevNbr, "  ",sizeof(sPcNrevNbr));
               strncpy(sPcCardIssDt, "  ",sizeof(sPcCardIssDt));

               strcpy(sPcPprNbr, A04477.A04477_appl_area.sPprNbr);
               strcpy(sPcNrevNbr, A04477.A04477_appl_area.sNrevNbr);
               strcpy(sPcCardIssDt, A04477.A04477_appl_area.sCardIssDt);

               /******************************************************************************/
               /** Close the pass card table cursor - only needed to read the first record. **/
               /******************************************************************************/
               R04477.R04477_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
               nSvcRtnCd = BCH_InvokeService(EPBINQ7, &R04477,&A04477,SERVICE_ID_04477,1,sizeof(_R04477_APPL_AREA));

               /*****************************************************************************/
               /** If the record is present, get the card issue date from the answer block,**/
               /** and update the record.  Otherwise, insert a new record.                 **/
               /*****************************************************************************/
               if (nPcRecFound == TRUE)
                  {
                  /** Initialize Service Request Block **/
                  memset(&R04478, LOW_VALUES, sizeof(_R04478));

                  strcpy(R04478.R04478_appl_area.sPprNbr, sPcPprNbr);
                  strcpy(R04478.R04478_appl_area.sNrevNbr, sPcNrevNbr);
                  strcpy(R04478.R04478_appl_area.sCardIssDt, sPcCardIssDt);
                  R04478.R04478_appl_area.cCardStsInd = 'A';

                  /********************************************************************/
                  /** call service to update pass card record                        **/
                  /********************************************************************/
                  TPM_7350_UpdatePassCardRecord();
                  }
               else
                  {
                  /** Initialize Service Request Block **/
                  memset(&R02388, LOW_VALUES, sizeof(_R02388));

                  /********************************************************************/
                  /** Format the request block for the insert to the Pass Card Table **/
                  /********************************************************************/
                  strcpy(R02388.R02388_appl_area.sPprNbr, DTL_REC.sPprNbr);
                  strcpy(R02388.R02388_appl_area.sNrevNbr, R04309.R04309_appl_area.sNrevNbr);

                  strcpy(R02388.R02388_appl_area.sCardIssDt, sCurrentTsDt);
                  R02388.R02388_appl_area.cCardStsInd = 'A';
                  if ((strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0) ||
                      (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) ||
                      (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) ||
                      (strcmp(DTL_REC.sSourceSys, ACA) == 0) ||
                      (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) ||
		      (strcmp(DTL_REC.sEmpCatCd, "IN") == 0))
                      R02388.R02388_appl_area.cCardProcInd = 'P';
                  else
                      R02388.R02388_appl_area.cCardProcInd = 'N';
                  strcpy(R02388.R02388_appl_area.sSvcChrgCd, NO_CHARGE);

                  /**********************************************************************/
                  /** call service to write a pass rider record to the pass card table **/
                  /**********************************************************************/
                  TPM_7320_InsertPassCardTableRider();
                  }
               }
            }

         /*****************************************************************************/
         /** If unrevoked or processed as revoked, write record to Audit Trail table **/
         /** and to the Comments Table.                                              **/
         /*****************************************************************************/
               
         if ((nProcessAsRevoked == TRUE) || (nUnRevokedInd == TRUE))
            {
            /*** Initialize Service Request and Answer Blocks for Audit Trail record **/
            memset(&R02561, LOW_VALUES, sizeof(_R02561));
            memset(&A02561, LOW_VALUES, sizeof(_A02561));
               
            /*** Initialize Service Request and Answer Blocks for Comments Table record **/
            memset(&R02483, LOW_VALUES, sizeof(_R02483));
            memset(&A02483, LOW_VALUES, sizeof(_A02483));

            /***************************************************************/
            /** format service request copybook for Audit Trail record    **/
            /***************************************************************/
            strcpy(R02561.R02561_appl_area.sAudtUserId, HRUPDATE);
            strcpy(R02561.R02561_appl_area.sNrevNbr,A04309.A04309_appl_area.sNrevNbr);
            strcpy(R02561.R02561_appl_area.sPassGrpCd,DTL_REC.sPassGrpCd);
            strcpy(R02561.R02561_appl_area.sAudtChgToNm, DTL_REC.sPassGrpCd);
            strcpy(R02561.R02561_appl_area.sPprNbr, DTL_REC.sPprNbr);
            strncpy(R02561.R02561_appl_area.sPassTypCd, " ", sizeof(R02561.R02561_appl_area.sPassTypCd));

            /***************************************************************/
            /** format service request copybook for Comments Table record **/
            /***************************************************************/
            strcpy(R02483.R02483_appl_area.sPprNbr, DTL_REC.sPprNbr);
            strcpy(R02483.R02483_appl_area.sNrevNbr,A04309.A04309_appl_area.sNrevNbr);
            strcpy(R02483.R02483_appl_area.sPassStsChgDt,sCurrentTsDt);
            strcpy(R02483.R02483_appl_area.sPassDtTmTs,sCurrentTsDt);
            strcpy(R02483.R02483_appl_area.sNrevNm, A04309.A04309_appl_area.sNrevNm);

            /************************************************************************/
            /** FORMAT THE COMMENTS FOR BOTH TABLES.                               **/
            /** To prevent writing the wrong comment in case a Deceased PPR comes  **/
            /** through as a Change record instead of a Delete record, the         **/
            /** program checks for the Deceased PPR here, before checking the      **/
            /** ProcessedAsRevoked flag, which would be set to TRUE in this case.  **/
            /** (Deceased PPRs should come thru with a pass group code of 'XX' and **/
            /** a record ID of 'D'.)                                               **/
            /************************************************************************/
            if ((strcmp(DTL_REC.sStsActCd, DECEASED_A1) == 0) || (strcmp(DTL_REC.sStsActCd, DECEASED_A1_BG) == 0))
               {
               strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased PPR   ");
               strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_EMP_COMMENT);
               strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
               strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);
               }
            else
            if (nProcessAsRevoked == TRUE)
               {
               strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Processed as Revoked     ");
               strcpy(R02483.R02483_appl_area.sNrevCmntTxt, PROCESSED_REVOKED_COMMENT);
               strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
               strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);
               }
            else
               {
               strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Pass Rider Unrevoked     ");
               strcpy(R02483.R02483_appl_area.sNrevCmntTxt, PPR_UNREVOKED_COMMENT);
               strcpy(R02483.R02483_appl_area.sPassStsCd, ACTIVE);
               strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);
               }

            strncpy(R02561.R02561_appl_area.sAudtChgFrNm, A03834.A03834_appl_area.sPassGrpCd,sizeof(R02561.R02561_appl_area.sAudtChgFrNm));

            TPM_7210_WriteAuditTrail();

            TPM_7200_InsertComment();
            }

      strcpy(R04309.R04309_appl_area.sNrevSrcCd,DTL_REC.sSourceSys);
 
      TPM_7040_DetermineImputedTravelInd();

   if ((nIntlStation == TRUE) &&
      ((strcmp(DTL_REC.sSourceSys, "DL") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "TQ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OH") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "XJ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||       
      (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||            
      (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||                  
      (strcmp(DTL_REC.sSourceSys, "S5") == 0) ||
	  (strcmp(DTL_REC.sSourceSys, "MN") == 0) || 
      (strcmp(DTL_REC.sSourceSys, "ML") == 0)) && 
      ((strcmp(A03834.A03834_appl_area.sPprRsdncyStsCd, "EX") != 0)) &&
      ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_DEP_ADULT) == 0))) 
      cImputedInd = 'N';
   
   if ((nIntlStation == TRUE) &&
      ((strcmp(DTL_REC.sSourceSys, "DL") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "TQ") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "OH") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "XJ") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "S5") == 0) ||
	   (strcmp(DTL_REC.sSourceSys, "MN") == 0) || 
       (strcmp(DTL_REC.sSourceSys, "ML") == 0)) &&
      ((strcmp(A03834.A03834_appl_area.sPprRsdncyStsCd, "EX") == 0)) &&
      ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_DEP_ADULT) == 0)))
       cImputedInd = 'Y';
   
   if ((nIntlStation == FALSE) &&
       (cImputedInd == 'N') && 
      ((strcmp(DTL_REC.sSourceSys, "DL") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "TQ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OH") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "XJ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||       
      (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||            
      (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||                  
      (strcmp(DTL_REC.sSourceSys, "S5") == 0) || 
	  (strcmp(DTL_REC.sSourceSys, "MN") == 0) ||		  
      (strcmp(DTL_REC.sSourceSys, "ML") == 0)) && 
      ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_DEP_ADULT) == 0))) 
      cImputedInd = 'Y';

 
    /*** DGS, Delta Academy domestic partners *********/
    /*** L. Scott 06-02-09                    *********/
 
   /*** ASA,Chautauqua,Freedom,Pinnacle,ShuttleAmerica change domestic partners to 'Y' imputed 03/08/2010 ***/
   /*** if (((strcmp(DTL_REC.sSourceSys, "AS") == 0) ||        ASA                                        ***/ 
   /*** (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||             Pinnacle                                   ***/
   /*** (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||             Chautauqua                                 ***/
   /*** (strcmp(DTL_REC.sSourceSys, "S5") == 0) ||             Shuttle                                    ***/
   /*** (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||             Freedom                                    ***/
   /*********************************************************************************************************/
   /**********************************************************************************************/
   /*** BBE 06-11-2014 - Commented out the below statement.  Per Carol Smart, the DP, CD, and  ***/
   /*** SD passenger types for CA and DS should not be set to Ticketed. They should be Imputed ***/
   /***  if (((strcmp(DTL_REC.sSourceSys, "CA") == 0) ||                                       ***/
   /***   (strcmp(DTL_REC.sSourceSys, "DS") == 0)) &&                                          ***/
   /***   ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||                             ***/
   /***   (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||                                ***/
   /***   (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0)))                               ***/
   /***   cImputedInd = 'T';                                                                   ***/
   /**********************************************************************************************/

   /*********************************************************/
   

     if ((A04309.A04309_appl_area.cPassImptInd == 'E') &&
        ((strcmp(A04309.A04309_appl_area.sNrevTypCd, DOMESTIC_PARTNER) == 0) ||
	 (strcmp(A04309.A04309_appl_area.sNrevTypCd, DOM_PART_CHILD) == 0) ||
	 (strcmp(A04309.A04309_appl_area.sNrevTypCd, DOM_PART_STUDENT) == 0)))
          cImputedInd = 'E';

      R04309.R04309_appl_area.cPassImptInd = cImputedInd;


      if (R04309.R04309_appl_area.cPassImptInd == A04309.A04309_appl_area.cPassImptInd)

         cImputedIndChg = 'N';
      else
         cImputedIndChg = 'Y';

     
/***********************************************************************************/
/***   Move activation fee save fields to request block                           **/
/***********************************************************************************/
      R04309.R04309_appl_area.cNrevDyMiInd = A04309.A04309_appl_area.cNrevDyMiInd;
      R04309.R04309_appl_area.cNrevDyMiNxtInd = A04309.A04309_appl_area.cNrevDyMiNxtInd;
      R04309.R04309_appl_area.nPassCardNbr = A04309.A04309_appl_area.nPassCardNbr; 
      R04309.R04309_appl_area.cPrvAtvnFeeCd = cSavePrvAtvnFeeCd;
      strcpy(R04309.R04309_appl_area.sPrvAtvnLupdtLts,  sSavePrvAtvnLupdtLts); 
      R04309.R04309_appl_area.cCurAtvnFeeCd = cSaveCurAtvnFeeCd;
      strcpy(R04309.R04309_appl_area.sCurAtvnLupdtLts, sSaveCurAtvnLupdtLts); 
      R04309.R04309_appl_area.cNxtAtvnFeeCd = cSaveNxtAtvnFeeCd;
      strcpy(R04309.R04309_appl_area.sNxtAtvnLupdtLts, sSaveNxtAtvnLupdtLts); 
      
/***********************************************************************************/
/***   Move gender to request block                                              **/
/***********************************************************************************/

/***  BBE Commenting out the below statement and replacing with the following one ***/
/*** original statement   R04309.R04309_appl_area.cGndrTypCd = A04309.A04309_appl_area.cGndrTypCd;  ***/
/*** new statement  R04309.R04309_appl_area.cGndrTypCd = DTL_REC.cGndr[0]; ***/

      R04309.R04309_appl_area.cGndrTypCd = A04309.A04309_appl_area.cGndrTypCd;      

      }
   else
      {
      /************************************************************************/
      /** INVALID PASS GROUP/PASSENGER TYPE                                  **/
      /** Revoke Nrev Psgr from Cursor -                                     **/
      /** This passenger is no longer eligible for pass benefits.            **/
      /** Revoke privileges, deactivate pass cards, write to the comments    **/
      /** table, audit trail table, and t_deltamatic.                        **/
      /************************************************************************/

      /************************************************************************/
      /** Set this indicator so TPM_4510_UpdateNrevRecordCursor will not be  **/
      /** performed after completing this paragraph.                         **/
      /************************************************************************/
      nChgToIneligible = TRUE;

      if (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) != 0)
         {
         TPM_4532_RvkCursorNrevInvldPgpPsgr();
         }
      }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_4532_RvkCursorNrevInvldPgpPsgr           **
**                                                               **
** Description:     This function formats the nonrev record      **
**                  update from the single nonrev record.        **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_4532_RvkCursorNrevInvldPgpPsgr()
{
   short   nSvcRtnCd;   /* Service return code */
 
 
   /************************************************************************/
   /** Revoke Nrev Psgr from Cursor                                       **/
   /** INVALID PASS GROUP/PASSENGER TYPE                                  **/
   /** This passenger is no longer eligible for pass benefits.            **/
   /** Revoke privileges, deactivate pass cards, write to the             **/
   /** comments table, and audit trail table.                             **/
   /************************************************************************/

   /** initialize service request block and populate to revoke pass rider **/
   /** on Nrev Passenger Table                                            **/
   memset(&R02564, LOW_VALUES, sizeof(_R02564));

   /*** Initialize Service Request and Answer Blocks to Comments Table **/
   memset(&R02483, LOW_VALUES, sizeof(_R02483));
   memset(&A02483, LOW_VALUES, sizeof(_A02483));
 
   /*** Initialize Service Request and Answer Blocks to Audit Trail Table **/
   memset(&R02561, LOW_VALUES, sizeof(_R02561));
   memset(&A02561, LOW_VALUES, sizeof(_A02561));

   strcpy(R02564.R02564_appl_area.sPprNbr, DTL_REC.sPprNbr);
   strcpy(R02564.R02564_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02564.R02564_appl_area.sNrevTypCd, A04309.A04309_appl_area.sNrevTypCd);


   if ((strcmp(DTL_REC.sStsActCd, DECEASED_A1) == 0) || (strcmp(DTL_REC.sStsActCd, DECEASED_A1_BG) == 0))
      {
      strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_EMP_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased Emp   ");
      }
   else
   if (strcmp(DTL_REC.sDesStsActCd, DECEASED_C2) == 0)
      {
      strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_DSG_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased       ");
      }
   else
   if (strcmp(DTL_REC.sDesStsActCd, DEATH_OF_CHILD) == 0)
      {
      strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_DSG_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased       ");
      }
   else
   if (strcmp(DTL_REC.sDesStsActCd, DEATH_OF_SPOUSE) == 0)
      {
      strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_DSG_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased       ");
      }
   else
   if (strcmp(DTL_REC.sDesStsActCd, PASS_TERM) == 0)
      {
      strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_DSG_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased       ");
      }
   else
      {
      strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED);
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, INELIGIBLE_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Ineligible     ");
      }

   R02564.R02564_appl_area.cNrevPassChgInd = 'Y';
   strcpy(R02564.R02564_appl_area.sPassSusExpDt, LOW_DATE);

   nNrevPresent = TRUE;

   /***************************************************************************************/
   /*** This function executes service 2564 to update PassStsCd and PassSusExpDt on the ***/
   /*** Nonrev Passenger Table to REVOKED.                                              ***/
   /***************************************************************************************/

   TPM_6520_ResetPassRiderStatus();

   /***************************************************************************************/
   /*** Now, complete service request block and write to Comments table.                ***/
   /***************************************************************************************/

   /** format service request copybook **/
   strcpy(R02483.R02483_appl_area.sPprNbr, DTL_REC.sPprNbr);
   strcpy(R02483.R02483_appl_area.sNrevNbr,A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02483.R02483_appl_area.sPassStsChgDt,sCurrentTsDt);
   strcpy(R02483.R02483_appl_area.sPassDtTmTs,sCurrentTsDt);
   strcpy(R02483.R02483_appl_area.sNrevNm, A04309.A04309_appl_area.sNrevNm);
   strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);

   TPM_7200_InsertComment();

   /**********************************************************************/
   /** Now, complete service request block and write Audit Trail record **/
   /**********************************************************************/

   /** format service request copybook **/
   strcpy(R02561.R02561_appl_area.sAudtUserId, HRUPDATE);
   strcpy(R02561.R02561_appl_area.sNrevNbr,A04309.A04309_appl_area.sNrevNbr);
   strcpy(R02561.R02561_appl_area.sPassGrpCd,DTL_REC.sPassGrpCd);
   strncpy(R02561.R02561_appl_area.sAudtChgFrNm, A03834.A03834_appl_area.sPassGrpCd,sizeof(R02561.R02561_appl_area.sAudtChgFrNm));
   strcpy(R02561.R02561_appl_area.sAudtChgToNm, DTL_REC.sPassGrpCd);
   strcpy(R02561.R02561_appl_area.sPprNbr, DTL_REC.sPprNbr);
   strncpy(R02561.R02561_appl_area.sPassTypCd, " ", sizeof(R02561.R02561_appl_area.sPassTypCd));

   TPM_7210_WriteAuditTrail();

   /***************************************************************************************/
   /*** Now, deactivate any active pass card records for this passenger only.           ***/
   /***************************************************************************************/

   /** Initialize service request block **/
   memset(&R02567, LOW_VALUES, sizeof(_R02567));

   strcpy(R02567.R02567_appl_area.sPprNbr, DTL_REC.sPprNbr);
   strcpy(R02567.R02567_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   R02567.R02567_appl_area.cCardStsInd = 'D';
   R02567.R02567_appl_area.cCardProcInd = 'P';

   TPM_7330_UpdatePassCardRecord();

   /***************************************************************************************/
   /*** Now, write a record to the deltamatic table for this passenger.                 ***/
   /***************************************************************************************/

   /****** Initialize request and answer blocks *****/ 
   memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA)); 
   memset(&A04325.A04325_appl_area, LOW_VALUES, sizeof(_A04325_APPL_AREA));
 

   strcpy(sPprNbr, DTL_REC.sPprNbr);
   strcpy(sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   R04325.R04325_appl_area.cEmplArRecInd = DELETE_REC;

   TPM_7520_FormatDlmaticRec();
}



/******************************************************************
**                                                               **
** Function Name:   TPM_4535_UpdateNrevSinglePsgr                **
**                                                               **
** Description:     This function formats the nonrev record      **
**                  update from the single nonrev record.        **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
int     TPM_4535_UpdateNrevSinglePsgr()
{
   short   nSvcRtnCd;   /* Service return code */
 
 
   /**********************************************************************************/
   /** updating a single nonrevenue passenger - data comes from Cursor              **/
   /** Only updates the record for the nonrev being processed                       **/
   /**********************************************************************************/

   /*****************************************/
   /** Open Cursor for all Nrev Passengers **/
   /*****************************************/
   TPM_7050_CursorNrevPsgr();

   while ((nSvcRtnCd != ARC_ROW_NOT_FOUND) && (nEndOfPassRiders == FALSE))
      {  
      if (strcmp(A04309.A04309_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr) == 0)
         {
         TPM_4540_FormatUpdateNrevSinglePsgr();
         nProcessAsRevoked = FALSE;

         if (nChgToIneligible == FALSE)
            {
            TPM_4510_UpdateNrevRecordCursor();
            }

         /**************************************************************/
         /** If nonrev type code changed, update the Remaining        **/
         /** Allotment Records for this Pass Rider only.              **/
         /** NOTE:  You cannot reset the allotments for someone who   **/
         /**        is being 'Processed As Revoked' because their     **/
         /**        Pass Group is 'XX', which is not valid on the     **/
         /**        Pass Allotment Table.                             **/
         /**************************************************************/

         if (nProcessAsRevoked == FALSE)
            {
            if ((cNrevTypChgInd == 'Y') || (nUnRevokedInd == TRUE))
               {
               TPM_7475_ReadPassTypeCodes();
               }
            else
            /***********************************************************/
            /** If name, birth date, or card issue date changed, must **/
            /** write a record to the Deltamatic Table.               **/
            /***********************************************************/
            if ((cNameChgInd  == 'Y') || 
                (cBdayChgInd == 'Y') || 
                (nCardIssDtChg == TRUE) || 
                (cImputedIndChg == 'Y'))
               {
               /****** Initialize request and answer blocks *****/ 
               memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA)); 
               memset(&A04325.A04325_appl_area, LOW_VALUES, sizeof(_A04325_APPL_AREA));

               strcpy(sPprNbr, DTL_REC.sPprNbr);
               strcpy(sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
               R04325.R04325_appl_area.cEmplArRecInd = CHANGE_REC;

               TPM_7520_FormatDlmaticRec();
               }
            }
         }

      /*******************************/
      /** get the next database row **/
      /*******************************/
      TPM_7055_NextNrevPsgr();

      } /* end while */
}


/******************************************************************
**                                                               **
** Function Name:   TPM_4540_FormatUpdateNrevSinglePsgr          **
**                                                               **
** Description:     This function formats the nonrev record      **
**                  update from the single nonrev record.        **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
int     TPM_4540_FormatUpdateNrevSinglePsgr()
{
   short   nSvcRtnCd;   /* Service return code */
   cCpInd = 'N';
   cParentChgInd = 'N';
 
 
 /*********************************************************************************/
 /** If the nonrev type is PARENT, check to see if there are already             **/
 /** two parents on the nrev passenger table.  If so, set the nMaxParentInd      **/
 /** to TRUE.                                                                    **/
 /*********************************************************************************/
   if (strcmp(DTL_REC.sPsgrTypeCd, PARENT) == 0)
      {  
      TPM_5510_CheckForParents();

      /*****************************************************************************************/
      /** If the parent used to be revoked, and is now eligible, this process cannot just     **/
      /** change them back to active if there are already two or more active or suspended     **/
      /** parents.  In that case, set cParentChgInd to 'Y', so the process will leave them    **/
      /** the way they were and put them on the error report to be checked by the             **/
      /** Pass Bureau.                                                                        **/
      /*****************************************************************************************/
      if (strcmp(A04309.A04309_appl_area.sPassStsCd, ACTIVE) == 0)
         cParentChgInd = 'N';
      else
      if ((strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) == 0) && (nMaxParentInd == TRUE))
         cParentChgInd = 'Y';
      else
         cParentChgInd = 'N';
      }

/*   if ((strcmp(A04710.A04710_appl_area.sNrevTypCd, COMPANION) == 0) ||
**      (strcmp(A04710.A04710_appl_area.sNrevTypCd, SPOUSE) == 0) || 
**      (strcmp(A04309.A04309_appl_area.sNrevTypCd, COMPANION) == 0) ||
**      (strcmp(A04309.A04309_appl_area.sNrevTypCd, SPOUSE) == 0))
*/
   if ((strcmp(A04309.A04309_appl_area.sNrevTypCd, COMPANION) == 0) ||
      (strcmp(A04309.A04309_appl_area.sNrevTypCd, SPOUSE) == 0) ||
      (strcmp(A04309.A04309_appl_area.sNrevTypCd, DOMESTIC_PARTNER) == 0))
      {  
        TPM_5512_CheckForCompanionOrSpouse();
 
        if ((strcmp(A04309.A04309_appl_area.sPassStsCd, ACTIVE) == 0) ||
           (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) == 0))
        {
          if ( (strcmp(A04309.A04309_appl_area.sNrevTypCd, SPOUSE) == 0) && 
          ((strcmp(A04710.A04710_appl_area.sNrevTypCd, COMPANION) == 0) || 
          (strcmp(A04710.A04710_appl_area.sNrevTypCd, DOMESTIC_PARTNER) == 0)) && 
          (strncmp(UTL_ConvertDate(A04710.A04710_appl_area.sArchLastUpdtTs, CNV_DB_TO_YYYYMMDD),RS.sTodayDt,sizeof(RS.sTodayDt)) == 0) )
          {
            cCpInd = 'Y';
          } else if ((strcmp(A04309.A04309_appl_area.sNrevTypCd, COMPANION) == 0) && 
	      ((strcmp(A04710.A04710_appl_area.sNrevTypCd, SPOUSE) == 0) || 
	      (strcmp(A04710.A04710_appl_area.sNrevTypCd, DOMESTIC_PARTNER) == 0)) && 
              (strncmp(UTL_ConvertDate(A04710.A04710_appl_area.sArchLastUpdtTs, CNV_DB_TO_YYYYMMDD),RS.sTodayDt,sizeof(RS.sTodayDt)) == 0) )
	  {
	    TPM_6515_RevokeSinglePassRider();
            cCpInd = 'N';
          } else {
              if ((nSpouseInd == FALSE) && (nCompanionInd == FALSE) && (nDomPartnerInd == FALSE))
                cCpInd = 'N';
              else
                cCpInd = 'Y';
          }
        } else {
	  cCpInd = 'Y';
	}
      }

   strcpy(R04309.R04309_appl_area.sPprNbr,DTL_REC.sPprNbr);
   strcpy(R04309.R04309_appl_area.sNrevNbr,DTL_REC.sDesNrevNbr);
   strcpy(R04309.R04309_appl_area.sNrevTypCd,DTL_REC.sPsgrTypeCd);
   strcpy(R04309.R04309_appl_area.sNrevBdayDt,UTL_ConvertDate(DTL_REC.sBirthDt, CNV_YYYYMMDD_TO_DB));
 
   /*strcpy(R04309.R04309_appl_area.sNrevNm,DTL_REC.sPsgrNm);*/
  if (nOneInitialLstNm == TRUE)
       {
       strcpy(R04309.R04309_appl_area.sNrevNm, sFullNm);        
       }
     else
       {
       strcpy(R04309.R04309_appl_area.sNrevNm, DTL_REC.sPsgrNm);
       }
   strcpy(R04309.R04309_appl_area.sNrevLstNm,sLstNm);
   strcpy(R04309.R04309_appl_area.sNrevFrstNm,sFrstNm);
   R04309.R04309_appl_area.cNrevMidNm = cMidNm;
   R04309.R04309_appl_area.cGndrTypCd = DTL_REC.cGndr[0];
      
   /************************************************************************************/
   /** SET PASS STATUS                                                                **/
   /** At this point, the pass group/passenger type is valid                          **/
   /************************************************************************************/
   /**                                                                                **/
   /************************************************************************************/
   /** If ppr is revoked, or processing as revoked, this passenger must be REVOKED -  **/
   /** Unless the Pass Bureau has already revoked them (cNrevPassChgInd != 'Y'),      **/
   /** in which case they will not be changed.                                        **/
   /************************************************************************************/
   if (((strcmp(DTL_REC.sDesNrevNbr, "00") != 0) && (nPprRevoked == TRUE)) || (nProcessAsRevoked == TRUE))
      {
      if (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) == 0)
         {
         if (A04309.A04309_appl_area.cNrevPassChgInd != 'Y')
            { /* Pass Bureau did the revoking - do not change */
            strcpy(R04309.R04309_appl_area.sPassStsCd,A04309.A04309_appl_area.sPassStsCd);
            R04309.R04309_appl_area.cNrevPassChgInd = ' ';  
            strcpy(R04309.R04309_appl_area.sPassSusExpDt,A04309.A04309_appl_area.sPassSusExpDt);
            nUnRevokedInd = FALSE;
            }
         else
            { /* this program did the revoking - leave as is */
            strcpy(R04309.R04309_appl_area.sPassStsCd,A04309.A04309_appl_area.sPassStsCd);
            R04309.R04309_appl_area.cNrevPassChgInd = A04309.A04309_appl_area.cNrevPassChgInd;
            strcpy(R04309.R04309_appl_area.sPassSusExpDt,A04309.A04309_appl_area.sPassSusExpDt);
            nUnRevokedInd = FALSE;
            }
         }
      else
         {
         /************************************/
         /* not already revoked - revoke now */
         /************************************/
         strcpy(R04309.R04309_appl_area.sPassStsCd,REVOKED);
         R04309.R04309_appl_area.cNrevPassChgInd = 'Y';
         strcpy(R04309.R04309_appl_area.sPassSusExpDt,LOW_DATE);
         nUnRevokedInd = FALSE;
         }
      }
   else /* processing the ppr, or processing as revoked */
      {
      /**********************************************************************/
      /** If the person was REVOKED, and this program did the revoking     **/
      /** (i.e. cNrevPassChgInd = 'Y'), unrevoke them.                     **/
      /**********************************************************************/
      if (strcmp(A04309.A04309_appl_area.sPassStsCd, REVOKED) == 0)
         {
         if (A04309.A04309_appl_area.cNrevPassChgInd == 'Y')
            {
            if ((cParentChgInd == 'N') && (cCpInd == 'N'))
               {
               strcpy(R04309.R04309_appl_area.sPassStsCd, ACTIVE);
               R04309.R04309_appl_area.cNrevPassChgInd = ' ';
               strcpy(R04309.R04309_appl_area.sPassSusExpDt, LOW_DATE);
               nUnRevokedInd = TRUE;
               }
            else
               { 
               /*****************************************************************/
               /* parent change to active with max parents already active -     */
               /* leave them the way they were and write record to error report */
               /*****************************************************************/
               strcpy(R04309.R04309_appl_area.sPassStsCd,A04309.A04309_appl_area.sPassStsCd);
               R04309.R04309_appl_area.cNrevPassChgInd = A04309.A04309_appl_area.cNrevPassChgInd;
               strcpy(R04309.R04309_appl_area.sPassSusExpDt,A04309.A04309_appl_area.sPassSusExpDt);
               nUnRevokedInd = FALSE;

               /************************************************/
               /** ERROR - Parent Status Change - PB handles. **/
               /** Write input record to ERROR REPORT.        **/
               /************************************************/
               cErrorCode = '2';
               if (strcmp(DTL_REC.sSourceSys, DELTA) == 0)
                  {   
                  TPM_7611_GenerateEPB50011();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)
                  {   
                  TPM_7612_GenerateEPB50012();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)
                  {   
                  TPM_7613_GenerateEPB50013();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)
                  {   
                  TPM_7614_GenerateEPB50014();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, ASA)== 0)
                  {   
                  TPM_7615_GenerateEPB50015();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, COMAIR)== 0)
                  {   
                  TPM_7616_GenerateEPB50016();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0) 
                  {   
                  TPM_7617_GenerateEPB50017();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY)== 0)
                  {   
                  TPM_7618_GenerateEPB50018();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, SKYWEST)== 0)
                  {   
                  TPM_7619_GenerateEPB50019();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, ACA)== 0)
                  {   
                  TPM_7620_GenerateEPB50020();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA)== 0)
                  {   
                  TPM_7621_GenerateEPB50021();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA)== 0)
                  {   
                  TPM_7622_GenerateEPB50022();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, FREEDOM)== 0)
                  {   
                  TPM_7623_GenerateEPB50023();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, BIG_SKY)== 0)
                  {   
                  TPM_7624_GenerateEPB50024();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET)== 0)
                  {   
                  TPM_7625_GenerateEPB50025();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, PINNACLE)== 0)
                  {   
                  TPM_7626_GenerateEPB50026();
                  }   
               else
			   //Manual PPR Added data --PPatnaik
			   if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0) 
			   {
				   TPM_7627_GenerateEPB50027();  
			   }
			   else
               if (strcmp(DTL_REC.sSourceSys, MESABA)== 0)
                  {   
                  TPM_7628_GenerateEPB50028();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, COMPASS)== 0)
                  {   
                  TPM_7629_GenerateEPB50029();
                  }   
               else
               if (strcmp(DTL_REC.sSourceSys, MLT)== 0)
                  {   
                  TPM_7630_GenerateEPB50030();
                  } 
               else
               if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE)== 0)
                  {   
                  TPM_7631_GenerateEPB50031();
                  }  
               else
               if (strcmp(DTL_REC.sSourceSys, GOJET)== 0)
                  {   
                  TPM_7632_GenerateEPB50032();
                  }  
               else
                  {   
                  sprintf(sErrorMessage, "ERROR 2:  Parent Status Change-handle manually ");
                  BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
                  sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, RecType = %s",
                                          DTL_REC.cRecordId,
                                          DTL_REC.sPprNbr,
                                          DTL_REC.sDesNrevNbr,
                                          DTL_REC.sRecType);
                  BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
                  BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_4540_FormatUpdateNrevSinglePsgr");
                  }
               }
            }
         else
            {
            /*********************************************************************/
            /* leave them the way they were - cannot override Pass Bureau revoke */
            /*********************************************************************/
            strcpy(R04309.R04309_appl_area.sPassStsCd,A04309.A04309_appl_area.sPassStsCd);
            R04309.R04309_appl_area.cNrevPassChgInd = ' ';
            strcpy(R04309.R04309_appl_area.sPassSusExpDt,A04309.A04309_appl_area.sPassSusExpDt);
            nUnRevokedInd = FALSE;
            }
         }
      else
         {
         /******************************/
         /* already active - no change */
         /******************************/
         strcpy(R04309.R04309_appl_area.sPassStsCd,A04309.A04309_appl_area.sPassStsCd);
         R04309.R04309_appl_area.cNrevPassChgInd = ' ';  
         strcpy(R04309.R04309_appl_area.sPassSusExpDt,A04309.A04309_appl_area.sPassSusExpDt);
         nUnRevokedInd = FALSE;
         }
      } /** endif - NOT ppr revoked, or processing as revoked **/

   /*************************************************************************************/
   /** When a passenger's birthdate, name, or pass card issue date changes, a record   **/
   /** must be written to the Pass Card Table to request a new Pass Card.              **/
   /** If a passenger is unrevoked, and none of these things changed, the most current **/
   /** record is re-activated, if it exists.  If no record is present, a new one is    **/
   /** written.                                                                        **/
   /** Any records on the pass card table for this ppr/nrev are deactivated before     **/
   /** the new record is written.                                                      **/
   /** Worldspan and Transquest pass cards are always marked Active and Processed      **/
   /** when the passenger is active, as they produce their own pass cards.             **/
   /*************************************************************************************/
   if ((cBdayChgInd == 'Y') || (nCardIssDtChg == TRUE) || (cNameChgInd == 'Y') ||
       (nProcessAsRevoked == TRUE))
      {
      /*****************************************************************************/
      /** First, must deactivate all pass card records on the table for this psgr **/
      /*****************************************************************************/

      /** Initialize Service Request Block **/
      memset(&R02567, LOW_VALUES, sizeof(_R02567));
 
      /** Format the request block for the update the Pass Card Table **/
      strcpy(R02567.R02567_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02567.R02567_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
      R02567.R02567_appl_area.cCardStsInd = 'D';
      R02567.R02567_appl_area.cCardProcInd = 'P';
 
      TPM_7330_UpdatePassCardRecord();

      /*****************************************/
      /** Now, write the new pass card record **/
      /*****************************************/
 
      if (nProcessAsRevoked == FALSE)
         if (strcmp(R04309.R04309_appl_area.sPassStsCd, ACTIVE) == 0)
         {
         /** Initialize Service Request Block **/
         memset(&R02388, LOW_VALUES, sizeof(_R02388));

         /********************************************************************/
         /** Format the request block for the insert to the Pass Card Table **/
         /********************************************************************/
         strcpy(R02388.R02388_appl_area.sPprNbr, DTL_REC.sPprNbr);
         strcpy(R02388.R02388_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
 
         if ((strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0) ||
             (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) ||
             (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) ||
             (strcmp(DTL_REC.sSourceSys, ACA) == 0) ||
             (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) ||
	     (strcmp(DTL_REC.sEmpCatCd, "IN") == 0))
            {
            if((strcmp(DTL_REC.sCardIssDt, ZERO_DATE) == 0) ||
               (strcmp(DTL_REC.sCardIssDt, "") == 0))
               { 
               strcpy(R02388.R02388_appl_area.sCardIssDt, LOW_DATE);
               R02388.R02388_appl_area.cCardStsInd = 'A';
               R02388.R02388_appl_area.cCardProcInd = 'P';
               } 
            else
               { 
               strcpy(R02388.R02388_appl_area.sCardIssDt, UTL_ConvertDate(DTL_REC.sCardIssDt, CNV_YYYYMMDD_TO_DB));
               R02388.R02388_appl_area.cCardStsInd = 'A';
               R02388.R02388_appl_area.cCardProcInd = 'P';
               } 
            }
         else
            {
            strcpy(R02388.R02388_appl_area.sCardIssDt, sCurrentTsDt);
            R02388.R02388_appl_area.cCardStsInd = 'A';
            R02388.R02388_appl_area.cCardProcInd = 'N';
            }

         strcpy(R02388.R02388_appl_area.sSvcChrgCd, NO_CHARGE);
 
         /**********************************************************************/
         /** call service to write a pass rider record to the pass card table **/
         /**********************************************************************/
         TPM_7320_InsertPassCardTableRider();
         }
      }  
   else
   if (nUnRevokedInd == TRUE)
      {
      /**********************************************************************/
      /** Cursor the pass card table for the latest record.  if one exists,**/
      /** get the key information and use service 4478 to update the       **/
      /** pass_sts_ind to 'A'.  If there is no record, insert a new one    **/
      /** with 'A' and 'N'.                                                **/
      /** NOTE:  only the first record is processed (they are brought back **/
      /**        in descending order)                                      **/
      /**********************************************************************/
  
      /*** Initialize Service Request and Answer Blocks for Pass Card record cursor **/
      memset(&R04477, LOW_VALUES, sizeof(_R04477));
      memset(&A04477, LOW_VALUES, sizeof(_A04477));

      strcpy(R04477.R04477_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R04477.R04477_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
  
      TPM_7340_CursorPassCardTable();
  
      strncpy(sPcPprNbr, "  ",sizeof(sPcPprNbr)); 
      strncpy(sPcNrevNbr, "  ",sizeof(sPcNrevNbr)); 
      strncpy(sPcCardIssDt, "  ",sizeof(sPcCardIssDt));

      strcpy(sPcPprNbr, A04477.A04477_appl_area.sPprNbr);
      strcpy(sPcNrevNbr, A04477.A04477_appl_area.sNrevNbr);
      strcpy(sPcCardIssDt, A04477.A04477_appl_area.sCardIssDt);
 
      /******************************************************************************/
      /** Close the pass card table cursor - only needed to read the first record. **/
      /******************************************************************************/
      R04477.R04477_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
      nSvcRtnCd = BCH_InvokeService(EPBINQ7,&R04477,&A04477,SERVICE_ID_04477,1,sizeof(_R04477_APPL_AREA));
 

      /*****************************************************************************/
      /** If the record is present, get the card issue date from the answer block,**/
      /** and update the pass status indicator to 'A' on the selected record.     **/
      /** Otherwise, insert a new record.                                         **/
      /*****************************************************************************/
      if (nPcRecFound == TRUE)
         {
         /*** Initialize Service Request and Answer Blocks for Pass Card record cursor **/
         memset(&R04478, LOW_VALUES, sizeof(_R04478));
         memset(&A04478, LOW_VALUES, sizeof(_A04478));
 
         strcpy(R04478.R04478_appl_area.sPprNbr, sPcPprNbr);
         strcpy(R04478.R04478_appl_area.sNrevNbr, sPcNrevNbr);
         strcpy(R04478.R04478_appl_area.sCardIssDt, sPcCardIssDt);
         R04478.R04478_appl_area.cCardStsInd = 'A';
 
         /********************************************************************/
         /** call service to update pass card record                        **/
         /********************************************************************/
         TPM_7350_UpdatePassCardRecord();
         }
      else
         {
         /** Initialize Service Request Block **/
         memset(&R02388, LOW_VALUES, sizeof(_R02388));
 
         /********************************************************************/
         /** Format the request block for the insert to the Pass Card Table **/
         /********************************************************************/
         strcpy(R02388.R02388_appl_area.sPprNbr, DTL_REC.sPprNbr);
         strcpy(R02388.R02388_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
  
         strcpy(R02388.R02388_appl_area.sCardIssDt, sCurrentTsDt);
         R02388.R02388_appl_area.cCardStsInd = 'A';
         if ((strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0) ||
             (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) ||
             (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) ||
             (strcmp(DTL_REC.sSourceSys, ACA) == 0) ||
             (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) ||
	     (strcmp(DTL_REC.sEmpCatCd, "IN") == 0))
              R02388.R02388_appl_area.cCardProcInd = 'P';
         else
              R02388.R02388_appl_area.cCardProcInd = 'N';
         strcpy(R02388.R02388_appl_area.sSvcChrgCd, NO_CHARGE);
 
         /********************************************************************/
         /** call service to insert new pass card record                    **/
         /********************************************************************/
         TPM_7320_InsertPassCardTableRider();
         }
      }
  
   /******************************************************************************/
   /** Now, write a record to the Audit Trail and Comments table, if necessary  **/
   /******************************************************************************/
  
   if ((nProcessAsRevoked == TRUE) || (nUnRevokedInd == TRUE))
      {
      /*** Initialize Service Request and Answer Blocks **/
      memset(&R02483, LOW_VALUES, sizeof(_R02483));
      memset(&A02483, LOW_VALUES, sizeof(_A02483));
  
      /** format service request copybook **/
      strcpy(R02483.R02483_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02483.R02483_appl_area.sNrevNbr,DTL_REC.sDesNrevNbr);
      strcpy(R02483.R02483_appl_area.sPassStsChgDt,sCurrentTsDt);
      strcpy(R02483.R02483_appl_area.sPassDtTmTs,sCurrentTsDt);
      strcpy(R02483.R02483_appl_area.sNrevNm, DTL_REC.sPsgrNm);
  
      /** Format comment field **/
      if (nProcessAsRevoked == TRUE)
         {
         strcpy(R02483.R02483_appl_area.sNrevCmntTxt, PROCESSED_REVOKED_COMMENT);
         strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
         strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);
         }
      else
         {
         strcpy(R02483.R02483_appl_area.sNrevCmntTxt, PPR_UNREVOKED_COMMENT);
         strcpy(R02483.R02483_appl_area.sPassStsCd, ACTIVE);
         strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);
         }
 
      TPM_7200_InsertComment();
 
      /*** Initialize Service Request and Answer Blocks **/
      memset(&R02561, LOW_VALUES, sizeof(_R02561));
      memset(&A02561, LOW_VALUES, sizeof(_A02561));
 
      /** format service request copybook **/
      if (nProcessAsRevoked == TRUE)
         strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Processed As Revoked     ");
      else
         strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Pass Rider Unrevoked     ");

      strncpy(R02561.R02561_appl_area.sAudtChgFrNm, A03834.A03834_appl_area.sPassGrpCd,sizeof(R02561.R02561_appl_area.sAudtChgFrNm));
      strcpy(R02561.R02561_appl_area.sAudtChgToNm, DTL_REC.sPassGrpCd);
      strcpy(R02561.R02561_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strncpy(R02561.R02561_appl_area.sPassTypCd, " ", sizeof(R02561.R02561_appl_area.sPassTypCd));
      strcpy(R02561.R02561_appl_area.sAudtUserId, HRUPDATE);
      strcpy(R02561.R02561_appl_area.sNrevNbr,A04309.A04309_appl_area.sNrevNbr);
      strcpy(R02561.R02561_appl_area.sPassGrpCd,DTL_REC.sPassGrpCd);


      TPM_7210_WriteAuditTrail();
      }
 
   strcpy(R04309.R04309_appl_area.sNrevSrcCd,DTL_REC.sSourceSys);
 
   R04309.R04309_appl_area.cNrevDyMiInd = A04309.A04309_appl_area.cNrevDyMiInd;
   R04309.R04309_appl_area.cNrevDyMiNxtInd = A04309.A04309_appl_area.cNrevDyMiNxtInd;
   R04309.R04309_appl_area.nPassCardNbr = A04309.A04309_appl_area.nPassCardNbr;
 
   TPM_7040_DetermineImputedTravelInd();
   
   if ((nIntlStation == TRUE) &&
      ((strcmp(DTL_REC.sSourceSys, "DL") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "TQ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OH") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "XJ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||       
      (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||            
      (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||                  
      (strcmp(DTL_REC.sSourceSys, "S5") == 0) || 
	  (strcmp(DTL_REC.sSourceSys, "MN") == 0) ||	
      (strcmp(DTL_REC.sSourceSys, "ML") == 0)) && 
      ((strcmp(A03834.A03834_appl_area.sPprRsdncyStsCd, "EX") != 0)) &&
      ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_DEP_ADULT) == 0))) 
      cImputedInd = 'N';
   
   if ((nIntlStation == TRUE) &&
      ((strcmp(DTL_REC.sSourceSys, "DL") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "TQ") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "OH") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "XJ") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
       (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||       
       (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||            
       (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||                  
       (strcmp(DTL_REC.sSourceSys, "S5") == 0) || 
		(strcmp(DTL_REC.sSourceSys, "MN") == 0) ||
		(strcmp(DTL_REC.sSourceSys, "ML") == 0)) &&
      ((strcmp(A03834.A03834_appl_area.sPprRsdncyStsCd, "EX") == 0)) &&
      ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_DEP_ADULT) == 0)))
       cImputedInd = 'Y';
   
   if ((nIntlStation == FALSE) &&
      ((cImputedInd == 'N')) &&
      ((strcmp(DTL_REC.sSourceSys, "DL") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "TQ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OH") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "XJ") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "G7") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "CP") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "OO") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "AS") == 0) ||
      (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||       
      (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||            
      (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||                  
      (strcmp(DTL_REC.sSourceSys, "S5") == 0) || 
	  (strcmp(DTL_REC.sSourceSys, "MN") == 0) ||
	  (strcmp(DTL_REC.sSourceSys, "ML") == 0)) && 
      ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0) ||
      (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_DEP_ADULT) == 0))) 
      cImputedInd = 'Y';

   /*** DGS, Delta Academy domestic partners *****/ 
   /*** L. Scott 05-21-08                    *****/

   /*** ASA,Chautauqua,Freedom,Pinnacle,Shuttle change domestic partners to imputed 'Y' 03/06/2010 ***/
   /*** if (((strcmp(DTL_REC.sSourceSys, "AS") == 0) ||        ASA                                 ***/    
   /*** (strcmp(DTL_REC.sSourceSys, "9E") == 0) ||             Pinnacle                            ***/      
   /*** (strcmp(DTL_REC.sSourceSys, "RP") == 0) ||             Chautauqua                          ***/         
   /*** (strcmp(DTL_REC.sSourceSys, "S5") == 0) ||             Shuttle                             ***/            
   /*** (strcmp(DTL_REC.sSourceSys, "F8") == 0) ||             Freedom                             ***/
   /**************************************************************************************************/ 
   /**********************************************************************************************/
   /*** BBE 06-11-2014 - Commented out the below statement.  Per Carol Smart, the DP, CD, and  ***/
   /*** SD passenger types for CA and DS should not be set to Ticketed. They should be Imputed ***/
   /***  if (((strcmp(DTL_REC.sSourceSys, "CA") == 0) ||                                       ***/
   /***   (strcmp(DTL_REC.sSourceSys, "DS") == 0)) &&                                          ***/
   /***   ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||                             ***/
   /***   (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||                                ***/
   /***   (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0)))                               ***/
   /***   cImputedInd = 'T';                                                                   ***/
   /**********************************************************************************************/

   /*********************************************************/


   if ((A04309.A04309_appl_area.cPassImptInd == 'E') &&
      ((strcmp(DTL_REC.sPsgrTypeCd, DOMESTIC_PARTNER) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_CHILD) == 0) ||
       (strcmp(DTL_REC.sPsgrTypeCd, DOM_PART_STUDENT) == 0)))
       cImputedInd = 'E';

   R04309.R04309_appl_area.cPassImptInd = cImputedInd;

   if (R04309.R04309_appl_area.cPassImptInd == A04309.A04309_appl_area.cPassImptInd)
      cImputedIndChg = 'N'; 
   else 
      cImputedIndChg = 'Y'; 
 
 /****************   testing old code  ********************/

   R04309.R04309_appl_area.cPrvAtvnFeeCd = A04309.A04309_appl_area.cPrvAtvnFeeCd;
   strcpy(R04309.R04309_appl_area.sPrvAtvnLupdtLts, A04309.A04309_appl_area.sPrvAtvnLupdtLts);
   R04309.R04309_appl_area.cCurAtvnFeeCd = A04309.A04309_appl_area.cCurAtvnFeeCd;
   strcpy(R04309.R04309_appl_area.sCurAtvnLupdtLts, A04309.A04309_appl_area.sCurAtvnLupdtLts);
   R04309.R04309_appl_area.cNxtAtvnFeeCd = A04309.A04309_appl_area.cNxtAtvnFeeCd;
   strcpy(R04309.R04309_appl_area.sNxtAtvnLupdtLts, A04309.A04309_appl_area.sNxtAtvnLupdtLts);

 /***************   testing old code  ************************/
}
 
 
/******************************************************************
**                                                               **
** Function Name:   TPM_5500_ProcessChangeRecord                 **
**                                                               **
** Description:     Process detail change record.                **
**                  Determine the type of change.                **
**                  Then evaluate the type of the input record,  **
**                  and process accordingly.                     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int  TPM_5500_ProcessChangeRecord()
{
   short   nSvcRtnCd;   /* Service return code */


   /**************************************************************************/
   /** For a change record to be processed, the PPR record must be present. **/
   /** If not, write the record to the error file.                          **/
   /**************************************************************************/

   if (nPPRPresent == TRUE)
      {
      TPM_5505_DetermineTypeOfChange();

      if(strcmp(DTL_REC.sRecType, A1_REC) == 0)
         {
         TPM_5520_ProcessA1Change();
         }
      else
      if(strcmp(DTL_REC.sRecType, C2_REC) == 0)
	 {
   /*************************************************************************/
   /** L.Scott (08/02/00) - Removed code that checked for "AS" source code **/
   /**                      and "CP" & "ND" passenger tyes, since ASA      **/
   /**                      employees can now have CP's and ND's.          **/
   /*************************************************************************/

            if (nNrevPresent == TRUE)
              {
              TPM_5530_ProcessC2Change();
              }
            else
              {
              TPM_4230_ProcessC2Add();
              }
            }		
         }
   else
      {
      /*************************************************************************/
      /** If PPR is not present, process as an add.                           **/
      /** Any C2 records without a corresponding PPR were errored out in      **/
      /** TPM_4000PProcessFileRecords.                                        **/ 
      /*************************************************************************/
      TPM_4220_ProcessA1Add();
      }

}




/******************************************************************
**                                                               **
** Function Name:   TPM_5505_DetermineTypeOfChange               **
**                                                               **
** Description:     Determine the type of change.                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_5505_DetermineTypeOfChange()
{
   short   nSvcRtnCd;        /* Service return code */


   /***************************************************************************************/
   /** For TQ and WS, check to see if the card issue date field is populated.  If it is, **/
   /** it is checked to see if there has been a change.                                  **/
   /** For all source systems, other changes looked for are:                             **/
   /**   A1 Record:  Pass Group, Start Date, Name, Intertax Number, Birth Date           **/
   /**   C2 Record:  Name, Birth Date, Nonrev Type.                                      **/
   /**                                                                                   **/
   /** 2/3/98 DEV MAKIM: Card Issue Date field should be chaecked only for worldspan     **/
   /** records. TQ (Delta Technology) records should be processed same as Delta records. **/
   /***************************************************************************************/
   if ((strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0) ||
       (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) ||
       (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) ||
       (strcmp(DTL_REC.sSourceSys, ACA) == 0) ||
       (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) ||
       (strcmp(DTL_REC.sEmpCatCd, "IN") == 0))
      if ((strcmp(DTL_REC.sCardIssDt, ZERO_DATE) != 0) && 
          (strcmp(DTL_REC.sCardIssDt, "") != 0))
         {
         TPM_5515_GetCardIssDt();

         if(nDateFound == TRUE)
            if (strcmp(DTL_REC.sCardIssDt, UTL_ConvertDate(A02769.A02769_appl_area.sCardIssDt, CNV_DB_TO_YYYYMMDD)) != 0)
               nCardIssDtChg = TRUE;
            else
               nCardIssDtChg = FALSE;
         else
            nCardIssDtChg = TRUE;
         }

   if (strcmp(DTL_REC.sRecType, A1_REC) == 0)
      {
      if(memcmp(A03834.A03834_appl_area.sPprNm,DTL_REC.sPsgrNm,strlen(DTL_REC.sPsgrNm)) != 0)
         cNameChgInd = 'Y';

      if(strcmp(A03834.A03834_appl_area.sPassGrpCd,DTL_REC.sPassGrpCd) != 0)
         cPGpChgInd = 'Y';

      if(strcmp(UTL_ConvertDate(A03834.A03834_appl_area.sPprStrtDt, CNV_DB_TO_YYYYMMDD), DTL_REC.sStrtDt) != 0)
         cHireDtChgInd = 'Y';

      if((strcmp(A03834.A03834_appl_area.sPprInttxNbr,DTL_REC.sInttaxNbr) != 0) && (strcmp(DTL_REC.sSourceSys, WORLDSPAN) != 0)) 
         if(strcmp(A03834.A03834_appl_area.sPprInttxNbr, " ") == 0)
            {
            if(strcmp(DTL_REC.sInttaxNbr," ") != 0)
               cInttxChgInd = 'Y';
            }
         else
            cInttxChgInd = 'Y';
      }

   if (strcmp(DTL_REC.sRecType, C2_REC) == 0)
      if(memcmp(A04036.A04036_appl_area.sNrevNm,DTL_REC.sPsgrNm,strlen(DTL_REC.sPsgrNm)) != 0)
         cNameChgInd = 'Y';

   if(strcmp(UTL_ConvertDate(A04036.A04036_appl_area.sNrevBdayDt, CNV_DB_TO_YYYYMMDD), DTL_REC.sBirthDt) != 0)
      cBdayChgInd = 'Y';

   if(strcmp(A04036.A04036_appl_area.sNrevTypCd,DTL_REC.sPsgrTypeCd) != 0)
      cNrevTypChgInd = 'Y';

}

/******************************************************************
**                                                               **
** Function Name:   TPM_5510_CheckForParents                     **
**                                                               **
** Description:     Check to see if there are already two        **
**                  parents in the nrev passenger file.          **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
int     TPM_5510_CheckForParents()
{
   short   nSvcRtnCd;        /* Service return code */
 

   /***************************************************/
   /**  Check for Active or Suspended parents.       **/
   /***************************************************/

   /*** Initialize Service Request and Answer Blocks **/
   memset(&R03341, LOW_VALUES, sizeof(_R03341));
   memset(&A03341, LOW_VALUES, sizeof(_A03341));
      
   strcpy(R03341.R03341_appl_area.sPprNbr, DTL_REC.sPprNbr);
   strcpy(R03341.R03341_appl_area.sNrevTypCd, PARENT);
   strcpy(R03341.R03341_appl_area.sPassStsCd, ACTIVE);
   strcpy(R03341.R03341_appl_area.sPassSts2Cd, SUSPENDED);
   strcpy(R03341.R03341_appl_area.sPassSts3Cd, EMP_REVOKED);

   /**********************************************************************/
   /** Call service to count the number of active and suspended parents **/
   /** on the nonrev psgr table for this PPR                            **/
   /**********************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R03341,&A03341,SERVICE_ID_03341,1,sizeof(_R03341_APPL_AREA));

   /** Service Return Code Processing **/

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         if (A03341.A03341_appl_area.nFltFeeMaxNbr >= 4)
            {  
            nMaxParentInd = TRUE;
            }
         break;
 
      case ARC_ROW_NOT_FOUND:
         break;
 
       default:
          BCH_FormatMessage(1,TXT_SVC_UNSUCC);
          BCH_FormatMessage(2,TXT_SVC,"FYS03341");
          BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
          BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5510_CheckForParents");
          break;
       }

}

/******************************************************************
**                                                               **
** Function Name:   TPM_5512_CheckForCompanionOrSpouse           **
**                                                               **
** Description:     Check to see if there is an (active or       **
**                  suspended) companion or spouse.              **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
int     TPM_5512_CheckForCompanionOrSpouse()
{
   short   nSvcRtnCd;        /* Service return code */
 

   /*** Initialize Service Request and Answer Blocks **/
   memset(&R04710, LOW_VALUES, sizeof(_R04710));
   memset(&A04710, LOW_VALUES, sizeof(_A04710));
      
   strcpy(R04710.R04710_appl_area.sPprNbr, DTL_REC.sPprNbr);

   /**********************************************************************/
   /** Call service to check for a companion or spouse that is          **/
   /** currently active or suspended.                                   **/
   /**********************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04710,&A04710,SERVICE_ID_04710,1,sizeof(_R04710_APPL_AREA));

   /** Service Return Code Processing **/

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
          nNrevPresent = TRUE;

          if (strcmp(A04710.A04710_appl_area.sNrevTypCd, COMPANION) == 0)   
          {
            nCompanionInd = TRUE;
          }
          if (strcmp(A04710.A04710_appl_area.sNrevTypCd, SPOUSE) == 0)
          {
            nSpouseInd = TRUE; 
          }
          if (strcmp(A04710.A04710_appl_area.sNrevTypCd, DOMESTIC_PARTNER) == 0)
          {
            nDomPartnerInd = TRUE; 
          }
         break;
 
      case ARC_ROW_NOT_FOUND:
         break;
 
       default:
          BCH_FormatMessage(1,TXT_SVC_UNSUCC);
          BCH_FormatMessage(2,TXT_SVC,"FYS04710");
          BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
          BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5512_CheckForCompanionOrSpouse");
          break;
       }
}

/******************************************************************
**                                                               **
** Function Name:   TPM_5515_GetCardIssDt                        **
**                                                               **
** Description:     Check to see if there has been a change      **
**                  in the pass card issue date for WS and TQ    **
**                  personnel.                                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
int     TPM_5515_GetCardIssDt()
{
   short   nSvcRtnCd;        /* Service return code */

 
   /*** Initialize Service Request and Answer Blocks **/
   memset(&R02769, LOW_VALUES, sizeof(_R02769));
   memset(&A02769, LOW_VALUES, sizeof(_A02769));
      
   strcpy(R02769.R02769_appl_area.sPprNbr, DTL_REC.sPprNbr);
   strcpy(R02769.R02769_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
 
   nSvcRtnCd = BCH_InvokeService(EPBUPD6,&R02769,&A02769,SERVICE_ID_02769,1,sizeof(_R02769_APPL_AREA));
 
   /** Service Return Code Processing **/
   switch (nSvcRtnCd)
      {   
      case ARC_SUCCESS:
         nDateFound = TRUE;
         break;

      case ARC_ROW_NOT_FOUND:
         nDateFound = FALSE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02769");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5515_GetCardIssDt");
         break;
      }   

}



/******************************************************************
**                                                               **
** Function Name:   TPM_5520_ProcessA1Change                     **
**                                                               **
** Description:     Process change record for A1.                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void   TPM_5520_ProcessA1Change()
{
   short   nSvcRtnCd;   /* Service return code */
 

   TPM_4310_ProcessPprUpdate();
         
   /********************************************************************/
   /** At this point, the select has been done to get the original    **/
   /** PPR record, and the PPR record has been updated.               **/
   /** It has been determined whether or not the nonrev record is     **/
   /** on the Nrev table, and the pass group/passenger type is valid. **/
   /********************************************************************/

   if ((cInttxChgInd == 'Y') || (cPGpChgInd == 'Y') || (cHireDtChgInd == 'Y'))
      {
      nUpdateAll = TRUE;
      TPM_4520_UpdateAllNrevRecs();
      }
   else 
      {
      TPM_4535_UpdateNrevSinglePsgr();
      }

}

/*** LAS 12-07-2009 ********/

/******************************************************************
**                                                               **
** Function Name:   TPM_5525_DisableNrap                         **
**                                                               **
** Description:     Update NRAP eligibility indicator to 'N'.    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 void TPM_5525_DisableNrap()
 {
         short   nSvcRtnCd;   /* Service return code */

	 memset(&R04730.R04730_appl_area, LOW_VALUES, sizeof(_R04730_APPL_AREA));
	 memset(&R04730, LOW_VALUES, sizeof(_R04730));
	 memset(&A04730, LOW_VALUES, sizeof(_A04730));
	 strcpy(R04730.R04730_appl_area.sPprNbr, DTL_REC.sPprNbr);

         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04730,&A04730,SERVICE_ID_04730,1,sizeof(R04730.R04730_appl_area));
         switch (nSvcRtnCd)
	 {
	 case ARC_SUCCESS:
	     cServId = '1';
	     break;

	 case ARC_ROW_NOT_FOUND:
	     break;

         default:
	     BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	     BCH_FormatMessage(2,TXT_SVC, "FYS04730");
	     sprintf(sErrorMessage, "Ppr = %s", R04730.R04730_appl_area.sPprNbr);
	     BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	     BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5525_DisableNrap");
	     break;
	 }

     /**** Delete nrap_bkg record, which triggers the record to be written to nrap_bkg_hst  ****/
   
   if (cServId == '1')
      {
	 memset(&R04731.R04731_appl_area, LOW_VALUES, sizeof(_R04731_APPL_AREA));
	 memset(&R04731, LOW_VALUES, sizeof(_R04731));
	 memset(&A04731, LOW_VALUES, sizeof(_A04731));
	 strcpy(R04731.R04731_appl_area.sPprNbr, DTL_REC.sPprNbr);

         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04731,&A04731,SERVICE_ID_04731,1,sizeof(R04731.R04731_appl_area));
         switch (nSvcRtnCd)
	 {
	 case ARC_SUCCESS:
	     break;

	 case ARC_ROW_NOT_FOUND:
	     break;

         default:
	     BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	     BCH_FormatMessage(2,TXT_SVC, "FYS04731");
	     sprintf(sErrorMessage, "Ppr = %s", R04731.R04731_appl_area.sPprNbr);
	     BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	     BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5525_DisableNrap");
	     break;
	 }
      }
 }
 
/*** LAS 12-07-2009 - above ********/

/******************************************************************
**                                                               **
** Function Name:   TPM_5530_ProcessC2Change                     **
**                                                               **
** Description:     Process change record for C2.                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void   TPM_5530_ProcessC2Change()
{
   short   nSvcRtnCd;   /* Service return code */
 

   TPM_4535_UpdateNrevSinglePsgr();

}    



/******************************************************************
**                                                               **
** Function Name:   TPM_6500_ProcessDeleteRecord                 **
**                                                               **
** Description:     Process detail record to Revoke pass         **
**                  privileges.  If the input record is an 'A1'  **
**                  record, revoke for ALL pass riders associated**
**                  with the PPR.                                **
**                  If the input record is a 'C2' record,        **
**                  revoke for the input pass rider only.        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int    TPM_6500_ProcessDeleteRecord()
{
   short   nSvcRtnCd;   /* Service return code */


 /*********************************************************************/
 /** For ALL employees:  (changed from Delta to ALL 7/9/96 - ghm)    **/
 /** For input A1 records, this function revokes pass privileges for **/
 /** ALL pass riders associated with the PPR.                        **/
 /** For input C2 records, this function revokes pass privileges for **/
 /** the pass rider only.                                            **/
 /** for non-Delta employees, revokes each passenger individually    **/
 /**                                                                 **/
 /** Shridev Makim: (7/24/98)                                        **/
 /** For input A1 records, blacklist all of the F&F and A&B          **/
 /** certificates for the PPR.                                       **/
 /*********************************************************************/
 
   if(strcmp(DTL_REC.sRecType, A1_REC) == 0)
      {
      if (nPPRPresent == TRUE)
         {
         TPM_6510_RevokeAllPassRiders();

         TPM_7535_BlklstCertRecord();

	 /**** LAS 12-07-2009  *********/

         /***********************************************************/
         /** 12/08/2010 BBE    Added code for new "CV"             **/
         /**                   CONN_CARR_NOZED pass group.         **/
         /***********************************************************/

         if ((strcmp(DTL_REC.sPassGrpCd, FURL_EMPL) == 0) ||  
             (strcmp(DTL_REC.sPassGrpCd, VOL_SEV_DL_RECOVERY) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, FURL_PILOT) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, FURL_MERIT) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, TRAVEL_OP_SEV) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, RETIRED_EARLY_SIX) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, RETIRED_LIMIT_DELTA) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, RETIRED_DELTA) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, RETIRED_ASSOCIATE) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, CONN_DELTA_RETIREE) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, CONN_CARR_RETIREE) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, CONN_CARR_NOZED) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, VOL_LEAVE_SDW_WK) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, VOL_LEAVE_SDW) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, VOL_LEAVE_MRD) == 0) ||
             (strcmp(DTL_REC.sPassGrpCd, INELIG_PASS_GRP) == 0))
              {
              TPM_5525_DisableNrap();
              }
	 /**** LAS 12-07-2009 - above *********/

         }
      else
         {
         /** PPR not present on A1 Delete **/
         cErrorCode = '7';  
         if (strcmp(DTL_REC.sSourceSys, DELTA) == 0) 
            {
            TPM_7611_GenerateEPB50011();  
            }
         else 
         if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)  
            {
            TPM_7612_GenerateEPB50012();  
            }
         else  
         if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)   
            {
            TPM_7613_GenerateEPB50013();  
            }
         else  
         if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)   
            {
            TPM_7614_GenerateEPB50014();  
            }
         else 
         if (strcmp(DTL_REC.sSourceSys, ASA) == 0) 
            {
            TPM_7615_GenerateEPB50015();  
            }
         else 
         if (strcmp(DTL_REC.sSourceSys, COMAIR) == 0) 
            {
            TPM_7616_GenerateEPB50016();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0) 
            {
            TPM_7617_GenerateEPB50017();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY) == 0) 
            {
            TPM_7618_GenerateEPB50018();
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) 
            {
            TPM_7619_GenerateEPB50019();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, ACA) == 0) 
            {
            TPM_7620_GenerateEPB50020();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) 
            {
            TPM_7621_GenerateEPB50021();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) 
            {
            TPM_7622_GenerateEPB50022();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, FREEDOM) == 0) 
            {
            TPM_7623_GenerateEPB50023();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, BIG_SKY) == 0) 
            {
            TPM_7624_GenerateEPB50024();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET) == 0) 
            {
            TPM_7625_GenerateEPB50025();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, PINNACLE) == 0) 
            {
            TPM_7626_GenerateEPB50026();  
            }
         else
	 /*****************
         if (strcmp(DTL_REC.sSourceSys, NORTHWEST) == 0) 
            {
            TPM_7627_GenerateEPB50027();  
            }
         else
	 *****************************/
		 //Manual PPR Added data --PPatnaik
		 if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0) 
		 {
			 TPM_7627_GenerateEPB50027();  
		 }
		 else
         if (strcmp(DTL_REC.sSourceSys, MESABA) == 0) 
            {
            TPM_7628_GenerateEPB50028();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMPASS) == 0) 
            {
            TPM_7629_GenerateEPB50029();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, MLT) == 0) 
            {
            TPM_7630_GenerateEPB50030();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE) == 0) 
            {
            TPM_7631_GenerateEPB50031();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, GOJET) == 0) 
            {
            TPM_7632_GenerateEPB50032();  
            }
         else
            {
            sprintf(sErrorMessage, "ERROR 7:  PPR Not Present on A1 Delete");
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
            sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s",
                                    DTL_REC.cRecordId,
                                    DTL_REC.sPprNbr,
                                    DTL_REC.sDesNrevNbr);
            BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_6500_ProcessDeleteRecord");   
            }


         }
      }
   else
   if(strcmp(DTL_REC.sRecType, C2_REC) == 0)
      {
      if (nNrevPresent == TRUE)
         {
         TPM_6515_RevokeSinglePassRider();
         }
      else
         {
         cErrorCode = '8';  
         if (strcmp(DTL_REC.sSourceSys, DELTA) == 0) 
            {
            TPM_7611_GenerateEPB50011();  
            }
         else 
         if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)  
            {
            TPM_7612_GenerateEPB50012();  
            }
         else  
         if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)   
            {
            TPM_7613_GenerateEPB50013();  
            }
         else  
         if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)   
            {
            TPM_7614_GenerateEPB50014();  
            }
         else 
         if (strcmp(DTL_REC.sSourceSys, ASA) == 0) 
            {
            TPM_7615_GenerateEPB50015();  
            }
         else 
         if (strcmp(DTL_REC.sSourceSys, COMAIR) == 0) 
            {
            TPM_7616_GenerateEPB50016();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0) 
            {
            TPM_7617_GenerateEPB50017();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY) == 0) 
            {
            TPM_7618_GenerateEPB50018();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) 
            {
            TPM_7619_GenerateEPB50019();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, ACA) == 0) 
            {
            TPM_7620_GenerateEPB50020();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) 
            {
            TPM_7621_GenerateEPB50021();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) 
            {
            TPM_7622_GenerateEPB50022();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, FREEDOM) == 0) 
            {
            TPM_7623_GenerateEPB50023();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, BIG_SKY) == 0) 
            {
            TPM_7624_GenerateEPB50024();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET) == 0) 
            {
            TPM_7625_GenerateEPB50025();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, PINNACLE) == 0) 
            {
            TPM_7626_GenerateEPB50026();  
            }
         else
	 /*****************
         if (strcmp(DTL_REC.sSourceSys, NORTHWEST) == 0) 
            {
            TPM_7627_GenerateEPB50027();  
            }
         else
	 ******************/
		 //Manual PPR Added data --PPatnaik
		 if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0) 
		 {
			 TPM_7627_GenerateEPB50027();  
		 }
		 else
         if (strcmp(DTL_REC.sSourceSys, MESABA) == 0) 
            {
            TPM_7628_GenerateEPB50028();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMPASS) == 0) 
            {
            TPM_7629_GenerateEPB50029();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, MLT) == 0) 
            {
            TPM_7630_GenerateEPB50030();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE) == 0) 
            {
            TPM_7631_GenerateEPB50031();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, GOJET) == 0) 
            {
            TPM_7632_GenerateEPB50032();  
            }
         else
            {
            sprintf(sErrorMessage, "ERROR 8:  NrevPsgr not found      ");
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
            sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s",
                                    DTL_REC.cRecordId,
                                    DTL_REC.sPprNbr,
                                    DTL_REC.sDesNrevNbr);
            BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_6500_ProcessDeleteRecord");   
            }
         } 
      } 
}



/******************************************************************
**                                                               **
** Function Name:   TPM_6510_RevokeAllPassRiders                 **
**                                                               **
** Description:     1. Revoke all pass riders for the ppr.       **
**                  2. Deactivate all pass cards.                **
**                  3. Write a comment for each passenger.       **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int    TPM_6510_RevokeAllPassRiders()
{
   short   nSvcRtnCd;   /* Service return code */
   nEndOfPassRiders = FALSE;


   /***************************************************************************/
   /** Open Cursor for ALL nonrev passengers for this PPR to:                **/ 
   /** 1. revoke each pass rider,                                            **/ 
   /** 2. deactivate all pass cards for each pass rider, and                 **/
   /** 3. write a comments record for each pass rider.                       **/
   /***************************************************************************/
  
   TPM_7050_CursorNrevPsgr();

   while ((nSvcRtnCd != ARC_ROW_NOT_FOUND) && (nEndOfPassRiders == FALSE))
      {
    if (strcmp(A04309.A04309_appl_area.sPassStsCd, ACTIVE) == 0)
      {
      /*************************************************************************************/
      /** This function executes service 2564 to update PassStsCd, PassSusExpDt, and      **/
      /** on the Nonrev Passenger Table for each passenger for this PPR.                  **/
      /*************************************************************************************/

      /** initialize service request block and populate to revoke pass rider **/
      memset(&R02564, LOW_VALUES, sizeof(_R02564));

      strcpy(R02564.R02564_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02564.R02564_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
      strcpy(R02564.R02564_appl_area.sNrevTypCd, A04309.A04309_appl_area.sNrevTypCd);

      if ((strcmp(DTL_REC.sStsActCd, DECEASED_A1) == 00) || (strcmp(DTL_REC.sStsActCd, DECEASED_A1_BG) == 00))
         strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      else
         strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED);

      R02564.R02564_appl_area.cNrevPassChgInd = 'Y';
      strcpy(R02564.R02564_appl_area.sPassSusExpDt, LOW_DATE);

      TPM_6520_ResetPassRiderStatus();


      /****************************************************************/
      /** Deactivate all active pass card records for each pass      **/
      /** rider associated with this PPR.                            **/
      /****************************************************************/

      /** Initialize Service Request Block **/
      memset(&R02567, LOW_VALUES, sizeof(_R02567));
 
      /** Format the request block for the update to the Pass Card Table **/
      strcpy(R02567.R02567_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02567.R02567_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
      R02567.R02567_appl_area.cCardStsInd = 'D';
      R02567.R02567_appl_area.cCardProcInd = 'P';
 
      TPM_7330_UpdatePassCardRecord();
 

      /*******************************************************************************/
      /** Format comment field and write to the comments table for this pass rider  **/
      /*******************************************************************************/

      /** initialize service request block for Comments Table **/
      memset(&R02483, LOW_VALUES, sizeof(_R02483));

      /*** Initialize Service Request and Answer Blocks for Audit Trail Table **/
      memset(&R02561, LOW_VALUES, sizeof(_R02561));
      memset(&A02561, LOW_VALUES, sizeof(_A02561));

      /** format service request copybook **/
      strcpy(R02483.R02483_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02483.R02483_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
      strcpy(R02483.R02483_appl_area.sPassStsChgDt,sCurrentTsDt);
      strcpy(R02483.R02483_appl_area.sPassDtTmTs,sCurrentTsDt);
      strcpy(R02483.R02483_appl_area.sNrevNm, A04309.A04309_appl_area.sNrevNm);
      strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);

      if ((strcmp(DTL_REC.sStsActCd, DECEASED_A1) == 0) || (strcmp(DTL_REC.sStsActCd, DECEASED_A1_BG) == 0))
         {
         strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_EMP_COMMENT);
         strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
         strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased Emp   ");
         }
      else
         {
         strcpy(R02483.R02483_appl_area.sNrevCmntTxt, TRM_COMMENT);
         strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
         strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Emp Terminated ");
         }

      TPM_7200_InsertComment();

      /***************************************************/
      /** Now, write a record to the Audit Trail table  **/
      /***************************************************/
 
      /** format service request copybook **/
      strcpy(R02561.R02561_appl_area.sAudtUserId, HRUPDATE);
      strcpy(R02561.R02561_appl_area.sNrevNbr,A04309.A04309_appl_area.sNrevNbr);
      strcpy(R02561.R02561_appl_area.sPassGrpCd,DTL_REC.sPassGrpCd);
      strncpy(R02561.R02561_appl_area.sAudtChgFrNm, A03834.A03834_appl_area.sPassGrpCd,sizeof(R02561.R02561_appl_area.sAudtChgFrNm));
      strcpy(R02561.R02561_appl_area.sAudtChgToNm, DTL_REC.sPassGrpCd);
      strcpy(R02561.R02561_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strncpy(R02561.R02561_appl_area.sPassTypCd, " ", sizeof(R02561.R02561_appl_area.sPassTypCd));

      TPM_7210_WriteAuditTrail();

      /**************************************************************************************/
      /** Now, cursor the remaining allotment table and write a record to the deltamatic   **/
      /** table for each pass type for this passenger.                                     **/
      /**************************************************************************************/

      /****** Initialize request and answer blocks *****/ 
      memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA)); 
      memset(&A04325.A04325_appl_area, LOW_VALUES, sizeof(_A04325_APPL_AREA));

      strcpy(sPprNbr, DTL_REC.sPprNbr);
      strcpy(sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
      R04325.R04325_appl_area.cEmplArRecInd = DELETE_REC;
 
      TPM_7520_FormatDlmaticRec(); 

      }
  TPM_7055_NextNrevPsgr();
  }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_6515_RevokeSinglePassRider               **
**                                                               **
** Description:     1. Revoke a single pass rider.               **
**                  2. Deactivate pass card records.             **
**                  3. Write Comment.                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
int     TPM_6515_RevokeSinglePassRider()
{
   short   nSvcRtnCd;   /* Service return code */
   nEndOfPassRiders = FALSE;
 
 
   /***********************************************************************/
   /** 1. Update the status field on the nonrev passenger record to      **/
   /**    'REVOKED', and set the PassSusExpDt to the default date.       **/
   /**    Also update the NrevTypCd, since it may have changed.          **/
   /***********************************************************************/

   /** initialize service request block **/
   memset(&R02564, LOW_VALUES, sizeof(_R02564));   

   /** format service request copybook **/
   strcpy(R02564.R02564_appl_area.sPprNbr, DTL_REC.sPprNbr);

   if ((nSpouseInd == TRUE) || (nCompanionInd == TRUE) || (nDomPartnerInd == TRUE))
      {
      strcpy(R02564.R02564_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02564.R02564_appl_area.sNrevNbr,A04710.A04710_appl_area.sNrevNbr);
      strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED);
      strcpy(R02564.R02564_appl_area.sNrevTypCd,A04710.A04710_appl_area.sNrevTypCd);
      }
   else 
      { 
      strcpy(R02564.R02564_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
      strcpy(R02564.R02564_appl_area.sNrevTypCd, DTL_REC.sPsgrTypeCd);

      if ((strcmp(DTL_REC.sStsActCd, DECEASED_A1) == 0) || (strcmp(DTL_REC.sStsActCd, DECEASED_A1_BG) == 0))
         strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      else
      if (strcmp(DTL_REC.sDesStsActCd, DECEASED_C2) == 0)
         strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      else
      if (strcmp(DTL_REC.sDesStsActCd, DEATH_OF_CHILD) == 0)
         strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      else
      if (strcmp(DTL_REC.sDesStsActCd, DEATH_OF_SPOUSE) == 0)
         strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      else
      if (strcmp(DTL_REC.sDesStsActCd, PASS_TERM) == 0)
         strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED_DEATH);
      else
         strcpy(R02564.R02564_appl_area.sPassStsCd, REVOKED);
      }

     

   R02564.R02564_appl_area.cNrevPassChgInd = 'Y';
   strcpy(R02564.R02564_appl_area.sPassSusExpDt, LOW_DATE);

   TPM_6520_ResetPassRiderStatus();
 
 
   /***********************************************************************/
   /**  2. Now, deactivate any active pass card records for a single     **/
   /**     pass rider.                                                   **/
   /***********************************************************************/
 
   /** Initialize service request block **/
   memset(&R02567, LOW_VALUES, sizeof(_R02567));
 
   if ((nSpouseInd == TRUE) || (nCompanionInd == TRUE) || (nDomPartnerInd == TRUE))
      {
      strcpy(R02567.R02567_appl_area.sPprNbr, A04710.A04710_appl_area.sPprNbr);
      strcpy(R02567.R02567_appl_area.sNrevNbr, A04710.A04710_appl_area.sNrevNbr);
      }
   else
      {
      strcpy(R02567.R02567_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02567.R02567_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
      }
   R02567.R02567_appl_area.cCardStsInd = 'D';
   R02567.R02567_appl_area.cCardProcInd = 'P';

   TPM_7330_UpdatePassCardRecord();

   /****************************************************************/
   /** 3. Get ready to write a record to the Audit Trail table  **/
   /****************************************************************/
 
   /*** Initialize Service Request and Answer Blocks **/
   memset(&R02561, LOW_VALUES, sizeof(_R02561));
   memset(&A02561, LOW_VALUES, sizeof(_A02561));
 
   /** format service request copybook **/
   strncpy(R02561.R02561_appl_area.sAudtChgFrNm, A03834.A03834_appl_area.sPassGrpCd,sizeof(R02561.R02561_appl_area.sAudtChgFrNm));
   strncpy(R02561.R02561_appl_area.sPassTypCd, " ", sizeof(R02561.R02561_appl_area.sPassTypCd));
   strcpy(R02561.R02561_appl_area.sAudtUserId, HRUPDATE);

   if ((nSpouseInd == TRUE) || (nCompanionInd == TRUE) || (nDomPartnerInd == TRUE))
      {
      strcpy(R02561.R02561_appl_area.sNrevNbr, A04710.A04710_appl_area.sNrevNbr);
      strcpy(R02561.R02561_appl_area.sPassGrpCd, DTL_REC.sPassGrpCd);
      strcpy(R02561.R02561_appl_area.sAudtChgToNm, DTL_REC.sPassGrpCd);
      strcpy(R02561.R02561_appl_area.sPprNbr, A04710.A04710_appl_area.sPprNbr);
      }
   else
      {
      strcpy(R02561.R02561_appl_area.sNrevNbr,DTL_REC.sDesNrevNbr);
      strcpy(R02561.R02561_appl_area.sPassGrpCd,DTL_REC.sPassGrpCd);
      strcpy(R02561.R02561_appl_area.sAudtChgToNm, DTL_REC.sPassGrpCd);
      strcpy(R02561.R02561_appl_area.sPprNbr, DTL_REC.sPprNbr);
      } 

   /***********************************************************************/
   /** 4. Now, write a comment for this passenger.                       **/
   /**    Also, set up the same comment for the audit trail table        **/
   /**    and then write the audit trail record.                         **/
   /***********************************************************************/

   /** initialize service request block **/
   memset(&R02483, LOW_VALUES, sizeof(_R02483));
 
   /** format service request copybook **/
   strcpy(R02483.R02483_appl_area.sPassStsChgDt,sCurrentTsDt);
   strcpy(R02483.R02483_appl_area.sPassDtTmTs,sCurrentTsDt);
   strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);
  
   if ((nSpouseInd == TRUE) || (nCompanionInd == TRUE) || (nDomPartnerInd == TRUE))
      {
      strcpy(R02483.R02483_appl_area.sPprNbr, A04710.A04710_appl_area.sPprNbr);
      strcpy(R02483.R02483_appl_area.sNrevNbr, A04710.A04710_appl_area.sNrevNbr);
      strcpy(R02483.R02483_appl_area.sNrevNm, A04710.A04710_appl_area.sNrevNm);
      }
   else    
      {
      strcpy(R02483.R02483_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02483.R02483_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
      strcpy(R02483.R02483_appl_area.sNrevNm, DTL_REC.sPsgrNm);
      }
 
   if ((strcmp(DTL_REC.sStsActCd, DECEASED_A1) == 0) || (strcmp(DTL_REC.sStsActCd, DECEASED_A1_BG) == 0))
      {
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_EMP_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased Emp   ");
      }
   else  
   if (strcmp(DTL_REC.sDesStsActCd, DECEASED_C2) == 0)
      {
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_DSG_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased       "); 
      }
   if (strcmp(DTL_REC.sDesStsActCd, DEATH_OF_CHILD) == 0)
      {
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_DSG_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased       "); 
      }
   else  
   if (strcmp(DTL_REC.sDesStsActCd, DEATH_OF_SPOUSE) == 0)
      {
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_DSG_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased       "); 
      }
   else  
   if (strcmp(DTL_REC.sDesStsActCd, PASS_TERM) == 0)
      {
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED_DEATH);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, DECEASED_DSG_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Deceased       "); 
      }
   else /* psgr is now an ex-spouse */
   if ((strcmp(DTL_REC.sPsgrTypeCd, "XX") == 0) &&
       (strcmp(A04036.A04036_appl_area.sNrevTypCd, SPOUSE) == 0))
      {  
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, EX_SPOUSE_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - XSpouse        ");
      }  
   else
   if (nSpouseInd == TRUE) 
      {
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, SPOUSE_REVOKED_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Ineligible     ");
      }
   else
   if (nCompanionInd == TRUE)
      {
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt,COMPANION_REVOKED_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Ineligible     ");
      }
   if (nDomPartnerInd == TRUE)
      {
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt,DOMPARTNER_REVOKED_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Ineligible     ");
      }
   else
      {
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, INELIGIBLE_COMMENT);
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Ineligible     ");
      }

   TPM_7200_InsertComment();
 
   TPM_7210_WriteAuditTrail();
 
   /**************************************************************************************/
   /** Now, cursor the remaining allotment table and write a record to the deltamatic   **/
   /** table for each pass type for this passenger.                                     **/
   /**************************************************************************************/
 
   /****** Initialize request and answer blocks *****/ 
   memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA)); 
   memset(&A04325.A04325_appl_area, LOW_VALUES, sizeof(_A04325_APPL_AREA));

   if ((nSpouseInd == TRUE) || (nCompanionInd == TRUE) || (nDomPartnerInd == TRUE))
      {
      strcpy(sPprNbr, A04710.A04710_appl_area.sPprNbr);
      strcpy(sNrevNbr, A04710.A04710_appl_area.sNrevNbr);
      }
   else
      {
      strcpy(sPprNbr, DTL_REC.sPprNbr);
      strcpy(sNrevNbr, DTL_REC.sDesNrevNbr);
      }
   R04325.R04325_appl_area.cEmplArRecInd = DELETE_REC;

   TPM_7520_FormatDlmaticRec();

}



/******************************************************************
**                                                               **
** Function Name:   TPM_6520_ResetPassRiderStatus                **
**                                                               **
** Description:     Update the Status and PassSuspExpDt fields   **
**                  on the nonrev record.                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int    TPM_6520_ResetPassRiderStatus()
{
   short   nSvcRtnCd;   /* Service return code */


   if (nNrevPresent == TRUE)
      {
      nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R02564,&A02564,SERVICE_ID_02564,1,sizeof(_R02564_APPL_AREA));

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            RS.updt_nrev_record_cntr++;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS02564");
            if ((nSpouseInd == TRUE) || (nCompanionInd == TRUE) || (nDomPartnerInd == TRUE))
               {
               sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, PsgrType = %s", 
 
                                     A04710.A04710_appl_area.sPprNbr,
                                     A04710.A04710_appl_area.sNrevNbr,
                                     A04710.A04710_appl_area.sNrevTypCd);
               }
               else
               {                                      
               sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, PassGrp = %s, PsgrType = %s, RecType = %s, EffDt = %s",
                                     DTL_REC.cRecordId,
                                     DTL_REC.sPprNbr,
                                     DTL_REC.sDesNrevNbr,
                                     DTL_REC.sPassGrpCd,
                                     DTL_REC.sPsgrTypeCd,
                                     DTL_REC.sRecType,
                                     DTL_REC.sEffDt);
               }
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_6520_ResetPassRiderStatus");
            break;
         }
      }
   else /* else no nrev record present - can't revoke - do not process - drop the record */
      RS.records_not_processed++;
}



/******************************************************************
**                                                               **
** Function Name:   TPM_7001_WriteFutureDatedRec                 **
**                                                               **
** Description:     This function writes the input record to the **
**                  future file if the effective date is greater **
**                  than today.                                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_7001_WriteFutureDatedRec()

{

   /* Initialize output buffer */ 
   memset(&RS.EPBF030_buffer, LOW_VALUES, sizeof(RS.EPBF030_buffer));
   
   /***********************************************************/
   /** put today's date in the error date field in the buffer**/
   /***********************************************************/
   strncpy(RS.EPBF010_buffer+241,RS.sTodayDt,strlen(RS.sTodayDt));

   /***********************************************************/
   /** put the effective date in the effective date field;   **/
   /** may contain today's date (+) 30 days for deceased     **/ 
   /** processing.                                           **/
   /***********************************************************/
   strncpy(RS.EPBF010_buffer+249,DTL_REC.sEffDt,strlen(DTL_REC.sEffDt));
 
   /***********************************************************/
   /** Copy what's in the input buffer to the output buffer  **/ 
   /***********************************************************/
   memcpy(RS.EPBF030_buffer, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));

   /***********************************************************/
   /** Write record to output file                           **/
   /***********************************************************/
   BCH_WriteRec(RS.EPBF030, RS.EPBF030_buffer, sizeof(RS.EPBF030_buffer));
  
   /***********************************************************/
   /** Increment output future dated file record counter     **/
   /***********************************************************/
   RS.EPBF030_record_cntr++;

}



 
/******************************************************************
**                                                               **
** Function Name:   TPM_7005_CalculateMonthsSvc                  **
**                                                               **
** Description:     Calculate the months of service completed    **
**                  based on the input PPR Start Date and        **
**                  today's date.                                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

short TPM_7005_CalculateMonthsSvc(char *sStrtDt) 

{
   char         sString[3],            /** String for date components **/
                sYrString[5];          /** String for year date component **/

   short        nEffMonth,             /** Effective month string **/
                nEffDay,               /** Effective day string **/
                nEffYear,              /** Effective year string **/
                nStrtMonth,            /** Start month string **/
                nStrtDay,              /** Start day string **/
                nStrtYear,             /** Start year string **/
                nFltMoSvcNbr,          /** PPR months of service **/
		nDay;                  /** Day difference **/

   /**** Assign effective year ****/
   memset(sYrString,LOW_VALUES, sizeof(sYrString));
   strncpy(sYrString, RS.sTodayDt, 4);
   nEffYear = atoi(sYrString);
 
   /**** Assign effective month ****/
   memset(sString,LOW_VALUES, sizeof(sString));
   strncpy(sString, RS.sTodayDt+4, 2);
   nEffMonth = atoi(sString);
 
   /**** Assign effective day ****/
   memset(sString,LOW_VALUES, sizeof(sString));
   strncpy(sString, RS.sTodayDt+6, 2);
   nEffDay = atoi(sString);
 
   /**** Assign start year ****/
   memset(sYrString,LOW_VALUES, sizeof(sYrString));
   strncpy(sYrString, sStrtDt, 4);
   nStrtYear = atoi(sYrString);
 
   /**** Assign start month ****/
   memset(sString,LOW_VALUES, sizeof(sString));
   strncpy(sString, sStrtDt+4, 2);
   nStrtMonth = atoi(sString);
 
   /**** Assign start day ****/
   memset(sString,LOW_VALUES, sizeof(sString));
   strncpy(sString, sStrtDt+6, 2);
   nStrtDay = atoi(sString);
 
   /**** Calculate months of service ****/
   nFltMoSvcNbr = (((nEffYear - nStrtYear) * 12) + (nEffMonth - nStrtMonth));

   /***********************************************************************/
   /**** If start day is greater than effective day, subtract one from ****/
   /**** the months of service completed to account for the last month ****/
   /**** being less than a whole month.                                ****/
   /***********************************************************************/

   /** if (nStrtDay > nEffDay) **/
   /**   nFltMoSvcNbr -= 1;    **/
   nDay = 0;
   if ( nFltMoSvcNbr == 0 )
   {
     nDay = nEffDay - nStrtDay;
     if ( nDay >= 29 )
       nFltMoSvcNbr = 1;
   } else if ( nFltMoSvcNbr > 1 ) {
       if ( nStrtDay > nEffDay )
         nFltMoSvcNbr -= 1;
   } else {
     nDay = nStrtDay - nEffDay;
     switch(nStrtMonth) {
       case 1: case 3: case 5: case 7: case 8: case 10: case 12:
	   if (nDay > 2)
             nFltMoSvcNbr -= 1;
	 break;
       default:
	   if (nDay > 1)
             nFltMoSvcNbr -= 1;
         break;
     }
   }
 
   return (nFltMoSvcNbr);

}


/******************************************************************
**                                                               **
** Function Name:   TPM_7006_CalculateEffMonthsSvc               **
**                                                               **
** Description:     Calculate the months of service completed    **
**                  based on the input PPR Start Date and        **
**                  the input effective date.                    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

short TPM_7006_CalculateEffMonthsSvc(char *sStrtDt) 

{
   char         sString[3],            /** String for date components **/
                sYrString[5];          /** String for year date component **/

   short        nEffMonth,             /** Effective month string **/
                nEffDay,               /** Effective day string **/
                nEffYear,              /** Effective year string **/
                nStrtMonth,            /** Start month string **/
                nStrtDay,              /** Start day string **/
                nStrtYear,             /** Start year string **/
                nEffMoSvcNbr,          /** PPR months of service **/
		nDay;                  /** Day difference **/


   /**** Assign effective year ****/
   nEffYear = atoi(sEffdtYr);
 
   /**** Assign effective month ****/
   nEffMonth = atoi(sEffdtMo);
 
   /**** Assign effective day ****/
   nEffDay = atoi(sEffdtDy);
 
   /**** Assign start year ****/
   memset(sYrString,LOW_VALUES, sizeof(sYrString));
   strncpy(sYrString, sStrtDt, 4);
   nStrtYear = atoi(sYrString);
 
   /**** Assign start month ****/
   memset(sString,LOW_VALUES, sizeof(sString));
   strncpy(sString, sStrtDt+4, 2);
   nStrtMonth = atoi(sString);
 
   /**** Assign start day ****/
   memset(sString,LOW_VALUES, sizeof(sString));
   strncpy(sString, sStrtDt+6, 2);
   nStrtDay = atoi(sString);
 
   /**** Calculate months of service ****/
   nEffMoSvcNbr = (((nEffYear - nStrtYear) * 12) + (nEffMonth - nStrtMonth));

   /***********************************************************************/
   /**** If start day is greater than effective day, subtract one from ****/
   /**** the months of service completed to account for the last month ****/
   /**** being less than a whole month.                                ****/
   /***********************************************************************/
   /** if (nStrtDay > nEffDay) **/
   /**    nEffMoSvcNbr -= 1;   **/
   nDay = 0;
   if ( nEffMoSvcNbr == 0 )
   {
     nDay = nEffDay - nStrtDay;
     if ( nDay >= 29 )
       nEffMoSvcNbr = 1;
   } else if ( nEffMoSvcNbr > 1 ) {
       if ( nStrtDay > nEffDay )
         nEffMoSvcNbr -= 1;
   } else {
     nDay = nStrtDay - nEffDay;
     switch(nStrtMonth) {
       case 1: case 3: case 5: case 7: case 8: case 10: case 12:
	   if (nDay > 2)
             nEffMoSvcNbr -= 1;
	 break;
       default:
	   if (nDay > 1)
             nEffMoSvcNbr -= 1;
         break;
     }
   }
 
   return (nEffMoSvcNbr);

}

 
/******************************************************************
**                                                               **
** Function Name:   TPM_7007_CalculateYearsSvc                   **
**                                                               **
** Description:     Calculate the years of service completed     **
**                  based on the input PPR Start Year and        **
**                  the current year.                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

short TPM_7007_CalculateYearsSvc(char *sStrtDt)

{
   char         sString[3],            /** String for date components **/
                sYrString[5];          /** String for year date component **/

   short        nEffYear,              /** Effective year string **/
                nStrtYear,             /** Start year string **/
                nYearsSvcNbr;          /** PPR years of service **/

   /**** Assign effective year ****/
   memset(sYrString,LOW_VALUES, sizeof(sYrString));
   strncpy(sYrString, RS.sTodayDt, 4);
   nEffYear = atoi(sYrString);
 
   /**** Assign start year ****/
   memset(sYrString,LOW_VALUES, sizeof(sYrString));
   strncpy(sYrString, sStrtDt, 4);
   nStrtYear = atoi(sYrString);
 
   /**** Calculate years of service ****/
   nYearsSvcNbr = (nEffYear - nStrtYear);
 
   return (nYearsSvcNbr);

}


/******************************************************************
**                                                               **
** Function Name:   TPM_7008_ConvertDate                         **
**                                                               **
** Description:     This function calls the service to add 30    **
**                  days to today's date and return.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   sFltDprtDt                                   **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_7008_ConvertDate()
{
   short   nSvcRtnCd;   /* Service return code */


   /***************************************************/
   /** Call service to add 30 days to the given date **/
   /***************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04118,&A04118,SERVICE_ID_04118,1,sizeof(_R04118_APPL_AREA));
 
   /** Service Return Code Processing **/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04118");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7008_ConvertDate");
      }  
 
}
 


/******************************************************************
**                                                               **
** Function Name:   TPM_7010_CheckForPprRec                      **
**                                                               **
** Description:     Check to see if the PPR record is already    **
**                  there.                                      **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int  TPM_7010_CheckForPprRec()
{
   short   nSvcRtnCd;   /* Service return code */

 
 /*** Initialize Service Request and Answer Blocks **/
   memset(&R03834, LOW_VALUES, sizeof(_R03834));
   memset(&A03834, LOW_VALUES, sizeof(_A03834));

   strcpy(R03834.R03834_appl_area.sPprNbr, DTL_REC.sPprNbr);

   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R03834,&A03834,SERVICE_ID_03834,1,sizeof(_R03834_APPL_AREA));

   /** Service Return Code Processing **/

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         nPPRPresent = TRUE;
      if ((strcmp(A03834.A03834_appl_area.sPprStnId, "ABV") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ACA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ACC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "AGP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "AMM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "AMS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ANU") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ARN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ATH") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "AUA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BCN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BEG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BER") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BGI") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BJS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BJX") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BKK") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BOG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BOM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BRU") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BUD") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BUH") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BZE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CAI") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CCS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CDG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CPH") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CPT") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CUL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CUN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CZM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "DEL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "DKR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "DUB") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "DUS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "DXB") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "EDI") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "EZE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "FBU") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "FCO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "FOR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "FRA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GCM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GDL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GEO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GIG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GRU") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GUA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GVA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GYE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "HAM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "HEL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "HKG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "HMO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "IST") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "IZM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "JNB") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "KBP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "KIN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "KRK") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "KWI") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LED") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LGW") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LHR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LIM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LIR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LIS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LMM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LON") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LOS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LTO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LYS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MAA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MAD") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MAN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MAO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MBJ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MEX") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MGA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MID") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MIL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MOW") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MTY") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MUC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MXP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MZT") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "NBO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "NCE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "NGO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "NRT") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ORY") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "OSL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "OTP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PAR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PLS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "POP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "POS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "POZ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PRG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PSA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PTY") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PUJ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PVR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "REC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "RIO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ROM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "RTB") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SAL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SAO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SAP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SCL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SDQ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SIN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SJD") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SJO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SNN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "STI") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "STO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "STR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SVO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SXM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SYD") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TGU") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TIJ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TLV") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TRC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TXL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TYO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "UIO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "UVF") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "VCE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "VIE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "VLC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "WAW") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "YEG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "YUL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "YVR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "YYC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "YYZ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ZAG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ZCL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ZIH") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ZRH") == 0))
	     nIntlStation = TRUE;
         break;

      case ARC_ROW_NOT_FOUND:
         nPPRPresent = FALSE;
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS03834");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7010_CheckForPprRec");
         break;
      }

/****
      if ((strcmp(A03834.A03834_appl_area.sPprStnId, "ABV") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ACA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ACC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "AGP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "AMM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "AMS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ANU") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ARN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ATH") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "AUA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BCN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BEG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BER") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BGI") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BJS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BJX") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BKK") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BOG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BOM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BRU") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BUD") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BUH") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "BZE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CAI") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CCS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CDG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CPH") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CPT") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CUL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CUN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "CZM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "DEL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "DKR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "DUB") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "DUS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "DXB") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "EDI") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "EZE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "FBU") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "FCO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "FOR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "FRA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GCM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GDL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GEO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GIG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GRU") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GUA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GVA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "GYE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "HAM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "HEL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "HKG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "HMO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "IST") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "IZM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "JNB") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "KBP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "KIN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "KRK") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "KWI") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LED") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LGW") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LHR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LIM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LIR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LIS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LMM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LON") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LOS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LTO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "LYS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MAA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MAD") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MAN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MAO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MBJ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MEX") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MGA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MID") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MIL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MOW") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MTY") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MUC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MXP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "MZT") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "NBO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "NCE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "NGO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "NRT") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ORY") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "OSL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "OTP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PAR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PLS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "POP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "POS") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "POZ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PRG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PSA") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PTY") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PUJ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "PVR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "REC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "RIO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ROM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "RTB") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SAL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SAO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SAP") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SCL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SDQ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SIN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SJD") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SJO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SNN") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "STI") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "STO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "STR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SVO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SXM") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "SYD") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TGU") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TIJ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TLV") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TRC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TXL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "TYO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "UIO") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "UVF") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "VCE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "VIE") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "VLC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "WAW") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "YEG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "YUL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "YVR") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "YYC") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "YYZ") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ZAG") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ZCL") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ZIH") == 0) ||
          (strcmp(A03834.A03834_appl_area.sPprStnId, "ZRH") == 0))
	      
	     nIntlStation = TRUE;
****/	      

}
 
        

/******************************************************************
**                                                               **
** Function Name:   TPM_7015_EvalValidPsgrType                   **
**                                                               **
** Description:     This function evaluates the pass group       **
**                  and passenger type.  If not valid, the       **
**                  record will not be processed.  It will be    **
**                  written to the error file.                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int    TPM_7015_EvalValidPsgrType()
{
   short   nSvcRtnCd;   /* Service return code */


   strcpy(R02861.R02861_appl_area.sPassGrpCd, sSavePassGrpCd);

   /**********************************************************************/
   /** Call service to select row from the PassGroup/PsgrTypeCode table **/
   /**********************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R02861,&A02861,SERVICE_ID_02861,1,sizeof(_R02861_APPL_AREA));

   /** Service Return Code Processing **/

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         nValidPgpPtyp = TRUE;
         break;
        
      case ARC_ROW_NOT_FOUND:  
         nValidPgpPtyp = FALSE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02861");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7015_EvalValidPsgrType");
         break;  

      }

}

 

/******************************************************************
**                                                               **
** Function Name:   TPM_7020_ParseOutName                        **
**                                                               **
** Description:     Split the name into last, first, middle init **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_7020_ParseOutName()
{
   short   nSvcRtnCd;        /* Service return code */
   int     nNmCtr,           /* Counts name components (1 = last, 2 = first, 3 = middle) */
           nPos,             /* Counts position of name components */
           nMidInd,          /* Indicates middle initial */
           nFrstCommaInd,    /* Indicates first comma encounted in name */
           nMultNmInd,       /* Indicates if last name has more than one word */
           i;                /* Indicates position in full name string */


 /* Break down the passenger name */
   nNmCtr = 1;
   nPos   = 0;
   i      = 0;
   nMidInd       = TRUE;
   nFrstCommaInd = TRUE;
   nMultNmInd    = FALSE;
   nOneInitialLstNm  = FALSE;

 /*** clear out intermediate name fields                                         ***/
   strncpy(sLstNm, SPACE_CHAR,sizeof(sLstNm));
   strncpy(sFrstNm, SPACE_CHAR,sizeof(sFrstNm));
   strncpy(sFullNm, SPACE_CHAR,sizeof(sFullNm));
   cMidNm = ' ';

   while ((i < 30) && (DTL_REC.sPsgrNm[i] != LOW_VALUES))
      {
      switch (DTL_REC.sPsgrNm[i])
         {
         case ',':
            if (nFrstCommaInd == TRUE)
	    /*******  checking for ',' in second position  LAS 02-25-2010***/
               if (i >= 2)
               {
               nNmCtr = 2;
               nPos = 0;

               i++;
               if (DTL_REC.sPsgrNm[i] ==  ' ')
                  {
                  cNameError = 'Y';
                  }
               else
                  {
                  cNameError = 'N';
                  }
               i = i - 1;
               }
	       /******** code for "MR" before single character last name, LAS 02-25-2010 ***/
	       else
	         {
                  nOneInitialLstNm = TRUE;
                  strcpy(sLstNm, "M");
		  strcat(sLstNm, "R");
                  strncat(sLstNm, DTL_REC.sPsgrNm, 1);
                  strncpy(sFullNm, sLstNm, 2);
                  strncat(sFullNm,DTL_REC.sPsgrNm, 28); 
                  nNmCtr = 2;
                  nPos = 0;

                  i++;
                  if (DTL_REC.sPsgrNm[i] ==  ' ')
                     {
                     cNameError = 'Y';
                     }
                  else
                     {
                     cNameError = 'N';
                     }
                  i = i - 1;
		  /*
                  sLstNm[nPos] = DTL_REC.sPsgrNm[i];
		  */
	         }	  
	       /****** code above is to move "MR" before single character last name, LAS 02-25-2010 ***/
            break;
         case ' ':
            if (nNmCtr == 1)
               {
               nMultNmInd = TRUE;
               if (nPos <= 14)
                  sLstNm[nPos] = DTL_REC.sPsgrNm[i];
               break;
               }
            if (nNmCtr == 2)
               {
               nNmCtr++;
               break;
               }
            if (nNmCtr == 3)
               {
               nNmCtr++;
               cMidNm = ' ';
               break;
               }
            if (nNmCtr > 3)
               nNmCtr++;
            break;
         default:
            if (nNmCtr == 1)
               if (nPos <= 14) 
                  sLstNm[nPos++] = DTL_REC.sPsgrNm[i];
            if (nNmCtr == 2)
               {
               nFrstCommaInd = FALSE;
               if (nPos <= 13) 
                  sFrstNm[nPos++] = DTL_REC.sPsgrNm[i];
               }
            if ((nNmCtr == 3) && (nMidInd == TRUE))
               {
               nMidInd = FALSE;
               if (DTL_REC.sPsgrNm[i] == '\0')
                  cMidNm = ' '; 
               else
                  cMidNm = DTL_REC.sPsgrNm[i];
               nNmCtr++;
               }
            break;
         }
      i++;
      if (nMultNmInd == TRUE)
         {
         nMultNmInd = FALSE;
         nPos++;
         }
      }
               
   if ((sFrstNm[0] == LOW_VALUES) || (nFrstCommaInd == TRUE))
      {
/*
      strncpy(sFrstNm, sFrstNmSpace, sizeof(sFrstNm));
      cMidNm = ' ';
*/
      cNameError = 'Y';
      }

}




/******************************************************************
**                                                               **
** Function Name:   TPM_7025_CheckPprRevoked                     **
**                                                               **
** Description:     Check to see if the Ppr is revoked.          **
**                  Also, for A1 records, set the flag           **
**                  nNrevPresent.                                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
int  TPM_7025_CheckPprRevoked()
{
   short   nSvcRtnCd;   /* Service return code */
 
 
   memset(&R04036, LOW_VALUES, sizeof(_R04036));
   memset(&A04036, LOW_VALUES, sizeof(_A04036));
 
   strcpy(R04036.R04036_appl_area.sPprNbr, DTL_REC.sPprNbr);
   strcpy(R04036.R04036_appl_area.sNrevNbr, "00");
 
   nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04036,&A04036,SERVICE_ID_04036,1,sizeof(_R04036_APPL_AREA));
 
   /** Service Return Code Processing **/
 
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:

      /**** testing original code  ****
	 cSaveCurAtvnFeeCd = A04036.A04036_appl_area.cCurAtvnFeeCd;
     *****/

         if (strcmp(A04036.A04036_appl_area.sPassStsCd, REVOKED) == 0)
            nPprRevoked = TRUE;
         else
            nPprRevoked = FALSE;

         if (strcmp(DTL_REC.sRecType, A1_REC) == 0)
            nNrevPresent = TRUE;
         break;
 
      case ARC_ROW_NOT_FOUND:
         if (strcmp(DTL_REC.sRecType, A1_REC) == 0)
            nNrevPresent = FALSE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04036");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7025_CheckPprRevoked");
         break;
      }


}



 
/******************************************************************
**                                                               **
** Function Name:   TPM_7030_CheckForNrevRecord                  **
**                                                               **
** Description:     Check to see if the Nrev record is already   **
**                  there.                                       **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int  TPM_7030_CheckForNrevRecord()
{
   short   nSvcRtnCd;   /* Service return code */

 
   /*** Initialize Service Request and Answer Blocks **/
   memset(&R04036, LOW_VALUES, sizeof(_R04036));
   memset(&A04036, LOW_VALUES, sizeof(_A04036));

   strcpy(R04036.R04036_appl_area.sPprNbr, DTL_REC.sPprNbr);
   strcpy(R04036.R04036_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

   nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04036,&A04036,SERVICE_ID_04036,1,sizeof(_R04036_APPL_AREA));

   /** Service Return Code Processing **/

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         nNrevPresent = TRUE;
         break;

      case ARC_ROW_NOT_FOUND:
         nNrevPresent = FALSE;
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04036");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7030_CheckForNrevRecord");
         break;
      }

}
 
 
        
/******************************************************************
**                                                               **
** Function Name:   TPM_7040_DetermineImputedTravelInd           **
**                                                               **
** Description:     This function determines the Imputed Travel  **
**                  Indicator for the nonrev record.             **
**                  First, the intertax number is checked.  If   **
**                  it is not blank, the imputed indicator is    **
**                  set to 'Y', and no other processing is       **
**                  necessary.  If it is blank, then the Pass    **
**                  Group Code table is checked.  After this,    **
**                  if the imputed indicator is still 'N', the   **
**                  Passenger Type Code table is checked.        **
**                  After this check, if the imputed indicator   **
**                  is still 'N', then the passes are not        **
**                  imputed for this passenger.                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_7040_DetermineImputedTravelInd()
{
   short   nSvcRtnCd;   /* Service return code */
cImputedInd = 'N';

 /************************************************************************************************/
 /** The module will no longer check Intertax Nbr to determine the imputed indicator, will now always check the pass group table.  (L.Scott, 11/23/99)               
 /************************************************************************************************/

      /***************************************************************/
      /** Read pass group code table and set the imputed indicator  **/
      /***************************************************************/
      TPM_7041_ReadPassGpCodeTable();
 
      /***************************************************************/
      /** If imputed indicator has not been set to 'Y' or 'T',      **/
      /** check the imputed indicator on the Passenger Type table   **/
      /***************************************************************/
      if ((cImputedInd != 'Y') && (cImputedInd != 'T')) 
         {
         TPM_7045_CheckPsgrTypeCdTbl();
         }

}



/******************************************************************
**                                                               **
** Function Name:   TPM_7041_ReadPassGpCodeTable                 **
**                                                               **
** Description:     This function selects a record from the      **
**                  Pass Group Code Table.                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_7041_ReadPassGpCodeTable()
{
   short   nSvcRtnCd;   /* Service return code */


   /** Initialize Service Request and Answer Blocks to select from Pass Grp Cd table**/
   memset(&R02475, LOW_VALUES, sizeof(_R02475));
   memset(&A02475, LOW_VALUES, sizeof(_A02475));

   /** Format application area of request block **/
   strcpy(R02475.R02475_appl_area.sPassGrpCd, DTL_REC.sPassGrpCd);

   /*************************************************************/
   /** Call service to select row from the PassGroupCode table **/
   /*************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R02475,&A02475,SERVICE_ID_02475,1,sizeof(_R02475_APPL_AREA));

   /** Service return code processing **/
   switch(nSvcRtnCd)
      {
      case ARC_SUCCESS:
         cImputedInd = A02475.A02475_appl_area.cPassImptInd; 
         break;
    
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02475");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7041_ReadPassGpCodeTable");
         break;
      }  

}



/******************************************************************
**                                                               **
** Function Name:   TPM_7045_CheckPsgrTypeCdTbl                  **
**                                                               **
** Description:     This function uses the pass type code        **
**                  to check the Imputed Indicator on the        **
**                  Passenger Type Code Table.                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_7045_CheckPsgrTypeCdTbl()
{
   short   nSvcRtnCd;   /* Service return code */


   /************************************************************************************/
   /** Initialize Service Request and Answer Blocks to select from Psgr Type Cd table **/
   /** to check imputed indicator based on Passenger Type Code                        **/
   /************************************************************************************/
   memset(&R02529, LOW_VALUES, sizeof(_R02529));
   memset(&A02529, LOW_VALUES, sizeof(_A02529));

   /** Format application area of request block **/
   strcpy(R02529.R02529_appl_area.sNrevTypCd, DTL_REC.sPsgrTypeCd);

   /*******************************************************************/
   /** Call service to select row from the Passenger Type code table **/
   /** to check the imputed indicator                                **/
   /** NOTE:  the cValidPsgrType indicator is used only in Delete    **/
   /** processing.                                                   **/
   /*******************************************************************/
 
   nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(_R02529_APPL_AREA));

   /** Service return code processing **/
   switch (nSvcRtnCd)
      { 
      case ARC_SUCCESS:
         cImputedInd = A02529.A02529_appl_area.cPassImptInd;
         cValidPsgrType  = 'Y';
         break;

      case ARC_ROW_NOT_FOUND:
         cValidPsgrType  = 'N';
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02529");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7045_CheckPsgrTypeCdTbl");
         break;
      }

}

/******************************************************************
**                                                               **
** Function Name:   TPM_7050_CursorNrevPsgr                      **
**                                                               **
** Description:     Opens a cursor on the nonrev passenger       **
**                  table.  Used when read or update of all      **
**                  passengers is required.                      **
**                  Uses thread UPD1.                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    TPM_7050_CursorNrevPsgr()
{
   short   nSvcRtnCd;   /* Service return code */
 
   /** read database for ALL nonrev passengers for ppr **/
 
   /** Initialize Service Request Block **/
   memset(&R04309.R04309_appl_area, LOW_VALUES, sizeof(_R04309_APPL_AREA));
   memset(&A04309.A04309_appl_area, LOW_VALUES, sizeof(_A04309_APPL_AREA));
   R04309.R04309_appl_area.cNrevPassChgInd = ' ';
 
   /** Format the request block for the select of ALL nonrev records for the PPR **/
   strcpy(R04309.R04309_appl_area.sPprNbr, DTL_REC.sPprNbr);
 
   R04309.R04309_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
 
   nSvcRtnCd = BCH_InvokeService(EPBUPD8,&R04309,&A04309,SERVICE_ID_04309,1,sizeof(_R04309_APPL_AREA));
 
   /** Service return code processing **/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:

      /************  testing original code  ******/

      if (strcmp(A04309.A04309_appl_area.sNrevNbr, "00") == 0) 
	 {
	 cSavePrvAtvnFeeCd = ' ';
	 cSaveCurAtvnFeeCd = ' ';
	 cSaveNxtAtvnFeeCd = ' ';
	 strncpy(sSavePrvAtvnLupdtLts, "  ",sizeof(sSavePrvAtvnLupdtLts));
	 strncpy(sSaveCurAtvnLupdtLts, "  ",sizeof(sSaveCurAtvnLupdtLts));
	 strncpy(sSaveNxtAtvnLupdtLts, "  ",sizeof(sSaveNxtAtvnLupdtLts));
	 cSavePrvAtvnFeeCd = A04309.A04309_appl_area.cPrvAtvnFeeCd;
	 strcpy(sSavePrvAtvnLupdtLts, A04309.A04309_appl_area.sPrvAtvnLupdtLts);
	 cSaveCurAtvnFeeCd = A04309.A04309_appl_area.cCurAtvnFeeCd;
	 strcpy(sSaveCurAtvnLupdtLts, A04309.A04309_appl_area.sCurAtvnLupdtLts);
	 cSaveNxtAtvnFeeCd = A04309.A04309_appl_area.cNxtAtvnFeeCd;
	 strcpy(sSaveNxtAtvnLupdtLts, A04309.A04309_appl_area.sNxtAtvnLupdtLts);
	 }

     /************************/
         break;
 
      case ARC_ROW_NOT_FOUND:
         nEndOfPassRiders = TRUE;
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04309");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7050_CursorNrevPsgr");
         break;
      } 
 
}



/******************************************************************
**                                                               **
** Function Name:   TPM_7055_NextNrevPsgr                        **
**                                                               **
** Description:     Gets the next nonrev passenger from the      **
**                  cursor service 4309.                         **
**                  Uses thread UPD1.                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    TPM_7055_NextNrevPsgr()
{
   short   nSvcRtnCd;   /* Service return code */

   /** get the next database row **/
   R04309.R04309_appl_area.cArchCursorOpTxt = FETCH_ROW;
 
   nSvcRtnCd = BCH_InvokeService(EPBUPD8,&R04309,&A04309,SERVICE_ID_04309,1,sizeof(_R04309_APPL_AREA)); 

   /** Service return code processing **/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;
             
      case ARC_ROW_NOT_FOUND:
         nEndOfPassRiders = TRUE;
         break;
             
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04309");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7055_NextNrevPsgr");
         break;
      }   

}


/******************************************************************
**                                                               **
** Function Name:   TPM_7100_BadDate                             **
**                                                               **
** Description:     This function calls the function to write    **
**                  to the error file, formats the appropriate   **
**                  message.                                     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int     TPM_7100_BadDate()
{
   short   nSvcRtnCd;   /* Service return code */


   /*** Write input file to output error file ***/
   cValidateError = 'Y';

   cErrorCode = '4';   
   if (strcmp(DTL_REC.sSourceSys, DELTA) == 0)  
      {
      TPM_7611_GenerateEPB50011();   
      }
   else  
   if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)   
      {
      TPM_7612_GenerateEPB50012();   
      }
   else   
   if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)    
      {
      TPM_7613_GenerateEPB50013();   
      }
   else   
   if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)    
      {
      TPM_7614_GenerateEPB50014();   
      }
   else  
   if (strcmp(DTL_REC.sSourceSys, ASA) == 0)  
      {
      TPM_7615_GenerateEPB50015();   
      }
   else  
   if (strcmp(DTL_REC.sSourceSys, COMAIR) == 0)  
      {
      TPM_7616_GenerateEPB50016();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0) 
      {
      TPM_7617_GenerateEPB50017();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY) == 0)  
      {
      TPM_7618_GenerateEPB50018();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0)  
      {
      TPM_7619_GenerateEPB50019();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, ACA) == 0)  
      {
      TPM_7620_GenerateEPB50020();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0)  
      {
      TPM_7621_GenerateEPB50021();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0)  
      {
      TPM_7622_GenerateEPB50022();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, FREEDOM) == 0)  
      {
      TPM_7623_GenerateEPB50023();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, BIG_SKY) == 0)  
      {
      TPM_7624_GenerateEPB50024();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET) == 0)  
      {
      TPM_7625_GenerateEPB50025();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, PINNACLE) == 0)  
      {
      TPM_7626_GenerateEPB50026();   
      }
   else
   /**********************
   if (strcmp(DTL_REC.sSourceSys, NORTHWEST) == 0)  
      {
      TPM_7627_GenerateEPB50027();   
      }
   else
   ************************/
	//Manual PPR Added data --PPatnaik
	if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0) 
	{
		TPM_7627_GenerateEPB50027();  
	}
	else
   if (strcmp(DTL_REC.sSourceSys, MESABA) == 0)  
      {
      TPM_7628_GenerateEPB50028();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, COMPASS) == 0)  
      {
      TPM_7629_GenerateEPB50029();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, MLT) == 0)  
      {
      TPM_7630_GenerateEPB50030();   
      }
   else
   if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE) == 0) 
      {
      TPM_7631_GenerateEPB50031();  
      }
   else
   if (strcmp(DTL_REC.sSourceSys, GOJET) == 0) 
      {
      TPM_7632_GenerateEPB50032();  
      }
   else
      {
      sprintf(sErrorMessage, "ERROR 4:  Invalid Start Date      "); 
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s",
                              DTL_REC.sPprNbr,
                              DTL_REC.sDesNrevNbr);
      BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
      BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_7100_BadDate");   
      }
}




/******************************************************************
**                                                               **
** Function Name:   TPM_7200_InsertComment                       **
**                                                               **
** Description:     This function writes to the comments         **
**                  table when pass privileges are revoked.      **
**                  This occurs when an employee is terminated,  **
**                  or when a pass rider dies.                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7200_InsertComment()
{
   short   nSvcRtnCd;   /* Service return code */


   /****************************************************/
   /** call service to insert row into comments table **/
   /****************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD5,&R02483,&A02483,SERVICE_ID_02483,1,sizeof(_R02483_APPL_AREA));

   /** Service return code processing **/
   switch (nSvcRtnCd)
      { 
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02483");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7200_InsertComment");
         break;
      }

}



/******************************************************************
**                                                               **
** Function Name:   TPM_7210_WriteAuditTrail                     **
**                                                               **
** Description:     This function writes to the audit trail      **
**                  table when pass privileges are revoked or    **
**                  unrevoked.  Adds, Changes, and Deletes       **
**                  are included.                                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7210_WriteAuditTrail()
{
   short   nSvcRtnCd;   /* Service return code */


   /*******************************************************/
   /** call service to insert row into audit trail table **/
   /*******************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD7,&R02561,&A02561,SERVICE_ID_02561,1,sizeof(_R02561_APPL_AREA));

   /** Service return code processing **/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02561");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7210_WriteAuditTrail");
         break;
      }  

}


/******************************************************************
**                                                               **
** Function Name:   TPM_7310_WriteToPassCardTableRider           **
**                                                               **
** Description:     Write to Pass Card table.                    **
**                  When name or birthdate changes, write        **
**                  record for the pass rider only.              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void     TPM_7310_WriteToPassCardTableRider()
{
   short   nSvcRtnCd;        /* Service return code */

 
   /**************************************************************************************/
   /**   insert a new record with:                                                      **/
   /**      card_iss_dt = PPR start date                                                **/
   /**      card_sts_ind = "A"                                                          **/
   /**      card_proc_ind = "N"                                                         **/
   /**      svc_chgr_cd = NO_CHARGE                                                     **/
   /**************************************************************************************/
  
   /********************************************************/
   /** Insert new pass card record for this ppr/nrev:     **/
   /********************************************************/
   /** Initialize Service Request Block                   **/
   memset(&R02388, LOW_VALUES, sizeof(_R02388));
      
   strcpy(R02388.R02388_appl_area.sPprNbr, DTL_REC.sPprNbr);
   strcpy(R02388.R02388_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

   if ((strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0) ||
       (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) ||
       (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) ||
       (strcmp(DTL_REC.sSourceSys, ACA) == 0) ||
       (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) ||
       (strcmp(DTL_REC.sEmpCatCd, "IN") == 0))
      {
      if((strcmp(DTL_REC.sCardIssDt, ZERO_DATE) == 0) || 
         (strcmp(DTL_REC.sCardIssDt, "") == 0))
         strcpy(R02388.R02388_appl_area.sCardIssDt, LOW_DATE);
      else
         strcpy(R02388.R02388_appl_area.sCardIssDt, UTL_ConvertDate(DTL_REC.sCardIssDt, CNV_YYYYMMDD_TO_DB));
      }
   else
      strcpy(R02388.R02388_appl_area.sCardIssDt, sCurrentTsDt);

   if ((strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0) ||
       (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0) ||
       (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0) ||
       (strcmp(DTL_REC.sSourceSys, ACA) == 0) ||
       (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0) ||
       (strcmp(DTL_REC.sEmpCatCd, "IN") == 0))
      {
      if ((nMaxParentInd == TRUE) || (nPprRevoked == TRUE) || (nProcessAsRevoked == TRUE))
         {
         R02388.R02388_appl_area.cCardStsInd = 'D';
         R02388.R02388_appl_area.cCardProcInd = 'P';
         }
      else
         {
         R02388.R02388_appl_area.cCardStsInd = 'A';
         R02388.R02388_appl_area.cCardProcInd = 'P';
         }
      }
   else
      {
      if ((nMaxParentInd == TRUE) || (nPprRevoked == TRUE) || (nProcessAsRevoked == TRUE))
         {
         R02388.R02388_appl_area.cCardStsInd = 'D';
         R02388.R02388_appl_area.cCardProcInd = 'P';
         }
      else
         {
         R02388.R02388_appl_area.cCardStsInd = 'A';
         R02388.R02388_appl_area.cCardProcInd = 'N';
         }
      }

   strcpy(R02388.R02388_appl_area.sSvcChrgCd, NO_CHARGE);

   TPM_7320_InsertPassCardTableRider();

}



/******************************************************************
**                                                               **
** Function Name:   TPM_7320_InsertPassCardTableRider            **
**                                                               **
** Description:     Write to Pass Card table.                    **
**                  When name or birthdate changes, write        **
**                  record for the pass rider only.              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void     TPM_7320_InsertPassCardTableRider()
{
   short   nSvcRtnCd;        /* Service return code */
   short   nSvcRtnCd1;        /* Service return code */
 


   /************************************************/
   /** Shridev Makim: 2/20/98                     **/
   /** Do not order pass card for nrevs whose     **/
   /** ppr nbr starts with 'TQ'.                  **/
   /************************************************/
 
   if ( strncmp(DTL_REC.sPprNbr, "TQ", 2) == 0 )
        return;  


   /************************************************/
   /** Insert new record into the Pass Card Table **/
   /************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD6,&R02388,&A02388,SERVICE_ID_02388,1,sizeof(_R02388_APPL_AREA));

   /** Service return code processing **/
   switch (nSvcRtnCd)
      { 
      case ARC_SUCCESS:
         break;

      case ARC_DUPLICATE_ROW:
         strcpy(R04025.R04025_appl_area.sPprNbr, R02388.R02388_appl_area.sPprNbr);
         strcpy(R04025.R04025_appl_area.sNrevNbr, R02388.R02388_appl_area.sNrevNbr);
         R04025.R04025_appl_area.cCardStsInd = R02388.R02388_appl_area.cCardStsInd;
         R04025.R04025_appl_area.cCardProcInd = R02388.R02388_appl_area.cCardProcInd;
         strcpy(R04025.R04025_appl_area.sSvcChrgCd, NO_CHARGE);
         nSvcRtnCd1 = BCH_InvokeService(EPBUPD6,&R04025,&A04025,SERVICE_ID_04025,1,sizeof(_R04025_APPL_AREA));

         if (nSvcRtnCd1 != ARC_SUCCESS)
            {
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS02388");
            BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7320_InsertPassCardTableRider");
            }
            
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02388");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7320_InsertPassCardTableRider");
         break;
      }

}



/******************************************************************
**                                                               **
** Function Name:   TPM_7330_UpdatePassCardRecord                **
**                                                               **
** Description:     Updates the selected Pass Card Record.       **
**                  Changes the card status indicator and the    **
**                  card process indicator to the values set up  **
**                  prior to calling this function.              **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void     TPM_7330_UpdatePassCardRecord()
{
   short   nSvcRtnCd;        /* Service return code */
   char    sErrorMessage[64];


   /*************************************************************************/
   /** call service to Update the Pass Card Table for the current ppr/nrev **/
   /*************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD6,&R02567,&A02567,SERVICE_ID_02567,1,sizeof(_R02567_APPL_AREA));

   /** Service return code processing **/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02567");
         sprintf(sErrorMessage, "Ppr = %s, Nrev = %s", R02567.R02567_appl_area.sPprNbr, R02567.R02567_appl_area.sNrevNbr);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7330_UpdatePassCardRecord");
         break;
      }
 
}



/******************************************************************
**                                                               **
** Function Name:   TPM_7340_CursorPassCardTable                 **
**                                                               **
** Description:     For an individual pass rider, reads the      **
**                  Pass Card Table.                             **
**                  Sets an Indicator if no record is found.     **
**                  Executes service 04477.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7340_CursorPassCardTable()
{
   short   nSvcRtnCd;   /* Service return code */


   R04477.R04477_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /***********************************************************************/
   /** Execute service to read the Pass Card Table for the latest record **/
   /***********************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ7,&R04477,&A04477,SERVICE_ID_04477,1,sizeof(_R04477_APPL_AREA));

   /** Service return code processing **/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         nPcRecFound = TRUE;
         break;
 
      case ARC_ROW_NOT_FOUND:
         nPcRecFound = FALSE;
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04477");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7340_CursorPassCardTable");
         break;
      }
}
 
 
 
/******************************************************************
**                                                               **
** Function Name:   TPM_7350_UpdatePassCardRecord                **
**                                                               **
** Description:     Updates the selected Pass Card Record.       **
**                  Changes the card status indicator to the     **
**                  value set up prior to calling this function. **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void     TPM_7350_UpdatePassCardRecord()
{
   short   nSvcRtnCd;        /* Service return code */
 
 
   /*************************************************************************/
   /** call service to Update the Pass Card Table for the current ppr/nrev **/
   /*************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD6,&R04478,&A04478,SERVICE_ID_04478,1,sizeof(_R04478_APPL_AREA));
 
   /** Service return code processing **/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04478");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7350_UpdatePassCardRecord");
         break;
      }  

}
 

/******************************************************************
**                                                               **
** Function Name:   TPM_7400_CreateAllotRecordRider              **
**                                                               **
** Description:     Create remaining allotment records for       **
**                  new pass rider.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void     TPM_7400_CreateAllotRecordRider()
{
   short   nSvcRtnCd;   /* Service return code */

   nEndOfPassType = FALSE;

  
   /**************************************************************************************/
   /** Read pass allotment table for all allotment settings for this pass rider,        **/
   /** according to pass group code, nonrev type code, and months of service completed. **/
   /**************************************************************************************/
  
   /****** Initialize request and answer blocks *****/
   memset(&R02645.R02645_appl_area, LOW_VALUES, sizeof(_R02645_APPL_AREA));
   memset(&A02645.A02645_appl_area, LOW_VALUES, sizeof(_A02645_APPL_AREA));

   /**** Format service request copybook ****/
   strcpy(R02645.R02645_appl_area.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(R02645.R02645_appl_area.sNrevTypCd, DTL_REC.sPsgrTypeCd);

   /***************************************************************************************/
   /** if this is a C2 record, get months of svc completed from answer block of PPR read **/
   /** if this is an A1 record, recalculate the months of service completed              **/
   /***************************************************************************************/

   if(strcmp(DTL_REC.sRecType, C2_REC) == 0)
      R02645.R02645_appl_area.nFltMoSvcNbr = A03834.A03834_appl_area.nFltMoSvcNbr;
   else
      {
      R02645.R02645_appl_area.nFltMoSvcNbr = TPM_7005_CalculateMonthsSvc(DTL_REC.sStrtDt);
      }
 
   /** Open the initial DB cursor **/
   R02645.R02645_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
                         
   /**************************************************************************************/
   /** Execute service to select records from the Pass Allotment table based on the     **/
   /**  pass group, passenger type, and months of service completed                     **/
   /**************************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ5,&R02645,&A02645,SERVICE_ID_02645,1,sizeof(_R02645_APPL_AREA));
 
   /** Service return code processing **/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         cErrorCode = '5';   
         if (strcmp(DTL_REC.sSourceSys, DELTA) == 0)  
            {
            TPM_7611_GenerateEPB50011();   
            }
         else  
         if (strcmp(DTL_REC.sSourceSys, WORLDSPAN) == 0)   
            {
            TPM_7612_GenerateEPB50012();   
            }
         else   
         if (strcmp(DTL_REC.sSourceSys, TRANSQUEST) == 0)    
            {
            TPM_7613_GenerateEPB50013();   
            }
         else   
         if (strcmp(DTL_REC.sSourceSys, DELTA_STAFFING) == 0)    
            {
            TPM_7614_GenerateEPB50014();   
            }
         else  
         if (strcmp(DTL_REC.sSourceSys, ASA) == 0)  
            {
            TPM_7615_GenerateEPB50015();   
            }
         else  
         if (strcmp(DTL_REC.sSourceSys, COMAIR) == 0)  
            {
            TPM_7616_GenerateEPB50016();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, AIR_WISCONSIN) == 0) 
            {
            TPM_7617_GenerateEPB50017();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMAIR_ACADEMY) == 0)  
            {
            TPM_7618_GenerateEPB50018();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SKYWEST) == 0)  
            {
            TPM_7619_GenerateEPB50019();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, ACA) == 0)  
            {
            TPM_7620_GenerateEPB50020();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, CHAUTAUQUA) == 0)  
            {
            TPM_7621_GenerateEPB50021();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, SHUTTLE_AMERICA) == 0)  
            {
            TPM_7622_GenerateEPB50022();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, FREEDOM) == 0)  
            {
            TPM_7623_GenerateEPB50023();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, BIG_SKY) == 0)  
            {
            TPM_7624_GenerateEPB50024();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, EXPRESS_JET) == 0)  
            {
            TPM_7625_GenerateEPB50025();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, PINNACLE) == 0)  
            {
            TPM_7626_GenerateEPB50026();   
            }
         else
	 /***************
         if (strcmp(DTL_REC.sSourceSys, NORTHWEST) == 0)  
            {
            TPM_7627_GenerateEPB50027();   
            }
         else
	 ***************/
		  //Manual PPR Added data --PPatnaik
		 if (strcmp(DTL_REC.sSourceSys, MANUAL) == 0) 
			 {
			  TPM_7627_GenerateEPB50027();  
			 }
		 else         
		 if (strcmp(DTL_REC.sSourceSys, MESABA) == 0)  
            {
            TPM_7628_GenerateEPB50028();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, COMPASS) == 0)  
            {
            TPM_7629_GenerateEPB50029();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, MLT) == 0)  
            {
            TPM_7630_GenerateEPB50030();   
            }
         else
         if (strcmp(DTL_REC.sSourceSys, REGIONAL_ELITE) == 0) 
            {
            TPM_7631_GenerateEPB50031();  
            }
         else
         if (strcmp(DTL_REC.sSourceSys, GOJET) == 0) 
            {
            TPM_7632_GenerateEPB50032();  
            }
         else
            {
            sprintf(sErrorMessage, "ERROR 5:  Allotments not found on Pass Allotment table - Allotments not set");
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
            sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, PassGrp = %s, PsgrType = %s",
                                  DTL_REC.cRecordId,
                                  DTL_REC.sPprNbr,
                                  DTL_REC.sDesNrevNbr,
                                  DTL_REC.sPassGrpCd,
                                  DTL_REC.sPsgrTypeCd);
            BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
            sprintf(sErrorMessage, "RecType = %s, MoSvc = %d, EffDt = %s",
                                  DTL_REC.sRecType,
                                  R02645.R02645_appl_area.nFltMoSvcNbr,
                                  DTL_REC.sEffDt);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_7400_CreateAllotRecordRider");   
            }


         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02645");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7400_CreateAllotRecordRider");
      }
 
   /************************************/
   /** Process pass allotment DB rows **/
   /************************************/
   while ((nSvcRtnCd != ARC_ROW_NOT_FOUND) && (nEndOfPassType == FALSE))
      {
      /** Initialize request and answer blocks **/
      memset(&R02443.R02443_appl_area, LOW_VALUES, sizeof(_R02443_APPL_AREA));
      memset(&A02443.A02443_appl_area, LOW_VALUES, sizeof(_A02443_APPL_AREA));

      /** Format service request copybook **/
      strcpy(R02443.R02443_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R02443.R02443_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
      strcpy(R02443.R02443_appl_area.sPassTypCd, A02645.A02645_appl_area.sPassTypCd);
 
      /************************************************************************/
      /** When adding a new pass rider, assign allotments for days not miles.**/
      /** Remaining days and Current days will be the same.                  **/
      /** Remaining miles and Current miles will be zero.                    **/
      /**                                                                    **/
      /** Special processing for EXPATS:                                     **/
      /** If the pass type is '40'  AND                                      **/
      /**    the person is in pass group AC, AK, or MA  AND                  **/
      /**    the person's residency status code is 'EX' or 'TC',             **/
      /**    set nNrevRemnDyQty to '999'  and                                **/
      /**    set nFltAllotDyNbr to '999'.                                    **/
      /**                                                                    **/
      /**                                                                    **/
      /** Shridev Makim (7/20/98)                                            **/
      /** Pass type '70' and '80' are used for Above & Beyond and Friends    **/
      /** & Family certificates respectively. Do not create Remaining        **/
      /** allotments record or Deltamatic record for this pass type.         **/
      /**                                                                    **/
      /************************************************************************/
      if ((strcmp(A02645.A02645_appl_area.sPassTypCd, "40") == 0) && 
          ((strcmp(DTL_REC.sPassGrpCd, "AC") == 0) || (strcmp(DTL_REC.sPassGrpCd, "AK") == 0) ||
           (strcmp(DTL_REC.sPassGrpCd, "MA") == 0)) &&
           ((strcmp(DTL_REC.sResdSts, "EX") == 0) || (strcmp(DTL_REC.sResdSts, "TC") == 0))) 
         {
         R02443.R02443_appl_area.nNrevRemnDyQty = 999;
         R02443.R02443_appl_area.nFltAllotDyNbr = 999;
         } 
      else
         {
         R02443.R02443_appl_area.nNrevRemnDyQty = A02645.A02645_appl_area.nFltAllotDyNbr;
         R02443.R02443_appl_area.nFltAllotDyNbr = A02645.A02645_appl_area.nFltAllotDyNbr;
         }

      R02443.R02443_appl_area.lNrevRemnMiQty = 0;
      R02443.R02443_appl_area.lFltAllotMiQty = 0;
          
      R02443.R02443_appl_area.cPassAddlInd = A02645.A02645_appl_area.cPassAddlInd;
      strcpy(R02443.R02443_appl_area.sProcDt, UTL_ConvertDate(DTL_REC.sStrtDt, CNV_YYYYMMDD_TO_DB));
 
      if ((strcmp(R02443.R02443_appl_area.sPassTypCd, AB_PASS_TYPE) != 0) && 
          (strcmp(R02443.R02443_appl_area.sPassTypCd, FF_PASS_TYPE) != 0) && 
	  (strcmp(R02443.R02443_appl_area.sPassTypCd, REWARD_PASS_TYPE) != 0))
             TPM_7485_InsertNewRemnAllotRider();
 
      /************************************************************************************/
      /** Format and Write a record to the Deltamatic table for this ppr/nrev/pass type. **/
      /************************************************************************************/
      /****** Initialize request and answer blocks *****/
      memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA));
      memset(&A04325.A04325_appl_area, LOW_VALUES, sizeof(_A04325_APPL_AREA));
   
      /**** Format service request copybook ****/
      strcpy(R04325.R04325_appl_area.sPprNbr, DTL_REC.sPprNbr);
      strcpy(R04325.R04325_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
      strcpy(R04325.R04325_appl_area.sPassTypCd,  A02645.A02645_appl_area.sPassTypCd);
      R04325.R04325_appl_area.cEmplArRecInd = ADD_REC;

      if ((strcmp(R04325.R04325_appl_area.sPassTypCd, AB_PASS_TYPE) != 0) && 
          (strcmp(R04325.R04325_appl_area.sPassTypCd, FF_PASS_TYPE) != 0) && 
	  (strcmp(R02443.R02443_appl_area.sPassTypCd, REWARD_PASS_TYPE) != 0))
              TPM_7500_WriteDlmaticRecord();

      /**** get the next database row ****/
      R02645.R02645_appl_area.cArchCursorOpTxt = FETCH_ROW;

      nSvcRtnCd = BCH_InvokeService(EPBINQ5,&R02645,&A02645,SERVICE_ID_02645,1,sizeof(_R02645_APPL_AREA)); 

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;
 
         case ARC_ROW_NOT_FOUND:
            nEndOfPassType = TRUE;
            break;

         default:  
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02645");
            BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7400_CreateAllotRecordRider");
         }   
      
      }            

}




/******************************************************************
**                                                               **
** Function Name:   TPM_7440_ReadPriorRemnAllotRider             **
**                                                               **
** Description:     For an individual pass rider, reads the      **
**                  Prior Period Remaining Allotment Table       **
**                  for a specific pass type.                    **
**                  Executes service 02764.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7440_ReadPriorRemnAllotRider()
{
   short   nSvcRtnCd;   /* Service return code */

  
   /** Initialize request and answer blocks **/
   memset(&R02760.R02760_appl_area, LOW_VALUES, sizeof(_R02760_APPL_AREA));
   memset(&A02760.A02760_appl_area, LOW_VALUES, sizeof(_A02760_APPL_AREA));

   /** Format service request copybook **/
   strcpy(R02760.R02760_appl_area.sPprNbr, DTL_REC.sPprNbr);
   if (nResetAll == TRUE)
      strcpy(R02760.R02760_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   else
      strcpy(R02760.R02760_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(R02760.R02760_appl_area.sPassTypCd, pass_type[q].sPassTypCd);

   /************************************************************************/
   /** Execute service to read the Prior Period Remaining Allotment Table **/
   /** for an individual pass rider/pass type for a PPR.                  **/
   /************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD4,&R02760,&A02760,SERVICE_ID_02760,1,sizeof(_R02760_APPL_AREA));
 
   /** Service return code processing **/

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         nPriorRemnAllotInd = TRUE;
         break;

      case ARC_ROW_NOT_FOUND:
         nPriorRemnAllotInd = FALSE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02760");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7440_ReadPriorRemnAllotRider");
      }
  
}

/******************************************************************
**                                                               **
** Function Name:   TPM_7445_ReadRemnAllotRider                  **
**                                                               **
** Description:     For an individual pass rider, reads the      **
**                  Remaining Allotment Table for a specific     **
**                  pass type.                                   **
**                  Executes service 02441.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    TPM_7445_ReadRemnAllotRider()
{
   short   nSvcRtnCd;   /* Service return code */

 
   /****************************************************************************************/
   /** Execute service to read Remaining Allotment Table for the PprNbr/NrevNbr/PassTypCd **/
   /****************************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R02441,&A02441,SERVICE_ID_02441,1,sizeof(_R02441_APPL_AREA));
  
   /** Service return code processing **/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         nOldAllotInd = TRUE;
	 if (strncmp(R02441.R02441_appl_area.sPassTypCd,REWARD_PASS_TYPE,2) == 0)
/*****	 && (A02441.A02441_appl_area.nNrevRemnDyQty > 0) )  ***/
	   nRewardInd = TRUE;
         break;    
 
      case ARC_ROW_NOT_FOUND:
         nOldAllotInd = FALSE;
         break;    
 
      default:   
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02441");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7445_ReadRemnAllotRider");
         break;
      }
}

/******************************************************************
**                                                               **
** Function Name:   TPM_7447_ReadNewPassAllotRider               **
**                                                               **
** Description:     For an individual pass rider, reads the      **
**                  Pass Allotment Table with the NEW Pass Group.**
**                  Sets an Indicator.                           **
**                  Executes service 04000.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7447_ReadNewPassAllotRider()
{
   short   nSvcRtnCd;   /* Service return code */


   R04000.R04000_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /******************************************************/
   /** Execute service to read the Pass Allotment Table **/
   /******************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ4,&R04000,&A04000,SERVICE_ID_04000,1,sizeof(_R04000_APPL_AREA));
 
   /** Service return code processing **/
   switch (nSvcRtnCd)
      { 
      case ARC_SUCCESS:
         nNewAllotInd = TRUE;
         break;
 
      case ARC_ROW_NOT_FOUND:
         nNewAllotInd = FALSE;
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04000");
         BCH_FormatMessage(3,TXT_PSGR_TYPE,pass_type[q].sPassTypCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7447_ReadNewPassAllotRider");
         break;
      }
}



/******************************************************************
**                                                               **
** Function Name:   TPM_7450_DeletePriorRemnAllotRider           **
**                                                               **
** Description:     For an individual pass rider, deletes        **
**                  all records from the Prior Period Remaining  **
**                  Allotment Table for a specific pass type.    **
**                  Executes service 02764.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7450_DeletePriorRemnAllotRider()
{
   short   nSvcRtnCd;   /* Service return code */

  
   /** Initialize request and answer blocks **/
   memset(&R02764.R02764_appl_area, LOW_VALUES, sizeof(_R02764_APPL_AREA));

   /** Format service request copybook **/
   strcpy(R02764.R02764_appl_area.sPprNbr, DTL_REC.sPprNbr);

   if (nResetAll == TRUE)
      strcpy(R02764.R02764_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   else
      strcpy(R02764.R02764_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

   strcpy(R02764.R02764_appl_area.sPassTypCd, pass_type[q].sPassTypCd);
   strcpy(R02764.R02764_appl_area.sArchLastUpdtTs, A02760.A02760_appl_area.sArchLastUpdtTs);

   /***************************************************************************************/
   /** Execute service to delete records from the Prior Period Remaining Allotment Table **/
   /** For an individual pass rider for a PPR.                                           **/
   /***************************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD4,&R02764,&A02764,SERVICE_ID_02764,1,sizeof(_R02764_APPL_AREA));
 
   /** Service return code processing **/

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02764");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7450_DeletePriorRemnAllotRider");
      }
}



/******************************************************************
**                                                               **
** Function Name:   TPM_7455_InsertPriorRemnAllotRider           **
**                                                               **
** Description:     Copy all remaining allotment records to      **
**                  prior period remaining allotment table for   **
**                  an individual pass rider.                    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7455_InsertPriorRemnAllotRider()
{
   short   nSvcRtnCd;   /* Service return code */

  
   /************************************************************************************************/
   /** Execute primitive service to INSERT record into the Prior Period Remaining Allotment Table **/
   /************************************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD4,&R02762,&A02762,SERVICE_ID_02762,1,sizeof(_R02762_APPL_AREA));
 
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:  
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02762");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7455_InsertPriorRemnAllotRider");
      }

}

/******************************************************************
**                                                               **
** Function Name:   TPM_7457_UpdatePriorRemnAllotRider           **
**                                                               **
** Description:     Copy all remaining allotment records to      **
**                  prior period remaining allotment table for   **
**                  an individual pass rider.                    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7457_UpdatePriorRemnAllotRider()
{
   short   nSvcRtnCd;   /* Service return code */

 
   /************************************************************************************************/
   /** Execute primitive service to UPDATE record in the Prior Period Remaining Allotment Table   **/
   /************************************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD4,&R02763,&A02763,SERVICE_ID_02763,1,sizeof(_R02763_APPL_AREA));

   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;
 
      default:   
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02763");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7457_UpdatePriorRemnAllotRider");
      }  
 
}
 
 

/******************************************************************
**                                                               **
** Function Name:   TPM_7458_FormatUpdateRemnAllot               **
**                                                               **
** Description:     Format the request block for the insert of   **
**                  remaining allotments.  (2444)                **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7458_FormatUpdateRemnAllot()
{
   short   nSvcRtnCd;   /* Service return code */


   /****************************************************************************/
   /** If new pass allotments are found on the Pass Allotment Table, will     **/
   /** CALCULATE the NEW Remaining Allotments by subtracting the used days or **/
   /** miles from the new alloted days or miles.                              **/
   /** NOTE:  types '50' and '90' can be days or miles; all others are days   **/
   /** If Old allotments are present, must update the current record;         **/
   /** If New allotments are present, must insert a new record.               **/
   /****************************************************************************/
 
   /** Set up for Update of Remaining Allotments **/
   /****** Initialize request block for primitive update *****/
   memset(&R02444.R02444_appl_area, LOW_VALUES, sizeof(_R02444_APPL_AREA));

   /**** Format service request copybook  with PprId, NrevId, PassTypeCode****/
   strcpy(R02444.R02444_appl_area.sPprNbr, DTL_REC.sPprNbr);

   if (nResetAll == TRUE)
      strcpy(R02444.R02444_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);        
   else
      strcpy(R02444.R02444_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

   strcpy(R02444.R02444_appl_area.sPassTypCd, pass_type[q].sPassTypCd);

   /*********************************************************************************/
   /** Pass Types '50' and '90' can be days or miles, depending on the chosen type **/
   /** Calculate the remaining miles or days                                       **/
   /*********************************************************************************/
   if ((strcmp(pass_type[q].sPassTypCd, "50") == 0) || (strcmp(pass_type[q].sPassTypCd, "90") == 0))
      {
      if (A04309.A04309_appl_area.cNrevDyMiInd == 'M')
         {
         R02444.R02444_appl_area.lFltAllotMiQty = A04000.A04000_appl_area.lFltAllotMiQty;
         lNrevRemnMiQty = (A04000.A04000_appl_area.lFltAllotMiQty - lUsedAllotMi);
         if (lNrevRemnMiQty < 0)
            R02444.R02444_appl_area.lNrevRemnMiQty = (A04000.A04000_appl_area.lFltAllotMiQty - lUsedAllotMi);
         else
            R02444.R02444_appl_area.lNrevRemnMiQty = lNrevRemnMiQty;

         R02444.R02444_appl_area.nFltAllotDyNbr = 000;
         R02443.R02443_appl_area.nNrevRemnDyQty = 000;
         }
      else
         {
         R02444.R02444_appl_area.nFltAllotDyNbr = A04000.A04000_appl_area.nFltAllotDyNbr;
         nNrevRemnDyQty = (A04000.A04000_appl_area.nFltAllotDyNbr - nUsedAllotDy);
         if (nNrevRemnDyQty < 0)
            R02444.R02444_appl_area.nNrevRemnDyQty = 000;
         else
            R02444.R02444_appl_area.nNrevRemnDyQty = nNrevRemnDyQty;

         R02444.R02444_appl_area.lFltAllotMiQty = 0000000;
         R02444.R02444_appl_area.lNrevRemnMiQty = 0000000;
         }
      }
   else /* not pass type '50' or '90'   */
      {
      /************************************************************************/
      /** Special processing for EXPATS:                                     **/
      /** If the pass type is '40'  AND                                      **/
      /**    the PPR is in pass group AC, AK, or MA  AND                     **/ 
      /**    the PPR's residency status code is 'EX' or 'TC',                **/ 
      /**    set nNrevRemnDyQty to '999'  and                                **/
      /**    set nFltAllotDyNbr to '999'.                                    **/
      /************************************************************************/
      if ((strcmp(pass_type[q].sPassTypCd, "40") == 0) && 
          ((strcmp(A03834.A03834_appl_area.sPassGrpCd, "AC") == 0) || 
           (strcmp(A03834.A03834_appl_area.sPassGrpCd, "AK") == 0) || 
           (strcmp(A03834.A03834_appl_area.sPassGrpCd, "MA") == 0)) &&
           ((strcmp(A03834.A03834_appl_area.sPprRsdncyStsCd, "EX") == 0) || 
            (strcmp(A03834.A03834_appl_area.sPprRsdncyStsCd, "TC") == 0)))
         {
         R02444.R02444_appl_area.nNrevRemnDyQty = 999;
         R02444.R02444_appl_area.nFltAllotDyNbr = 999;
         }
      else
         {
         R02444.R02444_appl_area.nFltAllotDyNbr = A04000.A04000_appl_area.nFltAllotDyNbr;
         nNrevRemnDyQty = (A04000.A04000_appl_area.nFltAllotDyNbr - nUsedAllotDy);
         if (nNrevRemnDyQty < 0)
            R02444.R02444_appl_area.nNrevRemnDyQty = 000;
         else
            R02444.R02444_appl_area.nNrevRemnDyQty = nNrevRemnDyQty;
         }

      R02444.R02444_appl_area.lFltAllotMiQty = 0000000;
      R02444.R02444_appl_area.lNrevRemnMiQty = 0000000;
      }

   R02444.R02444_appl_area.cPassAddlInd = A04000.A04000_appl_area.cPassAddlInd;
   strcpy(R02444.R02444_appl_area.sProcDt, sCurrentTsDt);
   strcpy(R02444.R02444_appl_area.sArchLastUpdtTs, A02441.A02441_appl_area.sArchLastUpdtTs);

}


/******************************************************************
**                                                               **
** Function Name:   TPM_7459_UpdateRemnAllotRider                **
**                                                               **
** Description:     Delete individual record from the remaining  **
**                  allotment table for a pass rider.            **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    TPM_7459_UpdateRemnAllotRider()
{
   short   nSvcRtnCd;   /* Service return code */
 

   /******************************************************************************************/
   /** Execute service to update Remaining Allotment Table for the PprNbr/NrevNbr/PassTypCd **/
   /******************************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R02444,&A02444,SERVICE_ID_02444,1,sizeof(_R02444_APPL_AREA));
 
   /** Service return code processing **/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02444");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7459_UpdateRemnAllotRider");
         break;
      }  
}

/******************************************************************
**                                                               **
** Function Name:   TPM_7460_DeleteRemnAllotRider                **
**                                                               **
** Description:     Delete individual record from the remaining  **
**                  allotment table for a pass rider.            **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7460_DeleteRemnAllotRider()
{
   short   nSvcRtnCd;   /* Service return code */

  
 /*************************************************************************************/
 /** Read the Remaining Allotment Table for the NEW pass group, pass type, month svc **/
 /** to get the date/time stamp for the primitive update (delete).                   **/
 /*************************************************************************************/

   /** Initialize Service Request Block **/  
   memset(&R02441.R02441_appl_area, LOW_VALUES, sizeof(_R02441_APPL_AREA));

   /***************************************************************************/
   /** Format service request copybook with old pass group, nonrev number,   **/
   /** pass type code.                                                       **/
   /***************************************************************************/
   strcpy(R02441.R02441_appl_area.sPprNbr, DTL_REC.sPprNbr);
   if (nResetAll == TRUE)
      strcpy(R02441.R02441_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   else  
      strcpy(R02441.R02441_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(R02441.R02441_appl_area.sPassTypCd, pass_type[q].sPassTypCd);
 
   /****************************************************************************************/
   /** Execute service to read Remaining Allotment Table for the PprNbr/NrevNbr/PassTypCd **/
   /****************************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R02441,&A02441,SERVICE_ID_02441,1,sizeof(_R02441_APPL_AREA));
   
   /** Service return code processing **/
   switch (nSvcRtnCd)
      { 
      case ARC_SUCCESS:
         break;
  
      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02441");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7460_DeleteRemnAllotRider");
         break;
      }


   /** Initialize request and answer blocks **/
   memset(&R02445.R02445_appl_area, LOW_VALUES, sizeof(_R02445_APPL_AREA));

   /** Format service request copybook **/
   strcpy(R02445.R02445_appl_area.sPprNbr, DTL_REC.sPprNbr);
   if (nResetAll == TRUE)
      strcpy(R02445.R02445_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);        
   else
      strcpy(R02445.R02445_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(R02445.R02445_appl_area.sPassTypCd, pass_type[q].sPassTypCd);
   strcpy(R02445.R02445_appl_area.sArchLastUpdtTs, A02441.A02441_appl_area.sArchLastUpdtTs);

/*******************/
/* remove check for qty < 0 for REWARD_PASS_TYPE **/
/*******************/
/***************************************************************************************/
/******* Commented out the following         las 02/07/03  
   if ( (strncmp(pass_type[q].sPassTypCd, REWARD_PASS_TYPE, 2) == 0) && 
   ((cHireDtChgInd == 'Y') || 
   ((strncmp(DTL_REC.sStrtDt+4, RS.sTodayDt+4, 4) <= 0) && 
   (strncmp(RS.sTodayDt,"2003",4) >= 0))))
   {
******** Comented out the above code       las 02/07/03 ****/
/***************************************************************************************/
   /*******************************************************************************************/
   /** Execute service to delete rows from the Remaining Allotment Table for an INDIVIDUAL   **/
   /** PASS RIDER associated with a PPR.                                                     **/
   /*******************************************************************************************/
     nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R02445,&A02445,SERVICE_ID_02445,1,sizeof(_R02445_APPL_AREA));
/**** las 02/07/03 
   } else if (pass_type[q].sPassTypCd != REWARD_PASS_TYPE)
     nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R02445,&A02445,SERVICE_ID_02445,1,sizeof(_R02445_APPL_AREA));
**** las 02/07/03 ****/

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:  
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02445");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7460_DeleteRemnAllotRider");
      }
  
}





/******************************************************************
**                                                               **
** Function Name:   TPM_7470_StorePassTypeCodes                  **
**                                                               **
** Description:     Store DISTINCT Pass Type Codes from Pass     ** 
**                  Allotment Table in an array for use later.   **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7470_StorePassTypeCodes()
{
   short   nSvcRtnCd;   /* Service return code */
   nPassTypCnt = 0;
   q = 0;

/*****************************************************************************/
/** Read the Pass Allotment Table for the DISTINCT current valid pass       **/
/** type codes and store in an array.                                       **/
/** For each pass type code, do the following:                              **/
/** 1. Read the Remaining Allotment Table.  Calculate the allotments used   **/
/**    under the old pass group by subtracting the remaining days/miles     **/
/**    from the allotted days/miles to get the used days/miles.             **/
/**    If no record exists on the Remaining Allotment Table, the used       **/
/**    passes = 0.                                                          **/
/** 2. Read the Pass Allotment Table for the new Pass Group.                **/
/**    a. If no passes of the input pass type are allowed, delete the       **/
/**       remaining allotment record for that pass type, if it exists.      **/
/**    b. If passes are allowed, calculate the new Remaining Allotments by  **/
/**       subtracting the allotments already used from the new allowed      **/
/**       allotments.  Delete the remaining allotment record.  Insert the   **/
/**       new remaining allotment record.                                   **/
/*****************************************************************************/

   /*********************************************************************************/
   /** Open Cursor for ALL DISTINCT pass type codes from the Pass Allotment Table. **/
   /** save each pass type code in an array.                                       **/
   /*********************************************************************************/

   /** Initialize Service Request Block **/
   memset(&R04003.R04003_appl_area, LOW_VALUES, sizeof(_R04003_APPL_AREA));
   memset(&A04003.A04003_appl_area, LOW_VALUES, sizeof(_A04003_APPL_AREA));

   R04003.R04003_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /********************************************************************/
   /** execute service to get the first row of the DISTINCT cursor of **/
   /** pass type codes from the pass allotment table                  **/
   /********************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ3,&R04003,&A04003,SERVICE_ID_04003,1,sizeof(_R04003_APPL_AREA));

   /** Service return code processing **/
   switch (nSvcRtnCd)
      { 
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04003");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7470_StorePassTypeCodes");
         break;
      }

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {
      /***********************************/
      /** store pass type code in array **/
      /***********************************/
      strcpy(pass_type[nPassTypCnt].sPassTypCd, A04003.A04003_appl_area.sPassTypCd);
      nPassTypCnt++;

      /**** get the next database row ****/
      R04003.R04003_appl_area.cArchCursorOpTxt = FETCH_ROW;

      /*******************************************************************/
      /** Execute service to get the next row of the DISTINCT cursor of **/
      /** pass type codes from the Pass Allotment Table.                **/
      /*******************************************************************/
      nSvcRtnCd = BCH_InvokeService(EPBINQ3,&R04003,&A04003,SERVICE_ID_04003,1,sizeof(_R04003_APPL_AREA)); 

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;
 
         case ARC_ROW_NOT_FOUND:
            break;

         default:  
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04003");
            BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7470_StorePassTypeCodes");
         }
      }

}


/******************************************************************
**                                                               **
** Function Name:   TPM_7475_ReadPassTypeCodes                   **
**                                                               **
** Description:     Read pass type codes from array and use to   **
**                  drive process to make changes to nonrev      **
**                  records.                                     **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
** Shridev Makim: Do not process anything for pass type code     **
** of 70 or 80. These pass types are used for F&F and A&B        **
** certificates and employees do not have allotments for this    **
** certificates.                                                 **
**                                                               **
******************************************************************/
 
void    TPM_7475_ReadPassTypeCodes()
{
   short   nSvcRtnCd;   /* Service return code */
   nEndOfPassType   = FALSE;
   q = 0;
   nRewardInd = FALSE;
   nRemoveRewardInd = FALSE;

   while (q < nPassTypCnt)
      {
      if (strcmp(pass_type[q].sPassTypCd, AB_PASS_TYPE) != 0 &&
          strcmp(pass_type[q].sPassTypCd, FF_PASS_TYPE) != 0)
         TPM_7480_UpdateAllotments();
      q++;
      }

}




/******************************************************************
**                                                               **
** Function Name:   TPM_7480_UpdateAllotments                    **
**                                                               **
** Description:     Reset allotments to value for NEW pass       ** 
**                  group for a pass rider.                      **
**                                                               **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7480_UpdateAllotments()
{
   short   nSvcRtnCd;   /* Service return code */ 
   nOldAllotInd = FALSE;
   nNewAllotInd = FALSE;
   nPriorRemnAllotInd = FALSE;


   nUsedAllotDy = 000;
   lUsedAllotMi = 0000000;
   lNrevRemnMiQty = 0000000;
   nNrevRemnDyQty = 000;


   /** Check to see if Prior Remaining Allotments exist for this PprId, NrevId, PassType : **/
   /** Sets TRUE/FALSE indicator **/

   /****** Initialize request and answer blocks *****/
   memset(&R02760.R02760_appl_area, LOW_VALUES, sizeof(_R02760_APPL_AREA));
   memset(&A02760.A02760_appl_area, LOW_VALUES, sizeof(_A02760_APPL_AREA));
 
   /**** Format service request copybook ****/
   strcpy(R02760.R02760_appl_area.sPprNbr, DTL_REC.sPprNbr);
   if (nResetAll == TRUE)
      strcpy(R02760.R02760_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   else
      strcpy(R02760.R02760_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(R02760.R02760_appl_area.sPassTypCd, pass_type[q].sPassTypCd);

   TPM_7440_ReadPriorRemnAllotRider();

   /***************************************************************************/
   /** Read the Remaining Allotment Table in order to be able to calculate   **/
   /** allotments already used.  Sets TRUE/FALSE indicator                   **/
   /***************************************************************************/

   /** Initialize Service Request and Answer Blocks **/
   memset(&R02441.R02441_appl_area, LOW_VALUES, sizeof(_R02441_APPL_AREA));
   memset(&A02441.A02441_appl_area, LOW_VALUES, sizeof(_A02441_APPL_AREA));
 
   /** Format service request copybook with ppr nbr, nrev nbr, pass type code  **/
   strcpy(R02441.R02441_appl_area.sPprNbr, DTL_REC.sPprNbr);
 
   /********************************************************************************************/
   /** if resetting all, will be inside the 4309 cursor, so get the nonrev number from there. **/
   /** otherwise, get the nonrev number from the input record.                                **/
   /********************************************************************************************/
   if (nResetAll == TRUE)
      strcpy(R02441.R02441_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
   else
      strcpy(R02441.R02441_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

   strcpy(R02441.R02441_appl_area.sPassTypCd, pass_type[q].sPassTypCd);
 
   TPM_7445_ReadRemnAllotRider();
      
   /***************************************************************************************/
   /** If old allotments were found, Calculate used allotments for this ppr/nrev/passtyp:**/
   /** Subtract the days or miles remaining from the allotment for this pass type        **/
   /** to get the allotments ALREADY USED under the old pass group.                      **/
   /** NOTE:                                                                             **/
   /** If the pass type is '50', and the current days/miles indicator is 'M', calculate  **/
   /** on miles, otherwise, calculate on days.  All other types are calculated on days   **/
   /** (it doesn't matter if they are switching from miles to days, or vice versa)       **/
   /***************************************************************************************/

   if (nOldAllotInd == TRUE)
      {
      if ((strcmp(pass_type[q].sPassTypCd, DOMESTIC) == 0) || 
          (strcmp(pass_type[q].sPassTypCd, COMB_DOM_TO) == 0))
         {
         if (A04309.A04309_appl_area.cNrevDyMiInd == 'M')
            {
            lUsedAllotMi = (A02441.A02441_appl_area.lFltAllotMiQty - A02441.A02441_appl_area.lNrevRemnMiQty);
            nUsedAllotDy = 000;
            }
         else
            {
            nUsedAllotDy = (A02441.A02441_appl_area.nFltAllotDyNbr - A02441.A02441_appl_area.nNrevRemnDyQty);
            lUsedAllotMi = 0000000;
            }
         }
      else
         {
         nUsedAllotDy = (A02441.A02441_appl_area.nFltAllotDyNbr - A02441.A02441_appl_area.nNrevRemnDyQty);
         lUsedAllotMi = 0000000;
         }
      }


   /********************************************************************************/
   /** Read the Pass Allotment Table for the NEW pass group, pass type, month svc.**/
   /** Sets TRUE/FALSE indicator.                                                 **/
   /********************************************************************************/

   /** Initialize Service Request Block **/
   memset(&R04000.R04000_appl_area, LOW_VALUES, sizeof(_R04000_APPL_AREA));
   memset(&A04000.A04000_appl_area, LOW_VALUES, sizeof(_A04000_APPL_AREA));

   /*****************************************************************************/
   /** Format the request copybook with NEW pass group, current type code, and **/
   /** employee's months of service completed.                                 **/
   /*****************************************************************************/
   strcpy(R04000.R04000_appl_area.sPassTypCd, pass_type[q].sPassTypCd);

   /********************************************************************************/
   /** If resetting all, will be inside the 4309 cursor, so get the nonrev number **/
   /** from there, otherwise, get the nonrev number from the input record.        **/
   /**                                                                            **/
   /** If resetting all, get the new pass group code from the detail record;      **/
   /** otherwise, get it from the PPR record.                                     **/
   /********************************************************************************/
   if (nResetAll == TRUE)
      {
      strcpy(R04000.R04000_appl_area.sPassGrpCd, DTL_REC.sPassGrpCd);
      strcpy(R04000.R04000_appl_area.sNrevTypCd, A04309.A04309_appl_area.sNrevTypCd);        
      }
   else
      {
      strcpy(R04000.R04000_appl_area.sPassGrpCd, A03834.A03834_appl_area.sPassGrpCd);
      strcpy(R04000.R04000_appl_area.sNrevTypCd, DTL_REC.sPsgrTypeCd);
      }
 
   if (cHireDtChgInd ==  'Y')
   {
      R04000.R04000_appl_area.nFltMoSvcNbr = TPM_7005_CalculateMonthsSvc(DTL_REC.sStrtDt);
      if (strncmp(R02441.R02441_appl_area.sPassTypCd, REWARD_PASS_TYPE,2) != 0)
      {
        lUsedAllotMi=0000000;
        nUsedAllotDy=000;
      }
   }
   else
      R04000.R04000_appl_area.nFltMoSvcNbr = A03834.A03834_appl_area.nFltMoSvcNbr;

   TPM_7447_ReadNewPassAllotRider();

   /****************************************************************************/
   /** If new pass allotments are found on the Pass Allotment Table, will     **/
   /** CALCULATE the NEW Remaining Allotments by subtracting the used days or **/
   /** miles from the new alloted days or miles.                              **/
   /** NOTE:  types '50' and '90' can be days or miles; all others are days   **/
   /** If Old allotments are present, must update the current record;         **/
   /** If New allotments are present, must insert a new record.               **/
   /****************************************************************************/


   if ((nOldAllotInd == TRUE) && (nNewAllotInd == TRUE))
      {
      if (nPriorRemnAllotInd == TRUE)
         {
         /************************************************************************************/
         /* copy Remaining to Prior for this PprId, NrevId, PassType and UPDATE Prior (2763) */
         /************************************************************************************/

         /*** Initialize request and answer blocks ***/
         memset(&R02763.R02763_appl_area, LOW_VALUES, sizeof(_R02762_APPL_AREA));
 
         /*** Format service request copybook for primitive update ***/
         strcpy(R02763.R02763_appl_area.sPprNbr, DTL_REC.sPprNbr);
         if (nResetAll == TRUE)
            strcpy(R02763.R02763_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
         else
            strcpy(R02763.R02763_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

         strcpy(R02763.R02763_appl_area.sPassTypCd, pass_type[q].sPassTypCd);
         R02763.R02763_appl_area.nNrevRemnDyQty = A02441.A02441_appl_area.nNrevRemnDyQty;
         R02763.R02763_appl_area.lNrevRemnMiQty = A02441.A02441_appl_area.lNrevRemnMiQty;
         R02763.R02763_appl_area.cPassAddlInd = A02441.A02441_appl_area.cPassAddlInd;
         strcpy(R02763.R02763_appl_area.sArchLastUpdtTs, A02760.A02760_appl_area.sArchLastUpdtTs);
 
         TPM_7457_UpdatePriorRemnAllotRider();
         }
      else
         {
         /*****************************************************************************/
         /** Copy Remaining Allotments to Prior Period Remaining Allotment table for **/
         /** an individual pass rider/pass type code and INSERT into Prior. (2762)   **/
         /*****************************************************************************/
 
         /*** Initialize request and answer blocks ***/
         memset(&R02762.R02762_appl_area, LOW_VALUES, sizeof(_R02762_APPL_AREA));
 
         /** Format service request copybook for primitive insert **/
         strcpy(R02762.R02762_appl_area.sPprNbr, DTL_REC.sPprNbr);

         if (nResetAll == TRUE)
            strcpy(R02762.R02762_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
         else
            strcpy(R02762.R02762_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

         strcpy(R02762.R02762_appl_area.sPassTypCd, pass_type[q].sPassTypCd);
         R02762.R02762_appl_area.nNrevRemnDyQty = A02441.A02441_appl_area.nNrevRemnDyQty;
         R02762.R02762_appl_area.lNrevRemnMiQty = A02441.A02441_appl_area.lNrevRemnMiQty;
         R02762.R02762_appl_area.cPassAddlInd = A02441.A02441_appl_area.cPassAddlInd;
  
         TPM_7455_InsertPriorRemnAllotRider();
         }

      /***********************************************************************************/
      /** A Remaining Allotment record exists for this pass type, so will format that   **/
      /** record for update. (2444)                                                    **/
      /***********************************************************************************/
      if ((cPGpChgInd != 'Y') && 
         (strncmp(R02441.R02441_appl_area.sPassTypCd, REWARD_PASS_TYPE, 2) == 0))
      TPM_7458_FormatUpdateRemnAllot();

      /***********************************************************************************/
      /** After request block has been formatted, UPDATE the Remaining with NEW (2444)  **/
      /***********************************************************************************/
      if ((cPGpChgInd != 'Y') && 
         (strncmp(R02441.R02441_appl_area.sPassTypCd, REWARD_PASS_TYPE, 2) == 0))
      TPM_7459_UpdateRemnAllotRider();

      /***********************************************************************************/
      /** Format and write the Deltamatic Record - CHANGE                               **/
      /***********************************************************************************/

      /****** Initialize request and answer blocks *****/
      memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA));
      memset(&A04325.A04325_appl_area, LOW_VALUES, sizeof(_A04325_APPL_AREA));

      /**** Format service request copybook ****/
      strcpy(R04325.R04325_appl_area.sPprNbr, DTL_REC.sPprNbr);

      if (nResetAll == TRUE)
         strcpy(R04325.R04325_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
      else
         strcpy(R04325.R04325_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

      strcpy(R04325.R04325_appl_area.sPassTypCd,  pass_type[q].sPassTypCd);
      R04325.R04325_appl_area.cEmplArRecInd = CHANGE_REC;

      if ((strncmp(R02441.R02441_appl_area.sPassTypCd, REWARD_PASS_TYPE, 2) == 0) && 
         (strncmp(DTL_REC.sStrtDt+4, RS.sTodayDt+4, 4) <= 0) && 
          (strncmp(RS.sTodayDt,"2003",4) >= 0))
      {
        R04325.R04325_appl_area.cEmplArRecInd = DELETE_REC;
        /*************************************************************/
        /* delete remaining for this PprId, NrevId, PassType (02445) */
        /*************************************************************/
        TPM_7460_DeleteRemnAllotRider();
      }


      TPM_7500_WriteDlmaticRecord();
      }
   else
   if ((nOldAllotInd == TRUE) && (nNewAllotInd == FALSE))
      {
      if (nPriorRemnAllotInd == TRUE)
         {
         /************************************************************************************/
         /* copy Remaining to Prior for this PprId, NrevId, PassType and UPDATE Prior (2763) */
         /************************************************************************************/

         /*** Initialize request and answer blocks ***/
         memset(&R02763.R02763_appl_area, LOW_VALUES, sizeof(_R02762_APPL_AREA));

         /*** Format service request copybook for primitive update ***/
         strcpy(R02763.R02763_appl_area.sPprNbr, DTL_REC.sPprNbr);

         if (nResetAll == TRUE)
            strcpy(R02763.R02763_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
         else
            strcpy(R02763.R02763_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

         strcpy(R02763.R02763_appl_area.sPassTypCd, pass_type[q].sPassTypCd);
         R02763.R02763_appl_area.nNrevRemnDyQty = A02441.A02441_appl_area.nNrevRemnDyQty;
         R02763.R02763_appl_area.lNrevRemnMiQty = A02441.A02441_appl_area.lNrevRemnMiQty;
         R02763.R02763_appl_area.cPassAddlInd = A02441.A02441_appl_area.cPassAddlInd;
         strcpy(R02763.R02763_appl_area.sArchLastUpdtTs, A02760.A02760_appl_area.sArchLastUpdtTs);

         TPM_7457_UpdatePriorRemnAllotRider();
         }
      else
         {
         /*******************************************************************************/
         /*** Copy Remaining Allotments to Prior Period Remaining Allotment table for ***/
         /*** an individual pass rider/pass type code and INSERT into Prior.  (2762)  ***/
         /*******************************************************************************/
 
         /*** Initialize request and answer blocks ***/
         memset(&R02762.R02762_appl_area, LOW_VALUES, sizeof(_R02762_APPL_AREA));
 
         /*** Format service request copybook for primitive insert ***/
         strcpy(R02762.R02762_appl_area.sPprNbr, DTL_REC.sPprNbr);

         if (nResetAll == TRUE)
            strcpy(R02762.R02762_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);
         else
            strcpy(R02762.R02762_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

         strcpy(R02762.R02762_appl_area.sPassTypCd, pass_type[q].sPassTypCd);
         R02762.R02762_appl_area.nNrevRemnDyQty = A02441.A02441_appl_area.nNrevRemnDyQty; 
         R02762.R02762_appl_area.lNrevRemnMiQty = A02441.A02441_appl_area.lNrevRemnMiQty; 
         R02762.R02762_appl_area.cPassAddlInd = A02441.A02441_appl_area.cPassAddlInd; 
 
         TPM_7455_InsertPriorRemnAllotRider();
         }

      /*************************************************************/
      /* delete remaining for this PprId, NrevId, PassType (02445) */
      /*************************************************************/
      TPM_7460_DeleteRemnAllotRider();

      /***********************************************************************************/
      /** Format and write the Deltamatic Record - DELETE                               **/
      /***********************************************************************************/

      /****** Initialize request and answer blocks *****/ 
      memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA)); 
      memset(&A04325.A04325_appl_area, LOW_VALUES, sizeof(_A04325_APPL_AREA)); 
  
      /**** Format service request copybook ****/ 
      strcpy(R04325.R04325_appl_area.sPprNbr, DTL_REC.sPprNbr);

      if (nResetAll == TRUE)
         strcpy(R04325.R04325_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr); 
      else 
         strcpy(R04325.R04325_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
 
      strcpy(R04325.R04325_appl_area.sPassTypCd,  pass_type[q].sPassTypCd);
      R04325.R04325_appl_area.cEmplArRecInd = DELETE_REC;

      if ((strcmp(R04325.R04325_appl_area.sPassTypCd, AB_PASS_TYPE) != 0) && 
          (strcmp(R04325.R04325_appl_area.sPassTypCd, FF_PASS_TYPE) != 0))
        TPM_7500_WriteDlmaticRecord();
      }
   else
   if ((nOldAllotInd == FALSE) && (nNewAllotInd == TRUE))
      {
      if (nPriorRemnAllotInd == TRUE)
         {
         /******************************************************************************/
         /* delete prior remaining allotments for this PprId, NrevId, PassType (02764) */
         /******************************************************************************/
         TPM_7450_DeletePriorRemnAllotRider();
         }

      /***********************************************************************************/
      /* A Remaining Allotment record does not exist for this pass type, so will prepare */
      /* to insert a new record.  (2443)                                                 */
      /***********************************************************************************/
      TPM_7484_FormatInsertRemnAllot();
 
      if ((strcmp(R02443.R02443_appl_area.sPassTypCd, AB_PASS_TYPE) != 0) && 
          (strcmp(R02443.R02443_appl_area.sPassTypCd, FF_PASS_TYPE) != 0) && 
	  (strcmp(R02443.R02443_appl_area.sPassTypCd, REWARD_PASS_TYPE) != 0))
         TPM_7485_InsertNewRemnAllotRider();

      /***********************************************************************************/
      /** Format and write the Deltamatic Record - ADD                                  **/
      /** Do not insert records for pass type '70' or '80' since these types are used   **/
      /** by A&B and F&F certs.                                                         **/
      /***********************************************************************************/

      /****** Initialize request and answer blocks *****/
      memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA));
      memset(&A04325.A04325_appl_area, LOW_VALUES, sizeof(_A04325_APPL_AREA));

      /**** Format service request copybook ****/
      strcpy(R04325.R04325_appl_area.sPprNbr, DTL_REC.sPprNbr);

       if (nResetAll == TRUE)
         strcpy(R04325.R04325_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr); 
      else 
         strcpy(R04325.R04325_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);
 
      strcpy(R04325.R04325_appl_area.sPassTypCd,  pass_type[q].sPassTypCd);
      R04325.R04325_appl_area.cEmplArRecInd = ADD_REC;

      if ((strcmp(R04325.R04325_appl_area.sPassTypCd, AB_PASS_TYPE) != 0) && 
          (strcmp(R04325.R04325_appl_area.sPassTypCd, FF_PASS_TYPE) != 0) && 
	  (strcmp(R04325.R04325_appl_area.sPassTypCd, REWARD_PASS_TYPE) != 0))
        TPM_7500_WriteDlmaticRecord();
      }
   else
   if ((nOldAllotInd == FALSE) && (nNewAllotInd == FALSE))
      {  
      if (nPriorRemnAllotInd == TRUE)
         {
         /******************************************************************************/
         /* delete prior remaining allotments for this PprId, NrevId, PassType (02764) */
         /******************************************************************************/
         TPM_7450_DeletePriorRemnAllotRider();
         }
      } 


/************************************************************************************/
/** close the pass allotment table cursor so can start over for the next pass type **/
/************************************************************************************/
R04000.R04000_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
nSvcRtnCd = BCH_InvokeService(EPBINQ4,&R04000,&A04000,SERVICE_ID_04000,1,sizeof(_R04000_APPL_AREA));

}



/******************************************************************
**                                                               **
** Function Name:   TPM_7484_FormatInsertRemnAllot               **
**                                                               **
** Description:     Format the request block for the Insert of   **
**                  remaining allotments.  (2443)                **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7484_FormatInsertRemnAllot()
{
   short   nSvcRtnCd;   /* Service return code */


   /****************************************************************************/
   /** If new pass allotments are found on the Pass Allotment Table, will     **/
   /** CALCULATE the NEW Remaining Allotments by subtracting the used days or **/
   /** miles from the new alloted days or miles.                              **/
   /** NOTE:  types '50' and '90' can be days or miles; all others are days   **/
   /** If Old allotments are present, must update the current record;         **/
   /** If New allotments are present, must insert a new record.               **/
   /****************************************************************************/
 
   /****** Initialize request block for primitive insert *****/
   memset(&R02443.R02443_appl_area, LOW_VALUES, sizeof(_R02443_APPL_AREA));

   /**** Format service request copybook  with PprId, NrevId, PassTypeCode****/
   strcpy(R02443.R02443_appl_area.sPprNbr, DTL_REC.sPprNbr);

   if (nResetAll == TRUE)
      strcpy(R02443.R02443_appl_area.sNrevNbr, A04309.A04309_appl_area.sNrevNbr);        
   else
      strcpy(R02443.R02443_appl_area.sNrevNbr, DTL_REC.sDesNrevNbr);

   strcpy(R02443.R02443_appl_area.sPassTypCd, pass_type[q].sPassTypCd);

   /*********************************************************************************/
   /** Pass Types '50' and '90' can be days or miles. Depending on the chosen type,**/
   /** calculate the remaining miles or days.                                      **/
   /*********************************************************************************/
   if ((strcmp(pass_type[q].sPassTypCd, DOMESTIC) == 0) || 
       (strcmp(pass_type[q].sPassTypCd, COMB_DOM_TO) == 0))
      {
      if (A04309.A04309_appl_area.cNrevDyMiInd == 'M')
         {
         R02443.R02443_appl_area.lFltAllotMiQty = A04000.A04000_appl_area.lFltAllotMiQty;
         lNrevRemnMiQty = (A04000.A04000_appl_area.lFltAllotMiQty - lUsedAllotMi);
         if (lNrevRemnMiQty < 0)
            R02443.R02443_appl_area.lNrevRemnMiQty = (A04000.A04000_appl_area.lFltAllotMiQty - lUsedAllotMi);
         else
            R02443.R02443_appl_area.lNrevRemnMiQty = lNrevRemnMiQty;

         R02443.R02443_appl_area.nFltAllotDyNbr = 000;
         R02443.R02443_appl_area.nNrevRemnDyQty = 000;
         }
      else
         {
         R02443.R02443_appl_area.nFltAllotDyNbr = A04000.A04000_appl_area.nFltAllotDyNbr;
         nNrevRemnDyQty = (A04000.A04000_appl_area.nFltAllotDyNbr - nUsedAllotDy);
         if (nNrevRemnDyQty < 0)
            R02443.R02443_appl_area.nNrevRemnDyQty = 000;
         else
            R02443.R02443_appl_area.nNrevRemnDyQty = nNrevRemnDyQty;

         R02443.R02443_appl_area.lFltAllotMiQty = 0000000;
         R02443.R02443_appl_area.lNrevRemnMiQty = 0000000;
         }
      }
   else /* not pass type '50' or '90'   */
      {
      R02443.R02443_appl_area.nFltAllotDyNbr = A04000.A04000_appl_area.nFltAllotDyNbr;
      nNrevRemnDyQty = (A04000.A04000_appl_area.nFltAllotDyNbr - nUsedAllotDy);
      if (nNrevRemnDyQty < 0)
         R02443.R02443_appl_area.nNrevRemnDyQty = 000;
      else
         R02443.R02443_appl_area.nNrevRemnDyQty = nNrevRemnDyQty;

      R02443.R02443_appl_area.lFltAllotMiQty = 0000000;
      R02443.R02443_appl_area.lNrevRemnMiQty = 0000000;
      }

   R02443.R02443_appl_area.cPassAddlInd = A04000.A04000_appl_area.cPassAddlInd;
   strcpy(R02443.R02443_appl_area.sProcDt, sCurrentTsDt);

}



/******************************************************************
**                                                               **
** Function Name:   TPM_7485_InsertNewRemnAllotRider             **
**                                                               **
** Description:     Insert a record into the Remaining           ** 
**                  Allotment Table.                             **
**                                                               **
**                                                               **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7485_InsertNewRemnAllotRider()
{
   short   nSvcRtnCd;   /* Service return code */
   char    sErrorMessage[64];

   /*************************************************************************/
   /** Execute service to insert record into the Remaining Allotment table **/
   /*************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R02443,&A02443,SERVICE_ID_02443,1,sizeof(_R02443_APPL_AREA)); 

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:  
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02443");
         sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, PassTypCd = %s",
                                R02443.R02443_appl_area.sPprNbr,
                                R02443.R02443_appl_area.sNrevNbr,
                                R02443.R02443_appl_area.sPassTypCd);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7485_InsertNewRemnAllotRider");
      }   

}



/******************************************************************
**                                                               **
** Function Name:   TPM_7500_WriteDlmaticRecord                  **
**                                                               **
** Description:     Write a record to the Deltamatic table.      **
**                                                               **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    TPM_7500_WriteDlmaticRecord()
{
   short   nSvcRtnCd;   /* Service return code */
   short   nSvcRtnCd1;   /* Service return code */
 

   if (((nRewardInd == TRUE) && (strncmp(R04325.R04325_appl_area.sPassTypCd, HONOR_ROLL, 2) == 0)) || (nRemoveRewardInd == TRUE))
   {
     if (nRemoveRewardInd == TRUE)
       nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R04325,&A04325,SERVICE_ID_04325,1,sizeof(_R04325_APPL_AREA));
     else
       nSvcRtnCd = ARC_SUCCESS;
   } else {
     if ((strncmp(R04325.R04325_appl_area.sPassTypCd, REWARD_PASS_TYPE, 2) == 0) && (R04325.R04325_appl_area.cEmplArRecInd == 'D'))
       nRemoveRewardInd = TRUE;
     /*************************************************************************/
     /** Execute service to insert record into the Deltamatic table          **/
     /*************************************************************************/
     nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R04325,&A04325,SERVICE_ID_04325,1,sizeof(_R04325_APPL_AREA));
   }


   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;

      case ARC_DUPLICATE_ROW:
         strcpy(R04323.R04323_appl_area.sPprNbr, R04325.R04325_appl_area.sPprNbr);
         strcpy(R04323.R04323_appl_area.sNrevNbr, R04325.R04325_appl_area.sNrevNbr);
         strcpy(R04323.R04323_appl_area.sPassTypCd, R04325.R04325_appl_area.sPassTypCd);
         R04323.R04323_appl_area.cEmplArRecInd = R04325.R04325_appl_area.cEmplArRecInd;

         TPM_7505_ReadDlmaticRecord();

         strcpy(R04326.R04326_appl_area.sPprNbr, R04325.R04325_appl_area.sPprNbr);
         strcpy(R04326.R04326_appl_area.sNrevNbr, R04325.R04325_appl_area.sNrevNbr);
         strcpy(R04326.R04326_appl_area.sPassTypCd, R04325.R04325_appl_area.sPassTypCd);
         R04326.R04326_appl_area.cEmplArRecInd = R04325.R04325_appl_area.cEmplArRecInd;
         strcpy(R04326.R04326_appl_area.sArchLastUpdtTs, A04323.A04323_appl_area.sArchLastUpdtTs);

         /*************************************************************************/
         /** Execute service to update a record on the Deltamatic table          **/
         /*************************************************************************/
         nSvcRtnCd1 = BCH_InvokeService(EPBUPD2,&R04326,&A04326,SERVICE_ID_04326,1,sizeof(_R04326_APPL_AREA));

         if (nSvcRtnCd1 != ARC_SUCCESS)
            {
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS04326");
            BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7500_WriteDlmaticRecord");
            }
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04325");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7500_WriteDlmaticRecord");
      }  

}


/******************************************************************
**                                                               **
** Function Name:   TPM_7505_ReadDlmaticRecord                   **
**                                                               **
** Description:     Read a record on the Deltamatic table.       **
**                                                               **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7505_ReadDlmaticRecord()
{
   short   nSvcRtnCd;   /* Service return code */
   short   nSvcRtnCd1;   /* Service return code */



   /*************************************************************************/
   /** Execute service to read record on the Deltamatic table              **/
   /*************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R04323,&A04323,SERVICE_ID_04323,1,sizeof(_R04323_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04323");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7505_ReadDlmaticRecord");
      }  

}



/******************************************************************
**                                                               **
** Function Name:   TPM_7520_FormatDlmaticRec                    **
**                                                               **
S **                  remaining allotment cursor.                  **
**                                                               **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    TPM_7520_FormatDlmaticRec()
{
   short   nSvcRtnCd;   /* Service return code */
   short   nSvcRtnCd1;   /* Service return code */
 
 
   /**************************************************************/
   /** Format and Write Deltamatic record.                      **/
   /**************************************************************/

   /**************************************************************************************/
   /** Read remaining allotment table for all allotments for this pass rider.           **/
   /**************************************************************************************/
 
   /****** Initialize request and answer blocks *****/
   memset(&R02865.R02865_appl_area, LOW_VALUES, sizeof(_R02865_APPL_AREA));
   memset(&A02865.A02865_appl_area, LOW_VALUES, sizeof(_A02865_APPL_AREA));

   /**** Format service request copybook ****/
   strcpy(R02865.R02865_appl_area.sPprNbr, sPprNbr);
   strcpy(R02865.R02865_appl_area.sNrevNbr, sNrevNbr);
 
   /*****************************************************************/
   /** Open the initial DB cursor on the Remaining Allotment Table **/
   /*****************************************************************/
   R02865.R02865_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
                         
   /**************************************************************************************/
   /** Execute service to select records from the Remaining Allotment table based on    **/
   /** ppr number and nrev number.                                                      **/
   /**************************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02865,&A02865,SERVICE_ID_02865,1,sizeof(_R02865_APPL_AREA));
 
   /** Service return code processing **/
   switch (nSvcRtnCd)
      {    
      case ARC_SUCCESS:
         break;   

      case ARC_ROW_NOT_FOUND:
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02865");
         BCH_FormatMessage(3,TXT_PPR,sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7520_FormatDlmaticRec");
      } 

   /*****************************************************************/
   /** Process remaining allotment DB rows.                        **/
   /** For each pass type, write a record to the Deltamatic table. **/
   /*****************************************************************/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {
      /**** Format service request copybook ****/ 
      strcpy(R04325.R04325_appl_area.sPprNbr, sPprNbr);
      strcpy(R04325.R04325_appl_area.sNrevNbr, sNrevNbr);
      strcpy(R04325.R04325_appl_area.sPassTypCd,  A02865.A02865_appl_area.sPassTypCd);
      /* R04325.R04325_appl_area.cEmplArRecInd  was formatted right before 7520 was called */

      if (strncmp(A02865.A02865_appl_area.sPassTypCd, REWARD_PASS_TYPE,2) == 0)
  /***    && (A02865.A02865_appl_area.nNrevRemnDyQty > 0))  **/
	  nRewardInd = TRUE;
  /*******
      if ((strncmp(A02865.A02865_appl_area.sPassTypCd, REWARD_PASS_TYPE,2) == 0) && (A02865.A02865_appl_area.nNrevRemnDyQty <= 0))
	R04325.R04325_appl_area.cEmplArRecInd = 'D';

 ******/

      TPM_7500_WriteDlmaticRecord();

      /**** get the next database row from the remaining allotment table ****/
      R02865.R02865_appl_area.cArchCursorOpTxt = FETCH_ROW;

      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02865,&A02865,SERVICE_ID_02865,1,sizeof(_R02865_APPL_AREA));

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02865");
            BCH_FormatMessage(3,TXT_PPR,sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7520_FormatDlmaticRec");
         }
      }

}

/******************************************************************
**                                                               **
** Function Name:   TPM_7530_CreateFAndFCertRecord               **
**                                                               **
** Description:     Create Friends and Family certificate records**
**                  for newly added ppr. (Shridev Makim)         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 


void    TPM_7530_CreateFAndFCertRecord()
{
   short   nSvcRtnCd;   /* Service return code */
   short   nSvcRtnCd1;   /* Service return code */
   short   i;
   short   nCertExtnNbr;
   char    sCurrntYr[5];
   char    sPrevYr[5];
   char    sAnivDt[27];
   char    sMonDay[5];
   short   nDayDiff;
   short   nDays;
 
 
 
   /****** Initialize request and answer blocks *****/
   memset(&R04586.R04586_appl_area, LOW_VALUES, sizeof(_R04586_APPL_AREA));
   memset(&A04586.A04586_appl_area, LOW_VALUES, sizeof(_A04586_APPL_AREA));
 
   nCertExtnNbr = BEGIN_FF_EXTN_NBR;

   memset(&sCurrntYr, LOW_VALUES, sizeof(sCurrntYr));
   memset(&sAnivDt, LOW_VALUES, sizeof(sAnivDt));
   strncpy(sCurrntYr, sCurrentTsDt, 4);
   strcpy(sAnivDt, sCurrntYr);

  /*** Added a check for 2/29 start date, if current date is 2/29 use that date, ***/
  //** otherwise use 3/1 for certificate issue date                              ***/
  //** L.Scott 2-10-2010                                                         ***/

   strncpy(sMonDay, DTL_REC.sStrtDt+4, 4); 

   if (strncmp(sMonDay,"0229", 4) ==0)
       strcat(sAnivDt, "0301");
     else
   strcat(sAnivDt, DTL_REC.sStrtDt+4); 

   nDays = (atoi(DTL_REC.sStrtDt) - atol(UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD))); 
   
   if ((R02383.R02383_appl_area.nFltMoSvcNbr >= 12) ||
      (strncmp(DTL_REC.sStrtDt,"20090630", 8) <= 0))

   {

     for (i = 0; i < nCertftQty; i++)
     {

 /*******************************************************************************/
 /** Initialize Service Request and Answer Blocks to see if anniversary date   **/
 /** for current year has already been passed.                                 **/
 /*******************************************************************************/
     memset(&R04654, LOW_VALUES, sizeof(_R04654));
     memset(&A04654, LOW_VALUES, sizeof(_A04654));
     /** Format application area of request block **/
     strcpy(R04654.R04654_appl_area.sPprStrtDt, sAnivDt); 
    /**strcpy(R04654.R04654_appl_area.sPprStrtDt, UTL_ConvertDate(DTL_REC.sStrtDt, CNV_YYYYMMDD_TO_DB));**/
    /*******************************************************************/
    /** Call service to determine day diffrence between anniversary   **/
    /** date of current year and todays date. If the day difference   **/
    /** is greater than -30, that means the anniversary date has      **/
    /** already been passed or it coming within next 30 days and we   **/
    /** want to issue them certificates for current year.             **/
    /*******************************************************************/
     nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R04654,&A04654,SERVICE_ID_04654,1,sizeof(_R04654_APPL_AREA));
     /** Service return code processing **/
     switch (nSvcRtnCd)
     { 
     case ARC_SUCCESS:
     nDayDiff = A04654.A04654_appl_area.nFltMoSvcNbr;
     break
     ;
     case ARC_ROW_NOT_FOUND:
     break
     ;
     default:
     BCH_FormatMessage(1,TXT_SVC_UNSUCC);
     BCH_FormatMessage(2,TXT_SVC,"FYS04654");
     BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
     BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7530_CreateFAndFCertRecord");
     break;
     }

     if (nDayDiff >= 0)                 
	 strcpy(R04586.R04586_appl_area.sCertftIssDt, sAnivDt); 
	 else  
	 { 
	 strncpy(sCurrntYr, sCurrentTsDt, 4);
	 sprintf(sPrevYr, "%4d", atoi(sCurrntYr));
	 sprintf(sPrevYr, "%4d", atoi(sCurrntYr) - 1);
	 strcpy(R04586.R04586_appl_area.sCertftIssDt, sPrevYr);               
	 strcat(R04586.R04586_appl_area.sCertftIssDt, sAnivDt+4); 
	 } 


      /**** Format service request copybook ****/
      strcpy(R04586.R04586_appl_area.sPprNbr, DTL_REC.sPprNbr);
      sprintf(R04586.R04586_appl_area.sCertftExtnNbr, "%2d", nCertExtnNbr);
      strcpy(R04586.R04586_appl_area.sPassDtTmTs, sCurrentTsDt);
      strcpy(R04586.R04586_appl_area.sFltCertftNbr, "");
      R04586.R04586_appl_area.cCertftTypCd = F_and_F_IND;
   /* strncpy(sCurrntYr, sCurrentTsDt, 4);       **/
   /* sprintf(sPrevYr, "%4d", atoi(sCurrntYr));  **/
   /* strcpy(R04586.R04586_appl_area.sCertftIssDt, sPrevYr);   **/                
   /* strcat(R04586.R04586_appl_area.sCertftIssDt, DTL_REC.sStrtDt+4);  **/
      strcpy(R04586.R04586_appl_area.sProcDt, LOW_DATE);
      strcpy(R04586.R04586_appl_area.sCertftExpDt, LOW_DATE);
      R04586.R04586_appl_area.cBlklstResnCd = ' ';
      strcpy(R04586.R04586_appl_area.sBlklstProcDt, LOW_DATE);
      strcpy(R04586.R04586_appl_area.sSvcChrgCd, NO_CHARGE);
      strncpy(R04586.R04586_appl_area.sCertftIssYr, R04586.R04586_appl_area.sCertftIssDt, 4);
      R04586.R04586_appl_area.cCertftUseInd = 'N';
      R04586.R04586_appl_area.cFltCrtfSttCd = 'U';
 
      /**********************************************************************/
      /** Call primitive service to insert a row into the flt_certft table **/
      /**********************************************************************/
      nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04586,&A04586,SERVICE_ID_04586,1,sizeof(_R04586_APPL_AREA));
 
      /** Service Return Code Processing **/
 
      switch (nSvcRtnCd)
      {
          case ARC_SUCCESS:
            break;

          
          default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS04586");
            BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7530_CreateFAndFCertRecord");
            break; 
      }  
 
      nCertExtnNbr++;
     }
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_7535_BlklstCertRecord                    **
**                                                               **
** Description:     Blacklist Friends & Family and Above & Beyond**
**                  certificates for the selected ppr.           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    TPM_7535_BlklstCertRecord()
{
   short   nSvcRtnCd;   /* Service return code */
   short   nSvcRtnCd1;   /* Service return code */
 
 
 
   /****** Initialize request and answer blocks *****/
   memset(&R04604.R04604_appl_area, LOW_VALUES, sizeof(_R04604_APPL_AREA));
   memset(&A04604, LOW_VALUES, sizeof(_A04604));
 
   /**** Format service request copybook ****/
   strcpy(R04604.R04604_appl_area.sPprNbr, DTL_REC.sPprNbr);
   R04604.R04604_appl_area.cBlklstResnCd = TERMINATE_BLKLST_CD;
 
   /****************************************************************************/
   /** Call advance service to blacklist all of the certificates for the ppr. **/
   /****************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04604,&A04604,SERVICE_ID_04604,1,sizeof(_R04604_APPL_AREA));
 
   /** Service Return Code Processing **/

   switch (nSvcRtnCd)
     {
      case ARC_SUCCESS:
         break;
       
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04604");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7535_BlklstCertRecord");
         break; 

     }  
}


/******************************************************************
**                                                               **
** Function Name:   TPM_7540_CheckElligibilityForCerts           **
**                                                               **
** Description:     Blacklist Friends & Family and Above & Beyond**
**                  certificates for the selected ppr.           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    TPM_7540_CheckElligibilityForCerts()
{
   short   nSvcRtnCd;   /* Service return code */
   short   nSvcRtnCd1;   /* Service return code */
 
 

   /************************************************************************************/
   /** Shridev Makim (7/20/1998)                                                      **/
   /** Check the t_pass_allot table to see if the ppr is eligible for friends &       **/
   /** family and Above & Beyond certificate based on their pass group.               **/
   /************************************************************************************/

   /************************************************************************************/
   /** Initialize Service Request and Answer Blocks to select from Pass Allot table.  **/
   /************************************************************************************/
   memset(&R04603, LOW_VALUES, sizeof(_R04603));
   memset(&A04603, LOW_VALUES, sizeof(_A04603));

   /** Format application area of request block **/
   strcpy(R04603.R04603_appl_area.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(R04603.R04603_appl_area.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(R04603.R04603_appl_area.sPassTypCd, FF_PASS_TYPE);

   /*******************************************************************/
   /** Call service to select row from the Pass Allot table to check **/
   /** if the ppr is eligible for Friends & Family certificate.      **/
   /*******************************************************************/
 
   nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R04603,&A04603,SERVICE_ID_04603,1,sizeof(_R04603_APPL_AREA));

   /** Service return code processing **/
   switch (nSvcRtnCd)
      { 
      case ARC_SUCCESS:
         nPprFFElligible  = TRUE;
         nCertftQty = A04603.A04603_appl_area.nFltAllotDyNbr;
         break;

      case ARC_ROW_NOT_FOUND:
         nPprFFElligible  = FALSE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04603");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7540_CheckElligibilityForCerts");
         break;
      }


   /************************************************************************************/
   /** Initialize Service Request and Answer Blocks to select from Pass Allot table.  **/
   /************************************************************************************/
   memset(&R04603, LOW_VALUES, sizeof(_R04603));
   memset(&A04603, LOW_VALUES, sizeof(_A04603));

   /** Format application area of request block **/
   strcpy(R04603.R04603_appl_area.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(R04603.R04603_appl_area.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(R04603.R04603_appl_area.sPassTypCd, AB_PASS_TYPE);

   /*******************************************************************/
   /** Call service to select row from the Pass Allot table to check **/
   /** if the ppr is eligible for Above & Beyond certificate.        **/
   /*******************************************************************/
 
   nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R04603,&A04603,SERVICE_ID_04603,1,sizeof(_R04603_APPL_AREA));

   /** Service return code processing **/
   switch (nSvcRtnCd)
      { 
      case ARC_SUCCESS:
         nPprABElligible  = TRUE;
         break;

      case ARC_ROW_NOT_FOUND:
         nPprABElligible  = FALSE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04603");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7540_CheckElligibilityForCerts");
         break;
      }
}



/******************************************************************
**                                                               **
** Function Name:   TPM_7611_GenerateEPB50011                    **
**                                                               **
** Description:     Write DL Error Report record.                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7611_GenerateEPB50011()
{
   short nRptIndex;      /* Index into the report control table */


   /** Initialize report sort and data copybooks     **/

   memset(&EPRF5011.F5011_RptDataStruct, LOW_VALUES, sizeof(_F5011_RPTDATASTRUCT));
   memset(&EPRS5011.S5011_RptDataStruct, LOW_VALUES, sizeof(_S5011_RPTDATASTRUCT));

   /*****************************************************************/
   /** Initialize an Format report fields in data and sort layouts **/
   /*****************************************************************/

   EPRF5011.F5011_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5011.F5011_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5011.F5011_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5011.F5011_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5011.F5011_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5011.F5011_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5011.F5011_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5011.F5011_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5011.F5011_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5011.F5011_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5011.F5011_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5011.F5011_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5011.F5011_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5011.F5011_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5011.S5011_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5011.S5011_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5011.S5011_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /*****************************************************************/
   /** Scan report requests for a match with EPB50011              **/
   /*****************************************************************/
   BCH_WriteRptRec("EPB50011", &EPRS5011, sizeof(EPRS5011), &EPRF5011, sizeof(EPRF5011));
}


/******************************************************************
**                                                               **
** Function Name:   TPM_7612_GenerateEPB50012                    **
**                                                               **
** Description:     Write TQ Error Report record.                ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7612_GenerateEPB50012()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5012.F5012_RptDataStruct, LOW_VALUES, sizeof(_F5012_RPTDATASTRUCT));
   memset(&EPRS5012.S5012_RptDataStruct, LOW_VALUES, sizeof(_S5012_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5012.F5012_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5012.F5012_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5012.F5012_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5012.F5012_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5012.F5012_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5012.F5012_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5012.F5012_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5012.F5012_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5012.F5012_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5012.F5012_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5012.F5012_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5012.F5012_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5012.F5012_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5012.F5012_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5012.S5012_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5012.S5012_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5012.S5012_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50012     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50012", &EPRS5012, sizeof(EPRS5012), &EPRF5012, sizeof(EPRF5012));
}        



/******************************************************************
**                                                               **
** Function Name:   TPM_7613_GenerateEPB50013                    **
**                                                               **
** Description:     Write WS Error Report record.                ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7613_GenerateEPB50013()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5013.F5013_RptDataStruct, LOW_VALUES, sizeof(_F5013_RPTDATASTRUCT));
   memset(&EPRS5013.S5013_RptDataStruct, LOW_VALUES, sizeof(_S5013_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/

   EPRF5013.F5013_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5013.F5013_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5013.F5013_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5013.F5013_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5013.F5013_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5013.F5013_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5013.F5013_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5013.F5013_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5013.F5013_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5013.F5013_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5013.F5013_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5013.F5013_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5013.F5013_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5013.F5013_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;
 
   EPRS5013.S5013_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5013.S5013_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5013.S5013_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/
   /** Scan report requests for a match with EPB50013     **/ 
   /********************************************************/
   BCH_WriteRptRec("EPB50013", &EPRS5013, sizeof(EPRS5013), &EPRF5013, sizeof(EPRF5013));
}        



/******************************************************************
**                                                               **
** Function Name:   TPM_7614_GenerateEPB50014                    **
**                                                               **
** Description:     Write DSS Error Report record.               ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7614_GenerateEPB50014()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5014.F5014_RptDataStruct, LOW_VALUES, sizeof(_F5014_RPTDATASTRUCT));
   memset(&EPRS5014.S5014_RptDataStruct, LOW_VALUES, sizeof(_S5014_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5014.F5014_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5014.F5014_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5014.F5014_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5014.F5014_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5014.F5014_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5014.F5014_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5014.F5014_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5014.F5014_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5014.F5014_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5014.F5014_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5014.F5014_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5014.F5014_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5014.F5014_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5014.F5014_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5014.S5014_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5014.S5014_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5014.S5014_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50014     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50014", &EPRS5014, sizeof(EPRS5014), &EPRF5014, sizeof(EPRF5014));
}        



/******************************************************************
**                                                               **
** Function Name:   TPM_7615_GenerateEPB50015                    **
**                                                               **
** Description:     Write ASA Error Report record.               ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7615_GenerateEPB50015()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5015.F5015_RptDataStruct, LOW_VALUES, sizeof(_F5015_RPTDATASTRUCT));
   memset(&EPRS5015.S5015_RptDataStruct, LOW_VALUES, sizeof(_S5015_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5015.F5015_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5015.F5015_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5015.F5015_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5015.F5015_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5015.F5015_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5015.F5015_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5015.F5015_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5015.F5015_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5015.F5015_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5015.F5015_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5015.F5015_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5015.F5015_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5015.F5015_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5015.F5015_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5015.S5015_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5015.S5015_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5015.S5015_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50015     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50015", &EPRS5015, sizeof(EPRS5015), &EPRF5015, sizeof(EPRF5015));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7616_GenerateEPB50016                    **
**                                                               **
** Description:     Write COMAIR Error Report record.            ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7616_GenerateEPB50016()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5016.F5016_RptDataStruct, LOW_VALUES, sizeof(_F5016_RPTDATASTRUCT));
   memset(&EPRS5016.S5016_RptDataStruct, LOW_VALUES, sizeof(_S5016_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5016.F5016_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5016.F5016_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5016.F5016_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5016.F5016_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5016.F5016_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5016.F5016_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5016.F5016_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5016.F5016_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5016.F5016_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5016.F5016_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5016.F5016_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5016.F5016_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5016.F5016_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5016.F5016_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5016.S5016_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5016.S5016_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5016.S5016_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50016     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50016", &EPRS5016, sizeof(EPRS5016), &EPRF5016, sizeof(EPRF5016));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7617_GenerateEPB50017                    **
**                                                               **
** Description:     Write AirWisconsin Error Report record       ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7617_GenerateEPB50017()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5017.F5017_RptDataStruct, LOW_VALUES, sizeof(_F5017_RPTDATASTRUCT));
   memset(&EPRS5017.S5017_RptDataStruct, LOW_VALUES, sizeof(_S5017_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5017.F5017_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5017.F5017_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5017.F5017_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5017.F5017_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5017.F5017_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5017.F5017_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5017.F5017_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5017.F5017_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5017.F5017_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5017.F5017_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5017.F5017_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5017.F5017_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5017.F5017_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5017.F5017_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5017.S5017_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5017.S5017_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5017.S5017_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50017     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50017", &EPRS5017, sizeof(EPRS5017), &EPRF5017, sizeof(EPRF5017));
}        

/******************************************************************
**                                                               **
** Function Name:   TPM_7618_GenerateEPB50018                    **
**                                                               **
** Description:     Write Comair Academy Error Report record.    ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7618_GenerateEPB50018()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5018.F5018_RptDataStruct, LOW_VALUES, sizeof(_F5018_RPTDATASTRUCT));
   memset(&EPRS5018.S5018_RptDataStruct, LOW_VALUES, sizeof(_S5018_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5018.F5018_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5018.F5018_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5018.F5018_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5018.F5018_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5018.F5018_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5018.F5018_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5018.F5018_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5018.F5018_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5018.F5018_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5018.F5018_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5018.F5018_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5018.F5018_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5018.F5018_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5018.F5018_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5018.S5018_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5018.S5018_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5018.S5018_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50018     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50018", &EPRS5018, sizeof(EPRS5018), &EPRF5018, sizeof(EPRF5018));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7619_GenerateEPB50019                    **
**                                                               **
** Description:     Write SkyWest Error Report record.           ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7619_GenerateEPB50019()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5019.F5019_RptDataStruct, LOW_VALUES, sizeof(_F5019_RPTDATASTRUCT));
   memset(&EPRS5019.S5019_RptDataStruct, LOW_VALUES, sizeof(_S5019_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5019.F5019_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5019.F5019_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5019.F5019_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5019.F5019_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5019.F5019_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5019.F5019_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5019.F5019_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5019.F5019_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5019.F5019_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5019.F5019_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5019.F5019_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5019.F5019_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5019.F5019_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5019.F5019_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5019.S5019_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5019.S5019_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5019.S5019_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50019     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50019", &EPRS5019, sizeof(EPRS5019), &EPRF5019, sizeof(EPRF5019));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7620_GenerateEPB50020                    **
**                                                               **
** Description:     Write ACA Error Report record.               ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7620_GenerateEPB50020()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5020.F5020_RptDataStruct, LOW_VALUES, sizeof(_F5020_RPTDATASTRUCT));
   memset(&EPRS5020.S5020_RptDataStruct, LOW_VALUES, sizeof(_S5020_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5020.F5020_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5020.F5020_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5020.F5020_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5020.F5020_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5020.F5020_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5020.F5020_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5020.F5020_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5020.F5020_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5020.F5020_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5020.F5020_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5020.F5020_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5020.F5020_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5020.F5020_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5020.F5020_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5020.S5020_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5020.S5020_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5020.S5020_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50020     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50020", &EPRS5020, sizeof(EPRS5020), &EPRF5020, sizeof(EPRF5020));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7621_GenerateEPB50021                    **
**                                                               **
** Description:     Write Chautaugua Error Report record.        ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7621_GenerateEPB50021()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5021.F5021_RptDataStruct, LOW_VALUES, sizeof(_F5021_RPTDATASTRUCT));
   memset(&EPRS5021.S5021_RptDataStruct, LOW_VALUES, sizeof(_S5021_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5021.F5021_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5021.F5021_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5021.F5021_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5021.F5021_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5021.F5021_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5021.F5021_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5021.F5021_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5021.F5021_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5021.F5021_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5021.F5021_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5021.F5021_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5021.F5021_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5021.F5021_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5021.F5021_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5021.S5021_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5021.S5021_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5021.S5021_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50021     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50021", &EPRS5021, sizeof(EPRS5021), &EPRF5021, sizeof(EPRF5021));
}        

/******************************************************************
**                                                               **
** Function Name:   TPM_7622_GenerateEPB50022                    **
**                                                               **
** Description:     Write Shuttle America Error Report record.   ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7622_GenerateEPB50022()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5022.F5022_RptDataStruct, LOW_VALUES, sizeof(_F5022_RPTDATASTRUCT));
   memset(&EPRS5022.S5022_RptDataStruct, LOW_VALUES, sizeof(_S5022_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5022.F5022_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5022.F5022_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5022.F5022_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5022.F5022_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5022.F5022_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5022.F5022_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5022.F5022_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5022.F5022_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5022.F5022_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5022.F5022_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5022.F5022_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5022.F5022_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5022.F5022_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5022.F5022_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5022.S5022_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5022.S5022_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5022.S5022_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50022     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50022", &EPRS5022, sizeof(EPRS5022), &EPRF5022, sizeof(EPRF5022));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7623_GenerateEPB50023                    **
**                                                               **
** Description:     Write Freedom Error Report record.           ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7623_GenerateEPB50023()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5023.F5023_RptDataStruct, LOW_VALUES, sizeof(_F5023_RPTDATASTRUCT));
   memset(&EPRS5023.S5023_RptDataStruct, LOW_VALUES, sizeof(_S5023_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5023.F5023_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5023.F5023_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5023.F5023_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5023.F5023_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5023.F5023_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5023.F5023_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5023.F5023_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5023.F5023_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5023.F5023_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5023.F5023_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5023.F5023_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5023.F5023_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5023.F5023_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5023.F5023_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5023.S5023_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5023.S5023_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5023.S5023_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50023     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50023", &EPRS5023, sizeof(EPRS5023), &EPRF5023, sizeof(EPRF5023));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7624_GenerateEPB50024                    **
**                                                               **
** Description:     Write Big Sky Error Report record.           ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7624_GenerateEPB50024()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5024.F5024_RptDataStruct, LOW_VALUES, sizeof(_F5024_RPTDATASTRUCT));
   memset(&EPRS5024.S5024_RptDataStruct, LOW_VALUES, sizeof(_S5024_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5024.F5024_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5024.F5024_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5024.F5024_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5024.F5024_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5024.F5024_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5024.F5024_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5024.F5024_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5024.F5024_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5024.F5024_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5024.F5024_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5024.F5024_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5024.F5024_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5024.F5024_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5024.F5024_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5024.S5024_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5024.S5024_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5024.S5024_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50024     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50024", &EPRS5024, sizeof(EPRS5024), &EPRF5024, sizeof(EPRF5024));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7625_GenerateEPB50025                    **
**                                                               **
** Description:     Write Express Jet Error Report record.       ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7625_GenerateEPB50025()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5025.F5025_RptDataStruct, LOW_VALUES, sizeof(_F5025_RPTDATASTRUCT));
   memset(&EPRS5025.S5025_RptDataStruct, LOW_VALUES, sizeof(_S5025_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5025.F5025_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5025.F5025_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5025.F5025_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5025.F5025_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5025.F5025_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5025.F5025_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5025.F5025_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5025.F5025_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5025.F5025_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5025.F5025_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5025.F5025_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5025.F5025_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5025.F5025_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5025.F5025_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5025.S5025_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5025.S5025_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5025.S5025_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50025     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50025", &EPRS5025, sizeof(EPRS5025), &EPRF5025, sizeof(EPRF5025));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7626_GenerateEPB50026                    **
**                                                               **
** Description:     Write Pinnacle Error Report record.          ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7626_GenerateEPB50026()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5026.F5026_RptDataStruct, LOW_VALUES, sizeof(_F5026_RPTDATASTRUCT));
   memset(&EPRS5026.S5026_RptDataStruct, LOW_VALUES, sizeof(_S5026_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5026.F5026_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5026.F5026_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5026.F5026_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5026.F5026_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5026.F5026_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5026.F5026_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5026.F5026_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5026.F5026_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5026.F5026_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5026.F5026_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5026.F5026_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5026.F5026_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5026.F5026_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5026.F5026_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5026.S5026_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5026.S5026_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5026.S5026_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50026     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50026", &EPRS5026, sizeof(EPRS5026), &EPRF5026, sizeof(EPRF5026));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7627_GenerateEPB50027                    **
**                                                               **
** Description:     Not Used Northwest Error Report record.      ** 
** Description:     Write Manual PPR Error Report record.        **
** Description:     PPatnaik                                     **
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7627_GenerateEPB50027()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5027.F5027_RptDataStruct, LOW_VALUES, sizeof(_F5027_RPTDATASTRUCT));
   memset(&EPRS5027.S5027_RptDataStruct, LOW_VALUES, sizeof(_S5027_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5027.F5027_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5027.F5027_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5027.F5027_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5027.F5027_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5027.F5027_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5027.F5027_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5027.F5027_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5027.F5027_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5027.F5027_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5027.F5027_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5027.F5027_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5027.F5027_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5027.F5027_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5027.F5027_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5027.S5027_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5027.S5027_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5027.S5027_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50027     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50027", &EPRS5027, sizeof(EPRS5027), &EPRF5027, sizeof(EPRF5027));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7628_GenerateEPB50028                    **
**                                                               **
** Description:     Write Mesaba Error Report record.            ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7628_GenerateEPB50028()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5028.F5028_RptDataStruct, LOW_VALUES, sizeof(_F5028_RPTDATASTRUCT));
   memset(&EPRS5028.S5028_RptDataStruct, LOW_VALUES, sizeof(_S5028_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5028.F5028_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5028.F5028_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5028.F5028_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5028.F5028_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5028.F5028_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5028.F5028_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5028.F5028_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5028.F5028_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5028.F5028_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5028.F5028_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5028.F5028_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5028.F5028_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5028.F5028_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5028.F5028_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5028.S5028_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5028.S5028_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5028.S5028_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50028     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50028", &EPRS5028, sizeof(EPRS5028), &EPRF5028, sizeof(EPRF5028));
}        


/******************************************************************
**                                                               **
** Function Name:   TPM_7629_GenerateEPB50029                    **
**                                                               **
** Description:     Write Compass Error Report record.           ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7629_GenerateEPB50029()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5029.F5029_RptDataStruct, LOW_VALUES, sizeof(_F5029_RPTDATASTRUCT));
   memset(&EPRS5029.S5029_RptDataStruct, LOW_VALUES, sizeof(_S5029_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5029.F5029_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5029.F5029_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5029.F5029_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5029.F5029_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5029.F5029_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5029.F5029_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5029.F5029_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5029.F5029_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5029.F5029_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5029.F5029_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5029.F5029_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5029.F5029_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5029.F5029_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5029.F5029_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5029.S5029_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5029.S5029_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5029.S5029_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50029     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50029", &EPRS5029, sizeof(EPRS5029), &EPRF5029, sizeof(EPRF5029));
}        

/******************************************************************
**                                                               **
** Function Name:   TPM_7630_GenerateEPB50030                    **
**                                                               **
** Description:     Write MLT Error Report record.               ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7630_GenerateEPB50030()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5030.F5030_RptDataStruct, LOW_VALUES, sizeof(_F5030_RPTDATASTRUCT));
   memset(&EPRS5030.S5030_RptDataStruct, LOW_VALUES, sizeof(_S5030_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5030.F5030_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5030.F5030_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5030.F5030_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5030.F5030_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5030.F5030_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5030.F5030_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5030.F5030_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5030.F5030_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5030.F5030_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5030.F5030_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5030.F5030_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5030.F5030_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5030.F5030_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5030.F5030_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5030.S5030_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5030.S5030_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5030.S5030_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50030     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50030", &EPRS5030, sizeof(EPRS5030), &EPRF5030, sizeof(EPRF5030));
}        

/******************************************************************
**                                                               **
** Function Name:   TPM_7631_GenerateEPB50031                    **
**                                                               **
** Description:     Write Regional Elite Error Report record.    ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7631_GenerateEPB50031()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5031.F5031_RptDataStruct, LOW_VALUES, sizeof(_F5031_RPTDATASTRUCT));
   memset(&EPRS5031.S5031_RptDataStruct, LOW_VALUES, sizeof(_S5031_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5031.F5031_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5031.F5031_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5031.F5031_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5031.F5031_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5031.F5031_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5031.F5031_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5031.F5031_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5031.F5031_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5031.F5031_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5031.F5031_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5031.F5031_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5031.F5031_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5031.F5031_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5031.F5031_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5031.S5031_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5031.S5031_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5031.S5031_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50031     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50031", &EPRS5031, sizeof(EPRS5031), &EPRF5031, sizeof(EPRF5031));
} 

/******************************************************************
**                                                               **
** Function Name:   TPM_7632_GenerateEPB50032                    **
**                                                               **
** Description:     Write GoJet Error Report record.             ** 
**                                                               ** 
** Arguments:       None                                         ** 
**                                                               **
** Return Values:   None                                         ** 
**                                                               **
**                                                               ** 
******************************************************************/
 
void    TPM_7632_GenerateEPB50032()
{ 
   short nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize report sort and data copybooks     **/ 
 
   memset(&EPRF5032.F5032_RptDataStruct, LOW_VALUES, sizeof(_F5032_RPTDATASTRUCT));
   memset(&EPRS5032.S5032_RptDataStruct, LOW_VALUES, sizeof(_S5032_RPTDATASTRUCT));
 
   /********************************************************/ 
   /** Then format report fields in data and sort layouts **/
   /********************************************************/
 
   EPRF5032.F5032_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRF5032.F5032_RptDataStruct.sNrevSrcCd, DTL_REC.sSourceSys);
   strcpy(EPRF5032.F5032_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRF5032.F5032_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);
   strcpy(EPRF5032.F5032_RptDataStruct.sNrevNm, DTL_REC.sPsgrNm);
   strcpy(EPRF5032.F5032_RptDataStruct.sPassGrpCd, DTL_REC.sPassGrpCd);
   strcpy(EPRF5032.F5032_RptDataStruct.sNrevTypCd, DTL_REC.sPsgrTypeCd);
   strcpy(EPRF5032.F5032_RptDataStruct.sPprStCd, DTL_REC.sEmpCatCd);
   EPRF5032.F5032_RptDataStruct.cEmplArStsInd = DTL_REC.cStsInd;
   strcpy(EPRF5032.F5032_RptDataStruct.sEmplArActnCd, DTL_REC.sStsActCd);
   strcpy(EPRF5032.F5032_RptDataStruct.sFltClsSvcId, DTL_REC.sDesStsActCd);
   strcpy(EPRF5032.F5032_RptDataStruct.sPprStrtDt, DTL_REC.sStrtDt);
   strcpy(EPRF5032.F5032_RptDataStruct.sNrevBdayDt, DTL_REC.sBirthDt);
   EPRF5032.F5032_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   EPRS5032.S5032_RptDataStruct.cEmplArRecInd = cErrorCode;
   strcpy(EPRS5032.S5032_RptDataStruct.sPprNbr, DTL_REC.sPprNbr);
   strcpy(EPRS5032.S5032_RptDataStruct.sNrevNbr, DTL_REC.sDesNrevNbr);

   /********************************************************/ 
   /** Scan report requests for a match with EPB50031     **/ 
   /********************************************************/ 
   BCH_WriteRptRec("EPB50032", &EPRS5032, sizeof(EPRS5032), &EPRF5032, sizeof(EPRF5032));
} 

/******************************************************************
**                                                               **
** Function Name:   TPM_8000_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int  TPM_8000_ProcessLUW()
{
}



/******************************************************************
**                                                               **
** Function Name:   TPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_9500_ProcessEndOfProgram()
{
   char  sErrCnt[8];


 /** Include any logic here for final clean-up processing  **/

 /***********************************************************/
 /** Write header record for future dated records file.    **/
 /***********************************************************/
 
   memset(RS.EPBF030_buffer,' ',sizeof(RS.EPBF030_buffer));
 
   strncpy(header.sHdrId,"HDR",3);
   sprintf(header.sProcYear,sCurrentSortDt,4);
   sprintf(header.sProcMonth,sCurrentDispDt,2);
   sprintf(header.sProcDay,sCurrentDispDt+3,2);
   strncpy(header.sProcHr,sCurrentHHMMSS,2);
   strncpy(header.sProcMin,sCurrentHHMMSS+3,2);
   strncpy(header.sProcSec,sCurrentHHMMSS+6,2);
   strncpy(header.sProcXx,"00",2);
   sprintf(header.sNbrItems,"%07d",RS.EPBF030_record_cntr);
   strncpy(header.sSysId, "FD",2);
   memset(header.sHdrFiller, ' ',sizeof(header.sHdrFiller));
   strncpy(header.sSortByte,"0",1);
  
   BCH_WriteRec(RS.EPBF030, (char *)&header, sizeof(header));
 
 /************************/
 /**    CLOSE FILES     **/
 /************************/
   BCH_Close(RS.EPBF010);
   BCH_Close(RS.EPBF030);

 /************************/
 /**    CONTROL TOTALS  **/
 /************************/

   sprintf(sErrorMessage, "Total Input Records Read: ");
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF010_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "A1 Records Read: ");
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_FormatMessage(2,TXT_REC_TTL, RS.A1_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "C2 Records Read: ");
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_FormatMessage(2,TXT_REC_TTL, RS.C2_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "Future File Records Written: ");
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF030_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "PPR Records Added: ");
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_FormatMessage(2,TXT_REC_TTL, RS.add_ppr_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "NonRev Records Added: ");
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_FormatMessage(2,TXT_REC_TTL, RS.add_nrev_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "PPR Records Updated: ");
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_FormatMessage(2,TXT_REC_TTL, RS.updt_ppr_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "NonRev Records Updated: ");
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_FormatMessage(1,TXT_OUT_FILE, "RS.UPDATE.NREV.EPBF010");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.updt_nrev_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "Max Parent Counter = %d", RS.max_parent_record_cntr);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "Records not processed = %d", RS.records_not_processed);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9500_ProcessEndOfProgram");


}
