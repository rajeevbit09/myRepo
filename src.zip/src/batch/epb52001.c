/**************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB52001.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Transquest Information Solutions                       **
**                  Kimberly Gordon                                        **
**                                                                         **
** Date Written:                                                           **
**                                                                         **
** Description:     Any changes detected on the Stats-Airports Table on    **
**                  MVS are written to an interface file and downloaded    **
**                  to the Pass System.  This program will add change or   **
**                  delete items from the Airport Pair Mileage Table in    **
**                  the Pass system for each record on the interface file. **
**                                                                         **
**                  Before changing or adding an item to the Airport Pair  **
**                  Mileage table, the airport pair type must be deter-    **
**                  mined.                                                 **
**                                                                         **
**                  Any error that causes a row to not be processed, such  **
**                  as an invalid update indicator, or an error return from**
**                  an update or add service will cause the record to be   **
**                  written out to the error file.                         **
**                                                                         **
**                  This information is needed for the pass system to      **
**                  calculate service charges, international fees and      **
**                  imputed wages.                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         Description                               **
** ----       ----------         ----------------------------------------- **
** 9/26/95    KJG                Create                                    **
**                                                                         **
**12/16/95    FFA                Revised                                   **
**                                                                         **
**03/20/96    FFA                dont send message to log for type XX, and **
**                               write msg to log when commit is performed **
**                               to know what record is being processed.   **
**                                                                         **
**04/15/97    SKM                Added some code so that when ever a       **
**                               airport pair is added, changed or deleted **
**                               in the airport_pair_mile table, the       **
**                               reverse pair is also added, changed or    **
**                               deleted. For example if Detroit-Atlanta   **
**                               pair is changed, the program will now     **
**                               also change Atlanta-Detroit pair.         **
**                                                                         **
****************************************************************************/
#include "epb52001.h"

main()
{
   BCH_Init("EPB52001", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   /** Initialize  Fields  **/
   strcpy(sSaveOrigCty, "     ");
   eodflag = FALSE;
   RS.EPBF010_nRcdRead = 0;
   RS.EPBF020_nRcdWrit = 0;
   RS.nArptPrErr = 0;
   RS.nArptCdErr = 0;

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, "EPB52001", "DPM_1000_Initialize");

   /**** open the input file                  ***/
   RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_READ);
   if (RS.EPBF010 == BCH_FAIL)
   {
      BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
      BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
      BCH_HandleMessage(BCH_ERR_ABORT, "EPB52001", "DPM_1000_Initialize");
   }
   /**** open the output error file           ***/
   RS.EPBF020 = BCH_Open("EPBF020", BCH_FILE_WRITE);
   if (RS.EPBF020 == BCH_FAIL)
   {
      BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
      BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF020");
      BCH_HandleMessage(BCH_ERR_ABORT, "EPB52001", "DPM_1000_Initialize");
   }
   /**** after opening file, read the first interface record ***/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   if (BCH_eof(RS.EPBF010))
   {
      BCH_FormatMessage(1,TXT_EMPTY_INPUT_FILE);
      BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
      BCH_HandleMessage(BCH_ERR_ABORT, "EPB52001", "DPM_1000_Initialize");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   /**** Process interface records    ****/
   while (eodflag != TRUE)
   {
      DPM_2500_ProcessInterfaceRecords();

      /****  read the next  interface record ***/
      BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
      if (BCH_eof(RS.EPBF010))
         eodflag = TRUE;
   }  

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessInterfaceRecords             **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_2500_ProcessInterfaceRecords()
{
   cErrorInd = 'N';
   RS.EPBF010_nRcdRead++;
   
   /*** first, copy each of the fields from the record buffer into individual fields ***/
   memcpy(&cUpdateInd, (char*) RS.EPBF010_buffer, 1);
   strncpy(sOrigCty, (char *)RS.EPBF010_buffer+1, 5);
   strncpy(sOrigNm, (char *)RS.EPBF010_buffer+6, 25);
   memcpy(&cOrigStatId, RS.EPBF010_buffer+31, 1);
   strncpy(sDestCty, (char *)RS.EPBF010_buffer+32, 5);
   strncpy(sDestNm, (char *)RS.EPBF010_buffer+37, 25);
   memcpy(&cDestStatId, RS.EPBF010_buffer+62, 1);
   strncpy(sMileage, (char *)RS.EPBF010_buffer+63, 5);

   // Remove trailing spaces from string variables
   UTL_StripTrailingSpaces(sOrigCty);
   UTL_StripTrailingSpaces(sOrigNm);
   UTL_StripTrailingSpaces(sDestCty);
   UTL_StripTrailingSpaces(sDestNm);
   UTL_StripTrailingSpaces(sMileage);
   nMileage = atoi(sMileage);

   /*** save origin city code ***/
   strcpy(RS.sOrignlOrigCty, sOrigCty); 

   /*** if the update indicator is Add or Change, or delete, process airport pair mileage table  ***/
   if (cUpdateInd == ADD || cUpdateInd == DELETE || cUpdateInd == CHANGE)
   {
      DPM_2600_ProcessArptPr();                             

      /*** skm (4/14/97) Following code processes reverse pair.  ***/
      /*** For example DET-ATL pair wad added by previous code,  ***/
      /*** then, this code will add ATL-DET pair.                ***/
   	  memcpy(&cUpdateInd, (char*) RS.EPBF010_buffer, 1);
      strncpy(sDestCty, (char *)RS.EPBF010_buffer+1, 5);
      strncpy(sDestNm, (char *)RS.EPBF010_buffer+6, 25);
      memcpy(&cDestStatId, RS.EPBF010_buffer+31, 1);
      strncpy(sOrigCty, (char *)RS.EPBF010_buffer+32, 5);
      strncpy(sOrigNm, (char *)RS.EPBF010_buffer+37, 25);
      memcpy(&cOrigStatId, RS.EPBF010_buffer+62, 1);
   	  strncpy(sMileage, (char *)RS.EPBF010_buffer+63, 5);

      // Remove trailing spaces from 
      UTL_StripTrailingSpaces(sOrigCty);
      UTL_StripTrailingSpaces(sOrigNm);
      UTL_StripTrailingSpaces(sDestCty);
      UTL_StripTrailingSpaces(sDestNm);
      UTL_StripTrailingSpaces(sMileage);
   	  nMileage = atoi(sMileage);
   
      DPM_2600_ProcessArptPr();                             
   }
   else
   /*** otherwise,  write a message to the error log and write record out to error file         ***/
   {
          cErrorInd = '1';
          DPM_3000_Error();                     
   }

   /*** If the origin city changes, process the airport codes table ***/
   if ((cUpdateInd == ADD || cUpdateInd == CHANGE)  && strcmp(RS.sOrignlOrigCty, sSaveOrigCty) != 0)
      DPM_2800_ProcessArptCode();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2600_ProcessArptPr                       **
**                                                               **
** Description:     Add/Change items on Airport Pair Mileage Tbl **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_2600_ProcessArptPr()
{
   short     nSvcRtnCd;      /* Service return code */
   char      sSaveArptPrTyp[3];
   char      cRowFound;
   struct arptprtyp
   {
      char statsid1;
      char statsid2;
      char type[3];
   };
   struct arptprtyp items[14]  = {
      {'D', 'D', "DM"},
      {'D', 'I', "LA"},
      {'D', 'A', "TA"},
      {'D', 'P', "TP"},
      {'I', 'D', "LA"},
      {'I', 'I', "DM"},
      {'I', 'A', "TA"},
      {'I', 'P', "TP"},
      {'A', 'D', "TA"},
      {'A', 'I', "TA"},
      {'A', 'A', "IE"},
      {'P', 'D', "TP"},
      {'P', 'I', "TP"},
      {'P', 'P', "DM"}   }; 

   int i = 0;

   /*** first, find the appropriate airport pair type that corresponds to the  ***/
   /*** origin and destination stats id if add or change                       ***/
   if (cUpdateInd == ADD  || cUpdateInd == CHANGE)
   {
      strcpy(sSaveArptPrTyp, ERRORCD);
      while (i < 14)
      {
         if (items[i].statsid1 == cOrigStatId    &&
            items[i].statsid2 == cDestStatId)
         {
            strcpy(sSaveArptPrTyp, items[i].type);
            break;
         }
         i++;
      }

      /*** if the origin and destination id was not a valid combination, write a message to the error ***/
      /*** log.  the item will still be added to the table as type XX                                 ***/
      if (strcmp(sSaveArptPrTyp, ERRORCD) == 0)
      {
         cErrorInd = '2';
         DPM_3000_Error();
      }

      /*** next, if the airport pair type is determined to be Domestic or Latin America, then a further **/
      /*** breakdown must be made to determine if the airport pair type should be Alaska, Hawaii, or Canada **/
      if (strcmp(sSaveArptPrTyp , DOMESTIC_ARPTPR) == 0  || strcmp(sSaveArptPrTyp, LATIN_AMERICA) == 0)
      {
         /**** Alaskan Cities ****/
         for (i=0; i<164; i++)
	     {
   	        if  (strncmp(pALCtyStruct[i], sOrigCty, 3) == 0   ||
   	             strncmp(pALCtyStruct[i], sDestCty, 3) == 0)
	        {
		       strcpy(sSaveArptPrTyp, ALASKA); 
	 	       break;
	        }
	     }
	
         /**** Hawaiian Cities ****/
         for (i=0; i<10; i++)
         {
            if  (strncmp(pHICtyStruct[i], sOrigCty, 3)  == 0   || 
                 strncmp(pHICtyStruct[i], sDestCty, 3)  == 0)
            {
               strcpy(sSaveArptPrTyp, HAWAII);
               break;
            }
	     }

   	     /**** Canadian Cities ****/
	     for (i=0; i<23; i++)
	     {
   	        if  (strncmp(pCNCtyStruct[i], sOrigCty, 3) == 0   ||
   	             strncmp(pCNCtyStruct[i], sDestCty, 3) == 0)
	        {
		       strcpy(sSaveArptPrTyp, CANADA);
		       break;
	        }
         }
      }
   }
   
   /**** If this is an add,  execute service to add item to airport pair mileage table ***/
   if (cUpdateInd == ADD)
   {
      memset(&A02794,LOW_VALUES,sizeof(A02794));
      memset(&R02794,LOW_VALUES,sizeof(R02794));
      strcpy(R02794.R02794_appl_area.sFltOrigCtyId, sOrigCty);
      strcpy(R02794.R02794_appl_area.sFltDestCtyId, sDestCty);
      R02794.R02794_appl_area.lFltArptPrNbr =  nMileage;
      strcpy(R02794.R02794_appl_area.sFltArptPrTypCd, sSaveArptPrTyp);
      nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02794,&A02794,SERVICE_ID_02794,1,sizeof(R02794.R02794_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
         break;

         case ARC_DUPLICATE_ROW:
         BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
         BCH_FormatMessage(2,TXT_SVC, "FYS02794");
         sprintf(sErrorMessage, "sFltOrigCtyId = %s, sFltDestCtyId = %s, sFltArptPrTypCd = %s",
       	 sOrigCty, sDestCty, sSaveArptPrTyp);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_WARNING, "EPB52001", "DPM_2600_ProcessArptPr");
         cErrorInd = '4';
         DPM_3000_Error();
         break;

         default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02794");
         BCH_HandleMessage(BCH_ERR_ABORT, "EPB52001", "DPM_2600_ProcessArptPr");
         break;
       }  
    }

   /**** If update indicator = change or delete, get row from airport pair mileage table       ***/
   /**** and then change or delete the item on the table          ***/
   if (cUpdateInd == CHANGE  || cUpdateInd == DELETE)
   {
      /*** get row from airport pair mileage table ***/
      memset(&A02792,LOW_VALUES,sizeof(A02792));
      memset(&R02792,LOW_VALUES,sizeof(R02792));
      strcpy(R02792.R02792_appl_area.sFltOrigCtyId, sOrigCty);
      strcpy(R02792.R02792_appl_area.sFltDestCtyId, sDestCty);
      nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02792,&A02792,SERVICE_ID_02792,1,sizeof(R02792.R02792_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            cRowFound = YES_CHAR;
            break;

	     case ARC_ROW_NOT_FOUND:
            cRowFound = NO_CHAR;
            BCH_FormatMessage(1,TXT_ROW_NOT_FOUND);
            BCH_FormatMessage(2,TXT_SVC, "FYS02792");
            sprintf(sErrorMessage, "sFltOrigCtyId = %s, sFltDestCtyId = %s",
       	            sOrigCty, sDestCty);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, "EPB52001", "DPM_2600_ProcessArptPr");
            cErrorInd = '4';
            DPM_3000_Error();
	        break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02792");
            BCH_HandleMessage(BCH_ERR_ABORT, "EPB52001", "DPM_2600_ProcessArptPr");
	        break;
      }  
      
      /*** if a row was found,  execute service to update item on airport pair mileage table  ***/
      if (cRowFound == YES_CHAR && cUpdateInd == CHANGE)   
      {
         memset(&A02795,LOW_VALUES,sizeof(A02795));
   	     memset(&R02795,LOW_VALUES,sizeof(R02795));
   	     strcpy(R02795.R02795_appl_area.sFltOrigCtyId, sOrigCty);
   	     strcpy(R02795.R02795_appl_area.sFltDestCtyId, sDestCty);
   	     R02795.R02795_appl_area.lFltArptPrNbr =  nMileage;
   	     strcpy(R02795.R02795_appl_area.sFltArptPrTypCd, sSaveArptPrTyp);
	     strcpy(R02795.R02795_appl_area.sArchLastUpdtTs, A02792.A02792_appl_area.sArchLastUpdtTs);
   	     nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02795,&A02795,SERVICE_ID_02795,1,sizeof(R02795.R02795_appl_area));

    	 switch (nSvcRtnCd)
    	 {
            case ARC_SUCCESS:
               break;
 
	 	    default:                   
	 	       BCH_FormatMessage(1,TXT_SVC_UNSUCC);   
	 	       BCH_FormatMessage(2,TXT_SVC, "FYS02795");
	           sprintf(sErrorMessage, "sFltOrigCtyId = %s, sFltDestCtyId = %s, sFltArptPrTypCd = %s",
	        	       sOrigCty, sDestCty, sSaveArptPrTyp);
         	   BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	 	       BCH_HandleMessage(BCH_ERR_WARNING, "EPB52001", "DPM_2600_ProcessArptPr");
	 	       break;
    	 }  
      }

      /*** if delete, execute service to delete item from airport pair mileage table  ***/
      if (cRowFound == YES_CHAR  && cUpdateInd == DELETE)
      {
         memset(&A02796,LOW_VALUES,sizeof(A02796));
         memset(&R02796,LOW_VALUES,sizeof(R02796));
         strcpy(R02796.R02796_appl_area.sFltOrigCtyId, sOrigCty);
         strcpy(R02796.R02796_appl_area.sFltDestCtyId, sDestCty);
         strcpy(R02796.R02796_appl_area.sArchLastUpdtTs, A02792.A02792_appl_area.sArchLastUpdtTs);
         
         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02796,&A02796,SERVICE_ID_02796,1,sizeof(R02796.R02796_appl_area));

         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;

            default:                   
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);   
               BCH_FormatMessage(2,TXT_SVC, "FYS02796");
               sprintf(sErrorMessage, "sFltOrigCtyId = %s, sFltDestCtyId = %s",
      	               sOrigCty, sDestCty);
               BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
               BCH_HandleMessage(BCH_ERR_WARNING, "EPB52001", "DPM_2600_ProcessArptPr");
               break;
         }
	  }  
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2800_ProcessArptCode()                   **
**                                                               **
** Description:     Add or Change items on the Airport Codes Tbl **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2800_ProcessArptCode()
{
   short     nSvcRtnCd;      /* Service return code */

   char cRowFound,
        cSaveIntlInd,
        sSaveRgnCd[3];
   int  i=0;

   /*** get info about origin city from the buffer ***/
   strncpy(sOrigCty, (char *)RS.EPBF010_buffer+1, 5);
   strncpy(sOrigNm, (char *)RS.EPBF010_buffer+6, 25);
   memcpy(&cOrigStatId, RS.EPBF010_buffer+31, 1);

   // Remove trailing spaces from string variables
   UTL_StripTrailingSpaces(sOrigCty);
   UTL_StripTrailingSpaces(sOrigNm);

   strcpy(sSaveRgnCd, "  ");
   if (cOrigStatId == STAT_DOMESTIC)  
      cSaveIntlInd = NO_CHAR;
   else
      cSaveIntlInd = YES_CHAR;

   /*** next, determine the region code   ***/

   /**** Alaskan Cities ****/
   for (i=0; i<164; i++)
   {
      if  (strncmp(pALCtyStruct[i], sOrigCty, 3) == 0)
      {
	     strcpy(sSaveRgnCd, ALASKA);
	     break;
	  }
   }
	
   /**** Hawaiian Cities ****/
   for (i=0; i<10; i++)
   {
      if  (strncmp(pHICtyStruct[i], sOrigCty, 3) == 0)
      {
	     strcpy(sSaveRgnCd, HAWAII);
	     break;
      }
   }

   	/**** Canadian Cities ****/
	for (i=0; i<23; i++)
	{
   	   if  (strncmp(pCNCtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, CANADA);
		  break;
	   }
	}

   	/**** US_Territories  ****/
	for (i=0; i<3; i++)
	{
   	   if  (strncmp(pUTCtyStruct[i], sOrigCty, 3) == 0)
	   {
		  strcpy(sSaveRgnCd, US_TERRITORIES);
		  break;
	   }
	}

   	/**** German Cities ****/
	/******** Commented out for new regions
	for (i=0; i<7; i++)
	{
   	   if (strncmp(pGMCtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, GERMAN_REGION);
		  break;
	   }
	}
	************/

   	/**** African Cities ****/
	for (i=0; i<184; i++)
	{
   	   if (strncmp(pAFRICACtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, AFRICA_REGION);
		  break;
	   }
	}

   	/**** Asian Cities ****/
	for (i=0; i<145; i++)
	{
   	   if (strncmp(pASIACtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, ASIA_REGION);
		  break;
	   }
	}

   	/**** Caribbean Cities ****/
	for (i=0; i<40; i++)
	{
   	   if (strncmp(pCARIBCtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, CARIBBEAN_REGION);
		  break;
	   }
	}

   	/**** Central American Cities ****/
	for (i=0; i<35; i++)
	{
   	   if (strncmp(pCAMERCtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, C_AMERICA_REGION);
		  break;
	   }
	}

   	/**** European Cities ****/
	for (i=0; i<303; i++)
	{
   	   if (strncmp(pEUROCtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, EUROPE_REGION);
		  break;
	   }
	}

   	/**** Middle Eastern Cities ****/
	for (i=0; i<50; i++)
	{
   	   if (strncmp(pMIDEASTCtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, MIDEAST_REGION);
		  break;
	   }
	}

   	/**** Oceanian Cities ****/
	for (i=0; i<96; i++)
	{
   	   if (strncmp(pOCEANCtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, OCEANIA_REGION);
		  break;
	   }
	}

   	/**** South American Cities ****/
	for (i=0; i<156; i++)
	{
   	   if (strncmp(pSAMERCtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, S_AMERICA_REGION);
		  break;
	   }
	}

   	/**** Mexican Cities ****/
	for (i=0; i<45; i++)
	{
   	   if (strncmp(pMEXCtyStruct[i], sOrigCty, 3) == 0)
	   {
	      strcpy(sSaveRgnCd, MEXICO_REGION);
		  break;
	   }
	}

   /*** if the region code is not one of the above, determine region code by stats id ***/
   if (strcmp(sSaveRgnCd, "  ") == 0)
   {
      switch (cOrigStatId)
      {
         case STAT_DOMESTIC:
            strcpy(sSaveRgnCd, US_REGION);
            break;

         case STAT_INTERNATIONAL:
            strcpy(sSaveRgnCd, LATIN_AMERICA);
            break;

         case STAT_TRANSPACIFIC: 
            strcpy(sSaveRgnCd, EUR_ASIA);           
            break;

         case STAT_TRANSATLANTIC:
            strcpy(sSaveRgnCd, EUR_ASIA);           
            break;

         default:                      
            strcpy(sSaveRgnCd, ERRORCD);           
            cErrorInd = '3';
            DPM_3000_Error();
            break;
      }
   }


   /**** execute Service 02554  to see if row exists on t_arpt_cd table ****/
   memset(&A02554,LOW_VALUES,sizeof(_A02554));
   memset(&R02554,LOW_VALUES,sizeof(_R02554));
   strcpy(R02554.R02554_appl_area.sFltArptCd, sOrigCty);
   
   nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R02554,&A02554,SERVICE_ID_02554,1,sizeof(R02554.R02554_appl_area));
   
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         cRowFound = YES_CHAR;
         break;
      case ARC_ROW_NOT_FOUND:
         cRowFound = NO_CHAR;
         break;
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02554");
         BCH_HandleMessage(BCH_ERR_ABORT, "EPB52001", "DPM_2800_ProcessArptCode");
         break;
    }  

    /**** if row does not exist, execute Service 02556  to insert row into  t_arpt_cd table ****/
   if (cRowFound == NO_CHAR)
   {
      memset(&A02556,LOW_VALUES,sizeof(_A02556));
      memset(&R02556,LOW_VALUES,sizeof(_R02556));
      strcpy(R02556.R02556_appl_area.sFltArptCd, sOrigCty);
      R02556.R02556_appl_area.cFltIntlInd = cSaveIntlInd;
      strcpy(R02556.R02556_appl_area.sFltRgnCd, sSaveRgnCd);
      R02556.R02556_appl_area.cFltHubInd = NO_CHAR;
      strcpy(R02556.R02556_appl_area.sFltArptDs, sOrigNm);
       
      nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R02556,&A02556,SERVICE_ID_02556,1,sizeof(R02556.R02556_appl_area));
      
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;
        
         default:         
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02556");
	        sprintf(sErrorMessage, "sFltarptCd = %s, sFltRgnCd = %s",
	                sOrigCty, sSaveRgnCd);                     
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, "EPB52001", "DPM_2800_ProcessArptCode");
            break;
      }
   }  
   /** if row already exists, change the airport code info  ***/
   else                                
   {
      /**** Initialize and execute Service 02557 to update row on tdm_arpt_code table ****/
      memset(&A02557,LOW_VALUES,sizeof(_A02557));
   	  memset(&R02557,LOW_VALUES,sizeof(_R02557));
   	  strcpy(R02557.R02557_appl_area.sFltArptCd, sOrigCty);
   	  R02557.R02557_appl_area.cFltIntlInd = cSaveIntlInd;
   	  strcpy(R02557.R02557_appl_area.sFltRgnCd, sSaveRgnCd);
   	  R02557.R02557_appl_area.cFltHubInd = A02554.A02554_appl_area.cFltHubInd;
      strcpy(R02557.R02557_appl_area.sFltArptDs, sOrigNm);
   	  strcpy(R02557.R02557_appl_area.sArchLastUpdtTs, A02554.A02554_appl_area.sArchLastUpdtTs);
   		 
      nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R02557,&A02557,SERVICE_ID_02557,1,sizeof(R02557.R02557_appl_area));
   		 
      switch (nSvcRtnCd)
   	  {
         case ARC_SUCCESS:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02557");
	        sprintf(sErrorMessage, "sFltarptCd = %s, sFltRgnCd = %s",
	                sOrigCty, sSaveRgnCd);                     
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, "EPB52001", "DPM_2800_ProcessArptCode");
      	    break;  
      }  
   }

   /** after processing, save this city   ***/
   strcpy(sSaveOrigCty, RS.sOrignlOrigCty);
}

/******************************************************************
**                                                               **
** Function Name: DPM_3000_Error                                 **  
**                                                               **
** Description:     Write error message to error log             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_3000_Error()                         
{
   if (cErrorInd == '1')
   {
      BCH_WriteRec(RS.EPBF020, RS.EPBF010_buffer, sizeof RS.EPBF010_buffer);
      RS.EPBF020_nRcdWrit++;
	  sprintf(sErrorMessage, "Invalid update indicator - record written to error file");
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
	  sprintf(sErrorMessage, "OrigCty = %s, DestCty = %s,  UpdtInd = %c",
		      sOrigCty,
		      sDestCty,
		      cUpdateInd);
      BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
	  BCH_HandleMessage(BCH_ERR_WARNING, "EPB52001", "DPM_3000_Error");
   }

   if (cErrorInd == '2')
      RS.nArptPrErr++;

   if (cErrorInd =='3')
      RS.nArptCdErr++;

   if (cErrorInd == '4')
   {
      BCH_WriteRec(RS.EPBF020, RS.EPBF010_buffer, sizeof RS.EPBF010_buffer);
      RS.EPBF020_nRcdWrit++;
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_9500_ProcessEndOfProgram()
{
   BCH_Close(RS.EPBF010);
   BCH_Close(RS.EPBF020);

   BCH_FormatMessage(1,TXT_INPUT_FILE, "EPBF010");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF010_nRcdRead);
   BCH_HandleMessage(BCH_ERR_INFORMATION, "EPB52001", "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF020");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF020_nRcdWrit);
   BCH_HandleMessage(BCH_ERR_INFORMATION, "EPB52001", "DPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "Number of Airport Pr Mileage items with type XX = %08d",
		        RS.nArptPrErr);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, "EPB52001", "DPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "Number of Airport codes with region XX = %08d",
		        RS.nArptCdErr);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, "EPB52001", "DPM_9500_ProcessEndOfProgram");
}
