/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB50002.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Gayle H. Melton                                        **
**                                                                         **
** Date Written:                                                           **
**                                                                         **
** Description:     This module reads the nonrev_psgr table to get all     **
**                  non_DL dependent children who are 19 and are           **
**                  not students, or are 23 and writes the information out **
**                  to a file to be used by EPB50001 to convert them to    **
**                  non-dependents.                                        **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**  1/29/96     FFA                        Added processing to read HR     **
**                                         Client table and write all items**
**                                         to the same EPB5001 file.  The  **
**                                         items are then deleted from the **
**                                         table.                          **
**                                                                         **
** 07/23/96     FFA                        Write Effective date = today to **
**                                         the output file.                **
**                                                                         **
** 09/16/96     FFA                        Dont process DL records         **
**                                                                         **
** 12/25/97     SKM		           When writing HR change record   **
**                                         keep the source system code as  **
**                                         it is. Previously, it was       **
**                                         changing it to "ND".            **
** 05/07/2013   GLW                        change age for ST max to 24     **
**                                                                         **
****************************************************************************/

#include "epb50002.h"

main()
{

    BCH_Init("EPB50002", NUMBER_OF_THREADS);
    DPM_1000_Initialize();
    DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void DPM_1000_Initialize()
{

   /**** Initialize counters & accumulators ****/
   RS.EPBF020_record_cntr = 0;
   RS.nNrevCnt  = 0;
   RS.nHRClientCnt  = 0;
   strcpy(RS.sPprNbr, "         ");
   strcpy(RS.sNrevNbr, "  ");
   strcpy(RS.sHRPprNbr, "         ");
   strcpy(RS.sHRNrevNbr, "  ");
   RS.cEndOfNrevInd = 'N';
  
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   /*** Format the effective date = today in yyyymmdd format  ***/
   strcpy(sEffDt, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD));
      
   RS.EPBF020 = BCH_Open("EPBF020", BCH_FILE_WRITE);

   if (RS.EPBF020 == BCH_FAIL)
   {
        BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
        BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF020");
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */

   /*** if non-dependents havent already been processed, process them ***/
   if (RS.cEndOfNrevInd == 'N')                           
      {

      /** Calculate date for finding 19-year-olds **/
      nReset19Year = (nCurrentYear - 19);
	  sprintf(RS.sReset19Date, "%4d-%02d-%02d-00:00:00", nReset19Year, nCurrentMonth, nCurrentDayOfMon);

      /** Calculate date for finding 24-year-olds **/
      nResetNDYear = (nCurrentYear - 24);
      sprintf(RS.sResetNDDate, "%4d-%02d-%02d-00:00:00", nResetNDYear, nCurrentMonth, nCurrentDayOfMon);

      /*** Send message to error log to show dep to non-dep process beginning ***/
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "Beginning Dependent to Non-Dependent processing for 19 and 24 yr old ");
      sprintf(sErrorMessage, "Nrevs with birthdays on %s and %s.", RS.sReset19Date, RS.sResetNDDate);
      BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
	  BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");
    
      /***** Initialize Request and Answer Blocks *****/
      memset(&R02856.R02856_appl_area, LOW_VALUES, sizeof(R02856.R02856_appl_area));
      memset(&A02856.A02856_appl_area, LOW_VALUES, sizeof(A02856.A02856_appl_area));

      R02856.R02856_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

      /***** Format R02856 keys for initial DB Read *****/
      strcpy(R02856.R02856_appl_area.sNrevBdayDt,RS.sReset19Date);
      strcpy(R02856.R02856_appl_area.sPassSusExpDt,RS.sResetNDDate);
      strcpy(R02856.R02856_appl_area.sPprNbr,RS.sPprNbr);
      strcpy(R02856.R02856_appl_area.sNrevNbr,RS.sNrevNbr);

      /***** Execute service to retrieve driving rows  ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02856,&A02856,SERVICE_ID_02856,1,sizeof(R02856.R02856_appl_area));

      /***** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND: 
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02856");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
 
         }  

      /**** Process driving database rows ****/

      while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {

         /*** Dont process records with a source code of DL   ***/
         if (strcmp(A02856.A02856_appl_area.sNrevSrcCd, "DL") != 0)
            DPM_2500_ProcessRows();

         /** get the next database row **/
         R02856.R02856_appl_area.cArchCursorOpTxt = FETCH_ROW;
         memset(&A02856.A02856_appl_area, LOW_VALUES, sizeof(A02856.A02856_appl_area));
         nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02856,&A02856,SERVICE_ID_02856,1,sizeof(R02856.R02856_appl_area));
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;

            case ARC_ROW_NOT_FOUND:
               RS.cEndOfNrevInd = 'Y';
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS02856");
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
 
          }  
        }
   }

   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "End of Dependent to Non-Dependent processing for 19 and 24 yr olds ");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.nNrevCnt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");

   /*** next, process HR Client Interface table ***/
   DPM_3000_HRClientProcess();

   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{

   /**  Format and write out the HR change record.                                **/
   /**  For each input record, the Nrev Type Code is being changed to "ND",       **/
   /**  the Source System = "ND", the Record Type = "C2", and the Designee Status **/
   /**  Action Code = spaces.                                                     **/ 

   /**  Shridev Makim: 12/29/1997                                                 **/ 
   /**  While writing the HR change record, keep the Source System code as it is. **/ 

   /**  Initialize the hr record **/
   memset(&hr_data, LOW_VALUES, sizeof(hr_data));

   /**  Read the PPR record to get the PPR Start Date, and the Pass Group Code    **/
   DPM_2505_ReadPprRec();

   /** initialize the output record buffer **/
   memset(&RS.EPBF020_buffer, LOW_VALUES, sizeof(RS.EPBF020_buffer));

   hr_data.RecordId = 'C';
   strcpy(hr_data.PprNbr, A02856.A02856_appl_area.sPprNbr);
   strcpy(hr_data.DtlFiller1, SPACE_CHAR);
   strcpy(hr_data.NrevNbr, A02856.A02856_appl_area.sNrevNbr);
   strcpy(hr_data.NrevNm, A02856.A02856_appl_area.sNrevNm);

   /** these fields are filled with spaces because they do not apply to the C2 record or are not used in the HR processing: **/
   strcpy(hr_data.AddrLn1,SPACE_CHAR);
   strcpy(hr_data.AddrLn2,SPACE_CHAR);
   strcpy(hr_data.City,SPACE_CHAR);
   strcpy(hr_data.State,SPACE_CHAR);
   strcpy(hr_data.Zip,SPACE_CHAR);
   strcpy(hr_data.CtryCd,SPACE_CHAR);
   strcpy(hr_data.Phone,SPACE_CHAR);
   strcpy(hr_data.Dept,SPACE_CHAR);
   strcpy(hr_data.Station,SPACE_CHAR);
   strcpy(hr_data.EmpCatCd,SPACE_CHAR);
   hr_data.StsInd = ' ';
   strcpy(hr_data.StsActCd,SPACE_CHAR);
   strcpy(hr_data.AltId,SPACE_CHAR);

   strcpy(hr_data.StrtDt,
		  UTL_ConvertDate(A03834.A03834_appl_area.sPprStrtDt,CNV_DB_TO_YYYYMMDD));

   /** these fields are filled with spaces because they do not apply to the C2 record or are not used in the HR processing: **/
   strcpy(hr_data.EmpTermDt,SPACE_CHAR);
   strcpy(hr_data.PassRvkDt,SPACE_CHAR);
   strcpy(hr_data.InttaxNbr,SPACE_CHAR);

   strcpy(hr_data.RecType, "C2");
   strcpy(hr_data.NrevBdayDt,
		  UTL_ConvertDate(A02856.A02856_appl_area.sNrevBdayDt, CNV_DB_TO_YYYYMMDD));
   strcpy(hr_data.NrevTypCd, "ND");

   strcpy(hr_data.PassGrpCd,A03834.A03834_appl_area.sPassGrpCd);

   /** these fields are filled with spaces because they do not apply to the C2 record or are not used in the HR processing: **/
   strcpy(hr_data.CitzCtryCd,SPACE_CHAR);
   strcpy(hr_data.ResdSts,SPACE_CHAR);
   strcpy(hr_data.DesStsActCd,SPACE_CHAR);

   strcpy(hr_data.SourceSys, A02856.A02856_appl_area.sNrevSrcCd);
   strcpy(hr_data.EffDt,sEffDt);

   /** these fields are filled with spaces because they do not apply to the C2 record or are not used in the HR processing: **/
   strcpy(hr_data.CardIssDt,SPACE_CHAR);
   strcpy(hr_data.ErrorDt,SPACE_CHAR);
   strcpy(hr_data.DtlFiller2,SPACE_CHAR);
  
   DPM_2510_PrintDetail();

   /*** To write to output perform the following:                                ***/
   BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));
   RS.EPBF020_record_cntr++;
   RS.nNrevCnt++;

   strcpy(RS.sPprNbr, A02856.A02856_appl_area.sPprNbr);
   strcpy(RS.sNrevNbr, A02856.A02856_appl_area.sNrevNbr);

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2505_ReadPprRec                          **
**                                                               **
** Description:     Primitive select of the PPR record           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_2505_ReadPprRec()
{
   short   nSvcRtnCd;   /* Service return code */

 /*** Initialize Service Request and Answer Blocks **/
   memset(&R03834, LOW_VALUES, sizeof(_R03834));
   memset(&A03834, LOW_VALUES, sizeof(_A03834));

   strcpy(R03834.R03834_appl_area.sPprNbr, A02856.A02856_appl_area.sPprNbr);

   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R03834,&A03834,SERVICE_ID_03834,1,sizeof(_R03834_APPL_AREA));

 /** Service Return Code Processing **/

   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS03834");
         BCH_FormatMessage(3,TXT_PPR,A02856.A02856_appl_area.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2505_ReadPprRec");
         break;
      }  

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2510_PrintDetail                         **
**                                                               **
** Description:     Print the detail record.                     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
int  DPM_2510_PrintDetail()
{
   short nReturnCode;      /* RSAM commit return code */
 
 
sprintf(RS.EPBF020_buffer, HR_FORMAT,
                  hr_data.RecordId,
                  hr_data.PprNbr,
                  hr_data.DtlFiller1,
                  hr_data.NrevNbr,
                  hr_data.NrevNm,
                  hr_data.AddrLn1,
                  hr_data.AddrLn2,
                  hr_data.City,
                  hr_data.State,
                  hr_data.Zip,
                  hr_data.CtryCd,
                  hr_data.Phone,
                  hr_data.Dept,
                  hr_data.Station,
                  hr_data.EmpCatCd,
                  hr_data.StsInd,
                  hr_data.StsActCd,
                  hr_data.AltId,
                  hr_data.StrtDt,
                  hr_data.EmpTermDt,
                  hr_data.PassRvkDt,
                  hr_data.InttaxNbr,
                  hr_data.RecType,
                  hr_data.NrevBdayDt,
                  hr_data.NrevTypCd,
                  hr_data.PassGrpCd,
                  hr_data.CitzCtryCd,
                  hr_data.ResdSts,
                  hr_data.DesStsActCd,
                  hr_data.SourceSys,
                  hr_data.CardIssDt,
                  hr_data.ErrorDt,
                  hr_data.EffDt,
                  hr_data.DtlFiller2);

}


/******************************************************************
**                                                               **
** Function Name:   DPM_3000_HRClientProcess                     **
**                                                               **
** Description:     Process HR Client Table                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void DPM_3000_HRClientProcess()
{
   short     nSvcRtnCd;      /* Service return code */


      /***** Initialize Request and Answer Blocks *****/
      memset(&R04182.R04182_appl_area, LOW_VALUES, sizeof(R04182.R04182_appl_area));
      memset(&A04182.A04182_appl_area, LOW_VALUES, sizeof(A04182.A04182_appl_area));
      R04182.R04182_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
      strcpy(R04182.R04182_appl_area.sPprNbr,RS.sHRPprNbr);
      strcpy(R04182.R04182_appl_area.sNrevNbr,RS.sHRNrevNbr);

      /*** Send message to error log to show HR client  process beginning ***/
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "Beginning HR Client Interface  processing ") ;
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_3000_HRClientProcess");

      /***** Execute service to retrieve HR Client Interface rows  ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04182,&A04182,SERVICE_ID_04182,1,sizeof(R04182.R04182_appl_area));
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND: 
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_3000_HRClientProcess");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04182");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_HRClientProcess");
 
         }  

      /**** Process driving database rows ****/

      while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {

         DPM_3500_ProcessHRClientRows();

         /** get the next database row **/
         R04182.R04182_appl_area.cArchCursorOpTxt = FETCH_ROW;
         memset(&A04182.A04182_appl_area, LOW_VALUES, sizeof(A04182.A04182_appl_area));
         nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04182,&A04182,SERVICE_ID_04182,1,sizeof(R04182.R04182_appl_area));
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;

            case ARC_ROW_NOT_FOUND:
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS04182");
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_HRClientProcess");
 
          }  
        }

   /*** Finally, delete items from HR Client Interface if any were processed ***/
   if (RS.nHRClientCnt > 0)
   {
      /*** Send message to error log to show HR client  delete beginning ***/
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "Deleting HR Client Interface ") ;
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_3000_HRClientProcess");

      memset(&A04183, LOW_VALUES, sizeof(&A04183));
      nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04183,&A04183,SERVICE_ID_04183,1,sizeof(&R04183));
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;
         case ARC_ROW_NOT_FOUND:
            break;
         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04183");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_HRClientProcess");
 
         }  
   }

   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "End of HR Client Interface  processing ") ;
   BCH_FormatMessage(3,TXT_REC_TTL, RS.nHRClientCnt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_3000_HRClientProcess");

}

/******************************************************************
**                                                               **
** Function Name:   DPM_3500_ProcessHRClientRows                 **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void DPM_3500_ProcessHRClientRows()
{

   /**  Format and write out the HR change record.                                **/

   /**  Initialize the hr record and buffer **/
   memset(&hr_data, LOW_VALUES, sizeof(hr_data));
   memset(&RS.EPBF020_buffer, LOW_VALUES, sizeof(RS.EPBF020_buffer));

   hr_data.RecordId = 'C';
   strcpy(hr_data.PprNbr, A04182.A04182_appl_area.sPprNbr);
   strcpy(hr_data.DtlFiller1, SPACE_CHAR);
   strcpy(hr_data.NrevNbr, A04182.A04182_appl_area.sNrevNbr);
   strcpy(hr_data.NrevNm, A04182.A04182_appl_area.sNrevNm);
   strcpy(hr_data.AddrLn1,A04182.A04182_appl_area.sPpr1Addr);
   strcpy(hr_data.AddrLn2,A04182.A04182_appl_area.sPpr2Addr);
   strcpy(hr_data.City,A04182.A04182_appl_area.sPprCtyAddr);
   strcpy(hr_data.State,A04182.A04182_appl_area.sPprStCd);
   strcpy(hr_data.Zip,A04182.A04182_appl_area.sPprZipAddr);
   strcpy(hr_data.CtryCd,A04182.A04182_appl_area.sPprCtryCd);
   strcpy(hr_data.Phone,A04182.A04182_appl_area.sPprPhNbr);
   strcpy(hr_data.Dept,A04182.A04182_appl_area.sPprDeptNbr);
   strcpy(hr_data.Station,A04182.A04182_appl_area.sPprStnId);
   strcpy(hr_data.EmpCatCd,SPACE_CHAR);
   hr_data.StsInd = ' ';
   strcpy(hr_data.StsActCd,SPACE_CHAR);
   strcpy(hr_data.AltId,A04182.A04182_appl_area.sPprSocSecNbr);
   strcpy(hr_data.StrtDt,
		  UTL_ConvertDate(A04182.A04182_appl_area.sPprStrtDt, CNV_DB_TO_YYYYMMDD));
   strcpy(hr_data.EmpTermDt,SPACE_CHAR);
   strcpy(hr_data.PassRvkDt,
		  UTL_ConvertDate(A04182.A04182_appl_area.sPprRvkDt, CNV_DB_TO_YYYYMMDD));
   strcpy(hr_data.InttaxNbr,A04182.A04182_appl_area.sPprInttxNbr);
   strcpy(hr_data.RecType, A04182.A04182_appl_area.sPassRecCd);
   strcpy(hr_data.NrevBdayDt,
		  UTL_ConvertDate(A04182.A04182_appl_area.sNrevBdayDt, CNV_DB_TO_YYYYMMDD));
   strcpy(hr_data.NrevTypCd, A04182.A04182_appl_area.sNrevTypCd);
   strcpy(hr_data.PassGrpCd,A04182.A04182_appl_area.sPassGrpCd);
   strcpy(hr_data.CitzCtryCd,A04182.A04182_appl_area.sCtryCtznpCd);
   strcpy(hr_data.ResdSts,A04182.A04182_appl_area.sPprRsdncyStsCd);
   strcpy(hr_data.DesStsActCd,SPACE_CHAR);
   strcpy(hr_data.SourceSys, A04182.A04182_appl_area.sNrevSrcCd);
   strcpy(hr_data.CardIssDt,SPACE_CHAR);
   strcpy(hr_data.ErrorDt,SPACE_CHAR);
   strcpy(hr_data.EffDt, sEffDt);
   strcpy(hr_data.DtlFiller2,SPACE_CHAR);
  
   DPM_2510_PrintDetail();

   /*** To write to output perform the following:                                ***/
   BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));
   RS.EPBF020_record_cntr++;
   RS.nHRClientCnt++;

   strcpy(RS.sHRPprNbr, A04182.A04182_appl_area.sPprNbr);
   strcpy(RS.sHRNrevNbr, A04182.A04182_appl_area.sNrevNbr);

}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void DPM_9500_ProcessEndOfProgram()
{

   /** include any logic here for final clean-up processing  **/
   /** e.g. producing a final summary record  **/

   memset(&header,  ' ', sizeof(header));

   /** format and write out the header record **/
   strncpy(header.sHdrId, "HDR",3);
   sprintf(header.sProcYear, sCurrentSortDt, 4);
   sprintf(header.sProcMonth, sCurrentDispDt, 2);
   sprintf(header.sProcDay, sCurrentDispDt+3, 2);
   strncpy(header.sProcHr, sCurrentHHMMSS, 2);
   strncpy(header.sProcMin, sCurrentHHMMSS+3, 2);
   strncpy(header.sProcSec, sCurrentHHMMSS+6, 2);
   strncpy(header.sProcXx, "00", 2);
   sprintf(header.sNbrItems,"%07d", RS.EPBF020_record_cntr);
   strcpy(header.sSysId, "ND");
   strncpy(header.sHdrFiller, SPACE_CHAR, sizeof(header.sHdrFiller));

   BCH_WriteRec(RS.EPBF020,(char *) &header, sizeof(header)); 

   BCH_Close(RS.EPBF020);

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF020");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF020_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

}
