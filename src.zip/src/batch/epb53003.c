/*****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Pass 2000                                              **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    <EPB53003.c>                                           **
**                                                                         **
** Shell Used:      <shltmpc.c>                                            **
**                                                                         **
** Program Type:    Transaction Driven Process Module                      **
**                                                                         **
** Author :         L. Scott                                               **
**                                                                         **
** Date Written:    04/01/09                                               **
**                                                                         **
** Description:     This module adds records to the flt_leg,               **
**                  imput_flt_leg, bdy_nrev_pax_fl tables.  This data is   **
**                  from a nightly interface file passed from PARS.        **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
**                                                                         **
****************************************************************************/

#include "epb53003.h"
#include "stdio.h"


main()
{
   BCH_Init("EPB53003", NUMBER_OF_THREADS);

   TPM_1000_Initialize();

   TPM_2000_Mainline();
}

void write_to_log(char a[],char b[],char c[])
{
FILE *fp;
fp=fopen("mylog.txt","a");
fprintf(fp,"%s-%s-%s\n", a,b,c);
fclose(fp);
}
void write_to_log_char(char a[],char b)
{
FILE *fp;
fp=fopen("mylog.txt","a");
fprintf(fp,"%s-%c\n", a,b);
fclose(fp);
}

void Write_to_log_short(short n)
{
FILE *fp;
fp=fopen("mylog.txt","a");
fprintf(fp,"%i \n", n);
fclose(fp);
}

/******************************************************************
**                                                               **
** Function Name:   TPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_1000_Initialize()
{

 
 /**** Initialize counters & accumulators ***/

 /**** Initialize RSAM variables ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sPprNbrBud, SPACE_CHAR);
   strcpy(RS.sNrevNbr, SPACE_CHAR);
   strcpy(RS.sFltOrigCtyId, SPACE_CHAR);
   strcpy(RS.sFltNbr, SPACE_CHAR);
   strcpy(RS.sFltDestCtyId, SPACE_CHAR);
   strcpy(RS.sTkt, SPACE_CHAR);

 /**** Build thread table ***/

 /**** Initialize Message Request and Answer Copybooks ***/
   memset(&R03962, LOW_VALUES, sizeof(_R03962));
   memset(&A03962, LOW_VALUES, sizeof(_A03962));
   memset(&R03952, LOW_VALUES, sizeof(_R03952));
   memset(&A03952, LOW_VALUES, sizeof(_A03952));
   memset(&R02792, LOW_VALUES, sizeof(_R02792));
   memset(&A02792, LOW_VALUES, sizeof(_A02792));
   memset(&R02496, LOW_VALUES, sizeof(_R02496));
   memset(&A02496, LOW_VALUES, sizeof(_A02496));
   memset(&R02511, LOW_VALUES, sizeof(_R02511));
   memset(&A02511, LOW_VALUES, sizeof(_A02511));
   memset(&R02797, LOW_VALUES, sizeof(_R02797));
   memset(&A02797, LOW_VALUES, sizeof(_A02797));
   memset(&R04724, LOW_VALUES, sizeof(_R04724));
   memset(&A04724, LOW_VALUES, sizeof(_A04724));
   memset(&R04725, LOW_VALUES, sizeof(_R04725));
   memset(&A04725, LOW_VALUES, sizeof(_A04725));
   memset(&R04726, LOW_VALUES, sizeof(_R04726));
   memset(&A04726, LOW_VALUES, sizeof(_A04726));
   memset(&R02526, LOW_VALUES, sizeof(_R02526));
   memset(&A02526, LOW_VALUES, sizeof(_A02526));
   memset(&R04728, LOW_VALUES, sizeof(_R04728));
   memset(&A04728, LOW_VALUES, sizeof(_A04728));
   memset(&R04711, LOW_VALUES, sizeof(_R04711));
   memset(&A04711, LOW_VALUES, sizeof(_A04711));
   memset(&R04729, LOW_VALUES, sizeof(_R04729));
   memset(&A04729, LOW_VALUES, sizeof(_A04729));

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_1000_Initialize");


/**** NOTE: BCH_GetCurrentDate() will give current date and time in many 
             formats.  (including Sort, Display, and Timestamp)  ****/  

   /*********** Open Incoming PARS Interface file            *********/
   RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_READ);
   if (RS.EPBF010 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_1000_Initialize");
   }
    

   /************ Read first interface record            ************/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   if (BCH_eof(RS.EPBF010))
   {
       BCH_FormatMessage(1,TXT_EMPTY_INPUT_FILE);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_1000_Initialize");
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                  The main processing populates the request 	 **
**                  block for the insert into the flt_leg or     **
**                  imput_flt_leg table, Depending on if the     **
**                  passenger is imputed or not.                 **
**                  If the record cannot be added it  will be    **
**                  posted to The Suspense table for the Pass    **
**                  Beaureu to process.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_2000_Mainline()
{
    while (!BCH_eof(RS.EPBF010))
    {
        TPM_3000_ProcessFileEPBF010();
        RS.Read++;
    }

    TPM_9500_ProcessEndOfProgram();

    BCH_Terminate();

    exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   TPM_3000_ProcessFileEPBF010                  **
**                                                               **
** Description:     Call function to process individual          **
**                  records then read next record from buffer.   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_3000_ProcessFileEPBF010()
{
  char PprNbr[9+1];
  char NrevNbr[2+1];
  char FltNbr[4+1];
  char FltOrigCtyId[5+1];
  char FltDestCtyId[5+1];
  char DprtDt[27];
  char cProcSw = 'Y';
  char cPprFound = 'N';
  char *pTemp;
  int i = 0;
  int nFrstNmPeriod = TRUE;
  int nRecWritten = FALSE;
  short nNrevNbr;

   servid = '0';
   servid1 = '0';
   memset(&RS.sDTm, LOW_VALUES, sizeof(RS.sDTm));
   memset(&RS.sATm, LOW_VALUES, sizeof(RS.sATm));

   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sPprNbrBud, SPACE_CHAR);
   strcpy(RS.sNrevNbr, SPACE_CHAR);
   strcpy(RS.sFltOrigCtyId, SPACE_CHAR);
   strcpy(RS.sFltNbr, SPACE_CHAR);
   strcpy(RS.sFltDestCtyId, SPACE_CHAR);
   strcpy(RS.sTkt, SPACE_CHAR);
   strcpy(RS.sSgmtTvlCd, SPACE_CHAR);
   strcpy(sPassTypCd, SPACE_CHAR);
   strcpy(sMaxPassTypCd, SPACE_CHAR);
   strcpy(sMinPassTypCd, SPACE_CHAR);

   strcpy(PprNbr, RS.sPprNbr);
   strcpy(NrevNbr, RS.sNrevNbr);
   strcpy(FltNbr, RS.sFltNbr);
   strcpy(FltOrigCtyId, RS.sFltOrigCtyId);
   strcpy(FltDestCtyId, RS.sFltDestCtyId);
   strcpy(DprtDt, RS.sDprtDt);

   strncpy(RS.sEtId, (char *)RS.EPBF010_buffer+0,2);
   strncpy(RS.sTranDt, (char *)RS.EPBF010_buffer+2,10);
   strncpy(RS.sArLnTktId, (char *)RS.EPBF010_buffer+12,3);
   strncpy(RS.sTktSrlNum3, (char *)RS.EPBF010_buffer+15,3);
   strncpy(RS.sTktSrlNum7, (char *)RS.EPBF010_buffer+18,7);
   strncpy(RS.sTktCpnNum, (char *)RS.EPBF010_buffer+25,2);  
   strncpy(RS.sPsgrTyp, (char *)RS.EPBF010_buffer+27,3);
   strncpy(RS.sSgmtTvlCd, (char *)RS.EPBF010_buffer+30,2);
   strncpy(RS.sPsgrLstNm, (char *)RS.EPBF010_buffer+32,15);
   strncpy(RS.sPsgrFrstNm, (char *)RS.EPBF010_buffer+47,10);
   strncpy(RS.sTripOrig, (char *)RS.EPBF010_buffer+57,5);
   strncpy(RS.sTripDest, (char *)RS.EPBF010_buffer+62,5);
   strncpy(RS.sSegOrig, (char *)RS.EPBF010_buffer+67,5);
   strncpy(RS.sSegDest, (char *)RS.EPBF010_buffer+72,5);
   strncpy(RS.sSegFltNum, (char *)RS.EPBF010_buffer+77,4);
   strncpy(RS.sSegCls, (char *)RS.EPBF010_buffer+81,2);
   strncpy(RS.sEmpNum, (char *)RS.EPBF010_buffer+83,6);
   strncpy(RS.sFiller1, (char *)RS.EPBF010_buffer+89,4);
   strncpy(RS.sSegFltDtYr, (char *)RS.EPBF010_buffer+93,4);
   RS.cSegFltDtDsh1 = RS.EPBF010_buffer[+97];
   strncpy(RS.sSegFltDtMo, (char *)RS.EPBF010_buffer+98,2);
   RS.cSegFltDtDsh2 = RS.EPBF010_buffer[+100];
   strncpy(RS.sSegFltDtDy, (char *)RS.EPBF010_buffer+101,2);
   strncpy(RS.sSegArlnCd, (char *)RS.EPBF010_buffer+103,3);
   RS.cSegArcftType = RS.EPBF010_buffer[+106];
   strncpy(RS.sFmPyCd, (char *)RS.EPBF010_buffer+107,2);
   strncpy(RS.sFmPyCcCd, (char *)RS.EPBF010_buffer+109,2);
   strncpy(RS.sFmPymnt, (char *)RS.EPBF010_buffer+111,19);
   strncpy(RS.sAgncyNum, (char *)RS.EPBF010_buffer+130,4);
   strncpy(RS.sAgncyNm, (char *)RS.EPBF010_buffer+134,15);
   strncpy(RS.sEmpCpCd, (char *)RS.EPBF010_buffer+149,3);
   strncpy(RS.sPnrNum, (char *)RS.EPBF010_buffer+152,6);
   strncpy(RS.sTktDsg, (char *)RS.EPBF010_buffer+158,5);
   strncpy(RS.sTktTag, (char *)RS.EPBF010_buffer+163,5);
   strncpy(RS.sConjTktNum, (char *)RS.EPBF010_buffer+168,21);
   RS.cTrpTyp = RS.EPBF010_buffer[+189];
   RS.cTrpRtg = RS.EPBF010_buffer[+190];
   strncpy(RS.sOneWy, (char *)RS.EPBF010_buffer+191,2);
   strncpy(RS.sTurnArnd, (char *)RS.EPBF010_buffer+193,3);
   RS.cTurnArnd4 = RS.EPBF010_buffer[+196];
   strncpy(RS.sCrjInd, (char *)RS.EPBF010_buffer+197,3);
   strncpy(RS.sTktIssDt, (char *)RS.EPBF010_buffer+200,10);
   strncpy(RS.sTktSegMlg, (char *)RS.EPBF010_buffer+210,3); 
   strncpy(RS.sFiller2, (char *)RS.EPBF010_buffer+213,7);      

  while ((i < 10) && (RS.sPsgrFrstNm[i] != LOW_VALUES))
    {
    switch (RS.sPsgrFrstNm[i])
      {
      case '.':
	if (nFrstNmPeriod == TRUE)
	   {
	   RS.sPsgrFrstNm[i] = ' ';
	   nFrstNmPeriod = FALSE;
	   }
         break;
      case ' ':
	 break;
      default:
	if (nFrstNmPeriod == FALSE)
	    {
	    RS.sPsgrFrstNm[i] = ' ';
	    }
         break;
      }
   i++;
   }


   // Remove trailing spaces from string variables
   UTL_StripTrailingSpaces(RS.sArLnTktId);
   UTL_StripTrailingSpaces(RS.sTktSrlNum3);
   UTL_StripTrailingSpaces(RS.sTktSrlNum7);
   UTL_StripTrailingSpaces(RS.sTktCpnNum);
   UTL_StripTrailingSpaces(RS.sPsgrTyp);
   UTL_StripTrailingSpaces(RS.sSgmtTvlCd);
   UTL_StripTrailingSpaces(RS.sPsgrLstNm);
   UTL_StripTrailingSpaces(RS.sPsgrFrstNm);
   UTL_StripTrailingSpaces(RS.sTripOrig);
   UTL_StripTrailingSpaces(RS.sTripDest);
   UTL_StripTrailingSpaces(RS.sSegOrig);
   UTL_StripTrailingSpaces(RS.sSegDest);
   UTL_StripTrailingSpaces(RS.sSegFltNum);
   UTL_StripTrailingSpaces(RS.sSegCls);
   UTL_StripTrailingSpaces(RS.sEmpNum);
 //UTL_StripTrailingSpaces(RS.sSegFltDt);

 //strcpy(RS.sFltOrigCtyId, RS.sTripOrig);
 //strcpy(RS.sFltDestCtyId, RS.sTripDest);
   strcpy(RS.sFltOrigCtyId, RS.sSegOrig);
   strcpy(RS.sFltDestCtyId, RS.sSegDest);
   strcpy(RS.sFltNbr, RS.sSegFltNum);
   strcat(RS.sFltNbr,"N");
   if (strcmp(RS.sFltNbr, "N") == 0)
      strcpy(RS.sFltNbr, "    N");
   if (strcmp(RS.sFltOrigCtyId, "") == 0)
      {
      strcpy(RS.sFltOrigCtyId, RS.sTripOrig);
      strcpy(RS.sFltDestCtyId, RS.sTripDest);
      }
   strncpy(RS.sFltYrMoDy, RS.sSegFltDtYr, 4);
   strncpy(RS.sFltYrMoDy+4, RS.sSegFltDtMo, 2);
   strncpy(RS.sFltYrMoDy+6, RS.sSegFltDtDy, 2);   
   strcpy(RS.sDprtDt, RS.sFltYrMoDy);
   UTL_StripTrailingSpaces(RS.sDprtDt);
   strcpy(RS.sArrDt, RS.sFltYrMoDy);

   strcpy(RS.sTkt, RS.sArLnTktId);
   strcat(RS.sTkt, RS.sTktSrlNum3);
   strcat(RS.sTkt, RS.sTktSrlNum7);
   strcat(RS.sTkt, RS.sTktCpnNum);  

   // Now convert the dates to standard formats
      pTemp = UTL_ConvertDate(RS.sDprtDt, CNV_YYYYMMDD_TO_DB);
      strncpy(RS.sDprtDt, pTemp, sizeof(RS.sDprtDt));
      pTemp = UTL_ConvertDate(RS.sArrDt,  CNV_YYYYMMDD_TO_DB);   
      strncpy(RS.sArrDt, pTemp, sizeof(RS.sArrDt));

   nTm = 0;

   // Convert PARS passenger types to Delta (Deltamatic) passenger types
//write_to_log("Started Processing NW emp num"," - ",RS.sEmpNum);
//write_to_log("Original PARS psgr type is"," - ",RS.sPsgrTyp);      
   if (strcmp(RS.sPsgrTyp, "EMP") == 0)
      strcpy(RS.sPsgrTyp, "SF");
   if (strcmp(RS.sPsgrTyp, "SPS") == 0)
      strcpy(RS.sPsgrTyp, "SP");
   if (strcmp(RS.sPsgrTyp, "RDP") == 0)
      strcpy(RS.sPsgrTyp, "DP");
   if (strcmp(RS.sPsgrTyp, "DEP") == 0)
      strcpy(RS.sPsgrTyp, "MC");
   if (strcmp(RS.sPsgrTyp, "INF") == 0)
      strcpy(RS.sPsgrTyp, "MC");
   if (strcmp(RS.sPsgrTyp, "IF5") == 0)
      strcpy(RS.sPsgrTyp, "MC");
 //if (strcmp(RS.sPsgrTyp, "DEP") == 0)
 //   strcpy(RS.sPsgrTyp, "ST");
 //if (strcmp(RS.sPsgrTyp, "DEP") == 0)
 //   strcpy(RS.sPsgrTyp, "CD");
   if (strcmp(RS.sPsgrTyp, "PAR") == 0)
      strcpy(RS.sPsgrTyp, "PR");
   if (strcmp(RS.sPsgrTyp, "PNC") == 0)
      strcpy(RS.sPsgrTyp, "ND");
   if (strcmp(RS.sPsgrTyp, "RTC") == 0)
      strcpy(RS.sPsgrTyp, "CP");
   if (strcmp(RS.sPsgrTyp, "CMP") == 0)
      strcpy(RS.sPsgrTyp, "BU");
   if (strcmp(RS.sPsgrTyp, "UNA") == 0)
      strcpy(RS.sPsgrTyp, "BU");
 //write_to_log("PARS psgr type cnverted to"," - ",RS.sPsgrTyp);      

   // Convert PARS boarding priority to Delta boarding priority codes for comparison 
   // purpose only.  The real boarding priority will be stored.
 //write_to_log("Original PARS boarding priority is"," - ",RS.sSgmtTvlCd);      

   if (strcmp(RS.sSgmtTvlCd, "1") == 0 ||
       strcmp(RS.sSgmtTvlCd, "2") == 0 ||
       strcmp(RS.sSgmtTvlCd, "2R") == 0 ||
       strcmp(RS.sSgmtTvlCd, "2U") == 0 ||
       strcmp(RS.sSgmtTvlCd, "2W") == 0)
      strcpy(RS.sBrdPri, "PS");
   if (strcmp(RS.sSgmtTvlCd, "2E") == 0)
      strcpy(RS.sBrdPri, "S1A");
   if (strcmp(RS.sSgmtTvlCd, "2M") == 0 ||
       strcmp(RS.sSgmtTvlCd, "2K") == 0)
      strcpy(RS.sBrdPri, "S1");
   if (strcmp(RS.sSgmtTvlCd, "3V") == 0)
      strcpy(RS.sBrdPri, "S2");
   if (strcmp(RS.sSgmtTvlCd, "3A") == 0)
      strcpy(RS.sBrdPri, "S2B");
   if (strcmp(RS.sSgmtTvlCd, "3") == 0  ||
       strcmp(RS.sSgmtTvlCd, "5") == 0  ||
       strcmp(RS.sSgmtTvlCd, "5B") == 0  ||
       strcmp(RS.sSgmtTvlCd, "9H") == 0  ||
       strcmp(RS.sSgmtTvlCd, "8O") == 0  ||
       strcmp(RS.sSgmtTvlCd, "5O") == 0  ||
       strcmp(RS.sSgmtTvlCd, "GO") == 0  ||
       strcmp(RS.sSgmtTvlCd, "3A") == 0  ||
       strcmp(RS.sSgmtTvlCd, "3B") == 0  ||
       strcmp(RS.sSgmtTvlCd, "3O") == 0  ||
       strcmp(RS.sSgmtTvlCd, "L") == 0)
      strcpy(RS.sBrdPri, "S3");
   if (strcmp(RS.sSgmtTvlCd, "5W") == 0)
      strcpy(RS.sBrdPri, "S3C");
   if (strcmp(RS.sSgmtTvlCd, "3R") == 0 ||
       strcmp(RS.sSgmtTvlCd, "5R") == 0 ||
       strcmp(RS.sSgmtTvlCd, "7R") == 0)
      strcpy(RS.sBrdPri, "S3B");
   if (strcmp(RS.sSgmtTvlCd, "8B") == 0)
      strcpy(RS.sBrdPri, "S3D");
   if (strcmp(RS.sSgmtTvlCd, "30") == 0 ||
      strcmp(RS.sSgmtTvlCd, "9") == 0)
      strcpy(RS.sBrdPri, "S4");

 //write_to_log("PARS boarding priority converted to"," - ",RS.sBrdPri);      
  // Get ppr_nbr based on nw_empl_nb
    strcpy(R04728.R04728_appl_area.sNwEmplNb, RS.sEmpNum);
    memset(&A04728,LOW_VALUES,sizeof(A04728));

    cPprFound = 'N';
//write_to_log("Calling service 4728"," to get ","ppr_nbr based on nw_empl_nb");
    nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04728,&A04728,SERVICE_ID_04728,1,sizeof(R04728.R04728_appl_area));

    switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
	      cPprFound = 'Y';
              strcpy(RS.sPprNbrBud, A04728.A04728_appl_area.sPprNbr);
              break;

         case ARC_ROW_NOT_FOUND:
	      strcpy(sErrMsg, "Invalid NW employee number ");
              servid = '0';
              break;
   
         default:
	    BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	    BCH_FormatMessage(2,TXT_SVC, "FYS04728");
	    sprintf(sErrorMessage, "Ppr = %s",
			         R04728.R04728_appl_area.sNwEmplNb);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	    BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	       
         break;
         }


  // Get ppr_nbr, and nrev_nbr based on nw_empl_nb, nrev_typ_cd, and namess
    strcpy(R04724.R04724_appl_area.sNwEmplNb, RS.sEmpNum);
    strcpy(R04724.R04724_appl_area.sNrevTypCd, RS.sPsgrTyp);
    strcpy(R04724.R04724_appl_area.sNrevFrstNm, RS.sPsgrFrstNm);
    strcpy(R04724.R04724_appl_area.sNrevLstNm, RS.sPsgrLstNm);
    memset(&A04724,LOW_VALUES,sizeof(A04724));
//write_to_log(RS.sEmpNum," is ppr_nbr for nw emp_nb ", RS.sPprNbrBud);
//write_to_log("End calling service"," ","4728");    
//write_to_log("Calling service 4724"," to get ","ppr_nbr, nrev_nbr, nrev_src_cd based on ppr_nbr");
    nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04724,&A04724,SERVICE_ID_04724,1,sizeof(R04724.R04724_appl_area));

    switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:

              strcpy(RS.sPprNbr, A04724.A04724_appl_area.sPprNbr);
              strcpy(RS.sNrevNbr, A04724.A04724_appl_area.sNrevNbr);
              strcpy(RS.sNrevSrcCd, A04724.A04724_appl_area.sNrevSrcCd);
              break;

         case ARC_ROW_NOT_FOUND:
	      strcpy(sErrMsg, "Invalid NW employee number ");
              servid = '0';
              break;
   
         default:
	    BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	    BCH_FormatMessage(2,TXT_SVC, "FYS04724");
	    sprintf(sErrorMessage, "Ppr = %s, Nrev = %s",
			  R04724.R04724_appl_area.sNwEmplNb,
			  R04724.R04724_appl_area.sNrevTypCd,
			  R04724.R04724_appl_area.sNrevFrstNm,
			  R04724.R04724_appl_area.sNrevLstNm);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	    BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	       
         break;
         }
//write_to_log(RS.sPprNbr,RS.sNrevNbr,RS.sNrevSrcCd);
//write_to_log("End calling service"," ","4724");    
      //  Write_to_log(A04724.A04724_appl_area.sPprNbr);
      //  Write_to_log(A04724.A04724_appl_area.sNrevNbr);

    /*** Get pass group code, imputed indicator, and nrev type code from ppr and nrev table  ***/
    strcpy(R03962.R03962_appl_area.sPprNbr, RS.sPprNbr);
    strcpy(R03962.R03962_appl_area.sNrevNbr, RS.sNrevNbr);
    memset(&A03962,LOW_VALUES,sizeof(A03962));
//write_to_log("Calling service 3962","","");
    nSvcRtnCd1 = BCH_InvokeService(EPBINQ0,&R03962,&A03962,SERVICE_ID_03962,1,sizeof(R03962.R03962_appl_area));
	
      //  Write_to_log(A03962.A03962_appl_area.sPassGrpCd);
      //  Write_to_log(A03962.A03962_appl_area.sNrevTypCd);
    
    switch (nSvcRtnCd1)
         {
         case ARC_SUCCESS:
        //write_to_log("Service 3962 is successful","","");
     /**  3/15/05 ejs check if buddy pass then write flt leg record to bdy_nrev_pax_fl table  **/
           nNrevNbr = atoi(RS.sNrevNbr);
//		Write_to_log_short(nNrevNbr);
//	   if(nNrevNbr > 59)
//         {
	//	Write_to_log("Changing nrev typ to short");
	//	Write_to_log_short(nNrevNbr);
	//   }
	// Write_to_log(RS.sNrevNbr);
         if (strcmp(RS.sNrevNbr, "60") == 0 ||
             strcmp(RS.sNrevNbr, "61") == 0 ||
             strcmp(RS.sNrevNbr, "62") == 0 ||
             strcmp(RS.sNrevNbr, "63") == 0 ||
             strcmp(RS.sNrevNbr, "64") == 0 ||
             strcmp(RS.sNrevNbr, "65") == 0 ||
             strcmp(RS.sNrevNbr, "66") == 0 ||
             strcmp(RS.sNrevNbr, "67") == 0 ||
             strcmp(RS.sNrevNbr, "68") == 0 ||
             strcmp(RS.sNrevNbr, "69") == 0 ||
             strcmp(RS.sNrevNbr, "70") == 0 ||
             strcmp(RS.sNrevNbr, "71") == 0 ||
             strcmp(RS.sNrevNbr, "72") == 0 ||
             strcmp(RS.sNrevNbr, "73") == 0 ||
             strcmp(RS.sNrevNbr, "74") == 0 ||
             strcmp(RS.sNrevNbr, "75") == 0 ||
             strcmp(RS.sNrevNbr, "76") == 0 ||
             strcmp(RS.sNrevNbr, "77") == 0 ||
             strcmp(RS.sNrevNbr, "78") == 0 ||
             strcmp(RS.sNrevNbr, "79") == 0 ||
             strcmp(RS.sNrevNbr, "80") == 0 ||
             strcmp(RS.sNrevNbr, "81") == 0 ||
             strcmp(RS.sNrevNbr, "82") == 0 ||
             strcmp(RS.sNrevNbr, "83") == 0 ||
             strcmp(RS.sNrevNbr, "84") == 0 ||
             strcmp(RS.sNrevNbr, "85") == 0 ||
             strcmp(RS.sNrevNbr, "86") == 0 ||
             strcmp(RS.sNrevNbr, "87") == 0 ||
             strcmp(RS.sNrevNbr, "88") == 0 ||
             strcmp(RS.sNrevNbr, "89") == 0 ||
             strcmp(RS.sNrevNbr, "90") == 0 ||
             strcmp(RS.sNrevNbr, "91") == 0 ||
             strcmp(RS.sNrevNbr, "92") == 0 ||
             strcmp(RS.sNrevNbr, "93") == 0 ||
             strcmp(RS.sNrevNbr, "94") == 0 ||
             strcmp(RS.sNrevNbr, "95") == 0 ||
             strcmp(RS.sNrevNbr, "96") == 0 ||
             strcmp(RS.sNrevNbr, "97") == 0 ||
             strcmp(RS.sNrevNbr, "98") == 0)
//         if (nNrevNbr > 59) 
             servid = '3';
             else
           if (A03962.A03962_appl_area.cPassImptInd == 'Y') 
            servid = '1';
           else
            servid = '2';
      //  Write_to_log("servid");
      //  Write_to_log(servid);
           break;

         case ARC_ROW_NOT_FOUND:
            strcpy(sErrMsg, "Invalid Ppr/Nrev Number ");
            servid = '0';
            break;

         default:
	    BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	    BCH_FormatMessage(2,TXT_SVC, "FYS03962");
	    sprintf(sErrorMessage, "Ppr = %s, Nrev = %s",
			  R03962.R03962_appl_area.sPprNbr,
			  R03962.R03962_appl_area.sNrevNbr);
	  BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	  BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	  break;
	  }
//write_to_log_char("Calculated servid is",servid);
//write_to_log("End calling service 3962","","");
	  /* end switch */
	  /*** If ppr/nrev successfully found, go get the airport pair type ***/
	  if (servid != '0')
	  {
//write_to_log("Going to get","airport pair type","");
	  TPM_4000_Get_ArptPrTyp();
	  }
	  /*** if ppr/nrev/airport pair information found, get the boarding priority and airport information ***/
     if (servid != '0')
       {
         /*** Get the Max and Min pass type for the passed boarding priority ***/
//write_to_log("Going to get","max and min pass type","");
          cBrdPriFound = 'Y';
          TPM_4025_Get_BrdPriority();
 
          /*** if brd priority is not valid, check to see if priority used was lower than the lowest ***/
          /*** priority, and if so, use the pass type with the lowest priority                  ***/
          if (cBrdPriFound  == 'N')
             {
//write_to_log("Boarding priority is invalid","going to get lowest priority","");
                TPM_4075_Get_Lowest_Priority();
 
                if (cLowestPriFound == 'Y')
                   {
//write_to_log("Lowest priority found","","");
                   /*** if the lowest priority was found, process max and min pass type for this priority ***/
                   TPM_4025_Get_BrdPriority();
                   /*** if a max or min priority wasnt found for the lowest priority - error ***/
                   if (cBrdPriFound  == 'N')
                      {
                     /* servid = '0'; */
                      strcpy(sErrMsg, "Invalid Boarding Priority");
                      } /* end if cBrdPriFound == N  */
                   } /* end if cLowestPriFound == 'Y' */
                else
                   {
                   servid = '0';
                   strcpy(sErrMsg, "Invalid Boarding Priority");
                   }
             } /* end of if cBrdPriFound = 'N' ***/
 
      } /** endif for servid != 0   */
//write_to_log_char("servid is still ",servid);
     /*** Next Determine if item should go to Imputed or non-imputed flight leg table and process accordingly ***/
     switch (servid)
         {
         /****** Imputed Flight Leg Process    ******/
         case '1': 
           memset(&R02496, LOW_VALUES, sizeof(_R02496));
           memset(&A02496, LOW_VALUES, sizeof(_A02496));
           strcpy(R02496.R02496_appl_area.sPprNbr, RS.sPprNbr);
           strcpy(R02496.R02496_appl_area.sNrevNbr, RS.sNrevNbr);
           strcpy(R02496.R02496_appl_area.sFltNbr, RS.sFltNbr);
           strcpy(R02496.R02496_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId);
           strcpy(R02496.R02496_appl_area.sFltDestCtyId, RS.sFltDestCtyId);
           strcpy(R02496.R02496_appl_area.sFltDprtDt,RS.sDprtDt);
           strcpy(R02496.R02496_appl_area.sFltArrDt,RS.sArrDt);
           R02496.R02496_appl_area.nFltDprtTm = 0000;
           R02496.R02496_appl_area.nFltArrTm = 0000;

           /*** if a senior officer or board member, set the process date to today so no service charges or ***/
           /*** international fees will be processed against these legs.                                    ***/
           if (strcmp(A03962.A03962_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) == 0 ||
               strcmp(A03962.A03962_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) == 0 || 
               strcmp(A03962.A03962_appl_area.sPassGrpCd, SENIOR_OFFICERS) == 0 || 
               strcmp(A03962.A03962_appl_area.sPassGrpCd, BOARD_MEMBERS) == 0) 
                 strcpy(R02496.R02496_appl_area.sProcDt,sCurrentTsDt);
          else   
                 strcpy(R02496.R02496_appl_area.sProcDt, LOW_DATE);

          strcpy(R02496.R02496_appl_area.sPassTypCd, sPassTypCd);   
	  if (strcmp(RS.sSegCls, "") ==0)
	     {
	       strcpy(R02496.R02496_appl_area.sFltClsSvcId, " ");
	     }
	     else
	     strcpy(R02496.R02496_appl_area.sFltClsSvcId,RS.sSegCls);
          strcpy(R02496.R02496_appl_area.sFltArptPrTypCd,A02792.A02792_appl_area.sFltArptPrTypCd);
          strcpy(R02496.R02496_appl_area.sTktNbr,"9999999999");
          R02496.R02496_appl_area.cFltMatchInd = 'U';
          R02496.R02496_appl_area.lPassTripNbr = 0;
          R02496.R02496_appl_area.cFltLegSrcInd = 'I';
          R02496.R02496_appl_area.cFltRptInd = 'N';
          strcpy(R02496.R02496_appl_area.sFltOalFlnInd,"NW");
	  strcpy(R02496.R02496_appl_area.sOthrEmptCd,A03962.A03962_appl_area.sOthrEmptCd);
	  strcpy(R02496.R02496_appl_area.sSbPriCd,RS.sSgmtTvlCd);
	  strcpy(R02496.R02496_appl_area.sNwTktDocNb,RS.sArLnTktId);
	  strcat(R02496.R02496_appl_area.sNwTktDocNb,RS.sTktSrlNum3);
	  strcat(R02496.R02496_appl_area.sNwTktDocNb,RS.sTktSrlNum7);
	  strcat(R02496.R02496_appl_area.sNwTktDocNb,RS.sTktCpnNum);

          /*** If this record has the sam pprnbr, nrevnbr, flt nbt and orig city as the previous record ***/
          /*** then this is a double dated flight, and should have the same flight charge ref date.     ***/
          if ((strcmp(PprNbr, RS.sPprNbr)==0) && (strcmp(NrevNbr, RS.sNrevNbr)==0) &&
              (strcmp(FltNbr, RS.sFltNbr)==0) && (strcmp(FltDestCtyId, RS.sFltOrigCtyId)==0)) 
            {
                R02496.R02496_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(DprtDt);
            }
          else
            {
              R02496.R02496_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(RS.sDprtDt);
            }
//write_to_log("Calling service 2496 and writing to imput_flt_leg","because servid is 1",""); 
            /******Write to imput_flt_leg ****/
            nSvcRtnCd2 = BCH_InvokeService(EPBUPD0,&R02496,&A02496,SERVICE_ID_02496,1,sizeof(R02496.R02496_appl_area)); 
            switch (nSvcRtnCd2) 
            { 
            case ARC_SUCCESS: 
              RS.Imptfltleg++;
	      nRecWritten = TRUE;
              break;
 
            case ARC_DUPLICATE_ROW: 
	      BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
	      BCH_FormatMessage(2,TXT_SVC, "FYS02496");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
			  R02496.R02496_appl_area.sPprNbr,
			  R02496.R02496_appl_area.sNrevNbr,
			  R02496.R02496_appl_area.sFltOrigCtyId,
			  R02496.R02496_appl_area.sFltNbr,
			  R02496.R02496_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_3000_ProcessFileEPBF010");
              break; 
            default:
	      BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	      BCH_FormatMessage(2,TXT_SVC, "FYS02496");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
			  R02496.R02496_appl_area.sPprNbr,
			  R02496.R02496_appl_area.sNrevNbr,
			  R02496.R02496_appl_area.sFltOrigCtyId,
			  R02496.R02496_appl_area.sFltNbr,
			  R02496.R02496_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
              break;
            } /* end switch(nSvcRtnCd)*/
//write_to_log("End calling service 2496","","");
	break; /*** end of imputed flight leg process case 1***/

         /******** (non-imputed) Flight Leg Process    *******/
         case '2':
           memset(&R02511, LOW_VALUES, sizeof(_R02511));
           memset(&A02511, LOW_VALUES, sizeof(_A02511));

           strcpy(R02511.R02511_appl_area.sPprNbr, RS.sPprNbr);
           strcpy(R02511.R02511_appl_area.sNrevNbr, RS.sNrevNbr);
           strcpy(R02511.R02511_appl_area.sFltNbr, RS.sFltNbr);
           strcpy(R02511.R02511_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId);
           strcpy(R02511.R02511_appl_area.sFltDestCtyId, RS.sFltDestCtyId);
           strcpy(R02511.R02511_appl_area.sFltDprtDt,RS.sDprtDt);
           strcpy(R02511.R02511_appl_area.sFltArrDt,RS.sArrDt);
	   /********
           strcpy(R02511.R02511_appl_area.sFltDprtDt,RS.sDprtDt);
           strcpy(R02511.R02511_appl_area.sFltArrDt,RS.sArrDt);
	   **********/
           R02511.R02511_appl_area.nFltDprtTm = nTm;
           R02511.R02511_appl_area.nFltArrTm = nTm;
           strcpy(R02511.R02511_appl_area.sProcDt, LOW_DATE);
           strcpy(R02511.R02511_appl_area.sPassTypCd, sPassTypCd);
           if (strcmp(RS.sSegCls, "") ==0)
	      {
	       strcpy(R02511.R02511_appl_area.sFltClsSvcId, " ");
	      }
	     else
	     strcpy(R02511.R02511_appl_area.sFltClsSvcId,RS.sSegCls);
           strcpy(R02511.R02511_appl_area.sFltArptPrTypCd,A02792.A02792_appl_area.sFltArptPrTypCd);
	   strcpy(R02511.R02511_appl_area.sOthrEmptCd,A03962.A03962_appl_area.sOthrEmptCd);
	   strcpy(R02511.R02511_appl_area.sSbPriCd,RS.sSgmtTvlCd);
	   strcpy(R02511.R02511_appl_area.sNwTktDocNb,RS.sArLnTktId);
	   strcat(R02511.R02511_appl_area.sNwTktDocNb,RS.sTktSrlNum3);
	   strcat(R02511.R02511_appl_area.sNwTktDocNb,RS.sTktSrlNum7);
	   strcat(R02511.R02511_appl_area.sNwTktDocNb,RS.sTktCpnNum);
       //  R02511.R02511_appl_area.lFltChrgRfrnDt  = 2009115;
           R02511.R02511_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(RS.sDprtDt);

          /*** If this record has the sam pprnbr, nrevnbr, flt nbt and orig city as the previous record ***/
          /*** then this is a double dated flight, and should have the same flight charge ref date.     ***/
         //  if ((strcmp(PprNbr, RS.sPprNbr)==0) && (strcmp(NrevNbr, RS.sNrevNbr)==0) &&
         //     (strcmp(FltNbr, RS.sFltNbr)==0) && (strcmp(FltDestCtyId, RS.sFltOrigCtyId)==0)) 
         // {
         //    R02511.R02511_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(DprtDt);
        //  }
        //else
        //  {
        //    R02511.R02511_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(RS.sDprtDt);
        //  }


 
          /*******Write to flt_leg  ****/
//write_to_log("Calling service 2511 and writing to imput_flt_leg","because servid is 2",""); 
          nSvcRtnCd3 = BCH_InvokeService(EPBUPD0,&R02511,&A02511,SERVICE_ID_02511,1,sizeof(R02511.R02511_appl_area));
          switch (nSvcRtnCd3)
         {
         case ARC_SUCCESS:
           RS.Fltleg++;
	   nRecWritten = TRUE;
           break;
         case ARC_DUPLICATE_ROW:
	      BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
	      BCH_FormatMessage(2,TXT_SVC, "FYS02511");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
			  R02511.R02511_appl_area.sPprNbr,
			  R02511.R02511_appl_area.sNrevNbr,
			  R02511.R02511_appl_area.sFltOrigCtyId,
			  R02511.R02511_appl_area.sFltNbr,
			  R02511.R02511_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_3000_ProcessFileEPBF010");
            break;
         default:
	      BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	      BCH_FormatMessage(2,TXT_SVC, "FYS02511");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
			  R02511.R02511_appl_area.sPprNbr,
			  R02511.R02511_appl_area.sNrevNbr,
			  R02511.R02511_appl_area.sFltOrigCtyId,
			  R02511.R02511_appl_area.sFltNbr,
			  R02511.R02511_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
            break;
         } /* end switch (nSvcRtnCd) */

//write_to_log("End calling service 2511","","");
         break;  /*** end of case 2 ***/

         /******** Buddy Flight Leg Process    *******/
	 case '3':
         memset(&R04714, LOW_VALUES, sizeof(_R04714));
	 memset(&A04714, LOW_VALUES, sizeof(_A04714));
         strcpy(R04714.R04714_appl_area.sPprNbr, RS.sPprNbr);
         strcpy(R04714.R04714_appl_area.sNrevNbr, RS.sNrevNbr);
	 strcpy(R04714.R04714_appl_area.sCertftIssDt, A03962.A03962_appl_area.sNrevBdayDt);
         strcpy(R04714.R04714_appl_area.sFltNbr, RS.sFltNbr);
         strcpy(R04714.R04714_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId);
	 strcpy(R04714.R04714_appl_area.sFltDestCtyId, RS.sFltDestCtyId);
	 strcpy(R04714.R04714_appl_area.sFltDprtDt,RS.sDprtDt);
	 strcpy(R04714.R04714_appl_area.sFltArrDt,RS.sArrDt);
	 R04714.R04714_appl_area.nFltDprtTm = 0000;
	 R04714.R04714_appl_area.nFltArrTm = 0000;
	 strcpy(R04714.R04714_appl_area.sProcDt, LOW_DATE);
	 strcpy(R04714.R04714_appl_area.sPassTypCd, sPassTypCd);
         strcpy(R04714.R04714_appl_area.sFltClsSvcId,RS.sSegCls);
	 if (strcmp(RS.sSegCls, "") ==0)
	    {
	    strcpy(R04714.R04714_appl_area.sFltClsSvcId, " ");
	    }
	     else
	    strcpy(R04714.R04714_appl_area.sFltClsSvcId,RS.sSegCls);
	 strcpy(R04714.R04714_appl_area.sFltArptPrTypCd,A02792.A02792_appl_area.sFltArptPrTypCd);
	 strcpy(R04714.R04714_appl_area.sOthrEmptCd,A03962.A03962_appl_area.sOthrEmptCd);
	 strcpy(R04714.R04714_appl_area.sSbPriCd,RS.sSgmtTvlCd);
	 strcpy(R04714.R04714_appl_area.sNwTktDocNb,RS.sArLnTktId);
	 strcat(R04714.R04714_appl_area.sNwTktDocNb,RS.sTktSrlNum3);
	 strcat(R04714.R04714_appl_area.sNwTktDocNb,RS.sTktSrlNum7);
	 strcat(R04714.R04714_appl_area.sNwTktDocNb,RS.sTktCpnNum);

        /*** If this record has the sam pprnbr, nrevnbr, flt nbt and orig city as the previous record then this is a double dated flight, and should have the same flight charge ref date.     ***/
	 if ((strcmp(PprNbr, RS.sPprNbr)==0) && (strcmp(NrevNbr, RS.sNrevNbr)==0) &&
             (strcmp(FltNbr, RS.sFltNbr)==0) && (strcmp(FltDestCtyId, RS.sFltOrigCtyId)==0))
           {
	     R04714.R04714_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(DprtDt);
	   }
	  else
	   {
	   R04714.R04714_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(RS.sDprtDt);
	   }

	 /*******Write to buddy_flt_leg  ****/
//write_to_log("Calling service 4714 and writing to buddy_flt_leg","because servid is 3",""); 
	  nSvcRtnCd4 = BCH_InvokeService(EPBUPD0,&R04714,&A04714,SERVICE_ID_04714,1,sizeof(R04714.R04714_appl_area));
	  switch (nSvcRtnCd4)
	  {
         case ARC_SUCCESS:
	   RS.BuddyFltleg++;
	   nRecWritten = TRUE;
	   break;
	 case ARC_DUPLICATE_ROW: 
	      BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
	      BCH_FormatMessage(2,TXT_SVC, "FYS04714");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
			  R04714.R04714_appl_area.sPprNbr,
			  R04714.R04714_appl_area.sNrevNbr,
			  R04714.R04714_appl_area.sFltOrigCtyId,
			  R04714.R04714_appl_area.sFltNbr,
			  R04714.R04714_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_3000_ProcessFileEPBF010");
	     break;
	 default:
	      BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	      BCH_FormatMessage(2,TXT_SVC, "FYS04714");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
			  R04714.R04714_appl_area.sPprNbr,
			  R04714.R04714_appl_area.sNrevNbr,
			  R04714.R04714_appl_area.sFltOrigCtyId,
			  R04714.R04714_appl_area.sFltNbr,
			  R04714.R04714_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	 break;
      } /* end switch (nSvcRtnCd) */

//write_to_log("End calling service 4714","","");
      break;  /*** end of case 3 ***/

      /***  servid is not 1, 2 or 3 which means some error occurred.                    ***/
      /***  Before writing to suspense check to see if passnger type is a BU (buddy).   ***/
      /**   If so, then force a record to the buddy passenger table and then write the  ***/
      /**   flight leg to the buddy flight leg table.                                   ***/

         default:  

	if ((cPprFound  == 'Y') &&
            strcmp(RS.sPprNbrBud, SPACE_CHAR) != 0 &&
             strcmp(RS.sPsgrTyp, "BU") == 0)
         {


	/********************************************************************************/
        // check bdy_nrev_pax to see if "99" exists.  

        memset(&R04729,LOW_VALUES,sizeof(R04729));
        memset(&A04729,LOW_VALUES,sizeof(A04729));

        strcpy(R04729.R04729_appl_area.sPprNbr, RS.sPprNbrBud);


//write_to_log("Calling service 4729 and writing to buddy_flt_leg","because servid is not 1, 2 or 3",""); 
        nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04729,&A04729,SERVICE_ID_04729,1,sizeof(R04729.R04729_appl_area));

        switch (nSvcRtnCd)
             {
             case ARC_SUCCESS:
                  break;

             case ARC_ROW_NOT_FOUND:
                strcpy(A04729.A04729_appl_area.sNrevNbr, "00");
                strcpy(A04729.A04729_appl_area.sCertftIssDt, LOW_DATE);
                strcpy(A04729.A04729_appl_area.sTktDocNb, "9999999999");
	          strcpy(sErrMsg, "Invalid employee number ");
                  servid = '0';
                  break;
   
             default:
                strcpy(A04729.A04729_appl_area.sNrevNbr, "00");
                strcpy(A04729.A04729_appl_area.sCertftIssDt, LOW_DATE);
                strcpy(A04729.A04729_appl_area.sTktDocNb, LOW_VALUES);
             break;
            }
//write_to_log("End calling service 4729","","");
       //   Write_to_log("begin 4729 results");
       //   Write_to_log(R04729.R04729_appl_area.sPprNbr);
       // Write_to_log(A04729.A04729_appl_area.sNrevNbr);
       // Write_to_log(A04729.A04729_appl_area.sCertftIssDt);
       // Write_to_log(A04729.A04729_appl_area.sTktDocNb);
       // Write_to_log(RS.sTkt);
       //   Write_to_log("End of 4729 results");

	/********************************************************************************/

         memset(&R04711, LOW_VALUES, sizeof(_R04711));
	 memset(&A04711, LOW_VALUES, sizeof(_A04711));
      if (strcmp(A04729.A04729_appl_area.sTktDocNb, RS.sTkt) !=0 || strcmp(A04729.A04729_appl_area.sCertftIssDt, RS.sDprtDt) !=0)
        {
//*              strcpy(A04729.A04729_appl_area.sNrevNbr,  nrevSeq(R04711.R04711_appl_area.sNrevNbr));
	if (strcmp(A04729.A04729_appl_area.sNrevNbr, "00") == 0)
          strcpy(R04711.R04711_appl_area.sNrevNbr, "99");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "99") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9A");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9A") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9B");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9B") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9C");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9C") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9D");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9D") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9E");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9E") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9F");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9F") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9G");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9G") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9H");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9H") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9I");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9I") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9J");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9J") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9K");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9K") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9L");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9L") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9M");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9M") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9N");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9N") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9O");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9O") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9P");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9P") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9Q");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9Q") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9R");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9R") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9S");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9S") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9T");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9T") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9U");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9U") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9V");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9V") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9W");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9W") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9X");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9X") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9Y");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9Y") == 0)
         strcpy(R04711.R04711_appl_area.sNrevNbr, "9Z");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "9Z") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AA");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AA") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AB");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AB") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AC");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AC") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AD");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AD") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AE");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AE") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AF");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AF") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AG");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AG") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AH");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AH") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AI");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AI") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AJ");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AJ") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AK");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AK") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AL");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AL") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AM");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AM") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AN");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AN") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AO");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AO") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AP");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AP") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AQ");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AQ") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AR");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AR") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AS");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AS") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AT");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AT") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AU");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AU") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AV");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AV") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AW");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AW") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AX");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AX") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AY");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AY") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "AZ");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "AZ") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BA");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BA") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BB");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BB") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BC");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BC") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BD");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BD") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BE");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BE") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BF");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BF") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BG");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BG") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BH");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BH") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BI");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BI") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BJ");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BJ") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BK");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BK") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BL");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BL") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BM");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BM") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BN");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BN") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BO");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BO") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BP");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BP") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BQ");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BQ") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BR");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BR") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BS");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BS") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BT");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BT") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BU");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BU") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BV");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BV") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BW");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BW") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BX");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BX") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BY");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BY") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "BZ");
        else if (strcmp(A04729.A04729_appl_area.sNrevNbr, "BZ") == 0)
	 strcpy(R04711.R04711_appl_area.sNrevNbr, "CA");
         
	 strcpy(R04711.R04711_appl_area.sPprNbr, RS.sPprNbrBud);
	 strcpy(R04711.R04711_appl_area.sCertftIssDt, LOW_DATE);
	 strcpy(R04711.R04711_appl_area.sNrevNm, "YIELD-BUDDY");
	 strcpy(R04711.R04711_appl_area.sNrevLstNm, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sNrevFrstNm, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sNrevMidNm, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sNrevBdayDt, SPECIAL_DATE);
         strcpy(R04711.R04711_appl_area.sNrevTypCd, "BU");
         strcpy(R04711.R04711_appl_area.sPassStsCd, "AC");
	 strcpy(R04711.R04711_appl_area.sPassSusExpDt, LOW_DATE);
	 strcpy(R04711.R04711_appl_area.sNrevPassChgInd, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sTktDocNb, LOW_VALUES);
         strcpy(R04711.R04711_appl_area.sTktDocNb,RS.sArLnTktId);
  	 strcat(R04711.R04711_appl_area.sTktDocNb,RS.sTktSrlNum3);
  	 strcat(R04711.R04711_appl_area.sTktDocNb,RS.sTktSrlNum7);
  	 strcat(R04711.R04711_appl_area.sTktDocNb,RS.sTktCpnNum);
	 strcpy(R04711.R04711_appl_area.sTktDocIssLdt, LOW_DATE);
	 R04711.R04711_appl_area.lTktDocSqNb = 0;
	 strcpy(R04711.R04711_appl_area.sStr1Txt, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sStr2Txt, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sCtrySdivNmTxt, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sCtrySdivCd, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sPstlAreaCd, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sCtryCd, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sHmPhNb, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sBusPhNb, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sCellPhNb, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sNrevTrvlArzdLts, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sNrtrRvkdPsrdId, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sNrevTrvlRvkdLts, LOW_VALUES);
	 strcpy(R04711.R04711_appl_area.sPswdTxt, LOW_VALUES);
	 R04711.R04711_appl_area.cGndrTypCd = ' ';
//write_to_log("Calling service 4711 with Nrev_nbr",R04711.R04711_appl_area.sNrevNbr," to write to bdy_nrev_pax");
	 //Write_to_log(R04711.R04711_appl_area.sNrevNbr);
	 //Write_to_log(R04711.R04711_appl_area.sCertftIssDt);
	  nSvcRtnCd10 = BCH_InvokeService(EPBUPD0,&R04711,&A04711,SERVICE_ID_04711,1,sizeof(R04711.R04711_appl_area));
	  switch (nSvcRtnCd10)
	  {
         case ARC_SUCCESS:
	      BCH_FormatMessage(1,TXT_SVC, "SUC-4711");
              //Write_to_log("Successful 4711");
              //Write_to_log(R04711.R04711_appl_area.sPprNbr);
              //Write_to_log(R04711.R04711_appl_area.sNrevNbr);
	   break;
	 case ARC_DUPLICATE_ROW: 
	      BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
	      BCH_FormatMessage(2,TXT_SVC, "FYS04711");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s",
			  R04711.R04711_appl_area.sPprNbr,
			  R04711.R04711_appl_area.sNrevNbr);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_3000_ProcessFileEPBF010");
	     break;
	 default:
	      BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	      BCH_FormatMessage(2,TXT_SVC, "FYS04711");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s",
			  R04711.R04711_appl_area.sPprNbr,
			  R04711.R04711_appl_area.sNrevNbr);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	      break;
           }
//write_to_log("End calling service 4711 ","","");         
        } /** ticket numbers are the same **/
	/********************************************************************************/


         memset(&R04714, LOW_VALUES, sizeof(_R04714));
	 memset(&A04714, LOW_VALUES, sizeof(_A04714));
         if (strcmp(A04729.A04729_appl_area.sTktDocNb, RS.sTkt) == 0)
             strcpy(R04711.R04711_appl_area.sNrevNbr, A04729.A04729_appl_area.sNrevNbr);
         strcpy(R04714.R04714_appl_area.sPprNbr, RS.sPprNbrBud);
         strcpy(R04714.R04714_appl_area.sNrevNbr, R04711.R04711_appl_area.sNrevNbr);
	 strcpy(R04714.R04714_appl_area.sCertftIssDt, LOW_DATE);
         strcpy(R04714.R04714_appl_area.sFltNbr, RS.sFltNbr);
         strcpy(R04714.R04714_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId);
	 strcpy(R04714.R04714_appl_area.sFltDestCtyId, RS.sFltDestCtyId);
	 strcpy(R04714.R04714_appl_area.sFltDprtDt,RS.sDprtDt);
	 strcpy(R04714.R04714_appl_area.sFltArrDt,RS.sArrDt);
	 R04714.R04714_appl_area.nFltDprtTm = 0000;
	 R04714.R04714_appl_area.nFltArrTm = 0000;
	 strcpy(R04714.R04714_appl_area.sProcDt, LOW_DATE);
	 strcpy(R04714.R04714_appl_area.sPassTypCd, "  ");
	 if (strcmp(RS.sSegCls, "") ==0)
	    {
	    strcpy(R04714.R04714_appl_area.sFltClsSvcId, " ");
	    }
	     else
	    strcpy(R04714.R04714_appl_area.sFltClsSvcId,RS.sSegCls);
	 strcpy(R04714.R04714_appl_area.sFltArptPrTypCd, "  ");
	 strcpy(R04714.R04714_appl_area.sOthrEmptCd,A03962.A03962_appl_area.sOthrEmptCd);
	 strcpy(R04714.R04714_appl_area.sSbPriCd,RS.sSgmtTvlCd);
	 strcpy(R04714.R04714_appl_area.sNwTktDocNb,RS.sArLnTktId);
	 strcat(R04714.R04714_appl_area.sNwTktDocNb,RS.sTktSrlNum3);
	 strcat(R04714.R04714_appl_area.sNwTktDocNb,RS.sTktSrlNum7);
	 strcat(R04714.R04714_appl_area.sNwTktDocNb,RS.sTktCpnNum);
	 R04714.R04714_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(RS.sDprtDt);

	 /*******Write to buddy_flt_leg  ****/
//write_to_log("Calling service 4714 with Nrev_nbr",""," to write to bdy_nrev_paxi_fl");
	  nSvcRtnCd11 = BCH_InvokeService(EPBUPD0,&R04714,&A04714,SERVICE_ID_04714,1,sizeof(R04714.R04714_appl_area));
	  switch (nSvcRtnCd11)
	  {
         case ARC_SUCCESS:
	   servid1 = '1';
	   RS.BuddyFltleg++;
	   nRecWritten = TRUE;
	   break;
	 case ARC_DUPLICATE_ROW: 
	      BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
	      BCH_FormatMessage(2,TXT_SVC, "FYS04714");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
			  R04714.R04714_appl_area.sPprNbr,
			  R04714.R04714_appl_area.sNrevNbr,
			  R04714.R04714_appl_area.sFltOrigCtyId,
			  R04714.R04714_appl_area.sFltNbr,
			  R04714.R04714_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_3000_ProcessFileEPBF010");
	     break;
	 default:
	      BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	      BCH_FormatMessage(2,TXT_SVC, "FYS04714");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
			  R04714.R04714_appl_area.sPprNbr,
			  R04714.R04714_appl_area.sNrevNbr,
			  R04714.R04714_appl_area.sFltOrigCtyId,
			  R04714.R04714_appl_area.sFltNbr,
			  R04714.R04714_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	      break;
           }
        }
//write_to_log("End calling service 4714","","");
      /***  servid is not 1, 2 or 3, so some error occurred - write to suspense table   ***/
          if (servid1 == '0')
	    {
//write_to_log("Since servid is not 0","writing to suspense","");
            TPM_3100_Insert_Suspense();
	    nRecWritten = FALSE;
	    }
            break;
         } /***end switch for servid ***/

   /*** check to see if activation fee has been paid ***/
/*** temporarily commented out to not charge activation fees 3-29-2010, L.Scott  ***/

// if (nRecWritten == TRUE)
//   { 
//   TPM_5000_Check_Atvn_Fee();
//
//    if (strcmp(A03962.A03962_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) != 0 &&
//        strcmp(A03962.A03962_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD)!= 0 &&
//        strcmp(A03962.A03962_appl_area.sPassGrpCd, SENIOR_OFFICERS) != 0 &&
///       strcmp(A03962.A03962_appl_area.sPassGrpCd, BOARD_MEMBERS) != 0 &&
//        strcmp(RS.sBrdPri, "PS") != 0);
//   {
////write_to_log("Updating activation fee","and","inserting charge");
//     TPM_5010_Update_Atvn_Fee();
//     TPM_5020_Insert_Charge();
//    }
//   }

    strcpy(RS.sSavePprNbr, RS.sPprNbr);
//write_to_log("End processing ppr_nbr","",RS.sPprNbr);
   /*** Read next interface record ***/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer,sizeof(RS.EPBF010_buffer)); 
   TPM_8000_ProcessLUW();
}


/******************************************************************
**                                                               **
** Function Name:   TPM_3100_Insert_Suspense                     **
**                                                               **
** Description:     function to insert a row into the Suspense   **
**                  table because some error occurred.           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_3100_Insert_Suspense()
{

   memset(&R04395, LOW_VALUES, sizeof(_R04395));
   memset(&A04395, LOW_VALUES, sizeof(_A04395));
   if (strcmp(RS.sPprNbr, " ") == 0)
      {
        strcpy(R04395.R04395_appl_area.sPprNbr, RS.sEmpNum);
        strcat(R04395.R04395_appl_area.sPprNbr, "NW");
      } 
      else
       strcpy(R04395.R04395_appl_area.sPprNbr, RS.sPprNbr);
   strcpy(R04395.R04395_appl_area.sNrevNbr, RS.sNrevNbr);
   strcpy(R04395.R04395_appl_area.sFltNbr, RS.sFltNbr);
   strcpy(R04395.R04395_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId);
   strcpy(R04395.R04395_appl_area.sFltDestCtyId, RS.sFltDestCtyId);
   strcpy(R04395.R04395_appl_area.sFltDprtDt,RS.sDprtDt);
   strcpy(R04395.R04395_appl_area.sFltArrDt,RS.sArrDt);
   R04395.R04395_appl_area.nFltDprtTm = 0000;
   R04395.R04395_appl_area.nFltArrTm = 0000;
   if (strcmp(RS.sSegCls, "") ==0)
      {
        strcpy(R04395.R04395_appl_area.sFltClsSvcId, " ");
      }
     else
       strcpy(R04395.R04395_appl_area.sFltClsSvcId,RS.sSegCls);
   strcpy(R04395.R04395_appl_area.sPassBrdPriId,RS.sSgmtTvlCd);
   strcpy(R04395.R04395_appl_area.sAudtChgTypNm,sErrMsg);

 
   /*******Write to T_suspense ***/
   nSvcRtnCd5 = BCH_InvokeService(EPBUPD0,&R04395,&A04395,SERVICE_ID_04395,1,sizeof(R04395.R04395_appl_area));
   switch (nSvcRtnCd5)
   {
     case ARC_SUCCESS:
        RS.Error++;
        break;
     case ARC_DUPLICATE_ROW:
	      BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
	      BCH_FormatMessage(2,TXT_SVC, "FYS04395");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
			  R04395.R04395_appl_area.sPprNbr,
			  R04395.R04395_appl_area.sNrevNbr,
			  R04395.R04395_appl_area.sFltOrigCtyId,
			  R04395.R04395_appl_area.sFltNbr,
			  R04395.R04395_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_3100_Insert_Suspense");
	     break;
	 default:
	      BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	      BCH_FormatMessage(2,TXT_SVC, "FYS04395");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
			  R04395.R04395_appl_area.sPprNbr,
			  R04395.R04395_appl_area.sNrevNbr,
			  R04395.R04395_appl_area.sFltOrigCtyId,
			  R04395.R04395_appl_area.sFltNbr,
			  R04395.R04395_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3100_Insert_Suspense");
        break;
   }
}

/******************************************************************
**                                                               **
** Function Name:   TPM_4000_Get_ArptPrTyp                       **
**                                                               **
** Description:     function to get airport pair type from       **
**                  arpt_pr_mi table.                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_4000_Get_ArptPrTyp()
{


  /*** get the airport pair type from the airport pair mileage table ***/
  strcpy(R02792.R02792_appl_area.sFltOrigCtyId,RS.sFltOrigCtyId);
  strcpy(R02792.R02792_appl_area.sFltDestCtyId,RS.sFltDestCtyId);
  memset(&A02792,LOW_VALUES,sizeof(A02792));
  nSvcRtnCd6 = BCH_InvokeService(EPBINQ0,&R02792,&A02792,SERVICE_ID_02792,1,sizeof(R02792.R02792_appl_area));
   switch (nSvcRtnCd6)
         {
         case ARC_SUCCESS:
           break; 

           case ARC_ROW_NOT_FOUND:
            strcpy(sErrMsg, "Invalid orig/dest");
            servid = '0';
            break;

         default:  
	      BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	      BCH_FormatMessage(2,TXT_SVC, "FYS02792");
	      sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, Dest = %s",
			  RS.sPprNbr,
			  RS.sNrevNbr,
			  R02792.R02792_appl_area.sFltOrigCtyId,
			  R02792.R02792_appl_area.sFltDestCtyId);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4000_Get_ArptPrTyp");
 
            break;
         } /* end switch */
}


/******************************************************************
**                                                               **
** Function Name:   TPM_4025_Get_BrdPriority                     **
**                                                               **
** Description:     function to get the pass type code from      **
**                  The boarding priority table.                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_4025_Get_BrdPriority()
{

if ((strcmp(A03962.A03962_appl_area.sPassGrpCd, "CC") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "CB") != 0) &&
    (strcmp(RS.sBrdPri, "S3CR") == 0))
   strcpy(RS.sBrdPri, "S3B");

if ((strcmp(A03962.A03962_appl_area.sPassGrpCd, "CC") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "CB") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "CR") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GC") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GK") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GM") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GR") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GS") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GT") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "VR") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "WN") != 0) &&
    (strcmp(RS.sBrdPri, "S3C") == 0))
   strcpy(RS.sBrdPri, "S3");


        /*** first, get max and min pass type code from boarding priority table   ***/
        strcpy(R03952.R03952_appl_area.sPassGrpCd,A03962.A03962_appl_area.sPassGrpCd);
        strcpy(R03952.R03952_appl_area.sNrevTypCd,A03962.A03962_appl_area.sNrevTypCd); 
        strcpy(R03952.R03952_appl_area.sPassBrdPriId,RS.sBrdPri);
        memset(&A03952,LOW_VALUES,sizeof(A03952));
        nSvcRtnCd7 = BCH_InvokeService(EPBINQ0,&R03952,&A03952,SERVICE_ID_03952,1,sizeof(R03952.R03952_appl_area));
        switch (nSvcRtnCd7)
         {
         case ARC_SUCCESS:
           if (A03952.A03952_appl_area.sPassTypCd[0] == ' ')
              cBrdPriFound = 'N';
           else
             {
             /*** save the max pass type code from the brd priority table ***/
             strcpy(sPassTypCd,A03952.A03952_appl_area.sPassTypCd); 
             strcpy(sMaxPassTypCd,A03952.A03952_appl_area.sPassTypCd); 
             strcpy(sMinPassTypCd,A03952.A03952_appl_area.sPassStsCd); 
             cBrdPriFound = 'Y';

             /*** if the max and min pass types are not the same, go to airport pr type table ***/
             /*** to make final determination of pass type to use                             ***/
             if ( strcmp(sMaxPassTypCd, sMinPassTypCd) != 0)
               {
               TPM_4050_Get_PassTypCd(); 
               }
             } 
             break; 

         case ARC_ROW_NOT_FOUND: 
            cBrdPriFound = 'N';
            break; 
 
         default: 
	    BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	    BCH_FormatMessage(2,TXT_SVC, "FYS03952");
	    sprintf(sErrorMessage, "PprNbr = %s, NrevNbr = %s, Grp = %s, NrevTyp = %s, Pri = %s",
		  RS.sPprNbr,
		  RS.sNrevNbr,
		  R03952.R03952_appl_area.sPassGrpCd,
		  R03952.R03952_appl_area.sNrevTypCd,
		  R03952.R03952_appl_area.sPassBrdPriId);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	    BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4025_Get_BrdPriority");
 
            break;
         } /* end switch */


}

/******************************************************************
**                                                               **
** Function Name:   TPM_4050_Get_PassTypCd                       **
**                                                               **
** Description:     Call function to get PassTypCd from          **
**                  arpt_pr_typ table.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void TPM_4050_Get_PassTypCd()
{


   strcpy(R02797.R02797_appl_area.sFltArptPrTypCd,A02792.A02792_appl_area.sFltArptPrTypCd);
   nSvcRtnCd8 = BCH_InvokeService(EPBINQ0,&R02797,&A02797,SERVICE_ID_02797,1,sizeof(R02797.R02797_appl_area));
   switch (nSvcRtnCd8)
         {
         case ARC_SUCCESS:
           /*** if the pass type code from the airport pair type table is the max or min pass type ***/
           /*** from the boarding priority table, use the pass type from the airport pair type table ***/
           /*** if this is the parent of a single assoc w/o kids on a transoceanic flight leg using ***/
           /*** S3 boarding priority, use the pass type from the airport pair typ table.  This is    ***/
           /*** necessary because this group has S3's for 3 different pass types.                    ***/
           /*** otherwise, use the max pass type from the brd priority table                         ***/
           if ((! strcmp(A02797.A02797_appl_area.sPassTypCd, sMaxPassTypCd)) ||
               (! strcmp(A02797.A02797_appl_area.sPassTypCd, sMinPassTypCd))) 
           strcpy(sPassTypCd, A02797.A02797_appl_area.sPassTypCd);
	   if (strcmp(RS.sBrdPri, "S1  ") == 0)
              strcpy(sPassTypCd, sMinPassTypCd);
           if (strcmp(A03962.A03962_appl_area.sPassGrpCd, TEMPDL_SINGLE) == 0      &&
               strcmp(A03962.A03962_appl_area.sNrevTypCd, PARENT) == 0      &&
               strcmp(RS.sBrdPri, "S3  ") == 0                                &&
               (strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, TRANSATLANTIC) == 0   ||
                strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, TRANSPACIFIC) == 0))
                  strcpy(sPassTypCd, A02797.A02797_appl_area.sPassTypCd);
           break;

         case ARC_ROW_NOT_FOUND:
            strcpy(sErrMsg, "Invalid airport pair type");
            servid = '0';
            break;
 
         default:  
	    BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	    BCH_FormatMessage(2,TXT_SVC, "FYS02797");
	    sprintf(sErrorMessage, "PprNbr = %s, NrevNbr = %s, Orig = %s, Dest = %s, ArptPrTyp = %s",
		  RS.sPprNbr,
		  RS.sNrevNbr,
		  R02792.R02792_appl_area.sFltOrigCtyId,
		  R02792.R02792_appl_area.sFltDestCtyId,
		  R02797.R02797_appl_area.sFltArptPrTypCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	    BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4050_Get_PassTypCd");
 
            break;
         } /* end switch */

}

/******************************************************************
**                                                               **
** Function Name:   TPM_4075_Get_Lowest_Priority                 **
**                                                               **
** Description:     Call function to get the lowest possible     **
**                  boarding priority from t_brd_priority.       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void TPM_4075_Get_Lowest_Priority()
{


        memset(&A04400,LOW_VALUES,sizeof(A04400));
        memset(&R04400,LOW_VALUES,sizeof(R04400));
        strcpy(R04400.R04400_appl_area.sPassGrpCd,A03962.A03962_appl_area.sPassGrpCd);
        strcpy(R04400.R04400_appl_area.sNrevTypCd,A03962.A03962_appl_area.sNrevTypCd); 
        nSvcRtnCd9 = BCH_InvokeService(EPBINQ0,&R04400,&A04400,SERVICE_ID_04400,1,sizeof(R04400.R04400_appl_area));
        switch (nSvcRtnCd9)
         {
         case ARC_SUCCESS:
           if (A04400.A04400_appl_area.sPassBrdPriId[0] == ' ')
              cLowestPriFound = 'N';
           else
           {
             /*** if boarding priority used is > lowest boarding priority, use pass type for lowest ***/
             if (strcmp(RS.sBrdPri, A04400.A04400_appl_area.sPassBrdPriId) > 0)
             {
              cLowestPriFound = 'Y';
              strcpy(RS.sBrdPri, A04400.A04400_appl_area.sPassBrdPriId);
             }
             else 
               cLowestPriFound = 'N';
           }
             break; 

         case ARC_ROW_NOT_FOUND:
             cLowestPriFound = 'N';
             break;
 
         default: 
	    BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	    BCH_FormatMessage(2,TXT_SVC, "FYS04400");
	    sprintf(sErrorMessage, "PprNbr = %s, NrevNbr = %s, Grp = %s, NrevTyp",
		  RS.sPprNbr,
		  RS.sNrevNbr,
		  R04400.R04400_appl_area.sPassGrpCd,
		  R04400.R04400_appl_area.sNrevTypCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	    BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4075_Get_Lowest_Priority");
 
            break;
         } /* end switch */
}


/******************************************************************
**                                                               **
** Function Name:   TPM_5000_Check_Atvn_Fee                      **
**                                                               **
** Description:     Check to see if activation fee has bee paid  **
**                  and if not update current fee.               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_5000_Check_Atvn_Fee()
{
     memset(&R04725, LOW_VALUES, sizeof(_R04725));
     memset(&A04725, LOW_VALUES, sizeof(_A04725));
     strcpy(R04725.R04725_appl_area.sPprNbr, A04724.A04724_appl_area.sPprNbr);

    nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04725,&A04725,SERVICE_ID_04725,1,sizeof(R04725.R04725_appl_area));

    switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
              break;

         case ARC_ROW_NOT_FOUND:
	      strcpy(sErrMsg, "Invalid PPR number ");
              servid = '0';
              break;
   
         default:
	    BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	    BCH_FormatMessage(2,TXT_SVC, "FYS04725");
	    sprintf(sErrorMessage, "Ppr = %s, Nrev = %s",
			  R04725.R04725_appl_area.sPprNbr);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	    BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5000_Check_Atvn_Fee");
            break;
         }
}

/******************************************************************
**                                                               **
** Function Name:   TPM_5010_Update_Atvn_Fee                     **
**                                                               **
** Description:     Update activation fee.                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_5010_Update_Atvn_Fee()
{

    if (A04725.A04725_appl_area.cCurAtvnFeeCd == 'N')
      {
	memset(&R04726.R04726_appl_area, LOW_VALUES, sizeof(_R04726_APPL_AREA));
        memset(&R04726, LOW_VALUES, sizeof(_R04726));
        memset(&A04726, LOW_VALUES, sizeof(_A04726));
        strcpy(R04726.R04726_appl_area.sPprNbr, RS.sPprNbr);


        nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04726,&A04726,SERVICE_ID_04726,1,sizeof(R04726.R04726_appl_area));
        switch (nSvcRtnCd)
         {
         case ARC_SUCCESS: 
              break;

         case ARC_ROW_NOT_FOUND:
	      strcpy(sErrMsg, "Invalid PPR number ");
              servid = '0';
              break;
   
         default:
	    BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	    BCH_FormatMessage(2,TXT_SVC, "FYS04726");
	    sprintf(sErrorMessage, "Ppr = %s",
			  R04726.R04726_appl_area.sPprNbr);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	    BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5010_Update_Atvn_Fee");
            break;
         }
       
       }
    
}

/******************************************************************
**                                                               **
** Function Name:   TPM_5020_Insert_Charge                       **
**                                                               **
** Description:     Insert activation fee into t_chrg.           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_5020_Insert_Charge()
{
 

//  if ((strcmp(A04724.A04724_appl_area.sNrevSrcCd, "DL") == 0) &&
//		 (strncmp(A04724.A04724_appl_area.sPprNbr, "0", 1) == 0))
     

  if ((A04725.A04725_appl_area.cCurAtvnFeeCd == 'N') &&
      (strcmp(RS.sSavePprNbr, RS.sPprNbr)!=0))

  {
  memset(&R02526.R02526_appl_area,LOW_VALUES, sizeof(R02526.R02526_appl_area)); /* initialize request   */
  memset(&A02526,LOW_VALUES,sizeof(A02526));                                    /* and Answer block     */
  strcpy(R02526.R02526_appl_area.sPprNbr, RS.sPprNbr);
  strcpy(R02526.R02526_appl_area.sNrevNbr, "00");
  strcpy(R02526.R02526_appl_area.sFltDprtDt, RS.sDprtDt);
  strcpy(R02526.R02526_appl_area.sPassDtTmTs, RS.sArrDt);
  /*strcpy(R02526.R02526_appl_area.sFltDprtDt, sCurrentTsDt);  */
  /*strcpy(R02526.R02526_appl_area.sPassDtTmTs, sCurrentTsDt);  */
  strcpy(R02526.R02526_appl_area.sFltOrigCtyId, "*****");
  strcpy(R02526.R02526_appl_area.sFltDestCtyId, "*****");
  strcpy(R02526.R02526_appl_area.sFltNbr, "*****");
  strcpy(R02526.R02526_appl_area.sSvcChrgCd, "FE");
  R02526.R02526_appl_area.dCostChrgAmt = 50.00;
  strcpy(R02526.R02526_appl_area.sFltClsSvcId, "**");
  strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
  if ((strcmp(A04724.A04724_appl_area.sNrevSrcCd, "DL") == 0) &&
      (strncmp(A04724.A04724_appl_area.sPprNbr, "0", 1) == 0))
           strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "4807865");
      else
           strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "4807865");
  strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
  strcpy(R02526.R02526_appl_area.sSvcChrgDs, "Payroll Deduct");

  R02526.R02526_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(RS.sDprtDt);

     /****** Execute service   ****/
	nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));

    /****** Service Return Code Processing  ****/
        switch (nSvcRtnCd)
          {
	  case ARC_SUCCESS:
	     break;
	  default:
	     BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	     BCH_FormatMessage(2,TXT_SVC, "FYS02526");
	     BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
	                                              R02526.R02526_appl_area.sNrevNbr,
		 				      R02526.R02526_appl_area.sFltDprtDt,
						      R02526.R02526_appl_area.sSvcChrgCd);
	     BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5020_Insert_Charge");
           }					
   }

}
/******************************************************************
**                                                               **
** Function Name:   TPM_8000_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int  TPM_8000_ProcessLUW()
{
}


/******************************************************************
**                                                               **
** Function Name:   TPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_9500_ProcessEndOfProgram()
{

            sprintf(sErrorMessage, "Read = %6d, Errors Written = %5d, Dropped = %5d",
                          RS.Read,
                          RS.Error,
                          RS.Dropped);
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
            sprintf(sErrorMessage, "Flt_Leg = %6d, Impt_Flt_Leg = %6d, Bud_leg = %6d",
                          RS.Fltleg,
                          RS.Imptfltleg,
			  RS.BuddyFltleg);
            BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_9500_ProcessEndOfProgram");

   BCH_Close(RS.EPBF010);

}
static char *nrevSeq(char *pszBuffer)
//***************************************************************************
//* Description: Generate next nrevNbr spaces.
//*
//***************************************************************************
{
    if (pszBuffer[0] == '0' && pszBuffer[1] == '0'){
	pszBuffer[0] = '9';
	pszBuffer[1] = '9';
    }else if(pszBuffer[0] == '9'){
	if(pszBuffer[1] == '9'){
		pszBuffer[1] = 'A';
	}else if(pszBuffer[1] == 'Z'){
		pszBuffer[0] = 'A';
		pszBuffer[1] = 'A';
	}else{
		pszBuffer[1] = pszBuffer[1]+1;
	}
    }else if(pszBuffer[0] >= 'A' && pszBuffer[0] <= 'Z'){
	if(pszBuffer[1] == 'Z'){
		pszBuffer[0] = pszBuffer[0]+1;
		pszBuffer[1] = 'A';
	}else{
		pszBuffer[1] = pszBuffer[1]+1;
	}
    }  
   return pszBuffer;
} // _nrevSeq
