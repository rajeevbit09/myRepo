/**************************************************************************** 
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         ** 
** Sub-System :     Pass Accounting                                        **
**                                                                         ** 
** Program Name:    EPB90013.c                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.c>                                           **
**                                                                         **
** Program Type:    Batch Report Format Module with zero control breaks    **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Written:    May 24, 1995                                           **
**                                                                         **
** Description:     This program reads the sort record created by program  **
**                  EPB90003 and formats the "PASS PENALTY ABUSE REPORT".  **
**                                                                         **
** Revision Trail:                                                         ** 
**                                                                         ** 
** Date       Revised by         SIR #    Description                      ** 
** ----       ----------         -----    -----------                      ** 
**                                                                         ** 
** 11/21/96     FFA                      Added relationship to report      **
****************************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "epb90013.h"

#include "bchrfmcd.h"

main()
{
   RFM_1000_InitializeFlds();
   while ((feof(stdin)) == 0)
      {
      RFM_3000_ProcessDetail();  
      }
   RFM_4000_ProcessEndOfJob();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1000_InitializeFlds                      **
**                                                               **
** Description:     Initialize fields, read initial record,      **
**                  zero accumulators                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1000_InitializeFlds()
{
   char   sCurrentDate[13];  /* current date in mm/dd/yy format */
   
   char  *pEndDate;          /* pointers to reporting dates */
   char   sEndDate[11];      /* report ending date */

   rfm_ReadNextRecord();

   /*  Initialize totals      */
   nRptPagesWritten = 0;

   /* No application accumulators */

   /* Get system date and time    */
   current = time((time_t *)0);
   strcpy(tu.t_str, ctime(&current));
   strftime(sCurrentDate,12,"%m/%d/%y",localtime(&current));

   tu.t_str[7] = tu.t_str[10]=tu.t_str[19]=tu.t_str[24]='\0';
 
   /* Assign report beginning and ending dates to variables */
   pEndDate = (char *) getenv("DATE2");
   strcpy(sEndDate, pEndDate);

   /* If report has an as of date, format the as of date here   */
   nCurrentLineCount = NEW_PAGE;
   memset(print_line,' ',PAGE_WIDTH);
   strcpy(sRequestId, input_area.rqst_id);

   /* Format and save standard headings */

   /* standard heading 1 */
   PRINT_SETUP(1,"CSR #:");
   PRINT_SETUP(11,"7907");
   PRINT_SETUP(56,STD_RPT_TITLE);
   PRINT_SETUP(115,"PAGE:");
   memcpy(std_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 2 */
   PRINT_SETUP(1,"REPORT:");
   PRINT_SETUP(11, "EPB90013");
   PRINT_SETUP(54, "PASS PENALTY ABUSE REPORT");
   PRINT_SETUP(115,"DATE:");
   PRINT_SETUP(123, sCurrentDate);
   memcpy(std_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 3 */
   memset(&sFormatFld2, LOW_VALUES, sizeof(sFormatFld2));
   strcpy(sFormatFld2, "AS OF ");
   strncpy(sFormatFld2+6, sEndDate, 10);
   PRINT_SETUP(58, sFormatFld2);
   PRINT_SETUP(115,"TIME:");
   PRINT_SETUP(123,tu.ts.hh_mm_ss);
   memcpy(std_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 1 */
   PRINT_SETUP(6, "INSTRUCTIONS FOR USE:");
   memcpy(appl_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
 
   /* application heading 2 */
   PRINT_SETUP(11, "THE FOLLOWING FLIGHT LEGS HAVE BEEN FLOWN IN EXCESS OF PASS ALLOTMENT");
   memcpy(appl_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 3 */
   PRINT_SETUP(11, "AND HAVE INCURRED A PENALTY CHARGE IN THE PREVIOUS SIX MONTHS.");
   memcpy(appl_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 4 */
   PRINT_SETUP(11, "PLEASE REVIEW THESE FLIGHT LEGS TO DETERMINE IF THE NON-REVENUE PASSENGER");
   memcpy(appl_heading_4,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 5 */
   PRINT_SETUP(11, "IS ABUSING PASS PRIVILEGES AND IF PASS PRIVILEGES SHOULD BE SUSPENDED.");
   memcpy(appl_heading_5,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 6 */
   PRINT_SETUP(10, "PPR ID/NON-REV ID");
   PRINT_SETUP(31, "PPR/NON-REV PASSENGER NAME");
   PRINT_SETUP(62, "RLTNSHP");
   PRINT_SETUP(74, "FLIGHT DATE");
   PRINT_SETUP(88, "ORIG / DEST");
   PRINT_SETUP(105, "AMOUNT");
   memcpy(appl_heading_6,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 7 */
   PRINT_SETUP(10, "_________________");
   PRINT_SETUP(31, "__________________________");
   PRINT_SETUP(62, "_______");
   PRINT_SETUP(74, "___________");
   PRINT_SETUP(88, "_____________");
   PRINT_SETUP(105, "__________");
   memcpy(appl_heading_7,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3000_ProcessDetail                       **
**                                                               **
** Description:     Process detail line, read next record and    **
**                  determine if there was a control break       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3000_ProcessDetail()
{
    RFM_3100_ProcessReportRecord();
    rfm_ReadNextRecord();
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3100_ProcessReportRecord                 **
**                                                               **
** Description:     Format detail line, add amounts to control   **
**                  totals.                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3100_ProcessReportRecord()
{
   nLinesInGroup = DETAIL_LINE;

   /* Set end of report indicator to no */
   cEndOfRpt = 'N';

   /* Save and print  PPR number for new group line, if there is a new PPR number */
   if (strcmp(rpt_data.F9003_RptDataStruct.sPprNbr, sSavePprNbr) != 0)
      {
      /* Start new page if new PPR and close to the end of current page */
      if (nCurrentLineCount > (LINES_PER_PAGE - 4))
         nCurrentLineCount = NEW_PAGE;

      strcpy(sSavePprNbr, rpt_data.F9003_RptDataStruct.sPprNbr);
      strcpy(sSaveNrevNbr, NULL_STRING);

      /* Print PPR fields */
      sprintf(sFormatFld, "%s00", rpt_data.F9003_RptDataStruct.sPprNbr);
      PRINT_SETUP(10, sFormatFld);    
      PRINT_SETUP(31, rpt_data.F9003_RptDataStruct.sPprNm);    
         
      /* Print new group at beginning of new page; otherwise
         print two blank lines to separate groups on same page */ 
      if (nCurrentLineCount == 18)
         rfm_ControlPrint(SINGLE_SPACE, print_line);
      else
         rfm_ControlPrint(TRIPLE_SPACE, print_line);

      /* Save and print NRev number for new NRev group line */
      strcpy(sSaveNrevNbr, rpt_data.F9003_RptDataStruct.sNrevNbr);
      sprintf(sFormatFld, "%s%s", rpt_data.F9003_RptDataStruct.sPprNbr,
              rpt_data.F9003_RptDataStruct.sNrevNbr);
      PRINT_SETUP(11, sFormatFld);    
      PRINT_SETUP(32, rpt_data.F9003_RptDataStruct.sNrevNm);    
      PRINT_SETUP(65, rpt_data.F9003_RptDataStruct.sNrevTypCd);    
      }

   /* Save and print NRev number for new NRev group line
      or if continuing NRev group from previous page */ 
   else if (strcmp(rpt_data.F9003_RptDataStruct.sNrevNbr, sSaveNrevNbr) != 0 ||
           (nCurrentLineCount == LINES_PER_PAGE))
      {
      strcpy(sSaveNrevNbr, rpt_data.F9003_RptDataStruct.sNrevNbr);
       
      /* Print non-revenue grouping information */
      sprintf(sFormatFld, "%s%s", rpt_data.F9003_RptDataStruct.sPprNbr,
              rpt_data.F9003_RptDataStruct.sNrevNbr);
      PRINT_SETUP(11, sFormatFld);    
      PRINT_SETUP(32, rpt_data.F9003_RptDataStruct.sNrevNm);    
      PRINT_SETUP(65, rpt_data.F9003_RptDataStruct.sNrevTypCd);    
      }
  /** print detail information for non_revenue passenger ***/
   PRINT_SETUP(74, rpt_data.F9003_RptDataStruct.sFltDprtDt);    
   PRINT_SETUP(90, rpt_data.F9003_RptDataStruct.sSvcChrgDs);    

   //sprintf(sAmtFld, "%7.2f", rpt_data.F9003_RptDataStruct.dCostChrgAmt);
   //PRINT_SETUP(105, sAmtFld);
   PRINT_SETUP(105, rpt_data.F9003_RptDataStruct.sCostChrgAmt);

   rfm_ControlPrint(SINGLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_4000_ProcessEndOfJob                     **
**                                                               **
** Description:     Format grand total line, print end of report **
**                  line, close input file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4000_ProcessEndOfJob()
{
   /* Set end of report indicator to yes */
   cEndOfRpt = 'Y';

   PRINT_SETUP(10,
   "SF=SELF  SP=SPOUSE  MC=MINOR DEPEND CHILD<19  ST=FT DEPEND STDNT CHILD<23  DA=DEPEND ADULT RELATIVE");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
   PRINT_SETUP(10, "ND=NON-DEPEND CHILD  PR=PARENT");
   rfm_ControlPrint(SINGLE_SPACE, print_line);

   /* Format end of report line */
   PRINT_SETUP(3,"END OF REPORT");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_5000_PageHeadings                        **
**                                                               **
** Description:     Format and print heading line                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_5000_PageHeadings()
{
   char sNbrOfReportPages[4];  /* Number of report pages written */
 
   nRptPagesWritten++;
 
   /* Format first standard heading */
   memcpy(print_line,std_heading_1,PAGE_WIDTH);
   sprintf(sNbrOfReportPages,"%3i",nRptPagesWritten);
   PRINT_SETUP(128,sNbrOfReportPages);
   rfm_PrintLine(NEW_PAGE,print_line);
 
   /* Format second standard heading */
   memcpy(print_line,std_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   /* Format thrid standard heading */
   memcpy(print_line,std_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
   rfm_PrintLine(TRIPLE_SPACE, print_line);
 
   /* Print application headings if end of report indicator is no */
   if (cEndOfRpt == 'N')
      {
      /*  Format application headings */
      memcpy(print_line,appl_heading_1,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_2,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_3,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
 
      memcpy(print_line,appl_heading_4,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_5,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
      rfm_PrintLine(DOUBLE_SPACE, print_line);

      memcpy(print_line,appl_heading_6,PAGE_WIDTH);
      rfm_PrintLine(TRIPLE_SPACE, print_line);

      memcpy(print_line,appl_heading_7,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      /* Use the next line if you want a blank line between the last */
      /* application heading line and the first detail line          */

      rfm_PrintLine(SINGLE_SPACE, print_line);     
      }
}

/******************************************************************
**                                                               **
** Function Name:   CenterPosition                               **
**                                                               **
** Description:     Calculates number of positions to move       **
**                  to position text in center of field          **
**                                                               **
** Arguments:       Length of field                              **
**                  Input character string                       **
**                                                               **
** Return Values:   Position to center character string          **
**                                                               **
**                                                               **
******************************************************************/

int CenterPosition(int nLength, char sInput[])
{
   int nNbr;      /* Position to center string */

   nNbr = (nLength - (int)strlen(sInput)) / 2;
   return nNbr;
}

