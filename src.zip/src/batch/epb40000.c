/*##########################################################################*/
/*                                                                          */
/* Copyright 2010 - Delta Air Lines, Inc.                                   */
/*                       All Rights Reserved                                */
/*               Access, Modification, or Use Prohibited                    */
/* Without Express Permission of Delta Air Lines                            */
/*                                                                          */
/*##########################################################################*/
/*                                                                         **
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    epb40000.c                                             **
**                                                                         **
** Program Type:    Transaction Driven Process Module                      **
**                                                                         **
** Author:          Duane Ellis                                            **
**                                                                         **
** Date Written:    Mar 2010                                               **
**                                                                         **
** Description:     Transaction driven process module to read RPAD file    **
**                  file record by record.  The module will perform        **
**                  some action on each input record (e.g. update          **
**                  database table).                                       **
**                                                                         **
**                  This module performs the daily load/update of the      **
**                  daily RPAD file into the Pass System database.         **
**                  The RPAD Data received from the Data Warehouse         **
**                  contains Flown Flight Leg data for trips taken by      **
**                  employees. The One Great Team (OGT) program is a       **
**                  positive space award program and subject to taxation   **
**                  so the trip data is to be imputed into the employee's  **
**                  income. This module reads in the RPAD file and either  **
**                  loads the records into the NRAP_FLWN_FL table or       **
**                  can error them out during validation and puts them in  **
**                  suspense in RPAD_FLWN_FL_SPNS to be corrected.         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by    Description                                    **
** ----       ----------    --------------------                           **
** 03/04/2010 Duane Ellis   Inital Program Creation                        **
** 10/04/2010 Duane Ellis   Created new function to look up related tkts   **
** 08/10/2011 Duane Ellis   Disabled creating certain types of errors      **
** 08/05/2012 Duane Ellis   Created new function to assign Nrap_Sq_Nb      **
**                                                                         **
****************************************************************************/

#include "epb40000.h"

void Execute_Test_Scenario(int scenario);    // Duane: Take this out later!

char VersionStr[]    = "epb40000 v1.0.0.0";
char gCompile_Date[] = __DATE__;
char gCompile_Time[] = __TIME__;

time_t startupTime_;
time_t endTime_;

main(int argc, char **argv)
{
   // runMode=1  Process RPAD File
   // runMode=2  Reprocess Suspense Items
   int runMode = (argc > 1  && argv[1][0] == '2') ? REPROCESS_MODE : RPAD_MODE;

   BCH_Init("EPB40000", NUMBER_OF_THREADS);

   TPM_1000_Initialize(runMode);

   TPM_2000_Mainline(runMode);

   TPM_9000_ProcessEndOfProgram(runMode);

   BCH_Terminate();

   exit(0);
}


/******************************************************************
**                                                               **
** Function Name:   TPM_1000_Initialize                          **
**                                                               **
** Description:     Performs startup initialization and opens    **
**                  RPAD input file.                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_1000_Initialize(int runMode)
{
   char *pEnvFlag;

 /**** Initialize counters & accumulators ***/

   startupTime_ = time(0);

   // Init Counters
   RS.RPAD_Rec_Cnt    = 0;
   RS.SPNS_Rec_Cnt    = 0;
   RS.SPNS_Delete_Cnt = 0;
   RS.Flown_FL_Cnt    = 0;
   RS.Suspense_Cnt    = 0;
   RS.DupSuspense_Cnt = 0;
   RS.DupFlownFL_Cnt  = 0;
   RS.Ignore_Cnt      = 0;
   RS.Error_Cnt       = 0;
   RS.reclen          = 0;

  /**** Initialize flags ****/
   pEnvFlag = (char *)getenv("IGNORE_RECOGNITION_AWARD_PGM");
   RS.fIgnoreRecognitionAwardPgm = (pEnvFlag) ? EnvValueToBOOL(pEnvFlag) : 0;

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, VersionStr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_1000_Initialize");

  /*******************************************************************/
  /************    Open RPAD file and read first record    ***********/
  /*******************************************************************/
   if (runMode == RPAD_MODE)
   {
      RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_READ);

      if (RS.EPBF010 != BCH_FAIL)
      {
         // Read First Record
         RS.reclen = BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
         if (BCH_eof(RS.EPBF010))
         {
            printf("\n***** Error: RPAD File zero length! *****\n\n");

            BCH_Close(RS.EPBF010);

            RS.EPBF010 = BCH_FAIL;
         }
      }
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                  The main processing thread to processes      **
**                  RPAD data and to reprocess corrected data    **
**                  from the Suspense file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_2000_Mainline(int runMode)
{

   switch (runMode)
   {

      //---------  Process RPAD File  -------------------
      case RPAD_MODE:
         //
         // While there are RPAD Records to process....
         //
         if (RS.EPBF010 != BCH_FAIL)
         {
            printf("MODE: RPAD MODE\n");
            printf("Processing RPAD File...\n\n");

            while (!BCH_eof(RS.EPBF010))
            {
               if (RS.reclen > 0)
               {
                  printf("RPAD Record %ld\n", ++RS.RPAD_Rec_Cnt);
                  TPM_3000_ProcessFileEPBF010();

                  // Process RPAD Item
                  TPM_4000_ProcessFlownLeg();
               }

               // Read Next RPAD Record
               RS.reclen = BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
            }
         }
         break;


      //---------  Reprocess Suspense Items  -------------------
      case REPROCESS_MODE:
         //
         // While there are records in RPAD_FLWN_FL_SPNS that need processing
         //
         printf("MODE: Reprocessing MODE\n");
         printf("Reprocessing Suspense Items...\n\n");
         while (TPM_8100_GetSuspenseRecToReprocess())
         {
             printf("Suspense Item %ld\n", ++RS.SPNS_Rec_Cnt);

             // Reprocess Suspense Item
             TPM_4000_ProcessFlownLeg();
         }
         break;
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_3000_ProcessFileEPBF010                  **
**                                                               **
** Description:     Call function to process individual          **
**                  records from RPAD file.  Loads and martials  **
**                  the record data into memory.                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_3000_ProcessFileEPBF010()
{
   char *pTemp;

   // Fetch data from RPAD Record
   RPAD_REC = (struct _RPAD_REC *)RS.EPBF010_buffer;
   strncpy(RS.sPprNbr,       RPAD_REC->PPR_NBR,              9);
   strncpy(RS.sNrevNbr,      RPAD_REC->PPR_NB_EXT,           2);
   strncpy(RS.sPriTktDocNb,  RPAD_REC->PRI_TKT_DOC_NB,      15);
   strncpy(RS.sTktDocNbr,    RPAD_REC->TKT_DOC_NB,          15);
   strncpy(RS.sTktDocSqNb,   RPAD_REC->TKT_DOC_SQ_NB,        3);
   strncpy(RS.sOrglTktNbr,   RPAD_REC->ORGL_TKT_NBR_TXT,    15);
   strncpy(RS.sTktCpnNb,     RPAD_REC->CPN_NB,               3);
   strncpy(RS.sPaxFirstName, RPAD_REC->PAX_FRST_NM,         50);
   strncpy(RS.sPaxLastName,  RPAD_REC->PAX_LST_NM,          50);
   strncpy(RS.sFltNbr,       RPAD_REC->OPAS_FLT_NB,          5);
   strncpy(RS.sFltOrigCtyId, RPAD_REC->CPN_ORIG_TRSTN_CD,    5);
   strncpy(RS.sFltDestCtyId, RPAD_REC->CPN_DEST_TRSTN_CD,    5);
   strncpy(RS.sLegMileage,   RPAD_REC->GREAT_CRCL_MI,        8);
   strncpy(RS.sPsgrInfo,     RPAD_REC->PAX_INFO_TXT,        49);
   strncpy(RS.sTourCode,     RPAD_REC->TOUR_CODE_TXT,       20);  // Fetch, but field is never used
   strncpy(RS.sFareBasis,    RPAD_REC->FARE_BAS_TXT,         8);
   strncpy(RS.sTktDesignator,RPAD_REC->TKT_DSGTR_TXT,       15);

   // Remove trailing spaces from string variables
   UTL_StripTrailingSpaces(RS.sPprNbr);
   UTL_StripTrailingSpaces(RS.sNrevNbr);
   UTL_StripTrailingSpaces(RS.sPriTktDocNb);
   UTL_StripTrailingSpaces(RS.sTktDocNbr);
   UTL_StripTrailingSpaces(RS.sTktDocSqNb);
   UTL_StripTrailingSpaces(RS.sOrglTktNbr);
   UTL_StripTrailingSpaces(RS.sTktCpnNb);
   UTL_StripTrailingSpaces(RS.sPaxFirstName);
   UTL_StripTrailingSpaces(RS.sPaxLastName);
   UTL_StripTrailingSpaces(RS.sFltNbr);
   UTL_StripTrailingSpaces(RS.sFltOrigCtyId);
   UTL_StripTrailingSpaces(RS.sFltDestCtyId);
   UTL_StripTrailingSpaces(RS.sLegMileage);
   UTL_StripTrailingSpaces(RS.sPsgrInfo);
   UTL_StripTrailingSpaces(RS.sTourCode);
   UTL_StripTrailingSpaces(RS.sFareBasis);
   UTL_StripTrailingSpaces(RS.sTktDesignator);

   // Convert a few of the integer fields
   RS.nTktDocSqNb   = atoi(RS.sTktDocSqNb);
   RS.nTktCpnNb     = atoi(RS.sTktCpnNb);
   RS.lLegMileage   = atol(RS.sLegMileage);

   // Transform Ticket Issue Date from YYYY-MM-DD to YYYYMMDD, then convert to standard database format
   memcpy(RS.sTktDocIssDt,0, sizeof(RS.sTktDocIssDt));
   if (isdigit(RPAD_REC->TKT_DOC_ISS_LDT[0])) {
      memcpy(&RS.sTktDocIssDt[0], &RPAD_REC->TKT_DOC_ISS_LDT[0], 4);
      memcpy(&RS.sTktDocIssDt[4], &RPAD_REC->TKT_DOC_ISS_LDT[5], 2);
      memcpy(&RS.sTktDocIssDt[6], &RPAD_REC->TKT_DOC_ISS_LDT[8], 2);
      pTemp = UTL_ConvertDate(RS.sTktDocIssDt, CNV_YYYYMMDD_TO_DB);
      strncpy(RS.sTktDocIssDt, pTemp, sizeof(RS.sTktDocIssDt));
   }

   // Transform Flight Departure Date from YYYY-MM-DD to YYYYMMDD, then convert to standard database format
   memcpy(RS.sFltDprtDt,0, sizeof(RS.sFltDprtDt));
   if (isdigit(RPAD_REC->SCHD_DPRT_LDT[0])) {
      memcpy(&RS.sFltDprtDt[0], &RPAD_REC->SCHD_DPRT_LDT[0],   4);
      memcpy(&RS.sFltDprtDt[4], &RPAD_REC->SCHD_DPRT_LDT[5],   2);
      memcpy(&RS.sFltDprtDt[6], &RPAD_REC->SCHD_DPRT_LDT[8],   2);
      pTemp = UTL_ConvertDate(RS.sFltDprtDt, CNV_YYYYMMDD_TO_DB);
      strncpy(RS.sFltDprtDt, pTemp, sizeof(RS.sFltDprtDt));
   }

   RS.cRoundTripInd = RPAD_REC->RND_TRP_IND;
   if (RS.cRoundTripInd != 'N' && RS.cRoundTripInd != 'Y')
      RS.cRoundTripInd = 'Y';                                     // Fix, but this is supposed to be a RT program

   RS.cTktExchdInd  = RPAD_REC->TKT_DOC_EXCG_IND;

   // Quick Fix to help tie all the legs together   (DEllis 4/24/2010)
   if (RS.cTktExchdInd == 'Y'  && strcmp(RS.sOrglTktNbr, NULL_STRING)) {
      strncpy(RS.sPriTktDocNb, RS.sOrglTktNbr, 15);
   }

}


/******************************************************************
**                                                               **
** Function Name:   TPM_4000_ProcessFlownFLeg                    **
**                                                               **
** Description:     Main function to process RPAD data and data  **
**                  from suspense and insert records into the    **
**                  NRAP_FLWN_FL table.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
** Note: The two things that are iffy in this module are:        **
**       1. We can't be absolutely certain about the NRev_Nbr    **
**       2. We can't be absolutely certain about nNrapTrpSqNb    **
**                                                               **
**                                                               **
******************************************************************/

void TPM_4000_ProcessFlownLeg()
{
   int ENCIcertificate_found;
   int award_found;
   int ppr_valid;
   int nrev_valid;
   int nrev_assigned;
   int dup_fleg_found;


   /*****   Initialize award fields needed for NRAP_FLWN_FL   *****/
   strcpy(RS.sNrapCd,          NULL_STRING);
   RS.nNrapSpgmNb              = 0;
   strcpy(RS.sNrapFrstBkgLdt,  NULL_STRING);
   RS.nNrapTrpSqNb             = 0;

   /*********   See if we might have an associated ticket already on file ***********/
   if (TPM_8012_FindRelatedTkt(RS.sPriTktDocNb) == true)
   {
      //***  found related ticket.  PprNbr, NRevNbr, and Award fields are now populated!  ***/
   }

   /*********   Obtain PPR Number and NRev Number from other fields  ***********/

   //-- If PPR Number hasn't been provided, then obtain from PAX_INFO_TXT
   if (strcmp(RS.sPprNbr, NULL_STRING) == 0) {
      TPM_8001_GetPPRfromPaxInfo();
   }

   //-- If still no PPR Number, then try to obtain from TOUR_CODE
   if (strcmp(RS.sPprNbr, NULL_STRING) == 0) {
      TPM_8002_GetPPRfromTourCode();
   }

   // If NRev_Nbr wasn't provided then default to "00"
   if (strcmp(RS.sNrevNbr, NULL_STRING) == 0) {
      strcpy(RS.sNrevNbr, "00");
   }

   /****   See if this is a Skeletal RPAD record (No Flt Nbr, Orig City, Dest City, or FltDprtDt) ******/
   if (strcmp(RS.sFltNbr,   "00000") == 0  &&
       strcmp(RS.sFltOrigCtyId, "-") == 0  &&
       strcmp(RS.sFltDestCtyId, "-") == 0)
   {
      printf("Skeletal RPAD record detected. Record Ignored.\n");
      printf("  PPR=%s, TktNbr=%s, TktDocSqNb=%i, Cpn=%i, Flt Info=%s %s %s %10.10s\n",
         RS.sPprNbr, RS.sTktDocNbr, RS.nTktDocSqNb,
         RS.nTktCpnNb, RS.sFltNbr, RS.sFltOrigCtyId, RS.sFltDestCtyId, RS.sFltDprtDt);
      RS.Ignore_Cnt++;
      return;
   }

   //--- Audit Flight Data fields
   if (strcmp(RS.sFltOrigCtyId, NULL_STRING) == 0  ||
       strlen(RS.sFltOrigCtyId) < 3                ||
       strcmp(RS.sFltDestCtyId, NULL_STRING) == 0  ||
       strlen(RS.sFltDestCtyId) < 3                ||
       strcmp(RS.sFltDprtDt,    NULL_STRING) == 0  ||
       strcmp(RS.sFltNbr,       NULL_STRING) == 0  ||
       strcmp(RS.sFltNbr,       "00000")     == 0  ||
       strcmp(RS.sLegMileage,   NULL_STRING) == 0  ||
       RS.lLegMileage == 0)
   {
      //TPM_6000_SuspendRecord(SPNS_TXT_MISSING_FLT_DATA);     /* Stop generating error: 8/10/2011 DEllis */
      return;
   }

   //--- Audit Ticket Data fields
   if (strcmp(RS.sPriTktDocNb,  NULL_STRING) == 0  ||
       strcmp(RS.sTktDocNbr,    NULL_STRING) == 0  ||
       strcmp(RS.sTktDocIssDt,  NULL_STRING) == 0  ||
       strcmp(RS.sTktDocSqNb,   NULL_STRING) == 0  ||
       strcmp(RS.sTktCpnNb,     NULL_STRING) == 0  ||
       RS.nTktDocSqNb == 0)
   {
      TPM_6000_SuspendRecord(SPNS_TXT_MISSING_TKT_DATA);
      return;
   }

   //--- Ensure Tkt fields are numeric and in range
   if (! isAllNumeric(RS.sPriTktDocNb,13)  ||
       ! isAllNumeric(RS.sTktDocNbr,  13)  ||
       ! isAllNumeric(RS.sTktDocSqNb,  3)  ||
       ! isAllNumeric(RS.sTktCpnNb,    3)  ||
        (RS.nTktCpnNb < 1)                 ||
        (RS.nTktCpnNb > 4)                 ||

       // If Orig (or Certificate) exists make sure it is all numeric
       (isdigit(RS.sOrglTktNbr[0]) && ! isAllNumeric(RS.sOrglTktNbr,13)))
   {
      TPM_6000_SuspendRecord(SPNS_TXT_INVALID_TKT_DATA);
      return;
   }

   // Now check to see if we've already processed this Flown Flight Leg.
   // If we have already processed this leg, then log and toss this record.
   //
   // Note: Apparently this won't stop all legs that can cause integrity constraint
   //       errors (e.g. same Passenger on Same flight with 2 different tickets
   //       which shouldn't happen, but does) so we'll catch those during the INSERT
   dup_fleg_found = TPM_8011_FindDuplicateFlownFLeg();
   if (dup_fleg_found == true) {
      printf("Flown FLeg already on file. Record Ignored.\n");
      printf("  TktNbr=%s, TktDocSqNb=%i, Cpn=%i, Flt Info=%s %s %s %10.10s\n",
         RS.sTktDocNbr, RS.nTktDocSqNb, RS.nTktCpnNb,
         RS.sFltNbr, RS.sFltOrigCtyId, RS.sFltDestCtyId, RS.sFltDprtDt);
      RS.Ignore_Cnt++;
      return;
   }

   /*****   If Recognition Award Filter enabled AND the Tkt Designator is
            one of the recognition awards then ignore record   *****/
   if (RS.fIgnoreRecognitionAwardPgm)
   {
      if (strstr(RS.sTktDesignator, RECOGNITION_AWARD_DOMESTIC) ||
          strstr(RS.sTktDesignator, RECOGNITION_AWARD_ASIA))
      {
         printf("Recognition Award Filter Enabled\n");
         //TPM_6000_SuspendRecord(SPNS_TXT_FILTER_ENABLED);       /* Stop generating error: 8/10/2011 DEllis */
         return;
      }
   }


   /*****  If no Award info yet, look up Award using Ticket Designator  ****/
   if (strcmp(RS.sNrapCd, NULL_STRING) == 0  ||
       RS.nNrapSpgmNb == 0  ||
       strcmp(RS.sNrapFrstBkgLdt, NULL_STRING) == 0)
   {

       /*****  Look up Award using Ticket Designator  ****/
       award_found = TPM_8008_GetAwardInfoUsingTktDsgtr();
       if (award_found == false) {
         TPM_6000_SuspendRecord(SPNS_TXT_UNKNOWN_DESIGNATOR);
         return;
       }

       /*****   Detect and perform special handling of ENCI Awards   *****/
       if (strstr(RS.sTktDesignator, "FR") &&              // Is this an ENCI Award?
           strcmp(RS.sPprNbr, NULL_STRING) == 0)
       {
          // We need now need a Certificate Nbr to process ENCI Awards, so if it's missing we're done!
          if (strcmp(RS.sOrglTktNbr, NULL_STRING) == 0) {
             TPM_6000_SuspendRecord(SPNS_TXT_MISSING_CERTIFICATE);
             return;
          }

          //***  Look up Certificate in Cross-Reference table: NRAP_CRTF  ***
          //***  and get PPR Nbr and award associated with this certificate
          ENCIcertificate_found = TPM_8007_GetAwardInfoFromNRAP_CRTF();
          if (ENCIcertificate_found == false) {
             TPM_6000_SuspendRecord(SPNS_TXT_NO_CROSS_REFERENCE);
             return;
          }
       }
   }


   /*****  Validate PPR Number *****/
   ppr_valid = false;
   if (strcmp(RS.sPprNbr, NULL_STRING)) {
      ppr_valid = TPM_8004_ValidatePPR();
   }
   if (ppr_valid == false) {
      TPM_6000_SuspendRecord(SPNS_TXT_NEED_PPR_NBR);
      return;
   }


   /*****  Validate NRev_Nbr *****/
   nrev_valid = TPM_8005_ValidateNRevNbr();
   if (nrev_valid == false) {
      TPM_6000_SuspendRecord(SPNS_TXT_NEED_NREV_NBR);
      return;
   }

   /*****  Assign Trip Sq Nb and NRevNbr *****/
   if (RS.nNrapTrpSqNb == 0) {
      TPM_8009_FindBooking();       // This function does a lookup in union of NRAP_BKG and NRAP_PPR_ELGY tables
      TPM_8010_AssignNRevNbr();     // Make sure NRevNbr is properly assigned
   }

   //--- Audit Award Data fields
   if (strcmp(RS.sNrapCd,         NULL_STRING) == 0  ||
       strcmp(RS.sNrapFrstBkgLdt, NULL_STRING) == 0  ||
       RS.nNrapSpgmNb  == 0 ||
       RS.nNrapTrpSqNb == 0)
   {
      TPM_6000_SuspendRecord(SPNS_TXT_MISSING_AWARD_DATA);
      return;
   }


   // We can now insert Flown Flight Leg
   TPM_5000_InsertFlownFLeg();


   // Update the Associated Booking as "Flown" (if it exists)
   // Note:  set Bkg Status = 'FL' if nrap_bkg_stt_cd in ('OB','RR','PD');
   TPM_8300_UpdateBooking();

}


/******************************************************************
**                                                               **
** Function Name:   TPM_5000_InsertFlownFLeg                     **
**                                                               **
** Description:     Call function to insert a record into the    **
**                  NRAP_FLWN_FL table                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_5000_InsertFlownFLeg()
{
   memset(&R04740, LOW_VALUES, sizeof(_R04740));
   memset(&A04740, LOW_VALUES, sizeof(_A04740));

   strcpy(R04740.R04740_appl_area.sPprNbr,          RS.sPprNbr);
   strcpy(R04740.R04740_appl_area.sNrevNbr,         RS.sNrevNbr);
   strcpy(R04740.R04740_appl_area.sFltOrigCtyId,    RS.sFltOrigCtyId);
   strcpy(R04740.R04740_appl_area.sFltDestCtyId,    RS.sFltDestCtyId);
   strcpy(R04740.R04740_appl_area.sFltDprtDt,       RS.sFltDprtDt);
   strcpy(R04740.R04740_appl_area.sFltNbr,          RS.sFltNbr);
   strcpy(R04740.R04740_appl_area.sNrapCd,          RS.sNrapCd);
   R04740.R04740_appl_area.nNrapSpgmNb            = RS.nNrapSpgmNb;
   strcpy(R04740.R04740_appl_area.sNrapFrstBkgLdt,  RS.sNrapFrstBkgLdt);
   R04740.R04740_appl_area.nNrapTrpSqNb           = RS.nNrapTrpSqNb;
   strcpy(R04740.R04740_appl_area.sTktDocNb,        RS.sTktDocNbr);
   strcpy(R04740.R04740_appl_area.sTktDocIssLdt,    RS.sTktDocIssDt);
   R04740.R04740_appl_area.nTktDocSqNb            = RS.nTktDocSqNb;
   R04740.R04740_appl_area.nTktCpnNb              = RS.nTktCpnNb;
   R04740.R04740_appl_area.cRndTrpInd             = RS.cRoundTripInd;
   R04740.R04740_appl_area.lFltLegMiCt            = RS.lLegMileage;
   strcpy(R04740.R04740_appl_area.sPriTktDocNb,     RS.sPriTktDocNb);
   strcpy(R04740.R04740_appl_area.sProcdForImptnDt, LOW_DATE);
   strcpy(R04740.R04740_appl_area.sLstUpdtId,       MODULE_NAME);


   /*******Write to RPAD_FLWN_FL_SPNS ***/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0, &R04740, &A04740, SERVICE_ID_04740, 1, sizeof(R04740.R04740_appl_area));

   switch (nSvcRtnCd)
   {
     case ARC_SUCCESS:
        RS.Flown_FL_Cnt++;
        break;
     case ARC_DUPLICATE_ROW:
        RS.Error_Cnt++;
        //TPM_6000_SuspendRecord(SPNS_TXT_DUPLICATE_LEG);   /* Stop generating error: 8/10/2011 DEllis */
        break;
     default:
        RS.Error_Cnt++;   // Log runtime error
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS04740");
        sprintf(sErrorMessage,
           "\n  PPR=%s-%s, TktNbr=%s, TktDocSqNb=%i, Cpn=%i, Flt Info=%s %s %s %10.10s",
           R04740.R04740_appl_area.sPprNbr,
           R04740.R04740_appl_area.sNrevNbr,
           R04740.R04740_appl_area.sTktDocNb,
           R04740.R04740_appl_area.nTktDocSqNb,
           R04740.R04740_appl_area.nTktCpnNb,
           R04740.R04740_appl_area.sFltNbr,
           R04740.R04740_appl_area.sFltOrigCtyId,
           R04740.R04740_appl_area.sFltDestCtyId,
           R04740.R04740_appl_area.sFltDprtDt);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5000_InsertFlownFLeg");
        break;
   }

}

/******************************************************************
**                                                               **
** Function Name:   TPM_6000_SuspendRecord                       **
**                                                               **
** Description:     Call function to suspend the Flown Data      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_6000_SuspendRecord(char *reason)
{

   printf("Record Suspended. Reason=\"%s\"\n", reason);
   printf("  PPR=%s-%s, TktNbr=%s, TktDocSqNb=%i, Cpn=%i, Flt Info=%s %s %s %10.10s\n",
      RS.sPprNbr, RS.sNrevNbr, RS.sTktDocNbr, RS.nTktDocSqNb,
      RS.nTktCpnNb, RS.sFltNbr, RS.sFltOrigCtyId, RS.sFltDestCtyId, RS.sFltDprtDt);


 // Check to see if record already on file
   memset(&R04734, LOW_VALUES, sizeof(_R04734));
   memset(&A04734, LOW_VALUES, sizeof(_A04734));

   strcpy(R04734.R04734_appl_area.sPriTktDocNb,    RS.sPriTktDocNb);
   strcpy(R04734.R04734_appl_area.sTktDocNb,       RS.sTktDocNbr);
   strcpy(R04734.R04734_appl_area.sTktDocIssLdt,   RS.sTktDocIssDt);
   R04734.R04734_appl_area.nTktDocSqNb           = RS.nTktDocSqNb;
   R04734.R04734_appl_area.nTktCpnNb             = RS.nTktCpnNb;
   strcpy(R04734.R04734_appl_area.sPaxFrstNm,      RS.sPaxFirstName);
   strcpy(R04734.R04734_appl_area.sPaxLstNm,       RS.sPaxLastName);
   strcpy(R04734.R04734_appl_area.sFltNbr,         RS.sFltNbr);
   strcpy(R04734.R04734_appl_area.sFltOrigCtyId,   RS.sFltOrigCtyId);
   strcpy(R04734.R04734_appl_area.sFltDestCtyId,   RS.sFltDestCtyId);
   strcpy(R04734.R04734_appl_area.sTktDsgtrTxt,    RS.sTktDesignator);
   strcpy(R04734.R04734_appl_area.sDataUpdtMsgTxt, reason);
   strcpy(R04734.R04734_appl_area.sLstUpdtId,      MODULE_NAME);


   // Select record from RPAD_FLWN_FL_SPNS that matches all these fields
   nSvcRtnCd = BCH_InvokeService(EPBUPD0, &R04734, &A04734, SERVICE_ID_04734, 1, sizeof(R04734.R04734_appl_area));

   // If record found then there's no sense in writing duplicate record to Suspense
   if (nSvcRtnCd == ARC_SUCCESS) {
      RS.DupSuspense_Cnt++;
      return;
   }


   // Format record to write to RPAD_FLWN_FL_SPNS
   memset(&R04732, LOW_VALUES, sizeof(_R04732));
   memset(&A04732, LOW_VALUES, sizeof(_A04732));

   strcpy(R04732.R04732_appl_area.sPriTktDocNb,    RS.sPriTktDocNb);
   strcpy(R04732.R04732_appl_area.sTktDocNb,       RS.sTktDocNbr);
   strcpy(R04732.R04732_appl_area.sTktDocIssLdt,   RS.sTktDocIssDt);
   R04732.R04732_appl_area.nTktDocSqNb           = RS.nTktDocSqNb;
   strcpy(R04732.R04732_appl_area.sOrglTktDocNb,   RS.sOrglTktNbr);
   strcpy(R04732.R04732_appl_area.sFltNbr,         RS.sFltNbr);
   R04732.R04732_appl_area.nTktCpnNb             = RS.nTktCpnNb;
   strcpy(R04732.R04732_appl_area.sPaxFrstNm,      RS.sPaxFirstName);
   strcpy(R04732.R04732_appl_area.sPaxLstNm,       RS.sPaxLastName);
   strcpy(R04732.R04732_appl_area.sPaxInfoTxt,     RS.sPsgrInfo);
   strcpy(R04732.R04732_appl_area.sPprNbr,         RS.sPprNbr);
   strcpy(R04732.R04732_appl_area.sNrevNbr,        RS.sNrevNbr);
   strcpy(R04732.R04732_appl_area.sFltDprtDt,      RS.sFltDprtDt);
   strcpy(R04732.R04732_appl_area.sFltOrigCtyId,   RS.sFltOrigCtyId);
   strcpy(R04732.R04732_appl_area.sFltDestCtyId,   RS.sFltDestCtyId);
   strcpy(R04732.R04732_appl_area.sTktDsgtrTxt,    RS.sTktDesignator);
   R04732.R04732_appl_area.lGrtCrclMiCt          = RS.lLegMileage;
   R04732.R04732_appl_area.cRndTrpInd            = RS.cRoundTripInd;
   strcpy(R04732.R04732_appl_area.sDataUpdtMsgTxt, reason);
   strcpy(R04732.R04732_appl_area.sTourCdTxt,      RS.sTourCode);
   strcpy(R04732.R04732_appl_area.sLstUpdtId,      MODULE_NAME);


   // Write record to RPAD_FLWN_FL_SPNS
   nSvcRtnCd = BCH_InvokeService(EPBUPD0, &R04732, &A04732, SERVICE_ID_04732, 1, sizeof(R04732.R04732_appl_area));

   switch (nSvcRtnCd)
   {
     case ARC_SUCCESS:
        RS.Suspense_Cnt++;
        break;
    default:
        RS.Error_Cnt++;   // Log runtime error
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS04732");
        sprintf(sErrorMessage,
           "\n  PPR=%s-%s, TktNbr=%s, TktDocSqNb=%i, Cpn=%i, Flt Info=%s %s %s %10.10s",
           R04732.R04732_appl_area.sPprNbr,
           R04732.R04732_appl_area.sNrevNbr,
           R04732.R04732_appl_area.sTktDocNb,
           R04732.R04732_appl_area.nTktDocSqNb,
           R04732.R04732_appl_area.nTktCpnNb,
           R04732.R04732_appl_area.sFltNbr,
           R04732.R04732_appl_area.sFltOrigCtyId,
           R04732.R04732_appl_area.sFltDestCtyId,
           R04732.R04732_appl_area.sFltDprtDt);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_6000_SuspendRecord");
        break;
   }

}


/******************************************************************
**                                                               **
** Function Name:   TPM_8001_GetPPRfromPaxInfo                   **
**                                                               **
** Description:     Call function to process fetch the PPR and   **
**                  NRev_Nbr from the Passenger Info Text field  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void TPM_8001_GetPPRfromPaxInfo()
{
   int i;

   // Format should be "PPR999999999-99"
   // Often the PPR is missing! Often the -99 is missing!
   memset(RS.sPprNbr, 0, sizeof(RS.sPprNbr));
   memset(RS.sNrevNbr, 0, sizeof(RS.sNrevNbr));

   // find 9 consecutive digits in a row
   for (i=0; i < sizeof(RS.sPsgrInfo); i++)
   {
      if (isdigit(RS.sPsgrInfo[i+0]) &&
          isdigit(RS.sPsgrInfo[i+1]) &&
          isdigit(RS.sPsgrInfo[i+2]) &&
          isdigit(RS.sPsgrInfo[i+3]) &&
          isdigit(RS.sPsgrInfo[i+4]) &&
          isdigit(RS.sPsgrInfo[i+5]) &&
          isdigit(RS.sPsgrInfo[i+6]) &&
          isdigit(RS.sPsgrInfo[i+7]) &&
          isdigit(RS.sPsgrInfo[i+8]))
      {
         TPM_8003_GetPPRandNRevNbr(&RS.sPsgrInfo[i]);
         break;
      }
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8002_GetPPRfromTourCode                  **
**                                                               **
** Description:     Call function to process fetch the PPR       **
**                  number from the Tour Code field.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_8002_GetPPRfromTourCode()
{
   int i;

   // Format is "PPR999999999DL or PPR123456NW
   // Note: Often the PPR, DL or NW are missing, so don't rely on them!
   memset(RS.sPprNbr, 0, sizeof(RS.sPprNbr));
   memset(RS.sNrevNbr, 0, sizeof(RS.sNrevNbr));

   // find at least 6 consecutive digits in a row
   for (i=0; i < sizeof(RS.sTourCode); i++)
   {
      if (isdigit(RS.sTourCode[i+0]) &&
          isdigit(RS.sTourCode[i+1]) &&
          isdigit(RS.sTourCode[i+2]) &&
          isdigit(RS.sTourCode[i+3]) &&
          isdigit(RS.sTourCode[i+4]) &&
          isdigit(RS.sTourCode[i+5]))
      {
         TPM_8003_GetPPRandNRevNbr(&RS.sTourCode[i]);
         break;
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   TPM_8003_GetPPRfromPPRText                   **
**                                                               **
** Description:     Call function to obtain the PPR number when  **
**                  "PPR" text is specified                      **
**                                                               **
** Arguments:       Pointer to PPR+3 data (e.g.employee number)  **
**                                                               **
******************************************************************/
void TPM_8003_GetPPRandNRevNbr(char *pstr)
{
   int i, len;
   char *nptr;

   // Get PPR number and NRev Number
   if (pstr)
   {
      // Count the number of consecutive digits
      for (i=0, len=0; i < 10 && isdigit(pstr[i]); i++) {
         len++;
      }
      // only use if 6 digits or 9 digits
      if (len == 6 || len == 9) {
         strncpy(RS.sPprNbr, pstr, len);

         // Now go after NRevNbr
         nptr = strstr(pstr, "-");
         if (nptr && isdigit(nptr[1]) &&  isdigit(nptr[2])) {
            strncpy(RS.sNrevNbr, &nptr[1], 2);
         }
      }

      // If exactly 6 digits, look up DL PPR using NW Empl Nbr
      if (len == 6) {
         strcpy(&RS.sPprNbr[6], "NW");
         TPM_8006_GetPPRusingNWEmplNbr();
      }
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8004_ValidatePPR                         **
**                                                               **
** Description:     Call function to validate the PPR number.    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F   (true = PPR valid)                     **
**                                                               **
**                                                               **
******************************************************************/

int TPM_8004_ValidatePPR()
{
   int ppr_valid = false;

   memset(&R03834, LOW_VALUES, sizeof(_R03834));
   memset(&A03834, LOW_VALUES, sizeof(_A03834));
   strcpy(R03834.R03834_appl_area.sPprNbr, RS.sPprNbr);

   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03834,&A03834,SERVICE_ID_03834,1,sizeof(_R03834_APPL_AREA));

   if (nSvcRtnCd == ARC_SUCCESS) {
      ppr_valid = true;
   }

   return ppr_valid;
}

/******************************************************************
**                                                               **
** Function Name:   TPM_8005_ValidateNRevNbr                     **
**                                                               **
** Description:     Call function to process ????                **
**                  records then read next record from buffer.   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F  (true = NRevNbr is valid)               **
**                                                               **
**                                                               **
******************************************************************/

int TPM_8005_ValidateNRevNbr()
{

   // Validate NRev_Nbr.  Always assume "00" is valid since that's the employee.
   // Skip validation on NRev Nbrs of 40-59
   if (strcmp(RS.sNrevNbr, "00") == 0  ||
       *RS.sNrevNbr == '4' ||
       *RS.sNrevNbr == '5')
   {
      return true;
   }

   memset(&R02437, LOW_VALUES, sizeof(R02437));
   memset(&A02437, LOW_VALUES, sizeof(A02437));
   strcpy(R02437.R02437_appl_area.sPprNbr,  RS.sPprNbr);
   strcpy(R02437.R02437_appl_area.sNrevNbr, RS.sNrevNbr);

   // Service 2437 is used to validate
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02437,&A02437,
                                 SERVICE_ID_02437,1,sizeof(_R02437_APPL_AREA));

   return (nSvcRtnCd == ARC_SUCCESS) ? true : false;
}

/******************************************************************
**                                                               **
** Function Name:   TPM_8006_GetPPRusingNWEmplNbr                **
**                                                               **
** Description:     Call function to obtain the Delta PPR using  **
**                  the 6 digit NW Employee number               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F  (true = PPR found using NW Empl Nbr)    **
**                                                               **
**                                                               **
******************************************************************/

int TPM_8006_GetPPRusingNWEmplNbr()
{
   int ppr_found = false;

   // Get PPR_NBR based on NW_PPR_Nbr
   memset(&R04728, LOW_VALUES, sizeof(R04728));
   memset(&A04728, LOW_VALUES, sizeof(A04728));
   strncpy(R04728.R04728_appl_area.sNwEmplNb, RS.sPprNbr, 6);

   nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04728, &A04728, SERVICE_ID_04728, 1, sizeof(R04728.R04728_appl_area));

   if (nSvcRtnCd == ARC_SUCCESS) {
      strncpy(RS.sPprNbr, A04728.A04728_appl_area.sPprNbr,sizeof(RS.sPprNbr));
      ppr_found = true;
   }

   return ppr_found;
}

/******************************************************************
**                                                               **
** Function Name:   TPM_8007_GetAwardInfoFromNRAP_CRTF           **
**                                                               **
** Description:     Call function to obtain PPR and related      **
**                  Award Program data from the NRAP_CRTF table  **
**                  using a certificate.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F (true = Certificate found in NRAP_CRTF)  **
**                                                               **
******************************************************************/

int TPM_8007_GetAwardInfoFromNRAP_CRTF()
{
   int certificate_found = false;
   int update_status = false;
   char *psCurTktDocNb, *psCurTktDocIssDt;

   memset(&R04743, LOW_VALUES, sizeof(R04743));
   memset(&A04743, LOW_VALUES, sizeof(A04743));

   //------
   // Locate Certificate in Cross-Reference table: NRAP_CRTF
   //------

   // Compare Certificate (OrglTktNbr) to NRAP_CRTF.Cur_Tkt_Doc_Nb
   memset(&R04741, LOW_VALUES, sizeof(R04741));
   memset(&A04741, LOW_VALUES, sizeof(A04741));

   strcpy(R04741.R04741_appl_area.sCertificate, RS.sOrglTktNbr);

   nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04741, &A04741, SERVICE_ID_04741, 1, sizeof(R04741.R04741_appl_area));

   if (nSvcRtnCd == ARC_SUCCESS)
   {
      certificate_found = true;
      strcpy(RS.sPprNbr,         A04741.A04741_appl_area.sPprNbr);
      strcpy(RS.sNrapCd,         A04741.A04741_appl_area.sNrapCd);
      RS.nNrapSpgmNb           = A04741.A04741_appl_area.nNrapSpgmNb;
      strcpy(RS.sNrapFrstBkgLdt, A04741.A04741_appl_area.sNrapFrstBkgLdt);

      // Prepare to update Certificate Status
      if (A04741.A04741_appl_area.cNrapCrtfSttCd != 'C') {
         psCurTktDocNb    = A04741.A04741_appl_area.sCurTktDocNb;
         psCurTktDocIssDt = A04741.A04741_appl_area.sCurTkDcIssDt;
         update_status = true;
      }
   }
   else {

      // Compare Certificate (OrglTktNbr) to NRAP_CRTF.Init_Tkt_Doc_Nb
      strcpy(R04742.R04742_appl_area.sCertificate, RS.sOrglTktNbr);
      memset(&A04742, LOW_VALUES, sizeof(A04742));

      nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04742, &A04742, SERVICE_ID_04742, 1, sizeof(R04742.R04742_appl_area));

      if (nSvcRtnCd == ARC_SUCCESS)
      {
         certificate_found = true;
         strcpy(RS.sPprNbr,         A04742.A04742_appl_area.sPprNbr);
         strcpy(RS.sNrapCd,         A04742.A04742_appl_area.sNrapCd);
         RS.nNrapSpgmNb           = A04742.A04742_appl_area.nNrapSpgmNb;
         strcpy(RS.sNrapFrstBkgLdt, A04742.A04742_appl_area.sNrapFrstBkgLdt);

         // Prepare to update Certificate Status
         if (A04742.A04742_appl_area.cNrapCrtfSttCd != 'C') {
            psCurTktDocNb    = A04742.A04742_appl_area.sCurTktDocNb;
            psCurTktDocIssDt = A04742.A04742_appl_area.sCurTkDcIssDt;
            update_status = true;
         }
      }
   }

   // Since we are processing a flown segment and the Certificate was found,
   // set the Certificate's status to "Completed"
   if (update_status)
   {
      strcpy(R04743.R04743_appl_area.sCurTktDocNb,    psCurTktDocNb);
      strcpy(R04743.R04743_appl_area.sCurTktDocIssDt, psCurTktDocIssDt);
      R04743.R04743_appl_area.cCrtfSttCd = 'C';
      strcpy(R04743.R04743_appl_area.sLstUpdtId, MODULE_NAME);

      nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04743, &A04743, SERVICE_ID_04743, 1, sizeof(R04743.R04743_appl_area));
   }

   return certificate_found;

}


/******************************************************************
**                                                               **
** Function Name:   TPM_8008_GetAwardInfoUsingTktDsgtr           **
**                                                               **
** Description:     Call function to obtain the award program    **
**                  information using the Ticket Designator      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F  (true = award found using TktDsgtr)     **
**                                                               **
**                                                               **
******************************************************************/

int TPM_8008_GetAwardInfoUsingTktDsgtr()
{
   int award_found = false;

   memset(&R04744, LOW_VALUES, sizeof(_R04744));
   memset(&A04744, LOW_VALUES, sizeof(_A04744));

   strcpy(R04744.R04744_appl_area.sTktDsgtrTxt, RS.sTktDesignator);

   nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04744, &A04744, SERVICE_ID_04744, 1, sizeof(R04744.R04744_appl_area));

   if (nSvcRtnCd == ARC_SUCCESS)
   {
      award_found = true;
      strcpy(RS.sNrapCd,         A04744.A04744_appl_area.sNrapCd);
      strcpy(RS.sNrapFrstBkgLdt, A04744.A04744_appl_area.sNrapFrstBkgLdt);
      RS.nNrapSpgmNb           = A04744.A04744_appl_area.nNrapSpgmNb;
   }

   return award_found;
}


/***********************************************************************
**                                                                    **
** Function Name:   TPM_8009_FindBooking                              **
**                                                                    **
** Description:     Call function to assign Nrap_Trp_Sq_Nb from a     **
**                  related booking for this flown fleg               **
**                                                                    **
** Return Values:   T/F  (true = Bkng Found; Nrap_Trp_Sq_Nb assigned) **
**                                                                    **
** Step 1. Stored Procedure first uses Flt_Dprt_Dt to find Bkng       **
** Step 2, If bkng not found, use row from NRAP_PPR_ELGY.             **
**                                                                    **
***********************************************************************/

int TPM_8009_FindBooking()
{
   int related_bkg_found = false;

   // Open Cursor and obtain related booking (the first row returned is the one we want)
   memset(&R04755, LOW_VALUES, sizeof(R04755));
   memset(&A04755, LOW_VALUES, sizeof(A04755));
   //printf("TPM_8009_FindBooking() - sPprNbr=%s, sNrapCd=%s, sFltDprtDt=%s\n", RS.sPprNbr, RS.sNrapCd, RS.sFltDprtDt);
   strcpy(R04755.R04755_appl_area.sPprNbr,    RS.sPprNbr);
   strcpy(R04755.R04755_appl_area.sNrapCd,    RS.sNrapCd);
   strcpy(R04755.R04755_appl_area.sFltDprtDt, RS.sFltDprtDt);
   R04755.R04755_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   nSvcRtnCd = BCH_InvokeService(EPBINQ1, &R04755, &A04755, SERVICE_ID_04755, 1, sizeof(R04755.R04755_appl_area));

   // We just loaded a related booking out of the database - use information to update award fields.
   if (nSvcRtnCd == ARC_SUCCESS) {

      strcpy(RS.sNrapCd,         A04755.A04755_appl_area.sNrapCd);
      RS.nNrapSpgmNb           = A04755.A04755_appl_area.nNrapSpgmNb;
      strcpy(RS.sNrapFrstBkgLdt, A04755.A04755_appl_area.sNrapFrstBkgLdt);
      RS.nNrapTrpSqNb          = A04755.A04755_appl_area.nNrapTrpSqNb;
      printf("   TPM_8009_FindBooking() - Found related booking: Src=%s, PPR=%s, NrapCd=%s %i\n",
        A04755.A04755_appl_area.sSrcTblNm,
        A04755.A04755_appl_area.sPprNbr,
        A04755.A04755_appl_area.sNrapCd,
        A04755.A04755_appl_area.nNrapTrpSqNb);
      related_bkg_found = true;
   }

   // Close the cursor
   R04755.R04755_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
   BCH_InvokeService(EPBINQ1, &R04755, &A04755, SERVICE_ID_04755, 1, sizeof(R04755));

   return related_bkg_found;
}

/******************************************************************
**                                                               **
** Function Name:   TPM_8010_AssignNRevNbr                       **
**                                                               **
** Description:     Call function to shore up the Nrap_Trp_Sq_Nb **
**                  and possibly override the NRev Nbr.          **
**                                                               **
** Arguments:       None  (NRevNbr may already be initialized)   **
**                                                               **
** Return Values:   T/F  (true = NRevNbr successfully assigned)  **
**                                                               **
**                                                               **
** Note: This function is quite fragile. There were a lot of     **
** data issues that had to be accounted for and handled which    **
** ripple down into subsequent modules, so be VERY careful if    **
** you try to update or change this function in any way.         **
**     Duane Ellis   4/25/2010                                   **
**                                                               **
******************************************************************/

int TPM_8010_AssignNRevNbr()
{
   int index;
   int nrev_assigned = false;
   int highest_NrapTrpSqNb = 0;
   int highest_NRevNbr = -1;
   int need_to_override_nrev = false;
   int need_to_override_TrpSqNb = false;

   char sNRevNbrs[20][3] = {"40","41","42","43","44","45","46","47","48","49",
                            "50","51","52","53","54","55","56","57","58","59"};


   // Iterate through all the Flown Legs in the database for this PPR & Award and see
   // what kind of NRevNbrs are already in play
   memset(&R04736, LOW_VALUES, sizeof(R04736));
   memset(&A04736, LOW_VALUES, sizeof(A04736));

   strcpy(R04736.R04736_appl_area.sPprNbr,         RS.sPprNbr);
   strcpy(R04736.R04736_appl_area.sNrapCd,         RS.sNrapCd);
   R04736.R04736_appl_area.nNrapSpgmNb           = RS.nNrapSpgmNb;
   strcpy(R04736.R04736_appl_area.sNrapFrstBkgLdt, RS.sNrapFrstBkgLdt);

   R04736.R04736_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   nSvcRtnCd = BCH_InvokeService(EPBINQ1, &R04736, &A04736, SERVICE_ID_04736, 1, sizeof(R04736.R04736_appl_area));

   while (nSvcRtnCd == ARC_SUCCESS)
   {
      // If the Primary Ticket Numbers match, then use this NRev Nbr and Nrap_Trip_Sq_nb
      if (strcmp(A04736.A04736_appl_area.sPrmyTktDocNb, RS.sPriTktDocNb) == 0) {
         strcpy(RS.sNrevNbr, A04736.A04736_appl_area.sNrevNbr);
         RS.nNrapTrpSqNb   = A04736.A04736_appl_area.nNrapTrpSqNb;

         // Close the cursor
         R04736.R04736_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
         BCH_InvokeService(EPBINQ1, &R04736, &A04736, SERVICE_ID_04736, 1, sizeof(R04736));

         return (nrev_assigned = true);
      }

      // If related Trip Date already resides in NRAP_FLWN_FL then the TrpSeqNb
      // is related and has to be over-ridden with a sequentially higher number
      if (strcmp(A04736.A04736_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId) == 0 &&
          strcmp(A04736.A04736_appl_area.sFltDestCtyId, RS.sFltDestCtyId) == 0 &&
          strcmp(A04736.A04736_appl_area.sFltDprtDt,    RS.sFltDprtDt)    == 0 &&
          strcmp(A04736.A04736_appl_area.sFltNbr,       RS.sFltNbr)       == 0)
      {
          need_to_override_TrpSqNb = true;

          // Since Primary Ticket Numbers don't match, this is a different person or trip
          // If the NrevNbrs match, then we obviously need to override it
          if (strcmp(A04736.A04736_appl_area.sNrevNbr,  RS.sNrevNbr) == 0) {
             need_to_override_nrev = true;
          }
      }

      // Keep track of the highest sequence number we've encountered
      if (highest_NrapTrpSqNb < A04736.A04736_appl_area.nNrapTrpSqNb)
         highest_NrapTrpSqNb = A04736.A04736_appl_area.nNrapTrpSqNb;

      // Keep track of the highest Travel Companion Number we encounter
      if (*A04736.A04736_appl_area.sNrevNbr >= '4') {
         for (index=0; index<20; index++) {
            if (strcmp(A04736.A04736_appl_area.sNrevNbr, sNRevNbrs[index]) == 0  &&  highest_NRevNbr < index)
               highest_NRevNbr = index;
         }
      }


      // Next NRAP_FLWN_FL Record
      memset(&R04736, LOW_VALUES, sizeof(R04736));
      memset(&A04736, LOW_VALUES, sizeof(A04736));
      R04736.R04736_appl_area.cArchCursorOpTxt = FETCH_ROW;
      nSvcRtnCd = BCH_InvokeService(EPBINQ1, &R04736, &A04736, SERVICE_ID_04736, 1, sizeof(R04736.R04736_appl_area));
   }

   // Close the cursor
   R04736.R04736_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
   BCH_InvokeService(EPBINQ1, &R04736, &A04736, SERVICE_ID_04736, 1, sizeof(R04736));


   // Issue: TPA RES was assigning NRevNbr of '00' for EVERYBODY, so sometimes we have to
   // override the NRevNbr with a new number.if it's a different person in the same trip.
   if (need_to_override_nrev == true) {
      strcpy(RS.sNrevNbr, sNRevNbrs[highest_NRevNbr + 1]);
   }

   if (RS.nNrapTrpSqNb == 0 || need_to_override_TrpSqNb) {
      RS.nNrapTrpSqNb = highest_NrapTrpSqNb + 1;
   }

   return (nrev_assigned = true);
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8011_FindDuplicateFlownFLeg()            **
**                                                               **
** Description:     Call function to see if there is a matching  **
**                  flown flight leg in the database.            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F - True=Matching Leg found                **
**                                                               **
**                                                               **
******************************************************************/

int TPM_8011_FindDuplicateFlownFLeg()
{
   int dup_fleg_found = false;

   memset(&R04738, LOW_VALUES, sizeof(_R04738));
   memset(&A04738, LOW_VALUES, sizeof(_A04738));

   strcpy(R04738.R04738_appl_area.sPprNbr,RS.sPprNbr);
   strcpy(R04738.R04738_appl_area.sFltOrigCtyId,RS.sFltOrigCtyId);
   strcpy(R04738.R04738_appl_area.sFltDestCtyId,RS.sFltDestCtyId);
   strcpy(R04738.R04738_appl_area.sFltDprtDt,RS.sFltDprtDt);
   strcpy(R04738.R04738_appl_area.sFltNbr,RS.sFltNbr);
   strcpy(R04738.R04738_appl_area.sTktDocNbr,RS.sTktDocNbr);
   strcpy(R04738.R04738_appl_area.sTktDocIssLdt,RS.sTktDocIssDt);
   R04738.R04738_appl_area.nTktDocSqNb = RS.nTktDocSqNb;
   R04738.R04738_appl_area.nTktCpnNb = RS.nTktCpnNb;

   nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04738, &A04738, SERVICE_ID_04738, 1, sizeof(R04738.R04738_appl_area));

   if (nSvcRtnCd == ARC_SUCCESS) {
      dup_fleg_found = true;
   }

   return dup_fleg_found;
}

/******************************************************************
**                                                               **
** Function Name:   TPM_8012_FindRelatedTkt()                    **
**                                                               **
** Description:     Call function to see if there are any        **
**                  related tickets in the database.             **
**                                                               **
** Arguments:       Primary Ticket Document Number               **
**                                                               **
** Return Values:   T/F - True=Related Leg found                 **
**                                                               **
**                                                               **
******************************************************************/

int TPM_8012_FindRelatedTkt(char *sPrmyTktDocNb)
{
   int related_tkt_found = false;

   // Open Cursor and read in first Coupon
   memset(&R04746, LOW_VALUES, sizeof(R04746));
   memset(&A04746, LOW_VALUES, sizeof(A04746));
   strcpy(R04746.R04746_appl_area.sPrmyTktDocNb, sPrmyTktDocNb);
   R04746.R04746_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   nSvcRtnCd = BCH_InvokeService(EPBINQ1, &R04746, &A04746, SERVICE_ID_04746, 1, sizeof(R04746.R04746_appl_area));

   // We just loaded a related coupon out of the database - use information from it to override certain fields.
   if (nSvcRtnCd == ARC_SUCCESS) {
      strcpy(RS.sPprNbr,         A04746.A04746_appl_area.sPprNbr);
      strcpy(RS.sNrevNbr,        A04746.A04746_appl_area.sNrevNbr);

      strcpy(RS.sNrapCd,         A04746.A04746_appl_area.sNrapCd);
      RS.nNrapSpgmNb           = A04746.A04746_appl_area.nNrapSpgmNb;
      strcpy(RS.sNrapFrstBkgLdt, A04746.A04746_appl_area.sNrapFrstBkgLdt);
      RS.nNrapTrpSqNb          = A04746.A04746_appl_area.nNrapTrpSqNb;

      related_tkt_found = true;
   }

   // Close the cursor
   R04746.R04746_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
   BCH_InvokeService(EPBINQ1, &R04746, &A04746, SERVICE_ID_04746, 1, sizeof(R04746));

   return related_tkt_found;
}


/*********************************************************************
**                                                                  **
** Function Name:   TPM_8100_GetSuspenseRecToReprocess              **
**                                                                  **
** Description:     Call function to suspend locate Suspense record **
**                  to reprocess (LstUpdtId = 'PASS2000')           **
**                                                                  **
** Arguments:       None                                            **
**                                                                  **
** Return Values:   SpnsSeqNbr (key) of Suspense Record             **
**                                                                  **
**                                                                  **
**********************************************************************/

long TPM_8100_GetSuspenseRecToReprocess()
{
   long lSpnsSqNb = 0L;

 // Check to see if record already on file
   memset(&R04733, LOW_VALUES, sizeof(_R04733));
   memset(&A04733, LOW_VALUES, sizeof(_A04733));

   strcpy(R04733.R04733_appl_area.sLstUpdtId, PASS2000_MODULE);


   // Select record from RPAD_FLWN_FL_SPNS that matches all these fields
   nSvcRtnCd = BCH_InvokeService(EPBUPD0, &R04733, &A04733, SERVICE_ID_04733, 1, sizeof(R04733.R04733_appl_area));

   // If record found then there's no sense in writing duplicate record to Suspense
   if (nSvcRtnCd == ARC_SUCCESS)
   {
      lSpnsSqNb               = A04733.A04733_appl_area.lSpnsSqNb;

      strcpy(RS.sPriTktDocNb,   A04733.A04733_appl_area.sPriTktDocNb);
      strcpy(RS.sTktDocNbr,     A04733.A04733_appl_area.sTktDocNb);
      strcpy(RS.sTktDocIssDt,   A04733.A04733_appl_area.sTktDocIssLdt);
      RS.nTktDocSqNb          = A04733.A04733_appl_area.nTktDocSqNb;
      strcpy(RS.sOrglTktNbr,    A04733.A04733_appl_area.sOrglTktDocNb);
      strcpy(RS.sFltNbr,        A04733.A04733_appl_area.sFltNbr);
      RS.nTktCpnNb            = A04733.A04733_appl_area.nTktCpnNb;
      strcpy(RS.sPaxFirstName,  A04733.A04733_appl_area.sPaxFrstNm);
      strcpy(RS.sPaxLastName,   A04733.A04733_appl_area.sPaxLstNm);
      strcpy(RS.sPsgrInfo,      A04733.A04733_appl_area.sPaxInfoTxt);
      strcpy(RS.sPprNbr,        A04733.A04733_appl_area.sPprNbr);
      strcpy(RS.sNrevNbr,       A04733.A04733_appl_area.sNrevNbr);
      strcpy(RS.sFltDprtDt,     A04733.A04733_appl_area.sFltDprtDt);
      strcpy(RS.sFltOrigCtyId,  A04733.A04733_appl_area.sFltOrigCtyId);
      strcpy(RS.sFltDestCtyId,  A04733.A04733_appl_area.sFltDestCtyId);
      strcpy(RS.sTktDesignator, A04733.A04733_appl_area.sTktDsgtrTxt);
      RS.lLegMileage          = A04733.A04733_appl_area.lGrtCrclMiCt;
      RS.cRoundTripInd        = A04733.A04733_appl_area.cRndTrpInd;
      strcpy(RS.sTourCode,      A04733.A04733_appl_area.sTourCdTxt);

      sprintf(RS.sTktDocSqNb,"%03u", A04733.A04733_appl_area.nTktDocSqNb);
      sprintf(RS.sTktCpnNb,  "%03u", A04733.A04733_appl_area.nTktCpnNb);
      sprintf(RS.sLegMileage,"%08lu",A04733.A04733_appl_area.lGrtCrclMiCt);

      // Remove trailing spaces from string variables
      UTL_StripTrailingSpaces(RS.sPprNbr);
      UTL_StripTrailingSpaces(RS.sNrevNbr);
      UTL_StripTrailingSpaces(RS.sPriTktDocNb);
      UTL_StripTrailingSpaces(RS.sTktDocNbr);
      UTL_StripTrailingSpaces(RS.sOrglTktNbr);
      UTL_StripTrailingSpaces(RS.sPaxFirstName);
      UTL_StripTrailingSpaces(RS.sPaxLastName);
      UTL_StripTrailingSpaces(RS.sFltNbr);
      UTL_StripTrailingSpaces(RS.sFltOrigCtyId);
      UTL_StripTrailingSpaces(RS.sFltDestCtyId);
      UTL_StripTrailingSpaces(RS.sPsgrInfo);
      UTL_StripTrailingSpaces(RS.sTourCode);
      UTL_StripTrailingSpaces(RS.sFareBasis);
      UTL_StripTrailingSpaces(RS.sTktDesignator);

      if (strcmp(RS.sTktDocIssDt, LOW_DATE) == 0)
         strcpy(RS.sTktDocIssDt, NULL_STRING);

      if (strcmp(RS.sFltDprtDt, LOW_DATE) == 0)
         strcpy(RS.sFltDprtDt, NULL_STRING);

      // Delete Suspense Record. (However, it's possible we may add a new one back again!)
      TPM_8200_DeleteSpnsRecord(lSpnsSqNb);

   }

   return (lSpnsSqNb);
}

/******************************************************************
**                                                               **
** Function Name:   TPM_8200_DeleteSpnsRecord                    **
**                                                               **
** Description:     Call function to delete a record from        **
**                  RPAD_FLWN_FL_SPNS table using key            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void  TPM_8200_DeleteSpnsRecord(long lSpnsSqNb)
{

   // Rather than delete the suspense record we are going to update the LstUpdtId = "epb40000-IT"
   memset(&R04735, LOW_VALUES, sizeof(_R04735));
   memset(&A04735, LOW_VALUES, sizeof(_A04735));

   R04735.R04735_appl_area.lSpnsSqNb = lSpnsSqNb;
   strcpy(R04735.R04735_appl_area.sLstUpdtId, DELETE_UPDT_ID);

   nSvcRtnCd = BCH_InvokeService(EPBUPD0, &R04735, &A04735, SERVICE_ID_04735, 1, sizeof(R04735.R04735_appl_area));
   switch (nSvcRtnCd)
   {
     case ARC_SUCCESS:
        RS.SPNS_Delete_Cnt++;
        break;
     default:
        RS.Error_Cnt++;   // Log runtime error
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS04735");
        sprintf(sErrorMessage,"Unable to delete record from RPAD_FLWN_FL_SPNS. spns_sq_nb: %ld", lSpnsSqNb);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8600_DeleteSpnsRecord");
        break;
   }

}

/******************************************************************
**                                                               **
** Function Name:   TPM_8300_UpdateBooking                       **
**                                                               **
** Description:     Update Booking Status in associated booking  **
**                  as "Flown" (FL) using Trip Info to find Bkg  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F  (SQL execution of update successful)    **
**                                                               **
**                                                               **
******************************************************************/

int TPM_8300_UpdateBooking()
{

   // Locate and update the Associated Booking (if it exists)
   // and set Booking Status to "Flown" ("FL")
   memset(&R04748, LOW_VALUES, sizeof(_R04748));
   memset(&A04748, LOW_VALUES, sizeof(_A04748));

   strcpy(R04748.R04748_appl_area.sPprNbr,         RS.sPprNbr);
   strcpy(R04748.R04748_appl_area.sNrapCd,         RS.sNrapCd);
   R04748.R04748_appl_area.nNrapSpgmNb           = RS.nNrapSpgmNb;
   strcpy(R04748.R04748_appl_area.sNrapFrstBkgLdt, RS.sNrapFrstBkgLdt);
   strcpy(R04748.R04748_appl_area.sFltOrigDt,      RS.sFltDprtDt);
   strcpy(R04748.R04748_appl_area.sFltOrigCtyId,   RS.sFltOrigCtyId);
   strcpy(R04748.R04748_appl_area.sLstUpdtId,      MODULE_NAME);

   nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04748, &A04748, SERVICE_ID_04748, 1, sizeof(R04748.R04748_appl_area));

   return (nSvcRtnCd == ARC_SUCCESS) ?  true : false;
}


/******************************************************************
**                                                               **
** Function Name:   TPM_9000_ProcessEndOfProgram                 **
**                                                               **
** Description:     Call function to perform end of program      **
**                  housekeeping (close files, print summary)    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void TPM_9000_ProcessEndOfProgram(int runMode)
{
   static char totals_buffer[1024];

   endTime_ = time(0);

   /** Include any logic here for final clean-up processing  **/

   /************************/
   /**    CLOSE FILES     **/
   /************************/
   if (runMode == RPAD_MODE) {
      if (RS.EPBF010 != BCH_FAIL)
         BCH_Close(RS.EPBF010);
   }

   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, VersionStr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9000_ProcessEndOfProgram");


   /************************/
   /**    CONTROL TOTALS  **/
   /************************/

   sprintf(totals_buffer,
      "\n********* Module Information **********\n"
      "  Processing Totals:\n"
      "    RPAD Records Processed       : %lu\n"
      "    Suspense Records Reprocessed : %lu\n"
      "    Flown FLeg Records Written   : %lu\n"
      "    Records Written to Suspense  : %lu\n"
      "    Matching Records in Flown_FL : %lu\n"
      "    Matching Records in Suspense : %lu\n"
      "    Records Ignored              : %lu\n"
      "    Runtime Errors               : %lu",
      RS.RPAD_Rec_Cnt,
      RS.SPNS_Rec_Cnt,
      RS.Flown_FL_Cnt,
      RS.Suspense_Cnt,
      RS.DupFlownFL_Cnt,
      RS.DupSuspense_Cnt,
      RS.Ignore_Cnt,
      RS.Error_Cnt);
   puts(totals_buffer);        // print totals

   // Print start and end time;
   //     Note: can't call these both in the same call because
   //     time is stored in a static buffer.
   printf("    Time Job started:      %s",   asctime(localtime(&startupTime_)));
   printf("    Time Job completed:    %s\n", asctime(localtime(&endTime_)));

}


static void write_to_log(char a[],char b[],char c[])
{
   FILE *fp;
   fp=fopen("mylog.txt","a");
   if (fp) {
      fprintf(fp,"%s-%s-%s\n", a,b,c);
      fclose(fp);
   }
}

static int EnvValueToBOOL(const char *value)
{
   if (value)
   {
      if (!strcasecmp(value, "on")      ||
          !strcasecmp(value, "true")    ||
          !strcasecmp(value, "yes")     ||
          !strcasecmp(value, "1")       ||
          !strcasecmp(value, "enabled"))
      {
         return true;
      }
   }
   return false;
}

static int isAllNumeric(char *str, int len)
{
   char *tend;

   for (tend = str+len ; str < tend; str++) {
      if (!isdigit(*str))
         return 0;
   }
   return 1;
}



