/****************************************************************************
**                                                                         **
** File Name :      EPB97201.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB97201 module.                                   **
**                                                                         **
** Author :         TransQuest, Inc.                                       **
**                  Shridev Makim                                          **
**                                                                         **
** Date Created:    December 03, 1997                                      **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
****************************************************************************/
#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"

/*
 * You should include any subsytem header files here. For example:
 * #include "subsystem_db_io/current_date.h"
 *
 */

/*
 * No report sort and data layouts  
 */

/*
 * Service request and answer blocks
 */

#include "fyr04627.h"      /* service request layout */
#include "fya04627.h"      /* service answer layout  */
#include "fyr04628.h"      /* service request layout */
#include "fya04628.h"      /* service answer layout  */
 
_R04627 R04627;            /* Service Request Layout */
_A04627 A04627;            /* Service Answer Layout  */
_R04628 R04628;            /* Service Request Layout */
_A04628 A04628;            /* Service Answer Layout  */

#define SERVICE_ID_04627  4627
#define SERVICE_ID_04628  4628


/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_3500_MarkRecordsProcessed();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS 2   /** Number of threads used **/
#define EPBINQ0 0             /** Inquiry thread **/
#define EPBUPD0 1             /** Inquiry thread **/

#define SPACE               ' '

#define BLCKLIST_REC_FORMAT     "%-2s%-10s%c"
#define BLCKLIST_IDENTIFIER     "BL"

short     nSvcRtnCd;          /** Service return code **/
int 	  ntotal_record_cntr;

static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/
   int EPBF020;                   /** Output file **/


   /******   Save database buffer here:              ******/
   char   sPprNbr[10];                 /** PPR ID **/
   char   sCertftExtnNbr[11];              /** Certificate Nbr **/


   /******   @read_into structure/buffers go here:   ******/
   char   EPBF020_buffer[13];

   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   /*******   counters and accumulators              ******/
   int   total_record_cntr;

   char    end_of_save;

}  RS;
