/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5016                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/02/2000                                              */
/*              Time: 13:44:15                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5016                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5016_RPTDATASTRUCT_z                                                  
#define _S5016_RPTDATASTRUCT_z                                                  
typedef struct __S5016_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5016_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5016_z                                                             
#define _EPRS5016_z                                                             
                                                                                
   typedef struct __EPRS5016                                                    
   {                                                                            
      _S5016_RPTDATASTRUCT S5016_RptDataStruct;                                 
   }  _EPRS5016;                                                                
#endif                                                                          
                                                                                
