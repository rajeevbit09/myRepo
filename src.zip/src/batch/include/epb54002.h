/****************************************************************************
**                                                                         **
** File Name :      EPB54002.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Transquest Information Solutions                       **
**                  Faith Ammons>                                          **
**                                                                         **
** Date Created:    8/16/95                                                **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 8/21/96    G. Melton                   Added Worldspan o/p file         **
**                                                                         **
** 8/24/98    L. Walker                   Added changes for delayed billing**
**					  feature.                         **
**                                                                         **
** 8/15/00    E. Shelton                  Added changes for COMAIR         **
**                                                                         **
**                                                                         **
** 3/10/03    L. Scott                    Added changes for Song           **
**                                                                         **
** 4/29/03    L. Scott                    Added changes for Song detail    **
**                                        file.                            **
**                                                                         **
** 7/11/03    L. Scott                    Added changes for Comair         **
**                                        Academy.                         **
**                                                                         **
** 2/08/04    L.Scott                     Added changes fro ACA (DH),      **
**                                        Chautuagua (RP) and SkyWest (OO).**
**                                                                         **
** 6/16/04    L.Scott                     Added changes for Skyway (AL).   **
**                                                                         **
** 7/20/06    E. Shelton                  Added changes for Shuttle (S5)   **
**                                        and Freedom(F8)                  **
**                                                                         **
** 2/20/07    L.Scott                     Added changes for Big Sky (GQ)   **
**                                        and Express Jet (XE).            **
**                                                                         **
** 11/19/07   L.Scott                     Added changes for Pinnacle (9E). **
** 03/18/09   G.Whitman                   Added changes for Masaba   (XJ). **
** 03/18/09   G.Whitman                   Added changes for MLT     (MLT). **
** 03/18/09   G.Whitman                   Added changes for Compass  (CP). **
** 10/26/09   G.Whitman                   Added changes for Regional (RS). **
** 11/01/10   G.Whitman                   Added billing file for DGS (DS). **
** 12/15/11   M.Lewis                     Added GoJet file (G7)            **
** 12/19/12   B.Ellison                   Added Delta Private Jet file(PJ) **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/* Report sort and data layouts   */
#include "feps0540.h" 
#include "fepf0540.h"
#include "feps0541.h"
#include "fepf0541.h"

_EPRF0540 EPRF0540; 
_EPRS0540 EPRS0540;
_EPRF0541 EPRF0541;
_EPRS0541 EPRS0541;


/* Service request and answer blocks  */
#include "fyr02665.h"    
#include "fya02665.h"   
#include "fyr02666.h"  
#include "fya02666.h" 
#include "fyr02667.h"    
#include "fya02667.h"   
#include "fyr02529.h"  
#include "fya02529.h" 
#include "fyr02754.h"  
#include "fya02754.h" 
#include "fyr03932.h"  
#include "fya03932.h" 
#include "fyr04621.h"  
#include "fya04621.h" 
#include "fyr04622.h"  
#include "fya04622.h" 
#include "fyr04624.h"  
#include "fya04624.h" 
 
_R02665 R02665;      
_A02665 A02665;     
_R02666 R02666;    
_A02666 A02666;   
_R02667 R02667;      
_A02667 A02667;     
_R02529 R02529;    
_A02529 A02529;   
_R02754 R02754;    
_A02754 A02754;   
_R03932 R03932;   
_A03932 A03932;   
_R04621 R04621;   
_A04621 A04621;   
_R04622 R04622;   
_A04622 A04622;   
_R04624 R04624;   
_A04624 A04624;   

#define SERVICE_ID_02665  2665
#define SERVICE_ID_02666  2666
#define SERVICE_ID_02667  2667
#define SERVICE_ID_02529  2529
#define SERVICE_ID_02754  2754
#define SERVICE_ID_03932  3932
#define SERVICE_ID_04621  4621
#define SERVICE_ID_04622  4622
#define SERVICE_ID_04624  4624

/* Function definitions   */
void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_2520_UpdateProcessDate();
void    DPM_2550_WriteEmployeeAR();
void    DPM_2560_WriteWorldspan();
void    DPM_2570_WriteSong();
void    DPM_2580_WriteSkywest();
void    DPM_2581_WriteChatauqua();
void    DPM_2582_WriteShuttle();
void    DPM_2583_WriteFreedom();
void    DPM_2584_WriteASA();
void    DPM_2585_WriteBigSky();
void    DPM_2586_WriteExpressJet();
void    DPM_2587_WritePinnacle();
void    DPM_2588_WriteXJ();
void    DPM_2589_WriteMLT();
void    DPM_2590_WriteCP();
void    DPM_2591_WriteRS();
void    DPM_2592_WriteDGS();
void    DPM_2593_WriteG7();
void    DPM_2594_WritePJ();
void    DPM_3000_WriteTotals();
void    DPM_4920_ProcessLUW();
void    DPM_5000_GenerateEPB54011();
void    DPM_5010_GenerateEPB54012();
void    DPM_5020_GenerateEPB54013();
void    DPM_5030_GenerateEPB54014();
void    DPM_5040_GenerateEPB54015();
void    DPM_5040_GenerateEPB54016();
void    DPM_5040_GenerateEPB54017();
void    DPM_5040_GenerateEPB54018();
void    DPM_5040_GenerateEPB54019();
void    DPM_5040_GenerateEPB54020();
void    DPM_5040_GenerateEPB54021();
void    DPM_5040_GenerateEPB54022();
void    DPM_5040_GenerateEPB54023();
void    DPM_5040_GenerateEPB54024();
void    DPM_5040_GenerateEPB54025();
void    DPM_5040_GenerateEPB54026();
void    DPM_5040_GenerateEPB54027();
void    DPM_5040_GenerateEPB54028();
void    DPM_5040_GenerateEPB54029();
void    DPM_5040_GenerateEPB54030();
void    DPM_5040_GenerateEPB54031();
void    DPM_9500_ProcessEndOfProgram();

/* #defines and global variables   */
#define NUMBER_OF_THREADS 3
#define EPBUPD0 0
#define EPBINQ0 1
#define EPBINQ1 2
#define WORLDSPAN_NBR "WS9999999"
#define TRANSQUEST_NBR "WS8888888"
#define TERMSCD "??"
#define MONTHLY "MM"
#define BIWEEKLY "BW"
#define YES_CHAR 'Y'
#define NO_CHAR 'N'
#define COMMA ','

char cInterfaceWritten;
char cDLPayrollInd;
char cWorldspanInd;
char cTransquestInd;
char cDeltaStaffingInd;
char cASAInd;
char cOHInd;
char cSOInd;
char cCAInd;
char cDHInd;
char cRPInd;
char cOOInd;
char cF8Ind;
char cS5Ind;
char cGQInd;
char cXEInd;
char c9EInd;
char cXJInd;
char cMLTInd;
char cCPInd;
char cRSInd;
char cG7Ind;
char cPJInd;
char cDelimiter;
char sSavePprNbr[10];
char sSavePprNbr5[6];
char sSaveNrevNbr[3];
char sSaveNrevTyp[3];
char sSaveDate[7];
char sEndOfHdr[225];
char sEndOfWSPHdr[104];
char sEndOfSKYWESTHdr[103];
char sEndOfCHATAUQUAHdr[103];
char sEndOfSHUTTLEHdr[103];
char sEndOfFREEDOMHdr[103];
char sEndOfASAHdr[103];
char sEndOfBIGSKYHdr[103];
char sEndOfEXPRESSJETHdr[103];
char sEndOfPINNACLEHdr[103];
char sEndOfMesabaHdr[103];
char sEndOfMLTHdr[103];
char sEndOfCompassHdr[103];
char sEndOfRegionalHdr[103];
char sEndOfDGSHdr[103];
char sEndOfG7Hdr[103];
char sEndOfPJHdr[103];
char sSaveSvcChrgDs[16];
char sSaveCycleId[3];
int  nNbrOfChrgs;

struct
{
char    sSvcChrgCd[3],
        sSvcChrgDs[16];
}svc_chrg[50];

#define HEADER_FORMAT "%3s%8s%6s%06d%-12s%224s"
#define EMPLAR_FORMAT "%-4s%-1c%-5s%-9s%-10s%-9s%-3s%-6s%-3s%-11s%-19s%-18s%-100s%-3s%04d%-54s"

struct
{
char    batch_nbr[5],
        batch_type,
        bus_nbr[6],
        cust_id[10],
        curr_cd[4],
        oblig_id[7],
        trans_cd[4],
        sales_dept[4],
        trans_dt[7],
        terms_cd[3],
        ref_id[10],
        vend_nm[11],
        line_cd[4],
        chg_desc[55];
 int    line_nbr;
 double chg_amt;
}EmplAR;


#define WSP_HEADER_FORMAT "%2s%8s%9s%103s"
#define WSP_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-6s%-5s%-5s%-5s%-2s%-9s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[7],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        pass_type[3],
        filler[10];
}WSP_Dtl;

#define SKYWEST_HEADER_FORMAT "%2s%8s%9s%102s"
/**#define SKYWEST_HEADER_FORMAT "%2s%8s%-1c%9s%104s" **/
#define SKYWEST_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}SKYWEST_Dtl;
 
#define CHATAUQUA_HEADER_FORMAT "%2s%8s%9s%102s"
#define CHATAUQUA_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}CHATAUQUA_Dtl;
 
#define SHUTTLE_HEADER_FORMAT "%2s%8s%9s%102s"
#define SHUTTLE_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}SHUTTLE_Dtl;
 
#define FREEDOM_HEADER_FORMAT "%2s%8s%9s%102s"
#define FREEDOM_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}FREEDOM_Dtl;
 
#define ASA_HEADER_FORMAT "%2s%8s%9s%102s"
#define ASA_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}ASA_Dtl;
 
 
#define BIGSKY_HEADER_FORMAT "%2s%8s%9s%102s"
#define BIGSKY_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}BIGSKY_Dtl;
 
 
#define EXPRESSJET_HEADER_FORMAT "%2s%8s%9s%102s"
#define EXPRESSJET_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}EXPRESSJET_Dtl;
 
#define PINNACLE_HEADER_FORMAT "%2s%8s%9s%102s"
#define PINNACLE_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}PINNACLE_Dtl;
 
#define Mesaba_HEADER_FORMAT "%2s%8s%9s%102s"
#define Mesaba_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}Mesaba_Dtl;
 
#define MLT_HEADER_FORMAT "%2s%8s%9s%102s"
#define MLT_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}MLT_Dtl;

#define Compass_HEADER_FORMAT "%2s%8s%9s%102s"
#define Compass_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}Compass_Dtl;
 
#define Regional_HEADER_FORMAT "%2s%8s%9s%102s"
#define Regional_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
        nrev_nbr[3],
        nrev_nm[31],
        nrev_typ_cd[26],
        trans_dt[9],
        chrg_typ[16],
        chrg_amt[8],
        flt_orig[6],
        flt_dest[6],
        flt_nbr[6],
        filler[13];
}Regional_Dtl;

#define DGS_HEADER_FORMAT "%2s%8s%9s%102s"
#define DGS_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
	nrev_nbr[3],
	nrev_nm[31],
	nrev_typ_cd[26],
	trans_dt[9],
	chrg_typ[16],
	chrg_amt[8],
	flt_orig[6],
	flt_dest[6],
	flt_nbr[6],
	filler[13];
}DGS_Dtl;

#define G7_HEADER_FORMAT "%2s%8s%9s%102s"
#define G7_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
	nrev_nbr[3],
	nrev_nm[31],
	nrev_typ_cd[26],
	trans_dt[9],
	chrg_typ[16],
	chrg_amt[8],
	flt_orig[6],
	flt_dest[6],
	flt_nbr[6],
	filler[13];
}G7_Dtl;

#define PJ_HEADER_FORMAT "%2s%8s%9s%102s"
#define PJ_FORMAT "%-9s%-2s%-30s%-25s%-8s%-15s%-7s%-5s%-5s%-5s%-12s"

struct
{
char    ppr_nbr[10],
	nrev_nbr[3],
	nrev_nm[31],
	nrev_typ_cd[26],
	trans_dt[9],
	chrg_typ[16],
	chrg_amt[8],
	flt_orig[6],
	flt_dest[6],
	flt_nbr[6],
	filler[13];
}PJ_Dtl;

#define SONG_HEADER_FORMAT "%7s%-1c%8s%-1c%6s%-1c%15s%-1c%17s"
#define SONG_FORMAT "%3s%-1c%8s%-1c%5s%-1c%3s%-1c%-7s"

struct
{
char    co_code[4],
        dlm1[2],
        trans_dt[9],
        dlm2[2],
        ppr_nbr[6],
        dlm3[2],
	pass_type[4],
        dlm4[2],
        chrg_amt[8];
}Song_Dtl;
 
static struct
{
   char    start_of_save;

   int EPBF020;        /** Employee A/R file     **/
   int EPBF030;        /** Worldspan file        **/
   int EPBF040;        /** Song File             **/
   int EPBF050;        /** Skywest File          **/
   int EPBF060;        /** Chatauqua File        **/
   int EPBF070;        /** Shuttle File          **/
   int EPBF080;        /** Freedom File          **/
   int EPBF081;        /** ASA File              **/
   int EPBF082;        /** Big Sky File          **/
   int EPBF083;        /** Express Jet File      **/
   int EPBF084;        /** Pinnacle File         **/
   int EPBF085;        /** Mesaba File           **/
   int EPBF086;        /** MLT File              **/
   int EPBF087;        /** Compass File          **/
   int EPBF088;        /** Regional File         **/
   int EPBF089;        /** DGS File              **/
   int EPBF090;        /** G7 file               **/
   int EPBF091;        /** PJ file               **/
   int PRAF010;        /** Report output file    **/


   char EPBF020_buffer[260];
   char EPBF030_buffer[123];
   char EPBF040_buffer[58];
   char EPBF050_buffer[122];
   char EPBF060_buffer[122];
   char EPBF070_buffer[122];
   char EPBF080_buffer[122];
   char EPBF081_buffer[122];
   char EPBF082_buffer[122];
   char EPBF083_buffer[122];
   char EPBF084_buffer[122];
   char EPBF085_buffer[122];
   char EPBF086_buffer[122];
   char EPBF087_buffer[122];	
   char EPBF088_buffer[122];
   char EPBF089_buffer[122];
   char EPBF090_buffer[122];
   char EPBF091_buffer[122];
   char sCycleId[3];

   int  TblItemsRead;
   int  EPBF020_record_cnt;
   int  EPBF030_record_cnt;
   int  EPBF040_record_cnt;
   int  EPBF050_record_cnt;
   int  EPBF060_record_cnt;
   int  EPBF070_record_cnt;
   int  EPBF080_record_cnt;
   int  EPBF081_record_cnt;
   int  EPBF082_record_cnt;
   int  EPBF083_record_cnt;
   int  EPBF084_record_cnt;
   int  EPBF085_record_cnt;
   int  EPBF086_record_cnt;
   int  EPBF087_record_cnt;
   int  EPBF088_record_cnt;
   int  EPBF089_record_cnt;
   int  EPBF090_record_cnt;
   int  EPBF091_record_cnt;
   int  LineNbr;

   double EPBF020_record_amt;
   double EPBF030_record_amt;
   double EPBF040_record_amt;
   double EPBF050_record_amt;
   double EPBF060_record_amt;
   double EPBF070_record_amt;
   double EPBF080_record_amt;
   double EPBF081_record_amt;
   double EPBF082_record_amt;
   double EPBF083_record_amt;
   double EPBF084_record_amt;
   double EPBF085_record_amt;
   double EPBF086_record_amt;
   double EPBF087_record_amt;	
   double EPBF088_record_amt;
   double EPBF089_record_amt;
   double EPBF090_record_amt;
   double EPBF091_record_amt;
   double Worldspan_amt;  
   double Transquest_amt;  
   double DeltaStaffing_amt;  
   double ASA_amt;  
   double OH_amt;  
   double SO_amt;  
   double CA_amt;  
   double OO_amt;  
   double RP_amt;  
   double F8_amt;  
   double S5_amt;  
   double SK_amt;  
   double GQ_amt;  
   double XE_amt;  
   double E9_amt;  
   double XJ_amt;
   double MLT_amt;
   double CP_amt;
   double RS_amt;
   double G7_amt;
   double PJ_amt;
   double OO_total_amt;  

   char    end_of_save;
}  RS;
