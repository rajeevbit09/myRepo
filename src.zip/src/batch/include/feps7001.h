/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS7001                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/21/95                                                */
/*              Time: 11:41:16                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS7001                           */
/******************************************************************************/
                                                                                
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef _S7001_RPTDATASTRUCT_z                                                  
#define _S7001_RPTDATASTRUCT_z                                                  
typedef struct __S7001_RptDataStruct                                            
{                                                                               
   char                sPassGrpCd[FY002488_LEN];                                
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   long                lPassTripNbr;                                            
   char                sPassRptSortDt[FY003821_LEN];                            
   short               nFltDprtTm;                                              
}  _S7001_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS7001_z                                                             
#define _EPRS7001_z                                                             
                                                                                
   typedef struct __EPRS7001                                                    
   {                                                                            
      _S7001_RPTDATASTRUCT S7001_RptDataStruct;                                 
   }  _EPRS7001;                                                                
#endif                                                                          
                                                                                
