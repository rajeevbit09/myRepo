/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF9002                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/23/95                                                */
/*              Time: 09:12:45                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF9002                           */
/******************************************************************************/
                                                                                
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef   FY002704_LEN                                                          
#define   FY002704_LEN                         6                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002495_LEN
#define   FY002495_LEN                         3 
#endif
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY003585_LEN                                                          
#define   FY003585_LEN                         27                               
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F9002_RPTDATASTRUCT_z                                                  
#define _F9002_RPTDATASTRUCT_z                                                  
typedef struct __F9002_RptDataStruct                                            
{                                                                               
   char                sPprStnId[FY002711_LEN];                                 
   char                sPprDeptNbr[FY002704_LEN];                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPprNm[FY002480_LEN];                                    
   char                sNrevNm[FY002531_LEN];                                   
   char                sNrevTypCd[FY002495_LEN];
   char                sPassTypCd[FY002496_LEN];                                
   char                sFltOrigCtyId[FY002521_LEN];                             
   char                sFltDestCtyId[FY002522_LEN];                             
   char                sFltNbr[FY002553_LEN];                                   
   char                sFltDprtDt[FY003584_LEN];                                
   char                sFltFeeBegDt[FY003585_LEN];                              
   char                sFltFeeEndDt[FY003586_LEN];                              
   char                cRecEndLineTxt;                                          
}  _F9002_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF9002_z                                                             
#define _EPRF9002_z                                                             
                                                                                
   typedef struct __EPRF9002                                                    
   {                                                                            
      _F9002_RPTDATASTRUCT F9002_RptDataStruct;                                 
   }  _EPRF9002;                                                                
#endif                                                                          
                                                                                
