/****************************************************************************
**                                                                         **
** File Name :      EPB70001.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Faith Ammons                                           **
**                                                                         **
** Date Created:    10/16/95                                               **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 3-26-02    L.Scott                     Increased max_flt_legs to 99.    **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

#include "fyr02435.h"   
#include "fya02435.h"  
#include "fyr02554.h" 
#include "fya02554.h"
#include "fyr02576.h"     
#include "fya02576.h"    
#include "fyr02775.h" 
#include "fya02775.h"     
#include "fyr02776.h"    
#include "fya02776.h"   
#include "fyr03893.h"    
#include "fya03893.h"   
#include "fyr04084.h"    
#include "fya04084.h"   

_R02435 R02435;    
_A02435 A02435;    
_R02554 R02554;   
_A02554 A02554;   
_R02576 R02576;       
_A02576 A02576;      
_R02775 R02775;   
_A02775 A02775;   
_R02776 R02776;   
_A02776 A02776;   
_R03893 R03893;     
_A03893 A03893;     
_R04084 R04084;     
_A04084 A04084;     

#define SERVICE_ID_02435  2435
#define SERVICE_ID_02554  2554
#define SERVICE_ID_02576  2576
#define SERVICE_ID_02775  2775
#define SERVICE_ID_02776  2776
#define SERVICE_ID_03893  3893
#define SERVICE_ID_04084  4084

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2100_ProcessRows();
void    DPM_2200_ProcessImputedGroup();
void    DPM_2300_CreateNonGermanTrips();
void    DPM_2310_ProcessEachTrip();
void    DPM_2320_GetDestination();
void    DPM_2400_CreateGermanTrips();
void    DPM_4100_GetPprInfo();
void    DPM_4200_GetRelatedInfo();
void    DPM_4300_CompareCity();
void    DPM_4400_CreateTripRecord();
void    DPM_4500_UpdateArray();
void    DPM_4600_GetFurthestMiles();
void    DPM_4920_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();

#define NUMBER_OF_THREADS  4    
#define EPBUPD0            0             
#define EPBUPD1            1             
#define EPBINQ0            2            
#define EPBINQ1            3           
#define MAX_FLTLEGS        99
#define NO_CHAR            'N'
#define YES_CHAR           'Y'

typedef struct
{
   char    sOrigCty[6];
   char    sDestCty[6];
   char    sDprtDt[26];
   char    sArrvDt[26];
   char    cOrigIntlInd;
   char    cOrigHubInd;
   char    sOrigReg[3];
   char    cDestIntlInd;
   char    cDestHubInd;
   char    sDestReg[3];
   char    sFltNbr[6];
   char    sTktNbr[11];
   short   nDprtTm;
   long    lRfrnDt;
   double  lMilesFlown;
   short   nTempTripNbr;
   long    nActlTripNbr;
   short   nNbrOfDays;
} fltleg;

fltleg  fltleg_data[MAX_FLTLEGS];
char    sOldPprNbr[10];
char    sOldNrevNbr[3];
char    sCity1[6];
char    sCity2[6];
char    sTripOrig[6];
char    sTripDest[6];
char    sTripDprtDt[26];
char    sTripArrvDt[26];
char    cEndOfFltLegData;
char    cGermanInd;
char    cSameCityInd;
char    cUpdateAllInd;
int     nNbrOfLegs;
int     i;
short   nSaveTripNbr;
short   nTripCnt;
short   nFuncTripNbr;
short   nArrayItem;
short   nFurthestItem;

 struct
{
   char    start_of_save;


   short   nImpFltLegCnt;      

   char    end_of_save;
}  RS;
