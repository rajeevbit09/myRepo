/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5028                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 12/12/2008                                              */
/*              Time: 10:00:00                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5028                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5028_RPTDATASTRUCT_z                                                  
#define _S5028_RPTDATASTRUCT_z                                                  
typedef struct __S5028_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5028_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5028_z                                                             
#define _EPRS5028_z                                                             
                                                                                
   typedef struct __EPRS5028                                                    
   {                                                                            
      _S5028_RPTDATASTRUCT S5028_RptDataStruct;                                 
   }  _EPRS5028;                                                                
#endif                                                                          
                                                                                
