/****************************************************************************
**                                                                         **
** File Name :      EPB81001.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB81001 module.                                   **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Kimberly Gordon                                        **
**                                                                         **
** Date Created:    December 1, 1995                                       **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** Lookup Changes 9-21-95                                                  **
**                                                                         **
** 12-28-98   LSCOTT                      Correct state codes array to     **
**                                        match codes used by the IRS      **
**                                                                         **
** 12-30--3   L Scott                     Changes in file layout to add an **
**                                        extra name field, address field  **
**                                        a ppr vendor number.             **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"

/**** No report generated from this project ****/

/**** Service request and answer blocks ****/
#include "fyr02752.h"      /** service request layout **/
#include "fya02752.h"      /** service answer layout **/
#include "fyr02780.h"      /** service request layout **/
#include "fya02780.h"      /** service answer layout **/
#include "fyr03735.h"      /** service request layout **/
#include "fya03735.h"      /** service answer layout **/
#include "fyr03736.h"      /** service request layout **/
#include "fya03736.h"      /** service answer layout **/
#include "fyr04015.h"      /** service request layout **/
#include "fya04015.h"      /** service answer layout **/
#include "fyr04261.h"      /** service request layout **/
#include "fya04261.h"      /** service answer layout **/

_R02752 R02752;        /** Service Request Layout **/
_A02752 A02752;        /** Service Answer Layout **/
_R02780 R02780;        /** Service Request Layout **/
_A02780 A02780;        /** Service Answer Layout **/
_R03735 R03735;        /** Service Request Layout **/
_A03735 A03735;        /** Service Answer Layout **/
_R03736 R03736;        /** Service Request Layout **/
_A03736 A03736;        /** Service Answer Layout **/
_R04015 R04015;        /** Service Request Layout **/
_A04015 A04015;        /** Service Answer Layout **/
_R04261 R04261;        /** Service Request Layout **/
_A04261 A04261;        /** Service Answer Layout **/

#define SERVICE_ID_02752  2752
#define SERVICE_ID_02780  2780
#define SERVICE_ID_03735  3735
#define SERVICE_ID_03736  3736
#define SERVICE_ID_04015  4015
#define SERVICE_ID_04261  4261

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_3000_WriteRecords();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS 3            /** Number of threads used **/
#define EPBINQ0 0                      /** Inquiry thread **/
#define EPBUPD0 1                      /** Update thread **/
#define EPBUPD1 2                      /** Update thread **/

#define CNTL_IND        '0'            /** Control record type indicator **/ 
#define PRSNL_IND       '2'            /** Personnel record type indicator **/
#define VCHR_IND        '4'            /** Voucher record type indicator **/
#define RUN_NBR         "13"           /** Run number **/
#define TAX_NBR         '1'            /** Tax identification number **/
#define SPACE           ' '
#define STATUS_IND      'N'            /** Status indicator for 'No' **/
#define PASS_DEPT       "956"          /** Pass Office department number **/
#define VCHR_NBR        "0000000"      /** Voucher number **/
#define PMT_TYPE        '3'            /** Type payment **/
#define TAX_AMT         "0000000000"   /** Tax amount **/


/**** State Equivalency array ***/
char *pStateStruct[]=
  {"AL", "AK", "  ", "AZ", "AR", "CA", "CZ", "CO", "CT", "DE", "DC", "FL", 
  "GA", "GU", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", 
  "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", 
  "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "PR", "RI", 
  "SC", "SD", "TN", "TX", "UT", "VT", "VA", "VI", "WA", "WV", "WI", "WY"};


/**** Format strings for structures ****/
#define HDR_FMT "%c%-2s%-2s%-486s"
#define PRSNL_REC_FMT "%c%-9s%c%-29s%c%-10s%-29s%c%-10s%-29s%-2s%-9s%02d%c%-13s%-3s%-10s%-40s%-40s%-251s"
#define VCHR_REC_FMT  "%c%-9s%-7s%c%-10s%-10s%-453s"

short          nSvcRtnCd;              /** Service return code **/

static struct
{
   char    		start_of_save;

   /**** Restart save area ****/

   /**** RSAMFILE filename declaration ****/
   int 		EPBF020;


   /**** @read_into structure/buffer ****/
   char                 EPBF020_buffer[501];

   /**** Save database buffer here ****/

   int                  EPBF020_record_cntr;     /** Records processed accumulator **/

   double               EPBF020_record_amt;      /** Imputed wage accumulator **/

   short                nCntlFileWrttn;          /** Control file flag **/

   char                 sPprNbr[10],             /** PPR number **/
                        sBegDt[11],               /** Flight beginning date **/
                        sEndDt[11];               /** Filght ending date **/


   char                 end_of_save;
}  RS;


/**** Control record structure ****/
struct
{
   char                 cRecTypInd,              /** Type indicator **/
                        sTaxYr[3],               /** Current tax year **/
                        sRunNbr[3],              /** Run number **/
                        sFiller[487];
} CntlRec;
 

/**** Personnel record structure ****/
struct
{  
   char                 cRecTypInd,              /** Type indicator **/
                        sPprSocSecNbr[10],       /** PPR social security number **/
                        cTaxNbr,                 /** Tax type identification number **/
                        sPpr1Nm[30],             /** PPR full name **/
                        cFiller1,
                        sPpr2Nm[11],             /** Name field **/
                        sPpr1Addr[30],           /** PPR address 1 **/
                        cOvfwInd,                /** Overflow indicator **/
                        sPpr2Addr[11],           /** PPR address 2 **/
                        sPprCtyAddr[30],         /** PPR city **/
                        sPprStCd[3],             /** PPR state code **/
                        sPprZipAddr[10],         /** PPR zip code **/
                        cStsInd,                 /** Status indicator **/ 
                        sFiller2[14],
                        sDeptNbr[4],             /** Department number **/
			sPprVendor[11],          /** PPR number (vendor) **/
			sPpr2Name[41],           /** PPR full name #2 **/
			sPpr2Address[41],        /** PPR address #2 **/
                        sFiller3[251];

   short                nPprStNbr;               /** PPR converted state code number **/

} PrsnlRec;


/**** Voucher record structure ****/
struct
{
   char                 cRecTypInd,              /** Type indicator **/
                        sPprSocSecNbr[10],       /** PPR social security number **/
                        sVchrNbr[8],             /** Voucher number **/
                        cPmtTypCd,               /** Type payment **/
                        sFltImptWageAmt[11],     /** Imputed trip wage total **/
                        sTaxAmt[11],             /** Tax amount **/
                        sFiller[453];
} VchrRec;
