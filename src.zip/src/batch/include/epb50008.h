/****************************************************************************
**                                                                         **
** File Name :      EPB50008.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Delta Air Lines                                        **
**                  Gay Whitman                                            **
**                                                                         **
** Date Created:                                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"

/**** since this is just a balancing module, there are no services ***/

/* Function definitions */
void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessInterfaceRecords();
void    DPM_4920_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();


#define NUMBER_OF_THREADS 1  
#define EPBINQ0 0         
#define YES_CHAR	'Y'
#define NO_CHAR         'N'

char cEndOfData;
char sFileMsg[40];

static struct
{
   char    		start_of_save;
   int   		EPBF010,
                        EPBF020,
                        EPBF030,
                        EPBF040;
   char                 EPBF010_buffer[109],
                        sHdrId[4],
                        sHdrDt[9],
                        sHdrTm[9],
                        sHdrCnt[8],
                        sFileSrc[4],
                        cErrorInd,
			cErrorRec,
                        cFirstReadInd;
   int                  nTotHdrCnt;
   int                  EPBF010_nRcdRead;
   int                  EPBF020_nRcdWrit;
   char    		end_of_save;
} RS;

