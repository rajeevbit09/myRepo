/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF7001                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/21/95                                                */
/*              Time: 13:04:40                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF7001                           */
/******************************************************************************/
                                                                                
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002489_LEN                                                          
#define   FY002489_LEN                         26                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002631_LEN                                                          
#define   FY002631_LEN                         1                                
#endif                                                                          
#ifndef   FY002838_LEN                                                          
#define   FY002838_LEN                         6                                
#endif                                                                          
#ifndef   FY002839_LEN                                                          
#define   FY002839_LEN                         6                                
#endif                                                                          
#ifndef   FY003581_LEN                                                          
#define   FY003581_LEN                         27                               
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F7001_RPTDATASTRUCT_z                                                  
#define _F7001_RPTDATASTRUCT_z                                                  
typedef struct __F7001_RptDataStruct                                            
{                                                                               
   char                sPassGrpCd[FY002488_LEN];                                
   char                sPassGrpDs[FY002489_LEN];                                
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltNbr[FY002553_LEN];                                   
   char                sFltOrigCtyId[FY002521_LEN];                             
   short               nFltDprtTm;                                              
   char                sFltDestCtyId[FY002522_LEN];                             
   short               nFltArrTm;                                               
   long                lPassTripNbr;                                            
   char                cFltMatchInd;                                            
   char                sFltTripOrigId[FY002838_LEN];                            
   char                sFltTripDestId[FY002839_LEN];                            
   char                sFltArrDt[FY003581_LEN];                                 
   char                sFltDprtDt[FY003584_LEN];                                
   char                cRecEndLineTxt;                                          
}  _F7001_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF7001_z                                                             
#define _EPRF7001_z                                                             
                                                                                
   typedef struct __EPRF7001                                                    
   {                                                                            
      _F7001_RPTDATASTRUCT F7001_RptDataStruct;                                 
   }  _EPRF7001;                                                                
#endif                                                                          
                                                                                
