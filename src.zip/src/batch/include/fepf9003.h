/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF9003                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/07/96                                                */
/*              Time: 11:19:22                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF9003                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002495_LEN                                                          
#define   FY002495_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002636_LEN                                                          
#define   FY002636_LEN                         16                               
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F9003_RPTDATASTRUCT_z                                                  
#define _F9003_RPTDATASTRUCT_z                                                  
typedef struct __F9003_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPprNm[FY002480_LEN];                                    
   char                sNrevNm[FY002531_LEN];                                   
   char                sNrevTypCd[FY002495_LEN];                                
   char                sFltDprtDt[FY003584_LEN];                                
   char                sSvcChrgDs[FY002636_LEN];                                
   char                sFltFeeEndDt[FY003586_LEN];                              
   //double              dCostChrgAmt;
   char                sCostChrgAmt[10];
   char                cRecEndLineTxt;                                          
}  _F9003_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF9003_z                                                             
#define _EPRF9003_z                                                             
                                                                                
   typedef struct __EPRF9003                                                    
   {                                                                            
      _F9003_RPTDATASTRUCT F9003_RptDataStruct;                                 
   }  _EPRF9003;                                                                
#endif                                                                          
                                                                                
