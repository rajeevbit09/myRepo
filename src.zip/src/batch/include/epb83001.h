/****************************************************************************
**                                                                         **
** File Name :      EPB83001.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author :         TransQuest                                             **
**                  kenneth hancock                                        **
**                                                                         **
** Date Created:    9/7/95                                                 **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**  07/26/96    FFA                       Added processing counts          **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"

/** Service request and answer blocks */

#include "fyr02824.h"      
#include "fya02824.h"     
#include "fyr02825.h"    
#include "fya02825.h"   
#include "fyr02826.h"     
#include "fya02826.h"    
#include "fyr02827.h"   
#include "fya02827.h"  
 
_R02824 R02824;        
_A02824 A02824;       
_R02825 R02825;      
_A02825 A02825;     
_R02826 R02826;       
_A02826 A02826;      
_R02827 R02827;     
_A02827 A02827;    

#define SERVICE_ID_02824 2824      
#define SERVICE_ID_02825 2825     
#define SERVICE_ID_02826 2826    
#define SERVICE_ID_02827 2827   


/* Function definitions */
 
void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_9500_ProcessEndOfProgram();

#define NUMBER_OF_THREADS 2    
#define EPBINQ0 0             
#define EPBUPD0 1            

/** #defines and global variables */

short nSvcRtnCd1;
short nSvcRtnCd;
char  cCommitInd;

struct all
  {
     char cEmplArRecInd; 
     char sPprNbr[9]; 
     char sPprNm[30];
     char sPpr1Addr[24];
     char sPpr2Addr[24];
     char sPprCtyAddr[24];
     char sPprStCd[2];
     char sPprZipAddr[9]; 
     char sPprCtryCd[3];
     char sPprPhNbr[11];
     char sFiller1[17];
     char cEmplArStsInd;
     char sEmplArActnCd[2];
     char sFiller2[5];
     char sPprSocSecNbr[12];
     char sPprStrtDt[6];
     char sEmplArTermDt[6];
     char sFiller3[64];
  } ALL;


struct hdr
  {
     char sInd[3];
     char sYear[4];
     char sMonth[2];
     char sDay[2];
     char sHr[2];
     char sMin[2];
     char sSec[2];
     char sicount[5];
     char sFiller4[228];
  } HDR;

static struct
{
   char    start_of_save;

   int EPBF010;

   char sPprNbr[10];
   char sPassDtTmTs[27]; 
   short flag;
   short nRecsRead;
   short nRecsWrit;
   short nChngCnt;
   short nAddCnt;
   char    end_of_save;
}  RS;
