/****************************************************************************
**                                                                         **
** File Name :      EPB54021.h                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.h>                                           **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB54021 module.                                   **
**                                                                         **
** Author :         Delta Technology                                       **
**                  Elona Shelton                                          **
**                                                                         **
** Date Created:    August 15, 2006                                        **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

/***************************************************************************/
/*  FUNCTION PROTOTYPES                                                    */
/***************************************************************************/
void RFM_1000_InitializeFlds();
void RFM_3000_ProcessDetail();
void RFM_3100_ProcessReportRecord();
void RFM_3200_ProcessTotals();
void RFM_4000_ProcessEndOfJob();
void RFM_5000_PageHeadings();


/**************************************************************************/
/*   CONSTANTS                                                            */
/**************************************************************************/
#define LINES_PER_PAGE 59
#define PAGE_WIDTH 132
#define DETAIL_LINE 1
#define GRAND_TOTAL_BREAK 13
#define STD_RPT_TITLE "DELTA AIR LINES, INC."

/**************************************************************************/
/*   INPUT AREA                                                           */
/**************************************************************************/
#include "frapecep.h"  
#include "feps0541.h"  
#include "fepf0541.h" 

_EPRF0541 rpt_data;
_EPRS0541 rpt_sort;

/**************************************************************************/
/*     WORK AREAS                                                         */
/**************************************************************************/

long   current;

char   cEndOfRpt,                
       sAmtFld[20],             
       sNrevNmSpaces[16],
       sSavePprNbr[10],
       sSaveNrevNbr[3], 
       sFormatFld[35], 
       sFormatFld2[35];

double dNrevTtlAmt = 0.0;
double dGrandTtlAmt = 0.0;
