/****************************************************************************
**                                                                         **
** File Name :      EPB84002.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author :         TransQuest                                             **
**                  kenneth hancock                                        **
**                                                                         **
** Date Created:    9/7/95                                                 **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 02/22/99   L.Scott                     Changed sCardIssDt size from     **
**                                        6 to 8 bytes.                    **
**                                                                         **
** 10/22/03   L.Scott                     Added variables nCoBusiness and  **
**                                        OkayToPrint.                     **
**                                                                         **
** 01/27/06   L.S                         Added activation fee paid        **
**                                        indicator to Deltamatic file.    **
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/** Service request and answer blocks */
#include "fyr04342.h"      
#include "fya04342.h"     
#include "fyr02864.h"    
#include "fya02864.h"   
#include "fyr02769.h"  
#include "fya02769.h"     
#include "fyr04054.h"    
#include "fya04054.h"   
#include "fyr04336.h"  
#include "fya04336.h"     
#include "fyr04338.h"    
#include "fya04338.h"   
 
_R04342 R04342;       
_A04342 A04342;      
_R02864 R02864;     
_A02864 A02864;    
_R02769 R02769;   
_A02769 A02769;       
_R04054 R04054;      
_A04054 A04054;     
_R04336 R04336;    
_A04336 A04336;   
_R04338 R04338;       
_A04338 A04338;      

#define SERVICE_ID_04342 4342       
#define SERVICE_ID_02864 2864      
#define SERVICE_ID_02769 2769     
#define SERVICE_ID_04054 4054    
#define SERVICE_ID_04336 4336   
#define SERVICE_ID_04338 4338  

/* Function definitions */
void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_2510_ProcessRemAllot();
void    DPM_2550_Deltamatic();
void    DPM_9500_ProcessEndOfProgram();
void    writetolog(char x[], char y[]);

#define NUMBER_OF_THREADS 3     
#define EPBINQ0 0              
#define EPBINQ1 1             
#define EPBUPD0 2

/** #defines and global variables */
short nSvcRtnCd;
short nReward15;
short nCoBusiness;

   char sSavePprNbr[10];
   char sSaveNrevNbr[3];
   char sOthrEmptCd[4];

#define REM_FORMAT "%-1c%-9s%-6s%-2s%-2s%-30s%-2s%-6s%-6s%-2s%-1c%-2s%-3s%-5s%-1c%-4s%-4s%-1c%-13s"

struct rem
{ 
   char cchngind; 
   char spprnbr[9+1]; 
   char sstrtdt[6+1]; 
   char spassgrpcd[2+1]; 
   char spsgrtypcd[2+1];  
   char spsgrnm[30+1]; 
   char snrevnbr[2+1]; 
   char sbrthdt[6+1]; 
   char scardissdt[6+1]; 
   char spassstscd[2+1]; 
   char cimptind; 
   char spasstypcd[2+1]; 
   char srembrdgs[3+1]; 
   char sremmiles[5+1]; 
   char cpassaddlind; 
   char spassbrdpriid[4+1];
   char spassupgrdpriid[4+1];
   char catvnfeepd;
   char sfiller[13+1]; 
} REM;  

static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/
   int EPBF010;

   /*******   @read_into structure/buffers go here   ******/
   char EPBF010_buffer[100];

   char sPprNbr[9+1];
   char sPprStrtDt[6+1];
   char sPassGrpCd[2+1];
   char sPsgrTypCd[2+1];
   char sPsgrNm[30+1];
   char sNrevNbr[2+1];
   char sNrevBdayDt[6+1];
   char sCardIssDt[8+1];
   char sPassStsCd[2+1];
   char cImptInd;
   char sPassTypCd[2+1];
   char cPassAddlInd;
   char sPassBrdPriId[4+1];
   char sPassUpgrdPriId[4+1];
   char sPassDtTmTs[27]; 
   char sNrevTypCd[2+1];
   char RemInd;
   char AddInd;
   char OkayToPrint;
   char cAtvnFeePd;
   int  ReadCount;
   int  ErrCount;
   int  WrtCount;
   int  NonErrCnt;
   int  tempcnt;
   short  nNrevRemnDyQty;
   long  lNrevRemnMiQty;

   char    end_of_save;
}  RS;
