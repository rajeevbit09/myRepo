/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF7143                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/24/95                                                */
/*              Time: 14:14:20                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF7143                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                          
#define   FY002516_LEN                         3
#endif
#ifndef   FY002794_LEN                                                          
#define   FY002794_LEN                         9                               
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY003581_LEN                                                          
#define   FY003581_LEN                         27                               
#endif                                                                          
#ifndef   FY002778_LEN
#define   FY002778_LEN                         11
#endif
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F7143_RPTDATASTRUCT_z                                                  
#define _F7143_RPTDATASTRUCT_z                                                  
typedef struct __F7143_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];
   char                sPprInttxNbr[FY002794_LEN];                                   
   char                sNrevNm[FY002531_LEN];                                    
   char                sFltDprtDt[FY003584_LEN];                                
   char                sFltArrDt[FY003581_LEN];
   //short               nFltDprtTm;
   char                sFltDprtTm[5];
   char                sTktNbr[FY002778_LEN];
   char                sFltDestCtyId[FY002522_LEN];                            
   char                sFltOrigCtyId[FY002521_LEN];                            
   //float               fNrevPmtAmt;
   char                sNrevPmtAmt[14];
   char                cRecEndLineTxt;                                          
}  _F7143_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF7143_z                                                             
#define _EPRF7143_z                                                             
                                                                                
   typedef struct __EPRF7143                                                    
   {                                                                            
      _F7143_RPTDATASTRUCT F7143_RptDataStruct;                                 
   }  _EPRF7143;                                                                
#endif                                                                          
                                                                                
