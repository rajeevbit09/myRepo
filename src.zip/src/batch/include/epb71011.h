/****************************************************************************
**                                                                         **
** File Name :      EPB71011.h                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.h>                                           **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shlrfmc0 module.                                   **
**                                                                         **
** Author :         Transquest                                             **
**                  Kimberly Gordon                                        **
**                                                                         **
** Date Created:    August 24, 1995                                        **
**                                                                         **
****************************************************************************/

/***************************************************************************/
/*  FUNCTION PROTOTYPES                                                    */
/***************************************************************************/

void RFM_1000_InitializeFlds();
void RFM_3000_ProcessDetail();
void RFM_3100_ProcessReportRecord();
void RFM_4000_ProcessEndOfJob();
void RFM_5000_PageHeadings();


/**************************************************************************/
/*   CONSTANTS                                                            */
/**************************************************************************/
/* these constants should be customized for each particular format module */

#define LINES_PER_PAGE 59
#define PAGE_WIDTH 132
#define DETAIL_LINE 1
#define GRAND_TOTAL_BREAK 13
#define STD_RPT_TITLE "DELTA AIR LINES, INC."

char	cEndofRpt,
	sNmericFld[11],
	sSavePassGrpCd[3],
	sSaveNrevNbr[3],
	sSaveNrevNm[30],
	sSavePprNbr[10];
	
/**************************************************************************/
/*   INPUT AREA                                                           */
/**************************************************************************/

/*
 * Report sort and data layouts
 */

#include "fepf7101.h"     /** report sort layout (name of copybook) **/
#include "feps7101.h"     /** report data layout (name of copybook) **/

_EPRF7101 rpt_data;       /** Report1 Data Layout **/
_EPRS7101 rpt_sort;       /** Report1 Sort Layout **/


/**************************************************************************/
/*     WORK AREAS                                                         */
/**************************************************************************/

long current;
