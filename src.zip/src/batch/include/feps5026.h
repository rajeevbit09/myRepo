/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5026                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/13/2007                                              */
/*              Time: 10:00:00                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5026                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5026_RPTDATASTRUCT_z                                                  
#define _S5026_RPTDATASTRUCT_z                                                  
typedef struct __S5026_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5026_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5026_z                                                             
#define _EPRS5026_z                                                             
                                                                                
   typedef struct __EPRS5026                                                    
   {                                                                            
      _S5026_RPTDATASTRUCT S5026_RptDataStruct;                                 
   }  _EPRS5026;                                                                
#endif                                                                          
                                                                                
