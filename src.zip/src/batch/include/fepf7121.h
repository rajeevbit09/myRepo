/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF7121                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 01/08/96                                                */
/*              Time: 13:41:49                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF7121                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002794_LEN                                                          
#define   FY002794_LEN                         9     
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002478_LEN                                                          
#define   FY002478_LEN                         4                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002778_LEN                                                          
#define   FY002778_LEN                         11                               
#endif                                                                          
#ifndef   FY002838_LEN                                                          
#define   FY002838_LEN                         6                                
#endif                                                                          
#ifndef   FY002839_LEN                                                          
#define   FY002839_LEN                         6                                
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef   FY002704_LEN                                                          
#define   FY002704_LEN                         6                                
#endif                                                                          
#ifndef   FY003585_LEN                                                          
#define   FY003585_LEN                         27                               
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F7121_RPTDATASTRUCT_z                                                  
#define _F7121_RPTDATASTRUCT_z                                                  
typedef struct __F7121_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sPprInttxNbr[FY002794_LEN];                                   
   long                lFltArptPrKmNbr;                                         
   char                sPprNm[FY002480_LEN];                                    
   char                sNrevNm[FY002531_LEN];                                   
   char                sPprCtryCd[FY002478_LEN];                                
   char                sFltDprtDt[FY003584_LEN];                                
   char                sTktNbr[FY002778_LEN];                                   
   char                sFltTripOrigId[FY002838_LEN];                            
   char                sFltTripDestId[FY002839_LEN];                            
   double              fFltImptValAmt;                                          
   double              fFltImptWageAmt;                                         
   float               fNrevPmtAmt;                                             
   double              fCurrExchgRatNbr;                                        
   char                sFltNbr[FY002553_LEN];                                   
   char                sPprStnId[FY002711_LEN];                                 
   char                sPprDeptNbr[FY002704_LEN];                               
   char                sFltFeeBegDt[FY003585_LEN];                              
   char                sFltFeeEndDt[FY003586_LEN];                              
   char                cRecEndLineTxt;                                          
}  _F7121_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF7121_z                                                             
#define _EPRF7121_z                                                             
                                                                                
   typedef struct __EPRF7121                                                    
   {                                                                            
      _F7121_RPTDATASTRUCT F7121_RptDataStruct;                                 
   }  _EPRF7121;                                                                
#endif                                                                          
                                                                                
