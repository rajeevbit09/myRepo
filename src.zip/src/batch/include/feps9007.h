/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS9007                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/29/96                                                */
/*              Time: 10:48:24                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS9007                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef _S9007_RPTDATASTRUCT_z                                                  
#define _S9007_RPTDATASTRUCT_z                                                  
typedef struct __S9007_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPassRptSortDt[FY003821_LEN];                            
   char                sFltNbr[FY002553_LEN];                                   
   char                sFltOrigCtyId[FY002521_LEN];                             
}  _S9007_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS9007_z                                                             
#define _EPRS9007_z                                                             
                                                                                
   typedef struct __EPRS9007                                                    
   {                                                                            
      _S9007_RPTDATASTRUCT S9007_RptDataStruct;                                 
   }  _EPRS9007;                                                                
#endif                                                                          
                                                                                
