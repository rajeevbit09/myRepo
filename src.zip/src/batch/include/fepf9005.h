/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF9005                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/04/95                                                */
/*              Time: 12:35:44                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF9005                           */
/******************************************************************************/
                                                                                
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002635_LEN                                                          
#define   FY002635_LEN                         3                                
#endif                                                                          
#ifndef   FY002704_LEN                                                          
#define   FY002704_LEN                         6                                
#endif                                                                          
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef   FY003592_LEN                                                          
#define   FY003592_LEN                         27                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY003585_LEN                                                          
#define   FY003585_LEN                         27                               
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F9005_RPTDATASTRUCT_z                                                  
#define _F9005_RPTDATASTRUCT_z                                                  
typedef struct __F9005_RptDataStruct                                            
{                                                                               
   char                sPprNm[FY002480_LEN];                                    
   char                sSvcChrgCd[FY002635_LEN];                                
   char                sPprDeptNbr[FY002704_LEN];                               
   char                sPprStnId[FY002711_LEN];                                 
   char                sPprStrtDt[FY003592_LEN];                                
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevNm[FY002531_LEN];                                   
   char                sFltDprtDt[FY003584_LEN];                                
   char                sFltNbr[FY002553_LEN];                                   
   char                sFltOrigCtyId[FY002521_LEN];                             
   char                sFltDestCtyId[FY002522_LEN];                             
   //long                lFltChrgRfrnDt;
   char                sFltChrgRfrnDt[27];                                          
   char                sFltFeeBegDt[FY003585_LEN];                              
   char                sFltFeeEndDt[FY003586_LEN];                              
   //double              dCostChrgAmt; 
   char                sCostChrgAmt[10];                                           
   char                cRecEndLineTxt;                                          
}  _F9005_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF9005_z                                                             
#define _EPRF9005_z                                                             
                                                                                
   typedef struct __EPRF9005                                                    
   {                                                                            
      _F9005_RPTDATASTRUCT F9005_RptDataStruct;                                 
   }  _EPRF9005;                                                                
#endif                                                                          
                                                                                
