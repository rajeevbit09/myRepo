/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS7101                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/18/96                                                */
/*              Time: 15:37:58                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS7101                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef _S7101_RPTDATASTRUCT_z                                                  
#define _S7101_RPTDATASTRUCT_z                                                  
typedef struct __S7101_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPassRptSortDt[FY003821_LEN];                            
   //long                lPassTripNbr; 
   char                sPassTripNbr[11];                                           
}  _S7101_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS7101_z                                                             
#define _EPRS7101_z                                                             
                                                                                
   typedef struct __EPRS7101                                                    
   {                                                                            
      _S7101_RPTDATASTRUCT S7101_RptDataStruct;                                 
   }  _EPRS7101;                                                                
#endif                                                                          
                                                                                
