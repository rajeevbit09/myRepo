/****************************************************************************
**                                                                         **
** File Name :      EPB53006.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author :         Delta                                                  **
**                  L. Scott                                               **
**                                                                         **
** Date Created:    6/01/09                                                **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/* Service request and answer blocks */

#include "fyr04727.h"    
#include "fya04727.h"   
#include "fyr02526.h"    
#include "fya02526.h"   
 
_R04727 R04727;      
_A04727 A04727;     
_R02526 R02526;      
_A02526 A02526;     

#define SERVICE_ID_04727  4727   /** select t_flt_leg and bdy_nrev_pax_fl  **/ 
#define SERVICE_ID_02526  2526   /** insert t_chrg **/ 

/* Function definitions */

void    TPM_1000_Initialize();
void    TPM_2000_Mainline();
void    TPM_3000_ProcessFileEPBF010();
int     TPM_8000_ProcessLUW();
void    TPM_9500_ProcessEndOfProgram();

/* #defines and global variables */

#define NUMBER_OF_THREADS 2        
#define EPBUPD0 0                 
#define EPBINQ0 1                

char    isodt[8+1];
char    sErrMsg[26];
char    servid;
char    servid1;
char    servid2;
char    servid3;
char    servid4;
char    servid5;
char    servid6;
char    servid7;
char    servid8;
char    servid9;
char sCertftIssDt[27];
char    cBrdPriFound;
short   nSvcRtnCd;
short   nRfrnDt;
double  dChrgAmt;


static struct
{
   char    start_of_save;

   int EPBF010;        /** Input PARS file **/


   char    EPBF010_buffer[301];

   char sEmpNum[11];
   char sTktNum[14];
   char sTripOrig[6];
   char sTripDest[6];
   char cBrdPri;
   char cClassSvc;
   char cPsgrCode;
   char sFltDt[9];
   char sTotalAmt[8];
   char sBaseAmt5[6];
   char sBaseAmt2[3];
   char sTotalTax[8];
   char sTaxType1[11];
   char sTaxAmt1[3];
   char sTaxAmt1a[6];
   char sTaxAmt1b[3];
   char sTaxPct1[10];
   char sTaxType2[11];
   char sTaxAmt2[3];
   char sTaxAmt2a[6];
   char sTaxAmt2b[3];
   char sTaxPct2[10];
   char sTaxType3[11];
   char sTaxAmt3[3];
   char sTaxAmt3a[6];
   char sTaxAmt3b[3];
   char sTaxPct3[10];
   char sTaxType4[11];
   char sTaxAmt4[3];
   char sTaxAmt4a[6];
   char sTaxAmt4b[3];
   char sTaxPct4[10];
   char sTaxType5[11];
   char sTaxAmt5[3];
   char sTaxAmt5a[6];
   char sTaxAmt5b[3];
   char sTaxPct5[10];
   char sTaxType6[11];
   char sTaxAmt6[3];
   char sTaxAmt6a[6];
   char sTaxAmt6b[3];
   char sTaxPct6[10];
   char sTaxType7[11];
   char sTaxAmt7[2];
   char sTaxAmt7a[6];
   char sTaxAmt7b[3];
   char sTaxPct7[10];
   char sTaxType8[11];
   char sTaxAmt8[3];
   char sTaxAmt8a[6];
   char sTaxAmt8b[3];
   char sTaxPct8[10];
   char sFiller13[14];

   char sTktNum15[15+1];
   char sEmpNum10[10+1];
   char sOrig[5+1];
   char sDest[5+1];
   char sPprNbr[9+1];
   char sSavePprNbr[9+1];
   char sNrevNbr[2+1];
   char sNrevSrcCd[2+1];
   char sFltNbr[5+1];
   char sFltOrigCtyId[5+1];
   char sFltDestCtyId[5+1];
   char sDprtDt[27];
   char sArrDt[27];
   char sClsSvc[3];
   char sBrdPri5[5];
   char sFltYr[5];
   char sFltYrMo[7];
   char sFltYrMoDy[9];
   char sBaseAmt7[9];
   short Read;

}  RS;
