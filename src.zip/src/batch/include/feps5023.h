/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5023                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/16/2005                                              */
/*              Time: 10:00:00                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5023                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5023_RPTDATASTRUCT_z                                                  
#define _S5023_RPTDATASTRUCT_z                                                  
typedef struct __S5023_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5023_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5023_z                                                             
#define _EPRS5023_z                                                             
                                                                                
   typedef struct __EPRS5023                                                    
   {                                                                            
      _S5023_RPTDATASTRUCT S5023_RptDataStruct;                                 
   }  _EPRS5023;                                                                
#endif                                                                          
                                                                                
