/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5029                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 12/12/2008                                              */
/*              Time: 10:00:00                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5029                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5029_RPTDATASTRUCT_z                                                  
#define _S5029_RPTDATASTRUCT_z                                                  
typedef struct __S5029_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5029_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5029_z                                                             
#define _EPRS5029_z                                                             
                                                                                
   typedef struct __EPRS5029                                                    
   {                                                                            
      _S5029_RPTDATASTRUCT S5029_RptDataStruct;                                 
   }  _EPRS5029;                                                                
#endif                                                                          
                                                                                
