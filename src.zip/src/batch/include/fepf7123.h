/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF7123                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 01/06/96                                                */
/*              Time: 12:12:38                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF7123                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY003585_LEN                                                          
#define   FY003585_LEN                         27                               
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY002478_LEN                                                          
#define   FY002478_LEN                         4                                
#endif                                                                          
#ifndef   FY002475_LEN                                                          
#define   FY002475_LEN                         25                               
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002476_LEN                                                          
#define   FY002476_LEN                         25                               
#endif                                                                          
#ifndef   FY002477_LEN                                                          
#define   FY002477_LEN                         25                               
#endif                                                                          
#ifndef   FY002482_LEN                                                          
#define   FY002482_LEN                         3                                
#endif                                                                          
#ifndef   FY002518_LEN                                                          
#define   FY002518_LEN                         10                               
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002838_LEN                                                          
#define   FY002838_LEN                         6                                
#endif                                                                          
#ifndef   FY002839_LEN                                                          
#define   FY002839_LEN                         6                                
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F7123_RPTDATASTRUCT_z                                                  
#define _F7123_RPTDATASTRUCT_z                                                  
typedef struct __F7123_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sFltFeeBegDt[FY003585_LEN];                              
   char                sFltFeeEndDt[FY003586_LEN];                              
   char                sPprCtryCd[FY002478_LEN];                                
   char                sPpr1Addr[FY002475_LEN];                                 
   char                sFltDprtDt[FY003584_LEN];                                
   char                sPpr2Addr[FY002476_LEN];                                 
   char                sPprCtyAddr[FY002477_LEN];                               
   char                sPprStCd[FY002482_LEN];                                  
   char                sPprZipAddr[FY002518_LEN];                               
   char                sPprNm[FY002480_LEN];                                    
   char                sNrevNm[FY002531_LEN];                                   
   //long                lFltDprtDt;           // Not used - sFltDprtDt above is used                                             
   char                sFltNbr[FY002553_LEN];                                   
   char                sFltTripOrigId[FY002838_LEN];                            
   char                sFltTripDestId[FY002839_LEN];                            
   //long                lFltArptPrNbr;
   char                sFltArptPrNbr[14];  
   // double              fFltImptValAmt;
   char                sFltImptValAmt[14];                                          
   //double              fFltImptWageAmt; 
   char                sFltImptWageAmt[14];                                        
   //float               fNrevPmtAmt;      
   char                sNrevPmtAmt[14];                                       
   char                cRecEndLineTxt;                                          
}  _F7123_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF7123_z                                                             
#define _EPRF7123_z                                                             
                                                                                
   typedef struct __EPRF7123                                                    
   {                                                                            
      _F7123_RPTDATASTRUCT F7123_RptDataStruct;                                 
   }  _EPRF7123;                                                                
#endif                                                                          
                                                                                
