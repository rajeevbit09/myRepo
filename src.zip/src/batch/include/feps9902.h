/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS9902                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/12/98                                                */
/*              Time: 18:54:14                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS9902                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN
#define   FY002479_LEN                         10
#endif
#ifndef   FY002516_LEN
#define   FY002516_LEN                         3 
#endif
#ifndef   FY002868_LEN
#define   FY002868_LEN                         27
#endif
#ifndef   FY002535_LEN
#define   FY002535_LEN                         3 
#endif
#ifndef _S9902_RPTDATASTRUCT_z                                                  
#define _S9902_RPTDATASTRUCT_z                                                  
typedef struct __S9902_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];
   char                sNrevNbr[FY002516_LEN];
   char                sPassDtTmTs[FY002868_LEN];
   char                sPassStsCd[FY002535_LEN];
}  _S9902_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS9902_z                                                             
#define _EPRS9902_z                                                             
                                                                                
   typedef struct __EPRS9902                                                    
   {                                                                            
      _S9902_RPTDATASTRUCT S9902_RptDataStruct;                                 
   }  _EPRS9902;                                                                
#endif                                                                          
                                                                                
