#include <time.h>
#include <stdio.h>

#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "fyr04724.h"
#include "fya04724.h"
#include "epbcmncd.h"

#define NUMBER_OF_THREADS 1
#define EPBINQ0 0                
#define SERVICE_ID_04724  4724   /** select t_ppr, t_nrev_psgr, bdy_nrev_pax **/ 


_R04724 R04724;
_A04724 A04724;


char* aFTI18DNPassengerTyp[] = {"RTC", "CMP", "UNA", "PNC"};
char* aFTI18DNPassengerTyp2[] = {"RDP", "CDP", "SDP"};
char* aNrevSrcCd2[] = {"9E", "AS", "F8", "GQ", "OO", "RP", "S5", "SO", "WS", "XE"};
char identHeaderRec[2] = "HD";
char identDetailRec[2] = "ET";
char* FTI18DN_recs;

short   nSvcRtnCd;


static struct {
   char    start_of_save;

   int EPBF5305;        /** Input Deltamatic file **/
   //int EPBF5305_out;

   char EPBF5305_buffer[220];

   // Fly Together -� FTI02ND NW-PASS feed file for DL-PASS
   // FTI18DN_fileLayout same as FTI02ND_fileLayout, but allowed passenger's types are: RTC/ CMP/ UNA/ PNC -- PASSENGER TYPE
   char sETIdentifier[2];        //	ALWAYS 'ET'
   char sTranDate[10];           // 2009-01-31 -- WHEN PRA PROCESSED THE COUPONS
   char sAirlineTktId[3];        //	012 -- NW TICKET STOCK
   char sTktSerialNum1st3[3];    //	051/052/08x --	051 (E-TICKETS); 052 (E-PASSES); 08x (PAPER TICKETS)
   char sTktSerialNumLst7[7];    //	6565265 -- THE REST OF THE TICKET NUMBER
   char sTktCpnNum[2];           //	01/02/03/04	-- COUPON NUMBERS - MIN OF 1, MAX OF 4
   char sPassengerTyp[3];        //	EMP/ SPS/ DEP/ PAR/ RTC/ PNC/ CMP/ UNA/ CDP/ RDP/ INF/ INS -- PASSENGER TYPE
   char sSegmentTvlCde[2];       // 3/3A/5/9/ETC. -- PRIORITY CODE
   char sPasgrLastName[15];      // ALTARES -- PASSENGER�S LAST NAME
   char sPasgrFirstName[10];     // EDGAR	-- PASSENGER�S FIRST NAME
   char sTripOrig[5];            //	NGO -- TRIP ORIGIN (ORIGIN OF THE COUPONS RECEIVED IN THE BATCH)
   char sTripDest[5];            // DTW -- TRIP DESTINATINON (FINAL DESTINATION OF THE COUPONS RECEIVED IN THE BATCH)
   char sSegmentOrig[5];         // NGO -- SEGMENT�S ORIGIN
   char sSegmentDest[5];         // DTW -- SEGMENT�S DESTINATION
   char sSegmentFltNum[4];       // 0072 -- SEGMENT�S FLIGHT NUMBER
   char sSegmentTvlClass[2];     // Y / C / F -- COACH, BUSINESS CLASS, FIRST CLASS
   char sEmpNum[6];              // 237841 -- EMPLOYEE NUMBER (NW�S 6-DIGIT FORMAT)
   char sFiller4[4];
   char sSegmentFltDate[10];     // 2009-01-29 -- FLIGHT DATE FOR THE SEGMENT (DEPARTURE)
   char sSegmentAirlineCde[3];   // NW/XJ/9E/CP	-- NW, MESABA, COMPASS, PINNACLE
   char cSegmentAircraftTyp;     // J / P	-- JET, PROP, ETC.	Yes
   char sFormPayCde[2];          // USUALLY EMPTY
   char sFormPayCcCde[2];        // USUALLY EMPTY
   char sFormPayment[19];        // USUALLY EMPTY
   char sAgencyNum[4];
   char sAgencyName[15];         // 'USA DEFAULT AGE' -- SAMPLE ONLY, USUAL VALUE
   char sEmpCompanyCde[3];       // NW	-- EMPLOYEE�S COMPANY CODE
   char sPnrNum[6];              // 4V8X2R -- RECORD LOCATOR / CONFIRMATION CODE	-- Maybe*
   char sTktDsig[5];             // ID110/FR958 -- FARE BASIS CODE -- Maybe*
   // sTktTag[5];                // contains next 5 characters -- USED FOR NEW DAY PROCESSING -- Maybe*
   char cTktTagL;                // 'L' -- Always 'L' if a New Day ticket; otherwise, SPACES	-- Maybe*
   char cTktTagCpn;              // 1 / 2 / 3 / 4	-- Indicates which coupon starts the 'roundtrip' (the 'return' segments) -- Maybe*
   char sTktTagDest[3];          // 3-char airport code (turn around point) -- Maybe*
   // /sTktTag[5];
   char sConjTktNum[21];         // 0120526565265/66 -- DIGITS AFTER SLASH INDICATES 'NEXT' TICKETS -- Maybe*
   // sTaxInfo[8];               // contains next 8 characters -- USED FOR POSITIVE SPACE PROCESSING -- Maybe*
   char cTripType;               // B / L	-- B for BUSINESS; L for LEISURE
   char cTripRouting;            // O / R / U / J / C	-- One-way, Roundtrip, Unknown, Open-Jaw, Circle-Trip -- Maybe*
   char sOneWayTrips[2];         // How many one-way trips?	-- Maybe*
   char sTurnArndPt3[3];         // Maybe*
   char cTurnArndPtPos4;         // Maybe*
   // /sTaxInfo[8];
   char sFiller[3];              // UNUSUED FIELD	
   char sTktIssueDate[10];       // 2009-01-29 -- WHEN THE TRIP WAS TICKETED -- Maybe*
   char sTktSegmentMlg[3];       // 6525 -- MILEAGE BETWEEN SEGMENT ORIG AND DEST -- Maybe*
   char sFiller7[7];
   // /Fly Together -� FTI02ND NW-PASS feed file for DL-PASS

   short   Read;
   short   Error;
   short   Dropped;
   short   Processed;
   short   FTI18DNCnt;

   char    end_of_save;
}  RS;


void    TPM_1000_Initialize ();
void    TPM_2000_Mainline ();
void    TPM_3000_ProcessFileEPBF5305 ();
void    TPM_9500_ProcessEndOfProgram ();

void    Write_Log(char a[],char b[]);
