/****************************************************************************
**                                                                         **
** File Name :      EPB99001.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Delta Technologies                                     **
**                  LaShawnda Walker                                       **
**                                                                         **
** Date Created:    6/2/99                                                 **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 07/26/00   LSW                         Modified Month (Mtn) array to use**
**                                        all capital letters              **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"
#include <time.h>

#include "feps9901.h"     /** report sort layout (name of copybook) **/
#include "fepf9901.h"     /** report data layout (name of copybook) **/

/* Report sort and data layouts */

_EPRF9901 EPRF9901;       /** Report1 Data Layout **/
_EPRS9901 EPRS9901;       /** Report1 Data Layout **/

/* Service request and answer blocks  */
#include "fyr04700.h"  
#include "fya04700.h" 
#include "fyr04701.h"  
#include "fya04701.h" 
#include "fyr04705.h"  
#include "fya04705.h" 
 
_R04700 R04700;
_A04700 A04700;
_R04701 R04701;
_A04701 A04701;
_R04705 R04705;
_A04705 A04705;

#define SERVICE_ID_04700  4700
#define SERVICE_ID_04701  4701
#define SERVICE_ID_04705  4705

/* Function definitions   */
void DPM_1000_Initialize();
void DPM_2000_Mainline();
void DPM_3000_ProcessMultipleCompanions();
void DPM_4000_CurrentAnnYr();
void DPM_5000_ChkDateBuildList();
char *DPM_6000_PassStsChgDt();

/* #defines and global variables   */
#define NUMBER_OF_THREADS 4
#define EPBUPD0 0
#define EPBINQ0 1
#define EPBINQ1 2
#define EPBINQ2 3

static struct
{
   char    start_of_save;
 
   int PRAF010;        /** Report output file **/
 
 
   char    sTodayDt[27],
           sBegDt[27],
           sEndDt[27],
           PRAF010_buffer[236];
 
 
   char    end_of_save;
}  RS;

struct CP_REC {
  char ppr_nbr[10],
       nrev_nbr[3],
       pass_sts_chg_dt[27],
       pass_dt_tm_ts[27],
       ppr_strt_dt[27];
  int  month;
  struct CP_REC *next_cp;
};

struct CP_REC *new_cp_rec,
              *next_cp_rec,
              *hd_ptr=NULL,
              *tl_ptr;

struct ANN_YR {
  int nAnnStrtDt,
      nAnnEndDt;
  char sAnnStrtDt[27],
       sAnnEndDt[27];
};

struct ANN_YR *curr_ann_dt;

char Mtn[12][3] = {"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};

int nRecCnt=0;
