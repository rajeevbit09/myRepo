/****************************************************************************
**                                                                         **
** File Name :      EPB40001.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author:          Duane Ellis                                            **
**                                                                         **
** Date Created:    3/2010                                                 **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         Description                               **
** ----       ----------         --------------------                      **
** 03/04/2010 DHE                Inital Program Creation                   **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/* Service request and answer blocks */

#include "fyr02436.h"
#include "fya02436.h"
#include "fyr02792.h"
#include "fya02792.h"
#include "fyr04739.h"
#include "fya04739.h"
#include "fyr04745.h"
#include "fya04745.h"
#include "fyr04746.h"
#include "fya04746.h"
#include "fyr04747.h"
#include "fya04747.h"
#include "fyr04749.h"
#include "fya04749.h"
#include "fyr04750.h"
#include "fya04750.h"
#include "fyr04751.h"
#include "fya04751.h"
#include "fyr04752.h"
#include "fya04752.h"
#include "fyr04753.h"
#include "fya04753.h"
#include "fyr04754.h"
#include "fya04754.h"

_R02436 R02436;
_A02436 A02436;
_R02792 R02792;
_A02792 A02792;
_R04739 R04739;
_A04739 A04739;
_R04745 R04745;
_A04745 A04745;
_R04746 R04746;
_A04746 A04746;
_R04747 R04747;
_A04747 A04747;
_R04749 R04749;
_A04749 A04749;
_R04750 R04750;
_A04750 A04750;
_R04751 R04751;
_A04751 A04751;
_R04752 R04752;
_A04752 A04752;
_R04753 R04753;
_A04753 A04753;
_R04754 R04754;
_A04754 A04754;

#define SERVICE_ID_02436  2436   /** SELECT FROM T_NREV_PSGR table by PPR/NRev            **/
#define SERVICE_ID_02792  2792   /** SELECT FROM T_ARPT_PR_MI table by city pair          **/
#define SERVICE_ID_04739  4739   /** UPDATE NRAP_FLWN_FL SET PROCD_FOR_IMPTN_DT           **/
#define SERVICE_ID_04745  4745   /** SELECT DISTINCT PRMY_TKT_DOC_NBR FROM NRAP_FLWN_FL   **/
#define SERVICE_ID_04746  4746   /** SELECT Records from NRAP_FLWN_FL by PrmyTktNbr       **/
#define SERVICE_ID_04747  4747   /** SELECT from NRAP_TRP_IMPD_VAL where SNT_TO_PYRL_DT is LOW_DATE      **/
#define SERVICE_ID_04749  4749   /** UPATE  NRAP_TRP_IMPD_VAL record with values          **/
#define SERVICE_ID_04750  4750   /** INSERT Record into NRAP_TRP_IMPD_VAL table           **/
#define SERVICE_ID_04751  4751   /** SELECT from IMPD_TRVL_BAND by date & mileage         **/
#define SERVICE_ID_04752  4752   /** SELECT from NRAP_TRP_IMPD_VAL by PK fields           **/
#define SERVICE_ID_04753  4753   /** SELECT from NRAP_PARM by Award and Earning Nbr       **/
#define SERVICE_ID_04754  4754   /** UPDATE NRAP_TRP_IMPD_VAL set SNT_TO_PYRL_DT          **/


#define MODULE_NAME                  "epb40002"

/* #defines and global variables */
#define NUMBER_OF_THREADS 3
#define EPBUPD0 0
#define EPBINQ0 1
#define EPBINQ1 2

short   nSvcRtnCd;
int     retval;

#ifndef true
#define true   1
#define false  0
#endif

#define REC_WRITTEN  1
#define REC_SKIPPED  0


/* Function definitions */

void  TPM_1000_Initialize();
void  TPM_2000_Mainline();

void  TPM_3000_ProcessRecord();
int   TPM_4010_WriteToPayrollFile();
int   TPM_4020_WriteToCompassFile();
int   TPM_4030_WriteToMesabaFile();
int   TPM_4040_WriteToMLTFile();

short TPM_8001_GetUnprocessedRecord(char CursorOpTxt);
int   TPM_8003_GetCompanyCode(char *sPPR, char *sCompanyCode);
int   TPM_8005_GetEarningNbr();
void  TPM_8009_UpdateSentToPayroll();

void  TPM_8011_OpenPayrollFile();
void  TPM_8021_OpenCompassFile();
void  TPM_8031_OpenMesabaFile();
void  TPM_8041_OpenMLTFile();


void  TPM_9000_ProcessEndOfProgram();

static int   writeHeader(long numrec, FILE *nvalfp);
static int   writeDetail(char *ppr, float netamt, FILE *nvalfp);
static int   writePayrollDetail(char *ppr, float netamt, char *earnnbr, FILE *nvalfp);


typedef struct _AIRLINKHDR
{
   char  sHDR[3];             // 01-03    "HDR" - first record in the file
   char  sDate[8];            // 04-11    CCYYMMDD - Datefile created by Delta
   char  sNbrRecs[5];         // 12-16    00000 - Number of records in the file excluding Hdr record
   char  filler[4];           // 17-20    Filler (blanks)
} AIRLINKHDR;


typedef struct _AIRLINKDETAIL
{
   char  sPPR[9];             // 01-09    Primary Pass Rider Number (PPR)
   char  sNetAmt[7];          // 10-16    S9(4)v9  "9999.99" or "-999.99" - Amount of imputed value to report
   char  filler[4];           // 17-20    Filler (blanks)
} AIRLINKDETAIL;


typedef struct _IMPDVALRECS
{
   short nImpdValSqlNb;
   char  cImpdTrvlBandCd;
   long  lTotImpdMiCt;
   float fImpdNetAmt;
   char  sTrpOrigCtyId[5+1];
   char  sTrpDestCtyId[5+1];
   char  sTrpDprtDt[27];      // DB Format: YYYY-MM-DD-00:00:00
   char  sSentToPyrlDt[27];   // DB Format: YYYY-MM-DD-HH:MM:SS

} IMPDVALRECS;

//-------- Application Work Area --------------------------------------
static struct
{
   char    start_of_save;

   int   fDelta;
   int   fCompass;
   int   fMesaba;
   int   fMLT;

   //---- NRAP_TRP_IMP_VAL fields for Current Record ------
   char  sPprNbr[9+1];
   char  sNrevNbr[2+1];
   char  sNrapCd[8+1];
   short nNrapSpgmNb;
   char  sNrapFrstBkgLdt[27]; // DB Format: YYYY-MM-DD-HH:MM:SS
   short nNrapTrpSqNb;
   short nImpdValSqlNb;
   //--
   char  cImpdTrvlBandCd;
   char  cOwrtCd;
   char  cTrp1099Ind;
   long  lTotalImpdMiCt;      // Round Trip Mileage
   float fImpdNetAmt;
   char  sSentToPyrlDt[27];   // DB Format: YYYY-MM-DD-HH:MM:SS

   char  sTrpOrigCtyId[5+1];
   char  sTrpDestCtyId[5+1];
   char  sTrpDprtDt[27];      // DB Format: YYYY-MM-DD-00:00:00

   char  sEarningNbr[21];

   //-----------------------------------

   char  DeltaFilePath  [256];   // Paths to output files
   char  CompassFilePath[256];
   char  MesabaFilePath [256];
   char  MLT_FilePath   [256];

   FILE *fpPayroll;              // File Pointers to output files
   FILE *fpCompass;
   FILE *fpMesaba;
   FILE *fpMLT;

   //-----------------------------------
   long  Tot_Net_Val_Cnt;        // Total count of all records read from DB
   long  Payroll_Rec_Cnt;        // Count of records written
   long  Compass_Rec_Cnt;        //    "
   long  Mesaba_Rec_Cnt;         //    "
   long  MLT_Rec_Cnt;            //    "
   long  Ignore_Cnt;             // Number of records not exported
   long  Error_Cnt;              // Number of Runtime Errors encountered

   char  end_of_save;

} RS;

