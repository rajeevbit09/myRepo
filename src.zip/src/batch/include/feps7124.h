/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS7124                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 03/06/96                                                */
/*              Time: 18:27:28                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS7124                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef _S7124_RPTDATASTRUCT_z                                                  
#define _S7124_RPTDATASTRUCT_z                                                  
typedef struct __S7124_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltDprtDt[FY003584_LEN];                                
   long                lPassTripNbr;                                            
}  _S7124_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS7124_z                                                             
#define _EPRS7124_z                                                             
                                                                                
   typedef struct __EPRS7124                                                    
   {                                                                            
      _S7124_RPTDATASTRUCT S7124_RptDataStruct;                                 
   }  _EPRS7124;                                                                
#endif                                                                          
                                                                                
