/****************************************************************************
**                                                                         **
** File Name :      EPB71101.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB71101.c module.                                 **
**                                                                         **
**                                                                         **
** Date Created:    May 10, 2007                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/*
 * You should include any subsytem header files here. For example:
 * #include "subsystem_db_io/current_date.h"
 *
 */

/*
 * No Report sort and data layouts
 */

/*
 * Service request and answer blocks
 */

#include "fyr02436.h"      /** service request layout **/
#include "fya02436.h"      /** service answer layout **/
#include "fyr02526.h"      /** service request layout **/
#include "fya02526.h"      /** service answer layout **/
#include "fyr02574.h"      /** service request layout **/
#include "fya02574.h"      /** service answer layout **/
#include "fyr02575.h"      /** service request layout **/
#include "fya02575.h"      /** service answer layout **/
#include "fyr02576.h"      /** service request layout **/
#include "fya02576.h"      /** service answer layout **/
#include "fyr02577.h"      /** service request layout **/
#include "fya02577.h"      /** service answer layout **/
#include "fyr02579.h"      /** service request layout **/
#include "fya02579.h"      /** service answer layout **/
#include "fyr03208.h"      /** service request layout **/
#include "fya03208.h"      /** service answer layout **/
#include "fyr03885.h"      /** service request layout **/
#include "fya03885.h"      /** service answer layout **/
 
_R02436 R02436;        /** Service Request Layout **/
_A02436 A02436;        /** Service Answer Layout **/
_R02526 R02526;        /** Service Request Layout **/
_A02526 A02526;        /** Service Answer Layout **/
_R02574 R02574;        /** Service Request Layout **/
_A02574 A02574;        /** Service Answer Layout **/
_R02575 R02575;        /** Service Request Layout **/
_A02575 A02575;        /** Service Answer Layout **/
_R02576 R02576;        /** Service Request Layout **/
_A02576 A02576;        /** Service Answer Layout **/
_R02577 R02577;        /** Service Request Layout **/
_A02577 A02577;        /** Service Answer Layout **/
_R02579 R02579;        /** Service Request Layout **/
_A02579 A02579;        /** Service Answer Layout **/
_R03208 R03208;        /** Service Request Layout **/
_A03208 A03208;        /** Service Answer Layout **/
_R03885 R03885;        /** Service Request Layout **/
_A03885 A03885;        /** Service Answer Layout **/

#define SERVICE_ID_02436  2436
#define SERVICE_ID_02526  2526
#define SERVICE_ID_02574  2574
#define SERVICE_ID_02575  2575
#define SERVICE_ID_02576  2576
#define SERVICE_ID_02577  2577
#define SERVICE_ID_02579  2579
#define SERVICE_ID_03208  3208
#define SERVICE_ID_03885  3885


/*
 * Function definitions
 */

void     DPM_1000_Initialize();
void     DPM_2000_Mainline();
void     DPM_2500_ProcessRows();
void     DPM_2600_GetCityPairMileage();
void     DPM_2700_CalculateImputedValue();
void     DPM_2800_CalculateEmpPayment();
void     DPM_2850_ProcessHandlingFee();
void     DPM_2900_UpdateImputedTrip();
void     DPM_3000_ConvertDateToJulian(char *sDate);
void     DPM_3100_WritePayroll();
void     DPM_4920_ProcessLUW();
void     DPM_9500_ProcessEndOfProgram();
void    Write_Log(char a[],char b[]);

short    DPM_2750_DetAgeGroup ( char[],
                                char[] );

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS     4     /** Number of threads needed **/
#define EPBINQ0               0     /** First cursor thread **/
#define EPBINQ1               1     /** Second cursor thread **/
#define EPBINQ2               2     /** Third cursor thread **/
#define EPBUPD0               3     /** First update thread **/

#define AGE_GRP_UNDER_2       1     /** German passengers under 2          **/
#define AGE_GRP_2_TO_11       2     /** German passengers between 2 and 11 **/
#define AGE_GRP_OVER_11       3     /** German passengers over 11          **/

#define DEM_CURR              "DEM"
#define USD_CURR              "USD"

short      nSvcRtnCd,               /** Service return code **/
           nStopProcess;            /** Flag indicating process status **/

#define    CONTINUE_PROCESS   !nStopProcess

static struct
{
   float   fNrevPmtAmt;             /** Employee payment amount **/

   double  dFltImptWageAmt,         /** Imputed wage amount **/
           dFltImptValAmt;          /** Imputed value amount **/
} WS;

#define PAYROLL_IMPUT_FORMAT "%-9s%-7s"

struct
{
char    ppr_nbr[10],
	chrg_amt[8];
}PAYROLL_IMPUT_Dtl;

static struct
{
   char     start_of_save;

   /****   Restart save area                      ******/

  /****  File definitions                         ******/

  int EPBF020;            /** Payroll Imputed file **/

  char EPBF020_buffer[17];


   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   long         lPassTripNbr;


   char    end_of_save;

/****
#define PAYROLL_IMPUT_FORMAT "%-9s%-7s"

struct
{
char    ppr_nbr[10],
	chrg_amt[8];
}PAYROLL_IMPUT_Dtl;
****/

} RS;
