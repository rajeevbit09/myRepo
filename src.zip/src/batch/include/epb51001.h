/****************************************************************************
**                                                                         **
** File Name :      EPB51001.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB51001.c module.                                 **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Created:    December 10, 1995                                      **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 03/18/96   JBowser                     Revised to accomodate changes    **
**                                        made to source code.             **
**                                                                         **
** 07/29/96   FFA                         Added counts, new services       **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/** Service request and answer blocks */

#include "fyr02441.h"      /** service request layout **/
#include "fya02441.h"      /** service answer layout **/
#include "fyr02443.h"      /** service request layout **/
#include "fya02443.h"      /** service answer layout **/
#include "fyr02444.h"      /** service request layout **/
#include "fya02444.h"      /** service answer layout **/
#include "fyr02445.h"      /** service request layout **/
#include "fya02445.h"      /** service answer layout **/
#include "fyr02475.h"      /** service request layout **/
#include "fya02475.h"      /** service answer layout **/
#include "fyr02483.h"      /** service request layout **/
#include "fya02483.h"      /** service answer layout **/
#include "fyr02526.h"      /** service request layout **/
#include "fya02526.h"      /** service answer layout **/
#include "fyr02529.h"      /** service request layout **/
#include "fya02529.h"      /** service answer layout **/
#include "fyr02561.h"      /** service request layout **/
#include "fya02561.h"      /** service answer layout **/
#include "fyr02662.h"      /** service request layout **/
#include "fya02662.h"      /** service answer layout **/
#include "fyr02714.h"      /** service request layout **/
#include "fya02714.h"      /** service answer layout **/
#include "fyr02760.h"      /** service request layout **/
#include "fya02760.h"      /** service answer layout **/
#include "fyr02762.h"      /** service request layout **/
#include "fya02762.h"      /** service answer layout **/
#include "fyr02763.h"      /** service request layout **/
#include "fya02763.h"      /** service answer layout **/
#include "fyr02764.h"      /** service request layout **/
#include "fya02764.h"      /** service answer layout **/
#include "fyr03270.h"      /** service request layout **/
#include "fya03270.h"      /** service answer layout **/
#include "fyr04000.h"      /** service request layout **/
#include "fya04000.h"      /** service answer layout **/
#include "fyr04003.h"      /** service request layout **/
#include "fya04003.h"      /** service answer layout **/
#include "fyr04119.h"      /** service request layout **/
#include "fya04119.h"      /** service answer layout **/
#include "fyr04309.h"      /** service request layout **/
#include "fya04309.h"      /** service answer layout **/
#include "fyr04323.h"      /** service request layout **/
#include "fya04323.h"      /** service answer layout **/
#include "fyr04325.h"      /** service request layout **/
#include "fya04325.h"      /** service answer layout **/
#include "fyr04326.h"      /** service request layout **/
#include "fya04326.h"      /** service answer layout **/
#include "fyr04340.h"      /** service request layout **/
#include "fya04340.h"      /** service answer layout **/
#include "fyr04341.h"      /** service request layout **/
#include "fya04341.h"      /** service answer layout **/
#include "fyr04403.h"      /** service answer layout **/
#include "fya04403.h"      /** service answer layout **/
 
_R02441 R02441;        /** Service Request Layout **/
_A02441 A02441;        /** Service Answer Layout **/
_R02443 R02443;        /** Service Request Layout **/
_A02443 A02443;        /** Service Answer Layout **/
_R02444 R02444;        /** Service Request Layout **/
_A02444 A02444;        /** Service Answer Layout **/
_R02445 R02445;        /** Service Request Layout **/
_A02445 A02445;        /** Service Answer Layout **/
_R02475 R02475;        /** Service Request Layout **/
_A02475 A02475;        /** Service Answer Layout **/
_R02483 R02483;        /** Service Request Layout **/
_A02483 A02483;        /** Service Answer Layout **/
_R02526 R02526;        /** Service Request Layout **/
_A02526 A02526;        /** Service Answer Layout **/
_R02529 R02529;        /** Service Request Layout **/
_A02529 A02529;        /** Service Answer Layout **/
_R02561 R02561;        /** Service Request Layout **/
_A02561 A02561;        /** Service Answer Layout **/
_R02662 R02662;        /** Service Request Layout **/
_A02662 A02662;        /** Service Answer Layout **/
_R02714 R02714;        /** Service Request Layout **/
_A02714 A02714;        /** Service Answer Layout **/
_R02760 R02760;        /** Service Request Layout **/
_A02760 A02760;        /** Service Answer Layout **/
_R02762 R02762;        /** Service Request Layout **/
_A02762 A02762;        /** Service Answer Layout **/
_R02763 R02763;        /** Service Request Layout **/
_A02763 A02763;        /** Service Answer Layout **/
_R02764 R02764;        /** Service Request Layout **/
_A02764 A02764;        /** Service Answer Layout **/
_R03270 R03270;        /** Service Request Layout **/
_A03270 A03270;        /** Service Answer Layout **/
_R04000 R04000;        /** Service Request Layout **/
_A04000 A04000;        /** Service Answer Layout **/
_R04003 R04003;        /** Service Request Layout **/
_A04003 A04003;        /** Service Answer Layout **/
_R04119 R04119;        /** Service Request Layout **/
_A04119 A04119;        /** Service Answer Layout **/
_R04309 R04309;        /** Service Request Layout **/
_A04309 A04309;        /** Service Answer Layout **/
_R04323 R04323;        /** Service Request Layout **/
_A04323 A04323;        /** Service Answer Layout **/
_R04325 R04325;        /** Service Request Layout **/
_A04325 A04325;        /** Service Answer Layout **/
_R04326 R04326;        /** Service Request Layout **/
_A04326 A04326;        /** Service Answer Layout **/
_R04340 R04340;        /** Service Request Layout **/
_A04340 A04340;        /** Service Answer Layout **/
_R04341 R04341;        /** Service Request Layout **/
_A04341 A04341;        /** Service Answer Layout **/
_A04403 A04403;        /** Service Answer Layout **/
_R04403 R04403;        /** Service Answer Layout **/

#define SERVICE_ID_02441  2441
#define SERVICE_ID_02443  2443
#define SERVICE_ID_02444  2444
#define SERVICE_ID_02445  2445
#define SERVICE_ID_02475  2475
#define SERVICE_ID_02483  2483
#define SERVICE_ID_02526  2526
#define SERVICE_ID_02529  2529
#define SERVICE_ID_02662  2662
#define SERVICE_ID_02441  2441
#define SERVICE_ID_02443  2443
#define SERVICE_ID_02444  2444
#define SERVICE_ID_02445  2445
#define SERVICE_ID_02475  2475
#define SERVICE_ID_02483  2483
#define SERVICE_ID_02526  2526
#define SERVICE_ID_02529  2529
#define SERVICE_ID_02561  2561
#define SERVICE_ID_02662  2662
#define SERVICE_ID_02714  2714
#define SERVICE_ID_02760  2760
#define SERVICE_ID_02762  2762
#define SERVICE_ID_02763  2763
#define SERVICE_ID_02764  2764
#define SERVICE_ID_03270  3270
#define SERVICE_ID_04000  4000
#define SERVICE_ID_04003  4003
#define SERVICE_ID_04119  4119
#define SERVICE_ID_04309  4309
#define SERVICE_ID_04323  4323
#define SERVICE_ID_04325  4325
#define SERVICE_ID_04326  4326
#define SERVICE_ID_04340  4340
#define SERVICE_ID_04341  4341
#define SERVICE_ID_04403  4403


/** Function definitions */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2100_CalculateStartDate();
void    DPM_2200_ObtainNextDBRow(short nSvcNbr);
void    DPM_2500_ProcessRows();
void    DPM_2600_UpdateMonthsService();
void    DPM_2650_ProcessPassTypes();
void    DPM_2700_ReadNrevPsgr();
void    DPM_2710_UpdateIndicators();
void    DPM_2720_EvaluateGroupType();
void    DPM_2725_RevokeNrevPsgr();
void    DPM_2730_ProcessVolSeverance();
void    DPM_2800_UpdateToOrigAllot();
void    DPM_2900_UpdateToNewAllot();
void    DPM_2910_ReadPriorRemnAllot();
void    DPM_2920_ReadRemnAllot();
void    DPM_2930_ReadPassAllot();
void    DPM_2940_UpdatePriorRemnAllot();
void    DPM_2950_InsertPriorRemnAllot();
void    DPM_2960_DeletePriorRemnAllot();
void    DPM_2970_UpdateRemnAllot();
void    DPM_2980_InsertRemnAllot();
void    DPM_2990_DeleteRemnAllot();
void    DPM_2910_UpdateIndicators();
void    DPM_3000_WriteDlmaticRecord(char cRecTyp);
void    DPM_3100_ReadDlmaticRecord();
void    DPM_4920_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();

/** #defines and global variables */

#define NUMBER_OF_THREADS     6     /** Number of threads needed **/
#define EPBINQ0               0     /** Inquiry thread **/
#define EPBINQ1               1     /** Inquiry thread **/
#define EPBUPD0               2     /** Update thread for CSR 4309**/
#define EPBUPD1               3     /** Update thread for CSR 4340**/
#define EPBUPD2               4     /** Update thread **/
#define EPBUPD3               5     /** Update thread for CSR 4341**/

#define MILES                 'M'
#define IMPUTED               'Y'
#define TICKETED              'T'
#define INELIGIBLE_COMMENT    "EPB51001-Revoked due to invalid PassGp/PsgrType."
#define ADD_REC               'A'   /** ADD record        **/
#define CHANGE_REC            'C'   /** CHANGE record     **/
#define DELETE_REC            'D'   /** DELETE record     **/
#define STARS                 "**"
#define MAX_PASSTYPES         10    /** Maximum number of pass types **/
#define EXPAT                 "EX"  /** Expatriate **/
#define THIRD_CNTRY_NATL      "TC"  /** Third Country National **/
#define UNLIMITED_DAYS        999
#define SPACE                 ' '
#define REWARD_PASS_TYPE      "15" /** S1R reward **/

char       cProcInd;                /** monthly or yearly processing indicator **/
char       cImputedInd;             /** Imputed Travel Indicator **/


short   nRewardInd,		/** S1R Reward Indicator **/
        nRemoveRewardInd;	/** S1R Remove Reward Indicator **/

short   nSvcRtnCd,                  /* Service return code */
        nEndOfMoData,               /** End of data for month processing flag **/     
        nEndOfYrData,               /** End of data for year processing flag **/
        nPassTypCtr,                /** Pass type counter **/
        z,                          /** Pass type index **/
        nOldAllotInd,               /** Flag for existence of allotments **/
        nNewAllotInd,               /** Flag for new allotments for the year **/
        nPriorRemnAllotInd,         /** Flag for existence of prior period allotments **/
        nRvkInd;                    /** Revoked indicator **/

 
typedef struct
{
char    sPassTypCd[3];
}passtype;
 
passtype   pass_type[MAX_PASSTYPES];

static struct
{
   char    sPprNbr[10],             /** Pass group code **/
           sPassGrpCd[3],           /** Pass group code **/
           sPprRvkDt[27],           /** PPR revoked date **/
           sPprStrtDt[27],          /** PPR start date **/
           sPprInttxNbr[9],         /** PPR intertax number **/
           sPprRsdncyStsCd[3];      /** PPR residency status code **/

   short   nFltMoSvcNbr,            /** PPR months of service **/ 
           nEndOfPsgr;              /** End of passengers flag **/   

} WS;

static struct
{
   char     start_of_save;


   char         sEffDt[27],         /** Input Effective processing date **/
                sEff1Dt[27],        /** Effective processing date 1 for cursor 4341 **/
                sEff2Dt[27],        /** Effective processing date 2 for cursor 4341**/
                sMonth[4],
                sPprNbr[10];        /** PPR number **/

   short        nNbrOfDy,           /** Number of days used for month processing **/     
                nIniInd,            /** Initial commit flag **/
                nMoProc,            /** Month processing flag **/
                nYrProc,            /** Year processing flag **/
                nOneMonthPprCnt,
                nOneMonthNrevCnt,
                nYrPprCnt,
                nYrNrevCnt;
   
   struct tm tmDate;

   char    end_of_save;

} RS;
