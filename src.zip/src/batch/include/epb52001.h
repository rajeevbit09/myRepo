/****************************************************************************
**                                                                         **
** File Name :      EPB52001.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Kimberly Gordon                                        **
**                                                                         **
** Date Created:                                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** Lookup Changes 9-21-95        1                                         **
**                                                                         **
** 3-2-2010   L.Scott            2        Put all non-domesitc US airport  **
**                                        codes into distinct regions.     **
**                                                                         **
** 12-7-2010  L.Scott            3        Moved US Territory cities under  **
**                                        Caribbean region.                **
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/**** Service request and answer blocks ****/
#include "fyr02554.h" 
#include "fya02554.h"
#include "fyr02556.h"   
#include "fya02556.h"  
#include "fyr02557.h"  
#include "fya02557.h" 
#include "fyr02792.h"
#include "fya02792.h"   
#include "fyr02794.h"
#include "fya02794.h"   
#include "fyr02795.h"
#include "fya02795.h" 
#include "fyr02796.h"
#include "fya02796.h"

_R02554 R02554;     
_A02554 A02554;    
_R02556 R02556;       
_A02556 A02556;      
_R02557 R02557; 
_A02557 A02557;        
_R02792 R02792;   
_A02792 A02792;   
_R02794 R02794;  
_A02794 A02794;  
_R02795 R02795;     
_A02795 A02795;    
_R02796 R02796;       
_A02796 A02796;      

#define SERVICE_ID_02554  2554
#define SERVICE_ID_02556  2556
#define SERVICE_ID_02557  2557
#define SERVICE_ID_02792  2792
#define SERVICE_ID_02794  2794
#define SERVICE_ID_02795  2795
#define SERVICE_ID_02796  2796

/* Function definitions */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessInterfaceRecords();
void    DPM_2600_ProcessArptPr(); 
void    DPM_2800_ProcessArptCode();
void    DPM_3000_Error();
void    DPM_9500_ProcessEndOfProgram();


#define NUMBER_OF_THREADS 3  
#define EPBUPD0 0          
#define EPBUPD1 1         
#define EPBINQ0 2         

#define YES_CHAR	'Y'
#define NO_CHAR         'N'
#define ERRORCD         "XX"

/**** Origin Stats ID and Destination Stats ID ****/
#define	STAT_TRANSPACIFIC	'P'
#define	STAT_TRANSATLANTIC	'A'
#define	STAT_INTERNATIONAL      'I'
#define	STAT_DOMESTIC           'D'

/**** Update Indicator ****/
#define	ADD		'A'
#define	CHANGE          'C'
#define	DELETE          'D'

char sSaveOrigCty[6];
char cErrorInd;
char eodflag;
int  nMileage;
 char	cUpdateInd,
	sOrigCty[6],
	sOrigNm[26],
	cOrigStatId, 
	sDestCty[6],
	sDestNm[26],
	cDestStatId,
	sMileage[6];

/**** German Cities   *****/
/*****char *pGMCtyStruct[]=               ********/
/**** {"TXL", "DUS", "FRA", "HAM", "HAJ", "MUC", "STR"}; ******/

/**** Alaskan Cities **/

char *pALCtyStruct[]=               
{"ABL", "ADK", "AET", "AFK", "AGN", "AHT", "AIN", "AKI", "AKN", "ALZ", "ANC", "ANI", "ANN", "ANV", "ATU", "AUK", "BET", "BKC", "BMX", "BNF", "BRW", "BSW", "BTI", "BTT", "BYA", "CDB", "CSH", "EIL", "FYU", "GAL", "GAM", "GKN", "GLV", "GMT", "GNU", "GST", "HBY", "HCR", "HMA", "HNH", "HNS", "HOL", "HOM", "HPB", "HSL", "HUS", "HWI", "HYG", "HZA", "IAN", "ICY", "IKO", "KAE", "KAL", "KAS", "KCC", "KCN", "KCO", "KEB", "KEK", "KFP", "KGK", "KGX", "KKA", "KKI", "KKK", "KKU", "KLG", "KLL", "KLN", "KLW", "KLZ", "KOD", "KOT", "KOV", "KOZ", "KPB", "KPC", "KPM", "KPN", "KPR", "KPY", "KQA", "KSM", "KTB", "KTK", "KUY", "KVC", "KVL", "KWF", "KWG", "KWK", "KWN", "KWP", "KWT", "KXA", "KYK", "KYU", "KZB", "LKK", "LSR", "LUR", "MCG", "MDO", "MDR", "MLL", "MOS", "MXY", "NHB", "NIN", "NUL", "NUP", "OME", "OPH", "ORI", "ORT", "OTZ", "PBA", "PBY", "PEC", "PHO", "PIZ", "PKA", "PLL", "PML", "POJ", "PSG", "PTH", "PTU", "PYA", "RBY", "RDV", "RXB", "SCM", "SDP", "SEI", "SGY", "SHG", "SHH", "SHX", "SIT", "SKJ", "SKK", "SKW", "SLQ", "SMK", "SNP", "SOV", "SRD", "SRV", "SVA", "SXP", "SXQ", "TAL", "TEK", "TII", "TKA", "TKE", "TLK", "TNC", "TNK", "TOG", "YAK"};

/**** Hawaiian Cities ****/
char *pHICtyStruct[]=               
      {"HNL", "OGG", "HKP", "HNM", "ITO", "KOA", "LIH", "LNY", "LUP", "MKK"};

/**** Canadian Cities **/
char *pCNCtyStruct[]=               
      {"YVR", "YYC", "YEG", "YQR", "YHZ", "YUW", "LAK", "YFC", "YLW", "YOW", "YQB", "YQM", "YQT", "YUL", "YVR", "YWG", "YXC", "YXE", "YXU", "YYG", "YYJ", "YYT", "YYZ"};

/**** US_Territories  **/
/******* US Territory cities are now listed under Carribean as of 12/7/2010 **********/
/**char *pUTCtyStruct[]=               **/
/***  {"SJU", "STT", "STX"};           **/

/**** African Cities  **/
char *pAFRICACtyStruct[]=               

{"AAE", "ABA", "ABJ", "ABV", "ACC", "ADD", "AEH", "AEO", "AGA", "ALG", "ALJ", "ALY", "ANU", "APL", "ASA", "ASM", "ASW", "ATB", "ATV", "AXU", "BBT", "BBY", "BEN", "BEW", "BFN", "BGF", "BGU", "BJM", "BJR", "BKO", "BKU", "BKY", "BKZ", "BLJ", "BMB", "BNB", "BNI", "BOY", "BSG", "BSK", "BUG", "BUO", "BUQ", "BUX", "BXE", "BXO", "BYK", "BZV", "CAB", "CAI", "CAS", "CBH", "CBQ", "COO", "CPT", "DKR", "FTV", "JNB", "KAA", "KAB", "KAN", "KBO", "KBS", "KED", "KEN", "KGJ", "KGL", "KGO", "KIM", "KIS", "KIW", "KIY", "KKW", "KMN", "KMS", "KMU", "KND", "KNE", "KNN", "KRT", "KSE", "KSL", "KWZ", "KYS", "LAD", "LBQ", "LBV", "LBZ", "LDI", "LFW", "LIE", "LIQ", "LJA", "LLB", "LLI", "LLW", "LMQ", "LOB", "LOS", "LTD", "LUD", "LUM", "LUN", "LVI", "LXR", "MAK", "MAT", "MAX", "MBA", "MBI", "MDK", "MFA", "MFF", "MFQ", "MGQ", "MJL", "MJM", "MJN", "MLN", "MLW", "MNB", "MNO", "MNR", "MOM", "MQQ", "NBO", "NKC", "NLA", "NOS", "NOV", "NZE", "ODA", "ORN", "OUA", "OUD", "OUE", "OUH", "OUR", "OVA", "PBZ", "PHW", "PLZ", "PMA", "PNR", "POG", "POL", "PSD", "PTE", "PZU", "RAI", "RAK", "RBA", "ROB", "RVA", "SAY", "SDD", "SEB", "SGX", "SID", "SII", "SJH", "SJQ", "SNI", "SSG", "SSH", "SSY", "SVB", "SVP", "SXU", "TBO", "TET", "TGR", "TGT", "TIP", "TKC", "TKD", "TLE", "TML", "TMM", "TMR", "TNG", "TOB", "TOM"};

/**** Asian Cities  **/
char *pASIACtyStruct[]=               

{"AGR", "AIO", "AKY", "AMD", "AMI", "AOR", "ATQ", "AXT", "BAG", "BAO", "BBI", "BCD", "BDO", "BHJ", "BHO", "BHU", "BIK", "BIR", "BJS", "BKI", "BKK", "BLR", "BNX", "BOM", "BPN", "BTN", "BWA", "BXU", "CAN", "CBO", "CTS", "DEL", "DNA", "FRU", "FUK", "GTB", "HKG", "HND", "ICN", "IDR", "JP1", "KAG", "KBR", "KCH", "KCZ", "KGU", "KHH", "KIJ", "KIX", "KJR", "KKJ", "KLO", "KMG", "KMI", "KMJ", "KNT", "KNU", "KOE", "KOP", "KTM", "KUA", "KUH", "KUL", "KWJ", "KZJ", "LAO", "LBU", "LDU", "LGP", "LKO", "LPT", "LWY", "MAA", "MBT", "MBV", "MDC", "MDL", "MES", "MGL", "MKZ", "MNL", "MOH", "NGO", "NNG", "NRT", "OKA", "OKD", "OKJ", "OKO", "OMJ", "OSA", "OSN", "OZC", "PAT", "PBD", "PDG", "PEK", "PEN", "PGK", "PHS", "PKU", "PKZ", "PLM", "PLV", "PNH", "PNK", "PNQ", "PPS", "PUS", "PVG", "PXU", "QDM", "RAJ", "REP", "RGN", "RMO", "RRK", "RXS", "SBW", "SDJ", "SDK", "SEL", "SGN", "SGZ", "SHA", "SIN", "SPK", "SRG", "SUB", "SUG", "SWQ", "SXR", "SZX", "TAC", "TAE", "TAG", "TAK", "TEZ", "TKG", "TKL", "TKS", "TNN", "TOY", "TPE"};

/**** Caribbean Cities  **/
char *pCARIBCtyStruct[]=               

{"ASD", "AUA", "AXA", "BBQ", "BCA", "BGI", "BIM", "BON", "BTO", "CAP", "CAT", "CUR", "ELH", "FDF", "FPO", "GCM", "GGT", "HAV", "KIN", "LGI", "LRM", "LYB", "MBJ", "MHH", "MNI", "NAS", "NBW", "NVG", "OCJ", "PAP", "PDH", "PLS", "POP", "POS", "POT", "PTP", "PUJ", "RSD", "SAQ", "SCU", "SDQ", "SJU","SKB", "SML", "STI", "STT", "STX","SVD", "SXM", "TAB", "TCB", "TLB", "UVF"};

/**** Central American Cities  **/
char *pCAMERCtyStruct[]=               

{"AML", "BLB", "BOC", "BZA", "BZE", "CAA", "CNF", "GIG", "GUA", "LCE",  "LIR", "LSL", "MGA", "OAN", "OCO", "PEO", "PMZ", "PTY", "PUE", "PUZ", "QUE",  "RTB", "RUY", "SAL", "SAP", "SDH", "SIU", "SJO", "STB", "SZB", "SZC", "TEA", "TGU", "TKM", "TNU"};

/**** Mexican Cities  **/
char *pMEXCtyStruct[]=               

{"ACA", "AGU", "AZG", "BJX", "CUL", "CUN", "CZM", "GDL", "HMO", "KGX", "LAP", "LEN", "LMM", "LOV", "LTO", "MAM", "MEX", "MID", "MLM", "MMC", "MTY", "MZT", "NLD", "NOG", "OAX", "PBC", "PDS", "PNO", "PQM", "PVR", "PZC", "QRO", "REX", "SJD", "SLP", "SLW", "SRL", "TAM", "TAP", "TGZ", "TIJ", "TRC", "ZCL", "ZIH", "ZLO"};

/**** European Cities  **/
char *pEUROCtyStruct[]=               

{"AAL", "AAR", "ABZ", "ACE", "ACI", "ADA", "AER", "AES", "AEY", "AFY", "AGH", "AGP", "AGQ", "AHO", "AJA", "ALA", "ALC", "ALF", "AMS", "ANK", "ANR", "ANX", "AOI", "ARN", "ARW", "ASB", "ATH", "AVB", "AYT", "BAK", "BAY", "BBU", "BCN", "BDM", "BDS", "BDU", "BEG", "BER", "BES", "BFS", "BGO", "BGY", "BHK", "BHX", "BIA", "BIO", "BIQ", "BLK", "BLL", "BLQ", "BMA", "BOD", "BOH", "BOO", "BRE", "BRH", "BRI", "BRN", "BRQ", "BRS", "BRU", "BRV", "BSL", "BTS", "BTZ", "BUD", "BUH", "BUS", "BVA", "BZI", "BZO", "CAG", "CAL", "CAX", "CBG", "CDG", "CGN", "CIA", "CPH", "DME", "DUB", "DUS", "EDI", "FAO", "FBU", "FCO", "FRA", "FRF", "GEN", "GLA", "GOA", "GVA", "GXW", "HAJ", "HAM", "HEL", "HHN", "HRT", "HUY", "IST", "JYV", "KAJ", "KBP", "KEF", "KEL", "KEM", "KGS", "KHE", "KID", "KIV", "KKN", "KLR", "KLU", "KLV", "KOI", "KOK", "KRK", "KRN", "KRP", "KRR", "KRS", "KSC", "KTW", "KUO", "KVA", "KYA", "KYZ", "KZI", "KZN", "LBA", "LBG", "LCG", "LCY", "LDE", "LDY", "LED", "LEI", "LEJ", "LGW", "LHR", "LIL", "LIN", "LIS", "LJU", "LKL", "LLA", "LNZ", "LPA", "LPL", "LPP", "LRA", "LRH", "LRT", "LSI", "LTN", "LTQ", "LUX", "LWO", "LXS", "LYS", "LYX", "MAD", "MAH", "MAN", "MHQ", "MIL", "MJT", "MLA", "MLH", "MLX", "MME", "MOW", "MPL", "MUC", "MXP", "NAP", "NBC", "NCE", "NRA", "NRK", "NTE", "NUE", "NVK", "ODE", "ODS", "OER", "OHD", "OLB", "OMO", "OMS", "OPO", "ORK", "ORY", "OSD", "OSL", "OSR", "OST", "OTP", "OUL", "OVB", "OVD", "PAR", "PDV", "PGF", "PIK", "PMI", "PMO", "PNL", "POR", "PRG", "PRJ", "PRO", "PSA", "PSR", "PUF", "PUY", "PVK", "PXO", "PZE", "PZY", "REG", "REK", "RHO", "RMI", "RMS", "RNB", "RNN", "RNS", "ROM", "ROU", "ROV", "RRS", "RTM", "RVN", "RZE", "SBK", "SBZ", "SCN", "SCQ", "SDL", "SDR", "SEN", "SFT", "SGD", "SIP", "SJJ", "SKD", "SKE", "SKG", "SKP", "SKS", "SLD", "SMA", "SMI", "SNN", "SOF", "SOU", "SPC", "SPU", "SRT", "SSX", "STN", "STO", "STR", "SUI", "SVG", "SVO", "SVQ", "SWS", "SXB", "SXF", "SYY", "SZG", "SZO", "SZZ", "TAR", "TAS", "TBS", "TER", "TFN", "TFS", "TGD", "TGM", "THF", "TIA", "TIV", "TKU", "TLL", "TLN", "TLS", "TMP", "TOS", "TRN", "TRS", "TXL", "VCE", "VIE", "VKO", "VLC", "WAW", "ZRH"};

/**** Middle East Cities  **/
char *pMIDEASTCtyStruct[]=               

{"ABD", "AKH", "ALP", "AMM", "AQJ", "AWZ", "AZD", "BAH", "BEY", "BGW", "BND", "BSR", "BUZ", "DFD", "DHA", "DHF", "DOH", "DXB", "KAC", "KBL", "KDH", "KER", "KHI", "KHK", "KIK", "KWI", "LCA", "LHE", "MED", "MHD", "MHY", "OSM", "PEW", "PFO", "QJB", "RAH", "RIY", "RWP", "SDV", "SHJ", "SKZ", "SYZ", "TAI", "TBZ", "TDM", "THR", "TIF", "TLV", "XJD", "XWG"};

/**** Oceania Cities  **/
char *pOCEANCtyStruct[]=               

{"AAB", "ABX", "ADL", "AGK", "AKL", "ALH", "AMX", "APW", "ARM", "ASP", "AUD", "AXC", "AYQ", "AYR", "BCI", "BDB", "BEU", "BHE", "BHQ", "BKQ", "BME", "BNE", "BNZ", "BOB", "BUC", "BUL", "CAZ", "GUM", "ISI", "KAT", "KGI", "KIE", "KKO", "KNX", "KVG", "KWA", "LBS", "LEA", "LRE", "LST", "LUU", "MAJ", "MAS", "MBH", "MDU", "MEB", "MEL", "MFN", "MGB", "MIM", "MKY", "MON", "MQL", "NLK", "NOU", "NPE", "NPL", "NSN", "NTL", "OAM", "OKY", "OOL", "OOM", "ORE", "OVC", "PER", "PHE", "PKE", "PLO", "PMR", "PNI", "POM", "PPG", "PPP", "PPT", "RAB", "RBU", "RFP", "RGI", "RMA", "ROK", "ROP", "ROR", "ROT", "SIO", "SON", "SPN", "SVU", "SYD", "TBU", "TCA", "TEU", "TFP", "THG", "THY", "TIS", "TIU", "TKK", "TMW"};

/**** South American Cities  **/
char *pSAMERCtyStruct[]=               

{"AAI", "AAO", "AAX", "AEP", "AFA", "AJU", "ALQ", "ANF", "AQP", "ARI", "ARQ", "ASU", "AXM", "AYP", "BAQ", "BAU", "BAZ", "BEJ", "BEL", "BGA", "BHI", "BHZ", "BLA", "BNS", "BOG", "BRC", "BRM", "BSB", "BUE", "BVB", "BZY", "CAF", "CAJ", "CAM", "CAY", "CBB", "CBL", "CCS", "CIX", "COR", "EZE", "FOR", "GEO", "GRU", "GYE", "IBU", "IPI", "LDB", "LET", "LIM", "LOH", "LPB", "LRI", "LSC", "LSP", "LTH", "LUQ", "LVB", "MAB", "MAO", "MAR", "MCJ", "MCP", "MCS", "MCZ", "MDQ", "MDX", "MDZ", "MGD", "MGN", "MGO", "MOY", "MVD", "NNU", "NQN", "NVA", "ORU", "OTU", "OYK", "PAV", "PBL", "PBM", "PCH", "PCL", "PDP", "PEI", "PET", "PFB", "PHB", "PIN", "PIO", "PIU", "PMC", "PMG", "PMV", "PNB", "PNZ", "POA", "PPB", "PPN", "PRA", "PSO", "PSS", "PSZ", "PUD", "PUQ", "PUR", "PVH", "PYH", "PZA", "PZO", "RAO", "RBO", "RCH", "RCU", "REC", "REL", "RER", "RES", "RGA", "RGL", "RIB", "RIO", "ROO", "ROS", "SAO", "SCL", "SDE", "SDU", "SFD", "SFN", "SJA", "SLA", "SLZ", "SMR", "SNF", "SNG", "SNM", "SNV", "SOM", "SRE", "SRZ", "SSA", "STM", "SVZ", "TCO", "TCQ", "TDA", "TDD", "TGX", "THE", "TJA", "TOQ", "UIO", "VCP"};


static struct
{
   int          		EPBF010,
                        EPBF020;
   char                 EPBF010_buffer[68];
   long                 EPBF010_nRcdRead;
   long                 EPBF020_nRcdWrit;
   char			        sOrignlOrigCty[6];
   long                 nArptPrErr;
   long                 nArptCdErr;
} RS;

