/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS9004                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 06/30/95                                                */
/*              Time: 11:36:01                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS9004                           */
/******************************************************************************/
                                                                                
#ifndef   FY003087_LEN                                                          
#define   FY003087_LEN                         9                                
#endif                                                                          
#ifndef   FY003080_LEN                                                          
#define   FY003080_LEN                         7                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY003084_LEN                                                          
#define   FY003084_LEN                         26                               
#endif                                                                          
#ifndef _S9004_RPTDATASTRUCT_z                                                  
#define _S9004_RPTDATASTRUCT_z                                                  
typedef struct __S9004_RptDataStruct                                            
{                                                                               
   char                sAcrlEffDt[FY003087_LEN];                                
   char                sAudtUserId[FY003080_LEN];                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPassGrpCd[FY002488_LEN];                                
   char                sAudtChgTypNm[FY003084_LEN];                             
}  _S9004_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS9004_z                                                             
#define _EPRS9004_z                                                             
                                                                                
   typedef struct __EPRS9004                                                    
   {                                                                            
      _S9004_RPTDATASTRUCT S9004_RptDataStruct;                                 
   }  _EPRS9004;                                                                
#endif                                                                          
                                                                                
