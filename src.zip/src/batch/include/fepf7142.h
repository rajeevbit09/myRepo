/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF7142                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 03/07/96                                                */
/*              Time: 11:20:08                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF7142                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002794_LEN                                                          
#define   FY002794_LEN                         9                                
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F7142_RPTDATASTRUCT_z                                                  
#define _F7142_RPTDATASTRUCT_z                                                  
typedef struct __F7142_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sPprNm[FY002480_LEN];                                    
   char                sPprInttxNbr[FY002794_LEN];                              
   float               fNrevPmtAmt;                                             
   double              fFltImptWageAmt;                                         
   char                sFltFeeEndDt[FY003586_LEN];                              
   char                sPassGrpCd[FY002488_LEN];                                
   char                cRecEndLineTxt;                                          
}  _F7142_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF7142_z                                                             
#define _EPRF7142_z                                                             
                                                                                
   typedef struct __EPRF7142                                                    
   {                                                                            
      _F7142_RPTDATASTRUCT F7142_RptDataStruct;                                 
   }  _EPRF7142;                                                                
#endif                                                                          
                                                                                
