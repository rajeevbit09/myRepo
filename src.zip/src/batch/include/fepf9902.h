/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF9902                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/24/95                                                */
/*              Time: 14:14:20                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF9902                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                          
#define   FY002516_LEN                         3
#endif
#ifndef   FY003591_LEN
#define   FY003591_LEN                         27
#endif
#ifndef   FY000014_LEN
#define   FY000014_LEN                         9 
#endif
#ifndef   FY002601_LEN
#define   FY002601_LEN                         51
#endif
#ifndef   FY003593_LEN
#define   FY003593_LEN                         27
#endif
#ifndef   FY002535_LEN
#define   FY002535_LEN                         3 
#endif
#ifndef _F9902_RPTDATASTRUCT_z                                                  
#define _F9902_RPTDATASTRUCT_z                                                  
typedef struct __F9902_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];
   char                sPassStsChgDt[FY003591_LEN];
   char                sArchLastUpdtId[FY000014_LEN];
   char                sNrevCmntTxt[FY002601_LEN];
   char                sPassSusExpDt[FY003593_LEN];
   char                sPassStsCd[FY002535_LEN];
   char                cRecEndLineTxt;                                          
}  _F9902_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF9902_z                                                             
#define _EPRF9902_z                                                             
                                                                                
   typedef struct __EPRF9902                                                    
   {                                                                            
      _F9902_RPTDATASTRUCT F9902_RptDataStruct;                                 
   }  _EPRF9902;                                                                
#endif                                                                          
                                                                                
