/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS0540                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/18/95                                                */
/*              Time: 14:18:04                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS0540                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef _S0540_RPTDATASTRUCT_z                                                  
#define _S0540_RPTDATASTRUCT_z                                                  
typedef struct __S0540_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltDprtDt[FY003584_LEN];                                
}  _S0540_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS0540_z                                                             
#define _EPRS0540_z                                                             
                                                                                
   typedef struct __EPRS0540                                                    
   {                                                                            
      _S0540_RPTDATASTRUCT S0540_RptDataStruct;                                 
   }  _EPRS0540;                                                                
#endif                                                                          
                                                                                
