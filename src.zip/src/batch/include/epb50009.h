/****************************************************************************
**                                                                         **
** File Name :      EPB50009.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Delta Air Lines                                        **
**                  Gay Whitman                                            **
**                                                                         **
** Date Created:                                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"

/* Service request and answer blocks */

#include "fyr04780.h"
#include "fya04780.h"
#include "fyr04781.h"
#include "fya04781.h"
#include "fyr04782.h"
#include "fya04782.h"
#include "fyr04783.h"
#include "fya04783.h"

_R04780 R04780;
_A04780 A04780;
_R04781 R04781;
_A04781 A04781;
_R04782 R04782;
_A04782 A04782;
_R04783 R04783;
_A04783 A04783;

#define SERVICE_ID_04780  4780   /** primitive select bdy_nrev_pax_cfcn      **/
#define SERVICE_ID_04782  4782   /** primitive insert bdy_nrev_pax_cfcn      **/
#define SERVICE_ID_04783  4783   /** primitive uodate bdy_nrev_pax_cfcn      **/
char sPprNbr[10];
char cBdyCd;


/* Function definitions */
void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessInterfaceRecords();
void    DPM_4920_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();


#define NUMBER_OF_THREADS 1
#define EPBINQ0 0
#define YES_CHAR	'Y'
#define NO_CHAR     'N'

char cEndOfData;
char sFileMsg[40];

static struct
{
   char    		start_of_save;
   int   		EPBF010,
                EPBF020,
                EPBF030;
   char         EPBF010_buffer[109],
                sPprNbr[9],
                cBdyFill,
		cBdyCode,
                cErrorInd,
                cFirstReadInd;
   int          nTotHdrCnt,
                EPBF010_nRcdRead,
                EPBF020_nRcdWrit,
                EPBF030_nRcdWrit;
   char    		end_of_save;
} RS;




