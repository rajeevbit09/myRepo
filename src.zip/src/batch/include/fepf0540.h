
	/*                                                                            */
	/*   Header name  :   FEPF0540                                                */
	/*                                                                            */
	/*   Description  :                                                           */
	/*                                                                            */
	/*   Generation Date: 02/28/96                                                */
	/*              Time: 16:34:54                                                */
	/******************************************************************************/
											
	/******************************************************************************/
	/* The following are #DEFINES for typedef _EPRF0540                           */
	/******************************************************************************/
											
	#ifndef   FY002480_LEN                                                          
	#define   FY002480_LEN                         31                               
	#endif                                                                          
	#ifndef   FY002479_LEN                                                          
	#define   FY002479_LEN                         10                               
	#endif                                                                          
	#ifndef   FY002475_LEN                                                          
	#define   FY002475_LEN                         25                               
	#endif                                                                          
	#ifndef   FY002476_LEN                                                          
	#define   FY002476_LEN                         25                               
	#endif                                                                          
	#ifndef   FY002477_LEN                                                          
	#define   FY002477_LEN                         25                               
	#endif                                                                          
	#ifndef   FY002478_LEN                                                          
	#define   FY002478_LEN                         4                                
	#endif                                                                          
	#ifndef   FY002482_LEN                                                          
	#define   FY002482_LEN                         3                                
	#endif                                                                          
	#ifndef   FY002518_LEN                                                          
	#define   FY002518_LEN                         10                               
	#endif                                                                          
	#ifndef   FY002516_LEN                                                          
	#define   FY002516_LEN                         3                                
	#endif                                                                          
	#ifndef   FY002531_LEN                                                          
	#define   FY002531_LEN                         31                               
	#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002636_LEN                                                          
#define   FY002636_LEN                         16                               
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002635_LEN                                                          
#define   FY002635_LEN                         3                                
#endif   
#ifndef   FY005029_LEN
#define   FY005029_LEN                         3
#endif   
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F0540_RPTDATASTRUCT_z                                                  
#define _F0540_RPTDATASTRUCT_z                                                  
typedef struct __F0540_RptDataStruct                                            
{                                                                               
   char                sPprNm[FY002480_LEN];                                    
   char                sPprNbr[FY002479_LEN];                                   
   char                sPpr1Addr[FY002475_LEN];                                 
   char                sPpr2Addr[FY002476_LEN];                                 
   char                sPprCtyAddr[FY002477_LEN];                               
   char                sPprCtryCd[FY002478_LEN];                                
   char                sPprStCd[FY002482_LEN];                                  
   char                sPprZipAddr[FY002518_LEN];                               
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevNm[FY002531_LEN];                                   
   char                sFltDprtDt[FY003584_LEN];                                
   char                sSvcChrgDs[FY002636_LEN];                                
   char                sFltOrigCtyId[FY002521_LEN];                             
   char                sFltDestCtyId[FY002522_LEN];                             
   //double              dCostChrgAmt;
   char                sCostChrgAmt[20];
   char                sSvcChrgCd[FY002635_LEN]; 
   char                sOthrEmptCd[FY005029_LEN];
   char                cRecEndLineTxt;
}  _F0540_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF0540_z                                                             
#define _EPRF0540_z                                                             
                                                                                
   typedef struct __EPRF0540                                                    
   {                                                                            
      _F0540_RPTDATASTRUCT F0540_RptDataStruct;                                 
   }  _EPRF0540;                                                                
#endif                                                                          
                                                                                
