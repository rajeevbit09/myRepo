/****************************************************************************
**                                                                         **
** File Name :      EPB90002.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB90002 module.                                   **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Created:    May 11, 1995                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/
#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/*
 * Report sort and data layouts
 */

#include "fepf9002.h"      /** report data layout (name of copybook) **/
#include "feps9002.h"      /** report sort layout (name of copybook) **/

_EPRF9002 EPRF9002;        /** Report1 Data Layout **/
_EPRS9002 EPRS9002;        /** Report1 Sort Layout **/

/*
 * Service request and answer blocks
 */

#include "fyr02770.h"      /** service request layout (name of copybook) **/
#include "fya02770.h"      /** service answer layout (name of copybook) **/
 
_R02770 R02770;        /** Service Request Layout **/
_A02770 A02770;        /** Service Answer Layout **/

#define SERVICE_ID_02770  2770

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_5010_Generate();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS     1         /** enter number of threads needed **/
#define EPBINQ0               0         /** enter the associated thread number **/

static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/

   int PRAF010;        /** Report output file **/


   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   char    sPprStnId[6],
           sPprDeptNbr[6],
           sPprNbr[10],
           sNrevNbr[3],
           sPassTypCd[3],
           sFltDprtDt[27],
           sFltNbr[6],
           sFltOrigCtyId[6],
           sFltFeeBegDt[27],
           sFltFeeEndDt[27];

   /**** Flag for all rows processed ****/
   short        nProcessedAllRows;

   /** Part of Report request table saved to "re_sync" report requests at restart **/


   char    end_of_save;

}  RS;
