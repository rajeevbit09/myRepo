/****************************************************************************
**                                                                         **
** File Name :      EPB40005.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author:          Duane Ellis                                            **
**                                                                         **
** Date Created:    8/2012                                                 **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by    Description                                    **
** --------   ----------    --------------------                           **
** 8/6/2012   Duane Ellis   Inital Program Creation                        **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/* Service request and answer blocks */


#include "fyr04741.h"
#include "fya04741.h"
#include "fyr04742.h"
#include "fya04742.h"
#include "fyr04744.h"
#include "fya04744.h"
#include "fyr04756.h"
#include "fya04756.h"


_R04741 R04741;
_A04741 A04741;
_R04742 R04742;
_A04742 A04742;
_R04744 R04744;
_A04744 A04744;
_R04756 R04756;
_A04756 A04756;


#define SERVICE_ID_04741  4741   /** SELECT NRAP_CRTF where cur_tkt = certificate         **/
#define SERVICE_ID_04742  4742   /** SELECT NRAP_CRTF WHERE init_tkt = certificate        **/
#define SERVICE_ID_04744  4744   /** SELECT NRAP by TKT_DSGTR_TXT                         **/
#define SERVICE_ID_04756  4756   /** INSERT record into INTO NRAP_CRTF                    **/

#define MODULE_NAME                  "epb40005"

/* #defines and global variables */
#define NUMBER_OF_THREADS 2
#define EPBUPD0 0
#define EPBINQ0 1
#define EPBINQ1 2

short   nSvcRtnCd;
int     retval;

#ifndef true
#define true   1
#define false  0
#endif

#define NULL_CHAR   '\0'

/* This is the structure for the eNCI record record layout */
struct _ENCI_REC
{
   char PPR_NBR[9];                 // PPR Number
   char CUST_FIRST_NM[50];          // Customer First Name; Left-aligned;
   char CUST_LAST_NM[50];           // Customer Last Name; Left-aligned; May also contain a suffix.
   char TKT_DSGTR_TXT[15];          // Ticket Designator for award pgm. Left-aligned; e.g. FR958
   char INIT_TKT_DOC_NB[15];        // Tkt Doc Num   eNCI Certificate Number; 13 digits; Left-aligned
   char INIT_TKT_DOC_ISS_LDT[8];    // Certificate Issue Date; Format: YYYYMMDD e.g. 20120125
   char REDEMPTION_CD[10];          // Redemption Code; Left-aligned
   char XCHG_TKT_DOC_NB[15];        // (if avail) Exchange Ticket Nbr; 13 digits; Left-aligned
   char XCHG_TKT_DOC_ISS_LDT[8];    // (if avail) Format: YYYYMMDD e.g. 20120215
   char END_OF_REC;
} * ENCI_REC;


/* Function definitions */

void  TPM_1000_Initialize();
void  TPM_2000_Mainline();
void  TPM_3000_ProcessFileEPBF005();
void  TPM_4000_ProcessENCIRecord();
void  TPM_5000_InsertCertificate();
int   TPM_8001_FindExistingCert(char *);
int   TPM_8002_GetAwardInfoUsingTktDsgtr();
void  TPM_9000_ProcessEndOfProgram();


static struct
{
   char    start_of_save;

   // File handle and input buffer for ENCI file
   int   EPBF005;              // Input ENCI file
   char  EPBF005_buffer[500];  // Should be ample Buffer!
   int   reclen;               // Record Length

   //---- NRAP_CRTF fields ------
   char  sCurTktDocNb[15+1];
   char  sCurTkDcIssLdt[27];   // DB Format: YYYY-MM-DD-HH24:MI:SS
   char  sInitTktDocNb[15+1];
   char  sInitTkDcIssLdt[27];  // DB Format: YYYY-MM-DD-HH24:MI:SS
   char  sNrapCd[8+1];
   short nNrapSpgmNb;
   char  sNrapFrstBkgLdt[27];  // DB Format: YYYY-MM-DD-HH24:MI:SS
   char  sPprNbr[9+1];
   char  cNrapCrtfSttCd;       // Status Code

   char  sCustFirstNm[50+1];
   char  sCustLastNm[50+1];
   char  sTktDesignator[15+1];
   char  sRedemptionCd[10+1];

   //----

   long  Rec_Cnt;              // Number of ENCI records processed
   long  Insert_Cnt;           // Number of records written to NRAP_CRTF table
   long  Update_Cnt;           // Number of NRAP_CRTF records updated
   long  Duplicate_Cnt;        // Number of certificates already on file (duplicates)
   long  Error_Cnt;            // Number of Runtime Errors encountered

   char  end_of_save;

} RS;














