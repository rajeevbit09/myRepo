/*######################################################################*/
/*                                                                      */
/* Copyright [2001] Delta Air Lines, Inc./Delta Technology, Inc.        */
/*                       All Rights Reserved                            */
/*               Access, Modification, or Use Prohibited                */
/* Without Express Permission of Delta Air Lines or Delta Technology.   */
/*                                                                      */
/*######################################################################*/
/***************************************************************************/
/***************************************************************************/
/*               D E L T A   A I R   L I N E S,  I N C.                    */
/*                                                                         */
/*  SYSTEM       : FINANCE REENGINEERING SYSTEM                            */
/*                                                                         */
/*  SUBSYSTEM    : ECEP                                                    */
/*                                                                         */
/*  HEADER NAME  : FRAPECEP.h                                              */
/*                                                                         */
/*  AUTHOR       : Transquest                                              */
/*                 Faith Ammons                                            */
/*                                                                         */
/*  DATE WRITTEN : 05/18/95                                                */
/*                                                                         */
/*  DESCRIPTION  : This include file contains various includes, function   */
/*                 prototypes, global variable declarations, macro         */
/*                 definitions, and constants unique to the processing     */
/*                 of FRAPECEP.                                            */
/*                                                                         */
/*  REVISION TRAIL :                                                       */
/*                                                                         */
/*    DATE     PRMR    NBR                   DESCRIPTION                   */
/*  --------   ----    ---   --------------------------------------------  */
/*                                                                         */
/*   8/14/95    FFA     1    Moved global defines from ECEPGLBLDEFS.h, and */
/*                           deleted reference to ECEPGLBLDEFS.h           */
/*                                                                         */
/*   2/27/96    FFA     2    Added lots of new pass group codes.           */
/*                                                                         */
/*   6/29/99    LAS     3    Added Companion (CP) nonrev passenger type.   */
/*                                                                         */
/*   2/07/01    LAS     4    Added pass type 15 for REWARD.                */
/*                                                                         */
/*   4/06/01    LAS     5    Added pass groups for Delta Global Services:  */
/*                           GM, GK, GC, GT, GS and GR.                    */
/*                                                                         */
/*   6/11/01    LAS     6    Added new passenger types for domestic partner*/
/*                           relationships.                                */
/*                           CD - Domestic Partner minor child             */
/*                           SD - Domestic Partner student                 */
/*                           DD - Domestic Partner dependent adult         */
/*                                                                         */
/*  10/02/01    LAS     7    Added pass groups for Delta Recovery Program: */
/*                           VA - Voluntary Leave Time (SDW) w/kids        */
/*                           VB - Voluntary Leave Time (SDW) w/o kids      */
/*                           VC - Voluntary Leave Time (M/CP)              */
/*                           VR - Voluntary Severance DL Recovery          */
/*                                                                         */
/*  11/28/01    LAS     9    Added another pass group for Delta Recovery   */
/*                           Program:                                      */
/*                           FP - Furloughed Pilot                         */
/*                                                                         */
/*  11/08/02    LAS     10   Added pass group for Delta Workforce Program: */
/*                           FV - Furloughed Inactive                      */
/*                                                                         */
/*  08/08/03    LAS     11   Added pass groups for Connection Carriers:    */
/*                           CC - Connection Carrier active non-crew       */
/*                           CR - Connection Carrier crew                  */
/*                           CX - Connection Carrier retired               */
/*                                                                         */
/*  10/07/03    LAS     12   Added pass groups for merit furloughed:       */
/*                           TM - Merit furloughed.                        */
/*                                                                         */
/*  10/23/03    LAS     13   Added pass types 05 POSTV_SPACE for positive  */
/*                           space and 12 CO_BUSINESS for company business.*/
/*                                                                         */
/*  09/20/04    LAS     14   Added pass group CU - Rehired Retiree         */
/*                                                                         */
/*  11/09/04    LAS     15   Added pass group TO - Travel Op Severance     */
/*                                                                         */
/*  03/04/05    LAS     16   Added BUDDY "BU" passenger type               */
/*                                                                         */
/*  10/11/05    EJS     17   Added DEACTIVATED "ER" FOR STATUS CODE        */
/*                                                                         */
/*  04/18/07    LAS     18   Added pass group                              */
/*                           CA - Connection Carrier (prorate) active      */
/*                                                                         */
/*                           Added passenger type "DP" Domestic Partner    */
/*                                                                         */
/*  12/03/07    LAS     19   Added pass group                              */
/*                           CZ - Skywest/ASA active                       */
/*                                                                         */
/*  01/10/07    LAS     20   Added ZED Fare "ZD" pass type.                */
/*                                                                         */
/*  07/11/08    LAS     21   Added pass groups                             */
/*                           NW - Northwest active                         */
/*                           NR - Northwest retiree                        */
/*                                                                         */
/*  11/06/08    LAS     22   NW pass groups were left in even though they  */
/*                           will not be used.   These were originally     */
/*                           added on 7-11-08.                             */
/*                                                                         */
/*  11/06/08    LAS     23   Added pass group CY for Non-Delta dedicated   */
/*                           Skywest employees.                            */
/*                                                                         */
/*  03/30/09    LAS     24   Added pass group CB for the new DCI groupings.*/
/*                           Also added pass types "F3" (30% confimred) and*/
/*                           "CL" (positive space confirmed leisure).      */
/*                           Added pass group CW for DCI retirees.         */
/*                                                                         */
/*  03/05/10    LAS     25   Added new region codes.                       */
/*                                                                         */
/*  03/10/10    DEllis  26   Removed redefinition of TRANSQUEST_FROMDL     */
/*                                                                         */
/*  12/06/10    BBE     27   Added new pass groups for Ready Reserves:     */
/*                           JM - Ready Reserve (M)                        */
/*                           JS - Ready Reserve (SDW) w/o kids             */
/*                           JK - Ready Reserve (SDW) with kids            */
/*                           Modified the label for the MR, SR, & KR pass  */
/*                           groups to be specific for Coops & Interns.    */
/*                           Added pass group CV for DCI retirees for      */
/*                           not owned and not ZED eligible.               */
/*                                                                         */
/*  12/29/10    LAS     28   Added new charge type "TS" for Transoceanic   */
/*                           Service Charge.                               */
/*                                                                         */
/***************************************************************************/

#include "stdlib.h"

/****  pass groups      ****/

#define ACTIVE_DL              "AC"                /** Active DL (SDW) without kids        **/
#define ACTIVE_DL_WK           "AK"                /** Active DL (SDW) with kids           **/
#define ACTIVE_DL_MRD          "MA"                /** Active DL (M)                       **/
#define SENIOR_OFFICERS        "SO"                /** Senior officers (SDW) w/o kids      **/
#define SENIOR_OFFICERS_WK     "SK"                /** Senior officers (SDW) with kids     **/
#define SENIOR_OFFICERS_MRD    "SM"                /** Senior officers (M)                 **/
#define BOARD_MEMBERS          "BM"                /** Board members                       **/
#define EXPATRIOTS             "EP"                /** Expatriots - DL                     **/

#define RDYRSV_MARRIED         "JM"                /** Ready Reserve (M)                   **/
#define RDYRSV_SINGLE          "JS"                /** Ready Reserve (SDW) w/o kids        **/
#define RDYRSV_SINGLE_WK       "JK"                /** Ready Reserve (SDW) with  kids      **/

#define COOPINT_MARRIED        "MR"                /** Coops & Interns (M)                 **/
#define COOPINT_SINGLE         "SR"                /** Coops & Interns (SDW) w/o kids      **/
#define COOPINT_SINGLE_WK      "KR"                /** Coops & Interns (SDW) with  kids    **/

#define TEMPDL_MARRIED         "MT"                /** Associate DL (M)                    **/
#define TEMPDL_SINGLE          "ST"                /** Associate DL (SDW) without kids     **/
#define TEMPDL_SINGLE_WK       "KT"                /** Associate DL (SDW) with kids        **/

#define DISABLED_RETRD_SDW     "DA"                /** Disabled, >52, 10 yrs svc (SDW)     **/
#define DISABLED_RETRD_MRD     "DB"                /** Disabled, >52, 10 yrs svc (M)       **/
#define DISABLED_DL_SDW        "DS"                /** Disabled DL (SDW)                   **/
#define DISABLED_DL_MRD        "MD"                /** Disabled DL (M)                     **/

#define LEAVE_OF_ABSENCE       "LC"                /** Leave of absence - company conv     **/
#define LOA_SICK_SDW_WK        "LK"                /** Leave of absence, sick (SDW) w/kids **/
#define LOA_SICK_SDW           "LS"                /** Leave of absence, sick (SDW) w/o kids **/
#define LOA_EXTENDED_PERSONAL  "LP"                /** Leave of absence, extended personal **/
#define LOA_SICK_MRD           "LM"                /** Leave of absence, sick (M)          **/

#define FURL_EMPL              "FU"                /** Furloughed Employee                 **/
#define MILITARY_LEAVE         "LT"                /** Military leave (> 30)               **/

#define QTO_SDW_WK             "QK"                /** Leadership 7.5 QTO (SDW) with kids  **/
#define QTO_SDW                "QT"                /** Leadership 7.5 QTO (SDW) w/out kids **/
#define QTO_MRD                "QM"                /** Leadership 7.5 QTO (M)              **/
#define VOL_SEV                "VS"                /** Leadership 7.5 voluntary severence  **/

#define RETIRED_EARLY_SIX      "RE"                /** Retired Early Six                   **/
#define RETIRED_LIMIT_DELTA    "RL"                /** Retired Limit DL                    **/
#define RETIRED_DELTA          "RR"                /** Regular retired DL                  **/
#define RETIRED_ASSOCIATE      "RT"                /** Regular retired associate           **/

#define PANAM                  "PA"                /** Pan Am participant                  **/
#define TRANSQUEST_FROMDL      "TD"                /** TQ - former DL                      **/
#define TRANSQUEST_NONDL       "TQ"                /** TQ - not former DL                  **/
#define TRANSQUEST_FROMDL_RET  "TR"                /** TQ - former DL retired              **/

#define WORLDSPAN_FROMDL       "WA"                /** WS active fmr DL (SDW) without kids **/
#define WORLDSPAN_FROMDL_MRD   "WB"                /** WS active fmr DL (M)                **/
#define WORLDSPAN_DSABLD_SDW   "WC"                /** WS disabled fmr DL (SDW)            **/
#define WORLDSPAN_DSABLD_MRD   "WD"                /** WS disabled fmr DL (M)              **/
#define WORLDSPAN_RTRD_FROMDL  "WF"                /** WS retired fmr DL                   **/
#define WORLDSPAN_RTRD_NONDL   "WG"                /** WS retired not fmr DL               **/
#define WORLDSPAN_MLTRY_LV     "WH"                /** WS military leave, fmr DL           **/
#define WORLDSPAN_FROMDL_WK    "WK"                /** WS active fmr DL (SDW) with kids    **/
#define WORLDSPAN_LEAVE        "WL"                /** WS leave - frmr DL                  **/
#define WORLDSPAN_TEMP_MRD     "WM"                /** WS temp frm DL (M)                  **/
#define WORLDSPAN_NONDL        "WN"                /** WS - not former DL                  **/
#define WORLDSPAN_TEMP_SDW     "WS"                /** WS temp frm DL (SDW) without kids   **/
#define WORLDSPAN_TEMP_SDW_WK  "WT"                /** WS temp frm DL (SDW) with kids      **/

#define WESTERN_EARLYOUT       "WE"                /** Western Early-out                   **/
#define WESTERN_RETIREE        "WR"                /** Western Retiree                     **/
#define FORMER_WESTERN_EMP     "FW"                /** Former Western Employee             **/

#define DISABLED_LIM_WIDOW     "DW"                /** Disabled limit widow                **/
#define EARLY_THREE_WIDOW      "EW"                /** Early three widow                   **/
#define RETIREE_LIM_WIDOW      "LW"                /** Retiree limit widow                 **/
#define OJI_WIDOW              "OW"                /** OJI widow                           **/
#define THREE_MTH_WIDOW        "TW"                /** Three Month Widow                   **/
#define UNLIM_WIDOW            "UW"                /** Unlimited widow                     **/

#define DGS_AVTN_SEC_MRD       "GM"                /** DGS Aviation/Security (M)           **/
#define DGS_AVTN_SEC_SDW_WK    "GK"                /** DGS Aviation/Security (SDW) w/kids  **/
#define DGS_AVTN_SEC_SDW       "GC"                /** DGS Aviation/Security (SDW) no kids **/
#define DGS_TEMP_STAFF_MRD     "GT"                /** DGS Temp Staffing (M)               **/
#define DGS_TEMP_STAFF_SDW_WK  "GS"                /** DGS Temp Staffing (SDW) with kids   **/
#define DGS_TEMP_STAFF_SDW     "GR"                /** DGS Temp Staffing (SDW) no kids     **/
#define VOL_LEAVE_SDW_WK       "VA"                /** Voluntary Leave Time (SDW) with kids**/
#define VOL_LEAVE_SDW          "VB"                /** Voluntary Leave Time (SDW) no kids  **/
#define VOL_LEAVE_MRD          "VC"                /** Voluntary Leave Time (M)            **/
#define VOL_SEV_DL_RECOVERY    "VR"                /** Voluntary Severance DL Recovery     **/
#define FURL_PILOT             "FP"                /** Furloughed Pilot                    **/
#define INTERN                 "IN"                /** Intern                              **/
#define FURL_INACTIVE          "FV"                /** Furloughed Inactive                 **/
#define CONN_CARR_ACTIVE       "CC"                /** Connection Carrier active non-crew  **/
#define CONN_CARR_CREW         "CR"                /** Connection Carrier crew (PS Co-Bus) **/
#define CONN_CARR_RETIREE      "CX"                /** Connection Carrier retireee         **/
#define CONN_CARR_PRORATE      "CA"                /** Connection Carrier prorate - active **/
#define FURL_MERIT             "TM"                /** Furloughed Merit                    **/
#define REHIRE_RETIREE         "CU"                /** Rehired Retiree                     **/
#define SKYWEST_ASA_ACTIVE     "CZ"                /** Skywest and ASA active              **/
#define TRAVEL_OP_SEV          "TO"                /** Travel Option - Severance           **/
#define NORTHWEST_ACTIVE       "NW"                /** Northwest Active                    **/
#define NORTHWEST_RETIREE      "NR"                /** Northwest Retiree                   **/
#define NON_DELTA_DEDICATED    "CY"                /** Non-Delta Dedicated Skywest employees        **/
#define CONN_DELTA             "CB"                /** Connection Delta - OH,RS emps         **/
#define CONN_DELTA_RETIREE     "CW"                /** Connection Delta Retiree - OH,RS emps **/
#define CONN_CARR_NOZED        "CV"                /** Connection Carrier Retiree Not ZED eligible  **/
#define INELIG_PASS_GRP        "XX"                /** Ineligible Pass group                        **/

/****  Passenger types  ****/

#define SELF               "SF"
#define SPOUSE             "SP"
#define DEP_CHILD          "MC"
#define DEP_CHILD_STUDENT  "ST"
#define NONDEP_CHILD       "ND"
#define PARENT             "PR"
#define DEP_ADULT          "DA"
#define COMPANION          "CP"
#define DOM_PART_CHILD     "CD"
#define DOM_PART_STUDENT   "SD"
#define DOM_PART_DEP_ADULT "DD"
#define BUDDY              "BU"
#define DOMESTIC_PARTNER   "DP"

/****  pass types    ****/

#define POSTV_SPACE        "05"
#define EMERGENCY          "10"
#define CO_BUSINESS        "12"
#define REWARD             "15"
#define PRIORITY           "20"
#define HONOR_ROLL         "30"
#define TRANSOCEANIC       "40"
#define DOMESTIC           "50"
#define COMB_DOM_TO        "90"
#define FAM_FARES          "FA"
#define ZED_FARES          "ZD"
#define FAM_FARES_30%      "F3"
#define CONFIRMED_LEISURE  "ZD"
/****  airport pair types and region codes ****/

#define DOMESTIC_ARPTPR    "DM"
#define TRANSATLANTIC      "TA"
#define TRANSPACIFIC       "TP"
#define INTRAEURO          "IE"
#define CANADA             "CN"
#define ALASKA             "AK"
#define HAWAII             "HI"
#define LATIN_AMERICA      "LA"
#define DFLT_ARPTPRTYP     "**"
#define US_REGION          "US"
#define GERMAN_REGION      "GM"
#define EUR_ASIA           "EA"
#define US_TERRITORIES     "UT"
#define AFRICA_REGION      "AF"
#define ASIA_REGION        "AS"
#define CARIBBEAN_REGION   "CB"
#define C_AMERICA_REGION   "CA"
#define S_AMERICA_REGION   "SA"
#define EUROPE_REGION      "EU"
#define MIDEAST_REGION     "ME"
#define OCEANIA_REGION     "OC"
#define MEXICO_REGION      "MX"


/**** pass status codes    ****/

#define SUSPENDED    "SU"
#define REVOKED            "RV"
#define ACTIVE             "AC"
#define REVOKED_DEATH      "RD"
#define EMP_REVOKED        "ER"

/**** charge type codes    ****/

#define SERVICE_CHARGE     "SV"
#define FLAT_FEE_SVCCHG    "FT"
#define HONORROLL_PENALTY_INTL  "IP"
#define FLIGHT_PENALTY     "FP"
#define PREMIUM_CHARGE     "UP"
#define INTL_FEE           "IF"
#define HANDLING_FEE       "HD"
#define FARE               "FR"
#define QTO_PASSCARD_CHRG3 "Q1"
#define QTO_PASSCARD_CHRG5 "Q2"
#define PASSCARD_CHARGE    "PC"
#define LOSTCARD1_CHARGE   "L1"
#define LOSTCARD2_CHARGE   "L2"
#define LOSTCARD3_CHARGE   "L3"
#define REISSUE_CERT_CHARGE "RC"
#define TRANSOCEANIC_SVCCHG "TS"


/**** match indicator   ****/

#define UNMATCHED          'U'
#define MATCHED            'M'
#define APPROVED           'A'
#define NOTIFIED           'N'
#define PROCESSED          'P'
#define CORRECTED          'C'
#define UNMATCHED_DESCR    "UNMATCHED"
#define MATCHED_DESCR      "MATCHED"
#define APPROVED_DESCR     "APPROVED"
#define NOTIFIED_DESCR     "NOTIFIED"
#define PROCESSED_DESCR    "PROCESSED"
#define CORRECTED_DESCR    "CORRECTED"


/***  other common values  ****/

#define USD_CURR           "USD"
#define USA                "USA"
#define LOW_VALUES         '\0'
#define ENDLINE_CHAR       '\n'
#define SPACE_CHAR         " "
#define NULL_STRING        ""
#define LANDSCAPE          132
#define PORTRAIT           80
#define LOW_DATE           "1899-12-31-00:00:00"
#define SPECIAL_DATE       "1950-12-31-00:00:00"


#if !defined(MINUS)
#define MINUS '-'
#endif

#if !defined(PLUS)
#define PLUS '+'
#endif

#if !defined(DECIMAL_PT)
#define DECIMAL_PT '.'
#endif
