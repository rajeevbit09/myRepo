/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF9901                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/24/95                                                */
/*              Time: 14:14:20                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF9901                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                          
#define   FY002516_LEN                         3
#endif
#ifndef   FY003591_LEN
#define   FY003591_LEN                         27
#endif
#ifndef   FY003592_LEN
#define   FY003592_LEN                         27
#endif
#ifndef _F9901_RPTDATASTRUCT_z                                                  
#define _F9901_RPTDATASTRUCT_z                                                  
typedef struct __F9901_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];
   char                sNrevNbr[FY002516_LEN];
   char                sPassStsChgDt[FY003591_LEN];
   char                sPprStrtDt[FY003592_LEN];
   char                cRecEndLineTxt;
}  _F9901_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF9901_z                                                             
#define _EPRF9901_z                                                             
                                                                                
   typedef struct __EPRF9901                                                    
   {                                                                            
      _F9901_RPTDATASTRUCT F9901_RptDataStruct;                                 
   }  _EPRF9901;                                                                
#endif                                                                          
                                                                                
