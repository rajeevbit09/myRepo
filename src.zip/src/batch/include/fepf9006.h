/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF9006                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/11/95                                                */
/*              Time: 13:32:22                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF9006                           */
/******************************************************************************/
                                                                                
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY003585_LEN                                                          
#define   FY003585_LEN                         27                               
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F9006_RPTDATASTRUCT_z                                                  
#define _F9006_RPTDATASTRUCT_z                                                  
typedef struct __F9006_RptDataStruct                                            
{                                                                               
   char                sFltNbr[FY002553_LEN];                                   
   //long                lPsgr5RatNbr;
   char                sPsgr5RatNbr[9];                            
   //long                lPsgr10RatNbr;                                           
   char                sPsgr10RatNbr[9];
   char                sFltFeeBegDt[FY003585_LEN];                              
   char                sFltFeeEndDt[FY003586_LEN];                              
   char                cRecEndLineTxt;                                          
}  _F9006_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF9006_z                                                             
#define _EPRF9006_z                                                             
                                                                                
   typedef struct __EPRF9006                                                    
   {                                                                            
      _F9006_RPTDATASTRUCT F9006_RptDataStruct;                                 
   }  _EPRF9006;                                                                
#endif                                                                          
                                                                                
