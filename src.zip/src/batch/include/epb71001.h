/****************************************************************************
**                                                                         **
** File Name :      EPB71001.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Transquest                                             **
**                  Kimberly Gordon                                        **
**                  August 22, 1995                                        **
**                                                                         **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/*
 * You should include any subsytem header files here. For example:
 * #include "subsystem_db_io/current_date.h"
 *
 */

/*
 * Report sort and data layouts
 */

#include "feps7101.h"      /** report sort layout (name of copybook) **/
#include "fepf7101.h"      /** report data layout (name of copybook) **/

_EPRF7101 EPRF7101;        /** Report1 Data Layout **/
_EPRS7101 EPRS7101;        /** Report1 Sort Layout **/

/*
 * Service request and answer blocks
 */

#include "fyr02598.h"      /** service request layout (name of copybook **/
#include "fya02598.h"      /** service answer layout (name of copybook **/
 
_R02598 R02598;        /** Service Request Layout **/
_A02598 A02598;        /** Service Answer Layout **/

#define SERVICE_ID_02598  2598

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_5000_GenerateEPB71011();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS 1        /** enter number of threads needed **/
#define EPBINQ0 0                  /** enter the associated thread number **/

static struct
{
   char     start_of_save;

   /****   Restart save area                      ******/
   /****   RSAMFILE filename declarations go here  ******/

   int      PRAF010;        /** Report output file **/

   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   short	nProcessedAllRows;
   /** Part of Report request table saved to "re_sync" report requests at restart **/


   /* Replace the following with values that will need to be saved for each commit. */
   short	rptprnt,
    		eodflag;

   char     sTblNme[20],
		    sPprNbr[10],
		    sNrevNbr[3],
    		sSvcNbr[10],
	    	sSavePprNbr[10],
		    sSaveNrevNbr[3],
		    sSaveFltDprtDt[27],
		    sFltDprtDt[8],
		    sSavePassGrpCd[3];

   int		recsproc;

   long     lSavePassTripNbr,
		    lSaveSeqNbr;

   char     end_of_save;

}  RS;
