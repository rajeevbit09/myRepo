/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5024                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/13/0705                                              */
/*              Time: 10:00:00                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5024                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5024_RPTDATASTRUCT_z                                                  
#define _S5024_RPTDATASTRUCT_z                                                  
typedef struct __S5024_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5024_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5024_z                                                             
#define _EPRS5024_z                                                             
                                                                                
   typedef struct __EPRS5024                                                    
   {                                                                            
      _S5024_RPTDATASTRUCT S5024_RptDataStruct;                                 
   }  _EPRS5024;                                                                
#endif                                                                          
                                                                                
