/****************************************************************************
**                                                                         **
** File Name :      EPB90006.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         <Company Name>                                         **
**                  <Author Name>                                          **
**                                                                         **
** Date Created:                                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
$Log:   /FRAP/ECEP/dvl/archives/src/include/EPB90006.h_v  $
?="
?="   Rev 1.1   Fri Sep 01 17:45:20 1995   twithers
?="No change.
?="
?="   Rev 1.0   Wed Dec 27 13:32:14 1995   twithers
?="Initial revision.
 * 
 *    Rev 4.1   Wed Apr 19 17:11:08 1995   sgwin
 * Update shell per Misb. Billing request
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"

/*
 * You should include any subsytem header files here. For example:
 * #include "subsystem_db_io/current_date.h"
 *
 */

/*
 * Report sort and data layouts
 */

#include "feps9006.h"      /** report sort layout (name of copybook) **/
#include "fepf9006.h"      /** report data layout (name of copybook) **/

_EPRF9006 EPRF9006;        /** Report1 Data Layout **/
_EPRS9006 EPRS9006;        /** Report1 Sort Layout **/

/*
 * Service request and answer blocks
 */

#include "fyr02768.h"      /** service request layout (name of copybook **/
#include "fya02768.h"      /** service answer layout (name of copybook **/
 
_R02768 R02768;        /** Service Request Layout **/
_A02768 A02768;        /** Service Answer Layout **/

#define SERVICE_ID_02768  2768

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_5010_Generate();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS 1        /** enter number of threads needed **/
#define EPBINQ0 0                   /** enter the associated thread number **/
#define SPACE_CHAR  " "            /** fix for bad header                  **/

static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/


   int PRAF010;        /** Report output file **/


   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   char       sFltNbr[6];
   char       sFltArptPrTypCd[3];
   char       sFltFeeBegDt[27];
   char       sFltFeeEndDt[27];

   /*** End of Data Flag ****/
   short      nProcessedAllRows;
   /** Part of Report request table saved to "re_sync" report requests at restart **/


   /* Replace the following with values that will need to be saved for each commit. */

   short   accumulator_field1;
   double  accumulator_field2;

   char    end_of_save;

}  RS;
