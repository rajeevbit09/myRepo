/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS9003                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/07/96                                                */
/*              Time: 11:27:17                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS9003                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef _S9003_RPTDATASTRUCT_z                                                  
#define _S9003_RPTDATASTRUCT_z                                                  
typedef struct __S9003_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPassRptSortDt[FY003821_LEN];                            
}  _S9003_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS9003_z                                                             
#define _EPRS9003_z                                                             
                                                                                
   typedef struct __EPRS9003                                                    
   {                                                                            
      _S9003_RPTDATASTRUCT S9003_RptDataStruct;                                 
   }  _EPRS9003;                                                                
#endif                                                                          
                                                                                
