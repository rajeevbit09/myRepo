/****************************************************************************
**                                                                         **
** File Name :      EPB97713.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB97701 module.                                   **
**                                                                         **
** Author :         TransQuest, Inc.                                       **
**                  Gayle Melton                                           **
**                                                                         **
** Date Created:    November 11, 1996                                      **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 11/04/1997   S MAKIM		          Added new counters for senior    **
**                                        officer mail file and fake zip   **
**                                        code for company mail file.      **
**                                        Removed some unused RSAM File    **
**                                        variables.                       **
**                                                                         **
**                                                                         **
**                                                                         **
****************************************************************************/
#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/*
 * You should include any subsytem header files here. For example:
 * #include "subsystem_db_io/current_date.h"
 *
 */

/*
 * No report sort and data layouts  
 */

/*
 * Service request and answer blocks
 */

#include "fyr04619.h"      /* service request layout */
#include "fya04619.h"      /* service answer layout  */
#include "fyr04620.h"      /* service request layout */
#include "fya04620.h"      /* service answer layout  */
 
_R04619 R04619;            /* Service Request Layout */
_A04619 A04619;            /* Service Answer Layout  */
_R04620 R04620;            /* Service Request Layout */
_A04620 A04620;            /* Service Answer Layout  */

#define SERVICE_ID_04619  4619
#define SERVICE_ID_04620  4620

/*
 * Function definitions
 */
void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_3000_WriteRecord(short nFileNbr,
                             char *sVarBuffer);
void    DPM_4000_UpdtCrtftRecord();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS 2   /** Number of threads used **/
#define EPBINQ0 0             /** Inquiry thread **/
#define EPBUPD0 1             /** Inquiry thread **/

#define SPACE               ' '
#define USA                 "USA"
#define US                  "US"
#define PUR                 "PUR"
#define ISV                 "ISV"
#define F_and_F             "FF"
#define A_and_B             "AB"
#define F_F                 "F"

#define PASSENGER_FORMAT    "%-9s%-30s%-24s%-24s%-24s%-2s%-10s%-30s%-5s%-6s%-6s%-2s%01d%1c%1c"
/* #define TRAILER_FORMAT      "%-8s%06d%160s" */

short     nSvcRtnCd;          /** Service return code **/
char      sUSOnlyZip[6];      /** US Indicator        **/
short     nCount;             /** Count of certificates **/
char      cCount;             /** Character Count of certificates **/
long      nSOMailCntr;        /** Senior Officer Mail record counter **/
long      nCOMailCntr;        /** Company Mail record counter **/
long      nFakeZip_COMailCntr;   /** Company Mail record counter **/
long      nUSMailCntr;        /** US Mail record counter **/
char      sEffMo[3];          /** start month ***/
char      sEffDy[3];          /** start day   ***/
char      sEffYr[3];          /** start year  ***/
char      sAbvByd;            /** Above and beyond ind ***/

static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/
   int EPBF030;                   /** Output file **/


   /******   Save database buffer here:              ******/
   char   sPprNbr[10],                 /** PPR ID **/
          sRnTyp[3],                   /** Run type **/
          sCrtNbr[3],                  /** Certificate ext number **/
          sEffDt[11],                  /** Date of run **/
          sTodayDt[9],                 /** Run date in CCYYMMDD **/
          sStrtMo[3],                  /** PPR start month ***/
          sStrtDy[3];                  /** PPR start day   ***/

   short  nMonth,                      
          nDay;

   /******   @read_into structure/buffers go here:   ******/
   char   EPBF030_buffer[176];

   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   /*******   counters and accumulators              ******/
   int   EPBF030_record_cntr,
         EPBF040_record_cntr,
         SOMail_cntr,
         COMail_cntr,
         FakeZip_COMail_cntr,
         USMail_cntr,
         USOnlyMailCntr,
         IntlMailCntr,
         total_record_cntr;

   char    end_of_save;

}  RS;
