/****************************************************************************
**                                                                         **
** Program Name:    <EPB50005.c>                                           **
**                                                                         **
** Shell Used:      <shltmpc.c>                                            **
**                                                                         **
** Program Type:    Transaction Driven Process Module                      **
**                                                                         **
**                                                                         **
** Author:          L.Scott                                                **
**                                                                         **
** Date Written:    4/2005                                                 **
**                                                                         **
** Description:     Transaction driven process modules read an input       **
**                  file record by record.  The module will perform        **
**                  some action on each input record (e.g. update          **
**                  database table).                                       **
****************************************************************************/

#include "epb50005.h"


main()
{
   BCH_Init("EPB50005", NUMBER_OF_THREADS);

   TPM_1000_Initialize();

   TPM_2000_Mainline();
}



/******************************************************************
**                                                               **
** Function Name:   TPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_1000_Initialize()
{

 
 /**** Initialize counters & accumulators ***/

 /**** Initialize flags ****/

 /**** Initialize RSAM variables ****/

 /**** Initialize Message Request and Answer Copybooks ***/
   memset(&R04716, LOW_VALUES, sizeof(_R04716));
   memset(&A04716, LOW_VALUES, sizeof(_A04716));
   memset(&R04717, LOW_VALUES, sizeof(_R04717));
   memset(&A04717, LOW_VALUES, sizeof(_A04717));
   memset(&R04718, LOW_VALUES, sizeof(_R04718));
   memset(&A04718, LOW_VALUES, sizeof(_A04718));
   memset(&R04721, LOW_VALUES, sizeof(_R04721));
   memset(&A04721, LOW_VALUES, sizeof(_A04721));

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_1000_Initialize");

   /**************************************************/ 
   /** set up today's date in CCYYMMDD format       **/ 
   /**************************************************/ 
   memset(&RS.sTodayDt, LOW_VALUES, sizeof(RS.sTodayDt));
   strncpy(RS.sTodayDt, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD), sizeof(RS.sTodayDt));

   /************************************************************************/
   /*********** Call RSAM to open each file that is used for input *********/
   /************************************************************************/

   RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_READ);
   if (RS.EPBF010 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_1000_Initialize");
   }


   /*********** Call RSAM to read first input record ************/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));

   if (BCH_eof(RS.EPBF010))
   {
       BCH_FormatMessage(1,TXT_EMPTY_INPUT_FILE);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_1000_Initialize");
   }
}



/******************************************************************
**                                                               **
** Function Name:   TPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_2000_Mainline()
{


   while (!BCH_eof(RS.EPBF010))
      {
      TPM_3000_ProcessFileEPBF010();
      }

   TPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);

}



/******************************************************************
**                                                               **
** Function Name:   TPM_3000_ProcessFileEPBF010                  **
**                                                               **
** Description:     Call function to process individual          **
**                  records then read next record from buffer.   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_3000_ProcessFileEPBF010()
{

   TPM_4000_ProcessFileRecords();

 /** read the next record **/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer,sizeof(RS.EPBF010_buffer)); 

   TPM_8000_ProcessLUW();
}



/******************************************************************
**                                                               **
** Function Name:   TPM_4000_ProcessFileRecords                  **
**                                                               **
** Description:     Analyze record, based on first               **
**                  character of record, to determine the type   **
**                  of record (i.e. header or detail)            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_4000_ProcessFileRecords()
{

   char    cRecType;     /* Record Type Identifier   */
   char    sPprLstNm;
   char    sPprFrstNm;
   char    cPprMidNm;

   cNameError = 'N';
   cRecType = ' ';
   cErrorCode = ' ';

   strncpy(sName, "  ",sizeof(sName));
   strncpy(sFrstNmSpace, " ", sizeof(sFrstNmSpace));
   memset(sTempMonth,LOW_VALUES, sizeof(sTempMonth));
   memset(sTempDay,LOW_VALUES, sizeof(sTempDay));
   strncpy(sStrtMo, "  ",sizeof(sStrtMo));
   strncpy(sStrtDy, "  ",sizeof(sStrtDy));
   strncpy(sPcPprNbr, "  ",sizeof(sPcPprNbr));
   strncpy(sPcNrevNbr, "  ",sizeof(sPcNrevNbr));


   cRecType = RS.EPBF010_buffer[0];

   /********************************************************************************/
   /** Move the data from the input record into the detail record structure       **/
   /********************************************************************************/
   TPM_4005_FormatDetailRecord();
     

   /*#######################################################################################*/
   /*#         > > > > > >          VALIDATE INPUT RECORD          < < < < < <             #*/
   /*#                                                                                     #*/
   /*#######################################################################################*/
      /************************************************************/
      /** Validate the NAME on the input record.                 **/
      /** Break out the name into last, first, middle initial.   **/
      /** Write NAME errors to the ERROR REPORT.                 **/
      /************************************************************/

      TPM_7100_ParseOutName();

      if (cNameError == 'Y')
         {  
         cValidateError = 'Y';
         cErrorCode = '1';
            sprintf(sErrorMessage, "ERROR 1:  Incorrect NAME format");
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
            sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, NAME = %s",
                                    DTL_REC.sPprNbr,
                                    DTL_REC.sPsgrNm);
            BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);

            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_4000_ProcessFileRecords");
         }   

      /*****************************************************************************************/
      /** Validate the Birth Date on the input record - if it is zeros or spaces, write it    **/
      /** to the ERROR REPORT.                                                                **/
      /*****************************************************************************************/
      if ((strcmp(DTL_REC.sBirthDt, ZERO_DATE) == 0) || 
          (strcmp(DTL_REC.sBirthDt, "") == 0))
         {
         cValidateError = 'Y';

         cErrorCode = '9';
             sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, BirthDt = %s",
                                     DTL_REC.sPprNbr,
                                     DTL_REC.sPsgrNm,
                                     DTL_REC.sBirthDt);
             BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
             BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_4000_ProcessFileRecords");
         }
 

   TPM_7200_CheckForBudNrev();

   TPM_4510_UpdateBudNrev();

   TPM_7300_Write_BdyNrevPaxDlm();

   TPM_7500_UpdateFltCertft();

}

/******************************************************************
**                                                               **
** Function Name:   TPM_4005_FormatDetailRecord                  **
**                                                               **
** Description:     Move the data from the input buffer to       **
**                  the Detail Record structure.                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_4005_FormatDetailRecord()
{
   char dtldata[127];
   int i;
   int length_of_line ;

 /* Initialize detail record with nulls */
   memset(&DTL_REC, LOW_VALUES, sizeof(DTL_REC));
   memset(&dtldata, LOW_VALUES, sizeof(dtldata));

 /*****************************************************************************/
 /* Before moving data, remove any single quotes in the data and replace with */
 /* a single space.                                                           */
 /*****************************************************************************/
   strncpy(dtldata, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   length_of_line = strlen(dtldata);
   for (i = 0; i < length_of_line ; i++)
      {
      if (dtldata[i] == SLASH)
	 dtldata[i] = ',';
      }

   strncpy(RS.EPBF010_buffer, dtldata, sizeof(dtldata));

 /* Move buffer into detail record fields */
   strncpy(DTL_REC.sPprNbr, (char *)RS.EPBF010_buffer+0,9);
   strncpy(DTL_REC.sPsgrNm, (char *)RS.EPBF010_buffer+9,25);
   strncpy(DTL_REC.sBirthDt, (char *)RS.EPBF010_buffer+38,4);
   strncpy(DTL_REC.sBirthDt+4, (char *)RS.EPBF010_buffer+34,4);
   strncpy(DTL_REC.sAddrLn1, (char *)RS.EPBF010_buffer+42,24);
   strncpy(DTL_REC.sAddrLn2, (char *)RS.EPBF010_buffer+66,13);
   strncpy(DTL_REC.sCity, (char *)RS.EPBF010_buffer+79,37);
   strncpy(DTL_REC.sState, (char *)RS.EPBF010_buffer+116,2);
   strncpy(DTL_REC.sZip, (char *)RS.EPBF010_buffer+118,9);
   strncpy(DTL_REC.sPhone, (char *)RS.EPBF010_buffer+127,10);

   // Remove trailing spaces from string variables
/***
   UTL_StripTrailingSpaces(DTL_REC.sPprNbr);
   UTL_StripTrailingSpaces(DTL_REC.sPsgrNm);
   UTL_StripTrailingSpaces(DTL_REC.sBirthDt);
   UTL_StripTrailingSpaces(DTL_REC.sAddrLn1);
   UTL_StripTrailingSpaces(DTL_REC.sCity);
   UTL_StripTrailingSpaces(DTL_REC.sState);
   UTL_StripTrailingSpaces(DTL_REC.sZip);
***/
}


/******************************************************************
**                                                               **
** Function Name:   TPM_4510_UpdateBudNrev                       **
**                                                               **
** Description:     This function calls the service to update    **
**                  a record on the BDY_NREV_PAX table           **
**                  Service = 4718                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_4510_UpdateBudNrev()
{
   short   nSvcRtnCd;   /* Service return code */

  /*** Initialize Service Request and Answer Blocks **/
  
  /*****/
   memset(&R04718.R04718_appl_area, LOW_VALUES, sizeof(_R04718_APPL_AREA));
  memset(&R04718, LOW_VALUES, sizeof(_R04718));
  memset(&A04718, LOW_VALUES, sizeof(_A04718));
 /*****/

  strcpy(R04718.R04718_appl_area.sPprNbr, DTL_REC.sPprNbr);
  strcpy(R04718.R04718_appl_area.sNrevNbr, A04716.A04716_appl_area.sNrevNbr);
  strcpy(R04718.R04718_appl_area.sCertftIssDt, A04716.A04716_appl_area.sCertftIssDt);
  strncpy(R04718.R04718_appl_area.sNrevNm, DTL_REC.sPsgrNm,25);
  strcpy(R04718.R04718_appl_area.sNrevLstNm, sLstNm); 
  strcpy(R04718.R04718_appl_area.sNrevFrstNm, sFrstNm);
/*strncpy(R04718.R04718_appl_area.sNrevLstNm, DTL_REC.sPsgrNm,4); */
/*strncpy(R04718.R04718_appl_area.sNrevFrstNm, DTL_REC.sPsgrNm+5,3); */
 /* strcpy(R04718.R04718_appl_area.sNrevMidNm, " "); */
  strcpy(R04718.R04718_appl_area.sNrevBdayDt,UTL_ConvertDate(DTL_REC.sBirthDt, CNV_YYYYMMDD_TO_DB));   
  strncpy(R04718.R04718_appl_area.sStr1Txt, DTL_REC.sAddrLn1,24);
  strncpy(R04718.R04718_appl_area.sStr2Txt, DTL_REC.sAddrLn2,13);
  strcpy(R04718.R04718_appl_area.sCtrySdivNmTxt, DTL_REC.sCity);
  strcpy(R04718.R04718_appl_area.sCtrySdivCd, DTL_REC.sState);
  strcpy(R04718.R04718_appl_area.sPstlAreaCd, DTL_REC.sZip);
  strcpy(R04718.R04718_appl_area.sHmPhNb, DTL_REC.sPhone);


   /****************************************************/
   /** Call service to update a row on the Nrev table **/
   /****************************************************/

   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04718,&A04718,SERVICE_ID_04718,1,sizeof(_R04718_APPL_AREA));

   /** Service Return Code Processing **/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;
        
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04718");
/*******************
         sprintf(sErrorMessage, "RecId = %c, Ppr = %s, Nrev = %s, PassGrp = %s, PsgrType = %s, RecType = %s, EffDt = %s",
                                     DTL_REC.sPprNbr,
                                     DTL_REC.sPsgrNm,
*********************/
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4510_UpdateBudNrev");
         break;  

      }

}


/******************************************************************
**                                                               **
** Function Name:   TPM_7100_ParseOutName                        **
**                                                               **
** Description:     Split the name into last, first, middle init **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void     TPM_7100_ParseOutName()
{
   short   nSvcRtnCd;        /* Service return code */
   int     nNmCtr,           /* Counts name components (1 = last, 2 = first, 3 = middle) */
           nPos,             /* Counts position of name components */
           nCommaInd,    /* Indicates first comma encounted in name */
	   nMidInd,          /* Indicates midddle initial
           cMultNmInd,       /* Indicates if last name has more than one word */
           i;                /* Indicates position in full name string */


 /* Break down the passenger name */
   nNmCtr = 1;
   nPos   = 0;
   i      = 0;
   nMidInd       = TRUE;
   nCommaInd = TRUE;
   cMultNmInd    = FALSE;


 /*** clear out intermediate name fields                                         ***/
   strncpy(sLstNm, SPACE_CHAR,sizeof(sLstNm));
   strncpy(sFrstNm, SPACE_CHAR,sizeof(sFrstNm));
   sMidNm = ' ';

   while ((i < 26) && (DTL_REC.sPsgrNm[i] != LOW_VALUES))
      {
      switch (DTL_REC.sPsgrNm[i])
         {
         case ',':
            if (nCommaInd == TRUE)
               {
               nNmCtr = 2;
               nPos = 0;

               i++;
               if (DTL_REC.sPsgrNm[i] ==  ' ')
                  {
                  cNameError = 'Y';
                  }
               else
                  {
                  cNameError = 'N';
                  }
               i = i - 1;
               }
            break;
         case ' ':
            if (nNmCtr == 1)
               {
               cMultNmInd = TRUE;
               if (nPos <= 14)
                  sLstNm[nPos] = DTL_REC.sPsgrNm[i];
               break;
               }
            if (nNmCtr == 2)
               {
               nNmCtr++;
               break;
               }
            if (nNmCtr == 3)
               {
               nNmCtr++;
               break;
               }
            if (nNmCtr > 3)
               nNmCtr++;
            break;
         default:
            if (nNmCtr == 1)
               if (nPos <= 14) 
                  sLstNm[nPos++] = DTL_REC.sPsgrNm[i];
            if (nNmCtr == 2)
               {
               nCommaInd = FALSE;
               if (nPos <= 13) 
                  sFrstNm[nPos++] = DTL_REC.sPsgrNm[i];
               }
             if (nNmCtr ==3 )
	       sMidNm = ' ';
            break;
         }
      i++;
      if (cMultNmInd == TRUE)
         {
         cMultNmInd = FALSE;
         nPos++;
         }
      }
               
   if ((sFrstNm[0] == LOW_VALUES) || (nCommaInd == TRUE))
      {
/*
      strncpy(sFrstNm, sFrstNmSpace, sizeof(sFrstNm));
*/
      cNameError = 'Y';
      }

}

/******************************************************************
**                                                               **
** Function Name:   TPM_7200_CheckForBudNrev                     **
**                                                               **
** Description:     Check to see if the Nrev record is already   **
**                  there.                                       **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_7200_CheckForBudNrev()
{
   short   nSvcRtnCd;   /* Service return code */

 
   /*** Initialize Service Request and Answer Blocks **/
   memset(&R04716, LOW_VALUES, sizeof(_R04716));
   memset(&A04716, LOW_VALUES, sizeof(_A04716));

   strcpy(R04716.R04716_appl_area.sPprNbr, DTL_REC.sPprNbr);

   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04716,&A04716,SERVICE_ID_04716,1,sizeof(_R04716_APPL_AREA));

   /** Service Return Code Processing **/

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         nNrevPresent = TRUE;
         break;

      case ARC_ROW_NOT_FOUND:
         nNrevPresent = FALSE;
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04716");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7200_CheckForBudNrev");
         break;
      }

}

/******************************************************************
**                                                               **
** Function Name:   TPM_7300_Write_BdyNrevPaxDlm                 **
**                                                               **
** Description:     This function writes to the bdy_nrev_pax_dlm **
**                  table when adding buddy records.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_7300_Write_BdyNrevPaxDlm()
{
     short nSvcRtnCd;   /* Service return code */

      /****** Initialize request and answer blocks *****/
      memset(&R04717.R04717_appl_area, LOW_VALUES, sizeof(_R04717_APPL_AREA));
      memset(&A04717.A04717_appl_area, LOW_VALUES, sizeof(_A04717_APPL_AREA));
   
      /**** Format service request copybook ****/
      strcpy(R04717.R04717_appl_area.sPprNbr, R04716.R04716_appl_area.sPprNbr);
      strcpy(R04717.R04717_appl_area.sNrevNbr, A04716.A04716_appl_area.sNrevNbr);
      strcpy(R04717.R04717_appl_area.sCertftIssDt, A04716.A04716_appl_area.sCertftIssDt);
      strcpy(R04717.R04717_appl_area.sPassTypCd, COMB_DOM_TO); 
      R04717.R04717_appl_area.cEmplArRecInd = 'A';

 
 /*************************************************************************/
 /** Execute service to insert record into the Buddy Deltamatic table    **/
 /*************************************************************************/
 nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04717,&A04717,SERVICE_ID_04717,1,sizeof(_R04717_APPL_AREA));


   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;

      case ARC_DUPLICATE_ROW:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04717");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7300_WriteDlmaticRecord");
      }  

}

/******************************************************************
**                                                               **
** Function Name:   TPM_7500_UpdateFltCertft                     **
**                                                               **
** Description:     This function calls the service to update    **
**                  a record on the T_FLT_CERTFT table           **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_7500_UpdateFltCertft()
{
   short   nSvcRtnCd;   /* Service return code */

  /*** Initialize Service Request and Answer Blocks **/
  
 
  memset(&R04721.R04721_appl_area, LOW_VALUES, sizeof(_R04721_APPL_AREA));
  memset(&R04721, LOW_VALUES, sizeof(_R04721));
  memset(&A04721, LOW_VALUES, sizeof(_A04721));

  strcpy(R04721.R04721_appl_area.sPprNbr, DTL_REC.sPprNbr);
  strcpy(R04721.R04721_appl_area.sCertftExtnNbr, A04716.A04716_appl_area.sNrevNbr);
  strcpy(R04721.R04721_appl_area.sCertftIssDt, A04716.A04716_appl_area.sCertftIssDt);
  strcpy(R04721.R04721_appl_area.cFltCrtfSttCd, ATHZ_REC);
/*R04721.R04721_appl_area.cFltCrtfSttCd = 'A'; */

 /*************************************************************************/
 /** Execute service to update  record on the t_flt_certft table         **/
 /*************************************************************************/
 nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04721,&A04721,SERVICE_ID_04721,1,sizeof(_R04721_APPL_AREA));


   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;

      case ARC_DUPLICATE_ROW:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04721");
         BCH_FormatMessage(3,TXT_PPR,DTL_REC.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_7500_UpdateFltCertft");
      }  

}

/******************************************************************
**                                                               **
** Function Name:   TPM_8000_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_8000_ProcessLUW()
{
}



/******************************************************************
**                                                               **
** Function Name:   TPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_9500_ProcessEndOfProgram()
{

 /************************/
 /**    CLOSE FILES     **/
 /************************/
   BCH_Close(RS.EPBF010);

}
