/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Pass 2000                                              **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    <EPB53006.c>                                           **
**                                                                         **
** Shell Used:      <shltmpc.c>                                            **
**                                                                         **
** Program Type:    Transaction Driven Process Module                      **
**                                                                         **
** Author :         L. Scott                                               **
**                                                                         **
** Date Written:    06/01/09                                               **
**                                                                         **
** Description:     This module reads the PARS valuation file and          **
**                  inserts records into the charge table.                 **
**                                                                         **
** Revision Trail:                                                         **
** 11/09/2009      Whitman - Change the check for each occurance of a tax  **
**                 type to check for all 6 domestic taxes                  **
****************************************************************************/

#include "epb53006.h"
#include "stdio.h"


main()
{
   BCH_Init("EPB53006", NUMBER_OF_THREADS);

   TPM_1000_Initialize();

   TPM_2000_Mainline();
}


//GL2140160                  Passenger Transportation Tax Payable                      NW (DOM - US)
//GL2140170                  International Transportation Tax Payable                  NW (ITT-AKHI)
//GL2190500                  Aviation/Transportation Security Fee - Tax Code AY        NW (AY-SEC-FEE)
//GL2140200                  U.S. Domestic Segment Tax Payable                         NW (DOM - ZP)
//GL2140160                  Passenger Transportation Tax Payable                      NW (ANC-US)
//GL2140160                  Passenger Transportation Tax Payable                      NW (HNL-US)

/******************************************************************
**                                                               **
** Function Name:   TPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_1000_Initialize()
{

 
 /**** Initialize counters & accumulators ***/

 /**** Initialize RSAM variables ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sNrevNbr, SPACE_CHAR);
   strcpy(RS.sFltOrigCtyId, SPACE_CHAR);
   strcpy(RS.sFltNbr, SPACE_CHAR);
   strcpy(RS.sFltDestCtyId, SPACE_CHAR);
   strcpy(RS.sTktNum15, SPACE_CHAR);

 /**** Build thread table ***/

 /**** Initialize Message Request and Answer Copybooks ***/
   memset(&R04727, LOW_VALUES, sizeof(_R04727));
   memset(&A04727, LOW_VALUES, sizeof(_A04727));
   memset(&R02526, LOW_VALUES, sizeof(_R02526));
   memset(&A02526, LOW_VALUES, sizeof(_A02526));

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_1000_Initialize");


/**** NOTE: BCH_GetCurrentDate() will give current date and time in many 
             formats.  (including Sort, Display, and Timestamp)  ****/  

   /*********** Open Incoming PARS Interface file            *********/
   RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_READ);
   if (RS.EPBF010 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_1000_Initialize");
   }
    

   /************ Read first interface record            ************/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   if (BCH_eof(RS.EPBF010))
   {
       BCH_FormatMessage(1,TXT_EMPTY_INPUT_FILE);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_1000_Initialize");
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                  The main processing populates the request 	 **
**                  block for the insert into the flt_leg or     **
**                  imput_flt_leg table, Depending on if the     **
**                  passenger is imputed or not.                 **
**                  If the record cannot be added it  will be    **
**                  posted to The Suspense table for the Pass    **
**                  Beaureu to process.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_2000_Mainline()
{
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_2000_Initialize");

    while (!BCH_eof(RS.EPBF010))
    {
        TPM_3000_ProcessFileEPBF010();
	RS.Read++;
    }

    TPM_9500_ProcessEndOfProgram();

    BCH_Terminate();

    exit(0);
}


/******************************************************************
**                                                               **
** Function Name:   TPM_3000_ProcessFileEPBF010                  **
**                                                               **
** Description:     Call function to process individual          **
**                  records then read next record from buffer.   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_3000_ProcessFileEPBF010()
{

  char PprNbr[9+1];
  char NrevNbr[2+1];
  char FltNbr[4+1];
  char FltOrigCtyId[5+1];
  char FltDestCtyId[5+1];
  char DprtDt[27];
  char cProcSw = 'Y';
  char *pTemp;
  int i = 0;
  int nFrstNmPeriod = TRUE;
  int nRecWritten = FALSE;

   servid = '0';
   servid1 = '0';
   servid2 = '0';
   servid3 = '0';
   servid4 = '0';
   //memset(&RS.sDTm, LOW_VALUES, sizeof(RS.sDTm));
   //memset(&RS.sATm, LOW_VALUES, sizeof(RS.sATm));

   strcpy(PprNbr, RS.sPprNbr);
   strcpy(NrevNbr, RS.sNrevNbr);
   strcpy(FltNbr, RS.sFltNbr);
   strcpy(FltOrigCtyId, RS.sTripOrig);
   strcpy(FltDestCtyId, RS.sTripDest);
   strcpy(DprtDt, RS.sDprtDt);


   strncpy(RS.sEmpNum, (char *)RS.EPBF010_buffer+4,6);
   strncpy(RS.sTktNum, (char *)RS.EPBF010_buffer+10,13);
   strncpy(RS.sTripOrig, (char *)RS.EPBF010_buffer+23,4);
   strncpy(RS.sTripDest, (char *)RS.EPBF010_buffer+27,4);
   RS.cBrdPri, (char *)RS.EPBF010_buffer[31];
   RS.cClassSvc, (char *)RS.EPBF010_buffer[32];
   RS.cPsgrCode, (char *)RS.EPBF010_buffer[33];
   strncpy(RS.sFltDt, (char *)RS.EPBF010_buffer+34,8);
   strncpy(RS.sTotalAmt, (char *)RS.EPBF010_buffer+42,7);
   strncpy(RS.sBaseAmt5, (char *)RS.EPBF010_buffer+49,5);
   strncpy(RS.sBaseAmt2, (char *)RS.EPBF010_buffer+54,2);
   strncpy(RS.sTotalTax, (char *)RS.EPBF010_buffer+56,7);
   strncpy(RS.sTaxType1, (char *)RS.EPBF010_buffer+63,10);
   strncpy(RS.sTaxAmt1, (char *)RS.EPBF010_buffer+73,2);
   strncpy(RS.sTaxAmt1a, (char *)RS.EPBF010_buffer+75,5);
   strncpy(RS.sTaxAmt1b, (char *)RS.EPBF010_buffer+80,2);
   strncpy(RS.sTaxPct1, (char *)RS.EPBF010_buffer+82,9);
   strncpy(RS.sTaxType2, (char *)RS.EPBF010_buffer+91,10);
   strncpy(RS.sTaxAmt2, (char *)RS.EPBF010_buffer+101,2);
   strncpy(RS.sTaxAmt2a, (char *)RS.EPBF010_buffer+103,5);
   strncpy(RS.sTaxAmt2b, (char *)RS.EPBF010_buffer+108,2);
   strncpy(RS.sTaxPct2, (char *)RS.EPBF010_buffer+110,9);
   strncpy(RS.sTaxType3, (char *)RS.EPBF010_buffer+119,10);
   strncpy(RS.sTaxAmt3, (char *)RS.EPBF010_buffer+129,2);
   strncpy(RS.sTaxAmt3a, (char *)RS.EPBF010_buffer+131,5);
   strncpy(RS.sTaxAmt3b, (char *)RS.EPBF010_buffer+136,2);
   strncpy(RS.sTaxPct3, (char *)RS.EPBF010_buffer+138,9);
   strncpy(RS.sTaxType4, (char *)RS.EPBF010_buffer+147,10);
   strncpy(RS.sTaxAmt4, (char *)RS.EPBF010_buffer+157,2);
   strncpy(RS.sTaxAmt4a, (char *)RS.EPBF010_buffer+159,5);
   strncpy(RS.sTaxAmt4b, (char *)RS.EPBF010_buffer+164,2);
   strncpy(RS.sTaxPct4, (char *)RS.EPBF010_buffer+166,9);
   strncpy(RS.sTaxType5, (char *)RS.EPBF010_buffer+175,10);
   strncpy(RS.sTaxAmt5, (char *)RS.EPBF010_buffer+185,2);
   strncpy(RS.sTaxAmt5a, (char *)RS.EPBF010_buffer+187,5);
   strncpy(RS.sTaxAmt5b, (char *)RS.EPBF010_buffer+192,2);
   strncpy(RS.sTaxPct5, (char *)RS.EPBF010_buffer+194,9);
   strncpy(RS.sTaxType6, (char *)RS.EPBF010_buffer+203,10);
   strncpy(RS.sTaxAmt6, (char *)RS.EPBF010_buffer+213,2);
   strncpy(RS.sTaxAmt6a, (char *)RS.EPBF010_buffer+215,5);
   strncpy(RS.sTaxAmt6b, (char *)RS.EPBF010_buffer+220,2);
   strncpy(RS.sTaxPct6, (char *)RS.EPBF010_buffer+222,9);
   strncpy(RS.sTaxType7, (char *)RS.EPBF010_buffer+231,10);
   strncpy(RS.sTaxAmt7, (char *)RS.EPBF010_buffer+241,2);
   strncpy(RS.sTaxAmt7a, (char *)RS.EPBF010_buffer+243,5);
   strncpy(RS.sTaxAmt7b, (char *)RS.EPBF010_buffer+248,2);
   strncpy(RS.sTaxPct7, (char *)RS.EPBF010_buffer+250,9);
   strncpy(RS.sTaxType8, (char *)RS.EPBF010_buffer+259,10);
   strncpy(RS.sTaxAmt8, (char *)RS.EPBF010_buffer+269,2);
   strncpy(RS.sTaxAmt8a, (char *)RS.EPBF010_buffer+271,5);
   strncpy(RS.sTaxAmt8b, (char *)RS.EPBF010_buffer+276,2);
   strncpy(RS.sTaxPct8, (char *)RS.EPBF010_buffer+278,9);
   strncpy(RS.sFiller13, (char *)RS.EPBF010_buffer+287,13);

   strcpy(RS.sTktNum15, RS.sTktNum);
   strcpy(RS.sEmpNum10, RS.sEmpNum);
   strcpy(RS.sBaseAmt7, RS.sBaseAmt5);
   strcat(RS.sBaseAmt7,".");
   strcat(RS.sBaseAmt7, RS.sBaseAmt2);

   // Remove trailing spaces from string variables
   UTL_StripTrailingSpaces(RS.sTripOrig);
   UTL_StripTrailingSpaces(RS.sTripDest);
   UTL_StripTrailingSpaces(RS.sEmpNum10);
   UTL_StripTrailingSpaces(RS.sTktNum15);
   UTL_StripTrailingSpaces(RS.sEmpNum);
   UTL_StripTrailingSpaces(RS.sTktNum);
   UTL_StripTrailingSpaces(RS.sTaxType1);
   UTL_StripTrailingSpaces(RS.sTaxType2);
   UTL_StripTrailingSpaces(RS.sTaxType3);
   UTL_StripTrailingSpaces(RS.sTaxType4);
   UTL_StripTrailingSpaces(RS.sTaxType5);
   UTL_StripTrailingSpaces(RS.sTaxType6);
   UTL_StripTrailingSpaces(RS.sTaxType7);
   UTL_StripTrailingSpaces(RS.sTaxType8);

   strcpy(RS.sFltOrigCtyId, RS.sTripOrig);
   strcpy(RS.sFltDestCtyId, RS.sTripDest);

   strcpy(RS.sDprtDt, RS.sFltDt);
   UTL_StripTrailingSpaces(RS.sDprtDt);

   // Now convert the dates to standard formats
      pTemp = UTL_ConvertDate(RS.sDprtDt, CNV_YYYYMMDD_TO_DB);
      strncpy(RS.sDprtDt, pTemp, sizeof(RS.sDprtDt));


  // Get flight leg assosicated with the PARS priced coupons  


    memset(&A04727,LOW_VALUES,sizeof(A04727));
    memset(&R04727,LOW_VALUES,sizeof(R04727));
    strcpy(R04727.R04727_appl_area.sNwEmplNb, RS.sEmpNum10);
    strcpy(R04727.R04727_appl_area.sNwTktDocNb, RS.sTktNum15);
    strcpy(R04727.R04727_appl_area.sFltDprtDt, RS.sDprtDt);
 // strcpy(R04727.R04727_appl_area.sNwEmplNb, RS.sEmpNum);
 // strcpy(R04727.R04727_appl_area.sNwTktDocNb, RS.sTktNum);
    

    nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04727,&A04727,SERVICE_ID_04727,1,sizeof(R04727.R04727_appl_area));
    switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
              servid = '0';
              break;

         case ARC_ROW_NOT_FOUND:
	      strcpy(sErrMsg, "NW Ticket number and/or NW employee nbr not found");
              break;
   
         default:
	    BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	    BCH_FormatMessage(2,TXT_SVC, "FYS04727");
	    sprintf(sErrorMessage, "Tkt = %s, EmpNbr = %s",
			  R04727.R04727_appl_area.sNwTktDocNb,
			  R04727.R04727_appl_area.sNwEmplNb);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	    BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	       
         break;
         }

if (servid == '0')
   {
    memset(&R02526,LOW_VALUES, sizeof(R02526)); 
    memset(&A02526,LOW_VALUES,sizeof(A02526)); 
    strcpy(R02526.R02526_appl_area.sPprNbr, A04727.A04727_appl_area.sPprNbr);
    strcpy(R02526.R02526_appl_area.sNrevNbr, A04727.A04727_appl_area.sNrevNbr);
  //strcpy(R02526.R02526_appl_area.sFltDprtDt, A04727.A04727_appl_area.sFltDprtDt);
    strcpy(R02526.R02526_appl_area.sFltDprtDt, RS.sDprtDt);
    strcpy(R02526.R02526_appl_area.sPassDtTmTs, RS.sDprtDt);
 // strcpy(R02526.R02526_appl_area.sFltOrigCtyId, A04727.A04727_appl_area.sFltOrigCtyId);        
 // strcpy(R02526.R02526_appl_area.sFltDestCtyId, A04727.A04727_appl_area.sFltDestCtyId);
    strcpy(R02526.R02526_appl_area.sFltOrigCtyId, RS.sTripOrig);        
    strcpy(R02526.R02526_appl_area.sFltDestCtyId, RS.sTripDest);
    strcpy(R02526.R02526_appl_area.sFltNbr, A04727.A04727_appl_area.sFltNbr);
    strcpy(R02526.R02526_appl_area.sSvcChrgCd, "BV");
    R02526.R02526_appl_area.dCostChrgAmt = atof(RS.sBaseAmt7);
    strcpy(R02526.R02526_appl_area.sFltClsSvcId, A04727.A04727_appl_area.sFltClsSvcId);
    strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "4803100");
    strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sSvcChrgDs, "Payroll Deduct");
    R02526.R02526_appl_area.lFltChrgRfrnDt = A04727.A04727_appl_area.lFltChrgRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
     {
     case ARC_SUCCESS:
	 servid1 = '0';
         break;
     default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	 BCH_FormatMessage(2,TXT_SVC, "FYS02526");
	 BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
	                                          R02526.R02526_appl_area.sNrevNbr,
						  R02526.R02526_appl_area.sFltDprtDt,
						  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	 break;
     }

 if (servid1 == '0')
   {

   /*********************************************/
   /**   Tax Type1
   /*********************************************/
    if (strcmp(RS.sTaxType1, "DOM-ZP") ==0 || strcmp(RS.sTaxType1, "DOM-US") ==0 ||
        strcmp(RS.sTaxType1, "HNL-US") ==0 || strcmp(RS.sTaxType1, "ANC-US") ==0 ||
	strcmp(RS.sTaxType1, "AY-SEC-FEE") ==0 || strcmp(RS.sTaxType1, "ITT-AKHI") ==0)
    {
    memset(&R02526,LOW_VALUES, sizeof(R02526)); 
    memset(&A02526,LOW_VALUES, sizeof(A02526)); 
    strcpy(RS.sBaseAmt7, SPACE_CHAR);
    strcpy(RS.sBaseAmt7, RS.sTaxAmt1a);
    strcat(RS.sBaseAmt7,".");
    strcat(RS.sBaseAmt7, RS.sTaxAmt1b);

    if (strcmp(RS.sTaxType1, "DOM-ZP") ==0) 
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140200");
       }
    if (strcmp(RS.sTaxType1, "DOM-US") ==0 || strcmp(RS.sTaxType1, "HNL-US") ==0 || strcmp(RS.sTaxType1, "ANC-US") ==0) 
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140160");
       }
    if (strcmp(RS.sTaxType1, "ITT-AKHI") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140170");
       }
     if (strcmp(RS.sTaxType1, "AY-SEC-FEE") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2190500");       
       }
    strcpy(R02526.R02526_appl_area.sPprNbr, A04727.A04727_appl_area.sPprNbr);
    strcpy(R02526.R02526_appl_area.sNrevNbr, A04727.A04727_appl_area.sNrevNbr);
    strcpy(R02526.R02526_appl_area.sFltDprtDt, A04727.A04727_appl_area.sFltDprtDt);
    strcpy(R02526.R02526_appl_area.sPassDtTmTs, RS.sDprtDt);
 // strcpy(R02526.R02526_appl_area.sFltOrigCtyId, A04727.A04727_appl_area.sFltOrigCtyId);        
 // strcpy(R02526.R02526_appl_area.sFltDestCtyId, A04727.A04727_appl_area.sFltDestCtyId);
    strcpy(R02526.R02526_appl_area.sFltOrigCtyId, RS.sTripOrig);        
    strcpy(R02526.R02526_appl_area.sFltDestCtyId, RS.sTripDest);
    strcpy(R02526.R02526_appl_area.sFltNbr, A04727.A04727_appl_area.sFltNbr);
    strcpy(R02526.R02526_appl_area.sSvcChrgCd, "BV");
    R02526.R02526_appl_area.dCostChrgAmt = atof(RS.sBaseAmt7);
    strcpy(R02526.R02526_appl_area.sFltClsSvcId, A04727.A04727_appl_area.sFltClsSvcId);
    strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sSvcChrgDs, "Payroll Deduct");
    R02526.R02526_appl_area.lFltChrgRfrnDt = A04727.A04727_appl_area.lFltChrgRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
     {
     case ARC_SUCCESS:
	 servid2 = '0';
         break;
     default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	 BCH_FormatMessage(2,TXT_SVC, "FYS02526");
	 BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
	                                          R02526.R02526_appl_area.sNrevNbr,
						  R02526.R02526_appl_area.sFltDprtDt,
						  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	 break;
     } /*TaxType1 invoke service */
    } /*strcmp TaxType1*/

   /*********************************************/
   /**   Tax Type2
   /*********************************************/
    if (strcmp(RS.sTaxType2, "DOM-ZP") ==0 || strcmp(RS.sTaxType2, "DOM-US") ==0 ||
	strcmp(RS.sTaxType2, "HNL-US") ==0 || strcmp(RS.sTaxType2, "ANC-US") ==0 ||
	strcmp(RS.sTaxType2, "AY-SEC-FEE") ==0 || strcmp(RS.sTaxType2, "ITT-AKHI") ==0)

    {
    memset(&R02526,LOW_VALUES, sizeof(R02526)); 
    memset(&A02526,LOW_VALUES, sizeof(A02526)); 
    strcpy(RS.sBaseAmt7, SPACE_CHAR);
    
    strcpy(RS.sBaseAmt7, RS.sTaxAmt2a);
    strcat(RS.sBaseAmt7,".");
    strcat(RS.sBaseAmt7, RS.sTaxAmt2b);

    if (strcmp(RS.sTaxType2, "DOM-ZP") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140200");
       }
    if (strcmp(RS.sTaxType2, "DOM-US") ==0 || strcmp(RS.sTaxType2, "HNL-US") ==0 || strcmp(RS.sTaxType2, "ANC-US") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140160");
       }
    if (strcmp(RS.sTaxType2, "ITT-AKHI") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140170");
       }
    if (strcmp(RS.sTaxType2, "AY-SEC-FEE") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2190500");
       }


    strcpy(R02526.R02526_appl_area.sPprNbr, A04727.A04727_appl_area.sPprNbr);
    strcpy(R02526.R02526_appl_area.sNrevNbr, A04727.A04727_appl_area.sNrevNbr);
    strcpy(R02526.R02526_appl_area.sFltDprtDt, A04727.A04727_appl_area.sFltDprtDt);
    strcpy(R02526.R02526_appl_area.sPassDtTmTs, RS.sDprtDt);
 // strcpy(R02526.R02526_appl_area.sFltOrigCtyId, A04727.A04727_appl_area.sFltOrigCtyId);        
 // strcpy(R02526.R02526_appl_area.sFltDestCtyId, A04727.A04727_appl_area.sFltDestCtyId);
    strcpy(R02526.R02526_appl_area.sFltOrigCtyId, RS.sTripOrig);
    strcpy(R02526.R02526_appl_area.sFltDestCtyId, RS.sTripDest);
    strcpy(R02526.R02526_appl_area.sFltNbr, A04727.A04727_appl_area.sFltNbr);
    strcpy(R02526.R02526_appl_area.sSvcChrgCd, "BV");
    R02526.R02526_appl_area.dCostChrgAmt = atof(RS.sBaseAmt7);
    strcpy(R02526.R02526_appl_area.sFltClsSvcId, A04727.A04727_appl_area.sFltClsSvcId);
    strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sSvcChrgDs, "Payroll Deduct");
    R02526.R02526_appl_area.lFltChrgRfrnDt = A04727.A04727_appl_area.lFltChrgRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
     {
     case ARC_SUCCESS:
	 servid3 = '0';
         break;
     default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	 BCH_FormatMessage(2,TXT_SVC, "FYS02526");
	 BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
	                                          R02526.R02526_appl_area.sNrevNbr,
						  R02526.R02526_appl_area.sFltDprtDt,
						  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	 break;
     } /*TaxType2 invoke service */
    } /*strcmp TaxType2*/

   /*********************************************/
   /**   Tax Type3
   /*********************************************/
    if (strcmp(RS.sTaxType3, "DOM-ZP") ==0 || strcmp(RS.sTaxType3, "DOM-US") ==0 ||
	strcmp(RS.sTaxType3, "HNL-US") ==0 || strcmp(RS.sTaxType3, "ANC-US") ==0 ||
        strcmp(RS.sTaxType3, "AY-SEC-FEE") ==0 || strcmp(RS.sTaxType3, "ITT-AKHI") ==0)
    
    {
    memset(&R02526,LOW_VALUES, sizeof(R02526)); 
    memset(&A02526,LOW_VALUES, sizeof(A02526)); 
    strcpy(RS.sBaseAmt7, SPACE_CHAR);

    strcpy(RS.sBaseAmt7, RS.sTaxAmt3a);
    strcat(RS.sBaseAmt7,".");
    strcat(RS.sBaseAmt7, RS.sTaxAmt3b);
    
    if (strcmp(RS.sTaxType3, "DOM-ZP") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140200");
       }
    if (strcmp(RS.sTaxType3, "DOM-US") ==0 || strcmp(RS.sTaxType3, "HNL-US") ==0 || strcmp(RS.sTaxType3, "ANC-US") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140160");
       }
    if (strcmp(RS.sTaxType3, "ITT-AKHI") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140170");
       }
     if (strcmp(RS.sTaxType3, "AY-SEC-FEE") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2190500");
       }
    
    strcpy(R02526.R02526_appl_area.sPprNbr, A04727.A04727_appl_area.sPprNbr);
    strcpy(R02526.R02526_appl_area.sNrevNbr, A04727.A04727_appl_area.sNrevNbr);
    strcpy(R02526.R02526_appl_area.sFltDprtDt, A04727.A04727_appl_area.sFltDprtDt);
    strcpy(R02526.R02526_appl_area.sPassDtTmTs, RS.sDprtDt);
  //strcpy(R02526.R02526_appl_area.sFltOrigCtyId, A04727.A04727_appl_area.sFltOrigCtyId);        
  //strcpy(R02526.R02526_appl_area.sFltDestCtyId, A04727.A04727_appl_area.sFltDestCtyId);
    strcpy(R02526.R02526_appl_area.sFltOrigCtyId, RS.sTripOrig);
    strcpy(R02526.R02526_appl_area.sFltDestCtyId, RS.sTripDest);
    strcpy(R02526.R02526_appl_area.sFltNbr, A04727.A04727_appl_area.sFltNbr);
    strcpy(R02526.R02526_appl_area.sSvcChrgCd, "BV");
    R02526.R02526_appl_area.dCostChrgAmt = atof(RS.sBaseAmt7);
    strcpy(R02526.R02526_appl_area.sFltClsSvcId, A04727.A04727_appl_area.sFltClsSvcId);
    strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sSvcChrgDs, "Payroll Deduct");
    R02526.R02526_appl_area.lFltChrgRfrnDt = A04727.A04727_appl_area.lFltChrgRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
     {
     case ARC_SUCCESS:
	 servid4 = '0';
         break;
     default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	 BCH_FormatMessage(2,TXT_SVC, "FYS02526");
	 BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
	                                          R02526.R02526_appl_area.sNrevNbr,
						  R02526.R02526_appl_area.sFltDprtDt,
						  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	 break;
     } /*TaxType3 invoke service */
    } /*strcmp TaxType3*/

   /*********************************************/
   /**   Tax Type4
   /*********************************************/
    if (strcmp(RS.sTaxType4, "DOM-ZP") ==0 || strcmp(RS.sTaxType4, "DOM-US") ==0 ||
	strcmp(RS.sTaxType4, "HNL-US") ==0 || strcmp(RS.sTaxType4, "ANC-US") ==0 ||
        strcmp(RS.sTaxType4, "AY-SEC-FEE") ==0 || strcmp(RS.sTaxType4, "ITT-AKHI") ==0)
    {
    memset(&R02526,LOW_VALUES, sizeof(R02526)); 
    memset(&A02526,LOW_VALUES, sizeof(A02526)); 
    strcpy(RS.sBaseAmt7, SPACE_CHAR);

    strcpy(RS.sBaseAmt7, RS.sTaxAmt4a);
    strcat(RS.sBaseAmt7,".");
    strcat(RS.sBaseAmt7, RS.sTaxAmt4b);
    
    if (strcmp(RS.sTaxType4, "DOM-ZP") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140200");
       }
    if (strcmp(RS.sTaxType4, "DOM-US") ==0 || strcmp(RS.sTaxType4, "HNL-US") ==0 || strcmp(RS.sTaxType4, "ANC-US") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140160");
       }
    if (strcmp(RS.sTaxType4, "ITT-AKHI") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140170");
       }
     if (strcmp(RS.sTaxType4, "AY-SEC-FEE") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2190500");
       }

    strcpy(R02526.R02526_appl_area.sPprNbr, A04727.A04727_appl_area.sPprNbr);
    strcpy(R02526.R02526_appl_area.sNrevNbr, A04727.A04727_appl_area.sNrevNbr);
    strcpy(R02526.R02526_appl_area.sFltDprtDt, A04727.A04727_appl_area.sFltDprtDt);
    strcpy(R02526.R02526_appl_area.sPassDtTmTs, RS.sDprtDt);
 // strcpy(R02526.R02526_appl_area.sFltOrigCtyId, A04727.A04727_appl_area.sFltOrigCtyId);        
 // strcpy(R02526.R02526_appl_area.sFltDestCtyId, A04727.A04727_appl_area.sFltDestCtyId);
    strcpy(R02526.R02526_appl_area.sFltOrigCtyId, RS.sTripOrig);
    strcpy(R02526.R02526_appl_area.sFltDestCtyId, RS.sTripDest);
    strcpy(R02526.R02526_appl_area.sFltNbr, A04727.A04727_appl_area.sFltNbr);
    strcpy(R02526.R02526_appl_area.sSvcChrgCd, "BV");
    R02526.R02526_appl_area.dCostChrgAmt = atof(RS.sBaseAmt7);
    strcpy(R02526.R02526_appl_area.sFltClsSvcId, A04727.A04727_appl_area.sFltClsSvcId);
    strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sSvcChrgDs, "Payroll Deduct");
    R02526.R02526_appl_area.lFltChrgRfrnDt = A04727.A04727_appl_area.lFltChrgRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
     {
     case ARC_SUCCESS:
	 servid5 = '0';
         break;
     default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	 BCH_FormatMessage(2,TXT_SVC, "FYS02526");
	 BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
	                                          R02526.R02526_appl_area.sNrevNbr,
						  R02526.R02526_appl_area.sFltDprtDt,
						  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	 break;
     } /*TaxType4 invoke service */
    } /*strcmp TaxType4*/

   /*********************************************/
   /**   Tax Type5
   /*********************************************/
    if (strcmp(RS.sTaxType5, "DOM-ZP") ==0 || strcmp(RS.sTaxType5, "DOM-US") ==0 ||
	strcmp(RS.sTaxType5, "HNL-US") ==0 || strcmp(RS.sTaxType5, "ANC-US") ==0 ||
        strcmp(RS.sTaxType5, "AY-SEC-FEE") ==0 || strcmp(RS.sTaxType5, "ITT-AKHI") ==0)
    {
    memset(&R02526,LOW_VALUES, sizeof(R02526)); 
    memset(&A02526,LOW_VALUES, sizeof(A02526)); 
    strcpy(RS.sBaseAmt7, SPACE_CHAR);

       strcpy(RS.sBaseAmt7, RS.sTaxAmt5a);
       strcat(RS.sBaseAmt7,".");
       strcat(RS.sBaseAmt7, RS.sTaxAmt5b);
    if (strcmp(RS.sTaxType5, "DOM-ZP") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140200");
       }
    if (strcmp(RS.sTaxType5, "DOM-US") ==0 || strcmp(RS.sTaxType5, "HNL-US") ==0 || strcmp(RS.sTaxType5, "ANC-US") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140160");
       }
    if (strcmp(RS.sTaxType5, "ITT-AKHI") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140170");
       }
     if (strcmp(RS.sTaxType5, "AY-SEC-FEE") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2190500");
       }

    strcpy(R02526.R02526_appl_area.sPprNbr, A04727.A04727_appl_area.sPprNbr);
    strcpy(R02526.R02526_appl_area.sNrevNbr, A04727.A04727_appl_area.sNrevNbr);
    strcpy(R02526.R02526_appl_area.sFltDprtDt, A04727.A04727_appl_area.sFltDprtDt);
    strcpy(R02526.R02526_appl_area.sPassDtTmTs, RS.sDprtDt);
//  strcpy(R02526.R02526_appl_area.sFltOrigCtyId, A04727.A04727_appl_area.sFltOrigCtyId);        
//  strcpy(R02526.R02526_appl_area.sFltDestCtyId, A04727.A04727_appl_area.sFltDestCtyId);
    strcpy(R02526.R02526_appl_area.sFltOrigCtyId, RS.sTripOrig);
    strcpy(R02526.R02526_appl_area.sFltDestCtyId, RS.sTripDest);
    strcpy(R02526.R02526_appl_area.sFltNbr, A04727.A04727_appl_area.sFltNbr);
    strcpy(R02526.R02526_appl_area.sSvcChrgCd, "BV");
    R02526.R02526_appl_area.dCostChrgAmt = atof(RS.sBaseAmt7);
    strcpy(R02526.R02526_appl_area.sFltClsSvcId, A04727.A04727_appl_area.sFltClsSvcId);
    strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sSvcChrgDs, "Payroll Deduct");
    R02526.R02526_appl_area.lFltChrgRfrnDt = A04727.A04727_appl_area.lFltChrgRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
     {
     case ARC_SUCCESS:
	 servid6 = '0';
         break;
     default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	 BCH_FormatMessage(2,TXT_SVC, "FYS02526");
	 BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
	                                          R02526.R02526_appl_area.sNrevNbr,
						  R02526.R02526_appl_area.sFltDprtDt,
						  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	 break;
     } /*TaxType5 invoke service */
    } /*strcmp TaxType5*/

   /*********************************************/
   /**   Tax Type6
   /*********************************************/
    if (strcmp(RS.sTaxType6, "DOM-ZP") ==0 || strcmp(RS.sTaxType6, "DOM-US") ==0 ||
	strcmp(RS.sTaxType6, "HNL-US") ==0 || strcmp(RS.sTaxType6, "ANC-US") ==0 ||
        strcmp(RS.sTaxType6, "AY-SEC-FEE") ==0 || strcmp(RS.sTaxType6, "ITT-AKHI") ==0)
    {
    memset(&R02526,LOW_VALUES, sizeof(R02526)); 
    memset(&A02526,LOW_VALUES, sizeof(A02526)); 
    strcpy(RS.sBaseAmt7, SPACE_CHAR);

       strcpy(RS.sBaseAmt7, RS.sTaxAmt6a);
       strcat(RS.sBaseAmt7,".");
       strcat(RS.sBaseAmt7, RS.sTaxAmt6b);
    if (strcmp(RS.sTaxType6, "DOM-ZP") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140200");
       }
    if (strcmp(RS.sTaxType6, "DOM-US") ==0 || strcmp(RS.sTaxType6, "HNL-US") ==0 || strcmp(RS.sTaxType6, "ANC-US") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140160");
       }
    if (strcmp(RS.sTaxType6, "ITT-AKHI") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140170");
       }
     if (strcmp(RS.sTaxType6, "AY-SEC-FEE") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2190500");
       }

    strcpy(R02526.R02526_appl_area.sPprNbr, A04727.A04727_appl_area.sPprNbr);
    strcpy(R02526.R02526_appl_area.sNrevNbr, A04727.A04727_appl_area.sNrevNbr);
    strcpy(R02526.R02526_appl_area.sFltDprtDt, A04727.A04727_appl_area.sFltDprtDt);
    strcpy(R02526.R02526_appl_area.sPassDtTmTs, RS.sDprtDt);
 // strcpy(R02526.R02526_appl_area.sFltOrigCtyId, A04727.A04727_appl_area.sFltOrigCtyId);        
 // strcpy(R02526.R02526_appl_area.sFltDestCtyId, A04727.A04727_appl_area.sFltDestCtyId);
    strcpy(R02526.R02526_appl_area.sFltOrigCtyId, RS.sTripOrig);
    strcpy(R02526.R02526_appl_area.sFltDestCtyId, RS.sTripDest);
    strcpy(R02526.R02526_appl_area.sFltNbr, A04727.A04727_appl_area.sFltNbr);
    strcpy(R02526.R02526_appl_area.sSvcChrgCd, "BV");
    R02526.R02526_appl_area.dCostChrgAmt = atof(RS.sBaseAmt7);
    strcpy(R02526.R02526_appl_area.sFltClsSvcId, A04727.A04727_appl_area.sFltClsSvcId);
    strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sSvcChrgDs, "Payroll Deduct");
    R02526.R02526_appl_area.lFltChrgRfrnDt = A04727.A04727_appl_area.lFltChrgRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
     {
     case ARC_SUCCESS:
	 servid7 = '0';
         break;
     default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	 BCH_FormatMessage(2,TXT_SVC, "FYS02526");
	 BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
	                                          R02526.R02526_appl_area.sNrevNbr,
						  R02526.R02526_appl_area.sFltDprtDt,
						  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	 break;
     } /*TaxType6 invoke service */
    } /*strcmp TaxType6*/

   /*********************************************/
   /**   Tax Type7
   /*********************************************/
    if (strcmp(RS.sTaxType7, "DOM-ZP") ==0 || strcmp(RS.sTaxType7, "DOM-US") ==0 ||
        strcmp(RS.sTaxType7, "HNL-US") ==0 || strcmp(RS.sTaxType7, "ANC-US") ==0 ||
        strcmp(RS.sTaxType7, "AY-SEC-FEE") ==0 || strcmp(RS.sTaxType7, "ITT-AKHI") ==0)
    {
    memset(&R02526,LOW_VALUES, sizeof(R02526)); 
    memset(&A02526,LOW_VALUES, sizeof(A02526)); 
    strcpy(RS.sBaseAmt7, SPACE_CHAR);

       strcpy(RS.sBaseAmt7, RS.sTaxAmt7a);
       strcat(RS.sBaseAmt7,".");
       strcat(RS.sBaseAmt7, RS.sTaxAmt7b);
    if (strcmp(RS.sTaxType7, "DOM-ZP") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140200");
       }
    if (strcmp(RS.sTaxType7, "DOM-US") ==0 || strcmp(RS.sTaxType7, "HNL-US") ==0 || strcmp(RS.sTaxType7, "ANC-US") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140160");
       }
    if (strcmp(RS.sTaxType7, "ITT-AKHI") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140170");
       }
     if (strcmp(RS.sTaxType7, "AY-SEC-FEE") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2190500");
       }
       

    strcpy(R02526.R02526_appl_area.sPprNbr, A04727.A04727_appl_area.sPprNbr);
    strcpy(R02526.R02526_appl_area.sNrevNbr, A04727.A04727_appl_area.sNrevNbr);
    strcpy(R02526.R02526_appl_area.sFltDprtDt, A04727.A04727_appl_area.sFltDprtDt);
    strcpy(R02526.R02526_appl_area.sPassDtTmTs, RS.sDprtDt);
 // strcpy(R02526.R02526_appl_area.sFltOrigCtyId, A04727.A04727_appl_area.sFltOrigCtyId);        
 // strcpy(R02526.R02526_appl_area.sFltDestCtyId, A04727.A04727_appl_area.sFltDestCtyId);
    strcpy(R02526.R02526_appl_area.sFltOrigCtyId, RS.sTripOrig);
    strcpy(R02526.R02526_appl_area.sFltDestCtyId, RS.sTripDest);
    strcpy(R02526.R02526_appl_area.sFltNbr, A04727.A04727_appl_area.sFltNbr);
    strcpy(R02526.R02526_appl_area.sSvcChrgCd, "BV");
    R02526.R02526_appl_area.dCostChrgAmt = atof(RS.sBaseAmt7);
    strcpy(R02526.R02526_appl_area.sFltClsSvcId, A04727.A04727_appl_area.sFltClsSvcId);
    strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sSvcChrgDs, "Payroll Deduct");
    R02526.R02526_appl_area.lFltChrgRfrnDt = A04727.A04727_appl_area.lFltChrgRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
     {
     case ARC_SUCCESS:
	 servid8 = '0';
         break;
     default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	 BCH_FormatMessage(2,TXT_SVC, "FYS02526");
	 BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
	                                          R02526.R02526_appl_area.sNrevNbr,
						  R02526.R02526_appl_area.sFltDprtDt,
						  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	 break;
     } /*TaxType7 invoke service */
    } /*strcmp TaxType7*/

   /*********************************************/
   /**   Tax Type8
   /*********************************************/
    if (strcmp(RS.sTaxType8, "DOM-ZP") ==0 || strcmp(RS.sTaxType8, "DOM-US") ==0 ||
        strcmp(RS.sTaxType8, "HNL-US") ==0 || strcmp(RS.sTaxType8, "ANC-US") ==0 ||
        strcmp(RS.sTaxType8, "AY-SEC-FEE") ==0 || strcmp(RS.sTaxType8, "ITT-AKHI") ==0)
    {
    memset(&R02526,LOW_VALUES, sizeof(R02526)); 
    memset(&A02526,LOW_VALUES, sizeof(A02526)); 
    strcpy(RS.sBaseAmt7, SPACE_CHAR);

       strcpy(RS.sBaseAmt7, RS.sTaxAmt8a);
       strcat(RS.sBaseAmt7,".");
       strcat(RS.sBaseAmt7, RS.sTaxAmt8b);
    if (strcmp(RS.sTaxType8, "DOM-ZP") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140200");
       }
    if (strcmp(RS.sTaxType8, "DOM-US") ==0 || strcmp(RS.sTaxType8, "HNL-US") ==0 || strcmp(RS.sTaxType8, "ANC-US") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140160");
       }
    if (strcmp(RS.sTaxType8, "ITT-AKHI") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2140170");
       }
     if (strcmp(RS.sTaxType8, "AY-SEC-FEE") ==0)
       {
       strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, "2190500");
       }
    
    strcpy(R02526.R02526_appl_area.sPprNbr, A04727.A04727_appl_area.sPprNbr);
    strcpy(R02526.R02526_appl_area.sNrevNbr, A04727.A04727_appl_area.sNrevNbr);
    strcpy(R02526.R02526_appl_area.sFltDprtDt, A04727.A04727_appl_area.sFltDprtDt);
    strcpy(R02526.R02526_appl_area.sPassDtTmTs, RS.sDprtDt);
 // strcpy(R02526.R02526_appl_area.sFltOrigCtyId, A04727.A04727_appl_area.sFltOrigCtyId);        
 // strcpy(R02526.R02526_appl_area.sFltDestCtyId, A04727.A04727_appl_area.sFltDestCtyId);
    strcpy(R02526.R02526_appl_area.sFltOrigCtyId, RS.sTripOrig);
    strcpy(R02526.R02526_appl_area.sFltDestCtyId, RS.sTripDest);
    strcpy(R02526.R02526_appl_area.sFltNbr, A04727.A04727_appl_area.sFltNbr);
    strcpy(R02526.R02526_appl_area.sSvcChrgCd, "BV");
    R02526.R02526_appl_area.dCostChrgAmt = atof(RS.sBaseAmt7);
    strcpy(R02526.R02526_appl_area.sFltClsSvcId, A04727.A04727_appl_area.sFltClsSvcId);
    strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
    strcpy(R02526.R02526_appl_area.sSvcChrgDs, "Payroll Deduct");
    R02526.R02526_appl_area.lFltChrgRfrnDt = A04727.A04727_appl_area.lFltChrgRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
     {
     case ARC_SUCCESS:
	 servid9 = '0';
         break;
     default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	 BCH_FormatMessage(2,TXT_SVC, "FYS02526");
	 BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
	                                          R02526.R02526_appl_area.sNrevNbr,
						  R02526.R02526_appl_area.sFltDprtDt,
						  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
	 break;
     } /*TaxType8 invoke service */
    } /*strcmp TaxType8*/
  /***************************************************
   } /*servid1 */
  } /*servid  */
}
  /*** Read next interface record ***/
     BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer,sizeof(RS.EPBF010_buffer));
	TPM_8000_ProcessLUW();
}

/******************************************************************
**                                                               **
** Function Name:   TPM_8000_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int  TPM_8000_ProcessLUW()
{
}


/******************************************************************
**                                                               **
** Function Name:   TPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_9500_ProcessEndOfProgram()
{ 

   BCH_Close(RS.EPBF010);

}
