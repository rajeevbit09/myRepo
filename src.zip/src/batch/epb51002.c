/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB51002.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Written:    September 19, 1995                                     **
**                                                                         **
** Description:     This module resets the pass status to active for       **
**                  all pass privilege suspensions that have expired.      **
**                  It also sets the pass status to revoked for all        **
**                  non-revenue passengers whose pass privileges should    **
**                  be revoked.                                            **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 3/96       G. Melton                   Added logic to deactivate pass   **
**                                        cards when revoking; and added   **
**                                        logic to deactivate and then     **
**                                        write out new pass card records  **
**                                        when changing back to active.    **
**                                                                         **
** 03/25/96   J. Bowser                   Added logic to check pass group/ **
**                                        passenger type if pass status    **
**                                        is Suspended:  if combination    **
**                                        is invalid, perform revoke       **
**                                        processing.                      **
**                                                                         **
** 04/02/96   J.Bowser                    Revised code to populate linked  **
**                                        list from driving cursor and     **
**                                        process on the linked list.      **
**                                                                         **
** 07/26/96   FFA                         Added counts of items processed  **
**                                                                         **
** 07/29/96   FFA                         Write to Audit Trail table when  **
**                                        revoking.                        **
**                                                                         **
** 08/05/96   FFA                         Set nrev_pass_chg_ind when rvkng **
** 11/22/96   FFA                         Always set nrev_pass_chg_ind to  **
**                                        'Y' when revoking.               **
**                                                                         **
** 04/22/98   S. Makim                    When you order new pass card,    **
**                                        only for Worldspan employees     **
**                                        mark their records as processed. **
**                                                                         **
** 03/01/01   L. Scott                    When writing out records to the  **
**                                        t_deltamatic table check to see  **
**                                        if pass type 15 and 30 exist for **
**                                        the same nonrev if so don't write**
**                                        out the 30.                      **
**                                                                         **
****************************************************************************/


#include "epb51002.h"


main()
{
   BCH_Init("EPB51002", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{
   char   *pEffDt;                /* Pointer to effective date */


   /**** Assign effective date to variable ****/
   pEffDt = (char *) getenv("DATE1");
   strcpy(RS.sEffDt, pEffDt);

   /**** Convert effective date to Julian ****/
   lJulEffDt = UTL_GetJulianFromDate(RS.sEffDt);

   /**** Initialize flags ****/
   nActive       = FALSE;               /** Active pass status flag **/
   nRevoked      = FALSE;               /** Revoked pass status flag (for invalid pass grp/psgr type) **/
   nOldAllotInd  = FALSE;               /** Flag for existence of remaining allotment **/
   nReward15     = FALSE;               /** Flag for existence of pass type 15 allotments **/

   /**** Initialize head pointer to linked list ****/
   pHead = LOW_VALUES;

   /**** Initialize counters ****/
   nPassTypCtr = 0;
   RS.nTotalCnt = 0;
   RS.nActiveCnt = 0;
   RS.nRvkCnt = 0;

   /**** Initialize architecture area of service answer and request blocks ****/    
   memset(&A02388, LOW_VALUES, sizeof(_A02388)); 
   memset(&R02388, LOW_VALUES, sizeof(_R02388)); 
   memset(&A02441, LOW_VALUES, sizeof(_A02441)); 
   memset(&R02441, LOW_VALUES, sizeof(_R02441)); 
   memset(&A02483, LOW_VALUES, sizeof(_A02483)); 
   memset(&R02483, LOW_VALUES, sizeof(_R02483)); 
   memset(&A02567, LOW_VALUES, sizeof(_A02567)); 
   memset(&R02567, LOW_VALUES, sizeof(_R02567)); 
   memset(&A02596, LOW_VALUES, sizeof(_A02596)); 
   memset(&R02596, LOW_VALUES, sizeof(_R02596)); 
   memset(&A02748, LOW_VALUES, sizeof(_A02748)); 
   memset(&R02748, LOW_VALUES, sizeof(_R02748)); 
   memset(&A03270, LOW_VALUES, sizeof(_A03270)); 
   memset(&R03270, LOW_VALUES, sizeof(_R03270)); 
   memset(&A03716, LOW_VALUES, sizeof(_A03716)); 
   memset(&R03716, LOW_VALUES, sizeof(_R03716)); 
   memset(&A04003, LOW_VALUES, sizeof(_A04003)); 
   memset(&R04003, LOW_VALUES, sizeof(_R04003)); 
   memset(&A04323, LOW_VALUES, sizeof(_A04323)); 
   memset(&R04323, LOW_VALUES, sizeof(_R04323)); 
   memset(&A04325, LOW_VALUES, sizeof(_A04325)); 
   memset(&R04325, LOW_VALUES, sizeof(_R04325)); 
   memset(&A04326, LOW_VALUES, sizeof(_A04326)); 
   memset(&R04326, LOW_VALUES, sizeof(_R04326)); 
 
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{

   /****** Initialize request and answer blocks *****/
   memset(&R03716.R03716_appl_area, LOW_VALUES, sizeof(_R03716_APPL_AREA));
   memset(&A03716.A03716_appl_area, LOW_VALUES, sizeof(_A03716_APPL_AREA));

   /**** Format service request copybook ****/
   strcpy(R03716.R03716_appl_area.sFltFeeBegDt, RS.sEffDt);     /** sFltFeeBegDt holds the effective processing date **/

   R03716.R03716_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to select from the Non-revenue Passenger table for non-revenue passengers 
           to be unsuspended and revoked ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03716,&A03716,SERVICE_ID_03716,1,sizeof(_R03716_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
          break;

      case ARC_ROW_NOT_FOUND:
          BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
          break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS03716");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {
      /**** Convert PPR revoke date to Julian ****/
      if (!strcmp(A03716.A03716_appl_area.sPprRvkDt, LOW_DATE))
         lJulRvkDt = 1899365;
      else
         lJulRvkDt = UTL_GetJulianFromDate(A03716.A03716_appl_area.sPprRvkDt);

      /**** Populate linked list ****/
      DPM_2100_PopulateLinkedList();
      RS.nTotalCnt++;

      R03716.R03716_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A03716, LOW_VALUES, sizeof(_A03716));
 
      /**** Execute service to obtain next DB row ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03716,&A03716,SERVICE_ID_03716,1,sizeof(_R03716_APPL_AREA));
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;
 
         case ARC_ROW_NOT_FOUND:
            break;
 
         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03716");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
         }
      }

   /**** Populate pass type array ****/
   DPM_2200_ProcessPassTypes();

   DPM_2500_ProcessRows();

   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2100_PopulateLinkedList                  **
**                                                               **
** Description:     Populates linked list for non-revenue        **
**                  passengers who will be unsuspended and       **
**                  revoked                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/
 
void DPM_2100_PopulateLinkedList()
{

   /**** Allocate space for structure and assign it to the current pointer ****/
   pCurr = (struct nonrev_psgr *) malloc(sizeof(struct nonrev_psgr));

   /**** Assign the linked list current pointer to the head pointer if the head pointer is NULL ****/
   if (pHead == LOW_VALUES)
      pHead = pCurr;

   /**** Otherwise, assign the linked list current pointer to the previous structure's 'next' pointer ****/
   else
      pPrev->pNext = pCurr;

   /**** Assign NULL to the current 'next' pointer, assign the PPR and non-rev numbers,
         and assign the current structure pointer to the previous pointer structure ****/  
   pCurr->pNext = LOW_VALUES;
   strcpy(pCurr->sPprNbr, A03716.A03716_appl_area.sPprNbr);
   strcpy(pCurr->sNrevNbr, A03716.A03716_appl_area.sNrevNbr);
   strcpy(pCurr->sNrevNm, A03716.A03716_appl_area.sNrevNm);
   strcpy(pCurr->sPassGrpCd, A03716.A03716_appl_area.sPassGrpCd);
   strcpy(pCurr->sPassStsCd, A03716.A03716_appl_area.sPassStsCd);
   strcpy(pCurr->sNrevTypCd, A03716.A03716_appl_area.sNrevTypCd);
   if (!strcmp(A03716.A03716_appl_area.sPprRvkDt, LOW_DATE) || (lJulRvkDt > lJulEffDt))
      pCurr->cStatInd = UNSUSPENDED_STAT;
   else
      pCurr->cStatInd = REVOKED_STAT;

   /**** Assign current pointer to previous pointer ****/
   pPrev = pCurr;
}

 
/******************************************************************
**                                                               **
** Function Name:   DPM_2200_ProcessPassTypes                    **
**                                                               **
** Description:     Store DISTINCT Pass Type Codes from Pass     **
**                  Allotment table in an array and read pass    **
**                  type codes from array to drive the resetting **
**                  of allotments.                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void    DPM_2200_ProcessPassTypes()
{
 
   /**** Initialize service request and answer blocks ****/
   memset(&R04003.R04003_appl_area, LOW_VALUES, sizeof(_R04003_APPL_AREA));
   memset(&A04003.A04003_appl_area, LOW_VALUES, sizeof(_A04003_APPL_AREA));
 
   /**** Open the DB cursor ****/
   R04003.R04003_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /**** Execute DISTINCT cursor service to get the pass type codes from the Pass Allotment table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04003,&A04003,SERVICE_ID_04003,1,sizeof(_R04003_APPL_AREA));
                         
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:  
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04003");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessPassTypes");
         break;
      }

   /**** Save each pass type code in an array ****/
   for (nPassTypCtr = 0; nSvcRtnCd != ARC_ROW_NOT_FOUND; nPassTypCtr++)
      {
      /**** Store pass type code in array ****/
      strcpy(pass_type[nPassTypCtr].sPassTypCd, A04003.A04003_appl_area.sPassTypCd);

      R04003.R04003_appl_area.cArchCursorOpTxt = FETCH_ROW;                          

      /**** Get the next DB row ****/                       
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04003,&A04003,SERVICE_ID_04003,1,sizeof(_R04003_APPL_AREA));

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;
 
         case ARC_ROW_NOT_FOUND:
            break;

         default:  
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS04003");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessPassTypes");
         }
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process driving DB rows                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessRows()
{

   /**** Assign the head pointer for the linked list to the current pointer ****/
   pCurr = pHead;


   /**** Process until the current pointer is NULL ****/
   while (pCurr != LOW_VALUES)
      {
      /**** Initialize flags ****/
      nActive  = FALSE;
      nRevoked = FALSE;

      /******************************************************************************/
      /*******************       Perform ACTIVE PROCESSING        *******************/
      /******************************************************************************/
      if (pCurr->cStatInd == UNSUSPENDED_STAT)
         {
         DPM_2550_EvaluateGroupType();

         /**** If valid Pass Group/Passenger Type continue active processing ****/
         if (nRevoked == FALSE)
            {
            DPM_2600_UpdateToActive();
            DPM_2750_DeactivatePassCards();
            DPM_2650_WriteNewPassCardRec();
            }

         /**** Read allotment for pass type and write change Deltamatic record ****/
         for (z = 0; z < nPassTypCtr; z++)
            {
            DPM_2950_ReadRemnAllot();
            if (nOldAllotInd == TRUE)
	       {
	       if ((strcmp(R02441.R02441_appl_area.sPassTypCd, "30") != 0) ||
		  ((strcmp(R02441.R02441_appl_area.sPassTypCd, "30") == 0) &&
		  (nReward15 == FALSE)))    
		  {
                  DPM_3000_WriteDlmaticRecord(CHANGE_REC);
		  }
               }
            }
         }

      /******************************************************************************/
      /******************  Otherwise, perform REVOKED PROCESSING  *******************/
      /******************************************************************************/
      else
         {
         DPM_2700_UpdateToRevoked();
         DPM_2750_DeactivatePassCards();

         /**** Read allotment for pass type and write delete Deltamatic record ****/
         for (z = 0; z < nPassTypCtr; z++)
            {
            DPM_2950_ReadRemnAllot();
            if (nOldAllotInd == TRUE)
               DPM_3000_WriteDlmaticRecord(DELETE_REC);
            }

         }
      /**** Write comment / Audit Trail for pass status change ****/
      DPM_2800_WriteComment();

      /**** Assign current 'next' pointer to structure to current pointer ****/
      pCurr = pCurr->pNext;

      DPM_4920_ProcessLUW();
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2550_EvaluateGroupType                   **
**                                                               **
** Description:     Calls service to select from the Pass Group  **
**                  Passenger Type table to determine if the     **
**                  combination is valid.                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/
 
void DPM_2550_EvaluateGroupType()
{
 
   /**** Initialize request and answer blocks ****/
   memset(&R03270.R03270_appl_area, LOW_VALUES, sizeof(_R03270_APPL_AREA));
   memset(&A03270.A03270_appl_area, LOW_VALUES, sizeof(_A03270_APPL_AREA));

   /**** Format service request block ****/
   strcpy(R03270.R03270_appl_area.sPassGrpCd, pCurr->sPassGrpCd);
   strcpy(R03270.R03270_appl_area.sNrevTypCd, pCurr->sNrevTypCd);

   /****** Execute service to select from the Pass Group Passenger Type table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03270,&A03270,SERVICE_ID_03270,1,sizeof(_R03270_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         /** Set revoked indicator to true and revoke non-revenue passenger **/
         nRevoked = TRUE;
         DPM_2700_UpdateToRevoked();
         DPM_2750_DeactivatePassCards();
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS03270");
         BCH_FormatMessage(3,TXT_PPR,pCurr->sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2550_EvaluateGroupType");
      }  
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2600_UpdateToActive                      **
**                                                               **
** Description:     Update pass status to active                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2600_UpdateToActive()
{

   /**** Set active pass status flag to true ****/
   nActive = TRUE;

   /****** Initialize request and answer blocks *****/
   memset(&R02596.R02596_appl_area, LOW_VALUES, sizeof(_R02596_APPL_AREA));

   /**** Format service request copybook ****/
   strcpy(R02596.R02596_appl_area.sPprNbr, pCurr->sPprNbr);
   strcpy(R02596.R02596_appl_area.sNrevNbr, pCurr->sNrevNbr);
 
   /****** Execute service to update the Non-revenue Passenger table with active pass status and
           suspension expiration date of the defaulted low date ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02596,&A02596,SERVICE_ID_02596,1,sizeof(_R02596_APPL_AREA));
 
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         RS.nActiveCnt++;
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02596");
         BCH_FormatMessage(3,TXT_PPR,pCurr->sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_UpdateToActive");
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2650_WriteNewPassCardRec                 **
**                                                               **
** Description:     Write new record to Pass Card Table.         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2650_WriteNewPassCardRec()
{

   /****** Initialize request and answer blocks *****/
   memset(&R02388.R02388_appl_area, LOW_VALUES, sizeof(_R02388_APPL_AREA));
 
   /**** Format service request copybook ****/
   strcpy(R02388.R02388_appl_area.sPprNbr, pCurr->sPprNbr);
   strcpy(R02388.R02388_appl_area.sNrevNbr, pCurr->sNrevNbr);
   strcpy(R02388.R02388_appl_area.sCardIssDt, sCurrentTsDt);
   R02388.R02388_appl_area.cCardStsInd = ACTIVATED;
   if (!strcmp(A03716.A03716_appl_area.sNrevSrcCd, WORLDSPAN))
      R02388.R02388_appl_area.cCardProcInd = PROCESSED;
   else
      R02388.R02388_appl_area.cCardProcInd = NOT_PROCESSED;
   strcpy(R02388.R02388_appl_area.sSvcChrgCd, NA_CHARGE);

 
   /****** Execute service to insert new record into Pass Card Table ******/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02388,&A02388,SERVICE_ID_02388,1,sizeof(_R02388_APPL_AREA));
 
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02388");
         BCH_FormatMessage(3,TXT_PPR,pCurr->sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2650_WriteNewPassCardRec");
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2700_UpdateToRevoked                     **
**                                                               **
** Description:     Update pass status to revoked and write to   **
**                  Audit Trail Table.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2700_UpdateToRevoked()
{

   /****** Initialize request and answer blocks *****/
   memset(&R02748.R02748_appl_area, LOW_VALUES, sizeof(_R02748_APPL_AREA));

   /**** Format service request copybook ****/
   strcpy(R02748.R02748_appl_area.sPprNbr, pCurr->sPprNbr);
   strcpy(R02748.R02748_appl_area.sNrevNbr, pCurr->sNrevNbr);
   R02748.R02748_appl_area.cNrevPassChgInd = 'Y';
 
   /****** Execute service to update the Non-revenue Passenger table with revoked pass status ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02748,&A02748,SERVICE_ID_02748,1,sizeof(_R02748_APPL_AREA));
 
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         RS.nRvkCnt++;
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02748");
         BCH_FormatMessage(3,TXT_PPR,pCurr->sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2700_UpdateToRevoked");
      }

   /****** insert row in Audit Trail Table  *****/
   memset(&R02561.R02561_appl_area, LOW_VALUES, sizeof(_R02561_APPL_AREA));
   memset(&A02561.A02561_appl_area, LOW_VALUES, sizeof(_A02561_APPL_AREA));
   strcpy(R02561.R02561_appl_area.sPprNbr, pCurr->sPprNbr);
   strcpy(R02561.R02561_appl_area.sNrevNbr, pCurr->sNrevNbr);
   strcpy(R02561.R02561_appl_area.sAudtUserId, "RSALLT");
   strcpy(R02561.R02561_appl_area.sPassGrpCd, pCurr->sPassGrpCd);

   /*** Use appropriate error msg to indicate revoking an un-suspended psgr because of invalid ***/
   /*** pass grp/nrev typ,  or because of expired pass priviliges                              ***/
   if (pCurr -> cStatInd == UNSUSPENDED_STAT)
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Invalid Grp/Typ");
   else
      strcpy(R02561.R02561_appl_area.sAudtChgTypNm, "Revoked - Exprd Benefits");

   strcpy(R02561.R02561_appl_area.sAudtChgFrNm, pCurr->sPassStsCd);
   strcpy(R02561.R02561_appl_area.sAudtChgToNm, REVOKED);               
   strcpy(R02561.R02561_appl_area.sPassTypCd, "  ");         
 
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02561,&A02561,SERVICE_ID_02561,1,sizeof(_R02561_APPL_AREA));
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02561");
         BCH_FormatMessage(3,TXT_PPR,pCurr->sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2700_UpdateToRevoked");
      }
}
 

/******************************************************************
**                                                               **
** Function Name:   DPM_2750_DeactivatePassCards                 **
**                                                               **
** Description:     Deactivate all records on Pass Card Table    **
**                  for this ppr/nrev.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2750_DeactivatePassCards()
{
 
   /****** Initialize request and answer blocks *****/
   memset(&R02567.R02567_appl_area, LOW_VALUES, sizeof(_R02567_APPL_AREA));
 
   /**** Format service request copybook ****/
   strcpy(R02567.R02567_appl_area.sPprNbr, pCurr->sPprNbr);
   strcpy(R02567.R02567_appl_area.sNrevNbr, pCurr->sNrevNbr);
   R02567.R02567_appl_area.cCardStsInd = DEACTIVATED;
   R02567.R02567_appl_area.cCardProcInd = PROCESSED;
 
   /****** Execute service to update all Pass Cards for non-rev psgr to Deactivated/Processed ******/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02567,&A02567,SERVICE_ID_02567,1,sizeof(_R02567_APPL_AREA));
 
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02567");
         BCH_FormatMessage(3,TXT_PPR,pCurr->sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2750_DeactivatePassCards");
      }  

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2800_WriteComment                        **
**                                                               **
** Description:     Insert record into the Comments table.       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_2800_WriteComment()
{

   /****** Initialize request and answer blocks *****/
   memset(&R02483.R02483_appl_area, LOW_VALUES, sizeof(_R02483_APPL_AREA));

   /**** Format service request copybook ****/
   strcpy(R02483.R02483_appl_area.sPprNbr, pCurr->sPprNbr);
   strcpy(R02483.R02483_appl_area.sNrevNbr, pCurr->sNrevNbr);
   strcpy(R02483.R02483_appl_area.sNrevNm, pCurr->sNrevNm);
   strcpy(R02483.R02483_appl_area.sPassStsChgDt, sCurrentTsDt);
   strcpy(R02483.R02483_appl_area.sPassSusExpDt, LOW_DATE);
   strcpy(R02483.R02483_appl_area.sPassDtTmTs, sCurrentTsDt);
 
   if (nActive == TRUE && nRevoked == FALSE)
      {
      /**** Format comment and status code fields for active status ****/
      strcpy(R02483.R02483_appl_area.sNrevCmntTxt, ACTIVE_COMMENT);
      strcpy(R02483.R02483_appl_area.sPassStsCd, ACTIVE);
      }

   else 
      {
      /**** Format invalid Pass Group/Passenger Type comment ****/
      if (nRevoked == TRUE)
         strcpy(R02483.R02483_appl_area.sNrevCmntTxt, INELIGIBLE_COMMENT);

      /**** Format pass benefits expired comment ****/
      else
         strcpy(R02483.R02483_appl_area.sNrevCmntTxt, EXPIRED_COMMENT);

      /**** Format revoked status code ****/
      strcpy(R02483.R02483_appl_area.sPassStsCd, REVOKED);
      }

   /****** Execute service to insert record in the Comments table to log changed pass status ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02483,&A02483,SERVICE_ID_02483,1,sizeof(_R02483_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02483");
         BCH_FormatMessage(3,TXT_PPR,pCurr->sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2800_WriteComment");
      }

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2950_ReadRemnAllot                       **
**                                                               **
** Description:     For an individual pass rider, reads the      **
**                  Remaining Allotment table for a specific     **
**                  pass type.                                   **
**                  Executes service 02441.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/
 
void    DPM_2950_ReadRemnAllot()
{
 
   nOldAllotInd = FALSE;
 
   /**** Initialize request and answer blocks ****/
   memset(&R02441.R02441_appl_area, LOW_VALUES, sizeof(_R02441_APPL_AREA));
   memset(&A02441.A02441_appl_area, LOW_VALUES, sizeof(_A02441_APPL_AREA));
 
   /**** Format service request block ****/
   strcpy(R02441.R02441_appl_area.sPprNbr, pCurr->sPprNbr);
   strcpy(R02441.R02441_appl_area.sNrevNbr, pCurr->sNrevNbr);
   strcpy(R02441.R02441_appl_area.sPassTypCd, pass_type[z].sPassTypCd);

   /**** Execute service to select the row for the pass type in the Remaining Allotment table for the non-rev psgr ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02441,&A02441,SERVICE_ID_02441,1,sizeof(_R02441_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         nOldAllotInd = TRUE;
         break;

      case ARC_ROW_NOT_FOUND:
         nOldAllotInd = FALSE;
         break;

      default:  
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS02441");
         BCH_FormatMessage(3,TXT_PPR,pCurr->sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2950_ReadRemnAllot");
         break;
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_3000_WriteDlmaticRecord                  **
**                                                               **
** Description:     Write a record to the Deltamatic table.      **
**                                                               **
** Arguments:       Record type                                  **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/
 
void    DPM_3000_WriteDlmaticRecord(char cRecTyp)
{
   short   nSvcRtnCd1;        /** Service return code **/
 
 
   /**** Initialize request block ****/
   memset(&R04325.R04325_appl_area, LOW_VALUES, sizeof(_R04325_APPL_AREA));
 
   /**** Format request block ****/
   strcpy(R04325.R04325_appl_area.sPprNbr, pCurr->sPprNbr);
   strcpy(R04325.R04325_appl_area.sNrevNbr, pCurr->sNrevNbr);
   strcpy(R04325.R04325_appl_area.sPassTypCd,  pass_type[z].sPassTypCd);
   if ((strcmp(sSavePprNbr, R04325.R04325_appl_area.sPprNbr) != 0) ||
      (strcmp(sSaveNrevNbr, R04325.R04325_appl_area.sNrevNbr) != 0))
      nReward15 = FALSE;
   strcpy(sSavePprNbr, R04325.R04325_appl_area.sPprNbr);
   strcpy(sSaveNrevNbr, R04325.R04325_appl_area.sNrevNbr);
   if (strcmp(R04325.R04325_appl_area.sPassTypCd, "15") == 0)
      nReward15 = TRUE;
   if (cRecTyp == CHANGE_REC)  
      R04325.R04325_appl_area.cEmplArRecInd = CHANGE_REC;
   else 
      R04325.R04325_appl_area.cEmplArRecInd = DELETE_REC;
 
   /**** Execute service to insert record into the Deltamatic table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04325,&A04325,SERVICE_ID_04325,1,sizeof(_R04325_APPL_AREA));
 
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {  
      case ARC_SUCCESS:  
         break;
 
      case ARC_DUPLICATE_ROW:
         DPM_3100_ReadDlmaticRecord();
 
         strcpy(R04326.R04326_appl_area.sPprNbr, R04325.R04325_appl_area.sPprNbr);
         strcpy(R04326.R04326_appl_area.sNrevNbr, R04325.R04325_appl_area.sNrevNbr);
         strcpy(R04326.R04326_appl_area.sPassTypCd, R04325.R04325_appl_area.sPassTypCd);
         R04326.R04326_appl_area.cEmplArRecInd = R04325.R04325_appl_area.cEmplArRecInd;
         strcpy(R04326.R04326_appl_area.sArchLastUpdtTs, A04323.A04323_appl_area.sArchLastUpdtTs);
 
         /**** Execute service to update record in the Deltamatic table ****/
         nSvcRtnCd1 = BCH_InvokeService(EPBUPD0,&R04326,&A04326,SERVICE_ID_04326,1,sizeof(_R04326_APPL_AREA));
                                     
         if (nSvcRtnCd1 != ARC_SUCCESS)
            {
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC,"FYS04326");
            BCH_FormatMessage(3,TXT_PPR,R04325.R04325_appl_area.sPprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_WriteDlmaticRecord");
            }
 
 
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04325");
         BCH_FormatMessage(3,TXT_PPR,pCurr->sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_WriteDlmaticRecord");
      }
 
}
 

/******************************************************************
**                                                               **
** Function Name:   DPM_3100_ReadDlmaticRecord                   **
**                                                               **
** Description:     Select a record on the Deltamatic table.     **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/
 
void    DPM_3100_ReadDlmaticRecord()                                
{
 
   /**** Initialize request and answer blocks ****/           
   memset(&R04323.R04323_appl_area, LOW_VALUES, sizeof(_R04323_APPL_AREA));
   memset(&A04323.A04323_appl_area, LOW_VALUES, sizeof(_A04323_APPL_AREA));
 
   /**** Format request block ****/
   strcpy(R04323.R04323_appl_area.sPprNbr, R04325.R04325_appl_area.sPprNbr);
   strcpy(R04323.R04323_appl_area.sNrevNbr, R04325.R04325_appl_area.sNrevNbr);
   strcpy(R04323.R04323_appl_area.sPassTypCd, R04325.R04325_appl_area.sPassTypCd);
   R04323.R04323_appl_area.cEmplArRecInd = R04325.R04325_appl_area.cEmplArRecInd;
 
   /**** Execute service to select record on the Deltamatic table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04323,&A04323,SERVICE_ID_04323,1,sizeof(_R04323_APPL_AREA));
 
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;
 
      default:  
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04323");
         BCH_FormatMessage(3,TXT_PPR,R04325.R04325_appl_area.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3100_ReadDlmaticRecord");
      }
 
}       

/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_4920_ProcessLUW()
{
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{

   /** Final clean-up processing  **/
   free(pHead);
   free(pCurr);
   free(pPrev);

   sprintf(sErrorMessage, "Total rows processed = %d, reactivated = %d, revoked = %d",
                           RS.nTotalCnt, RS.nActiveCnt, RS.nRvkCnt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);		
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

}
