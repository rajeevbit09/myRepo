/**************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass System                                            **
**                                                                         **
** Program Name:    <EPB50009.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Delta Air Lines                                        **
**                  Gay Wghitman                                           **
**                                                                         **
** Date Written:    02/15/2012                                             **
**                                                                         **
** Description:     This module process the nightly interface file from    **
**                  TesserACT for the buddy pass indicator                 **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         Description                               **
** ----       ----------         ----------------------------------------- **
**                                                                         **
**                                                                         **
****************************************************************************/

#include "epb50009.h"

main()
{
   BCH_Init("EPB50009", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
   DPM_2500_ProcessInterfaceRecords();

}

void writetologX(char x[], char y[])
{
   FILE *fp = fopen("BDYlog.txt","a");
   fprintf(fp,"%s%s\n",x,y);
   fclose(fp);
}
 void writetolog(char x[], char y)
{
   FILE *fp = fopen("BDYlog.txt","a");
   fprintf(fp,"%s%c\n",x,y);
   fclose(fp);
}

void writetoACS(char x[], char y[])
{
    FILE *fp = fopen("ACSlog.txt","a");
    fprintf(fp,"%s%s\n",x,y);
    fclose(fp);
}

void writetoDEL(char x[], char y[])
{
    FILE *fp = fopen("DELlog.txt","a");
    fprintf(fp,"%s%s\n",x,y);
    fclose(fp);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{
   char *pFileSrc;

   writetologX("Made it ","DPM_1000");

   /** Initialize  Fields  **/
   cEndOfData = NO_CHAR;
   RS.cErrorInd = NO_CHAR;
   RS.cBdyCode = YES_CHAR;
   RS.cFirstReadInd = YES_CHAR;
   RS.nTotHdrCnt = 0;
   RS.EPBF010_nRcdRead = 0;
   RS.EPBF020_nRcdWrit = 0;

   writetolog("error ind = ", RS.cErrorInd);

  /*** Get the file source from the script ***/
  /**  pFileSrc = (char *) getenv("FILE");
   strcpy(RS.sFileSrc, pFileSrc);
   strcpy(RS.sFileSrc,"EPFI509DL"); **/

 /**** Build thread table  *****/

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");


   /**** open the input HR Interface file     ***/
   RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_READ);
   if (RS.EPBF010 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sFileMsg);
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   writetolog("error ind2 = ", RS.cErrorInd);

   /**** after opening file, read the first interface record ***/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   if (BCH_eof(RS.EPBF010))
   {
       RS.cErrorInd = YES_CHAR;
       cEndOfData = YES_CHAR;
       BCH_FormatMessage(1,TXT_EMPTY_INPUT_FILE);
       BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sFileMsg);
       BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_1000_Initialize");
   }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{
  writetolog("DPM_2000",RS.cErrorInd);

 /**** Process interface records    ****/
 while (cEndOfData == NO_CHAR)
 {
   DPM_2500_ProcessInterfaceRecords();

  /****  read the next  interface record ***/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   if (BCH_eof(RS.EPBF010))
      cEndOfData = YES_CHAR;
 }

   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   if (RS.cErrorInd == NO_CHAR)
      exit(0);
   else
      exit(5);

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessInterfaceRecords             **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessInterfaceRecords()
{
   short     nSvcRtnCd;
   char      cRowFound;

   RS.EPBF010_nRcdRead++;

   writetolog("error ind3 = ", RS.cErrorInd);

   if (RS.cErrorInd == NO_CHAR)
   {
      strncpy(RS.sPprNbr, (char *)RS.EPBF010_buffer, 9);
      RS.cBdyCode = RS.EPBF010_buffer[+11,1];
      memcpy(&cBdyCode, (char*) RS.EPBF010_buffer[+10,1]);
      strncpy(sPprNbr,  (char *)RS.EPBF010_buffer, 9);
      writetolog(RS.sPprNbr,RS.cBdyCode);
      writetolog("Buddy CD",RS.cBdyCode);
      writetolog("buddyBuf",RS.EPBF010_buffer[+10,1]);
   }
   else
   {
	   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	   BCH_FormatMessage(2,TXT_SVC, "FYS04780");
	   BCH_HandleMessage(BCH_ERR_ABORT, "EPB50009", "DPM_2500_ProcessInterfaceRecords");
   }

   /*** Initialize Request and Answer Blocks for service to update bdy_nrev_pax_cfcn ***/
    memset(&R04780,LOW_VALUES, sizeof(_R04780));
    memset(&A04780,LOW_VALUES, sizeof(_A04780));

   strcpy(R04780.R04780_appl_area.sPprNbr, sPprNbr);

   /*** Execute Service to see if ppr_nbr already exists ***/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04780,&A04780,SERVICE_ID_04780,1,sizeof(R04780.R04780_appl_area));

   switch (nSvcRtnCd)
   {
         case ARC_SUCCESS:
               cRowFound = YES_CHAR;
               break;

   	     case ARC_ROW_NOT_FOUND:
               cRowFound = NO_CHAR;
               BCH_FormatMessage(1,TXT_ROW_NOT_FOUND);
               BCH_FormatMessage(2,TXT_SVC, "FYS04780");
             	sprintf(sErrorMessage, "sPprNbr = %s", sPprNbr);
               BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
               BCH_HandleMessage(BCH_ERR_WARNING, "EPB50009", "DPM_2500_ProcessInterfaceRecords");
   	           break;
         default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "EPB50009");
               BCH_HandleMessage(BCH_ERR_ABORT, "EPB50009", "DPM_2500_ProcessInterfaceRecords");
   	           break;
    }


   /*** check status if record does not exists execute service to insert else execute service to update ***/
   if (cRowFound == NO_CHAR)
   {
	memset(&R04782,LOW_VALUES, sizeof(_R04782));
    	memset(&A04782,LOW_VALUES, sizeof(_A04782));
    	strcpy(R04782.R04782_appl_area.sPprNbr, sPprNbr);
		R04782.R04782_appl_area.cBdyNrevPaxCfcnCd = cBdyCd;
		R04782.R04782_appl_area.sPrvNrevPaxCfcnCd = " ";
		strcpy(R04782.R04782_appl_area.sArchLastUpdtId, "pep5009");
		strcpy(R04782.R04782_appl_area.sPrvUpdtId, " ");

    /*** Execute Service to insert record for bdy_nrev_pax_cfcn ***/
   	nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04782,&A04782,SERVICE_ID_04782,1,sizeof(R04782.R04782_appl_area));
        switch (nSvcRtnCd)
        {
         	case ARC_SUCCESS:
         	   RS.EPBF020_nRcdWrit++;

            	break;

         	default:
            	BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            	BCH_FormatMessage(2,TXT_SVC, "FYS04782");
	        	sprintf(sErrorMessage, "sPprNbr = %s", sPprNbr);
            	BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            	BCH_HandleMessage(BCH_ERR_ABORT, "EPB50009", "DPM_2500_ProcessInterfaceRecords");
            	break;
      	}
	}
	else
	{
  	memset(&R04783,LOW_VALUES, sizeof(_R04783));
    	memset(&A04783,LOW_VALUES, sizeof(_A04783));
        strcpy(R04783.R04783_appl_area.sPprNbr, sPprNbr);
        R04783.R04783_appl_area.cBdyNrevPaxCfcnCd = cBdyCd;
        R04783.R04783_appl_area.sPrvNrevPaxCfcnCd = A04780.A04780_appl_area.sPrvNrevPaxCfcnCd;
        strcpy(R04783.R04783_appl_area.sArchLastUpdtId, "pep5009");
        strcpy(R04783.R04783_appl_area.sPrvUpdtId, A04780.A04780_appl_area.sPrvUpdtId);
	strcpy(R04783.R04783_appl_area.sPrvUpdtLts, A04780.A04780_appl_area.sPrvUpdtLts);

   	/*** Execute Service to update record for bdy_nrev_pax_cfcn ***/
   	nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04783,&A04783,SERVICE_ID_04783,1,sizeof(R04783.R04783_appl_area));
        switch (nSvcRtnCd)
        {
         	case ARC_SUCCESS:
          	   	RS.EPBF020_nRcdWrit++;
           		break;

         	default:
            	BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            	BCH_FormatMessage(2,TXT_SVC, "FYS04783");
	        	sprintf(sErrorMessage, "sPprNbr = %s", sPprNbr);
            	BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            	BCH_HandleMessage(BCH_ERR_ABORT, "EPB50009", "DPM_2500_ProcessInterfaceRecords");
            	break;
      	}
	}


}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{

   BCH_Close(RS.EPBF010);

   if (RS.cErrorInd == NO_CHAR)
   {
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sFileMsg);
      BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF010_nRcdRead);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

      BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF020");
      BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF020_nRcdWrit);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
   }
}


