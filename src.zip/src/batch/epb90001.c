/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB90001.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Transquest Inc.                                        **
**                  Faith Ammons                                           **
**                                                                         **
** Date Written:    08/29/96                                               **
**                                                                         **
** Description:     This program reads the flight leg tables and charges   **
**                  Tables and extracts information                        **
**                  on pass usage and pass charges for the month.          **
**                  It writes the records for the Monthly Pass Usage       **
**                  Summary report.                                        **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/
#include "epb90001.h"

main()
{
   BCH_Init("EPB90001", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short  nRptIndex,                 /** Report index **/
          nReqRptInd1 = FALSE;       /** Required report #1 indicator **/

   char   *pBegDate,                 /** Pointers to reporting dates **/ 
          *pEndDate;

   /**** Initialize RSAM save fields ****/
   strcpy(RS.sPassGrpCd, SPACE_CHAR);
   strcpy(sSavePprNbr, SPACE_CHAR);
   strcpy(sSaveNrevNbr, SPACE_CHAR);
   strcpy(sSavePassGrpDs, SPACE_CHAR);
   strcpy(sSavePassGrpCd, SPACE_CHAR);
   cEndOfData = 'N';
   nFltLegCnt = 0;
   RS.nLegCnt = 0;
   RS.nChrgCnt = 0;

   /**** Assign pointers for report beginning and ending dates ****/
   pBegDate = (char *) getenv("DATE1");
   pEndDate = (char *) getenv("DATE2");
   strcpy(RS.sBegDt, pBegDate);
   strcpy(RS.sEndDt, pEndDate);

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   int i = 0;
   short nSvcRtnCd;

   /*** First, load all Pass type codes and descriptions into an array - there is no ***/
   /*** Pass type table so this data is hard - coded here ***/
   strcpy(pass_typ[0].sPassTypCd, EMERGENCY);
   strcpy(pass_typ[0].sPassTypDs, "Emergency");
   strcpy(pass_typ[1].sPassTypCd, PRIORITY);
   strcpy(pass_typ[1].sPassTypDs, "Priority");
   strcpy(pass_typ[2].sPassTypCd, HONOR_ROLL);
   strcpy(pass_typ[2].sPassTypDs, "Honor Roll");
   strcpy(pass_typ[3].sPassTypCd, TRANSOCEANIC);
   strcpy(pass_typ[3].sPassTypDs, "Transoceanic");
   strcpy(pass_typ[4].sPassTypCd, DOMESTIC);
   strcpy(pass_typ[4].sPassTypDs, "Domestic");
   strcpy(pass_typ[5].sPassTypCd, COMB_DOM_TO);
   strcpy(pass_typ[5].sPassTypDs, "Combo Dom/TO");

   /*** Initialize the total fields in the pass type array ***/
   DPM_4100_InitPassTypArray();

   /*** Next, go get all of the Pass Group codes and descriptions and store in array ***/
   nPassGrpCnt = 0;

   memset(&R04472.R04472_appl_area,LOW_VALUES, sizeof(R04472.R04472_appl_area));
   memset(&A04472,LOW_VALUES,sizeof(A04472));
   R04472.R04472_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04472,&A04472,SERVICE_ID_04472,1,sizeof(R04472.R04472_appl_area));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04472");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {   
      /*** store pass group code and description in array   ***/
      strcpy(pass_grp[nPassGrpCnt].sPassGrpCd, A04472.A04472_appl_area.sPassGrpCd);
      strcpy(pass_grp[nPassGrpCnt].sPassGrpDs, A04472.A04472_appl_area.sPassGrpDs);
      nPassGrpCnt++;

      /*** go get next pass Group information**/
      R04472.R04472_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04472,LOW_VALUES,sizeof(A04472));
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04472,&A04472,SERVICE_ID_04472,1,sizeof(R04472.R04472_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04472");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   /*** Next, begin processing the flight legs that fall within the input date range ***/
   /**** Initialize Request and Answer Blocks ****/
   memset(&R04429.R04429_appl_area, LOW_VALUES, sizeof(_R04429_APPL_AREA));
   memset(&A04429.A04429_appl_area, LOW_VALUES, sizeof(_A04429_APPL_AREA));
   strcpy(R04429.R04429_appl_area.sPassGrpCd, RS.sPassGrpCd);
   strcpy(R04429.R04429_appl_area.sFltFeeBegDt, RS.sBegDt);    
   strcpy(R04429.R04429_appl_area.sFltFeeEndDt, RS.sEndDt);      
   R04429.R04429_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /*** Execute service to retrieve driving rows from the Flight Leg, Imputed Flight Leg,
        and pass group information  ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04429,&A04429,SERVICE_ID_04429,1,sizeof(_R04429_APPL_AREA));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         strcpy(RS.sPassGrpCd, A04429.A04429_appl_area.sPassGrpCd);
         strcpy(sSavePassGrpCd, A04429.A04429_appl_area.sPassGrpCd);
         strcpy(sSavePprNbr, A04429.A04429_appl_area.sPprNbr);
         strcpy(sSaveNrevNbr, A04429.A04429_appl_area.sNrevNbr);
         lSaveRfrnDt = A04429.A04429_appl_area.lFltChrgRfrnDt;
         DPM_4200_GetPassGrpDs();
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04429");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows for Monthly Pass Usage Report for
         Flight Legs and Imputed Flight Legs****/

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      DPM_2500_ProcessRows();
      RS.nLegCnt++;

      /*** Get next flight leg ***/
      R04429.R04429_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04429, LOW_VALUES, sizeof(_A04429));
      
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04429,&A04429,SERVICE_ID_04429,1,sizeof(_R04429_APPL_AREA));
      
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04429");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   /**** Process the last group of flight legs                   ****/
   cEndOfData = 'Y';
   DPM_2500_ProcessRows();

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   /*** if ppr nbr, nrev nbr, or flight charge refrn date changes,  Process ***/
   /*** charges for this group  and prepare for next batch of flight legs   ***/
   /*** if pass group changes, or if end of data, write report records ***/
   /*** and then set up to process next pass group                     ***/
   if (strcmp(A04429.A04429_appl_area.sPassGrpCd, sSavePassGrpCd) != 0    ||
       strcmp(A04429.A04429_appl_area.sPprNbr, sSavePprNbr) != 0    ||
       strcmp(A04429.A04429_appl_area.sNrevNbr, sSaveNrevNbr) != 0  ||
       A04429.A04429_appl_area.lFltChrgRfrnDt != lSaveRfrnDt        ||
       cEndOfData == 'Y')            
   {
      /*** Process this group of flight legs   ***/
      DPM_2600_ProcessFltLegGrp();

      /*** if there is no more flight leg data, write the last ***/
      /*** report records and then do no further processing    ***/
      if (cEndOfData == 'Y')
      {
         DPM_5010_Generate();
         return;
      }

      /*** save the new flight leg data ***/
      strcpy(sSavePprNbr, A04429.A04429_appl_area.sPprNbr);
      strcpy(sSaveNrevNbr, A04429.A04429_appl_area.sNrevNbr);
      lSaveRfrnDt = A04429.A04429_appl_area.lFltChrgRfrnDt;
      nFltLegCnt = 0;

      /*** if the pass group changes, Get the pass group description for the new pass group code ***/
      if (strcmp(A04429.A04429_appl_area.sPassGrpCd, sSavePassGrpCd) != 0)  
      {
         /*** write the report records for the previous pass group***/
         DPM_5010_Generate();

         /*** Set the totals in the pass type array back to 0 ***/
         DPM_4100_InitPassTypArray();

         /*** save the new pass group information ***/
         strcpy(sSavePassGrpCd, A04429.A04429_appl_area.sPassGrpCd);
         strcpy(RS.sPassGrpCd, A04429.A04429_appl_area.sPassGrpCd);
         DPM_4200_GetPassGrpDs();
      }
   }

   /*** Finally, load the flight leg data into the flight leg array ***/
   strcpy(flt_leg[nFltLegCnt].sPassTypCd, A04429.A04429_appl_area.sPassTypCd);
   strcpy(flt_leg[nFltLegCnt].sFltDprtDt, A04429.A04429_appl_area.sFltDprtDt);
   strcpy(flt_leg[nFltLegCnt].sFltOrigCtyId, A04429.A04429_appl_area.sFltOrigCtyId);
   strcpy(flt_leg[nFltLegCnt].sFltDestCtyId, A04429.A04429_appl_area.sFltDestCtyId);
   nFltLegCnt++;
    
   /*** Add 1 to leg count in pass type array   ***/
   nType = 2;
   strcpy(sPassTyp, A04429.A04429_appl_area.sPassTypCd);
   DPM_4300_AddToTotals();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2600_ProcessFltLegGrp                    **
**                                                               **
** Description:     Determine day pass type, get all associated  **
**                  charges, and write report records.           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2600_ProcessFltLegGrp()
{
   int i = 0;
   short nSvcRtnCd;

   /*** First, determine the day pass type for this group of legs ***/
   /*** the day pass type is the lowest value.                    ***/
   strcpy(sDayPassTyp, "99");
   for (i=0; i < nFltLegCnt; i++)
   {
      if (strcmp(flt_leg[i].sPassTypCd, sDayPassTyp) < 0)
         strcpy(sDayPassTyp, flt_leg[i].sPassTypCd);
   }
    
   /*** Add 1 to day count in pass type array   ***/
   nType = 1;
   strcpy(sPassTyp, sDayPassTyp);
   DPM_4300_AddToTotals();

   /*** Next, get all of the svc charges and penalties for this ppr, nrev, day and ***/
   /*** add to the appropriate total                                               ***/

   /**** Initialize Request and Answer Blocks ****/
   memset(&R04430.R04430_appl_area, LOW_VALUES, sizeof(_R04430_APPL_AREA));
   memset(&A04430.A04430_appl_area, LOW_VALUES, sizeof(_A04430_APPL_AREA));
   strcpy(R04430.R04430_appl_area.sPprNbr, sSavePprNbr);
   strcpy(R04430.R04430_appl_area.sNrevNbr, sSaveNrevNbr);
   R04430.R04430_appl_area.lFltChrgRfrnDt = lSaveRfrnDt; 
   R04430.R04430_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to retrieve the charges *******/                                   
   nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R04430,&A04430,SERVICE_ID_04430,1,sizeof(_R04430_APPL_AREA));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04430");
         sprintf(sErrorMessage, "ppr nbr = %s, nrev nbr = %s, flt chrg rfrn dt = %d",
                 sSavePprNbr, sSaveNrevNbr, lSaveRfrnDt);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_ProcessFltLegGrp");
   }  

   /**** Process each charge returned ***/                                         
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      if (strcmp(A04430.A04430_appl_area.sSvcChrgCd, PREMIUM_CHARGE) == 0   ||
                strcmp(A04430.A04430_appl_area.sSvcChrgCd, INTL_FEE) == 0   ||
                strcmp(A04430.A04430_appl_area.sSvcChrgCd, HONORROLL_PENALTY_INTL) == 0)   
         DPM_2610_ProcessLegCharges();
      else
         DPM_2620_ProcessDayCharges();

      RS.nChrgCnt++;

      /*** get next charge ***/
      R04430.R04430_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04430, LOW_VALUES, sizeof(_A04430));
      
      nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R04430,&A04430,SERVICE_ID_04430,1,sizeof(_R04430_APPL_AREA));
      
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04430");
            sprintf(sErrorMessage, "ppr nbr = %s, nrev nbr = %s, flt chrg rfrn dt = %d",
                    sSavePprNbr, sSaveNrevNbr, lSaveRfrnDt);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_ProcessFltLegGrp");
      }  
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2610_ProcessLegCharges                   **
**                                                               **
** Description:     Determine the type of charge and add to the  **
**                  appropriate total.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2610_ProcessLegCharges()
{
   int i = 0;

   strcpy(sPassTyp, DOMESTIC);  /** default pass type **/
   dAmt = A04430.A04430_appl_area.dCostChrgAmt;

   /*** determine the pass type for this charge by finding the matching leg ***/
   for (i=0; i < nFltLegCnt; i++)
   {
      if (strcmp(flt_leg[i].sFltDprtDt, A04430.A04430_appl_area.sFltDprtDt) == 0  &&
          strcmp(flt_leg[i].sFltOrigCtyId, A04430.A04430_appl_area.sFltOrigCtyId) == 0  &&
          strcmp(flt_leg[i].sFltDestCtyId, A04430.A04430_appl_area.sFltDestCtyId) == 0)
         strcpy(sPassTyp, flt_leg[i].sPassTypCd);
   }

   /*** If this charge is a service charge, add to service charge count and amount totals ***/
   if (strcmp(A04430.A04430_appl_area.sSvcChrgCd, PREMIUM_CHARGE) == 0)
   {
      nType = 4;
      DPM_4300_AddToTotals();
      nType = 3;
      DPM_4300_AddToTotals();
   }

   /*** If this charge is a penalty add to penalty amount total ***/
   if (strcmp(A04430.A04430_appl_area.sSvcChrgCd, HONORROLL_PENALTY_INTL) == 0) 
   {
      nType = 5;
      DPM_4300_AddToTotals();
   }

   /*** If this charge is an international fee add to international fee amount total ***/
   if (strcmp(A04430.A04430_appl_area.sSvcChrgCd, INTL_FEE) == 0)
   {
      nType = 6;
      DPM_4300_AddToTotals();
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2620_ProcessDayCharges                   **
**                                                               **
** Description:     Determine the type of charge and add to the  **
**                  appropriate total.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2620_ProcessDayCharges()
{
   strcpy(sPassTyp, sDayPassTyp);
   dAmt = A04430.A04430_appl_area.dCostChrgAmt;

   /*** If this charge is a service charge, add to service charge count and amount totals ***/
   if (strcmp(A04430.A04430_appl_area.sSvcChrgCd, FLAT_FEE_SVCCHG) == 0   ||
       strcmp(A04430.A04430_appl_area.sSvcChrgCd, HANDLING_FEE) == 0   ||
       strcmp(A04430.A04430_appl_area.sSvcChrgCd, SERVICE_CHARGE) == 0)   
   {
      nType = 4;
      DPM_4300_AddToTotals();
      nType = 3;
      DPM_4300_AddToTotals();
   }
   /*** otherwise add to penalty total    ***/
   else
   {
      nType = 5;
      DPM_4300_AddToTotals();
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4100_InitPassTypArray                    **
**                                                               **
** Description:     Set total fields in pass type array to 0     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_4100_InitPassTypArray()
{
   int i = 0;

   for (i=0; i < 10; i++)
   {
      pass_typ[i].lFltDyCnt = 0;
      pass_typ[i].lFltLegCnt = 0;
      pass_typ[i].lSvcChgCnt = 0;
      pass_typ[i].dTotSvcChgAmt = 0.0;
      pass_typ[i].dTotPenaltyAmt = 0.0;
      pass_typ[i].dTotIntlFeeAmt = 0.0;
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4200_GetPassGrpDs                        **
**                                                               **
** Description:     Get the pass group description from the array**
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_4200_GetPassGrpDs()
{
   char cPassGrpFound = 'N';
   int i = 0;
   short nSvcRtnCd;

      while (i < nPassGrpCnt)
      {
         if (strcmp(sSavePassGrpCd, pass_grp[i].sPassGrpCd) == 0)
         {
            strcpy(sSavePassGrpDs, pass_grp[i].sPassGrpDs);
            cPassGrpFound = 'Y';
            break;
         }
         i++;
      }

      /*** If the PPR's pass group isnt valid, send an error message to the msg log ***/
      if (cPassGrpFound == 'N')
      {
         strcpy(sSavePassGrpDs, sSavePassGrpCd);
         BCH_FormatMessage(1,TXT_MISSING_PASS_GRP);
         BCH_FormatMessage(2,TXT_PASS_GROUP, sSavePassGrpCd);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_4200_GetPassGrpDs");
      }

}

/******************************************************************
**                                                               **
** Function Name:   DPM_4300_AddToTotals                         **
**                                                               **
** Description:     Add to appropriate total in the Pass Type    **
**                  array according to the pass type.            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_4300_AddToTotals()
{
   int i = 0;

   /*** determine which array item should be updated ***/
   if (strcmp(sPassTyp, EMERGENCY) == 0)
      i = 0;
   else if (strcmp(sPassTyp, PRIORITY) == 0)
      i = 1;
   else if (strcmp(sPassTyp, HONOR_ROLL) == 0)
      i = 2;
   else if (strcmp(sPassTyp, TRANSOCEANIC) == 0)
      i = 3;
   else if (strcmp(sPassTyp, DOMESTIC) == 0)
      i = 4;
   else if (strcmp(sPassTyp, COMB_DOM_TO) == 0)
      i = 5;

   /*** Next, add to appropriate count or amount field ***/
   switch (nType)
   {
      case 1:
         pass_typ[i].lFltDyCnt++;
         break;
      
      case 2:
         pass_typ[i].lFltLegCnt++;
         break;
      
      case 3:
         pass_typ[i].lSvcChgCnt++;
         break;
      
      case 4:
         pass_typ[i].dTotSvcChgAmt += dAmt;
         break;
      
      case 5:
         pass_typ[i].dTotPenaltyAmt += dAmt;
         break;
      
      default:
         pass_typ[i].dTotIntlFeeAmt += dAmt;
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5010_Generate                            **
**                                                               **
** Description:     Write report records for each item in the    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_5010_Generate()
{
   short     nRptIndex,                     /** Index into the report control table **/
             i;                             /** Index **/
 
    /**** Initialize report sort and data copybooks ****/  
   memset(&EPRF9001.F9001_RptDataStruct, LOW_VALUES, sizeof(_F9001_RPTDATASTRUCT));
   memset(&EPRS9001.S9001_RptDataStruct, LOW_VALUES, sizeof(_S9001_RPTDATASTRUCT));
 
   for (i = 0; i < 10; i++) 
   {
      if (pass_typ[i].lFltLegCnt != 0)
      {
         /**** Put the pass group description and pass type code in the sort copybook ***/
         strcpy(EPRS9001.S9001_RptDataStruct.sPassGrpDs, sSavePassGrpDs);
         strcpy(EPRS9001.S9001_RptDataStruct.sPassTypCd, pass_typ[i].sPassTypCd);

         /*** Format the report fields in the reoport copybook ***/
         strcpy(EPRF9001.F9001_RptDataStruct.sPassGrpDs, sSavePassGrpDs);
         strcpy(EPRF9001.F9001_RptDataStruct.sPassTypDs, pass_typ[i].sPassTypDs);
         //EPRF9001.F9001_RptDataStruct.lFltDyCnt = pass_typ[i].lFltDyCnt;
         sprintf(EPRF9001.F9001_RptDataStruct.sFltDyCnt, "% 12ld", pass_typ[i].lFltDyCnt);
         //EPRF9001.F9001_RptDataStruct.lFltLegCnt = pass_typ[i].lFltLegCnt;
         sprintf(EPRF9001.F9001_RptDataStruct.sFltLegCnt, "% 12ld", pass_typ[i].lFltLegCnt);
         //EPRF9001.F9001_RptDataStruct.lSvcChgCnt = pass_typ[i].lSvcChgCnt;
         sprintf(EPRF9001.F9001_RptDataStruct.sSvcChgCnt, "% 12ld", pass_typ[i].lSvcChgCnt);
         //EPRF9001.F9001_RptDataStruct.dTotSvcChgAmt = pass_typ[i].dTotSvcChgAmt;
         sprintf(EPRF9001.F9001_RptDataStruct.sTotSvcChgAmt, "% 13.2f", pass_typ[i].dTotSvcChgAmt);
         //EPRF9001.F9001_RptDataStruct.dTotPenaltyAmt = pass_typ[i].dTotPenaltyAmt;
         sprintf(EPRF9001.F9001_RptDataStruct.sTotPenaltyAmt, "% 9.2f", pass_typ[i].dTotPenaltyAmt);
         //EPRF9001.F9001_RptDataStruct.dTotIntlFeeAmt = pass_typ[i].dTotIntlFeeAmt;
         sprintf(EPRF9001.F9001_RptDataStruct.sTotIntlFeeAmt, "% 13.2f", pass_typ[i].dTotIntlFeeAmt);

         /*** Add up the total charges for this pass group/pass type ***/
         //EPRF9001.F9001_RptDataStruct.dTotChgAmt = pass_typ[i].dTotSvcChgAmt    +
         //                                          pass_typ[i].dTotPenaltyAmt   +
         //                                          pass_typ[i].dTotIntlFeeAmt;
         sprintf(EPRF9001.F9001_RptDataStruct.sTotChgAmt, "% 15.2f", pass_typ[i].dTotSvcChgAmt +
                                                                     pass_typ[i].dTotPenaltyAmt +
                                                                     pass_typ[i].dTotIntlFeeAmt);

         EPRF9001.F9001_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

         /**** Write report record ****/
		 BCH_WriteRptRec("EPB90011",&EPRS9001, sizeof(EPRS9001), &EPRF9001, sizeof(EPRF9001));
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   sprintf(sErrorMessage, "Total nbr of flt legs and imputed flt legs processed = %d",
                           RS.nLegCnt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   sprintf(sErrorMessage, "Total nbr of Charges processed = %d",
                           RS.nChrgCnt);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
