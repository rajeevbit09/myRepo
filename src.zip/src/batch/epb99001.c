/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB99001.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Delta Technologies                                     **
**                  LaShawnda Walker                                       **
**                                                                         **
** Date Written:    05/28/99                                               **
**                                                                         **
** Description:     This process will determine if there has been multiple ** 
**                  companions set up in the same aniversary year.  A      **
**                  report will be created which will be sent to the Pass  ** 
**                  Bureau.                                                **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 07/26/00   LSW                         Corrected date conversion problems**
**                                                                         **
** 07/27/00   LSW                         Modified module to use passed in **
**                                        parameter "DATE2" for the current**
**                                        date time stamp.                 **
**                                                                         **
****************************************************************************/
#include "epb99001.h"

main()
{
   BCH_Init("EPB99001", NUMBER_OF_THREADS);
  
   DPM_1000_Initialize();

   DPM_2000_Mainline();

   BCH_Terminate();

   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short   nRptIndex,                 /** Report index **/
           nReqRptInd1 = FALSE;       /** Required report #1 indicator **/

   char   *pBegDate,                  /** Pointers to reporting dates **/
          *pEndDate;
    
   /**** Assign pointers for report beginning and ending dates ****/
   pBegDate = (char *) getenv("DATE1");
   pEndDate = (char *) getenv("DATE2");
   strcpy(RS.sBegDt, pBegDate);
   strcpy(RS.sEndDt, pEndDate);

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   /**** set up today's date ****/
   strcpy(RS.sTodayDt, sCurrentTsDt);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Process all ppr_nbr's that have multiple     **
**                  companions defined in the same anniversary   **
**                  year.                                        **
**                                                               **
** Arguments:       None.                                        **
**                                                               **
** Return Values:   None.                                        **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   char sYear[5],
        sMonth[3],
        sPrevPprNbr[10],
        sCurrPprNbr[10],
        sPassStsChgDt[27];

   int i,
       nMonth,
       nYear,
       nSvcRtnCd,
       nProcessMth=0,
       nProcessYr=0,
       nPassStsChgDt[9];

   struct CP_REC *cp_ptr;

   memset(sPrevPprNbr,'\0',sizeof(sPrevPprNbr));
   memset(sCurrPprNbr,'\0',sizeof(sCurrPprNbr));

   memset(sYear,'\0',sizeof(sYear));
   memset(sMonth,'\0',sizeof(sMonth));
 
   strncpy(sYear,getenv("DATE2")+DB_TS_POS_YEAR,4);
   strncpy(sMonth,getenv("DATE2")+DB_TS_POS_MON,2);
/*   strncpy(sYear,RS.sTodayDt+DB_TS_POS_YEAR,4); */
/*   strncpy(sMonth,RS.sTodayDt+DB_TS_POS_MON,2); */
 
   nYear = atoi(sYear);
   nMonth = atoi(sMonth);
    
   if ( nMonth == 1 )
   {
      nProcessMth = 12;
      nProcessYr = (nYear - 1);
   }
   else
   {
      nProcessMth = (nMonth - 1);
      nProcessYr = nYear;
   }

   /*** Select each companion add entry from the t_cmnt table ***/
   /*** for the current month ***/
   memset(&R04700.R04700_appl_area,LOW_VALUES,sizeof(R04700.R04700_appl_area));
   memset(&A04700,LOW_VALUES,sizeof(A04700));
   R04700.R04700_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   R04700.R04700_appl_area.nFltArrTm = nProcessMth;
   R04700.R04700_appl_area.nFltDprtTm = nProcessYr;

   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04700,&A04700,SERVICE_ID_04700,1,sizeof(R04700.R04700_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         strcpy(sPrevPprNbr,A04700.A04700_appl_area.sPprNbr);
         DPM_4000_CurrentAnnYr(A04700.A04700_appl_area.sPprStrtDt);
         break;

       case ARC_ROW_NOT_FOUND:
          break;
    
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04700");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }

   if (nSvcRtnCd == ARC_SUCCESS)
   {
      cp_ptr = (struct CP_REC *) malloc(sizeof(struct CP_REC));
      memset(cp_ptr,'\0',sizeof(struct CP_REC));
      strcpy(cp_ptr->ppr_nbr,A04700.A04700_appl_area.sPprNbr);
      strcpy(cp_ptr->nrev_nbr,A04700.A04700_appl_area.sNrevNbr);
      strcpy(cp_ptr->pass_sts_chg_dt,A04700.A04700_appl_area.sPassStsChgDt);
      strcpy(cp_ptr->pass_dt_tm_ts,A04700.A04700_appl_area.sPassDtTmTs);
      strcpy(cp_ptr->ppr_strt_dt,A04700.A04700_appl_area.sPprStrtDt);
      cp_ptr->month = A04700.A04700_appl_area.nPassCardNbr;
      cp_ptr->next_cp = NULL;
      DPM_5000_ChkDateBuildList(cp_ptr);
   }

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      R04700.R04700_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04700,LOW_VALUES,sizeof(A04700));
      
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04700,&A04700,SERVICE_ID_04700,1,sizeof(R04700.R04700_appl_area));
 
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            strcpy(sCurrPprNbr,A04700.A04700_appl_area.sPprNbr);
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04700");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }

      if ( (strcmp(sPrevPprNbr, sCurrPprNbr) != 0) || (nSvcRtnCd == ARC_ROW_NOT_FOUND) )
      {
         if ( nSvcRtnCd != ARC_ROW_NOT_FOUND )
         {
            DPM_3000_ProcessMultipleCompanions(sPrevPprNbr);
            while ( hd_ptr != NULL )
            {
               tl_ptr = hd_ptr->next_cp;
               free(hd_ptr);
               hd_ptr = tl_ptr;
            }
            hd_ptr = NULL;
            tl_ptr = NULL;
            new_cp_rec = NULL;
            next_cp_rec = NULL;
            free(curr_ann_dt);
            curr_ann_dt = NULL;
            next_cp_rec = (struct CP_REC *) malloc(sizeof(struct CP_REC));
            memset(next_cp_rec,'\0',sizeof(struct CP_REC));
            memset(sPrevPprNbr,'\0',sizeof(sPrevPprNbr));
            memset(sCurrPprNbr,'\0',sizeof(sCurrPprNbr));
            strcpy(sPrevPprNbr, A04700.A04700_appl_area.sPprNbr);
            DPM_4000_CurrentAnnYr(A04700.A04700_appl_area.sPprStrtDt);
            cp_ptr = (struct CP_REC *) malloc(sizeof(struct CP_REC));
            memset(cp_ptr,'\0',sizeof(struct CP_REC));
            strcpy(cp_ptr->ppr_nbr,A04700.A04700_appl_area.sPprNbr);
            strcpy(cp_ptr->nrev_nbr,A04700.A04700_appl_area.sNrevNbr);
            strcpy(cp_ptr->pass_sts_chg_dt,A04700.A04700_appl_area.sPassStsChgDt);
            strcpy(cp_ptr->pass_dt_tm_ts,A04700.A04700_appl_area.sPassDtTmTs);
            strcpy(cp_ptr->ppr_strt_dt,A04700.A04700_appl_area.sPprStrtDt);
            cp_ptr->month = A04700.A04700_appl_area.nPassCardNbr;
            cp_ptr->next_cp = NULL;
            DPM_5000_ChkDateBuildList(cp_ptr);
            nSvcRtnCd = ARC_SUCCESS;
         }
         else
         {
            DPM_3000_ProcessMultipleCompanions(sPrevPprNbr);
            while ( hd_ptr != NULL )
            {
               tl_ptr = hd_ptr->next_cp;
               free(hd_ptr);
               hd_ptr = tl_ptr;
            }
            hd_ptr = NULL;
            tl_ptr = NULL;
            new_cp_rec = NULL;
            next_cp_rec = NULL;
            free(curr_ann_dt);
            curr_ann_dt = NULL;
         }
      } 
      else if ( nSvcRtnCd == ARC_SUCCESS ) 
      { 
         cp_ptr = (struct CP_REC *) malloc(sizeof(struct CP_REC));
         memset(cp_ptr,'\0',sizeof(struct CP_REC));
         strcpy(cp_ptr->ppr_nbr,A04700.A04700_appl_area.sPprNbr);
         strcpy(cp_ptr->nrev_nbr,A04700.A04700_appl_area.sNrevNbr);
         strcpy(cp_ptr->pass_sts_chg_dt,A04700.A04700_appl_area.sPassStsChgDt);
         strcpy(cp_ptr->pass_dt_tm_ts,A04700.A04700_appl_area.sPassDtTmTs);
         strcpy(cp_ptr->ppr_strt_dt,A04700.A04700_appl_area.sPprStrtDt);
         cp_ptr->month = A04700.A04700_appl_area.nPassCardNbr;
         cp_ptr->next_cp = NULL;
         DPM_5000_ChkDateBuildList(cp_ptr);
      }
   }

   BCH_FormatMessage(1,TXT_OUT_FILE, "PRAF010");
   BCH_FormatMessage(2,TXT_REC_TTL, nRecCnt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");

}

/******************************************************************
**                                                               **
** Function Name:   DPM_3000_ProcessMultipleCompanions           **
**                                                               **
** Description:     This function determines if there were any   **
**                  companions defined for the previous 12 months**
**                  and adds them to the list of companions.     **
**                                                               **
** Arguments:       sPprNbr                                      **
**                                                               **
** Return Values:   None.                                        **
**                                                               **
**                                                               **
******************************************************************/
void DPM_3000_ProcessMultipleCompanions(char *sPprNbr)
{
   int nStrtMth,
       nSvcRtnCd,
       nCurrentMth=0,
       nCurrentYr=0,
       nProcessMth=0,
       nProcessYr=0,
       nPassStsChgDt=0;

   char sStrtMth[3],
        sCurrentMth[3],
        sCurrentYr[5],
        sProcessMth[4],
        sNrevNbr[3];

   short nRptIndex;                     /** Index into the report control table **/

   struct CP_REC *cp_ptr,
                 *new_ptr,
                 *prev_ptr;


   memset(sCurrentMth,'\0',sizeof(sCurrentMth));
   strncpy(sCurrentMth,getenv("DATE2")+DB_TS_POS_MON,2);
   memset(sCurrentYr,'\0',sizeof(sCurrentYr));
   strncpy(sCurrentYr,getenv("DATE2")+DB_TS_POS_YEAR,4);
   nCurrentMth = atoi(sCurrentMth);
   nCurrentYr = atoi(sCurrentYr);

   if ( nCurrentMth == 1 )
   {
      nProcessMth = 12;
      nProcessYr = (nCurrentYr - 1);
   } 
   else 
   {
      nProcessMth = (nCurrentMth - 1);
      nProcessYr = nCurrentYr;
   }

   memset(sProcessMth,'\0',sizeof(sProcessMth));
   strncpy(sProcessMth,Mtn[nProcessMth-1],3);

   memset(sStrtMth,'\0',sizeof(sStrtMth));
   strncpy(sStrtMth,curr_ann_dt->sAnnStrtDt+DB_TS_POS_MON-1,2);
   nStrtMth = atoi(sStrtMth);

   if ( nStrtMth != (nProcessMth) )
   {
      /*** Get companion add entry from the t_cmnt table for ppr_nbr  ***/
      memset(&R04701.R04701_appl_area,LOW_VALUES,sizeof(R04701.R04701_appl_area));
      memset(&A04701,LOW_VALUES,sizeof(A04701));
      strcpy(R04701.R04701_appl_area.sPprNbr, sPprNbr);
      R04701.R04701_appl_area.nFltArrTm = nProcessMth;
      R04701.R04701_appl_area.nFltDprtTm = nProcessYr;
      R04701.R04701_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
    
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04701,&A04701,SERVICE_ID_04701,1,sizeof(R04701.R04701_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04701");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_ProcessMultipleCompanions");
      }

      while ( nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {
         new_ptr = hd_ptr;
         nPassStsChgDt = atoi(DPM_6000_PassStsChgDt(A04701.A04701_appl_area.sPassDtTmTs,A04701.A04701_appl_area.nPassCardNbr));
         if ( nPassStsChgDt != (curr_ann_dt->nAnnStrtDt-1) )
         {  
            while ( new_ptr != NULL )
            {
               if ( (strncmp(new_ptr->ppr_nbr,A04701.A04701_appl_area.sPprNbr,9) == 0) && 
                    (strncmp(new_ptr->nrev_nbr,A04701.A04701_appl_area.sNrevNbr,2) == 0) )
                  break;
               else
                  new_ptr = new_ptr->next_cp;
            }
         }   
        
         if ( new_ptr == NULL )
         {
            cp_ptr = (struct CP_REC *) malloc(sizeof(struct CP_REC));
            memset(cp_ptr,'\0',sizeof(struct CP_REC));
            strcpy(cp_ptr->ppr_nbr,A04701.A04701_appl_area.sPprNbr);
            strcpy(cp_ptr->nrev_nbr,A04701.A04701_appl_area.sNrevNbr);
            strcpy(cp_ptr->pass_sts_chg_dt,A04701.A04701_appl_area.sPassStsChgDt);
            strcpy(cp_ptr->pass_dt_tm_ts,A04701.A04701_appl_area.sPassDtTmTs);
            strcpy(cp_ptr->ppr_strt_dt,A04701.A04701_appl_area.sPprStrtDt);
            cp_ptr->month = A04701.A04701_appl_area.nPassCardNbr;
            cp_ptr->next_cp = NULL;
            DPM_5000_ChkDateBuildList(cp_ptr);
         }

         /*** Get all companion add entries from the t_cmnt table ***/
         /*** for ppr_nbr  ***/
         memset(&A04701,LOW_VALUES,sizeof(A04701));
         R04701.R04701_appl_area.cArchCursorOpTxt = FETCH_ROW;

         nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04701,&A04701,SERVICE_ID_04701,1,sizeof(R04701.R04701_appl_area));

         /****** Service Return Code Processing  ****/
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;

            case ARC_ROW_NOT_FOUND:
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS04701");
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_ProcessMultipleCompanions");
         }
      }

      /*** Get all companion revoke entries from the t_cmnt table for ppr_nbr  ***/
      memset(&R04705.R04705_appl_area,LOW_VALUES,sizeof(R04705.R04705_appl_area));
      memset(&A04705,LOW_VALUES,sizeof(A04705));
      strcpy(R04705.R04705_appl_area.sPprNbr, sPprNbr);
      R04705.R04705_appl_area.nFltArrTm = nProcessMth;
      R04705.R04705_appl_area.nFltDprtTm = nProcessYr;
      R04705.R04705_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
      
      nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R04705,&A04705,SERVICE_ID_04705,1,sizeof(R04705.R04705_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04705");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_ProcessMultipleCompanions");
      }

      while ( nSvcRtnCd != ARC_ROW_NOT_FOUND )
      {
         new_ptr = hd_ptr;
         nPassStsChgDt = atoi(DPM_6000_PassStsChgDt(A04705.A04705_appl_area.sPassDtTmTs,A04705.A04705_appl_area.nPassCardNbr));
         if ( nPassStsChgDt != (curr_ann_dt->nAnnStrtDt-1) )
         {
            while ( new_ptr != NULL )
            {
               if ( (strncmp(new_ptr->ppr_nbr,A04705.A04705_appl_area.sPprNbr,9) == 0) && 
                    (strncmp(new_ptr->nrev_nbr,A04705.A04705_appl_area.sNrevNbr,2) == 0) )
                  break;
               else
                  new_ptr = new_ptr->next_cp;
         }
      }

      if ( new_ptr == NULL )
      {
        cp_ptr = (struct CP_REC *) malloc(sizeof(struct CP_REC));
        memset(cp_ptr,'\0',sizeof(struct CP_REC));
        strcpy(cp_ptr->ppr_nbr,A04705.A04705_appl_area.sPprNbr);
        strcpy(cp_ptr->nrev_nbr,A04705.A04705_appl_area.sNrevNbr);
        strcpy(cp_ptr->pass_sts_chg_dt,A04705.A04705_appl_area.sPassStsChgDt);
        strcpy(cp_ptr->pass_dt_tm_ts,A04705.A04705_appl_area.sPassDtTmTs);
        strcpy(cp_ptr->ppr_strt_dt,A04705.A04705_appl_area.sPprStrtDt);
        cp_ptr->month = A04705.A04705_appl_area.nPassCardNbr;
        cp_ptr->next_cp = NULL;
        DPM_5000_ChkDateBuildList(cp_ptr);
      }

      /*** Get companion revoke entry from the t_cmnt table for ppr_nbr  ***/
      memset(&A04705,LOW_VALUES,sizeof(A04705));
      R04705.R04705_appl_area.cArchCursorOpTxt = FETCH_ROW;
      nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R04705,&A04705,SERVICE_ID_04705,1,sizeof(R04705.R04705_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
      {
        case ARC_SUCCESS:
          break;
        case ARC_ROW_NOT_FOUND:
          break;
        default:
          BCH_FormatMessage(1,TXT_SVC_UNSUCC);
          BCH_FormatMessage(2,TXT_SVC, "FYS04705");
          BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_ProcessMultipleCompanions");
      }

    }
  }

  new_ptr = hd_ptr;
  prev_ptr = new_ptr;

  while ( new_ptr != NULL )
  {
    memset(&EPRF9901.F9901_RptDataStruct, LOW_VALUES, sizeof(_F9901_RPTDATASTRUCT));
    memset(&EPRS9901.S9901_RptDataStruct, LOW_VALUES, sizeof(_S9901_RPTDATASTRUCT));

    strcpy(EPRS9901.S9901_RptDataStruct.sPprNbr,new_ptr->ppr_nbr);
    strcpy(EPRS9901.S9901_RptDataStruct.sNrevNbr,new_ptr->nrev_nbr);
    strcpy(EPRS9901.S9901_RptDataStruct.sPassDtTmTs,
           UTL_ConvertDate(new_ptr->pass_sts_chg_dt,CNV_DB_TO_DD_MMM_YYYY));
    strcpy(EPRF9901.F9901_RptDataStruct.sPprNbr,new_ptr->ppr_nbr);
    strcpy(EPRF9901.F9901_RptDataStruct.sNrevNbr,new_ptr->nrev_nbr);
    strcpy(EPRF9901.F9901_RptDataStruct.sPassStsChgDt,
           UTL_ConvertDate(new_ptr->pass_sts_chg_dt,CNV_DB_TO_DD_MMM_YYYY));
    strcpy(EPRF9901.F9901_RptDataStruct.sPprStrtDt,
           UTL_ConvertDate(new_ptr->ppr_strt_dt,CNV_DB_TO_DD_MMM_YYYY));
    EPRF9901.F9901_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;
    if ( (strncmp(sProcessMth,UTL_ConvertDate(new_ptr->pass_sts_chg_dt,CNV_DB_TO_DD_MMM_YYYY)+3,3) == 0) && 
         (new_ptr->next_cp != NULL) )
    {
       ++nRecCnt;
       BCH_WriteRptRec("EPB99011",&EPRS9901, sizeof(EPRS9901), &EPRF9901, sizeof(EPRF9901));
    }
    else if ( (strncmp(sProcessMth,UTL_ConvertDate(new_ptr->pass_sts_chg_dt,CNV_DB_TO_DD_MMM_YYYY)+3,3) == 0) && 
              (new_ptr->next_cp == NULL) && (new_ptr != hd_ptr) )
    {
       ++nRecCnt;
       BCH_WriteRptRec("EPB99011",&EPRS9901, sizeof(EPRS9901), &EPRF9901, sizeof(EPRF9901));
    }
    else if ( (strncmp(sProcessMth,UTL_ConvertDate(new_ptr->pass_sts_chg_dt,CNV_DB_TO_DD_MMM_YYYY)+3,3) != 0) && 
              (new_ptr->next_cp == NULL) && 
              (strncmp(sProcessMth,UTL_ConvertDate(prev_ptr->pass_sts_chg_dt,CNV_DB_TO_DD_MMM_YYYY)+3,3) == 0))
    {
       ++nRecCnt;
       BCH_WriteRptRec("EPB99011",&EPRS9901, sizeof(EPRS9901), &EPRF9901, sizeof(EPRF9901));
    }
    prev_ptr = new_ptr;
    new_ptr = new_ptr->next_cp;
  }

  new_ptr = NULL;
  prev_ptr = NULL;

}

/******************************************************************
**                                                               **
** Function Name:   DPM_4000_CurrentAnnYr                        **
**                                                               **
** Description:     This function determines the current         **
**                  anniversary year for each ppr_nbr passed in. **
**                                                               **
** Arguments:       sPprStrtDt                                   **
**                                                               **
** Return Values:   None.                                        **
**                                                               **
**                                                               **
******************************************************************/
void DPM_4000_CurrentAnnYr(char *sPprStrtDt)
{
  char sDay[3],
       sMonth[4],
       sRSMthDay[5],
       sMonthDay[5],
       sRSYear[5];

  int nEndYr=0,
      nStrtYr=0,
      nMonth=0,
      nMonthDay=0,
      nRSMthDay=0,
      i=0;


  memset(sDay,'\0',sizeof(sDay));
  memset(sMonth,'\0',sizeof(sMonth));
  memset(sRSYear,'\0',sizeof(sRSYear));
  memset(sRSMthDay,'\0',sizeof(sRSMthDay));

  strncpy(sDay,sPprStrtDt+DB_TS_POS_DAY,2);
  strncpy(sMonth,sPprStrtDt+DB_TS_POS_MON,2);
  strncpy(sRSMthDay,RS.sTodayDt+DB_TS_POS_MON,2);
  strncat(sRSMthDay,RS.sTodayDt+DB_TS_POS_DAY,2);
  
  nMonth = atoi(sMonth);

  curr_ann_dt = (struct ANN_YR *) malloc(sizeof(struct ANN_YR));
  memset(curr_ann_dt,'\0',sizeof(struct ANN_YR));

  sprintf(sMonthDay,"%d",nMonth);
  strcat(sMonthDay,sDay);

  nMonthDay = atoi(sMonthDay);
  nRSMthDay = atoi(sRSMthDay);

  strncpy(sRSYear,RS.sTodayDt+DB_TS_POS_YEAR,4);

  if ( nMonthDay > nRSMthDay )
  {
    nStrtYr = atoi(sRSYear) - 1;
    sprintf(curr_ann_dt->sAnnStrtDt,"%d",nStrtYr);
    nEndYr = atoi(sRSYear);
    sprintf(curr_ann_dt->sAnnEndDt,"%d",nEndYr);
  } else if ( nMonthDay <= nRSMthDay ) {
    nStrtYr = atoi(sRSYear);
    sprintf(curr_ann_dt->sAnnStrtDt,"%d",nStrtYr);
    nEndYr= atoi(sRSYear) + 1;
    sprintf(curr_ann_dt->sAnnEndDt,"%d",nEndYr);
  }

  strncpy(curr_ann_dt->sAnnStrtDt+4,sMonth,2);
  strncpy(curr_ann_dt->sAnnStrtDt+6,sPprStrtDt+DB_TS_POS_DAY,2);

  strncpy(curr_ann_dt->sAnnEndDt+4,sMonth,2);
  strncpy(curr_ann_dt->sAnnEndDt+6,sPprStrtDt+DB_TS_POS_DAY,2);

  curr_ann_dt->nAnnStrtDt = atoi(curr_ann_dt->sAnnStrtDt);
  curr_ann_dt->nAnnEndDt = atoi(curr_ann_dt->sAnnEndDt);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5000_ChkDateBuildList                    **
**                                                               **
** Description:     This function determines if the record is for**
**                  the current ppr_nbr anniversary year and then**
**                  adds the data into the list.                 **
**                                                               **
** Arguments:       struct CP_REC *cp_ptr                        **
**                                                               **
** Return Values:   None.                                        **
**                                                               **
**                                                               **
******************************************************************/
void DPM_5000_ChkDateBuildList(struct CP_REC *cp_ptr)
{

  int nAnnEndDt=0,
      nPassStsChgDt=0,
      nMonth=0;

  char sAnnEndDt[9],
       sMonth[3];

  memset(sAnnEndDt,'\0',sizeof(sAnnEndDt));
  strncpy(sAnnEndDt,getenv("DATE2")+DB_TS_POS_YEAR,4);
  strncat(sAnnEndDt,getenv("DATE2")+DB_TS_POS_MON,2);
  strncat(sAnnEndDt,"01",2);

  nAnnEndDt=atoi(sAnnEndDt);

  nPassStsChgDt = atoi(DPM_6000_PassStsChgDt(cp_ptr->pass_dt_tm_ts,cp_ptr->month));

  if ( (nPassStsChgDt >= (curr_ann_dt->nAnnStrtDt-1)) && (nPassStsChgDt < nAnnEndDt) )
  {
    if ( hd_ptr == NULL)
    {
      new_cp_rec = (struct CP_REC *) malloc(sizeof(struct CP_REC));
      memset(new_cp_rec,'\0',sizeof(struct CP_REC));
      strcpy(new_cp_rec->ppr_nbr,cp_ptr->ppr_nbr);
      strcpy(new_cp_rec->nrev_nbr,cp_ptr->nrev_nbr);
      strcpy(new_cp_rec->pass_sts_chg_dt,cp_ptr->pass_sts_chg_dt);
      strcpy(new_cp_rec->pass_dt_tm_ts,cp_ptr->pass_dt_tm_ts);
      strcpy(new_cp_rec->ppr_strt_dt,cp_ptr->ppr_strt_dt);
      new_cp_rec->month = cp_ptr->month;
      new_cp_rec->next_cp = NULL;
      hd_ptr = new_cp_rec;
      tl_ptr = new_cp_rec;
    } else {
      next_cp_rec = (struct CP_REC *) malloc(sizeof(struct CP_REC));
      memset(next_cp_rec,'\0',sizeof(struct CP_REC));
      new_cp_rec->next_cp = next_cp_rec;
      new_cp_rec = next_cp_rec;
      strcpy(next_cp_rec->ppr_nbr,cp_ptr->ppr_nbr);
      strcpy(next_cp_rec->nrev_nbr,cp_ptr->nrev_nbr);
      strcpy(next_cp_rec->pass_sts_chg_dt,cp_ptr->pass_sts_chg_dt);
      strcpy(next_cp_rec->pass_dt_tm_ts,cp_ptr->pass_dt_tm_ts);
      strcpy(next_cp_rec->ppr_strt_dt,cp_ptr->ppr_strt_dt);
      next_cp_rec->month = cp_ptr->month;
      next_cp_rec->next_cp = NULL;
      tl_ptr = new_cp_rec;
    }
  }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_6000_PassStsChgDt                        **
**                                                               **
** Description:     This function determines the pass status     **
**                  change date from the record information that **
**                  is passed in.   And returns a pointer to the **
**                  value.                                       **
**                                                               **
** Arguments:       sDate, sMonth                                **
**                                                               **
** Return Values:   Pointer to a date string.                    **
**                                                               **
**                                                               **
******************************************************************/
char *DPM_6000_PassStsChgDt(sDate,nMonth)
char *sDate;
int nMonth;
{
   char iStr[3],
        sPassStsChgDt[9];

   memset(iStr,'\0',sizeof(iStr));
   memset(sPassStsChgDt,'\0',sizeof(sPassStsChgDt));

   strncpy(sPassStsChgDt,sDate+DB_TS_POS_YEAR,4);
 
   sprintf(iStr,"%d",nMonth);
   if ( strlen(iStr) < 2 )
      sprintf(sPassStsChgDt+4,"0%s",iStr);
   else
      sprintf(sPassStsChgDt+4,"%s",iStr);

   strncpy(sPassStsChgDt+6,sDate+DB_TS_POS_DAY,2);
 
   return(sPassStsChgDt);
}
