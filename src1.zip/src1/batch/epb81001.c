/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB81001.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Transquest Information Solutions                       **
**                  Kimberly Gordon                                        **
**                                                                         **
** Date Written:    December 1, 1995                                       **
**                                                                         **
** Description:     This program produces the 1099 Interface file.         **
**                  Data is collected for Board Members, Western           **
**                  Early-Outs, and Former Western employees from          **
**                  the PPR, Imputed Trip, and Imputed Trip History        **
**                  tables.                                                **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         Description                               **
** ----       ----------         ----------------------------------------- **
** 9/11/95    KJG                Create                                    **
** 8/11/99    CDM                Convert                                   **
** 1/26/00    LAS                Added ARC_ROW_NOT_FOUND case for fyr03735 **   
**                                                                         **
****************************************************************************/

#include "epb81001.h"

main()
{
   BCH_Init("EPB81001", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   char *pEndDt;                  /** Pointer to flight ending date **/

   /**** Initialize RSAM Save Fields with spaces ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);
  
   /**** Get beginning and ending dates from environment variables ****/
   pEndDt = (char *) getenv("END_DATE");
   strcpy(RS.sEndDt, pEndDt);

   /**** Initialize accumulators ****/
   RS.EPBF020_record_cntr = 0;
   RS.EPBF020_record_amt = 0.0;

   /**** Set flag to false ****/
   RS.nCntlFileWrttn = FALSE;

   /**** Initialize interface layout structures ****/
   memset(&CntlRec,LOW_VALUES,sizeof(CntlRec));
   memset(&PrsnlRec,LOW_VALUES,sizeof(PrsnlRec));
   memset(&VchrRec,LOW_VALUES,sizeof(VchrRec));

   /**** Initialize architecture of service area ****/
   memset(&A02752,LOW_VALUES,sizeof(_A02752));
   memset(&R02752,LOW_VALUES,sizeof(_R02752));
   memset(&A02780,LOW_VALUES,sizeof(_A02780));
   memset(&R02780,LOW_VALUES,sizeof(_R02780));
   memset(&A03735,LOW_VALUES,sizeof(_A03735));
   memset(&R03735,LOW_VALUES,sizeof(_R03735));
   memset(&A03736,LOW_VALUES,sizeof(_A03736));
   memset(&R03736,LOW_VALUES,sizeof(_R03736));
   memset(&A04015,LOW_VALUES,sizeof(_A04015));
   memset(&R04015,LOW_VALUES,sizeof(_R04015));
   memset(&A04261,LOW_VALUES,sizeof(_A04261));
   memset(&R04261,LOW_VALUES,sizeof(_R04261));

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   RS.EPBF020 = BCH_Open("EPBF020", BCH_FILE_WRITE);
   if (RS.EPBF020 == BCH_FAIL)
   {
      BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
      BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF020");
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   /****** Initialize Request and Answer Blocks *****/
   memset(&R02752.R02752_appl_area,LOW_VALUES,sizeof(R02752.R02752_appl_area));
   memset(&A02752.A02752_appl_area,LOW_VALUES,sizeof(A02752.A02752_appl_area));

   /**** Format service request block for initial DB cursor read ****/
   strcpy(R02752.R02752_appl_area.sPprNbr, RS.sPprNbr);

   /**** Open the initial DB cursor ****/
   R02752.R02752_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to retrieve driving rows from the PPR table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02752,&A02752,SERVICE_ID_02752,1,sizeof(_R02752_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
   	  case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02752");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  
   
   /**** Process driving database rows ****/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      DPM_2500_ProcessRows();

      DPM_3000_WriteRecords();
	  

      /**** Initialize request block ****/
      memset(&R03735.R03735_appl_area,LOW_VALUES,sizeof(_R03735_APPL_AREA));

      /**** Format Request block with specifics ****/
      strcpy(R03735.R03735_appl_area.sPprNbr, A02752.A02752_appl_area.sPprNbr);
      strcpy(R03735.R03735_appl_area.sFltFeeEndDt, RS.sEndDt);

      /**** Update row that has been processed from the Imputed Trip table ****/
	  nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R03735,&A03735,SERVICE_ID_03735,1,sizeof(_R03735_APPL_AREA));

      /**** Service return code processing ****/
	  switch (nSvcRtnCd)
      {
	 case ARC_ROW_NOT_FOUND:
	    break;     

         case ARC_SUCCESS:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03735");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  

      /**** Initialize request block ****/
      memset(&R03736.R03736_appl_area,LOW_VALUES,sizeof(_R03736_APPL_AREA));

      /**** Format Request block with specifics ****/
      strcpy(R03736.R03736_appl_area.sPprNbr, A02752.A02752_appl_area.sPprNbr);
      strcpy(R03736.R03736_appl_area.sFltFeeEndDt, RS.sEndDt);

      /**** Update row that has been processed from the Imputed Trip History table ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R03736,&A03736,SERVICE_ID_03736,1,sizeof(_R03736_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03736");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
      memset(&R04261.R04261_appl_area,LOW_VALUES,sizeof(_R04261_APPL_AREA));

      /**** Format Request block with specifics ****/
      strcpy(R04261.R04261_appl_area.sPprNbr, A02752.A02752_appl_area.sPprNbr);
      strcpy(R04261.R04261_appl_area.sFltFeeEndDt, RS.sEndDt);
 
      /**** Update row that has been processed from the Imputed flight leg table ****/
	  nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04261,&A04261,SERVICE_ID_04261,1,sizeof(_R04261_APPL_AREA));
 
      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {  
         case ARC_SUCCESS:
            break;

	 case ARC_ROW_NOT_FOUND:
		     break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04261");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  


      /**** Open cursor to obtain next db row ****/
      R02752.R02752_appl_area.cArchCursorOpTxt = FETCH_ROW;

      memset(&A02752.A02752_appl_area,LOW_VALUES,sizeof(_A02752_APPL_AREA));

      /****** Execute service to retrieve driving rows from the PPR table ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02752,&A02752,SERVICE_ID_02752,1,sizeof(_R02752_APPL_AREA));


      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02752");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   
   }

   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   /**** Initialize service request and answer blocks  ****/
   memset(&R04015.R04015_appl_area,LOW_VALUES,sizeof(_R04015_APPL_AREA));
   memset(&A04015.A04015_appl_area,LOW_VALUES,sizeof(_A04015_APPL_AREA));

   /**** Format Request block with specifics ****/
   strcpy(R04015.R04015_appl_area.sPprNbr, A02752.A02752_appl_area.sPprNbr);
   strcpy(R04015.R04015_appl_area.sFltFeeEndDt, RS.sEndDt);
  
   /**** Execute service to calculate total imputed wage amount from the Imputed Trip table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04015,&A04015,SERVICE_ID_04015,1,sizeof(_R04015_APPL_AREA));
   
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04015");
         BCH_FormatMessage(3,TXT_PPR, R04015.R04015_appl_area.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
   }  

   /**** Initialize service request and answer blocks ****/
   memset(&R02780.R02780_appl_area,LOW_VALUES,sizeof(_R02780_APPL_AREA));
   memset(&A02780.A02780_appl_area,LOW_VALUES,sizeof(_A02780_APPL_AREA));
 
   /**** Format Request block with specifics ****/
   strcpy(R02780.R02780_appl_area.sPprNbr, A02752.A02752_appl_area.sPprNbr);
   strcpy(R02780.R02780_appl_area.sFltFeeEndDt, RS.sEndDt);

   /**** Execute service to calculate total imputed wage amount from the Imputed Trip History table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02780,&A02780,SERVICE_ID_02780,1,sizeof(_R02780_APPL_AREA));
   
   /**** Return code processing ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02780");
         BCH_FormatMessage(3,TXT_PPR, R02780.R02780_appl_area.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
   }  
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3000_WriteRecords()                      **
**                                                               **
** Description:     Write control, personnel, and voucher        **
**                  records to interface file.                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_3000_WriteRecords()
{
   double dTotFltImptWage;
   char   sTempWage1[12];
   char   sTempWage2[11];
   int    i;

   dTotFltImptWage = 0;

   if (RS.nCntlFileWrttn == FALSE)
   {
      /**** Initialize Control record ****/
      memset(&RS.EPBF020_buffer,SPACE_CHAR,sizeof(RS.EPBF020));
      RS.EPBF020_buffer[sizeof(RS.EPBF020)] = LOW_VALUES;

      /**** Format Control record ****/
      CntlRec.cRecTypInd = CNTL_IND;
      memset(CntlRec.sTaxYr, LOW_VALUES, sizeof(CntlRec.sTaxYr));
      strncpy(CntlRec.sTaxYr, RS.sEndDt+2, 2);   /* chng for CCYY  kh */
      strcpy(CntlRec.sRunNbr, RUN_NBR);
      strcpy(CntlRec.sFiller, SPACE_CHAR);

      sprintf(RS.EPBF020_buffer, HDR_FMT, CntlRec.cRecTypInd,
                                          CntlRec.sTaxYr,
                                          CntlRec.sRunNbr,
                                          CntlRec.sFiller);

      /**** Write Control record to file ****/
      BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));

      RS.nCntlFileWrttn = TRUE;
   }

   /**** Initialize output buffer ****/
   memset(&RS.EPBF020_buffer,SPACE_CHAR,sizeof(RS.EPBF020));
   RS.EPBF020_buffer[sizeof(RS.EPBF020)] = LOW_VALUES;

   /**** Format Personnel record ****/
   PrsnlRec.cRecTypInd = PRSNL_IND;
   strcpy(PrsnlRec.sPprSocSecNbr, A02752.A02752_appl_area.sPprSocSecNbr);
   PrsnlRec.cTaxNbr = TAX_NBR;
   strcpy(PrsnlRec.sPpr1Nm, A02752.A02752_appl_area.sPprNm);
   PrsnlRec.cFiller1 = SPACE;
   strcpy(PrsnlRec.sPpr2Nm, SPACE_CHAR);
   strcpy(PrsnlRec.sPpr2Nm, SPACE_CHAR);
   strcpy(PrsnlRec.sPpr1Addr, A02752.A02752_appl_area.sPpr1Addr);
   PrsnlRec.cOvfwInd = SPACE;
   strcpy(PrsnlRec.sPpr2Addr, SPACE_CHAR);
   strcpy(PrsnlRec.sPprCtyAddr, A02752.A02752_appl_area.sPprCtyAddr);
   strcpy(PrsnlRec.sPprStCd, A02752.A02752_appl_area.sPprStCd);
   strcpy(PrsnlRec.sPprZipAddr, A02752.A02752_appl_area.sPprZipAddr);
   PrsnlRec.cStsInd = STATUS_IND;
   strcpy(PrsnlRec.sFiller2, SPACE_CHAR);
   strcpy(PrsnlRec.sDeptNbr, PASS_DEPT);
   strcpy(PrsnlRec.sPprVendor, A02752.A02752_appl_area.sPprNbr);
   strcpy(PrsnlRec.sPpr2Name, SPACE_CHAR);
   strcpy(PrsnlRec.sPpr2Address, A02752.A02752_appl_area.sPpr2Addr);
   strcpy(PrsnlRec.sFiller3, SPACE_CHAR);

   /**** Determine the numeric state code ****/
   for (i = 0; i < 57; i++)
   {
      if (strcmp(PrsnlRec.sPprStCd, pStateStruct[i]) == 0)
      {
         PrsnlRec.nPprStNbr = i+1;
         break;
      }
   }

   /**** Format message if state code is not found ****/
   if (i == 57)
   {
      BCH_FormatMessage(1,TXT_INVLD_STATE_CD);
      BCH_FormatMessage(2,TXT_PPR,A02752.A02752_appl_area.sPprNbr);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_3000_WriteRecords");
   }

   /**** Format Voucher record ****/
   VchrRec.cRecTypInd = VCHR_IND;
   strcpy(VchrRec.sPprSocSecNbr, A02752.A02752_appl_area.sPprSocSecNbr);
   strcpy(VchrRec.sVchrNbr, VCHR_NBR);
   VchrRec.cPmtTypCd = PMT_TYPE;
   strcpy(VchrRec.sTaxAmt, TAX_AMT);
   strcpy(VchrRec.sFiller, SPACE_CHAR);

   /**** Set total imputed wage amount equal to sum of amounts from the Imputed Trip and Imputed Trip
         History tables ****/
   dTotFltImptWage = A02780.A02780_appl_area.fFltImptWageAmt + A04015.A04015_appl_area.fFltImptWageAmt;

   if (dTotFltImptWage != 0 )
   {
      /**** Initialize temporary fields ****/
      memset(sTempWage1, LOW_VALUES, sizeof(sTempWage1));
      memset(sTempWage2, LOW_VALUES, sizeof(sTempWage2));

      /**** Format imputed wage amount field without decimal ****/
      sprintf(sTempWage1, "%011.2f", dTotFltImptWage);
      strncpy(sTempWage2, sTempWage1, 8);
      strncpy(sTempWage2+8, sTempWage1+9, 2);
      strcpy(VchrRec.sFltImptWageAmt, sTempWage2);

      sprintf(RS.EPBF020_buffer, PRSNL_REC_FMT, PrsnlRec.cRecTypInd,
                                                PrsnlRec.sPprSocSecNbr,
                                                PrsnlRec.cTaxNbr,
                                                PrsnlRec.sPpr1Nm,
                                                PrsnlRec.cFiller1,
                                                PrsnlRec.sPpr2Nm,
                                                PrsnlRec.sPpr1Addr,
                                                PrsnlRec.cOvfwInd,
                                                PrsnlRec.sPpr2Addr,
                                                PrsnlRec.sPprCtyAddr,
                                                PrsnlRec.sPprStCd,
                                                PrsnlRec.sPprZipAddr,
                                                PrsnlRec.nPprStNbr,
                                                PrsnlRec.cStsInd,
                                                PrsnlRec.sFiller2,
                                                PrsnlRec.sDeptNbr, 
						PrsnlRec.sPprVendor,
						PrsnlRec.sPpr2Name,
						PrsnlRec.sPpr2Address,
                                                PrsnlRec.sFiller3);

      /**** Write Personnel Record ****/
      BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));

      /**** Initialize output buffer ****/
      memset(&RS.EPBF020_buffer,SPACE_CHAR,sizeof(RS.EPBF020));
      RS.EPBF020_buffer[sizeof(RS.EPBF020)] = LOW_VALUES;

      sprintf(RS.EPBF020_buffer, VCHR_REC_FMT, VchrRec.cRecTypInd,
                                               VchrRec.sPprSocSecNbr,
                                               VchrRec.sVchrNbr,
                                               VchrRec.cPmtTypCd,
                                               VchrRec.sFltImptWageAmt,
                                               VchrRec.sTaxAmt, 
                                               VchrRec.sFiller);
  
      /**** Write Voucher Record ****/
      BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));
    
      RS.EPBF020_record_cntr++;
      RS.EPBF020_record_amt += dTotFltImptWage;
   }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program.                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void DPM_9500_ProcessEndOfProgram()
{

   BCH_Close(RS.EPBF020);

   /**** Write control totals here ****/
   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF020");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF020_record_cntr);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF020_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

}
