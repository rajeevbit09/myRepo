/**************************************************************************** 
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         ** 
** Sub-System :     Pass Accounting                                        **
**                                                                         ** 
** Program Name:    EPB90014.c                                             ** 
**                                                                         ** 
** Shell Used:      <shlrfmc0.c>                                           ** 
**                                                                         **
** Program Type:    Batch Report Format Module with zero control breaks    ** 
**                                                                         ** 
** Author :         Andersen Consulting                                    ** 
**                  C. Eachus                                              **
**                                                                         ** 
** Date Written:    6/21/95                                                ** 
**                                                                         ** 
** Description:     A Report Format Module (RFM) formats report records    ** 
**                  into a report.                                         ** 
**                                                                         **
**                                                                         ** 
****************************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "epb90014.h"
#include "bchrfmcd.h"

main()
{
   RFM_1000_InitializeFlds();
   while ((feof(stdin)) == 0)
      {
      RFM_3000_ProcessDetail();  
      }
   RFM_4000_ProcessEndOfJob();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1000_InitializeFlds                      **
**                                                               **
** Description:     Initialize fields, read initial record,      **
**                  zero accumulators                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1000_InitializeFlds()
{
char   sCurrentDate[13];  /* current date in mm/dd/yy format */

   rfm_ReadNextRecord();

   /*  Initialize totals      */
   nRptPagesWritten = 0;

   /* No grand total fields are needed for this report */

   /* Get system date and time    */
   current = time((time_t *)0);
   strcpy(tu.t_str, ctime(&current));
   strftime(sCurrentDate,12,"%m/%d/%y",localtime(&current));

   tu.t_str[7] = tu.t_str[10]=tu.t_str[19]=tu.t_str[24]='\0';
 
   /* If report has an as of date, format the as of date here   */
   nCurrentLineCount = NEW_PAGE;
   memset(print_line,' ',PAGE_WIDTH);
   strcpy(sRequestId, input_area.rqst_id);

   /* Format and save standard headings */

   /* standard heading 1 */
   PRINT_SETUP(1,"CSR #:");
   PRINT_SETUP(11,"7908");
   PRINT_SETUP(56,STD_RPT_TITLE);
   PRINT_SETUP(115,"PAGE:");
   memcpy(std_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 2 */
   PRINT_SETUP(1,"REPORT:");
   PRINT_SETUP(11,"EPB90014");
   PRINT_SETUP(54,"PASS OFFICE AUDIT REPORT");
   PRINT_SETUP(115,"DATE:");
   PRINT_SETUP(123,sCurrentDate);
   memcpy(std_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 3 */
   sprintf(sInputFld, "PERIOD %s TO %s", rpt_data.F9004_RptDataStruct.sFltFeeBegDt, rpt_data.F9004_RptDataStruct.sFltFeeEndDt);
   PRINT_SETUP(51, sInputFld);
   PRINT_SETUP(115,"TIME:");
   PRINT_SETUP(123,tu.ts.hh_mm_ss);
   memcpy(std_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* modify the following code sections to the requirements of the report */
 
   /* application heading 1 */
   PRINT_SETUP(13, "USER");
   PRINT_SETUP(23, "PPR/");
   PRINT_SETUP(33, "GRP");
   PRINT_SETUP(37, "TYP");
   memcpy(appl_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);


   /* application heading 2 */
   PRINT_SETUP(4, "DATE");
   PRINT_SETUP(14, "ID");
   PRINT_SETUP(22, "NREV ID");
   PRINT_SETUP(33, "CD");
   PRINT_SETUP(37, "CD");
   PRINT_SETUP(50, "CHANGE TYPE");
   PRINT_SETUP(81, "CHANGE FROM");
   PRINT_SETUP(113, "CHANGE TO");
   memcpy(appl_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);


   /* application heading 3 */
   PRINT_SETUP(2, "________");
   PRINT_SETUP(12,"______");
   PRINT_SETUP(20,"___________");
   PRINT_SETUP(33,"__");
   PRINT_SETUP(37,"__");
   PRINT_SETUP(41,"______________________________");
   PRINT_SETUP(72,"______________________________");
   PRINT_SETUP(103,"______________________________");
   memcpy(appl_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

}     /*** End of RFM_1000_InitializeFlds ***/

/******************************************************************
**                                                               **
** Function Name:   RFM_3000_ProcessDetail                       **
**                                                               **
** Description:     Process detail line, read next record and    **
**                  determine if there was a control break       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3000_ProcessDetail()
{
    RFM_3100_ProcessReportRecord();
    rfm_ReadNextRecord();
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3100_ProcessReportRecord                 **
**                                                               **
** Description:     Format detail line.                          **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3100_ProcessReportRecord()
{
  
  /* Variable used in right justifying the AudtChgFr(To)Nm */
   long lStartCol;

   nLinesInGroup = DETAIL_LINE;
  /* Set End of Report flag to no */
   cEndOfRpt = 'N';

   /* Format detail print line   */
  
   PRINT_SETUP(2,rpt_data.F9004_RptDataStruct.sAcrlEffDt);
   PRINT_SETUP(12,rpt_data.F9004_RptDataStruct.sAudtUserId);
   PRINT_SETUP(20,rpt_data.F9004_RptDataStruct.sPprNbr);
   PRINT_SETUP(29,rpt_data.F9004_RptDataStruct.sNrevNbr);
   PRINT_SETUP(33,rpt_data.F9004_RptDataStruct.sPassGrpCd);
   PRINT_SETUP(37,rpt_data.F9004_RptDataStruct.sPassTypCd);
   PRINT_SETUP(41,rpt_data.F9004_RptDataStruct.sAudtChgTypNm);
   PRINT_SETUP(72,rpt_data.F9004_RptDataStruct.sAudtChgFrNm);
   PRINT_SETUP(103,rpt_data.F9004_RptDataStruct.sAudtChgToNm);
   rfm_ControlPrint(SINGLE_SPACE, print_line);
 
}

/******************************************************************
**                                                               **
** Function Name:   RFM_4000_ProcessEndOfJob                     **
**                                                               **
** Description:     Format description lines, print "end of      **
**                  report" line, close input file.              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4000_ProcessEndOfJob()
{

 /* Set flag so no more header rows will be printed on top of the report */
       cEndOfRpt = 'Y';

       nCurrentLineCount = NEW_PAGE;

  /*** Format description key at the bottom of the report ***/

   PRINT_SETUP(3,"PASS GROUP DESCRIPTIONS");
   PRINT_SETUP(82,"PASS TYPE DESCRIPTIONS");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
   PRINT_SETUP(3,"_______________________");
   PRINT_SETUP(82,"_______________________");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"AC = ACTIVE DL (SDW) w/o kids");
   PRINT_SETUP(82,"10 = EMERGENCY");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"AK = ACTIVE DL (SDW) w/kids");
   PRINT_SETUP(82,"20 = PRIORITY");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"BM = BOARD MEMBERS"); 
   PRINT_SETUP(82,"30 = HONOR ROLL"); 
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"DA = DISABLED, SINGLE, age 52 (pilot - age 50) 10 yrs cont svc");
   PRINT_SETUP(82,"40 = TRANSOCEANIC");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"DB = DISABLED, MARRIED, age 52 (pilot - age 50) 10 yrs cont svc");
   PRINT_SETUP(82,"50 = DOMESTIC");
   PRINT_SETUP(3,"DS = DISABLED REGULAR (SDW)");
   PRINT_SETUP(82,"90 = COMB DOM/TO");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"DW = DISABLED LIMIT WIDOW");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"EW = EARLY THREE WIDOW");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"FU = FURLOUGHED EMPLOYEE");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"FW = FORMER WESTERN EMPLOYEE");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"KR = READY RESERVE (SDW) w/kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"KT = ASSOCIATE DELTA (SDW) w/kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"LC = LEAVE of ABSENCE CO CONVENIENCE");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"LK = LEAVE of ABSENCE SICK (SDW) w/kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"LM = LEAVE of ABSENCE SICK (M)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"LS = LEAVE of ABSENCE SICK (SDW) w/o kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"LT = MILITARY LEAVE (>30)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"LW = RETIREE LIMIT WIDOW");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"MA = ACTIVE DELTA (M)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"MD = DISABLED REGULAR (M)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"MR = READY RSRV DELTA (M)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"MT = ASSOCIATE DELTA (M)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"OW = OJI WIDOW");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"PA = PAN AM PARTICIPANT");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"QK = LEADERSHIP 7.5 QTO (SDW) w/kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"QM = LEADERSHIP 7.5 QTO (M)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"QT = LEADERSHIP 7.5 QTO (SDW) w/o kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"RE = RETIRED EARLY SIX");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"RL = RETIRED LIMIT DELTA");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"RR = REGULAR RETIRED DELTA");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"RT = RETIRED ASSOCIATE");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"SK = SENIOR OFFICERS (SDW) w/kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"SM = SENIOR OFFICERS (M)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"SO = SENIOR OFFICERS (SDW) w/o kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"SR = READY RSRV DELTA (SDW) w/o kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"ST = ASSOCIATE DELTA (SDW) w/o kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"TD = TRANSQUEST - FORMER DL");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"TQ = TRANSQUEST - NOT FORMER DL");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"TR = TRANSQUEST - FORMER DL RET");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"TW = THREE MONTH WIDOW");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"UW = UNLIMITED WIDOW");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"VS = LDRSHP 7.5 VOL SEVERANCE");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WA = WSPAN ACTIVE-FMR DL (SDW) w/o kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WB = WSPAN ACTIVE-FMR DL (M)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WC = WSPAN DISABLE-FMR DL (SDW)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WD = WSPAN DISABLE-FMR DL (M)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WE = WESTERN EARLY-OUT");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WL = WORLDSPAN LEAVE-FMR DL");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WM = WSPAN TEMP-FMR DL (M)");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WN = WORLDSPAN-NOT FMR DL");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WR = WESTERN RETIREE");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WS = WSPAN TEMP-FMR DL (SDW) w/o kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(3,"WT = WSPAN TEMP-FMR DL (SDW) w/kids");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   
   


  /* Format end of report line */

   PRINT_SETUP(3, "END OF REPORT");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_5000_PageHeadings                        **
**                                                               **
** Description:     Format and print heading line                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_5000_PageHeadings()
{
char sNbrOfReportPages[4];  /* Number of report pages written */
 
   nRptPagesWritten++;
   
   /*  Format first heading line */

   memcpy(print_line,std_heading_1,PAGE_WIDTH);
   sprintf(sNbrOfReportPages,"%3i",nRptPagesWritten);
   PRINT_SETUP(128,sNbrOfReportPages);
   rfm_PrintLine(NEW_PAGE,print_line);
 
   /*  Format second heading line */

   memcpy(print_line,std_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   /*  Format third heading line */
 
   memcpy(print_line,std_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
   rfm_PrintLine(DOUBLE_SPACE, print_line);

 if (cEndOfRpt == 'N')
   { 

   /* Add 7 blank lines between headings and application headings */
  
   rfm_PrintLine(SINGLE_SPACE, print_line);
   rfm_PrintLine(DOUBLE_SPACE, print_line);

   /*  Format application headings */
 
   memcpy(print_line,appl_heading_1,PAGE_WIDTH);
   rfm_PrintLine(DOUBLE_SPACE, print_line);
   memcpy(print_line,appl_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
   memcpy(print_line,appl_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
    } 
}

