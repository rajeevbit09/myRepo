/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB71100.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Written:    September 25, 1995                                     **
**                                                                         **
** Description:     This module calculates the imputed value, employee     **
**                  payment, and imputed wage amounts for trips flown      **
**                  by imputed PPRs and their designees.  These amounts    **
**                  are updated on the Imputed Trip table, and handling    **
**                  fee records are inserted into the Charges table for    **
**                  trips flown by non-revenue passengers whose PPRs are   **
**                  imputed but are not Board Members or Senior Officers.  **
**                                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 03/20/96      JFB                      Added new Senior Officer groups. **
**                                                                         **
** 04/16/96      JFB                      Modified SO/BM imputed wage      **
**                                        calculation to subract payment.  **
**                                                                         **
** 03/13/97      LAS                      Modified imputed value for       **
**                                        German PPRs to convert to US     **
**                                        dollars prior to calculating     **
**                                        imputed wage and writing to the  **
**                                        imputed trip table               **
**                                                                         **
** 05/01/98      LAS                      Removed Germans from imputed     **
**                                        processing.                      **		
**                                                                         **
****************************************************************************/


#include "epb71100.h"


main()
{
   BCH_Init("EPB71100", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}


/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{

   /**** Report variables not needed ****/
 
   /**** Set processing flag to continue ****/ 
   nStopProcess = FALSE;

   /**** Initialize key in RSAM saved area to zero ****/
   RS.lPassTripNbr = 0;
 
   /**** Initialize working storage ****/
   memset(&WS, LOW_VALUES, sizeof(WS));

   /**** No counters & accumulators ****/

   /**** Initialize architecture area of service answer and request blocks ****/
   memset(&A02436, LOW_VALUES, sizeof(_A02436));
   memset(&R02436, LOW_VALUES, sizeof(_R02436));
   memset(&A02526, LOW_VALUES, sizeof(_A02526));
   memset(&R02526, LOW_VALUES, sizeof(_R02526));
   memset(&A02574, LOW_VALUES, sizeof(_A02574));
   memset(&R02574, LOW_VALUES, sizeof(_R02574));
   memset(&A02575, LOW_VALUES, sizeof(_A02575));
   memset(&R02575, LOW_VALUES, sizeof(_R02575));
   memset(&A02576, LOW_VALUES, sizeof(_A02576));
   memset(&R02576, LOW_VALUES, sizeof(_R02576));
   memset(&A02577, LOW_VALUES, sizeof(_A02577));
   memset(&R02577, LOW_VALUES, sizeof(_R02577));
   memset(&A02579, LOW_VALUES, sizeof(_A02579));
   memset(&R02579, LOW_VALUES, sizeof(_R02579));
   memset(&A03208, LOW_VALUES, sizeof(_A03208));
   memset(&R03208, LOW_VALUES, sizeof(_R03208));
   memset(&A03885, LOW_VALUES, sizeof(_A03885));
   memset(&R03885, LOW_VALUES, sizeof(_R03885));

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{
      /****** Initialize service request and answer blocks *****/
      memset(&R02575.R02575_appl_area, LOW_VALUES, sizeof(_R02575_APPL_AREA));
      memset(&A02575.A02575_appl_area, LOW_VALUES, sizeof(_A02575_APPL_AREA));

      /**** Format service request block for initial DB cursor read ****/
      R02575.R02575_appl_area.lPassTripNbr = RS.lPassTripNbr;

      /**** Open the initial DB cursor ****/
      R02575.R02575_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

      /**** Execute service to select from the Imputed Trip table where match Indicator is 'A'
            and employee payment and imputed wage fields equal 0.00 ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02575,&A02575,SERVICE_ID_02575,1,sizeof(_R02575_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
             // Strip any trailing space, so an empty tax Number is NULL
             UTL_StripTrailingSpaces(A02575.A02575_appl_area.sPprInttxNbr);
             break;

         case ARC_ROW_NOT_FOUND: 
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02575");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
 
         }  


      /**** Get DEM to USD exchange rate from t_exchg_rate table to convert the imputed value amount ****/
      /**** to U.S. dollars                                                                          ****/
      memset(&R03208.R03208_appl_area,LOW_VALUES, sizeof(R03208.R03208_appl_area));
      memset(&A03208,LOW_VALUES,sizeof(A03208));
      strcpy(R03208.R03208_appl_area.sCurrSrcCd, DEM_CURR);
      strcpy(R03208.R03208_appl_area.sCurrDestCd, USD_CURR);

      nSvcRtnCd = BCH_InvokeService(EPBINQ2,
                                    &R03208,
                                    &A03208,
                                    SERVICE_ID_03208,
                                    1,
                                    sizeof(R03208.R03208_appl_area));

      switch (nSvcRtnCd)
           {
           case ARC_SUCCESS:
           break;
 
           case ARC_ROW_NOT_FOUND:
           BCH_FormatMessage(1,TXT_XCHG_RT_RETRIEVE_ERR, DEM_CURR);
           BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
           break;
 
           default:
           BCH_FormatMessage(1,TXT_SVC_UNSUCC);
           BCH_FormatMessage(2,TXT_SVC, "FYS03208");
           BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
           }

   /**** Process driving database rows ****/

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {
      /**** Updated to remove Germans from imputed processing, so the following logic will  ****/
      /**** exclude any German employees.  (LScott 04/30/98)                                ****/
      /**** Only Senior Officers and Board Members with an imputed value,                   ****/
      /**** and everyone else (not a SO or BM) with no imputed value                         ****/

     /** if ((A02575.A02575_appl_area.sPprInttxNbr[0] != NULL) &&
          (A02575.A02575_appl_area.fFltImptValAmt == 0))  

         DPM_2500_ProcessRows();    **/

         if  ((!strcmp(A02575.A02575_appl_area.sPassGrpCd, BOARD_MEMBERS) ||
               !strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS) ||
               !strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) ||
               !strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD)) &&
               (A02575.A02575_appl_area.fFltImptValAmt != 0))

         DPM_2500_ProcessRows();

         else if ((strcmp(A02575.A02575_appl_area.sPassGrpCd, BOARD_MEMBERS) != 0) &&
               (strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS) != 0) &&
               (strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) != 0) &&
               (strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) != 0) &&
               (A02575.A02575_appl_area.fFltImptValAmt == 0))

         DPM_2500_ProcessRows();


      DPM_4920_ProcessLUW();

      /**** Set processing flag to continue ****/
      nStopProcess = FALSE;

      /**** Execute service to obtain next db row ****/
      R02575.R02575_appl_area.cArchCursorOpTxt = FETCH_ROW;

      memset(&A02575.A02575_appl_area, LOW_VALUES,sizeof(_A02575_APPL_AREA));

      /**** Execute service to select from the Imputed Trip table where match Indicator is 'A'
            and employee payment and imputed wage fields equal 0.00 ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02575,&A02575,SERVICE_ID_02575,1,sizeof(_R02575_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            /**** Initialize working storage ****/
            memset(&WS, LOW_VALUES, sizeof(WS));
            // Strip any trailing space, so an empty tax Number is NULL
            UTL_StripTrailingSpaces(A02575.A02575_appl_area.sPprInttxNbr);
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02575");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
 
         }  
      }


   /**** Report logic is not needed ****/

   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessRows()
{
   char   sFmtAmt[10];           /** Formatted imputed amount **/


   /**** Initialize field ****/
   memset(&sFmtAmt, LOW_VALUES, sizeof(sFmtAmt));

   /**** Determine city pair mileage is the PPR is not a Board Member or Senior Officer who is not German ****/
   if (((strcmp(A02575.A02575_appl_area.sPassGrpCd, BOARD_MEMBERS) != 0) &&
       (strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS) != 0) &&
       (strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) != 0) &&
       (strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) != 0)) ||
       (A02575.A02575_appl_area.sPprInttxNbr[0] != NULL))
      DPM_2600_GetCityPairMileage();

   if (CONTINUE_PROCESS)
      {
      DPM_2700_CalculateImputedValue();

      if (CONTINUE_PROCESS)
         {
         DPM_2800_CalculateEmpPayment();

         
         /********************************/
         /**** Calculate imputed wage ****/
         /********************************/

         /**** Set imputed wage equal to imputed value less employee payment ****/
         sprintf(sFmtAmt, "%.2lf", WS.dFltImptValAmt);
         WS.dFltImptValAmt = atof(sFmtAmt);
         WS.dFltImptWageAmt = WS.dFltImptValAmt - WS.fNrevPmtAmt;

         if (WS.dFltImptWageAmt < 0)
            WS.dFltImptWageAmt = 0;

         DPM_2900_UpdateImputedTrip();
         }
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2600_GetCityPairMileage                  **
**                                                               **
** Description:     Get the number of miles flown for a city     **
**                  pair from the Airport Pair Mileage table.    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2600_GetCityPairMileage()
{
 
   /**** Initialize service request and answer blocks ****/
   memset(&A02576.A02576_appl_area, LOW_VALUES, sizeof(_A02576_APPL_AREA));
   memset(&R02576.R02576_appl_area, LOW_VALUES, sizeof(_R02576_APPL_AREA));

   /**** Format Request block with specifics ****/
   strcpy(R02576.R02576_appl_area.sFltOrigCtyId, A02575.A02575_appl_area.sFltTripOrigId);
   strcpy(R02576.R02576_appl_area.sFltDestCtyId, A02575.A02575_appl_area.sFltTripDestId);

   /**** Execute service to select from the Airport Pair Mileage table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02576,&A02576,SERVICE_ID_02576,1,sizeof(_R02576_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         nStopProcess = TRUE;
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_FormatMessage(2,TXT_ARPT_PR_RETRIEVE_ERR,R02576.R02576_appl_area.sFltOrigCtyId,
                                                      R02576.R02576_appl_area.sFltDestCtyId);
         BCH_FormatMessage(3,TXT_SVC, "FYS02576");
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2600_GetCityPairMileage");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02576");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_GetCityPairMileage");
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2700_CalculateImputedValue               **
**                                                               **
** Description:     Calcualate the imputed value of trip for     **
**                  imputed PPR.                                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2700_CalculateImputedValue()
{
   double   dKiloNbr;                  /** City Pair distance in kilometers **/
   double   dGrsTaxValRateMod;          /** Gross taxable value rate modifier (German only) **/

/*****************************************************************************************/
/**** Updated to remove Germans from imputed processing, so the following logic will  ****/
/**** exclude any German employees.  NOTE: Service FYS02575 was updated to exclude    ****/
/**** German employees   (L.Scott 04/30/98)                                           ****/ 
   /*********** Calculate imputed value for PPR ***********/
   if (A02575.A02575_appl_area.sPprInttxNbr[0] = NULL)    
      {  
      /**** Call primative service 2436 to retreive birthdate of nrev passenger ****/
  
      /**** Initialize service request and answer blocks ****/
      memset(&A02436.A02436_appl_area, LOW_VALUES, sizeof(_A02436_APPL_AREA));   
      memset(&R02436.R02436_appl_area, LOW_VALUES, sizeof(_R02436_APPL_AREA));  
  
      /**** Format Request block with specifics ****/
      strcpy(R02436.R02436_appl_area.sPprNbr,  A02575.A02575_appl_area.sPprNbr);  
      strcpy(R02436.R02436_appl_area.sNrevNbr, A02575.A02575_appl_area.sNrevNbr);  
  
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02436,&A02436,  
                                    SERVICE_ID_02436,1,sizeof(_R02436_APPL_AREA));  
  
      /**** Service return code processing ****/
      switch (nSvcRtnCd)  
         {
         case ARC_SUCCESS:
            /**** Determine passenger age at flight time and 
                  set gross taxable value rate modifier accordingly ****/
            switch (DPM_2750_DetAgeGroup (A02436.A02436_appl_area.sNrevBdayDt, 
                                          A02575.A02575_appl_area.sFltDprtDt))
               { 
               case AGE_GRP_UNDER_2:    dGrsTaxValRateMod = .1;
                                        break;
               case AGE_GRP_2_TO_11:    dGrsTaxValRateMod = .5;
                                        break;
               case AGE_GRP_OVER_11:    dGrsTaxValRateMod = 1.0;
                                        break;
              }  
               
            break;
   
         case ARC_ROW_NOT_FOUND:
            nStopProcess = TRUE;
            sprintf(sErrorMessage,"Information on passenger (PprNbr: %s, NrevNbr: %s) not found.",
                                   R02436.R02436_appl_area.sPprNbr, R02436.R02436_appl_area.sNrevNbr);
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
            BCH_FormatMessage(2,TXT_SVC, "FYS02436");
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2700_CalculateImputedValue");
            break;
  
         default:  
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02436");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2700_CalculateImputedValue");
         }  
  
      /**** Convert city pair miles to kilometers and double value to obtain round-trip distance ****/ 
      dKiloNbr = (double)A02576.A02576_appl_area.lFltArptPrNbr * 1.6094 * 2.0;
  
  
      /**** Calculate imputed value ****/
      if (dKiloNbr > 16000.00)
         WS.dFltImptValAmt = dKiloNbr * 0.042;
      else if (dKiloNbr > 12000.00)
         WS.dFltImptValAmt = dKiloNbr * (0.048 - (0.006 * ((dKiloNbr - 12000)/4000)));
      else if (dKiloNbr > 4000.00)
         WS.dFltImptValAmt = dKiloNbr * (0.078 - (0.030 * ((dKiloNbr - 4000)/8000)));
      else if (dKiloNbr > 2600.00)
         WS.dFltImptValAmt = dKiloNbr * (0.090 - (0.012 * ((dKiloNbr - 2600)/1400)));
      else if (dKiloNbr > 1200.00)
         WS.dFltImptValAmt = dKiloNbr * (0.114 - (0.024 * ((dKiloNbr - 1200)/1400)));
      else if (dKiloNbr > 600.00)
         WS.dFltImptValAmt = dKiloNbr * (0.162 - (0.048 * ((dKiloNbr - 600)/600)));
      else
         WS.dFltImptValAmt = dKiloNbr * (0.306 - (0.144 * ((dKiloNbr - 0)/600)));
  
      /**** Modify the gross taxable vaule by the modifier that was determined based on passenger's age ****/
      WS.dFltImptValAmt *= dGrsTaxValRateMod;
  
  
      /**** Multiply imputed value amount by the DEM exchange rate ****/
      WS.dFltImptValAmt *= A03208.A03208_appl_area.dPassExchgRatNbr;
  
      }
  

   /********** Set imputed value for Board Member or Senior Officer **********/
   /********** equat to imputed value amount in Imputed Trip table  **********/
        if (!strcmp(A02575.A02575_appl_area.sPassGrpCd, BOARD_MEMBERS) ||
            !strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS) ||
            !strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) ||
            !strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD))
      {

            WS.dFltImptValAmt = A02575.A02575_appl_area.fFltImptValAmt;
 
      }

   /********** Calculate imputed value for non-German PPR **********/
   /**********   (not a Board Member or Senior Officer)   **********/
   else
      {
      /**** Initialize service request and answer blocks ****/
      memset(&A02579.A02579_appl_area, LOW_VALUES, sizeof(_A02579_APPL_AREA));
      memset(&R02579.R02579_appl_area, LOW_VALUES, sizeof(_R02579_APPL_AREA));

      /**** Format Request block with specifics ****/
      strcpy(R02579.R02579_appl_area.sFltOrigCtyId, A02575.A02575_appl_area.sFltTripOrigId);
      strcpy(R02579.R02579_appl_area.sFltDestCtyId, A02575.A02575_appl_area.sFltTripDestId);

      /**** Execute service to select yield amount from the Airport Pair Type table ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02579,&A02579,SERVICE_ID_02579,1,sizeof(_R02579_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            /**** Calculate imputed value ****/
            WS.dFltImptValAmt = .25*(A02579.A02579_appl_area.dCpYieldAmt * (double)A02576.A02576_appl_area.lFltArptPrNbr);
            break;

         case ARC_ROW_NOT_FOUND:
            nStopProcess = TRUE;
            sprintf(sErrorMessage,"Yield for airport pair type code not found.");
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
            BCH_FormatMessage(2,TXT_ARPT_PR_RETRIEVE_ERR,R02579.R02579_appl_area.sFltOrigCtyId,
                                                         R02579.R02579_appl_area.sFltDestCtyId);
            BCH_FormatMessage(3,TXT_SVC, "FYS02579");
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2700_CalculateImputedValue");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02579");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2700_CalculateImputedValue");
         }
      } 
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2750_DetAgeGroup                         **
**                                                               **
** Description:     Determines what age group a passenger        **
**                  was in given that passenger's birhtdate      **
**                  and a trip departure date                    **
**                                                               **
** Arguments:       char[]   sNrevBdayDt   birth date            **
**                  char{}   sFltDprtDt    trip departure date   **
**                                                               **
** Return Values:                                                **
**   #define             Value                                   **
**   -------             -----                                   **
**   AGE_GRP_UNDER_2         1                                   **
**   AGE_GRP_2_TO_11         2                                   **
**   AGE_GRP_OVER_11         3                                   **
**                                                               **
******************************************************************/
short DPM_2750_DetAgeGroup (char *sNrevBdayDt, char *sFltDprtDt)
{
   struct tm NrevBdayDt;
   struct tm FltDprtDt;
   short  nAge;
   
   NrevBdayDt = UTL_GetTmFromDate(sNrevBdayDt);
   FltDprtDt  = UTL_GetTmFromDate(sFltDprtDt);

   /* now determine age */
   nAge = FltDprtDt.tm_year - NrevBdayDt.tm_year;

   if ( ( NrevBdayDt.tm_mon > FltDprtDt.tm_mon                          ) ||
        ((NrevBdayDt.tm_mon == FltDprtDt.tm_mon) && (NrevBdayDt.tm_mday > FltDprtDt.tm_mday))    )
      {
      nAge--;
      }  /* end if */

   /* return age group based on age */
   if ( nAge < 2 )
     {
     return (AGE_GRP_UNDER_2);
     }
   else if  ( (nAge >=2) && (nAge <= 11) )
     {
     return(AGE_GRP_2_TO_11);
     }
   else
     {
     return (AGE_GRP_OVER_11);
     }

}  /* end DPM_2750_DetAgeGroup */


/******************************************************************
**                                                               **
** Function Name:   DPM_2800_CalculateEmpPayment                 **
**                                                               **
** Description:     For a non-revenue passenger who is not a     **
**                  Senior Officer or Board Member, process      **
**                  a handling fee.  Call the service to         **
**                  compute the employee payment from the        **
**                  Charges table for all non-revenue            **
**                  passengers.                                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2800_CalculateEmpPayment()
{
   
/************************************************************************************ 
 ************************ HANDLING FEE IS NOT PROCESSED ***************************** 
 ************************************************************************************ 
    **** Process a handling fee for non-revenue passenger if German or not            
         a Senior Officer or Board Member ****                                        
   if (((strcmp(A02575.A02575_appl_area.sPassGrpCd, BOARD_MEMBERS) != 0) &&           
        (strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS) != 0) &&         
        (strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) != 0) &&      
        (strcmp(A02575.A02575_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) != 0)) ||    
        (A02575.A02575_appl_area.sPprInttxNbr[0] != NULL))                      
                                                                                      
      DPM_2850_ProcessHandlingFee();                                                  
 ************************************************************************************ 
 ************************************************************************************/


   /********** Determine employee payment **********/

   /**** Initialize service request and answer blocks ****/
   memset(&A02577.A02577_appl_area, LOW_VALUES, sizeof(_A02577_APPL_AREA));
   memset(&R02577.R02577_appl_area, LOW_VALUES, sizeof(_R02577_APPL_AREA));

   /**** Format Request block with specifics ****/
   R02577.R02577_appl_area.lPassTripNbr = A02575.A02575_appl_area.lPassTripNbr;

   /**** Execute service to select employee payment amount from Charges table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02577,&A02577,SERVICE_ID_02577,1,sizeof(_R02577_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         WS.fNrevPmtAmt = (float)A02577.A02577_appl_area.dCostChrgAmt;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02577");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2800_CalculateEmpPayment");
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2850_ProcessHandlingFee                  **
**                                                               **
** Description:     Insert a handling fee charge record into the **
**                  Charges table (double the amount if German). **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2850_ProcessHandlingFee()
{
  char sTemp[32];

   /**** Initialize service request and answer blocks ****/
   memset(&A03885.A03885_appl_area, LOW_VALUES, sizeof(_A03885_APPL_AREA));

   /**** Execute service to select handling fee amount from the Pass Charge Amount table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R03885,&A03885,SERVICE_ID_03885,1,sizeof(_R03885));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         sprintf(sErrorMessage,"Handling fee not found.");
         BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_FormatMessage(2,TXT_SVC, "FYS03885");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2850_ProcessHandlingFee");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS03885");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2850_ProcessHandlingFee");
      }

   /**** Initialize service request and answer blocks ****/
   memset(&A02526.A02526_appl_area, LOW_VALUES, sizeof(_A02526_APPL_AREA));
   memset(&R02526.R02526_appl_area, LOW_VALUES, sizeof(_R02526_APPL_AREA));

   /**** Format Request block with specifics ****/
   strcpy(R02526.R02526_appl_area.sPprNbr, A02575.A02575_appl_area.sPprNbr);
   strcpy(R02526.R02526_appl_area.sNrevNbr, A02575.A02575_appl_area.sNrevNbr);
   strcpy(R02526.R02526_appl_area.sFltDprtDt, A02575.A02575_appl_area.sFltDprtDt);
   strcpy(R02526.R02526_appl_area.sPassDtTmTs, sCurrentTsDt);
   strcpy(R02526.R02526_appl_area.sFltOrigCtyId, A02575.A02575_appl_area.sFltTripOrigId);
   strcpy(R02526.R02526_appl_area.sFltDestCtyId, A02575.A02575_appl_area.sFltTripDestId);
   R02526.R02526_appl_area.lPassTripNbr = A02575.A02575_appl_area.lPassTripNbr;
   strcpy(R02526.R02526_appl_area.sSvcChrgCd, HANDLING_FEE);

   /**** Double the handling fee for Germans to charge for round trip ****/
   if (A02575.A02575_appl_area.sPprInttxNbr[0] != NULL)
      R02526.R02526_appl_area.dCostChrgAmt = A03885.A03885_appl_area.dCostChrgAmt * 2.0;
   else
      R02526.R02526_appl_area.dCostChrgAmt = A03885.A03885_appl_area.dCostChrgAmt;

   strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
   strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, A03885.A03885_appl_area.sFltFeeAcctNbr);
   strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
   strcpy(R02526.R02526_appl_area.sSvcChrgDs, SPACE_CHAR);

   /**** Convert flight departure date to Julian ****/
   R02526.R02526_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(A02575.A02575_appl_area.sPassRptSortDt);

   /**** Execute service to insert handling fee record into Charges table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(_R02526_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02526");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2850_ProcessHandlingFee");
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2900_UpdateImputedTrip                   **
**                                                               **
** Description:     Update the Imputed Trip table with imputed   **
**                  value, employee payment, and imputed wage    **
**                  for the trip.                                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2900_UpdateImputedTrip()
{

   /**** Initialize service request and answer blocks ****/
   memset(&R02574.R02574_appl_area, LOW_VALUES, sizeof(_R02574_APPL_AREA));

   /**** Format Request block with specifics ****/
   R02574.R02574_appl_area.lPassTripNbr = A02575.A02575_appl_area.lPassTripNbr;
   R02574.R02574_appl_area.fFltImptWageAmt = WS.dFltImptWageAmt;
   R02574.R02574_appl_area.fNrevPmtAmt = WS.fNrevPmtAmt;
   R02574.R02574_appl_area.fFltImptValAmt = WS.dFltImptValAmt;
   
   /**** Execute service to update the Imputed Trip table with the imputed value, employee payment,
         and imputed wage for the trip ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02574,&A02574,SERVICE_ID_02574,1,sizeof(_R02574_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         sprintf(sErrorMessage,"Trip Number: %d",R02574.R02574_appl_area.lPassTripNbr);
         BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_FormatMessage(3,TXT_SVC, "FYS02574");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2900_UpdateImputedTrip");
      }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_4920_ProcessLUW()
{
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{
   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
