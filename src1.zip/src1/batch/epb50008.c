/**************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass System                                            **
**                                                                         **
** Program Name:    <EPB50008.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Delta Ait Lines                                        **
**                  Gay Whitman                                            **
**                                                                         **
** Date Written:    02/15/2012                                             **
**                                                                         **
** Description:     This module balances the input HR file.  If the file is**
**                  empty, contains no header record, or does not balance, **
**                  an error is issued so that that the HR Update Module   **
**                  will not run.  If everything is ok, the module writes  **
**                  all of the data records, but not the header, out to    **
**                  the balanced output file.                              **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         Description                               **
** ----       ----------         ----------------------------------------- **
**                                                                         **
**                                                                         **
****************************************************************************/


#include "epb50008.h"


main()
{
   BCH_Init("EPB50008", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

void writetolog(char x[], char y)
{
   FILE *fp = fopen("BDYlog.txt","a");
   fprintf(fp,"%s%c\n",x,y);
   fclose(fp);
}


void writetologX(char x[], char y[])
{
    FILE *fp = fopen("BDYlog.txt","a");
    fprintf(fp,"%s%s\n",x,y);
    fclose(fp);
}

void writetoACS(char x[], char y[])
{
    FILE *fp = fopen("ACSlog.txt","a");
    fprintf(fp,"%s%s\n",x,y);
    fclose(fp);
}

void writetoDEL(char x[], char y[])
{
    FILE *fp = fopen("DELlog.txt","a");
    fprintf(fp,"%s%s\n",x,y);
    fclose(fp);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{
   char *pFileSrc;          

   /** Initialize  Fields  **/
   cEndOfData = NO_CHAR;
   RS.cErrorInd = NO_CHAR;
   RS.cFirstReadInd = YES_CHAR;
   RS.nTotHdrCnt = 0;
   RS.EPBF010_nRcdRead = 0;
   RS.EPBF020_nRcdWrit = 0;

  writetologX(RS.sHdrId,"DPM_1000");
  writetolog("error ind = ", RS.cErrorInd);

  /*** Get the file source from the script ***/
   pFileSrc = (char *) getenv("FILE");
   strcpy(RS.sFileSrc, pFileSrc);
   sprintf(sFileMsg, "Input File: EPBF010, Source: %3s", RS.sFileSrc);

  writetologX(RS.sHdrId,"Thread  ");

 /**** Build thread table  *****/

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

  writetologX(RS.sHdrId,"Open File");

   /**** open the input HR Interface file     ***/
   RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_READ);
   if (RS.EPBF010 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sFileMsg);
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   RS.cErrorInd = NO_CHAR;
   writetolog(RS.sHdrId,RS.cErrorInd);
   writetologX(RS.sHdrId,"Open OUT ");

   /**** open the output Balanced HR file     ***/
   RS.EPBF020 = BCH_Open("EPBF020", BCH_FILE_WRITE);
   if (RS.EPBF020 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF020");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
       writetoACS("EPBF030","Unable to process Buddy Interface File");
       writetoDEL("EPBF040","Unable to process Buddy Interface File");
   }

   writetolog(RS.sHdrId,RS.cErrorInd);
   writetologX(RS.sHdrId,"Read File");

   /**** after opening file, read the first interface record ***/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   if (BCH_eof(RS.EPBF010))
   {
       RS.cErrorInd = YES_CHAR;
       cEndOfData = YES_CHAR;
       BCH_FormatMessage(1,TXT_EMPTY_INPUT_FILE);
       BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sFileMsg);
       BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_1000_Initialize");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{
  writetologX(RS.sHdrId,"DPM_2000");
 /**** Process interface records    ****/
 while (cEndOfData == NO_CHAR)
 {
   DPM_2500_ProcessInterfaceRecords();

  /****  read the next  interface record ***/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   if (BCH_eof(RS.EPBF010))
      cEndOfData = YES_CHAR;
 }  

   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   if (RS.cErrorInd == NO_CHAR)
      exit(0);
   else
      exit(5);

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessInterfaceRecords             **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessInterfaceRecords()
{
   writetologX(RS.sHdrId,"DPM_2500");

   /*** If this is the first read, the first record should be a header, otherwise  ***/
   /*** the file will automatically be out of balance                              ***/
   strncpy(RS.sHdrId, (char *)RS.EPBF010_buffer, 3);
   if (RS.cFirstReadInd == YES_CHAR)
   {
      if (strcmp(RS.sHdrId, "HDR") != 0)
        {
            RS.cErrorInd = YES_CHAR;
            BCH_FormatMessage(1,TXT_HDR_REC_NOT_FOUND);
            BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sFileMsg);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2500_ProcessInterfaceRecords");
         }
      RS.cFirstReadInd = NO_CHAR;
   }

   writetologX(RS.sHdrId,"FristTm");
   writetolog(RS.sHdrId,RS.cErrorInd);


   /*** If this is a header, save the header information for balancing later.  The ER header ***/
   /*** file can have multiple headers, so add the hdr count to an accumulater               ***/
   if (strcmp(RS.sHdrId, "HDR") == 0)
   {
      strncpy(RS.sHdrDt, (char *)RS.EPBF010_buffer+3, 8);
      strncpy(RS.sHdrTm, (char *)RS.EPBF010_buffer+11, 8);
      strncpy(RS.sHdrCnt, (char *)RS.EPBF010_buffer+19, 7);
      RS.nTotHdrCnt += atoi(RS.sHdrCnt);
   }
   /*** if not a header, and no errors occurred, write out to balanced output file ***/

   writetolog(RS.sHdrId,RS.cErrorInd);

   if (strcmp(RS.sHdrId, "HDR") != 0 && RS.cErrorInd == NO_CHAR)
   {
      BCH_WriteRec(RS.EPBF020, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
      RS.EPBF020_nRcdWrit++;

      RS.EPBF010_nRcdRead++;
      DPM_4920_ProcessLUW();
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_4920_ProcessLUW()
{
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{

   BCH_Close(RS.EPBF010);
   BCH_Close(RS.EPBF020);
 
   /*** if records counted not == records on header, write message to log ***/
   if (RS.nTotHdrCnt != RS.EPBF010_nRcdRead)
   {
      RS.cErrorInd = YES_CHAR;
      BCH_FormatMessage(1,TXT_UNEQUAL_RECORD_COUNTS);            
      sprintf(sErrorMessage, "%2s Hdr rec Cnt = %7d, Records read = %7d",
                              RS.sFileSrc, RS.nTotHdrCnt, RS.EPBF010_nRcdRead);
      BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);            
      BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_9500_ProcessEndOfProgram");
      writetoACS("EPBF030",sErrorMessage);
      writetoDEL("EPBF040",sErrorMessage);
   }

  /*** if there was a header record only with a count of zero, send a msg ***/
  /*** to the message log   ***/
   if (strcmp(RS.sHdrId, "HDR") == 0 && RS.nTotHdrCnt == 0 && RS.EPBF010_nRcdRead == 0)
   {
      RS.cErrorInd = YES_CHAR;
      sprintf(sErrorMessage, "Hdr only with record count = 0, no detail from source: %2s",
                              RS.sFileSrc);
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);            
      BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_9500_ProcessEndOfProgram");
      writetoACS("EPBF030",sErrorMessage);                                      
      writetoDEL("EPBF040",sErrorMessage);
   }

   if (RS.cErrorInd == NO_CHAR)
   {
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sFileMsg);
      BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF010_nRcdRead);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

      BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF020");
      BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF020_nRcdWrit);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
   }
}
