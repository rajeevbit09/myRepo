/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass System                                            **
**                                                                         **
** Program Name:    <EPB70001.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Faith Ammons                                           **
**                                                                         **
** Date Written:    10/17/95                                               **
**                                                                         **
** Description:     This module creates trips on the Imputed Trip Table    **
**                  from unmatched flight legs on the Imputed Flight Leg   **
**                  Table.  When a trip is formed, each flight leg is      **
**                  updated to show that a match has been made, and is     **
**                  given the same trip number as the imputed trip item.   **
**                  In addition, all charges that are associated with the  **
**                  trip are updated with the imputed trip number.         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** 2/20/96       FFA ---         -----    -----------                      **
** 2/20/96       FFA             143      Do not create 2 trip records for **
**                                        German employees - only 1 trip   **
**                                        record with the  origin and      **
**                                        furthest destination.            **
** 11/16/96      FFA                      When determining furthest miles **
**                                        if the 2 cities are the same,    **
**                                        set mileage to 0 and dont exe    **
**                                        service 02576.                   **
**                                                                         **
** 05/20/98      LAS                      Service FYS02775 updated to      **
**                                        exclude German employees from    **
**                                        imputed processing.              **
**                                                                         **
** 03/27/01      L.Scott                  When processing unmatched flight **
**                                        legs into trips, instead of      **
**                                        marking both as 'Matched', go    **
**                                        ahead and mark as 'Approved'.    **
**                                                                         **
** 05/10/07      L.Scott                  Every trip record when created   **
**                                        will now only match one flight   **
**                                        leg.  These changes were done to **
**                                        allow for domestic partner       **
**                                        travel but were expanded to      **
**                                        include all imputed travel.      **
**                                                                         **
****************************************************************************/


#include "epb70001.h"


main()
{
   BCH_Init("EPB70001", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{

 /**** Initialize fields ****/
   cEndOfFltLegData = NO_CHAR;
   memset(fltleg_data, LOW_VALUES, sizeof(fltleg_data));

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2000_Mainline()
{
   short nSvcRtnCd;
   nNbrOfLegs = 0;

      /****** Initialize Request and Answer Blocks for service to retrieve 1st imputed
       ****** flight leg row that has not been matched             *****/
      memset(&R02775.R02775_appl_area,LOW_VALUES, sizeof(R02775.R02775_appl_area));
      memset(&A02775,LOW_VALUES,sizeof(A02775));
      R02775.R02775_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02775,&A02775,SERVICE_ID_02775,1,sizeof(R02775.R02775_appl_area));

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            DPM_4100_GetPprInfo();
            strcpy(sOldPprNbr, A02775.A02775_appl_area.sPprNbr);
            strcpy(sOldNrevNbr, A02775.A02775_appl_area.sNrevNbr);
            break;

         case ARC_ROW_NOT_FOUND: 
            cEndOfFltLegData = YES_CHAR;
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02775");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
         }  

   /**** Process imputed flight leg items      ****/
   while (cEndOfFltLegData == NO_CHAR)       
      DPM_2100_ProcessRows();

   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2100_ProcessRows                         **
**                                                               **
** Description:     Process Imputed Flight Leg Table until end   **
**                  of rows.                                     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2100_ProcessRows()
{
   short     nSvcRtnCd;      /* Service return code */

   /*** If PPR number or Non-rev number changes, go process this imputed group   ***/
   if (strcmp(A02775.A02775_appl_area.sPprNbr, sOldPprNbr) != 0       ||
       strcmp(A02775.A02775_appl_area.sNrevNbr, sOldNrevNbr) != 0)   
   {
      DPM_2200_ProcessImputedGroup();                      
   
      /*** if PPR number changed, go get new PPR information   ***/
      if (strcmp(A02775.A02775_appl_area.sPprNbr, sOldPprNbr) != 0)
         DPM_4100_GetPprInfo();

      strcpy(sOldPprNbr, A02775.A02775_appl_area.sPprNbr);
      strcpy(sOldNrevNbr, A02775.A02775_appl_area.sNrevNbr);
      memset(fltleg_data, LOW_VALUES, sizeof(fltleg_data));
      nNbrOfLegs = 0;
   }

   /*** Next, go get the airport information about the origin and destination for this flight leg ***/
   DPM_4200_GetRelatedInfo();

   /*** Save each imputed flight leg for a ppr/nrev in array ***/
   strcpy(fltleg_data[nNbrOfLegs].sDprtDt, A02775.A02775_appl_area.sFltDprtDt);     
   strcpy(fltleg_data[nNbrOfLegs].sArrvDt, A02775.A02775_appl_area.sFltArrDt);
   fltleg_data[nNbrOfLegs].nDprtTm = A02775.A02775_appl_area.nFltDprtTm;
   fltleg_data[nNbrOfLegs].nNbrOfDays = A02775.A02775_appl_area.nPassAnsRowsNbr;
   strcpy(fltleg_data[nNbrOfLegs].sOrigCty, A02775.A02775_appl_area.sFltOrigCtyId);
   strcpy(fltleg_data[nNbrOfLegs].sDestCty, A02775.A02775_appl_area.sFltDestCtyId);
   strcpy(fltleg_data[nNbrOfLegs].sFltNbr, A02775.A02775_appl_area.sFltNbr);
   strcpy(fltleg_data[nNbrOfLegs].sTktNbr, A02775.A02775_appl_area.sTktNbr);
   fltleg_data[nNbrOfLegs].lRfrnDt = A02775.A02775_appl_area.lFltChrgRfrnDt;
   fltleg_data[nNbrOfLegs].lMilesFlown = A02576.A02576_appl_area.lFltArptPrNbr;
   nNbrOfLegs++;

   /*** after processing this row, increment the leg counter  and then get the next row ***/
   RS.nImpFltLegCnt++;                       

   R02775.R02775_appl_area.cArchCursorOpTxt = FETCH_ROW;
   memset(&A02775,LOW_VALUES,sizeof(A02775));

   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02775,&A02775,SERVICE_ID_02775,1,sizeof(R02775.R02775_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         cEndOfFltLegData = YES_CHAR;
         DPM_2200_ProcessImputedGroup();
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02775");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2100_ProcessRows");
       }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2200_ProcessImputedGroup                 **
**                                                               **
** Description:     This function begins the process to form     **
**                  imputed trips from the array of flight legs. **
**                  If a trip is formed, the flight legs are     **
**                  then updated with the trip number from the   **
**                  imputed trip table.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2200_ProcessImputedGroup()
{
   short nSvcRtnCd;

   cGermanInd = NO_CHAR;
   cUpdateAllInd = NO_CHAR;
   i = 1;
   nSaveTripNbr = 1;
   fltleg_data[0].nTempTripNbr = 1;   /* trip number of first leg = 1 */

   /*** First, go thru flight leg items and try to group the legs together into logical trips ***/
   while (i < nNbrOfLegs)
   {
      /*** determine if the origin of this leg is the same as the destination of  ***/
      /*** the previous leg.  If not the same, this is a new trip.                ***/
      strcpy(sCity1, fltleg_data[i].sOrigCty);
      strcpy(sCity2, fltleg_data[i-1].sDestCty);

    /*********  No longer needed because of Domestic Partner processing (LScott 5/10/07) *****
      DPM_4300_CompareCity();
      if (cSameCityInd == NO_CHAR)
    ********* The above was commented for for DP process  *****/

         nSaveTripNbr++;

 /*********  No longer needed because of Domestic Partner processing (LScott 5/10/07) *****
      *** if the last leg in this array, set the temporary trip number if not already set  ***
      if ((cSameCityInd == YES_CHAR) && (i == nNbrOfLegs-1) && (fltleg_data[i].nTempTripNbr == LOW_VALUES))
      {
         *** if there was more than 1 leg and orig of curren and prev leg not a hub, start another trip ***
         if ((nNbrOfLegs != 1) && (fltleg_data[i].cOrigHubInd == NO_CHAR) && (fltleg_data[i-1].cOrigHubInd == NO_CHAR))
            nSaveTripNbr++;
         ***  if neither the origin or destination is a hub, start another trip ***
         else if ((fltleg_data[i].cOrigHubInd == NO_CHAR) && (fltleg_data[i].cDestHubInd == NO_CHAR))
            nSaveTripNbr++;
      }

      ***  if not the last leg and neither the origin or destination is a hub, start another trip ***
      if ((cSameCityInd == YES_CHAR) && (i != nNbrOfLegs-1) && (fltleg_data[i].cOrigHubInd == NO_CHAR) 
                            && (fltleg_data[i].cDestHubInd == NO_CHAR))
         nSaveTripNbr++;

  ********* The above was commented for for DP process  *****/

      fltleg_data[i].nTempTripNbr = nSaveTripNbr;
      i++;
   }

   /*** next, create the actual trips ***/
   /***
   if (strcmp(A02776.A02776_appl_area.sPprInttxNbr, NULL_STRING) == 0)
   ***/

      DPM_2300_CreateNonGermanTrips();
   /***
   else
   {
      cGermanInd = YES_CHAR;
      DPM_2400_CreateGermanTrips();
   }
   **/

   /*** next, if trips were created, update the imputed flight legs and the associated   ***/
   /*** charges with the trip number                                                     ***/
   i = 0;
   while (i < nNbrOfLegs)
   {
 
      if (fltleg_data[i].nActlTripNbr != LOW_VALUES)
      {
         /*** Initialize Request and answer block to update the flight leg table ***/
         memset(&R02435.R02435_appl_area,LOW_VALUES, sizeof(R02435.R02435_appl_area));
         memset(&A02435,LOW_VALUES,sizeof(A02435));                                  
         strcpy(R02435.R02435_appl_area.sPprNbr, sOldPprNbr); 
         strcpy(R02435.R02435_appl_area.sNrevNbr, sOldNrevNbr); 
         strcpy(R02435.R02435_appl_area.sFltNbr, fltleg_data[i].sFltNbr); 
         strcpy(R02435.R02435_appl_area.sTktNbr, fltleg_data[i].sTktNbr); 
         strcpy(R02435.R02435_appl_area.sFltDprtDt, fltleg_data[i].sDprtDt); 
         strcpy(R02435.R02435_appl_area.sFltOrigCtyId,  fltleg_data[i].sOrigCty);
         R02435.R02435_appl_area.cFltMatchInd = APPROVED;
         R02435.R02435_appl_area.lPassTripNbr = fltleg_data[i].nActlTripNbr;

         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02435,&A02435,SERVICE_ID_02435,1,sizeof(R02435.R02435_appl_area));

         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS02435");
               BCH_FormatMessage(3,TXT_FLT_LEG_UPDATE_ERR, R02435.R02435_appl_area.sPprNbr,
                                                           R02435.R02435_appl_area.sNrevNbr,
                                                           R02435.R02435_appl_area.sFltDprtDt,
                                                           R02435.R02435_appl_area.sFltOrigCtyId);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessImputedGroup");
         }  

         /*** Initialize Request and answer block to update the charges table ***/
         memset(&R04084.R04084_appl_area,LOW_VALUES, sizeof(R04084.R04084_appl_area));
         memset(&A04084,LOW_VALUES,sizeof(A04084));                                  
         strcpy(R04084.R04084_appl_area.sPprNbr, sOldPprNbr); 
         strcpy(R04084.R04084_appl_area.sNrevNbr, sOldNrevNbr); 
         R04084.R04084_appl_area.lFltChrgRfrnDt = fltleg_data[i].lRfrnDt;          
         R04084.R04084_appl_area.lPassTripNbr = fltleg_data[i].nActlTripNbr;

         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04084,&A04084,SERVICE_ID_04084,1,sizeof(R04084.R04084_appl_area));

         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS04084");
               sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, lRfrnDt = %d, lTripNbr = %d",
                                                           R04084.R04084_appl_area.sPprNbr,
                                                           R04084.R04084_appl_area.sNrevNbr,
                                                           R04084.R04084_appl_area.lFltChrgRfrnDt,
                                                           R04084.R04084_appl_area.lPassTripNbr);
               BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessImputedGroup");
         }  
      }
      i++;
   }

   /*** Finally, commit all the changes made   ***/
   DPM_4920_ProcessLUW();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2300_CreateNonGermanTrips                **
**                                                               **
** Description:     This function creates trips for non-german's **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2300_CreateNonGermanTrips()
{
   int   j = 0;

   /*** first, check to see if orig of 1st leg = dest of last leg - an entire round trip ***/
   strcpy(sCity1, fltleg_data[0].sOrigCty);
   strcpy(sCity2, fltleg_data[nNbrOfLegs-1].sDestCty);
   DPM_4300_CompareCity();

   /*** if the origin of the first leg = the destination of the last leg, then an entire trip ***/
   /*** has been completed, and the trip records can now be created.                          ***/
   if (cSameCityInd == YES_CHAR) 
   {
      i = 0;
      nTripCnt = 1;

      /*** create multiple trip records if side trips were taken   ***/
      if (nSaveTripNbr > 1)
      {
         DPM_2310_ProcessEachTrip();
      }

      /*** otherwise, create 1 trip record                         ***/
      else
      {
         strcpy(sTripOrig, fltleg_data[0].sOrigCty);
         strcpy(sTripDprtDt, fltleg_data[0].sDprtDt);
         DPM_2320_GetDestination();
         
         /*** after determining the destination, go create a trip record for the first   ***/
         /*** part of the round trip and then update the array with the actual trip nbr  ***/
         DPM_4400_CreateTripRecord();
         nFuncTripNbr = 1;
         DPM_4500_UpdateArray();

         /*** next, create a trip record for the 2nd part of the round trip and then ***/
         /*** update the array with the 2nd actual trip number                       ***/
         strcpy(sTripOrig, fltleg_data[nArrayItem+1].sOrigCty);
         strcpy(sTripDest, fltleg_data[nNbrOfLegs-1].sDestCty);
         strcpy(sTripDprtDt, fltleg_data[nArrayItem+1].sDprtDt);
         strcpy(sTripArrvDt, fltleg_data[nNbrOfLegs-1].sArrvDt);
         DPM_4400_CreateTripRecord();
         nFuncTripNbr = 2;
         DPM_4500_UpdateArray();
      }
   }
   /*** if the origin of the first leg does not = the destination of the 2nd leg, check the age ***/
   /*** of the legs to determine if they are 60 days old, and if so, form trips anyway          ***/
   else
   {
      i = 0;
      nTripCnt = 1;
      while (i < nNbrOfLegs) 
      {
         /*** get the origin and destination of each possible trip and determine if it is 60 days or older ***/
         strcpy(sTripOrig, fltleg_data[i].sOrigCty);
         strcpy(sTripDprtDt, fltleg_data[i].sDprtDt);
         j = i;    /*  save location of first leg of each trip   */
         while ((i < nNbrOfLegs) && (fltleg_data[i].nTempTripNbr == nTripCnt))
            i++; 
         i--;  /* get the last leg with the same tem trip nbr */

         /*** create a trip if the frst leg is ge 60 days  ***/
         /**   if (fltleg_data[j].nNbrOfDays >= 60)   **/

         /*** create a trip if the first leg is age 0 days  ***/
         if (fltleg_data[j].nNbrOfDays >= 0)
         {
            strcpy(sTripDest, fltleg_data[i].sDestCty);
            strcpy(sTripArrvDt, fltleg_data[i].sArrvDt);
            DPM_4400_CreateTripRecord();
            nFuncTripNbr = nTripCnt;
            DPM_4500_UpdateArray();
         }
         nTripCnt++;
         i++;
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2310_ProcessEachTrip                     **
**                                                               **
** Description:     This function gathers each group of trips to **
**                  create an imputed trip record.               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2310_ProcessEachTrip()
{

   while (i < nNbrOfLegs)
   {
       strcpy(sTripOrig, fltleg_data[i].sOrigCty);
       strcpy(sTripDprtDt, fltleg_data[i].sDprtDt);
       /*** go thru array until the last leg of the trip is found   ***/
       while (i < nNbrOfLegs && fltleg_data[i].nTempTripNbr == nTripCnt)
         i++;
       /*** after finding the last leg, save the dest infor ***/
       strcpy(sTripDest, fltleg_data[i-1].sDestCty);
       strcpy(sTripArrvDt, fltleg_data[i-1].sArrvDt);

       DPM_4400_CreateTripRecord();  /** create a trip record for this imputed trip */

       nFuncTripNbr = nTripCnt;
       DPM_4500_UpdateArray();   /** update the array with the actual imputed trip nbr ***/

       nTripCnt++;
   }
} 

/******************************************************************
**                                                               **
** Function Name:   DPM_2320_GetDestination                      **
**                                                               **
** Description:     This function determines the destination for **
**                  one round trip with no side trips            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2320_GetDestination()
{
   char cHubInd = YES_CHAR;
   int   j = 0;
 
   nArrayItem = 0;
   /*** if there are only 2 legs, or the dest of the 1st leg is not a hub  ***/
   /*** then this dest will be the dest of the trip                        ***/
   if ((nNbrOfLegs == 2) || (fltleg_data[0].cDestHubInd == NO_CHAR))
   {
      strcpy(sTripDest, fltleg_data[0].sDestCty);
      strcpy(sTripArrvDt, fltleg_data[0].sArrvDt);
   }
   else      /*** otherwise, the first non-hub destination will be the dest of the trip   ***/
   {
      while ((j < nNbrOfLegs) && (cHubInd == YES_CHAR))
      {
         if(fltleg_data[j].cDestHubInd == NO_CHAR)
         {
            cHubInd = NO_CHAR;
            continue;
         }
         j++;
      }
      if ((cHubInd == NO_CHAR) && (j < nNbrOfLegs-1))   /*** a non-hub dest was found   ***/
      {
         strcpy(sTripDest, fltleg_data[j].sDestCty);
         strcpy(sTripArrvDt, fltleg_data[j].sArrvDt);
         nArrayItem = j;
      }
      /*** all of the destinations were hubs, therefore, use the one that is farthest from the origin  ***/
      else    
      {
         DPM_4600_GetFurthestMiles();
         strcpy(sTripDest, fltleg_data[nFurthestItem].sDestCty);
         strcpy(sTripArrvDt, fltleg_data[nFurthestItem].sArrvDt);
         nArrayItem = nFurthestItem;
      }  
   }

   /*** after determining the destination city, update the temporary trip number with a 2 to indicate ***/
   /*** the return trip   ***/
   j = nArrayItem + 1;
   while (j < nNbrOfLegs)
   {
      fltleg_data[j].nTempTripNbr = 2;
      j++;
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2400_CreateGermanTrips                   **
**                                                               **
** Description:     This function creates trips for german PPR's **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2400_CreateGermanTrips()
{
   int   j = 0;
   short     nSvcRtnCd;      /* Service return code */

   strcpy(sCity1, fltleg_data[0].sOrigCty);
   strcpy(sCity2, fltleg_data[nNbrOfLegs-1].sDestCty);
   DPM_4300_CompareCity();

   /*** if the origin of the first leg = the destination of the last leg, then an entire trip ***/
   /*** has been completed, and the trip record can now be created.                           ***/
   if (cSameCityInd == YES_CHAR) 
   {
      i = 0;
      nTripCnt = 1;
      strcpy(sTripOrig, fltleg_data[0].sOrigCty);
      strcpy(sTripDprtDt, fltleg_data[0].sDprtDt);
         
      DPM_4600_GetFurthestMiles();
      strcpy(sTripDest, fltleg_data[nFurthestItem].sDestCty);
      strcpy(sTripArrvDt, fltleg_data[nFurthestItem].sArrvDt);
      nArrayItem = nFurthestItem;

      /*** after determining the destination city, update the temporary trip number ***/
      /***  with a 1                                                                      ***/
      j = 0;
      while (j < nNbrOfLegs)   /** this was j < nArrayItem+1 for 2 trip processing ***/
      {
         fltleg_data[j].nTempTripNbr = 1;
         j++;
      }
      /***************************************************************************************************
      *** the following logic was commented out to prevent 2nd trip record from being created  - sir 134***
      ***j = nArrayItem + 1;
      ***while (j < nNbrOfLegs)
      ***{
      ***   fltleg_data[j].nTempTripNbr = 2;
      ***   j++;
      ***}
      ***************************************************************************************************/
         
      /*** after determining the destination, go create a trip record for the first   ***/
      /*** part of the round trip and then update the array with the actual trip nbr  ***/
      DPM_4400_CreateTripRecord();
      nFuncTripNbr = 1;
      DPM_4500_UpdateArray();

      /****************************************************************************************************
       *** the following logic was commented out to prevent 2nd trip record from being created  - sir 134***
       *** next, create a trip record for the 2nd part of the round trip and then *** 
       *** update the array with the 2nd actual trip number                       *** 
      ***strcpy(sTripOrig, fltleg_data[nArrayItem+1].sOrigCty);
      ***strcpy(sTripDest, fltleg_data[nNbrOfLegs-1].sDestCty);
      ***strcpy(sTripDprtDt, fltleg_data[nArrayItem+1].sDprtDt);
      ***strcpy(sTripArrvDt, fltleg_data[nNbrOfLegs-1].sArrvDt);
      ***DPM_4400_CreateTripRecord();
      ***nFuncTripNbr = 2;
      ***DPM_4500_UpdateArray();
      ****************************************************************************************************/
   }
   /*** if the origin of the first leg does not = the destination of the 2nd leg, check the age ***/
   /*** of the legs to determine if they are 60 days old, and if so, form trips anyway          ***/
   else
   {
      strcpy(sTripOrig, fltleg_data[0].sOrigCty);
      strcpy(sTripDprtDt, fltleg_data[0].sDprtDt);
   /****   if (fltleg_data[0].nNbrOfDays >= 60) ****/
      if (fltleg_data[0].nNbrOfDays >= 0)
      {
         strcpy(sTripDest, fltleg_data[nNbrOfLegs-1].sDestCty);
         strcpy(sTripArrvDt, fltleg_data[nNbrOfLegs-1].sArrvDt);
         DPM_4400_CreateTripRecord();
         nFuncTripNbr = 1;
         cUpdateAllInd = YES_CHAR;
         DPM_4500_UpdateArray();
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4100_GetPprInfo                          **
**                                                               **
** Description:     This function gets the pass group and        **
** intertax number from the PPR Table.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4100_GetPprInfo()
{
   short     nSvcRtnCd;      /* Service return code */
 
   /*** Initialize Request and answer block to get PPR information               ***/
   memset(&R02776.R02776_appl_area,LOW_VALUES, sizeof(R02776.R02776_appl_area));
   memset(&A02776,LOW_VALUES,sizeof(A02776));                                  
   strcpy(R02776.R02776_appl_area.sPprNbr, A02775.A02775_appl_area.sPprNbr);

   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02776,&A02776,SERVICE_ID_02776,1,sizeof(R02776.R02776_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
          // Strip any trailing space, so an empty tax Number is NULL
          UTL_StripTrailingSpaces(A02776.A02776_appl_area.sPprInttxNbr);
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02776");
         BCH_FormatMessage(3,TXT_PPR, R02776.R02776_appl_area.sPprNbr);       
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4100_GetPprInfo");
      }  
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4200_GetRelatedInfo                      **
**                                                               **
** Description:     This function gathers all of the related     **
** information needed to form imputed trips, by getting          **
** information from the Airport Pair Table and the Airport Codes **
** Table.                                                        **              
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4200_GetRelatedInfo()
{
   short     nSvcRtnCd;      /* Service return code */
 
   /*** First, get the airport pair  mileage from the Airport Pair Table          ***/
   memset(&R02576.R02576_appl_area,LOW_VALUES, sizeof(R02576.R02576_appl_area)); /* initialize request   */
   memset(&A02576,LOW_VALUES,sizeof(A02576));                                    /* and Answer block     */
   strcpy(R02576.R02576_appl_area.sFltOrigCtyId, A02775.A02775_appl_area.sFltOrigCtyId);
   strcpy(R02576.R02576_appl_area.sFltDestCtyId, A02775.A02775_appl_area.sFltDestCtyId);

   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02576,&A02576,SERVICE_ID_02576,1,sizeof(R02576.R02576_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02576");
         BCH_FormatMessage(3,TXT_ARPT_PR_RETRIEVE_ERR, R02576.R02576_appl_area.sFltOrigCtyId,
                                                       R02576.R02576_appl_area.sFltDestCtyId);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4200_GetRelatedInfo");
      }  

   /*** Next, get the Origin International indicator and region code from the Airport Code Table  ***/
   memset(&R02554.R02554_appl_area,LOW_VALUES, sizeof(R02554.R02554_appl_area)); /* initialize request   */
   memset(&A02554,LOW_VALUES,sizeof(A02554));                                    /* and Answer block     */
   strcpy(R02554.R02554_appl_area.sFltArptCd, A02775.A02775_appl_area.sFltOrigCtyId);

   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02554,&A02554,SERVICE_ID_02554,1,sizeof(R02554.R02554_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         strcpy(fltleg_data[nNbrOfLegs].sOrigReg, A02554.A02554_appl_area.sFltRgnCd);
         fltleg_data[nNbrOfLegs].cOrigIntlInd =  A02554.A02554_appl_area.cFltIntlInd;
         fltleg_data[nNbrOfLegs].cOrigHubInd =  A02554.A02554_appl_area.cFltHubInd;
         break;
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02554");
         BCH_FormatMessage(3,TXT_ARPT_CD_RETRIEVE_ERR, R02554.R02554_appl_area.sFltArptCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4200_GetRelatedInfo");
      }  

   /*** Finally, get the Destination International indicator and region code from the Airport Code Table  ***/
   memset(&R02554.R02554_appl_area,LOW_VALUES, sizeof(R02554.R02554_appl_area)); /* initialize request   */
   memset(&A02554,LOW_VALUES,sizeof(A02554));                                    /* and Answer block     */
   strcpy(R02554.R02554_appl_area.sFltArptCd, A02775.A02775_appl_area.sFltDestCtyId);

   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02554,&A02554,SERVICE_ID_02554,1,sizeof(R02554.R02554_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         strcpy(fltleg_data[nNbrOfLegs].sDestReg, A02554.A02554_appl_area.sFltRgnCd);
         fltleg_data[nNbrOfLegs].cDestIntlInd =  A02554.A02554_appl_area.cFltIntlInd;
         fltleg_data[nNbrOfLegs].cDestHubInd =  A02554.A02554_appl_area.cFltHubInd;
         break;
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02554");
         BCH_FormatMessage(3,TXT_ARPT_CD_RETRIEVE_ERR, R02554.R02554_appl_area.sFltArptCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4200_GetRelatedInfo");
      }  
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4300_CompareCity                         **
**                                                               **
** Description:     This function determines if 2 cities are the **
** same or if they are multi airport cities.                     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4300_CompareCity()
{
   cSameCityInd = NO_CHAR;

   if (strcmp(sCity1, sCity2) == 0)
      cSameCityInd = YES_CHAR;

   /*** multi airport cities are also considered the same city   ***/
   if ((strcmp(sCity1, "DCA") == 0 || strcmp(sCity1, "IAD") == 0)   &&
       (strcmp(sCity2, "DCA") == 0 || strcmp(sCity2, "IAD") == 0))
      cSameCityInd = YES_CHAR;

   if ((strcmp(sCity1, "HOU") == 0 || strcmp(sCity1, "IAH") == 0)   &&
       (strcmp(sCity2, "HOU") == 0 || strcmp(sCity2, "IAH") == 0))
      cSameCityInd = YES_CHAR;

   if ((strcmp(sCity1, "JFK") == 0 || strcmp(sCity1, "LGA") == 0 || strcmp(sCity1, "EWR") == 0)   &&
       (strcmp(sCity2, "JFK") == 0 || strcmp(sCity2, "LGA") == 0 || strcmp(sCity2, "EWR") == 0))   
      cSameCityInd = YES_CHAR;

}
 
/******************************************************************
**                                                               **
** Function Name:   DPM_4400_CreateTripRecord                    **
**                                                               **
** Description:     This function inserts a row into the Imputed **
** Trip Table.                                                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4400_CreateTripRecord()
{
   short     nSvcRtnCd;      /* Service return code */
 
   /*** Initialize Request and answer block to Insert Imputed Trip               ***/
   memset(&R03893.R03893_appl_area,LOW_VALUES, sizeof(R03893.R03893_appl_area));
   memset(&A03893,LOW_VALUES,sizeof(A03893));                                  
   strcpy(R03893.R03893_appl_area.sPprNbr, sOldPprNbr);
   strcpy(R03893.R03893_appl_area.sNrevNbr, sOldNrevNbr);
   strcpy(R03893.R03893_appl_area.sFltTripOrigId, sTripOrig);
   strcpy(R03893.R03893_appl_area.sFltTripDestId, sTripDest);
   strcpy(R03893.R03893_appl_area.sFltDprtDt, sTripDprtDt);
   strcpy(R03893.R03893_appl_area.sFltArrDt, sTripArrvDt);
   R03893.R03893_appl_area.fFltImptValAmt = 0.0;       
   R03893.R03893_appl_area.fFltImptWageAmt = 0.0;       
   R03893.R03893_appl_area.fNrevPmtAmt = 0.0;       
   R03893.R03893_appl_area.fCurrExchgRatNbr = 0.0;       
   strcpy(R03893.R03893_appl_area.sFltAcctEffDt, LOW_DATE);
   strcpy(R03893.R03893_appl_area.sFltRptNotfDt, LOW_DATE);
   R03893.R03893_appl_area.cFltMatchInd = APPROVED;
   R03893.R03893_appl_area.cFltRptInd = NO_CHAR;

   nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R03893,&A03893,SERVICE_ID_03893,1,sizeof(R03893.R03893_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS03893");
         sprintf(sErrorMessage, "Imp Trp Tbl insert: %s %s %s %s %s",
                                R03893.R03893_appl_area.sPprNbr,
                                R03893.R03893_appl_area.sNrevNbr,
                                R03893.R03893_appl_area.sFltDprtDt,
                                R03893.R03893_appl_area.sFltTripOrigId,
                                R03893.R03893_appl_area.sFltTripDestId);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);       
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4400_CreateTripRecord");
      }  
}
 
/******************************************************************
**                                                               **
** Function Name:   DPM_4500_UpdateArray                         **
**                                                               **
** Description:     This function updates each item in the flight**
** leg array with the actual imputed trip number.                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4500_UpdateArray()
{
   int   j = 0;
 
   while (j < nNbrOfLegs)
   {
      /*** only update items with the same trip number ***/
      if ((fltleg_data[j].nTempTripNbr == nFuncTripNbr) || (cUpdateAllInd == YES_CHAR)) 
         fltleg_data[j].nActlTripNbr = A03893.A03893_appl_area.lPassTripNbr;
      j++;
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4600_GetFurthestMiles                    **
**                                                               **
** Description:     This function gets the destination that is   **
** furthest from the origin city.                                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4600_GetFurthestMiles()
{
   short     nSvcRtnCd;      /* Service return code */
   short     j = 1;
   double    lFurthestMiles;
   double    lMileage;

   lFurthestMiles = fltleg_data[0].lMilesFlown;
   lMileage = 0;
   nFurthestItem = 0;
   while (j < nNbrOfLegs-1)
   {
      /*** Initialize request and answer blocks for the Airport Pair Table          ***/
      memset(&R02576.R02576_appl_area,LOW_VALUES, sizeof(R02576.R02576_appl_area));
      memset(&A02576,LOW_VALUES,sizeof(A02576));                                  
      strcpy(R02576.R02576_appl_area.sFltOrigCtyId, fltleg_data[0].sOrigCty);
      strcpy(R02576.R02576_appl_area.sFltDestCtyId, fltleg_data[j].sDestCty);

      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02576,&A02576,SERVICE_ID_02576,1,sizeof(R02576.R02576_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            lMileage = A02576.A02576_appl_area.lFltArptPrNbr;
            break;
         case ARC_ROW_NOT_FOUND:
            lMileage = 0;
            break;
         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02576");
            BCH_FormatMessage(3,TXT_ARPT_PR_RETRIEVE_ERR, R02576.R02576_appl_area.sFltOrigCtyId,
                                                       R02576.R02576_appl_area.sFltDestCtyId);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4600_GetFurthestMiles");
      }
      if (lMileage > lFurthestMiles)
      {
         lFurthestMiles = lMileage;
         nFurthestItem = j;
      }
         
      j++;
   }  
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_4920_ProcessLUW()
{
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{

   BCH_FormatMessage(1,TXT_INPUT_FILE, "t_imput_flt_leg");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.nImpFltLegCnt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

}
