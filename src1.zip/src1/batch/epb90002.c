/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB90002.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Written:    May 11, 1995                                           **
**                                                                         **
** Description:     Database driven programs use, as their primary input,  **
**                  a Sybase database.  The database is scanned and        **
**                  updated and/or transactions are generated for          **
**                  subsequent processing steps. This program reads from   **
**                  the Pass System and extracts information on frequent   **
**                  emergency pass usage when more than four emergency     **
**                  legs have been flown by a non-revenue passenger in     **
**                  in six months.  It will write the report records for   **
**                  the Emergency Pass Usage Report.                       **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 11/07/96   G.Swafford                  Re-work to make sql more efficent**
**                                        to prevent job from timing out.  **
**                                        Also, include nrev typ code to   **
**                                        report data, as well as, reorder-**
**                                        ing sort data.                   **
**                                         NOTED: GJS 11-07-96             **
**                                                                         **
** 11/16/09   L.Scott                     Check for retiree pass groups,   **
**                                        if so then force dept "951" and  **
**                                        station "ATG" in address fields, **
**                                        so the report goes to Employee   **
**                                        Service Center.                  **
**                                                                         **
****************************************************************************/
#include "epb90002.h"

main()
{
   BCH_Init("EPB90002", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short   nRptIndex,                 /* Report index */
           nReqRptInd1 = FALSE;       /* Required report #1 indicator */

   char   *pDate1,                    /* Pointer to reporting beginning and end dates */
          *pDate2;                     


   /**** Initialize RSAM Save fields with space ****/
   /*                             GJS 11-07-96     */                         
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sNrevNbr, SPACE_CHAR);
   strcpy(RS.sFltFeeBegDt, SPACE_CHAR);
   strcpy(RS.sFltFeeEndDt, SPACE_CHAR);

   /**** Assign report ending date to variables ****/
   pDate1 = (char *) getenv("DATE1");
   strcpy(RS.sFltFeeBegDt, pDate1);
   pDate2 = (char *) getenv("DATE2");
   strcpy(RS.sFltFeeEndDt, pDate2);

   /**** Initialize flag for all rows processed ****/
   RS.nProcessedAllRows = FALSE;

   /**** Initialize architecture area of service answer and request blocks ****/
   memset(&A02770, LOW_VALUES, sizeof(_A02770));
   memset(&R02770, LOW_VALUES, sizeof(_R02770)); 

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */

   /****** Initialize Request and Answer Blocks *****/
   memset(&R02770.R02770_appl_area, LOW_VALUES, sizeof(_R02770_APPL_AREA));
   memset(&A02770.A02770_appl_area, LOW_VALUES, sizeof(_A02770_APPL_AREA));

   /****** Format R02770 keys for initial DB Read *****/
   /*                             GJS 11-07-96        */                         
   strcpy(R02770.R02770_appl_area.sPprNbr, SPACE_CHAR);
   strcpy(R02770.R02770_appl_area.sNrevNbr, SPACE_CHAR);
   strcpy(R02770.R02770_appl_area.sFltFeeBegDt, RS.sFltFeeBegDt);
   strcpy(R02770.R02770_appl_area.sFltFeeEndDt, RS.sFltFeeEndDt);

   /**** Open the DB cursor ****/
   R02770.R02770_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to retrieve driving rows (Emergency and Honor Roll Flight Leg
           and Imputed Flight Leg data) ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,
                                 &R02770,
                                 &A02770,
                                 SERVICE_ID_02770,
                                 1,
                                 sizeof(_R02770_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS2770");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  
 
   /**** Process driving database rows for Frequent Emergency Pass Usage Report ****/
   while ((nSvcRtnCd != ARC_ROW_NOT_FOUND) && (RS.nProcessedAllRows == FALSE))
   {
      DPM_2500_ProcessRows();

      R02770.R02770_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A02770, LOW_VALUES, sizeof(_A02770));

      /**** Execute service to obtain next DB row ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02770,&A02770,SERVICE_ID_02770,1,sizeof(_R02770_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            RS.nProcessedAllRows = TRUE;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS2770");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }


   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   /*** No program logic to process the selected database row ***/

   /*** A report extract record is not generated. ***/

   /*** To generate a report extract record, perform the function                ***/
   /*** at the appropriate place in the program!                                 ***/

   DPM_5010_Generate();                                          

}

/******************************************************************
**                                                               **
** Function Name:   DPM_5010_Generate                            **
**                                                               **
** Description:     Write report records for report              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_5010_Generate()
{
   short     nRptIndex;                 /* Index into the report control table */
   char      cRecEndLineTxt = '\n';
  
   /**** Initialize report sort and data copybooks ****/
   memset(&EPRF9002.F9002_RptDataStruct, LOW_VALUES, sizeof(_F9002_RPTDATASTRUCT));
   memset(&EPRS9002.S9002_RptDataStruct, LOW_VALUES, sizeof(_S9002_RPTDATASTRUCT));

   /**** Format report fields in sort and data layouts ****/
   /*      LAS 11-16-2009        */
  if ((strcmp(A02770.A02770_appl_area.sPassGrpCd, "CW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "DA") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "DB") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "DP") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "DS") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "DW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "EW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "FP") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "FU") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "FV") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "FW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "LW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "OA") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "OW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "PA") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "RE") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "RL") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "RR") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "RT") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "TM") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "TO") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "TW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "UW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "VA") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "VB") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "VC") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "VR") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "WE") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "WF") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "WR") == 0))
         {
         strcpy(EPRF9002.F9002_RptDataStruct.sPprStnId, "ATG");
         strcpy(EPRF9002.F9002_RptDataStruct.sPprDeptNbr, "951");
	 }
    else
	{
        strcpy(EPRF9002.F9002_RptDataStruct.sPprStnId, A02770.A02770_appl_area.sPprStnId);
        strcpy(EPRF9002.F9002_RptDataStruct.sPprDeptNbr, A02770.A02770_appl_area.sPprDeptNbr);
	}
   /*                             GJS 11-07-96            */                         
   strcpy(EPRF9002.F9002_RptDataStruct.sPprNbr, A02770.A02770_appl_area.sPprNbr);
   strcpy(EPRF9002.F9002_RptDataStruct.sNrevNbr, A02770.A02770_appl_area.sNrevNbr);
   strcpy(EPRF9002.F9002_RptDataStruct.sPprNm, A02770.A02770_appl_area.sPprNm);
   strcpy(EPRF9002.F9002_RptDataStruct.sNrevNm, A02770.A02770_appl_area.sNrevNm);
   strcpy(EPRF9002.F9002_RptDataStruct.sNrevTypCd, A02770.A02770_appl_area.sNrevTypCd);
   strcpy(EPRF9002.F9002_RptDataStruct.sPassTypCd, A02770.A02770_appl_area.sPassTypCd);
   strcpy(EPRF9002.F9002_RptDataStruct.sFltOrigCtyId, A02770.A02770_appl_area.sFltOrigCtyId);
   strcpy(EPRF9002.F9002_RptDataStruct.sFltDestCtyId, A02770.A02770_appl_area.sFltDestCtyId);
   strcpy(EPRF9002.F9002_RptDataStruct.sFltNbr, A02770.A02770_appl_area.sFltNbr);
   strcpy(EPRF9002.F9002_RptDataStruct.sFltDprtDt, 
          UTL_ConvertDate(A02770.A02770_appl_area.sFltDprtDt,CNV_DB_TO_DD_MMM_YYYY));
   strcpy(EPRF9002.F9002_RptDataStruct.sFltFeeBegDt, 
          UTL_ConvertDate(RS.sFltFeeBegDt,CNV_DB_TO_MM_DD_YY));
   strcpy(EPRF9002.F9002_RptDataStruct.sFltFeeEndDt, 
          UTL_ConvertDate(RS.sFltFeeEndDt,CNV_DB_TO_MM_DD_YY));
   EPRF9002.F9002_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   /*      LAS 11-16-2009        */
  if ((strcmp(A02770.A02770_appl_area.sPassGrpCd, "CW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "DA") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "DB") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "DP") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "DS") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "DW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "EW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "FP") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "FU") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "FV") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "FW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "LW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "OA") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "OW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "PA") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "RE") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "RL") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "RR") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "RT") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "TM") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "TO") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "TW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "UW") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "VA") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "VB") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "VC") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "VR") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "WE") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "WF") == 0) ||
      (strcmp(A02770.A02770_appl_area.sPassGrpCd, "WR") == 0))
         {
         strcpy(EPRS9002.S9002_RptDataStruct.sPprStnId, "ATG");
         strcpy(EPRS9002.S9002_RptDataStruct.sPprDeptNbr, "951");
	 }
    else
	 {
         strcpy(EPRS9002.S9002_RptDataStruct.sPprStnId, A02770.A02770_appl_area.sPprStnId);
         strcpy(EPRS9002.S9002_RptDataStruct.sPprDeptNbr, A02770.A02770_appl_area.sPprDeptNbr);
	 }
   /*                             GJS 11-07-96            */                         
   strcpy(EPRS9002.S9002_RptDataStruct.sPassTypCd, A02770.A02770_appl_area.sPassTypCd);
   strcpy(EPRS9002.S9002_RptDataStruct.sPprNm, A02770.A02770_appl_area.sPprNm);
   strcpy(EPRS9002.S9002_RptDataStruct.sPprNbr, A02770.A02770_appl_area.sPprNbr);
   strcpy(EPRS9002.S9002_RptDataStruct.sNrevNbr, A02770.A02770_appl_area.sNrevNbr);
   strcpy(EPRS9002.S9002_RptDataStruct.sPassRptSortDt, 
          UTL_ConvertDate(A02770.A02770_appl_area.sPassRptSortDt,CNV_DB_TO_YYYYMMDD));
   strcpy(EPRS9002.S9002_RptDataStruct.sFltNbr, A02770.A02770_appl_area.sFltNbr);
   strcpy(EPRS9002.S9002_RptDataStruct.sFltOrigCtyId, A02770.A02770_appl_area.sFltOrigCtyId);

   /**** Write report record ****/
   BCH_WriteRptRec("EPB90012",&EPRS9002, sizeof(EPRS9002), &EPRF9002, sizeof(EPRF9002));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   /** include any logic here for final clean-up processing  **/
   /** e.g. producing a final summary record  **/
   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
