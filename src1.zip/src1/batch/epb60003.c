/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    <EPB60003.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         <Andersen Consulting>                                  **
**                  <C.Eachus>                                             **
**                                                                         **
** Date Written:    5/1/95                                                 **
**                                                                         **
** Description:     Database driven programs use, as their primary input,  **
**                  a Sybase database.  The database is scanned and        **
**                  updated and/or transactions are generated for          **
**                  subsequent processing steps.  This module is           ** 
**                  responsible for retrieving the Imputed Trip table and  **
**                  searching the table for items older than 6 months.     ** 
**                  The program then moves these items to the Imputed Trip **
**                  History table.                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 8/15/96    G. Melton                   Changed to retrieve from the     **
**                                        Imputed Trip Table items older   **
**                                        than one year and move them to   **
**                                        the Imputed Trip History Table.  **
**                                        Also added a count of rows       **
**                                        archived and corresponding       **
**                                        message to log.                  **
** 12/23/2008 Gay Whitman                 change to 3 years history        **
**                                                                         **
****************************************************************************/


#include "epb60003.h"
#include "epbcmncd.h"

main()
{
   BCH_Init("EPB60003", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and builds **
**                  the thread tables.                           **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{
    /**** Set key to primary database to nulls/zero ****/
    RS.lPassTripNbr=0;


    /**** Initialize service request and answer copybooks ****/
    memset(&A02873, LOW_VALUES, sizeof(_A02873)); 
    memset(&R02873, LOW_VALUES, sizeof(_R02873)); 
    memset(&A04118, LOW_VALUES, sizeof(_A04118)); 
    memset(&R04118, LOW_VALUES, sizeof(_R04118)); 

    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

    memset(&RS.sTodayDt, LOW_VALUES,     sizeof(RS.sTodayDt));
    strncpy(RS.sTodayDt, sCurrentTsDt,   sizeof(RS.sTodayDt));
    UTL_ZeroDatesTime(RS.sTodayDt);

    /*** Calculate the date one year ago today ***/
    strcpy(R04118.R04118_appl_area.sPassRptSortDt, RS.sTodayDt);
    /************change parm for years to archive ************/
    R04118.R04118_appl_area.nFltArrTm = -3*365;
    DPM_2100_ConvertDate();

    sprintf(sErrorMessage, "Processing Date: %s", A04118.A04118_appl_area.sFltDprtDt);
    BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline logic.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{
    DPM_2500_ProcessRows();

    DPM_4920_ProcessLUW();

    DPM_9500_ProcessEndOfProgram();

    BCH_Terminate();

    exit(0);
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2100_ConvertDate                         **
**                                                               **
** Description:     This function calls the service to add xx    **
**                  days to today's date and return.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   sFltDprtDt                                   **
**                                                               **
**                                                               **
******************************************************************/

int     DPM_2100_ConvertDate()
{
   short   nSvcRtnCd;   /* Service return code */

   /***************************************************/
   /** Call service to add xx days to the given date **/
   /***************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04118,&A04118,SERVICE_ID_04118,1,sizeof(_R04118_APPL_AREA));

   /** Service Return Code Processing **/
   switch (nSvcRtnCd)
      { 
      case ARC_SUCCESS:
         break;
            
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04118");
         sprintf(sErrorMessage, "Date: %s", R04118.R04118_appl_area.sPassRptSortDt);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT,sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2100_ConvertDate");
      }     
}
 
 
/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessRows()
{
}


/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_4920_ProcessLUW()
{
    short     nSvcRtnCd;      /* Service return code */

    /*** Initialize service request and answer blocks ***/
    memset(&R02873, LOW_VALUES, sizeof(_R02873));
    memset(&A02873, LOW_VALUES, sizeof(_A02873));

    /**** Format request block ****/
    strcpy(R02873.R02873_appl_area.sFltDprtDt, A04118.A04118_appl_area.sFltDprtDt);

    /**** Execute service to perform delete from imputed trip table where departure date > 1 year old ****/
    nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02873,&A02873,SERVICE_ID_02873,1,sizeof(_R02873));

    /*** Perform service return code processing ***/
    switch (nSvcRtnCd)
    {
        case ARC_SUCCESS:
            break;

        default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02873");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_9500_ProcessEndOfProgram");
    }  

   /** Write Messages to Log **/
    BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "Rows Archived");
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

    BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL); 
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{
}
