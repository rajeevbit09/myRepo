/**************************************************************************** 
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         ** 
** Sub-System :     Pass Accounting                                        **
**                                                                         ** 
** Program Name:    EPB90016.c                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.c>                                           **
**                                                                         **
** Program Type:    Batch Report Format Module with zero control breaks    **
**                                                                         **
** Author :         TransQuest                                             **
**                  kenneth hancock                                        **
**                                                                         **
** Date Written:    Aug 11, 1995                                            **
**                                                                         **
** Description:     This program reads the sort record created by program  **
**                  EPB90016 and formats the "PASSENGER DUTY TAX REPORT"  **
**                  report.                                                **
**                                                                         **
** Revision Trail:                                                         ** 
**                                                                         ** 
** Date       Revised by         SIR #    Description                      ** 
** ----       ----------         -----    -----------                      ** 
**                                                                         ** 
****************************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "epb90016.h"
#include "bchrfmcd.h"
#include "epbcmncd.h"

main()
{
   RFM_1000_InitializeFlds();
   while ((feof(stdin)) == 0)
      {
      RFM_3000_ProcessDetail();  
      }
   RFM_4000_ProcessEndOfJob();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1000_InitializeFlds                      **
**                                                               **
** Description:     Initialize fields, read initial record,      **
**                  zero accumulators                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1000_InitializeFlds()
{
   char   sCurrentDate[13];      /* current date in mm/dd/yy format */
   char  *pBegDate,              /* pointers to reporting dates */
         *pEndDate;
   
   rfm_ReadNextRecord();

   /* Get system date and time */
   current = time((time_t *)0);
   strcpy(tu.t_str, ctime(&current));
   strftime(sCurrentDate,12,"%m/%d/%y",localtime(&current));

   tu.t_str[7] = tu.t_str[10]=tu.t_str[19]=tu.t_str[24]='\0';
 
   /* Assign report beginning and ending dates to variables */
   pBegDate = (char *) getenv("DATE1");
   pEndDate = (char *) getenv("DATE2");
   strcpy(rpt_data.F9006_RptDataStruct.sFltFeeBegDt, UTL_ConvertDate(pBegDate,CNV_DB_TO_MM_DD_YY));
   strcpy(rpt_data.F9006_RptDataStruct.sFltFeeEndDt, UTL_ConvertDate(pEndDate,CNV_DB_TO_MM_DD_YY));

   /* If report has an as of date, format the as of date here   */
   nCurrentLineCount = NEW_PAGE;
   memset(print_line,' ',PAGE_WIDTH);
   strcpy(sRequestId, input_area.rqst_id);

   /* Format and save standard headings */

   /* standard heading 1 */
   PRINT_SETUP(1,"CSR #:");
   PRINT_SETUP(11,"7910");
   PRINT_SETUP(56,STD_RPT_TITLE);
   PRINT_SETUP(115,"PAGE:");
   memcpy(std_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 2 */
   PRINT_SETUP(1,"REPORT:");
   PRINT_SETUP(11, "EPB90016");
   PRINT_SETUP(53, "AIR PASSENGER DUTY TAX REPORT");
   PRINT_SETUP(115,"DATE:");
   PRINT_SETUP(123, sCurrentDate);
   memcpy(std_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 3 */
   sprintf(sFormatFld, "PERIOD %s TO %s", rpt_data.F9006_RptDataStruct.sFltFeeBegDt, rpt_data.F9006_RptDataStruct.sFltFeeEndDt);
   PRINT_SETUP(52, sFormatFld);
   PRINT_SETUP(115,"TIME:");
   PRINT_SETUP(123,tu.ts.hh_mm_ss);
   memcpy(std_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 2 */
      PRINT_SETUP(32, "FLT NUMBER");
   PRINT_SETUP(53, "NBR PSGRS AT 5 GBP RATE");
   PRINT_SETUP(84, "NBR PSGRS AT 10 GBP RATE");
   memcpy(appl_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 4 */
   PRINT_SETUP(32, "__________");
   PRINT_SETUP(51, "_______________________");
   PRINT_SETUP(84, "________________________");
   memcpy(appl_heading_4,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3000_ProcessDetail                       **
**                                                               **
** Description:     Process detail line, read next record and    **
**                  determine if there was a control break       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3000_ProcessDetail()
{
    RFM_3100_ProcessReportRecord();
    rfm_ReadNextRecord();
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3100_ProcessReportRecord                 **
**                                                               **
** Description:     Format detail line, add amounts to control   **
**                  totals.                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3100_ProcessReportRecord()
{
   nLinesInGroup = DETAIL_LINE;

   /* Set end of report indicator to no */
   cEndOfRpt = 'N';

      /* Print all fields, excluding Pass Group, if Pass Group is the same */
      PRINT_SETUP(32 + CenterPosition(10, rpt_data.F9006_RptDataStruct.sFltNbr), rpt_data.F9006_RptDataStruct.sFltNbr);
      //sprintf(sTempFld, "%8ld", rpt_data.F9006_RptDataStruct.lPsgr5RatNbr);
      strcpy(sTempFld, rpt_data.F9006_RptDataStruct.sPsgr5RatNbr);
      rfm_FormatStr(sTempFld, "ZZ,ZZZ,ZZ9", sInputFld);
      PRINT_SETUP(64, sInputFld);
      //sprintf(sTempFld, "%8ld", rpt_data.F9006_RptDataStruct.lPsgr10RatNbr);
      strcpy(sTempFld, rpt_data.F9006_RptDataStruct.sPsgr10RatNbr);
      rfm_FormatStr(sTempFld, "ZZ,ZZZ,ZZ9", sInputFld);
      PRINT_SETUP(98, sInputFld);
      rfm_ControlPrint(SINGLE_SPACE, print_line);


}


/******************************************************************
**                                                               **
** Function Name:   RFM_4000_ProcessEndOfJob                     **
**                                                               **
** Description:     Format grand total line, print end of report **
**                  line, close input file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4000_ProcessEndOfJob()
{
   /* Set end of report indicator to yes */
   cEndOfRpt = 'Y';

   /* Format end of report line */
   PRINT_SETUP(3, "END OF REPORT");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_5000_PageHeadings                        **
**                                                               **
** Description:     Format and print heading line                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_5000_PageHeadings()
{
   char sNbrOfReportPages[4];  /* Number of report pages written */
 
   nRptPagesWritten++;
 
   /* Format first heading line */
   memcpy(print_line,std_heading_1,PAGE_WIDTH);
   sprintf(sNbrOfReportPages,"%3i",nRptPagesWritten);
   PRINT_SETUP(128,sNbrOfReportPages);
   rfm_PrintLine(NEW_PAGE,print_line);
 
   /* Format second heading line */
   memcpy(print_line,std_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   /* Format third heading line */
   memcpy(print_line,std_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
   rfm_PrintLine(DOUBLE_SPACE, print_line);
 
   /* Print application headings if end of report indicator is no */
   if (cEndOfRpt == 'N')
      {
      /* Format application headings */
   /*   memcpy(print_line,appl_heading_1,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
 */
      memcpy(print_line,appl_heading_2,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

  /*    memcpy(print_line,appl_heading_3,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
*/
      memcpy(print_line,appl_heading_4,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
 
      /* Use the next line if you want a blank line between the last */
      /* application heading line and the first detail line          */
      rfm_PrintLine(SINGLE_SPACE, print_line);
      }
}

/******************************************************************
**                                                               **
** Function Name:   CenterPosition                               **
**                                                               **
** Description:     Calculates number of positions to move       **
**                  to position text in center of field          **
**                                                               **
** Arguments:       Length of field                              **
**                  Input character string                       **
**                                                               **
** Return Values:   Position to center character string          **
**                                                               **
**                                                               **
******************************************************************/

int CenterPosition(int nLength, char sInput[])
{
   int nNbr;      /* Position to center string */

   nNbr = (nLength - (int)strlen(sInput)) / 2;
   return nNbr;
}
