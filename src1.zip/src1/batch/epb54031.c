/**************************************************************************** 
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         ** 
** Sub-System :     Pass Accounting                                        **
**                                                                         ** 
** Program Name:    EPB54031.c                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.c>                                           **
**                                                                         **
** Program Type:    Batch Report Format Module with zero control breaks    **
**                                                                         **
** Author :         Delta Air Lines, Inc.                                  **
**                  Beverly Ellison                                        **
**                                                                         **
** Date Written:    January 15 2013                                        **
**                                                                         **
** Description:     This program reads the report records created by       **
**                  program EPB54002 and formats the Delta Private Jet     **
**                  Detail Report. this was copied from EPB54030.c         **
**                                                                         **
** Revision Trail:                                                         ** 
**                                                                         ** 
** Date       Revised by         SIR #    Description                      ** 
** ----       ----------         -----    -----------                      ** 
****************************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "epb54031.h"
#include "bchrfmcd.h"

main()
{
   RFM_1000_InitializeFlds();
   while ((feof(stdin)) == 0)
      {
      RFM_3000_ProcessDetail();  
      }
   RFM_4000_ProcessEndOfJob();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1000_InitializeFlds                      **
**                                                               **
** Description:     Initialize fields, read initial record,      **
**                  zero accumulators                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1000_InitializeFlds()
{
   char sCurrentDate[13]; /* current date in mm/dd/yy format */

   rfm_ReadNextRecord();
   strcpy(sSavePprNbr, rpt_data.F0541_RptDataStruct.sPprNbr);
   strcpy(sSaveNrevNbr, "  ");                                              

   /* Get system date and time */
   current = time((time_t *)0);
   strcpy(tu.t_str, ctime(&current));
   strftime(sCurrentDate,12,"%m/%d/%y",localtime(&current));

   tu.t_str[7] = tu.t_str[10]=tu.t_str[19]=tu.t_str[24]='\0';
 
   /* If report has an as of date, format the as of date here   */
   nCurrentLineCount = NEW_PAGE;
   memset(print_line,' ',PAGE_WIDTH);
   strcpy(sRequestId, input_area.rqst_id);

   /* Format and save standard headings */
   /* standard heading 1 */
   PRINT_SETUP(1,"CSR #:");
   PRINT_SETUP(11,"XXXX");
   PRINT_SETUP(56,STD_RPT_TITLE);
   PRINT_SETUP(115,"PAGE:");
   memcpy(std_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 2 */
   PRINT_SETUP(1,"REPORT:");
   PRINT_SETUP(11, "EPB54031");
   PRINT_SETUP(52, "DELTA PRIVATE JET DETAIL REPORT");
   PRINT_SETUP(115,"DATE:");
   PRINT_SETUP(123, sCurrentDate);
   memcpy(std_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 3 */
   PRINT_SETUP(59,"AS OF");
   PRINT_SETUP(65, sCurrentDate);
   PRINT_SETUP(115,"TIME:");
   PRINT_SETUP(123,tu.ts.hh_mm_ss);
   memcpy(std_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 1 */
   PRINT_SETUP(4, "PPR ID/NON-REV ID");
   PRINT_SETUP(27, "PPR/NON-REV PASSENGER NAME");
   PRINT_SETUP(61, "PPR SSN/PASSENGER TYPE");
   PRINT_SETUP(88, "TRANS DATE");
   PRINT_SETUP(104, "CHARGE TYPE");
   PRINT_SETUP(123, "AMOUNT");
   memcpy(appl_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 2 */
   PRINT_SETUP(4, "_________________");
   PRINT_SETUP(25, "______________________________");
   PRINT_SETUP(59, "_________________________");
   PRINT_SETUP(88, "___________");
   PRINT_SETUP(103, "_______________");
   PRINT_SETUP(122, "_________");
   memcpy(appl_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3000_ProcessDetail                       **
**                                                               **
** Description:     Process detail line, read next record and    **
**                  determine if there was a control break       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3000_ProcessDetail()
{
    RFM_3100_ProcessReportRecord();
    rfm_ReadNextRecord();
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3100_ProcessReportRecord                 **
**                                                               **
** Description:     Format detail line, add amounts to control   **
**                  totals.                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3100_ProcessReportRecord()
{
   /* if the ppr number changes, print the totals charges for the PPR  */
   if (strcmp(rpt_data.F0541_RptDataStruct.sPprNbr, sSavePprNbr) != 0)
   {
      RFM_3200_ProcessTotals();
      strcpy(sSavePprNbr, rpt_data.F0541_RptDataStruct.sPprNbr);
      strcpy(sSaveNrevNbr, "  ");
      dNrevTtlAmt = 0.0;
   }

   /* Format and print the detail line    */                                       
   /* print the ppr nbr and ppr name on the first line only     */                       
   if (dNrevTtlAmt == 0.0)
      {
      sprintf(sFormatFld, "%s00", rpt_data.F0541_RptDataStruct.sPprNbr);
      PRINT_SETUP(4, sFormatFld);
      PRINT_SETUP(25, rpt_data.F0541_RptDataStruct.sPprNm);
      PRINT_SETUP(59, rpt_data.F0541_RptDataStruct.sPprSocSecNbr);
      rfm_ControlPrint(SINGLE_SPACE, print_line);
      }
   

   /*  print the passenger name and passenger type on the first occurance of nrev only */
   if (strcmp(rpt_data.F0541_RptDataStruct.sNrevNbr, sSaveNrevNbr) != 0)
   {
      sprintf(sFormatFld2, "%s%s", rpt_data.F0541_RptDataStruct.sPprNbr, rpt_data.F0541_RptDataStruct.sNrevNbr);
      PRINT_SETUP(5, sFormatFld2);
      PRINT_SETUP(26, rpt_data.F0541_RptDataStruct.sNrevNm);
      PRINT_SETUP(60, rpt_data.F0541_RptDataStruct.sNrevTypDs);
      strcpy(sSaveNrevNbr, rpt_data.F0541_RptDataStruct.sNrevNbr);
   }
   else
   {
      PRINT_SETUP(4, sNrevNmSpaces);
      PRINT_SETUP(25, sNrevNmSpaces);
      PRINT_SETUP(59, sNrevNmSpaces);
   }

   PRINT_SETUP(88, rpt_data.F0541_RptDataStruct.sFltDprtDt);
   PRINT_SETUP(103, rpt_data.F0541_RptDataStruct.sSvcChrgDs);
   //sprintf(sAmtFld, "%9.2f", rpt_data.F0541_RptDataStruct.dCostChrgAmt);
   //PRINT_SETUP(122, sAmtFld);
   PRINT_SETUP(122, rpt_data.F0541_RptDataStruct.sCostChrgAmt);
   rfm_ControlPrint(SINGLE_SPACE, print_line);

   /*
   **  Modified By: LSW - 12/10/98
   **  Changed amount used to calculate total for dNrevTtlAmt
   **  from rpt_data.F0541_RptDataStruct.dCostChrgAmt to sAmtFld.  This was done to
   **  correct the total amount generated for the report.
   */
   /* Add detail amount to accumulator */
   //dNrevTtlAmt += atof(sAmtFld);  
   dNrevTtlAmt += atof(rpt_data.F0541_RptDataStruct.sCostChrgAmt);  
/*
   dNrevTtlAmt += rpt_data.F0541_RptDataStruct.dCostChrgAmt;  
*/
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3200_ProcessTotals                       **
**                                                               **
** Description:     Format and print Total Lines                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3200_ProcessTotals()
{
   /*  print the nrev totals */
   PRINT_SETUP(109, "TOTAL");
   sprintf(sAmtFld, "%9.2f", dNrevTtlAmt);
   PRINT_SETUP(122, sAmtFld);
   rfm_ControlPrint(DOUBLE_SPACE, print_line);
   rfm_PrintLine(SINGLE_SPACE, print_line);

   /* Add nonrev amount to grand total amount */
   dGrandTtlAmt += dNrevTtlAmt;  

}

/******************************************************************
**                                                               **
** Function Name:   RFM_4000_ProcessEndOfJob                     **
**                                                               **
** Description:     Format grand total line, print end of report **
**                  line, close input file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4000_ProcessEndOfJob()
{
   /* print ppr totals   */
   RFM_3200_ProcessTotals();

   /*  print the grand total */
   PRINT_SETUP(103, "GRAND TOTAL");
   sprintf(sAmtFld, "%10.2f", dGrandTtlAmt);
   PRINT_SETUP(121, sAmtFld);
   rfm_ControlPrint(TRIPLE_SPACE, print_line);

   PRINT_SETUP(3, "END OF REPORT");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_5000_PageHeadings                        **
**                                                               **
** Description:     Format and print heading line                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_5000_PageHeadings()
{
   char sNbrOfReportPages[4];  /* Number of report pages written */
 
   nRptPagesWritten++;
 
   /* Format first heading line */
   memcpy(print_line,std_heading_1,PAGE_WIDTH);
   sprintf(sNbrOfReportPages,"%3i",nRptPagesWritten);
   PRINT_SETUP(128,sNbrOfReportPages);
   rfm_PrintLine(NEW_PAGE,print_line);
 
   /* Format second heading line */
   memcpy(print_line,std_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   /* Format third heading line */
   memcpy(print_line,std_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
 
   /*   print the application heading 1*/
   memcpy(print_line,appl_heading_1,PAGE_WIDTH);
   rfm_PrintLine(TRIPLE_SPACE, print_line);
   
   /*   print the application heading 2*/
   memcpy(print_line,appl_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
   rfm_PrintLine(SINGLE_SPACE, print_line);
}

