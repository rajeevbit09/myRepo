/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    EPB90005.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest                                             **
**                  kenneth hancock                                        **
**                                                                         **
** Date Written:     Aug 24, 1995                                          **
**                                                                         **
** Description:     This program finds all Indian based employees and      **
**                  indicates travel and pass charges incurred in order    **
**                  to create the Indian Based Employee Travel             **
**                  Notification Report.                                   **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/
#include "epb90005.h"

main()
{
   BCH_Init("EPB90005", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short   nRptIndex,                 /* Report index */
           nReqRptInd1 = FALSE;       /* Required report #1 indicator */

   char   *pBegDate,                  /* pointers to reporting dates */ 
          *pEndDate;

   /**** Set key to primary database record in RSAM to nulls/zero ****/ 
   strcpy(RS.sPprNbr, " ");
   strcpy(RS.sNrevNbr, " ");
   strcpy(RS.sFltDprtDt, " ");
   strcpy(RS.sPassDtTmTs, " ");
   strcpy(RS.sFltOrigCtyId, " ");
   strcpy(RS.sFltDestCtyId, " ");
   strcpy(RS.sSvcChrgCd, " ");
   RS.lFltChrgRfrnDt = 0;

   /**** Assign report beginning and ending dates to variables ****/
   pBegDate = (char *) getenv("DATE1");
   pEndDate = (char *) getenv("DATE2");
   memcpy(RS.sFltFeeBegDt, pBegDate, sizeof(RS.sFltFeeBegDt));
   memcpy(RS.sFltFeeEndDt, pEndDate, sizeof(RS.sFltFeeEndDt));

   /**** Initialize flag for all rows processed ****/
   RS.nProcessedAllRows = FALSE;

   /**** Initialize architecture area of service answer and
         request blocks ****/
   memset(&A02747, LOW_VALUES, sizeof(_A02747));
   memset(&R02747, LOW_VALUES, sizeof(_R02747));
   memset(&A02767, LOW_VALUES, sizeof(_A02767));
   memset(&R02767, LOW_VALUES, sizeof(_R02767));
   memset(&A03845, LOW_VALUES, sizeof(_A03845));
   memset(&R03845, LOW_VALUES, sizeof(_R03845));
   memset(&A03917, LOW_VALUES, sizeof(_A03917));
   memset(&R03917, LOW_VALUES, sizeof(_R03917));

   GOOD = '1';

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */
   short     nSvcRtnCd1;      /* Service return code */

   /****** Initialize Request and Answer Blocks *****/
   memset(&R02747.R02747_appl_area, LOW_VALUES, sizeof(_R02747_APPL_AREA));
   memset(&A02747.A02747_appl_area, LOW_VALUES, sizeof(_A02747_APPL_AREA));

   /****** Format R02747 keys for initial DB Read *****/
   strcpy(R02747.R02747_appl_area.sPprNbr, RS.sPprNbr);
   strcpy(R02747.R02747_appl_area.sNrevNbr, RS.sNrevNbr);
   strcpy(R02747.R02747_appl_area.sFltDprtDt, RS.sFltDprtDt);
   strcpy(R02747.R02747_appl_area.sPassDtTmTs, RS.sPassDtTmTs);
   strcpy(R02747.R02747_appl_area.sFltFeeBegDt, RS.sFltFeeBegDt);
   strcpy(R02747.R02747_appl_area.sFltFeeEndDt, RS.sFltFeeEndDt);

   /**** Open the DB cursor ****/ 
   R02747.R02747_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to retrieve driving rows  ****/
   nSvcRtnCd1 = BCH_InvokeService(EPBINQ0,&R02747,&A02747,SERVICE_ID_02747,1,sizeof(_R02747_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd1)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         RS.nProcessedAllRows = TRUE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02747");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows for Travel and Service charges of Flight Legs ****/
   while ((nSvcRtnCd1 != ARC_ROW_NOT_FOUND) && (RS.nProcessedAllRows == FALSE))
   {
      if (A02747.A02747_appl_area.sSvcChrgCd[0] == 'S')
      {
         if (strcmp(A02747.A02747_appl_area.sPprNbr, RS.sPprNbr) != 0 || 
                    strcmp(A02747.A02747_appl_area.sNrevNbr, RS.sNrevNbr) != 0 || 
                    A02747.A02747_appl_area.lFltChrgRfrnDt != RS.lFltChrgRfrnDt || 
                    strcmp(A02747.A02747_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId) != 0)
		 {
            DPM_2500_ProcessRows(); 
         }
      } 
      else
      {
         if (strcmp(A02747.A02747_appl_area.sPprNbr, RS.sPprNbr) != 0 || 
                    strcmp(A02747.A02747_appl_area.sNrevNbr, RS.sNrevNbr) != 0 || 
                    A02747.A02747_appl_area.lFltChrgRfrnDt != RS.lFltChrgRfrnDt || 
                    strcmp(A02747.A02747_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId) != 0 || 
                    strcmp(A02747.A02747_appl_area.sFltDestCtyId, RS.sFltDestCtyId) != 0 || 
                    strcmp(A02747.A02747_appl_area.sSvcChrgCd, RS.sSvcChrgCd) != 0)
		 {
            DPM_2500_ProcessRows(); 
         }
      } 
      

      R02747.R02747_appl_area.cArchCursorOpTxt = FETCH_ROW;

      memset(&A02747, LOW_VALUES, sizeof(_A02747));

      /**** Execute service to obtain next DB row ****/
      nSvcRtnCd1 = BCH_InvokeService(EPBINQ0,&R02747,&A02747,SERVICE_ID_02747,1,sizeof(_R02747_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd1)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            RS.nProcessedAllRows = TRUE;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02747");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   /**** Control report is not generated ****/

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   short     nSvcRtnCd;      /* Service return code */

   if (A02747.A02747_appl_area.sSvcChrgCd[0] == 'S')
   {
      /**** Get ORIG/DEST from FLT_LEG table ****/

      /**** Initialize Service Request and Answer Blocks ****/
      memset(&R02767.R02767_appl_area, LOW_VALUES, sizeof(_R02767_APPL_AREA));
      memset(&A02767.A02767_appl_area, LOW_VALUES, sizeof(_A02767_APPL_AREA));

      /**** Format Request Block with specifics ****/
      strcpy(R02767.R02767_appl_area.sPprNbr, A02747.A02747_appl_area.sPprNbr);
      strcpy(R02767.R02767_appl_area.sNrevNbr, A02747.A02747_appl_area.sNrevNbr);
      R02767.R02767_appl_area.lFltChrgRfrnDt = A02747.A02747_appl_area.lFltChrgRfrnDt;

      /**** Execute Service to perform Advanced List from Flight Leg table ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02767,&A02767,SERVICE_ID_02767,1,sizeof(_R02767_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_FormatMessage(2,TXT_SVC, "FYS02767");
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2500_ProcessRows");
            GOOD = '0';
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02767");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
      } 

      /**** Initialize Service Request and Answer Blocks ****/
      memset(&R03917.R03917_appl_area, LOW_VALUES, sizeof(_R03917_APPL_AREA));
      memset(&A03917.A03917_appl_area, LOW_VALUES, sizeof(_A03917_APPL_AREA));
 
      /**** Format Request Block with specifics ****/
      strcpy(R03917.R03917_appl_area.sPprNbr, A02747.A02747_appl_area.sPprNbr);
      strcpy(R03917.R03917_appl_area.sNrevNbr, A02747.A02747_appl_area.sNrevNbr);
      R03917.R03917_appl_area.lFltChrgRfrnDt = A02747.A02747_appl_area.lFltChrgRfrnDt;
 
      /**** Execute Service to perform Advanced List from Flight Leg table ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R03917,&A03917,SERVICE_ID_03917,1,sizeof(_R03917_APPL_AREA));
 
      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;
 
         case ARC_ROW_NOT_FOUND:
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_FormatMessage(2,TXT_SVC, "FYS03917");
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2500_ProcessRows");
            GOOD = '0';
            break;
 
      default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03917");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
      }
   

   } /* endif for SV   */

   /**** Initialize Service Request and Answer Blocks ****/
   memset(&R03845.R03845_appl_area, LOW_VALUES, sizeof(_R03845_APPL_AREA));
   memset(&A03845.A03845_appl_area, LOW_VALUES, sizeof(_A03845_APPL_AREA));
      
   /**** Format Request Block with specifics ****/
   strcpy(R03845.R03845_appl_area.sPprNbr, A02747.A02747_appl_area.sPprNbr);
   strcpy(R03845.R03845_appl_area.sNrevNbr, A02747.A02747_appl_area.sNrevNbr);
   strcpy(R03845.R03845_appl_area.sSvcChrgCd, A02747.A02747_appl_area.sSvcChrgCd);
   R03845.R03845_appl_area.lFltChrgRfrnDt = A02747.A02747_appl_area.lFltChrgRfrnDt;
   if (A02747.A02747_appl_area.sSvcChrgCd[0] == 'I') 
   {
      strcpy(R03845.R03845_appl_area.sFltOrigCtyId, A02747.A02747_appl_area.sFltOrigCtyId);
      strcpy(R03845.R03845_appl_area.sFltDestCtyId, A02747.A02747_appl_area.sFltDestCtyId);
   } /* endif for IF  */
   else
   {
      strcpy(R03845.R03845_appl_area.sFltOrigCtyId, "*****");
      strcpy(R03845.R03845_appl_area.sFltDestCtyId, "*****");
   } /* end else   */
   
   /**** Execute Service to perform Advanced List from Flight Leg table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R03845,&A03845,SERVICE_ID_03845,1,sizeof(_R03845_APPL_AREA));
 
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;
 
      case ARC_ROW_NOT_FOUND:
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_FormatMessage(2,TXT_SVC, "FYS03845");
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2500_ProcessRows");
         GOOD = '0';
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS03845");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
   }

   strcpy(RS.sPprNbr, A02747.A02747_appl_area.sPprNbr);
   strcpy(RS.sNrevNbr, A02747.A02747_appl_area.sNrevNbr);
   strcpy(RS.sSvcChrgCd, A02747.A02747_appl_area.sSvcChrgCd);
   RS.lFltChrgRfrnDt = A02747.A02747_appl_area.lFltChrgRfrnDt;
   if (A02747.A02747_appl_area.sSvcChrgCd[0] == 'I')
   {
      strcpy(RS.sFltOrigCtyId, A02747.A02747_appl_area.sFltOrigCtyId);
      strcpy(RS.sFltDestCtyId, A02747.A02747_appl_area.sFltDestCtyId);
   } /* endif for IF */ 

   DPM_5010_Generate();   
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5010_Generate                            **
**                                                               **
** Description:     Write report records for report              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_5010_Generate()
{
   short     nRptIndex;                     /* Index into the report control table */
   char      cRecEndLineTxt = '\n';
   short     nRowRet;      /* Rows found in 2767 */
 
   /***** if for found flt_legs  *****/
   if (GOOD == '1')
   {
      /**** Initialize report sort and data copybooks ****/  
      memset(&EPRF9005.F9005_RptDataStruct, LOW_VALUES, sizeof(_F9005_RPTDATASTRUCT));
      memset(&EPRS9005.S9005_RptDataStruct, LOW_VALUES, sizeof(_S9005_RPTDATASTRUCT));
 
      /**** Format report fields in sort and data layouts ****/
      strcpy(EPRF9005.F9005_RptDataStruct.sPprNm, A02747.A02747_appl_area.sPprNm);
      strcpy(EPRF9005.F9005_RptDataStruct.sPprDeptNbr, A02747.A02747_appl_area.sPprDeptNbr);
      strcpy(EPRF9005.F9005_RptDataStruct.sPprStnId, A02747.A02747_appl_area.sPprStnId);
      strcpy(EPRF9005.F9005_RptDataStruct.sPprStrtDt, 
             UTL_ConvertDate(A02747.A02747_appl_area.sPprStrtDt,CNV_DB_TO_DD_MMM_YYYY));
      strcpy(EPRF9005.F9005_RptDataStruct.sPprNbr, A02747.A02747_appl_area.sPprNbr);
      strcpy(EPRF9005.F9005_RptDataStruct.sNrevNbr, A02747.A02747_appl_area.sNrevNbr);
      strcpy(EPRF9005.F9005_RptDataStruct.sNrevNm, A02747.A02747_appl_area.sNrevNm);
      strcpy(EPRF9005.F9005_RptDataStruct.sFltDprtDt, 
             UTL_ConvertDate(A02747.A02747_appl_area.sFltDprtDt,CNV_DB_TO_DD_MMM_YYYY));
      strcpy(EPRF9005.F9005_RptDataStruct.sSvcChrgCd, A02747.A02747_appl_area.sSvcChrgCd);
      strcpy(EPRF9005.F9005_RptDataStruct.sFltFeeBegDt, 
             UTL_ConvertDate(RS.sFltFeeBegDt,CNV_DB_TO_MM_DD_YY));
      strcpy(EPRF9005.F9005_RptDataStruct.sFltFeeEndDt, 
             UTL_ConvertDate(RS.sFltFeeEndDt,CNV_DB_TO_MM_DD_YY));

      if (A02747.A02747_appl_area.sSvcChrgCd[0] == 'I')
      {
         strcpy(EPRF9005.F9005_RptDataStruct.sFltNbr, A02747.A02747_appl_area.sFltNbr);
         strcpy(EPRF9005.F9005_RptDataStruct.sFltOrigCtyId, A02747.A02747_appl_area.sFltOrigCtyId);
         strcpy(EPRF9005.F9005_RptDataStruct.sFltDestCtyId, A02747.A02747_appl_area.sFltDestCtyId);
         //EPRF9005.F9005_RptDataStruct.dCostChrgAmt = A03845.A03845_appl_area.dCostChrgAmt;
         sprintf(EPRF9005.F9005_RptDataStruct.sCostChrgAmt, "%7.2f", A03845.A03845_appl_area.dCostChrgAmt);
      } /* end if for IF   */
      else
      {
         strcpy(EPRF9005.F9005_RptDataStruct.sFltOrigCtyId, A02767.A02767_appl_area.sFltOrigCtyId);
         strcpy(EPRF9005.F9005_RptDataStruct.sFltDestCtyId, A03917.A03917_appl_area.sFltDestCtyId);
         //EPRF9005.F9005_RptDataStruct.dCostChrgAmt = A03845.A03845_appl_area.dCostChrgAmt;
         sprintf(EPRF9005.F9005_RptDataStruct.sCostChrgAmt, "%7.2f", A03845.A03845_appl_area.dCostChrgAmt);
      } /* end else for IF  */

      EPRF9005.F9005_RptDataStruct.cRecEndLineTxt = '\n';

      strcpy(EPRS9005.S9005_RptDataStruct.sPprStnId, A02747.A02747_appl_area.sPprStnId);
      strcpy(EPRS9005.S9005_RptDataStruct.sPprDeptNbr, A02747.A02747_appl_area.sPprDeptNbr);
      strcpy(EPRS9005.S9005_RptDataStruct.sPprNbr, A02747.A02747_appl_area.sPprNbr);
      strcpy(EPRS9005.S9005_RptDataStruct.sNrevNbr, A02747.A02747_appl_area.sNrevNbr);
      strcpy(EPRS9005.S9005_RptDataStruct.sFltDprtDt, 
             UTL_ConvertDate(A02747.A02747_appl_area.sFltDprtDt,CNV_DB_TO_YYYYMMDD));
      strcpy(EPRS9005.S9005_RptDataStruct.sSvcChrgCd, A02747.A02747_appl_area.sSvcChrgCd);

      /**** Write report record ****/
      BCH_WriteRptRec("EPB90015",&EPRS9005, sizeof(EPRS9005), &EPRF9005, sizeof(EPRF9005));
   }  /*** endif for GOOD  ***/
   GOOD = '1';
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{
   /** include any logic here for final clean-up processing  **/
   /** e.g. producing a final summary record  **/
   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
