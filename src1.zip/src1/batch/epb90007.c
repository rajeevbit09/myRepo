/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    EPB90007.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Gillian Lyth                                           **
**                                                                         **
** Date Written:     Feb 29, 1996                                          **
**                                                                         **
** Description:     This program reports all Transoceanic flt_legs for     **
**                  passengers with a residency status code of 'EP' or     **
**                  'TC' for the month.                                    **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/
#include "epb90007.h"

main()
{
   BCH_Init("EPB90007", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short   nRptIndex,                 /* Report index */
           nReqRptInd1 = FALSE;       /* Required report #1 indicator */

   char   *pDate1,
          *pDate2;                  /* pointers to reporting dates */ 

   /**** Set key to primary database record in RSAM to nulls/zero ****/ 
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sNrevNbr, SPACE_CHAR);
   //strcpy(RS.sFltDprtDt, SPACE_CHAR);
   strcpy(RS.sFltNbr, SPACE_CHAR);
   strcpy(RS.sFltOrigCtyId, SPACE_CHAR);
   strcpy(RS.sFltFeeBegDt, SPACE_CHAR);
   strcpy(RS.sFltFeeEndDt, SPACE_CHAR);
   //memset(&RS.sFltDprtDt, LOW_VALUES, sizeof(RS.sFltDprtDt));
   strcpy(RS.sFltDprtDt, LOW_DATE);

   /**** Assign report period dates to variables ****/
   pDate1 = (char *) getenv("DATE1");
   strcpy(RS.sFltFeeBegDt, pDate1);
   pDate2 = (char *) getenv("DATE2");
   strcpy(RS.sFltFeeEndDt, pDate2);

   /**** Initialize flag for all rows processed ****/
   RS.nProcessedAllRows = FALSE;

   /**** Initialize architecture area of service answer and
         request blocks ****/
   memset(&A04274, LOW_VALUES, sizeof(_A04274));
   memset(&R04274, LOW_VALUES, sizeof(_R04274));
  
   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */

   /****** Initialize Request and Answer Blocks *****/
   memset(&R04274.R04274_appl_area, LOW_VALUES, sizeof(_R04274_APPL_AREA));
   memset(&A04274.A04274_appl_area, LOW_VALUES, sizeof(_A04274_APPL_AREA));

   /****** Format R04274 keys for initial DB Read *****/
   strcpy(R04274.R04274_appl_area.sPprNbr, RS.sPprNbr);
   strcpy(R04274.R04274_appl_area.sNrevNbr, RS.sNrevNbr);
   strcpy(R04274.R04274_appl_area.sFltDprtDt, RS.sFltDprtDt);
   strcpy(R04274.R04274_appl_area.sFltNbr, RS.sFltNbr);
   strcpy(R04274.R04274_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId);
   strcpy(R04274.R04274_appl_area.sFltFeeBegDt, RS.sFltFeeBegDt);
   strcpy(R04274.R04274_appl_area.sFltFeeEndDt, RS.sFltFeeEndDt);
   /**** Open the DB cursor ****/ 
   R04274.R04274_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to retrieve driving rows  ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04274,&A04274,SERVICE_ID_04274,1,sizeof(_R04274_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         RS.nProcessedAllRows = TRUE;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04274");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
 
   } /* end switch */ 

   /**** Process driving database rows for flight leg information */    
   while ((nSvcRtnCd != ARC_ROW_NOT_FOUND) && (RS.nProcessedAllRows == FALSE))
   {

      DPM_2500_ProcessRows();

      R04274.R04274_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04274, LOW_VALUES, sizeof(_A04274));

      /**** Execute service to obtain next DB row ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04274,&A04274,SERVICE_ID_04274,1,sizeof(_R04274_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            RS.nProcessedAllRows = TRUE;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04274");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      } /* end switch */ 
   } /* endwhile */


   /**** Control report is not generated ****/

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);

}
/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{

   /*** No program logic to process the selected database row ***/
 
   /*** A report extract record is not generated. ***/
 
   /*** To generate a report extract record, perform the function  ***/
   /*** at the appropriate place in the program!                   ***/
 
   DPM_5010_Generate();     
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5010_Generate                            **
**                                                               **
** Description:     Write report records for report              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_5010_Generate()
{
   short     nRptIndex;                     /* Index into the report control table */
   char      cRecEndLineTxt = '\n';
   short     nRowRet;      /* Rows found in 2767 */
 
   /**** Initialize report sort and data copybooks ****/  
   memset(&EPRF9007.F9007_RptDataStruct, LOW_VALUES, sizeof(_F9007_RPTDATASTRUCT));
   memset(&EPRS9007.S9007_RptDataStruct, LOW_VALUES, sizeof(_S9007_RPTDATASTRUCT));
 
   /**** Format report fields in sort and data layouts ****/
   strcpy(EPRF9007.F9007_RptDataStruct.sPprNbr, A04274.A04274_appl_area.sPprNbr);
   strcpy(EPRF9007.F9007_RptDataStruct.sNrevNbr, A04274.A04274_appl_area.sNrevNbr);
   strcpy(EPRF9007.F9007_RptDataStruct.sPprNm, A04274.A04274_appl_area.sPprNm);
   strcpy(EPRF9007.F9007_RptDataStruct.sNrevNm, A04274.A04274_appl_area.sNrevNm);
   strcpy(EPRF9007.F9007_RptDataStruct.sFltOrigCtyId, A04274.A04274_appl_area.sFltOrigCtyId);
   strcpy(EPRF9007.F9007_RptDataStruct.sFltDestCtyId, A04274.A04274_appl_area.sFltDestCtyId);
   strcpy(EPRF9007.F9007_RptDataStruct.sFltDprtDt, 
          UTL_ConvertDate(A04274.A04274_appl_area.sFltDprtDt,CNV_DB_TO_DD_MMM_YYYY));
   strcpy(EPRF9007.F9007_RptDataStruct.sFltNbr, A04274.A04274_appl_area.sFltNbr);
   
   strcpy(EPRF9007.F9007_RptDataStruct.sFltFeeBegDt, 
          UTL_ConvertDate(RS.sFltFeeBegDt,CNV_DB_TO_MM_DD_YY));
   strcpy(EPRF9007.F9007_RptDataStruct.sFltFeeEndDt, 
          UTL_ConvertDate(RS.sFltFeeEndDt,CNV_DB_TO_MM_DD_YY));
   EPRF9007.F9007_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS9007.S9007_RptDataStruct.sPprNbr, A04274.A04274_appl_area.sPprNbr);
   strcpy(EPRS9007.S9007_RptDataStruct.sNrevNbr, A04274.A04274_appl_area.sNrevNbr);
   strcpy(EPRS9007.S9007_RptDataStruct.sPassRptSortDt, 
          UTL_ConvertDate(A04274.A04274_appl_area.sPassRptSortDt,CNV_DB_TO_YYYYMMDD));
   strcpy(EPRS9007.S9007_RptDataStruct.sFltNbr, A04274.A04274_appl_area.sFltNbr);
   strcpy(EPRS9007.S9007_RptDataStruct.sFltOrigCtyId, A04274.A04274_appl_area.sFltOrigCtyId);

   /**** Write report record ****/
   BCH_WriteRptRec("EPB90017",&EPRS9007, sizeof(EPRS9007), &EPRF9007, sizeof(EPRF9007));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_9500_ProcessEndOfProgram()
{
   /** include any logic here for final clean-up processing  **/
   /** e.g. producing a final summary record  **/
   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
