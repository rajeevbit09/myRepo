/*##########################################################################*/
/*                                                                          */
/* Copyright 2010 - Delta Air Lines, Inc.                                   */
/*                       All Rights Reserved                                */
/*               Access, Modification, or Use Prohibited                    */
/* Without Express Permission of Delta Air Lines                            */
/*                                                                          */
/*##########################################################################*/
/*                                                                         **
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    epb40001.c                                             **
**                                                                         **
** Program Type:    Transaction Driven Process Module                      **
**                                                                         **
** Author:          Duane Ellis                                            **
**                                                                         **
** Date Written:    Mar 2010                                               **
**                                                                         **
** Description:     Transaction driven process module to process records   **
**                  from NRAP_FLWN_FL, impute them by applying             **
**                  travel banding logic, and write the resutling imputed  **
**                  Net Value records to the NRAP_TRP_IMPD_VAL table.      **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by  Description                                      **
** ----       ----------  --------------------                             **
** 03/25/2010 D Ellis     Inital Program Creation                          **
** 10/19/2010 D Ellis     Added nrap_trp_impd_val.Trp_Dprt_Dt Column       **
** 12/05/2010 D Ellis     Added logic to determine actual turnaround point **
** 07/11/2012 D Ellis     Added Addl Logic to determine the turnaround pnt **
**                                                                         **
****************************************************************************/
#include "epb40001.h"

char VersionStr[]    = "epb40001 v1.0.0.0";
char gCompile_Date[] = __DATE__;
char gCompile_Time[] = __TIME__;

time_t startupTime_;
time_t endTime_;

void main()
{

   BCH_Init("EPB40001", NUMBER_OF_THREADS);

   TPM_1000_Initialize();

   TPM_2000_Mainline();

   TPM_9000_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);
}


/******************************************************************
**                                                               **
** Function Name:   TPM_1000_Initialize                          **
**                                                               **
** Description:     Performs startup initialization and opens    **
**                  RPAD input file.                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_1000_Initialize()
{
   char *pEnvString;

 /**** Initialize counters & accumulators ***/

   startupTime_ = time(0);

   // Init Counters
   RS.Tot_Trip_Cnt       = 0L;
   RS.New_Trip_Cnt       = 0L;
   RS.Upd_Trip_Cnt       = 0L;
   RS.Match_Trip_Cnt     = 0L;
   RS.Ignore_Cnt         = 0L;
   RS.Error_Cnt          = 0L;

   retval = 0;


   /**** Get External Configuration Variables  ****/
   pEnvString = (char *)getenv("NBR_DAYS_PAST_FLTDPRT_DATE");
   RS.numDaysPastFltDepartDate = (pEnvString) ? atoi(pEnvString) : 40;


   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, VersionStr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_1000_Initialize");


}


/******************************************************************
**                                                               **
** Function Name:   TPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                  The main processing thread to processes      **
**                  RPAD data and to reprocess corrected data    **
**                  from the Suspense file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_2000_Mainline()
{

   char sPrmyTktDocNb[16];

   printf("Locating trips where the FltDprtDate is > %d days\n", RS.numDaysPastFltDepartDate);


   /*******************************************************************/
   /*** Get unprocessed records that are in Scope (Delta, Mesaba, MLT, etc)
   /*******************************************************************/
   nSvcRtnCd = TPM_8001_GetDistinctTrip(OPEN_AND_FETCH, sPrmyTktDocNb);
   if (nSvcRtnCd == ARC_ROW_NOT_FOUND)
   {
      printf("\nNo Trips found to impute\n\n");
      return;
   }


   //
   // While there are Records to process...
   //
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      // Process current Trip
      printf("\nTrip : %ld\n", ++RS.Tot_Trip_Cnt);
      TPM_3000_ProcessTrip(sPrmyTktDocNb);


      // Go get next Trip to process
      nSvcRtnCd = TPM_8001_GetDistinctTrip(FETCH_ROW, sPrmyTktDocNb);
   }

   // clean up - close the DB cursor
   TPM_8001_GetDistinctTrip(CLOSE_CURSOR, NULL);
}


/******************************************************************
**                                                               **
** Function Name:   TPM_3000_ProcessTrip                         **
**                                                               **
** Description:     Process and impute an unprocessed Trip       **
**                                                               **
** Arguments:       Primary Tkt Nbr                              **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void  TPM_3000_ProcessTrip(char *sPrmyTktDocNb)
{
   short cpn_ndx, rec_ndx;
   float fTmpAmt, fAdjAmt;
   int fOkayToUpdate;

   // Load ALL Coupons that go with this trip into coupon array
   // (all have matching PrmyTktDocNbs)
   TPM_8002_LoadTripCoupons(sPrmyTktDocNb);

   if (RS.TotalCoupons == 0) {
      sprintf(sErrorMessage,"Trip coupons not available for Primary Tkt Nbr %s", sPrmyTktDocNb);
      BCH_FormatMessage(1,TXT_ROW_NOT_FOUND);
      BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessTrip");
   }


   // The coupons loaded in the array are ordered by coupon number, Flt_Dprt_Dt,
   // so if the first record in the array is not coupon 1 then we don't have
   // a starting point. Ignore the trip if that happens.
   if (RS.TripCoupons[0].nTktDocSqNb != 1  ||  RS.TripCoupons[0].nTktCpnNb != 1 )
   {
      printf("First coupon in trip unavailable. Trip Ignored.\n");
      printf("  PPR=%s-%s, TktNbr=%s, TktSeq=%i, Cpn=%i, FltInfo=%s %s %s %10.10s\n",
         RS.TripCoupons[0].sPprNbr,
         RS.TripCoupons[0].sNrevNbr,
         RS.TripCoupons[0].sTktDocNbr, RS.TripCoupons[0].nTktDocSqNb,
         RS.TripCoupons[0].nTktCpnNb, RS.TripCoupons[0].sFltNbr,
         RS.TripCoupons[0].sFltOrigCtyId, RS.TripCoupons[0].sFltDestCtyId,
         RS.TripCoupons[0].sFltDprtDt);
      RS.Ignore_Cnt++;
      return;
   }

   printf("Processing Trip for PPR:%s, Primary Tkt Nbr:%s\n",
      RS.TripCoupons[0].sPprNbr, RS.TripCoupons[0].sPrmyTktDocNb);


   // Initialize NRAP_TRP_IMPD_VAL fields from first Coupon
   strncpy(RS.sPprNbr,         RS.TripCoupons[0].sPprNbr,  sizeof(RS.sPprNbr));
   strncpy(RS.sNrevNbr,        RS.TripCoupons[0].sNrevNbr, sizeof(RS.sNrevNbr));
   strncpy(RS.sNrapCd,         RS.TripCoupons[0].sNrapCd,  sizeof(RS.sNrapCd));
   strncpy(RS.sNrapFrstBkgLdt, RS.TripCoupons[0].sNrapFrstBkgLdt, sizeof(RS.sNrapFrstBkgLdt));

   RS.nNrapSpgmNb            = RS.TripCoupons[0].nNrapSpgmNb;
   RS.nNrapTrpSqNb           = RS.TripCoupons[0].nNrapTrpSqNb;
   RS.nImpdValSqlNb          = 1;
   RS.cTrp1099Ind            ='N';

   RS.cOwrtCd = 'R';          // Default to Round  Trip
   strncpy(RS.sFltDprtDt, RS.TripCoupons[0].sFltDprtDt, sizeof(RS.sFltDprtDt));

   // Note: These fields have not been assigned values yet so we have a couple more functions to call
   //    RS.cImpdTrvlBandCd
   //    RS.lTotalImpdMiCt
   //    RS.fImpdNetAmt
   //    RS.sTrpOrigCtyId
   //    RS.sTrpDestCtyId
   //    RS.sTrpDprtDt
   //    RS.sSentToPyrlDt
   //    RS.sLstUpdtId
   //    RS.sLstUpdtGts

   // Determine Origin and Destination, and mileage for this Trip
   if (TPM_8003_DetermineOrigDest())
      return;

   // Apply the travel band to this trip to determine imputed value of trip.
   if (TPM_8004_ApplyTravelBand())
      return;


   // We are now ready to insert the Imputed Value record.
   // See if there is already one or more existing records in the DB for this same trip.
   // Note: They are loaded into the array ordered by "Impd_val_sql_nb". (the way they went into the DB)
   TPM_8005_LoadTripImpdValRecords();


   // If no prior records, INSERT a new record into NRAP_TRP_IMPD_VAL table
   if (RS.TotalTrpImpdValRecs == 0) {

      TPM_5000_InsertTrpImpdVal(1, RS.fImpdNetAmt);        // Add a new record

   }

   // Oh boy! ... we found one or more records.
   // See if we have to make some corrections or adjustments
   else {


      // Let's see how far off we are
      // Sum all the amounts already in the DB for this trip
      for (rec_ndx=0, fTmpAmt=0.0; rec_ndx < RS.TotalTrpImpdValRecs; rec_ndx++) {
         fTmpAmt += RS.TripImpdValRecs[rec_ndx].fImpdNetAmt;
      }

      // See if we need to update the Destination City (only if not reported already)
      if (RS.TotalTrpImpdValRecs == 1  &&
          strcmp(RS.TripImpdValRecs[0].sTrpDestCtyId, RS.sTrpDestCtyId) != 0  &&
          strcmp(RS.TripImpdValRecs[0].sSentToPyrlDt, LOW_DATE) == 0)
	  {
          fOkayToUpdate = true;
      }

      // Amounts or something is off, Let's go figure out what kind of adjustments or corrections to make
      if (fTmpAmt != RS.fImpdNetAmt  ||  fOkayToUpdate == true)
      {
         fAdjAmt = RS.fImpdNetAmt;      // Init with full amt

         // Loop through all the records
         for (rec_ndx=0; rec_ndx < RS.TotalTrpImpdValRecs; rec_ndx++)
         {

            // See if this record has been reported to Payroll yet
            // If not, we can update this record. If it has, we can't touch the record.
            if (strcmp(RS.TripImpdValRecs[rec_ndx].sSentToPyrlDt, LOW_DATE) == 0)
            {
               // This one has NOT been sent to Payroll yet. Make corrections/adjustments
               RS.TripImpdValRecs[rec_ndx].fImpdNetAmt = fAdjAmt;


               // Update all the values in this record
               TPM_8006_UpdateImpdValRecord(RS.TripImpdValRecs[rec_ndx].nImpdValSqlNb,
                                            RS.cImpdTrvlBandCd,
                                            RS.lTotalImpdMiCt,
                                            RS.sTrpOrigCtyId,
                                            RS.sTrpDestCtyId,
                                            RS.sTrpDprtDt,
                                            RS.TripImpdValRecs[rec_ndx].fImpdNetAmt);
            }

            fAdjAmt -= RS.TripImpdValRecs[rec_ndx].fImpdNetAmt;
         }

         if (fAdjAmt > 0.0) {
            TPM_5000_InsertTrpImpdVal(RS.TotalTrpImpdValRecs+1, fAdjAmt);
         }
      }
	  else {
         //
         // 4/2/2010 - Per Mary Barrett we should not touch any reported records
         //
         //// Whew... the amounts all match, so just make sure the trip data is correct
         //for (rec_ndx=0, fTmpAmt=0.0; rec_ndx < RS.TotalTrpImpdValRecs; rec_ndx++)
         //{
         //
         //   if ((RS.TripImpdValRecs[rec_ndx].lTotImpdMiCt != RS.lTotalImpdMiCt)  ||
         //       (strcmp(RS.TripImpdValRecs[rec_ndx].sTrpOrigCtyId, RS.sTrpOrigCtyId) != 0) ||
         //       (strcmp(RS.TripImpdValRecs[rec_ndx].sTrpDestCtyId, RS.sTrpDestCtyId) != 0) ||
         //       (strcmp(RS.TripImpdValRecs[rec_ndx].sTrpDprtDt,    RS.sTrpDprtDt)    != 0))
         //   {
         //      // Just synch up Mileage and Orig/Dest City info
         //      TPM_8006_UpdateImpdValRecord(RS.TripImpdValRecs[rec_ndx].nImpdValSqlNb,
         //                                   RS.cImpdTrvlBandCd,
         //                                   RS.lTotalImpdMiCt,
         //                                   RS.sTrpOrigCtyId,
         //                                   RS.sTrpDestCtyId,
         //                                   RS.sTrpDprtDt,
         //                                   RS.TripImpdValRecs[rec_ndx].fImpdNetAmt);
         //   }
         //}

         printf("  Matched existing Trp_Impd_Val Recs: PPR:%s-%s, %s %i, Trip:%s %s %3.2f\n",
            RS.sPprNbr, RS.sNrevNbr, RS.sNrapCd, RS.nNrapSpgmNb,
            RS.sTrpOrigCtyId, RS.sTrpDestCtyId, RS.fImpdNetAmt);
         RS.Match_Trip_Cnt++;
      }
   }

   // Update all the flown FLegs for this trip as processed
   // (those that haven't been processed yet)
   TPM_8009_UpdateFlwnFlegAsProcessed();


   printf("Processing Complete\n");
}


/******************************************************************
**                                                               **
** Function Name:   TPM_5000_InsertTrpImpdVal()                  **
**                                                               **
** Description:     Call function to insert a record into the    **
**                  NRAP_FLWN_FL table                           **
**                                                               **
** Arguments:       NetAmt                                       **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_5000_InsertTrpImpdVal(short nSqlNb, float fNetAmt)
{

   memset(&R04750, LOW_VALUES, sizeof(_R04750));
   memset(&A04750, LOW_VALUES, sizeof(_A04750));

   strcpy(R04750.R04750_appl_area.sPprNbr,          RS.sPprNbr);
   strcpy(R04750.R04750_appl_area.sNrevNbr,         RS.sNrevNbr);
   strcpy(R04750.R04750_appl_area.sNrapCd,          RS.sNrapCd);
   R04750.R04750_appl_area.nNrapSpgmNb            = RS.nNrapSpgmNb;
   strcpy(R04750.R04750_appl_area.sNrapFrstBkgLdt,  RS.sNrapFrstBkgLdt);
   R04750.R04750_appl_area.nNrapTrpSqNb           = RS.nNrapTrpSqNb;
   R04750.R04750_appl_area.nImpdValSqlNb          = nSqlNb;
   R04750.R04750_appl_area.cImpdTrvlBandCd        = RS.cImpdTrvlBandCd;
   R04750.R04750_appl_area.cOwrtCd                = RS.cOwrtCd;
   R04750.R04750_appl_area.cTrp1099Ind            = RS.cTrp1099Ind;
   R04750.R04750_appl_area.lTotImpdMiCt           = RS.lTotalImpdMiCt;

   R04750.R04750_appl_area.fImpdNetAmt            = fNetAmt;

   strcpy(R04750.R04750_appl_area.sSentToPyrlDt,    LOW_DATE);
   strcpy(R04750.R04750_appl_area.sTrpOrigCtyId,    RS.sTrpOrigCtyId);
   strcpy(R04750.R04750_appl_area.sTrpDestCtyId,    RS.sTrpDestCtyId);
   strcpy(R04750.R04750_appl_area.sTrpDprtDt,       RS.sTrpDprtDt);
   strcpy(R04750.R04750_appl_area.sLstUpdtId,       MODULE_NAME);


   /*******Write to NRAP_TRP_IMPD_VAL Table ***/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0, &R04750, &A04750, SERVICE_ID_04750, 1, sizeof(R04750.R04750_appl_area));

   switch (nSvcRtnCd)
   {
     case ARC_SUCCESS:
        printf("  Inserted Trp_Impd_Val Rec: PPR:%s-%s, %s %i, Trip:%s %s %3.2f\n",
          RS.sPprNbr, RS.sNrevNbr, RS.sNrapCd, RS.nNrapSpgmNb, RS.sTrpOrigCtyId, RS.sTrpDestCtyId, fNetAmt);
        RS.New_Trip_Cnt++;
        break;
     default:
        RS.Error_Cnt++;   // Log runtime error
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS04750");
        sprintf(sErrorMessage,
           "\n  PPR=%s-%s, NRapCd=%s, NRapSpgm=%i, NRapTrpNbr=%s, Orig=%s, Dest=%s",
           R04750.R04750_appl_area.sPprNbr,
           R04750.R04750_appl_area.sNrevNbr,
           R04750.R04750_appl_area.sNrapCd,
           R04750.R04750_appl_area.nNrapSpgmNb,
           R04750.R04750_appl_area.nNrapTrpSqNb,
           R04750.R04750_appl_area.sTrpOrigCtyId,
           R04750.R04750_appl_area.sTrpDestCtyId);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5000_InsertTrpImpdVal");
        break;
   }

}



/******************************************************************
**                                                               **
** Function Name:   TPM_8001_GetDistinctTrip                     **
**                                                               **
** Description:     Call function to identify a trip that needs  **
**                  to be imputed or get next row.               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   Arch Service Return code                     **
**                                                               **
******************************************************************/

short  TPM_8001_GetDistinctTrip(char CursorOpTxt, char *sPrmyTktNb)
{
   short svc_rc;


   switch (CursorOpTxt)
   {

      case OPEN_AND_FETCH :

         memset(&R04745, LOW_VALUES, sizeof(R04745));
         memset(&A04745, LOW_VALUES, sizeof(A04745));
         R04745.R04745_appl_area.nNumDaysPastFltDprtDt = RS.numDaysPastFltDepartDate;
         R04745.R04745_appl_area.cArchCursorOpTxt      = OPEN_AND_FETCH;
         svc_rc = BCH_InvokeService(EPBINQ2, &R04745, &A04745, SERVICE_ID_04745, 1, sizeof(R04745.R04745_appl_area));
         break;

      case FETCH_ROW:

         // Get next Ticket Number
         memset(&R04745, LOW_VALUES, sizeof(R04745));
         memset(&A04745, LOW_VALUES, sizeof(A04745));
         R04745.R04745_appl_area.cArchCursorOpTxt = FETCH_ROW;
         svc_rc = BCH_InvokeService(EPBINQ2, &R04745, &A04745, SERVICE_ID_04745, 1, sizeof(R04745));
         break;

      case CLOSE_CURSOR :

         // Close the cursor
         R04745.R04745_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
         svc_rc = BCH_InvokeService(EPBINQ2, &R04745, &A04745, SERVICE_ID_04745, 1, sizeof(R04745));
         return ARC_SUCCESS;

   }

   switch (svc_rc) {
      case ARC_SUCCESS:
           strcpy(sPrmyTktNb, A04745.A04745_appl_area.sPrmyTktDocNb);
         break;
      case ARC_ROW_NOT_FOUND:
           strcpy(sPrmyTktNb, NULL_STRING);
         break;
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04745");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8001_GetDistinctTrips");
   }

   return svc_rc;

}



/******************************************************************
**                                                               **
** Function Name:   TPM_8002_LoadTripCoupons                     **
**                                                               **
** Description:     Call function to identify a trip that needs  **
**                  to be imputed or get next row.               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void TPM_8002_LoadTripCoupons(char *sPrmyTktDocNb)
{
   int ndx;

   memset(RS.TripCoupons, 0, sizeof(RS.TripCoupons));
   RS.TotalCoupons = 0;

   // Open Cursor and read in first Coupon
   memset(&R04746, LOW_VALUES, sizeof(R04746));
   memset(&A04746, LOW_VALUES, sizeof(A04746));
   strcpy(R04746.R04746_appl_area.sPrmyTktDocNb, sPrmyTktDocNb);
   R04746.R04746_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   nSvcRtnCd = BCH_InvokeService(EPBINQ1, &R04746, &A04746, SERVICE_ID_04746, 1, sizeof(R04746.R04746_appl_area));

   //
   // While there are coupons, load them into coupon array
   // (there should always be at least one or we wouldn't be in this function)
   //
   for (ndx=0; ndx < 16  &&   nSvcRtnCd != ARC_ROW_NOT_FOUND;  ++ndx)
   {
      if (nSvcRtnCd != ARC_SUCCESS)  {
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04746");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8002_LoadTripCoupons");
      }

      // We just loaded a coupon out of the database
      // so load it into our coupon array
      RS.TotalCoupons++;

      strcpy(RS.TripCoupons[ndx].sPprNbr,          A04746.A04746_appl_area.sPprNbr);
      strcpy(RS.TripCoupons[ndx].sNrevNbr,         A04746.A04746_appl_area.sNrevNbr);
      strcpy(RS.TripCoupons[ndx].sFltOrigCtyId,    A04746.A04746_appl_area.sFltOrigCtyId);
      strcpy(RS.TripCoupons[ndx].sFltDestCtyId,    A04746.A04746_appl_area.sFltDestCtyId);
      strcpy(RS.TripCoupons[ndx].sFltDprtDt,       A04746.A04746_appl_area.sFltDprtDt);
      strcpy(RS.TripCoupons[ndx].sFltNbr,          A04746.A04746_appl_area.sFltNbr);
      strcpy(RS.TripCoupons[ndx].sNrapCd,          A04746.A04746_appl_area.sNrapCd);
      RS.TripCoupons[ndx].nNrapSpgmNb            = A04746.A04746_appl_area.nNrapSpgmNb;
      strcpy(RS.TripCoupons[ndx].sNrapFrstBkgLdt,  A04746.A04746_appl_area.sNrapFrstBkgLdt);
      RS.TripCoupons[ndx].nNrapTrpSqNb           = A04746.A04746_appl_area.nNrapTrpSqNb;
      strcpy(RS.TripCoupons[ndx].sPrmyTktDocNb,    A04746.A04746_appl_area.sPrmyTktDocNb);
      strcpy(RS.TripCoupons[ndx].sTktDocNbr,       A04746.A04746_appl_area.sTktDocNb);
      strcpy(RS.TripCoupons[ndx].sTktDocIssDt,     A04746.A04746_appl_area.sTktDocIssLdt);
      RS.TripCoupons[ndx].nTktDocSqNb            = A04746.A04746_appl_area.nTktDocSqNb;
      RS.TripCoupons[ndx].nTktCpnNb              = A04746.A04746_appl_area.nTktCpnNb;
      RS.TripCoupons[ndx].cRoundTripInd          = A04746.A04746_appl_area.cRndTrpInd;
      RS.TripCoupons[ndx].lLegMileage            = A04746.A04746_appl_area.lFltLegMiCt;
      strcpy(RS.TripCoupons[ndx].sProcdForImptnDt, A04746.A04746_appl_area.sProcdForImptnDt);

	  //---------------------------------------------
      // Fix Anomoly: There are cases where we can get multiple Coupon #1 on the date of departure (Exchanges)
      // Example where they get loaded out of proper sequence:
      //   0.     Exch  Ticket #:  0062328167984  Cpn 1   10OCT JFK CDG
      //   1.  Original Ticket #:  0062328156687  Cpn 1   10OCT TPA JFK  <--- this is first leg!
      //   2.  Original Ticket #:  0062328156687  Cpn 3   19OCT CDG BOS
      //   3.  Original Ticket #:  0062328156687  Cpn 4   19OCT BOS TPA
      if (ndx == 1 &&
          RS.TripCoupons[0].nTktCpnNb == 1  &&
          RS.TripCoupons[1].nTktCpnNb == 1  &&
          strcmp(RS.TripCoupons[0].sFltDprtDt,    RS.TripCoupons[1].sFltDprtDt)    == 0  &&
          strcmp(RS.TripCoupons[0].sFltOrigCtyId, RS.TripCoupons[1].sFltDestCtyId) == 0)
      {
         // Out of order!  Swap the 1st and 2nd coupons
         //---- Coupon 1 -----
         strcpy(RS.TripCoupons[1].sPprNbr,          RS.TripCoupons[0].sPprNbr);
         strcpy(RS.TripCoupons[1].sNrevNbr,         RS.TripCoupons[0].sNrevNbr);
         strcpy(RS.TripCoupons[1].sFltOrigCtyId,    RS.TripCoupons[0].sFltOrigCtyId);
         strcpy(RS.TripCoupons[1].sFltDestCtyId,    RS.TripCoupons[0].sFltDestCtyId);
         strcpy(RS.TripCoupons[1].sFltDprtDt,       RS.TripCoupons[0].sFltDprtDt);
         strcpy(RS.TripCoupons[1].sFltNbr,          RS.TripCoupons[0].sFltNbr);
         strcpy(RS.TripCoupons[1].sNrapCd,          RS.TripCoupons[0].sNrapCd);
         RS.TripCoupons[1].nNrapSpgmNb            = RS.TripCoupons[0].nNrapSpgmNb;
         strcpy(RS.TripCoupons[1].sNrapFrstBkgLdt,  RS.TripCoupons[0].sNrapFrstBkgLdt);
         RS.TripCoupons[1].nNrapTrpSqNb           = RS.TripCoupons[0].nNrapTrpSqNb;
         strcpy(RS.TripCoupons[1].sPrmyTktDocNb,    RS.TripCoupons[0].sPrmyTktDocNb);
         strcpy(RS.TripCoupons[1].sTktDocNbr,       RS.TripCoupons[0].sTktDocNbr);
         strcpy(RS.TripCoupons[1].sTktDocIssDt,     RS.TripCoupons[0].sTktDocIssDt);
         RS.TripCoupons[1].nTktDocSqNb            = RS.TripCoupons[0].nTktDocSqNb;
         RS.TripCoupons[1].nTktCpnNb              = RS.TripCoupons[0].nTktCpnNb;
         RS.TripCoupons[1].cRoundTripInd          = RS.TripCoupons[0].cRoundTripInd;
         RS.TripCoupons[1].lLegMileage            = RS.TripCoupons[0].lLegMileage;
         strcpy(RS.TripCoupons[1].sProcdForImptnDt, RS.TripCoupons[0].sProcdForImptnDt);

         //---- Coupon 0 -----
         strcpy(RS.TripCoupons[0].sPprNbr,          A04746.A04746_appl_area.sPprNbr);
         strcpy(RS.TripCoupons[0].sNrevNbr,         A04746.A04746_appl_area.sNrevNbr);
         strcpy(RS.TripCoupons[0].sFltOrigCtyId,    A04746.A04746_appl_area.sFltOrigCtyId);
         strcpy(RS.TripCoupons[0].sFltDestCtyId,    A04746.A04746_appl_area.sFltDestCtyId);
         strcpy(RS.TripCoupons[0].sFltDprtDt,       A04746.A04746_appl_area.sFltDprtDt);
         strcpy(RS.TripCoupons[0].sFltNbr,          A04746.A04746_appl_area.sFltNbr);
         strcpy(RS.TripCoupons[0].sNrapCd,          A04746.A04746_appl_area.sNrapCd);
         RS.TripCoupons[0].nNrapSpgmNb            = A04746.A04746_appl_area.nNrapSpgmNb;
         strcpy(RS.TripCoupons[0].sNrapFrstBkgLdt,  A04746.A04746_appl_area.sNrapFrstBkgLdt);
         RS.TripCoupons[0].nNrapTrpSqNb           = A04746.A04746_appl_area.nNrapTrpSqNb;
         strcpy(RS.TripCoupons[0].sPrmyTktDocNb,    A04746.A04746_appl_area.sPrmyTktDocNb);
         strcpy(RS.TripCoupons[0].sTktDocNbr,       A04746.A04746_appl_area.sTktDocNb);
         strcpy(RS.TripCoupons[0].sTktDocIssDt,     A04746.A04746_appl_area.sTktDocIssLdt);
         RS.TripCoupons[0].nTktDocSqNb            = A04746.A04746_appl_area.nTktDocSqNb;
         RS.TripCoupons[0].nTktCpnNb              = A04746.A04746_appl_area.nTktCpnNb;
         RS.TripCoupons[0].cRoundTripInd          = A04746.A04746_appl_area.cRndTrpInd;
         RS.TripCoupons[0].lLegMileage            = A04746.A04746_appl_area.lFltLegMiCt;
         strcpy(RS.TripCoupons[0].sProcdForImptnDt, A04746.A04746_appl_area.sProcdForImptnDt);
      }
	  //---------------------------------------------

      // Read in the next coupon (if available)
      memset(&R04746, LOW_VALUES, sizeof(R04746));
      memset(&A04746, LOW_VALUES, sizeof(A04746));
      R04746.R04746_appl_area.cArchCursorOpTxt = FETCH_ROW;
      nSvcRtnCd = BCH_InvokeService(EPBINQ1, &R04746, &A04746, SERVICE_ID_04746, 1, sizeof(R04746.R04746_appl_area));
   }

   // Close the cursor
   R04746.R04746_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
   BCH_InvokeService(EPBINQ1, &R04746, &A04746, SERVICE_ID_04746, 1, sizeof(R04746));

}


/******************************************************************
**                                                               **
** Function Name:   TPM_8003_DetermineOrigDest                   **
**                                                               **
** Description:     Call function to determine the origin city   **
**                  and distination city related to this trip    **
**                  Logic: Dest City with greatest mileage from  **
**                         Origin City is the Trip destination.  **
**                  Uses Airport Pair Mileage table to get       **
**                  mileage between cities.                      **
**                                                               **
** Turn around point:  1st instance in the ticketed itinerary    **
** where the off point of segment-X is equal to the board point  **
** of any previous segment, then the turnaround point is the     **
** board point of segment-X.                                     **
**                                                               **
**                                                               **
** Arguments:       None, but assumes coupons are loaded in      **
**                  TripCoupons array.                           **
**                                                               **
** Return Values:   0 = function successful                      **
**                 -1 = function failed                          **
**                                                               **
******************************************************************/

int  TPM_8003_DetermineOrigDest()
{
   short first_cpn_ndx, cpn_ndx;
   char  *psCity, *prevCity;
   char  *psFurthestDestDateOfTravel;
   char  *psLastCtyOnFirstDateOfTravel;

   // Initialize Cities & Mileage
   strcpy(RS.sTrpOrigCtyId,  RS.TripCoupons[0].sFltOrigCtyId);
   strcpy(RS.sTrpDestCtyId,  RS.TripCoupons[0].sFltDestCtyId);
   strcpy(RS.sTrpDprtDt,     RS.TripCoupons[0].sFltDprtDt);
   RS.lTripOWMileage = 0;
   psFurthestDestDateOfTravel   = RS.TripCoupons[0].sFltDprtDt;
   psLastCtyOnFirstDateOfTravel = RS.TripCoupons[0].sFltDestCtyId;
   prevCity = RS.TripCoupons[0].sFltOrigCtyId;


   // Loop through all the coupons. Find the City furthest from Origin.
   for (cpn_ndx=0;  cpn_ndx < RS.TotalCoupons; cpn_ndx++)
   {

      // There are cases where we don't always get all the coupons,
      // so we are going to test ALL cities (orig and dest)

      // Work with Origin City
      psCity = RS.TripCoupons[cpn_ndx].sFltOrigCtyId;
      if (strcmp(psCity, RS.sTrpOrigCtyId) != 0  &&  strcmp(psCity, prevCity) != 0)
      {
         // Get mileage between this city pair
         memset(&R02792, LOW_VALUES, sizeof(R02792));
         memset(&A02792, LOW_VALUES, sizeof(A02792));
         strcpy(R02792.R02792_appl_area.sFltOrigCtyId,  RS.sTrpOrigCtyId);
         strcpy(R02792.R02792_appl_area.sFltDestCtyId,  psCity);
         nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02792,&A02792,SERVICE_ID_02792,1,sizeof(R02792.R02792_appl_area));

         if (nSvcRtnCd != ARC_SUCCESS) {
            printf("  City Pair (%s - %s) not found in T_ARPT_PR_MI table.  Trip Ignored\n", RS.sTrpOrigCtyId, psCity);
            RS.Ignore_Cnt++;
            return 1;
         }

         if (A02792.A02792_appl_area.lFltArptPrNbr > RS.lTripOWMileage) {
            RS.lTripOWMileage = A02792.A02792_appl_area.lFltArptPrNbr;
            strcpy(RS.sTrpDestCtyId, psCity);
            RS.lTotalImpdMiCt = RS.lTripOWMileage * 2;
			psFurthestDestDateOfTravel = RS.TripCoupons[cpn_ndx].sFltDprtDt;
         }
      }
      prevCity = psCity;

      // Work with Destination City
      psCity = RS.TripCoupons[cpn_ndx].sFltDestCtyId;
      if (strcmp(psCity, RS.sTrpOrigCtyId) != 0  &&  strcmp(psCity, prevCity) != 0)
      {

         // Get mileage between this city pair
         memset(&R02792, LOW_VALUES, sizeof(R02792));
         memset(&A02792, LOW_VALUES, sizeof(A02792));
         strcpy(R02792.R02792_appl_area.sFltOrigCtyId,  RS.sTrpOrigCtyId);
         strcpy(R02792.R02792_appl_area.sFltDestCtyId,  psCity);
         nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02792,&A02792,SERVICE_ID_02792,1,sizeof(R02792.R02792_appl_area));

         if (nSvcRtnCd != ARC_SUCCESS) {
            printf("  City Pair (%s - %s) not found in T_ARPT_PR_MI table.  Trip Ignored\n", RS.sTrpOrigCtyId, psCity);
            RS.Ignore_Cnt++;
            return 1;
         }

         if (A02792.A02792_appl_area.lFltArptPrNbr > RS.lTripOWMileage) {
            RS.lTripOWMileage = A02792.A02792_appl_area.lFltArptPrNbr;
            strcpy(RS.sTrpDestCtyId, psCity);
            RS.lTotalImpdMiCt = RS.lTripOWMileage * 2;
			psFurthestDestDateOfTravel = RS.TripCoupons[cpn_ndx].sFltDprtDt;
         }

      }
      prevCity = psCity;

      // Save last dest city on first date of travel (as long as not origin city)
      // (Seriously, why would someone go out and back on the same day... but some do)
      if (strcmp(RS.TripCoupons[cpn_ndx].sFltDprtDt, RS.sTrpDprtDt) == 0  &&
          strcmp(RS.TripCoupons[cpn_ndx].sFltDestCtyId, RS.sTrpOrigCtyId) != 0)
      {
         psLastCtyOnFirstDateOfTravel = RS.TripCoupons[cpn_ndx].sFltDestCtyId;
	  }
   }

   //------------------------------------------------
   //  Determine Turnaround Point
   //  There are 4 steps at determining destintation
   //------------------------------------------------

   // Step 1) The turnaround point is currently set to the furthest point from city of origin
   //         This isn't always the case since you often have to travel through a hub and may double back (ATL,LAX,etc.)
   //
   // RS.sTrpDestCityId = is already set to furthest city from origin city
   printf("  TPM_8003_DetermineOrigDest() - Step 1: RS.sTrpDestCityId = %s\n", RS.sTrpDestCtyId);

   // Step 2) Since most people tend to stay overnight at dest, we are going to assume dest of last leg
   //         on Trip Departure Date is actual destination (as long as dest does not match Trip Orig City).
   //         However, if date of travel to furthest dest is different than Trip Departure Date,
   //         then that is dest.
   //
   // If Date of Travel of the furthest city is same as Trip Dprt Date use last dest city on
   // Trip Departure Date as the turnaround point
   // (This solves that AAA->LAX->LAS or AAA->ATL->MCO problem, where LAX or ATL is furthest point)
   if (strcmp(psFurthestDestDateOfTravel, RS.sTrpDprtDt) == 0) {
         strcpy(RS.sTrpDestCtyId, psLastCtyOnFirstDateOfTravel);
   }
   printf("  TPM_8003_DetermineOrigDest() - Step 2: RS.sTrpDestCityId = %s\n", RS.sTrpDestCtyId);

   // Step 3) However, should we happen to have enough coupons to determine the turnaround point,
   // loop through all the coupons and see if we need to override the dest city
   //
   // This override logic will only work when both coupons at the turnaround are present.
   //        New turnaround point = 1st instance in the ticketed itinerary where the off point
   //        of "segment X" is equal to the board point of the previous segment, then the
   //        turnaround point is the board point of "segment X".
   for (cpn_ndx=1; (cpn_ndx < RS.TotalCoupons); cpn_ndx++)
   {
      if (strcmp(RS.TripCoupons[cpn_ndx].sFltDestCtyId, RS.TripCoupons[cpn_ndx-1].sFltOrigCtyId) == 0)
      {  // Found the real turnaround point
         strcpy(RS.sTrpDestCtyId,  RS.TripCoupons[cpn_ndx].sFltOrigCtyId);
         break;
      }
   }
   printf("  TPM_8003_DetermineOrigDest() - Step 3: RS.sTrpDestCityId = %s\n", RS.sTrpDestCtyId);

   // Step 4) Finally, if the turnaround point is used as a connection city on any day of travel,
   //         then use the board point of the first leg of the connection as the turnaround point
   for (cpn_ndx=1; (cpn_ndx < RS.TotalCoupons-1); cpn_ndx++)
   {
      if (strcmp(RS.TripCoupons[cpn_ndx].sFltDestCtyId, RS.sTrpDestCtyId)   == 0 &&
          strcmp(RS.TripCoupons[cpn_ndx+1].sFltOrigCtyId, RS.sTrpDestCtyId) == 0 &&
		  strcmp(RS.TripCoupons[cpn_ndx].sFltDprtDt, RS.TripCoupons[cpn_ndx+1].sFltDprtDt) == 0)
      {
         // We are connecting through current DestCity, so turnaround point is origin city
         strcpy(RS.sTrpDestCtyId, RS.TripCoupons[cpn_ndx].sFltOrigCtyId);
         break;
      }
   }
   printf("  TPM_8003_DetermineOrigDest() - Step 4: RS.sTrpDestCityId = %s\n", RS.sTrpDestCtyId);


   printf("  Found Trip: %s %s : RT Mileage=%ld\n", RS.sTrpOrigCtyId, RS.sTrpDestCtyId, RS.lTripOWMileage * 2);

   return 0;
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8004_ApplyTravelBand                     **
**                                                               **
** Description:     Call function to apply the applicable travel **
**                  band to the trip to obtain the Imputed Travel**
**                  Band amount (in dollars) based on Round Trip **
**                  mileage.                                     **
**                                                               **
** Arguments:       None, but expects RS.lTripOWMileage          **
**                                                               **
** Return Values:   0 = function successful                      **
**                 -1 = function failed                          **
**                                                               **
******************************************************************/

int  TPM_8004_ApplyTravelBand()
{

   // Fetch RT Travel Band Amount based on mileage
   memset(&R04751, LOW_VALUES, sizeof(R04751));
   memset(&A04751, LOW_VALUES, sizeof(A04751));

   strcpy(R04751.R04751_appl_area.sFltDprtDt,  RS.sFltDprtDt);  // Use FltDprtDt of first leg
   R04751.R04751_appl_area.cOwrtCd           = RS.cOwrtCd;
   R04751.R04751_appl_area.lTotImpdMiCt      = RS.lTotalImpdMiCt;

   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04751,&A04751,SERVICE_ID_04751,1,sizeof(R04751.R04751_appl_area));

   if (nSvcRtnCd != ARC_SUCCESS) {
      printf("  Unable to obtain Travel Band for Trip. Trip Ignored. RT Mileage=%ld\n", RS.lTotalImpdMiCt);
      RS.Ignore_Cnt++;
      return 1;
   }

   RS.cImpdTrvlBandCd = A04751.A04751_appl_area.cImpdTrvlBndCd;
   RS.fImpdNetAmt     = A04751.A04751_appl_area.fImptdTrvlBandAmt;

   return 0;
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8005_LoadTripImpdValRecords              **
**                                                               **
** Description:     Call function to load all the TrpImpdVal     **
**                  records for this PPR                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void TPM_8005_LoadTripImpdValRecords()
{
   int ndx;

   memset(RS.TripImpdValRecs, 0, sizeof(RS.TripImpdValRecs));
   RS.TotalTrpImpdValRecs = 0;

   // Open Cursor and read in first TripImpdVal Record
   memset(&R04752, LOW_VALUES, sizeof(_R04752));
   memset(&A04752, LOW_VALUES, sizeof(_A04752));

   strcpy(R04752.R04752_appl_area.sPprNbr,RS.sPprNbr);
   strcpy(R04752.R04752_appl_area.sNrevNbr,RS.sNrevNbr);
   strcpy(R04752.R04752_appl_area.sNrapCd,RS.sNrapCd);
   R04752.R04752_appl_area.nNrapSpgmNb = RS.nNrapSpgmNb;
   strcpy(R04752.R04752_appl_area.sNrapFrstBkgLdt,RS.sNrapFrstBkgLdt);
   R04752.R04752_appl_area.nNrapTrpSqNb = RS.nNrapTrpSqNb;

   R04752.R04752_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   nSvcRtnCd = BCH_InvokeService(EPBINQ1, &R04752, &A04752, SERVICE_ID_04752, 1, sizeof(R04752.R04752_appl_area));

   //
   // While there are records, load up to 4 matching records into record array
   //
   for (ndx=0; ndx < 4  &&   nSvcRtnCd != ARC_ROW_NOT_FOUND;   )
   {
      if (nSvcRtnCd != ARC_SUCCESS)  {
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC,"FYS04752");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8006_LoadTripImpdValRecords");
      }

      // We just loaded a record out of the database.
      // Load it into our TrpImpdValRec Array if the origin city matches.
      RS.TotalTrpImpdValRecs++;

      strcpy(RS.TripImpdValRecs[ndx].sPprNbr,         A04752.A04752_appl_area.sPprNbr);
      strcpy(RS.TripImpdValRecs[ndx].sNrevNbr,        A04752.A04752_appl_area.sNrevNbr);
      strcpy(RS.TripImpdValRecs[ndx].sNrapCd,         A04752.A04752_appl_area.sNrapCd);
      RS.TripImpdValRecs[ndx].nNrapSpgmNb           = A04752.A04752_appl_area.nNrapSpgmNb;
      strcpy(RS.TripImpdValRecs[ndx].sNrapFrstBkgLdt, A04752.A04752_appl_area.sNrapFrstBkgLdt);
      RS.TripImpdValRecs[ndx].nNrapTrpSqNb          = A04752.A04752_appl_area.nNrapTrpSqNb;

      RS.TripImpdValRecs[ndx].nImpdValSqlNb         = A04752.A04752_appl_area.nImpdValSqlNb;
      RS.TripImpdValRecs[ndx].cImpdTrvlBandCd       = A04752.A04752_appl_area.cImpdTrvlBandCd;
      RS.TripImpdValRecs[ndx].lTotImpdMiCt          = A04752.A04752_appl_area.lTotImpdMiCt;
      RS.TripImpdValRecs[ndx].fImpdNetAmt           = A04752.A04752_appl_area.fImpdNetAmt;
      strcpy(RS.TripImpdValRecs[ndx].sTrpOrigCtyId,   A04752.A04752_appl_area.sTrpOrigCtyId);
      strcpy(RS.TripImpdValRecs[ndx].sTrpDestCtyId,   A04752.A04752_appl_area.sTrpDestCtyId);
      strcpy(RS.TripImpdValRecs[ndx].sTrpDprtDt,      A04752.A04752_appl_area.sTrpDprtDt);
      strcpy(RS.TripImpdValRecs[ndx].sSentToPyrlDt,   A04752.A04752_appl_area.sSentToPyrlDt);

      // Read in the next record (if it exists)
      memset(&R04752, LOW_VALUES, sizeof(R04752));
      memset(&A04752, LOW_VALUES, sizeof(A04752));
      R04752.R04752_appl_area.cArchCursorOpTxt = FETCH_ROW;
      nSvcRtnCd = BCH_InvokeService(EPBINQ1, &R04752, &A04752, SERVICE_ID_04752, 1, sizeof(R04752.R04752_appl_area));
   }

   // Close the cursor
   R04752.R04752_appl_area.cArchCursorOpTxt = CLOSE_CURSOR;
   BCH_InvokeService(EPBINQ1, &R04752, &A04752, SERVICE_ID_04752, 1, sizeof(R04752));

}

/******************************************************************
**                                                               **
** Function Name:   TPM_8006_UpdateImpdValRecord                 **
**                                                               **
** Description:     Call function to set update various fields   **
**                  in specified NRAP_TRP_IMPD_VAL record        **
**                  trip.                                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void  TPM_8006_UpdateImpdValRecord(short  nRecSqlNb,
                                   char   cTrvlBandCd,
                                   long   lTotMiCt,
                                   char   sOrig[],
                                   char   sDest[],
                                   char   sTrpDprtDt[],
                                   float  fNetAmt)
{
  memset(&R04749, LOW_VALUES, sizeof(_R04749));
  memset(&A04749, LOW_VALUES, sizeof(_A04749));

  strcpy(R04749.R04749_appl_area.sPprNbr,         RS.sPprNbr);
  strcpy(R04749.R04749_appl_area.sNrevNbr,        RS.sNrevNbr);
  strcpy(R04749.R04749_appl_area.sNrapCd,         RS.sNrapCd);
  R04749.R04749_appl_area.nNrapSpgmNb           = RS.nNrapSpgmNb;
  strcpy(R04749.R04749_appl_area.sNrapFrstBkgLdt, RS.sNrapFrstBkgLdt);
  R04749.R04749_appl_area.nNrapTrpSqNb          = RS.nNrapTrpSqNb;
  //--- now apply parms
  R04749.R04749_appl_area.nImpdValSqlNb         = nRecSqlNb;
  R04749.R04749_appl_area.cImpdTrvlBandCd       = cTrvlBandCd;
  R04749.R04749_appl_area.lTotImpdMiCt          = lTotMiCt;
  R04749.R04749_appl_area.fImpdNetAmt           = fNetAmt;
  strcpy(R04749.R04749_appl_area.sTrpOrigCtyId,   sOrig);
  strcpy(R04749.R04749_appl_area.sTrpDestCtyId,   sDest);
  strcpy(R04749.R04749_appl_area.sTrpDprtDt,      sTrpDprtDt);
  R04749.R04749_appl_area.fImpdNetAmt           = fNetAmt;
  strcpy(R04749.R04749_appl_area.sLstUpdtId,      MODULE_NAME);

  /*******Update NRAP_TRP_IMPD_VAL record ***/
  nSvcRtnCd = BCH_InvokeService(EPBUPD0, &R04749, &A04749, SERVICE_ID_04749, 1, sizeof(R04749.R04749_appl_area));

  switch (nSvcRtnCd)
  {
    case ARC_SUCCESS:
       printf("  Updated Trp_Impd_Val Rec: PPR:%s-%s, %s %i, Trip:%s %s %3.2f\n",
            RS.sPprNbr, RS.sNrevNbr, RS.sNrapCd, RS.nNrapSpgmNb, sOrig, sDest, fNetAmt);
       RS.Upd_Trip_Cnt++;
       break;
    default:
       RS.Error_Cnt++;   // Log runtime error
       BCH_FormatMessage(1,TXT_SVC_UNSUCC);
       BCH_FormatMessage(2,TXT_SVC, "FYS04749");
       sprintf(sErrorMessage,
          "\n  PPR=%s-%s, Primary Tkt Nbr=%s, Orig=%s, Dest=%s",
          RS.sPprNbr,
          RS.sNrevNbr,
          RS.TripCoupons[0].sPrmyTktDocNb,
          RS.sTrpOrigCtyId,
          RS.sTrpDestCtyId);
       BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8006_UpdateImpdValRecord");
       break;
  }

}


/******************************************************************
**                                                               **
** Function Name:   TPM_8009_UpdateFlwnFlegAsProcessed           **
**                                                               **
** Description:     Call function to set the Procd_Ior_Imptn_Dt  **
**                  date field for all the coupons for a given   **
**                  trip.                                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_8009_UpdateFlwnFlegAsProcessed()
{

   memset(&R04739, LOW_VALUES, sizeof(_R04739));
   memset(&A04739, LOW_VALUES, sizeof(_A04739));

   strcpy(R04739.R04739_appl_area.sPrmyTktDocNb, RS.TripCoupons[0].sPrmyTktDocNb);
   strcpy(R04739.R04739_appl_area.sLstUpdtId,    MODULE_NAME);

   /*******Write to RPAD_FLWN_FL_SPNS ***/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0, &R04739, &A04739, SERVICE_ID_04739, 1, sizeof(R04739.R04739_appl_area));

   switch (nSvcRtnCd)
   {
     case ARC_SUCCESS:
        break;
     default:
        RS.Error_Cnt++;   // Log runtime error
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS04739");
        sprintf(sErrorMessage,
           "\n  PPR=%s-%s, Primary Tkt Nbr=%s, Orig=%s, Dest=%s",
           RS.sPprNbr,
           RS.sNrevNbr,
           RS.TripCoupons[0].sPrmyTktDocNb,
           RS.sTrpOrigCtyId,
           RS.sTrpDestCtyId);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_8009_UpdateFlwnFlegAsProcessed");
        break;
   }

}


/******************************************************************
**                                                               **
** Function Name:   TPM_9000_ProcessEndOfProgram                 **
**                                                               **
** Description:     Call function to perform end of program      **
**                  housekeeping (close files, print summary)    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void  TPM_9000_ProcessEndOfProgram()
{
   static char totals_buffer[1024];

   endTime_ = time(0);

   /** Include any logic here for final clean-up processing  **/


   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, VersionStr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9000_ProcessEndOfProgram");


   /************************/
   /**    CONTROL TOTALS  **/
   /************************/

   sprintf(totals_buffer,
      "\n********* Module Information **********\n"
      "  Selected Trips %u days past Flt Depart Date\n"
      "  Processing Totals:\n"
      "    Total Trips selected to Impute  : %lu\n"
      "    Trip Imputed Value Recs Added   : %lu\n"
      "    Trip Imputed Value Recs Updated : %lu\n"
      "    Trip Imputed Value Recs Matched : %lu\n"
      "    Trips Ignored                   : %lu\n"
      "    Runtime Errors                  : %lu",
      RS.numDaysPastFltDepartDate,
      RS.Tot_Trip_Cnt,
      RS.New_Trip_Cnt,
      RS.Upd_Trip_Cnt,
      RS.Match_Trip_Cnt,
      RS.Ignore_Cnt,
      RS.Error_Cnt);
   puts(totals_buffer);        // print totals

   // Print start and end time;
   //     Note: can't call these both in the same call because
   //     time is stored in a static buffer.
   printf("    Time Job started:      %s",   asctime(localtime(&startupTime_)));
   printf("    Time Job completed:    %s\n", asctime(localtime(&endTime_)));

}


