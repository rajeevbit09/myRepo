/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB54002.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Faith Ammons                                           **
**                                                                         **
** Date Written:    8/16/95                                                **
**                                                                         **
** Description:     This program processes all items on the Charges Table  **
**                  that have not already been processed.  For each item   **
**                  to be processed, one of the following actions is taken:**
**                     1 - the information is written out to the Employee  **
**                         A/R Interface file,                             **
**                     2 - A billing invoice is created,                   **
**                     3 - the information is written out to the Worldspan **
**                         Detail Report. All information written to this  **
**                         report is summed up and then 1 Worldspan summary**
**                         item is written to the Employee A/R Interface.  **
**                     4 - the information is written out to the TransQuest**
**                         Detail Report. All information written to this  **
**                         report is summed up and then 1 TransQuest summary*
**                         item is written to the Eployee A/R Interface.   **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 3/21/96       FFA                    1) Added processing for new active **
**                                         with kids pass groups.          **
**                                                                         **
** 5/15/96       FFA                    2) Added processing for 3 new      **
**                                         Wordlspan pass groups.          **
**                                                                         **
** 11/07/96      FFA                    4) Fixed Rounding problem on empl  **
**                                         a/r feed                        **
**                                                                         **
** 11/22/96      GHM                    3) Added Worldspan file.           **
**                                         Changed service 2665 to retrieve**
**                                         nrev source code. Will use that **
**                                         instead of pass group to        **
**                                         determine whether person being  **
**                                         processed is Delta, Worldspan,  **
**                                         or TransQuest.                  **
**                                                                         **
** 08/10/97      SKM                    5) Changed service 2666 to retrive **
**                                         ppr social security number, to  **
**                                         include it on TQ detail report. **
**                                         TQ employees will have the same **
**                                         pass group code as Delta employ-**
**                                         ees, so added logic to exclude  **
**                                         TQ employees from sending them  **
**                                         to employee A/R interface file. **
**                                                                         **
** 10/16/97      LAS                    6) All charges including pass card **
**                                         charges will now go to GL debit **
**                                         account number 127100003.       ** 
**                                                                         **
** 4/22/98       SKM                    7) Added processing for DSS        **
**                                         Employees. Generate new detail  **
**                                         charge report for DSS employees.**
**                                         CSR number is 7982.             **
** 8/17/98       SKM                    8) For active DL and inactive DL   **
**                                         employees, all non flight       **  
**                                         related charges should go to    **
**                                         "12712" account.                **  
**                                         Change sales dept # on records  **
**                                         sent to AR from 819 to 956.     **  
**                                                                         **
** 8/24/98       LSW                    9) Added processing for Delay      **
**                                         Charge billing feature.  Delay  **
**                                         is for 45 days from current date**
**                                         As a part of the changes a new  **
**                                         process module was added called **
**                                         DPM_2510_CompareDates().  Also, **
**                                         the conditional processing for  **
**                                         the updating of the process date**
**                                         was changed into a function     **
**                                         called                          **
**                                         DPM_2520_UpdateProcessDate.     **
**                                                                         **
** 1/28/2000   LAS		       10) Added code to check for ASA     **
**                                         employees.                      **
**                                                                         **
** 6/7/2000    LSW                     11) Added if condition to check     **
**                                         for senior officers when proc_dt**
**                                         is updated and then call PL/SQL **
**                                         ap_02754 (R02754) to update the **
**                                         flt_acct_eff_dt                 **
**                                                                         **
** 8/15/00     EJS		       12) Added code to check for OH      **
**                                         employees.                      **
**                                                                         **
** 3/10/03     LAS                     13) Added code to check for SO      **
**                                         (song) employees.               **
**                                                                         **
** 4/09/03     LAS                     14) Write Song detail charges to a  **
**                                         file.                           **
**                                                                         **
** 4/29/03     LAS                     15) Write 127100002 charges to      **
**                                         127100003 account.              **
**                                                                         **
** 7/11/03     LAS                     16) Added code for Comair Academy   **
**                                         (CA) employees.                 **
**                                                                         **
** 8/11/03     LAS                     17) Added code to show connection   **
**                                         carrier (Skywest, ACA and       **
**                                         Chautaugua) charge records as   **
**                                         processed.                      **
**                                                                         **
** 5/30/06     EJS/LAS                 18) Write Skywest charges to a      **
**                                         file                            **
**                                                                         **
** 6/06/06     EJS                     19) Write Chautauqua charges to a   **
**                                         file                            **
**                                                                         **
** 2/20/07     LAS                     20) Write Big Sky and Express Jet   **
**                                         charges to files.               **
**                                                                         **
** 11/19/07    L.Scott                 21) Write Pinnacle charges to a     **
**                                         file.                           **
** 03/15/2009  G.Whitman               22) Mesaba charges (XJ)             **
** 03/15/2009  G.Whitman               23) MLT charges                     **
** 03/15/2009  G.Whitman               24) Compass charges                 **
** 10/08/2009  M.Lewis                 25) Regional charges                **
** 01/29/2010  G.Whitman               26) Single Inventory                **
** 07/01/2010  G.Whitman               27) Compass charges to Delta DEAR   **
** 11/01/2010  G.Whitman               28) Write billing file for DGS      **
** 12/07/2010  M.Lewis                 29) Add CoOp/Intern passgrpcds      **  
** 12/07/2010  M.Lewis                 30) Compass Charges                 **
** 11/21/2011  M.Lewis	               31) GoJet Charges                   **
** 01/14/2013  B.Ellison               32) Delta Private Jet Charges       **
** 02/20/2013  G.Whitman               33) Comair 60 numbers print an      **
**                                         invoice and DPJ 45 numbers are  **
**                                         nrev_src_cd is OH               **
** 04/15/2013  G.Whitman               34) Add file for Delta Private Jet  **
** 08/06/2013  G.Whitman               35) Add File and report for GSAs    **
** 01/03/2014  G.Whitman               36) Process MLT through DEAR to TZ  **
** 01/31/2014  G.Whitman               37) remove SSN for charges reports  **
** 12/16/2014  G.Whitman               38) add AirWisconsin and DCCU bills **
****************************************************************************/


#include "epb54002.h"
#include <time.h>


main()
{
   BCH_Init("EPB54002", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}

void writetolog(char x[], char y)
{
   FILE *fp = fopen("GWlog.txt","a");
   fprintf(fp,"%s%c\n",x,y);
   fclose(fp);
}

void writetologX(char x[], char y[])
{
   FILE *fp = fopen("GWlog.txt","a");
   fprintf(fp,"%s%s\n",x,y);
   fclose(fp);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{
   short   nRptIndex,                 /* Report index */
           nReqRptInd1 = FALSE,       /* Required report #1 indicator */
           nReqRptInd2 = FALSE,       /* Required report #2 indicator */
           nReqRptInd3 = FALSE,       /* Required report #3 indicator */
           nReqRptInd4 = FALSE,       /* Required report #4 indicator */
           nSvcRtnCd;     	      /* Service return code */

   char *pCycleType;                  /*  pointer to cycle */

   int i, j;


 /*** Initialize fields          ***/

   RS.TblItemsRead = 0;              
   RS.Worldspan_amt = 0.0;
   RS.Transquest_amt = 0.0;
   RS.DeltaStaffing_amt = 0.0;
   RS.ASA_amt = 0.0;
   RS.OH_amt = 0.0;
   RS.SO_amt = 0.0;
   RS.CA_amt = 0.0;
   RS.OO_amt = 0.0;
   RS.RP_amt = 0.0;
   RS.F8_amt = 0.0;
   RS.S5_amt = 0.0;
   RS.SK_amt = 0.0;
   RS.GQ_amt = 0.0;
   RS.XE_amt = 0.0;
   RS.E9_amt = 0.0;
   RS.CP_amt = 0.0;
   RS.XJ_amt = 0.0;
   RS.RS_amt = 0.0;
   RS.G7_amt = 0.0;
   RS.PJ_amt = 0.0;
   RS.MLT_amt = 0.0;
   RS.GSA_amt = 0.0;
   RS.OO_total_amt = 0.0;
   RS.LineNbr = 0;
   RS.EPBF020_record_cnt = 0;
   RS.EPBF020_record_amt = 0.0;
   RS.EPBF030_record_cnt = 0;
   RS.EPBF030_record_amt = 0.0;
   RS.EPBF040_record_cnt = 0;
   RS.EPBF040_record_amt = 0.0;
   RS.EPBF050_record_cnt = 0;
   RS.EPBF050_record_amt = 000000.00;
   RS.EPBF060_record_cnt = 0;
   RS.EPBF060_record_amt = 000000.00;
   RS.EPBF070_record_cnt = 0;
   RS.EPBF070_record_amt = 000000.00;
   RS.EPBF080_record_cnt = 0;
   RS.EPBF080_record_amt = 000000.00;
   RS.EPBF081_record_cnt = 0;
   RS.EPBF081_record_amt = 000000.00;
   RS.EPBF082_record_cnt = 0;
   RS.EPBF082_record_amt = 000000.00;
   RS.EPBF083_record_cnt = 0;
   RS.EPBF083_record_amt = 000000.00;
   RS.EPBF084_record_cnt = 0;
   RS.EPBF084_record_amt = 000000.00;
   RS.EPBF085_record_cnt = 0;
   RS.EPBF085_record_amt = 000000.00;
   RS.EPBF086_record_cnt = 0;
   RS.EPBF086_record_amt = 000000.00;
   RS.EPBF087_record_cnt = 0;
   RS.EPBF087_record_amt = 000000.00;
   RS.EPBF088_record_cnt = 0;
   RS.EPBF088_record_amt = 000000.00;
   RS.EPBF089_record_cnt = 0;
   RS.EPBF089_record_amt = 000000.00;
   RS.EPBF090_record_cnt = 0;
   RS.EPBF090_record_amt = 000000.00;
   memset(sSavePprNbr, ' ', sizeof(sSavePprNbr));
   memset(sSaveNrevNbr, ' ', sizeof(sSaveNrevNbr));
   memset(sSaveNrevTyp, ' ', sizeof(sSaveNrevTyp));
   memset(sEndOfHdr, ' ', sizeof(sEndOfHdr));
   memset(sEndOfWSPHdr, ' ', sizeof(sEndOfWSPHdr));
   memset(sEndOfSKYWESTHdr, ' ', sizeof(sEndOfSKYWESTHdr));
   memset(sEndOfCHATAUQUAHdr, ' ', sizeof(sEndOfCHATAUQUAHdr));
   memset(sEndOfSHUTTLEHdr, ' ', sizeof(sEndOfSHUTTLEHdr));
   memset(sEndOfFREEDOMHdr, ' ', sizeof(sEndOfFREEDOMHdr));
   memset(sEndOfASAHdr, ' ', sizeof(sEndOfASAHdr));
   memset(sEndOfBIGSKYHdr, ' ', sizeof(sEndOfBIGSKYHdr));
   memset(sEndOfEXPRESSJETHdr, ' ', sizeof(sEndOfEXPRESSJETHdr));
   memset(sEndOfPINNACLEHdr, ' ', sizeof(sEndOfPINNACLEHdr));
   memset(sEndOfMesabaHdr, ' ',sizeof(sEndOfMesabaHdr)); 
   memset(sEndOfRegionalHdr, ' ',sizeof(sEndOfRegionalHdr)); 
   memset(sEndOfMLTHdr, ' ',sizeof(sEndOfMLTHdr));
   memset(sEndOfCompassHdr, ' ',sizeof(sEndOfCompassHdr));
   memset(sEndOfDGSHdr,' ',sizeof(sEndOfDGSHdr));
   memset(sEndOfG7Hdr,' ',sizeof(sEndOfG7Hdr));
   memset(sEndOfPJHdr,' ',sizeof(sEndOfPJHdr));
   

 /*** Initialize Employee AR Interface Layout   ***/

   memset(&EmplAR, LOW_VALUES, sizeof(EmplAR));
   strcpy(EmplAR.batch_nbr, "0000");
   EmplAR.batch_type = 'C';
   strcpy(EmplAR.curr_cd, USD_CURR);
   strcpy(EmplAR.line_cd, "MAT");
   strcpy(EmplAR.sales_dept, "956");
   memset(EmplAR.chg_desc, ' ', sizeof(EmplAR.chg_desc));
   strcpy(EmplAR.vend_nm, "PASS USAGE");
     
 /*** Initialize Worldspan Interface Layout   ***/
   memset(&WSP_Dtl, LOW_VALUES, sizeof(WSP_Dtl));

 /*** Initialize Song Interface Layout   ***/
   memset(&Song_Dtl, LOW_VALUES, sizeof(Song_Dtl));

 /*** Initialize GSA Interface Layout   ***/
   memset(&GSA_Dtl, LOW_VALUES, sizeof(GSA_Dtl));

 /*** Initialize Skywest Interface Layout   ***/
   memset(&SKYWEST_Dtl, LOW_VALUES, sizeof(SKYWEST_Dtl));

 /*** Initialize Chatauqua Interface Layout   ***/
   memset(&CHATAUQUA_Dtl, LOW_VALUES, sizeof(CHATAUQUA_Dtl));

 /*** Initialize Shuttle Interface Layout   ***/
   memset(&SHUTTLE_Dtl, LOW_VALUES, sizeof(SHUTTLE_Dtl));

 /*** Initialize Freedom Interface Layout   ***/
   memset(&FREEDOM_Dtl, LOW_VALUES, sizeof(FREEDOM_Dtl));

 /*** Initialize ASA Interface Layout   ***/
   memset(&ASA_Dtl, LOW_VALUES, sizeof(ASA_Dtl));

 /*** Initialize Big Sky Interface Layout   ***/
   memset(&BIGSKY_Dtl, LOW_VALUES, sizeof(BIGSKY_Dtl));

 /*** Initialize Express Jet Interface Layout   ***/
   memset(&EXPRESSJET_Dtl, LOW_VALUES, sizeof(EXPRESSJET_Dtl));

 /*** Initialize Pinnacle Interface Layout   ***/
   memset(&PINNACLE_Dtl, LOW_VALUES, sizeof(PINNACLE_Dtl));

 
 /*** Initialize Mesaba Interface Layout   ***/
   memset(&Mesaba_Dtl, LOW_VALUES, sizeof(Mesaba_Dtl));

 /*** Initialize Regional Interface Layout   ***/
   memset(&Regional_Dtl, LOW_VALUES, sizeof(Regional_Dtl));

 /*** Initialize MLT Interface Layout   ***/
   memset(&MLT_Dtl, LOW_VALUES, sizeof(MLT_Dtl));

 /*** Initialize Compass Interface Layout   ***/
   memset(&Compass_Dtl, LOW_VALUES, sizeof(Compass_Dtl));

/*** Initialize DGS Interface Layout   ***/
   memset(&DGS_Dtl, LOW_VALUES, sizeof(DGS_Dtl));
   
/*** Initialize GoJet Interface Layout  ***/
   memset(&G7_Dtl, LOW_VALUES, sizeof(G7_Dtl));
   
/*** Initialize Delta Private Jet Interface Layout  ***/
   memset(&PJ_Dtl, LOW_VALUES, sizeof(PJ_Dtl));

 /*** get cycle from script   ***/

   pCycleType = (char *) getenv("CYCLES");
   strcpy(RS.sCycleId, pCycleType);
   strcpy(sSaveCycleId, pCycleType);

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   //******************************************
   //*** create the trans date in MMDDYY format
   //******************************************
   strncpy(EmplAR.trans_dt, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_MMDDYY),
    sizeof(EmplAR.trans_dt));

   //******************************************
   //*** create the oblig ID in YYMMDD format
   //******************************************
   strncpy(EmplAR.oblig_id, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYMMDD),
    sizeof(EmplAR.oblig_id));

   /*********** Call RSAM to open for output Employee A/R Interface file ************/
   RS.EPBF020 = BCH_Open("EPBF020", BCH_FILE_WRITE);
   if (RS.EPBF020 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF020");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Worldspan Interface file   ************/
   RS.EPBF030 = BCH_Open("EPBF030", BCH_FILE_WRITE);
   if (RS.EPBF030 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF030");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /********Call RSAM to open for output Song Interface file-No Longer Song ***/
   /***********Call RSAM to open output GSA Interface File         ************/
   RS.EPBF040 = BCH_Open("EPBF040", BCH_FILE_WRITE);
   if (RS.EPBF040 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF040");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Skywest Interface file   ************/
   RS.EPBF050 = BCH_Open("EPBF050", BCH_FILE_WRITE);
   if (RS.EPBF050 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF050");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Chatauqua Interface file   ************/
   RS.EPBF060 = BCH_Open("EPBF060", BCH_FILE_WRITE);
   if (RS.EPBF060 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF060");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Shuttle Interface file   ************/
   RS.EPBF070 = BCH_Open("EPBF070", BCH_FILE_WRITE);
   if (RS.EPBF070 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF070");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Freedom Interface file   ************/
   RS.EPBF080 = BCH_Open("EPBF080", BCH_FILE_WRITE);
   if (RS.EPBF080 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF080");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output ASA Interface file   ************/
   RS.EPBF081 = BCH_Open("EPBF081", BCH_FILE_WRITE);
   if (RS.EPBF081 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF081");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Big Sky Interface file   ************/
   RS.EPBF082 = BCH_Open("EPBF082", BCH_FILE_WRITE);
   if (RS.EPBF082 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF082");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Express Jet Interface file   ************/
   RS.EPBF083 = BCH_Open("EPBF083", BCH_FILE_WRITE);
   if (RS.EPBF083 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF083");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Pinnacle Interface file   ************/
   RS.EPBF084 = BCH_Open("EPBF084", BCH_FILE_WRITE);
   if (RS.EPBF084 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF084");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Mesaba Interface file   ************/
   RS.EPBF085 = BCH_Open("EPBF085", BCH_FILE_WRITE);
   if (RS.EPBF085 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF085");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output MLT Interface file   ************/
   RS.EPBF086 = BCH_Open("EPBF086", BCH_FILE_WRITE);
   if (RS.EPBF086 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF086");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Compass Interface file   ************/
   RS.EPBF087 = BCH_Open("EPBF087", BCH_FILE_WRITE);
   if (RS.EPBF087 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF087");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output Regional Interface file   ************/
   RS.EPBF088 = BCH_Open("EPBF088", BCH_FILE_WRITE);
   if (RS.EPBF088 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF088");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /*********** Call RSAM to open for output DGS Interface file   ************/
   RS.EPBF089 = BCH_Open("EPBF089", BCH_FILE_WRITE);
      if (RS.EPBF089 == BCH_FAIL)
      {
          BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
          BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF089");
          BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
      }
 

   /*********** Call RSAM to open for output G7 Interface file   ************/
   RS.EPBF090 = BCH_Open("EPBF090", BCH_FILE_WRITE);
      if (RS.EPBF090 == BCH_FAIL)
      {
          BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
          BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF090");
          BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
      }
 

   /*********** Call RSAM to open for output PJ Interface file   ************/
   RS.EPBF091 = BCH_Open("EPBF091", BCH_FILE_WRITE);
      if (RS.EPBF091 == BCH_FAIL)
      {
          BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
          BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF091");
          BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
      }
 }
/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{
   char   *pTemp;
   short     nSvcRtnCd;      /* Service return code */
   int       i;
   nNbrOfChrgs = 0;

   /*** First, go get all of the charge codes and descriptions and store in an array  ***/
   memset(&R03932.R03932_appl_area,LOW_VALUES, sizeof(R03932.R03932_appl_area));
   memset(&A03932,LOW_VALUES,sizeof(A03932));
   R03932.R03932_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03932,&A03932,SERVICE_ID_03932,1,sizeof(R03932.R03932_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03932");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {   
      /*** store charge code and description in array   ***/
      strcpy(svc_chrg[nNbrOfChrgs].sSvcChrgCd, A03932.A03932_appl_area.sSvcChrgCd);
      strcpy(svc_chrg[nNbrOfChrgs].sSvcChrgDs, A03932.A03932_appl_area.sSvcChrgDs);
      nNbrOfChrgs++;

      /*** go get next charge description   ***/
      R03932.R03932_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A03932,LOW_VALUES,sizeof(A03932));
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03932,&A03932,SERVICE_ID_03932,1,sizeof(R03932.R03932_appl_area));

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03932");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
         }  
      }

/**********************************************************************************
**
** Execute service to get current date minus 45 days.
**
**********************************************************************************/

   memset(&R04622,LOW_VALUES,sizeof(R04622));
   memset(&A04622,LOW_VALUES,sizeof(A04622));
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04622,&A04622,SERVICE_ID_04622,1,sizeof(R04622));

   switch (nSvcRtnCd)
   {
     case ARC_SUCCESS:
       break;
     case ARC_ROW_NOT_FOUND: 
       BCH_FormatMessage(2,TXT_SVC, "FYS04622");
       sprintf(sErrorMessage,"%s","No rows exist with default date 12/31/1899.  Current date - 45 days not returned.");
       BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
       BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
       break;
     default:
       BCH_FormatMessage(1,TXT_SVC_UNSUCC);
       BCH_FormatMessage(2,TXT_SVC, "FYS04622");
       sprintf(sErrorMessage,"%s","Unable to obtain current date minus 45 days from database call.");
       BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }

   /****** next, begin processing charges items *****/
   memset(&R02665.R02665_appl_area,LOW_VALUES, sizeof(R02665.R02665_appl_area));
   memset(&A02665,LOW_VALUES,sizeof(A02665));
   R02665.R02665_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   strcpy(R02665.R02665_appl_area.sProcDt, LOW_DATE);   

   /************************************************************************************************/
   /****** Execute service to retrieve first charges item whose process date = 12/31/1899 and  *****/
   /****** its associated nrev item                                                            *****/
   /************************************************************************************************/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02665,&A02665,SERVICE_ID_02665,1,sizeof(R02665.R02665_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
	 // Convert the dates expected format is different
         pTemp = UTL_ConvertDate(A02665.A02665_appl_area.sFltDprtDt, CNV_DB_TO_DD_MMM_YYYY);
	 strncpy(A02665.A02665_appl_area.sFltDprtDt, pTemp,
	  sizeof(A02665.A02665_appl_area.sFltDprtDt));

         pTemp = UTL_ConvertDate(A02665.A02665_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	 strncpy(A02665.A02665_appl_area.sPassRptSortDt, pTemp,
	  sizeof(A02665.A02665_appl_area.sPassRptSortDt));

         break;

         case ARC_ROW_NOT_FOUND: 
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02665");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows ****/

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {
      RS.TblItemsRead++;
      DPM_2500_ProcessRows();
      DPM_4920_ProcessLUW();

      /**** after processing row, get the next charges item and associated nrev item   ***/
      R02665.R02665_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A02665,LOW_VALUES,sizeof(A02665));

      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02665,&A02665,SERVICE_ID_02665,1,sizeof(R02665.R02665_appl_area));

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
             // Convert the date expected format is different
	     pTemp = UTL_ConvertDate(A02665.A02665_appl_area.sFltDprtDt, CNV_DB_TO_DD_MMM_YYYY);
	     strncpy(A02665.A02665_appl_area.sFltDprtDt, pTemp,
	      sizeof(A02665.A02665_appl_area.sFltDprtDt));

	     pTemp = UTL_ConvertDate(A02665.A02665_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	     strncpy(A02665.A02665_appl_area.sPassRptSortDt, pTemp,
	      sizeof(A02665.A02665_appl_area.sPassRptSortDt));

	     break;


         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02665");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
         }  
      }
   DPM_3000_WriteTotals();
   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();

   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessRows()
{
   short     nSvcRtnCd;      /* Service return code */
   int       i = 0;

   char sCurDtMinus45[12],
        sPassDtTmTs[12];


   memset(sCurDtMinus45,'\0',12);
   memset(sPassDtTmTs,'\0',12);

   cInterfaceWritten = NO_CHAR;      /*  no interface record has been written yet     */
   cWorldspanInd = NO_CHAR;             
   cTransquestInd = NO_CHAR;             
   cDeltaStaffingInd = NO_CHAR;             
   cASAInd = NO_CHAR;
   cOHInd = NO_CHAR;
   cSOInd = NO_CHAR;
   cCAInd = NO_CHAR;
   cDHInd = NO_CHAR;
   cRPInd = NO_CHAR;
   cOOInd = NO_CHAR;
   cS5Ind = NO_CHAR;
   cF8Ind = NO_CHAR;
   cGQInd = NO_CHAR;
   cXEInd = NO_CHAR;
   c9EInd = NO_CHAR;
   cXJInd = NO_CHAR;
   cRSInd = NO_CHAR;
   cMLTInd = NO_CHAR;
   cGSAInd = NO_CHAR;
   cG7Ind = NO_CHAR;
   cPJInd = NO_CHAR;
   cCPInd = NO_CHAR;
   strcpy(sSaveSvcChrgDs, A02665.A02665_appl_area.sSvcChrgCd);
   strcpy(RS.sCycleId, sSaveCycleId);

   /*************************************************************************/
   /*** First, get the description for the service code from the array    ***/
   /*************************************************************************/
      while (i < nNbrOfChrgs)
         {
         if (strcmp(A02665.A02665_appl_area.sSvcChrgCd, svc_chrg[i].sSvcChrgCd) == 0)
            {
            strcpy(sSaveSvcChrgDs, svc_chrg[i].sSvcChrgDs);
            break;
            }
         i++;
         }

   /*****************************************************************************************/
   /*** next,  if the ppr number on the charges item changes, get the new ppr information ***/
   /*****************************************************************************************/
   if (strcmp(A02665.A02665_appl_area.sPprNbr, sSavePprNbr) != 0)
      {
      strcpy(sSavePprNbr, A02665.A02665_appl_area.sPprNbr);
      RS.LineNbr = 0;

      /****** Initialize Request and Answer Blocks *****/
      memset(&R02666.R02666_appl_area,LOW_VALUES, sizeof(R02666.R02666_appl_area));
      memset(&A02666,LOW_VALUES,sizeof(A02666));
      strcpy(R02666.R02666_appl_area.sPprNbr, sSavePprNbr); 

      /** Execute service to retrieve the PPr item that matches the charges PPR nbr **/
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02666,&A02666,SERVICE_ID_02666,1,sizeof(R02666.R02666_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;
         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02666");
            BCH_FormatMessage(3,TXT_PPR, sSavePprNbr);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
         }  
      }

  if (strcmp(A02665.A02665_appl_area.sSvcChrgCd, FARE) == 0  || 
    strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS) == 0  || 
    strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) == 0  || 
    strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) == 0  || 
    strcmp(A02666.A02666_appl_area.sPassGrpCd, BOARD_MEMBERS) == 0) 
  {
    DPM_2520_UpdateProcessDate();
  } 
   /*****************************************************************************************************/
   /*** dont process this item if charge code = fare or pass group = senior officers or board members  or connection carrier           ( ACA, Skywest, Chautaugua) ***/
   /*****************************************************************************************************/
   if (strcmp(A02665.A02665_appl_area.sSvcChrgCd, FARE) != 0  &&
       strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS) != 0  &&
       strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) != 0  &&
       strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) != 0  &&
       strcmp(A02666.A02666_appl_area.sPassGrpCd, BOARD_MEMBERS) != 0)
      {

      /****************************************************************************/
      /*** Determine if the pass group is one that is on Delta's payroll        ***/
      /****************************************************************************/
      if (strcmp(A02666.A02666_appl_area.sPassGrpCd, ACTIVE_DL)      == 0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, ACTIVE_DL_WK)   == 0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, ACTIVE_DL_MRD)  == 0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, RDYRSV_MARRIED) == 0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, RDYRSV_SINGLE) ==  0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, RDYRSV_SINGLE_WK) ==  0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, TEMPDL_MARRIED) == 0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, COOPINT_MARRIED) == 0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, COOPINT_SINGLE) ==  0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, COOPINT_SINGLE_WK) ==  0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, TEMPDL_SINGLE)  == 0 ||
          strcmp(A02666.A02666_appl_area.sPassGrpCd, TEMPDL_SINGLE_WK) ==0)
          cDLPayrollInd = YES_CHAR;
      else
          cDLPayrollInd = NO_CHAR;
 
      /***************************************************************************/
      /*** Determine if this is a Worldspan Employee                           ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "WS") == 0)
          cWorldspanInd = YES_CHAR;
 
      /***************************************************************************/
      /*** Determine if this is a TransQuest employee                          ***/
      /*** Added by SKM 8/6/97:                                                ***/
      /*** Starting from Sept 1st 1997, TQ Employees will have the same pass   ***/
      /*** group code as Delta Employees. So, for TQ Employees, set Delta      ***/
      /*** Payroll Indicator to NO.                                            ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "TQ") == 0)
      {
          cTransquestInd = NO_CHAR;
          cDLPayrollInd = NO_CHAR;
      }


      /***************************************************************************/
      /*** Determine if this is a Delta Staffing employee                      ***/
      /*** Added by SKM 4/8/1998:                                              ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "DS") == 0)
      {
          cDeltaStaffingInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a ASA employee                                 ***/
      /*** Added by LAS 1/28/2000:                                             ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "AS") == 0)
      {
          cASAInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a an employee is Comair or DPJ                 ***/
      /*** Added by EJS 8/28/2000: GLW 02/20/2013                              ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "OH") == 0)
      {
          cOHInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }
      if (strncmp(sSavePprNbr, "60", 2) == 0)
      {
          cOHInd = NO_CHAR;
	  cDLPayrollInd = NO_CHAR;
      } 


      /***************************************************************************/
      /*** Determine if this is a Song employee                                ***/
      /*** Added by LAS 3/10/2003                                              ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "SO") == 0)
      {
          cSOInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a Comair Academy employee                      ***/
      /*** Added by LAS 7/11/2003                                              ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "CA") == 0)
      {
          cOHInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a ACA employee                             ***/
      /*** Added by LAS 02/09/2003                                             ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "DH") == 0)
      {
          cDHInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a Chautaugua employee                      ***/
      /*** Added by LAS 02/09/2003                                             ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "RP") == 0)
      {
           cRPInd = YES_CHAR;
	   cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a SkyWest employee                             ***/
      /*** Added by LAS 02/09/2003                                             ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "OO") == 0)
      {
          cOOInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a Shuttle employee                             ***/
      /*** Added by EJS 07/2006                                                ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "S5") == 0)
      {
          cS5Ind = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a Freedom employee                             ***/
      /*** Added by EJS 07/2006                                                ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "F8") == 0)
      {
          cF8Ind = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a Big Sky employee                             ***/
      /*** Added by LAS 02/2007                                                ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "GQ") == 0)
      {
          cGQInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a Express Jet employee                         ***/
      /*** Added by LAS 02/2007                                                ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "XE") == 0)
      {
          cXEInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a Pinnacle employee                            ***/
      /*** Added by LAS 11/2007                                                ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "9E") == 0)
      {
          c9EInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }


      /***************************************************************************/
      /*** Determine if this is a Mesaba employee                                  ***/
      /*** Added by glw 03/15/2009                                                ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "XJ") == 0)
      {
          cXJInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a Regional employee                               ***/
      /*** Added by mll 10/08/2009                                                ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "RS") == 0)
      {
          cRSInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a MLT employee                                 ***/
      /*** Added by glw 03/15/2009                                             ***/
      /*** ML employees already set as cDLPayrollInd = YES_CHAR because of     ***/
      /*** PassGrpCd
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "ML") == 0)
      {
          cMLTInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a GoJet employee                              ***/
      /*** Added by mll 11/15/2011                                             ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "G7") == 0)
      {
          cG7Ind = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a Delta Private Jet employee                  ***/
      /*** Added by bbe 01/14/2013                                             ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "PJ") == 0)
      {
          cPJInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a GSA active sales associate                   ***/
      /*** Added by glw 08/06/2013-GSAs in nonrev source code MN but are sent  ***/
      /*** in a file to the Sale Office to be billed to the GSA agents         ***/
      /***************************************************************************/
      if (strcmp(A02666.A02666_appl_area.sPassGrpCd, GSA_ACTIVE) == 0)
      {
	 cGSAInd = YES_CHAR;
	 cDLPayrollInd = NO_CHAR;
      }

      /***************************************************************************/
      /*** Determine if this is a Compass employee                             ***/
      /*** Added by glw 03/15/2009                                             ***/
      /*** Change Compass employee to be processed through to Delta A/R and    ***/
      /*** no longer be treated as a DCI for active "CB" only. For retiree     ***/
      /*** produce a monthly statement.                                        ***/
      /*** 07/01/2010 glw                                                      ***/
      /*** 12/07/2010 mll - add Compass charges back                           ***/
      /***************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sNrevSrcCd, "CP") == 0)
      {
          cCPInd = YES_CHAR;
          cDLPayrollInd = NO_CHAR;
      }
      

      /*********************************************************************************/
      /*** Always Write to Employee A/R Interface file if on Delta's Payroll         ***/
      /*********************************************************************************/

  /*************************************************************************************
  **
  **  Added conditional processing to delay sending FP, IP, and FT of AC/AK groups 
  **  charge records to A/R unless the charges are 45 days or more old.
  **  By: LSW 8/11/98
  **
  **************************************************************************************/

      if ( (cDLPayrollInd == YES_CHAR) && \
( ((strcmp(A02665.A02665_appl_area.sSvcChrgCd,"FP") == 0) || \
(strcmp(A02665.A02665_appl_area.sSvcChrgCd,"IP") == 0)) || \
((strcmp(A02665.A02665_appl_area.sSvcChrgCd,"FT") == 0) && \
((strcmp(A02665.A02665_appl_area.sPassGrpCd,"AK") == 0) || \
(strcmp(A02665.A02665_appl_area.sPassGrpCd,"AC") == 0))) ) && \
(A02665.A02665_appl_area.dCostChrgAmt < 0) )
      {
        memset(&R04624.R04624_appl_area,LOW_VALUES, sizeof(R04624.R04624_appl_area));
        memset(&A04624,LOW_VALUES,sizeof(A04624));
        strcpy(R04624.R04624_appl_area.sPprNbr,A02665.A02665_appl_area.sPprNbr);
        strcpy(R04624.R04624_appl_area.sNrevNbr,A02665.A02665_appl_area.sNrevNbr);
        strcpy(R04624.R04624_appl_area.sFltDprtDt, UTL_ConvertDate(A02665.A02665_appl_area.sFltDprtDt, CNV_DD_MMM_YYYY_TO_DB));
        strcpy(R04624.R04624_appl_area.sSvcChrgCd,A02665.A02665_appl_area.sSvcChrgCd);
        strcpy(R04624.R04624_appl_area.sFltOrigCtyId,A02665.A02665_appl_area.sFltOrigCtyId);
        strcpy(R04624.R04624_appl_area.sFltDestCtyId,A02665.A02665_appl_area.sFltDestCtyId);
        R04624.R04624_appl_area.dCostChrgAmt = (-1*A02665.A02665_appl_area.dCostChrgAmt);

        DPM_2550_WriteEmployeeAR();

        memset(&A04624,LOW_VALUES,sizeof(A04624));
        nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04624,&A04624,SERVICE_ID_04624,1,sizeof(R04624));
        switch (nSvcRtnCd)
        {
          case ARC_SUCCESS:
            break;
          case ARC_ROW_NOT_FOUND:
            break;
          default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04624");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
        }

        if ( nSvcRtnCd == ARC_SUCCESS)
        {
          A02665.A02665_appl_area.lSeqID       = A04624.A04624_appl_area.lSeqID;
          A02665.A02665_appl_area.dCostChrgAmt = A04624.A04624_appl_area.dCostChrgAmt;
          DPM_2550_WriteEmployeeAR();
        }
      }
      else if ( (cDLPayrollInd == YES_CHAR) && \
( ((strcmp(A02665.A02665_appl_area.sSvcChrgCd,"FP") == 0) || \
(strcmp(A02665.A02665_appl_area.sSvcChrgCd,"IP") == 0)) || \
((strcmp(A02665.A02665_appl_area.sSvcChrgCd,"FT") == 0) && \
((strcmp(A02665.A02665_appl_area.sPassGrpCd,"AK") == 0) || \
(strcmp(A02665.A02665_appl_area.sPassGrpCd,"AC") == 0))) ) && \
(A02665.A02665_appl_area.dCostChrgAmt > 0) )
      {
        strncpy(sCurDtMinus45,A04622.A04622_appl_area.sPassDtTmTs,11);
        strncpy(sPassDtTmTs,A02665.A02665_appl_area.sPassDtTmTs,11);
        if ( strcmp(sCurDtMinus45,sPassDtTmTs) >= 0 )
        {
          DPM_2550_WriteEmployeeAR();
        }
      }
      else if (cDLPayrollInd == YES_CHAR)
      {
         DPM_2550_WriteEmployeeAR();
      }

      /****************************************************************************************************/
      /*** Write to Employee A/R & produce invoices if this is a monthend run & not on Delta's Payroll  ***/
      /****************************************************************************************************/

      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cDLPayrollInd == NO_CHAR          &&
          cTransquestInd == NO_CHAR         && 
          cDeltaStaffingInd == NO_CHAR      &&
          cASAInd == NO_CHAR                &&
          cOHInd == NO_CHAR                 &&
          cSOInd == NO_CHAR                 &&
          cCAInd == NO_CHAR                 &&
          cDHInd == NO_CHAR                 &&
          cRPInd == NO_CHAR                 &&
          cOOInd == NO_CHAR                 &&
          cS5Ind == NO_CHAR                 &&
          cF8Ind == NO_CHAR                 &&
          cGQInd == NO_CHAR                 &&
          cXEInd == NO_CHAR                 &&
          c9EInd == NO_CHAR                 &&
          cXJInd == NO_CHAR                 &&
          cRSInd == NO_CHAR                 &&
          cMLTInd == NO_CHAR                &&
	  cGSAInd == NO_CHAR                &&
	  cG7Ind == NO_CHAR                 &&
	  cPJInd == NO_CHAR                 &&
          cCPInd == NO_CHAR                 && 
          cWorldspanInd == NO_CHAR)
         {
           DPM_2550_WriteEmployeeAR();
           DPM_5000_GenerateEPB54011();   
         }

      /****************************************************************************************************/
      /*** Produce Worldspan Detail report if monthend and pass type = Worldspan                        ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cWorldspanInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2560_WriteWorldspan();
            DPM_5010_GenerateEPB54012();   
            RS.Worldspan_amt += A02665.A02665_appl_area.dCostChrgAmt;    /*  add amount to total    */
             
         }

      /***************************************************************************************************/
      /*** Produce TransQuest Detail report if monthend and source type = TQ                     ***/
      /***************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cTransquestInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                }  
             }
             cInterfaceWritten = YES_CHAR;    /*  set so process date can be updated */
             DPM_5020_GenerateEPB54013();   
             DPM_2520_UpdateProcessDate();
             RS.Transquest_amt += A02665.A02665_appl_area.dCostChrgAmt;    /*  add amount to total    */
             
         }

      /***************************************************************************************************/
      /*** Produce Delta Staffing Detail report if monthend and source type = DS  ***/
      /***************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cDeltaStaffingInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                }  
             }
	     DPM_2592_WriteDGS();
             cInterfaceWritten = YES_CHAR;    /*  set so process date can be updated */
             DPM_5030_GenerateEPB54014();   
             DPM_2520_UpdateProcessDate();
             RS.DeltaStaffing_amt += A02665.A02665_appl_area.dCostChrgAmt;    /*  add amount to total    */
             
         }

      /***************************************************************************************************/
      /*** Produce ASA Detail report if monthend and source type = ASA                     ***/
      /***************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
           cASAInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                }  
             }
             DPM_2584_WriteASA();
             cInterfaceWritten = YES_CHAR;    /*  set so process date can be updated */
             DPM_5040_GenerateEPB54015();   
             DPM_2520_UpdateProcessDate();
             RS.ASA_amt += A02665.A02665_appl_area.dCostChrgAmt;    /*  add amount to total    */
             
         }

      /***************************************************************************************************/
      /*** Produce OH Detail report if monthend and source type = OH                     ***/
      /***************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
           cOHInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                }  
             }
             cInterfaceWritten = YES_CHAR;    /*  set so process date can be updated */
             DPM_5040_GenerateEPB54016();   
             DPM_2520_UpdateProcessDate();
             RS.OH_amt += A02665.A02665_appl_area.dCostChrgAmt;    /*  add amount to total    */
             
         }

      /***************************************************************************************************/
      /*** Produce GSA Detail report if monthend source type MN pass group = GA                        ***/     
      /***************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 &&
          cGSAInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            } 
            DPM_2575_WriteGSA();
            RS.OO_amt += A02665.A02665_appl_area.dCostChrgAmt;
            DPM_5040_GenerateEPB54017();
            DPM_2520_UpdateProcessDate();
            
           }


      /***************************************************************************************************/
      /*** Produce SO (Song) Detail report if monthend or biweekly and source type = SO                ***/
      /***************************************************************************************************/
      if ((strcmp(RS.sCycleId, MONTHLY) == 0  || 
          strcmp(RS.sCycleId, BIWEEKLY) == 0) && 
           cSOInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get description     */
         /**********************************************************/
	 if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
           strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                }  
             }
             cInterfaceWritten = YES_CHAR;    /*  set so process date can be updated */
             DPM_2570_WriteSong();
             if (strcmp(RS.sCycleId, BIWEEKLY) == 0)
	       {
	       strcpy(RS.sCycleId, "MM");
	       }
             DPM_5040_GenerateEPB54017();    
             strcpy(RS.sCycleId, sSaveCycleId);
             RS.SO_amt += A02665.A02665_appl_area.dCostChrgAmt;    /*  add amount to total    */
             
         }

      /***************************************************************************************************/
      /*** Produce Comair Academy Detail report if monthend and source type = CA                     ***/
      /***************************************************************************************************
      THIS ENTIRE SECTION HAS BEEN COMMENTED OUT, BECAUSE COMAIR ACADEMY DATA
      IS INCLUDED ON THE COMAIR DETAIL REPORT.  THE CODE WAS NOT REMOVED IN
      CASE THE ACADEMY DATA IS SPLIT OUT AGAIN.
       ***************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
           cCAInd == YES_CHAR)
    /*     { */
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
   /*      if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);
   */
            /****** Initialize Request and Answer Blocks *****/
   /*       memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);
   */
            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
    /*      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));
    */
            /****** Service Return Code Processing  ****/
    /*      switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                }  
             }
       */
             cInterfaceWritten = YES_CHAR;    /*  set so process date can be updated */
        /*     DPM_5040_GenerateEPB54018();   */
             DPM_2520_UpdateProcessDate();
             RS.CA_amt += A02665.A02665_appl_area.dCostChrgAmt;    /*  add amount to total    */
             
         }

      /****************************************************************************************************/
      /*** Produce Skywest Detail report if monthend and employee is Skywest                            ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cOOInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2580_WriteSkywest();
            RS.OO_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54019();   
            DPM_2520_UpdateProcessDate();
         }

      /****************************************************************************************************/
      /*** Produce Chatauqua Detail report if monthend and employee is Chatauqua 8/9/06 EJS             ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cRPInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2581_WriteChatauqua();
            RS.RP_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54020();   
            DPM_2520_UpdateProcessDate();
         }   

      /****************************************************************************************************/
      /*** Produce Shuttle Detail report if monthend and employee is Shuttle 8/9/06 EJS             ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cS5Ind == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2582_WriteShuttle();
            RS.S5_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54021();   
            DPM_2520_UpdateProcessDate();
         }   

      /****************************************************************************************************/
      /*** Produce Freedom Detail report if monthend and employee is Freedom 8/9/06 EJS             ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cF8Ind == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2583_WriteFreedom();
            RS.F8_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54022();   
            DPM_2520_UpdateProcessDate();
         }   

      /****************************************************************************************************/
      /*** Produce Big Sky Detail report if monthend and employee is Big Sky 2/20/7 LAS             ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cGQInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2585_WriteBigSky();
            RS.GQ_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54023();   
            DPM_2520_UpdateProcessDate();
         }   

      /****************************************************************************************************/
      /*** Produce Express Jet Detail report if monthend and employee is Express Jet 2/20/07 LAS          ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cXEInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2586_WriteExpressJet();
            RS.XE_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54024();   
            DPM_2520_UpdateProcessDate();
         }   

      /****************************************************************************************************/
      /*** Produce Pinnacle Detail report if monthend and employee is Pinnacle 11/19/07 LAS          ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          c9EInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2587_WritePinnacle();
            RS.E9_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54025();   
            DPM_2520_UpdateProcessDate();
         }   

      /****************************************************************************************************/
      /*** Produce Mesaba Detail report if monthend and employee is Mesaba 03/18/09 glw                 ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cXJInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2588_WriteXJ();
            RS.XJ_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54026();   
            DPM_2520_UpdateProcessDate();
         }   

      /****************************************************************************************************/
      /*** Produce Regional Detail report if monthend and employee is Regional 10/08/09 mll             ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cRSInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2591_WriteRS();
            RS.RS_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54029();   
            DPM_2520_UpdateProcessDate();
         }   

 /****************************************************************************************************/
      /*** Produce MLT Detail report if monthend and employee is MLT 03/18/09 glw                  ***/
      /***********************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cMLTInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2589_WriteMLT();
            RS.MLT_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            /*    DPM_5040_GenerateEPB54027();  */   
            /*    DPM_2520_UpdateProcessDate(); */
         }   

 /****************************************************************************************************/
      /*** Produce GoJet Detail report if monthend and employee is GoJet 11/15/2011 mll            ***/
      /***********************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cG7Ind == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2593_WriteG7();
            RS.G7_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54030();   
            DPM_2520_UpdateProcessDate();
         }   

      /***********************************************************************************************/
      /*** Produce Delta Private Jet Detail report if monthend and employee is DPJ 01/14/2013 bbe  ***/
      /*** Delta Private Jet '45' numbers have nrev_src_cd = 'OH'                  04/15/2013 glw  ***/             
      /***********************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cOHInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2594_WritePJ();
            RS.PJ_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_2520_UpdateProcessDate();
         }   

      /****************************************************************************************************/
      /*** Produce Compass Detail report if monthend and employee is Compass 03/18/2009 glw             ***/
      /****************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          cCPInd == YES_CHAR)
         {
         /**********************************************************/
         /* if passenger type code changes, go get the description */
         /**********************************************************/
         if (strcmp(A02665.A02665_appl_area.sNrevTypCd, sSaveNrevTyp) != 0)
            {
            strcpy(sSaveNrevTyp, A02665.A02665_appl_area.sNrevTypCd);

            /****** Initialize Request and Answer Blocks *****/
            memset(&R02529.R02529_appl_area,LOW_VALUES, sizeof(R02529.R02529_appl_area));
            memset(&A02529,LOW_VALUES,sizeof(A02529));
            strcpy(R02529.R02529_appl_area.sNrevTypCd, A02665.A02665_appl_area.sNrevTypCd);

            /****** Execute service to retrieve the passenger type item that matches the psgr type code   ***/
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02529,&A02529,SERVICE_ID_02529,1,sizeof(R02529.R02529_appl_area));

            /****** Service Return Code Processing  ****/
            switch (nSvcRtnCd)
               {
               case ARC_SUCCESS:
                  break;

                default:
                   BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                   BCH_FormatMessage(2,TXT_SVC, "FYS02529");
                   BCH_FormatMessage(3,TXT_PSGR_TYPE, A02665.A02665_appl_area.sNrevTypCd);
                   BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
                 }
            }
            DPM_2590_WriteCP();
            RS.CP_amt += A02665.A02665_appl_area.dCostChrgAmt;    
            DPM_5040_GenerateEPB54028();   
            DPM_2520_UpdateProcessDate();
         }   


      /***************************************************************************************************/
      /***************************************************************************************************/
      /***************************************************************************************************/
      /***************************************************************************************************/
      /*** Check ACA/Chautuagua/SkyWest for monthend and source type = DH  or RP           or OO                    ***/
      /****   removed all compnaies except ACA                                                          **/

      /***************************************************************************************************/
      if (strcmp(RS.sCycleId, MONTHLY) == 0 && 
          (cDHInd == YES_CHAR))
         {
             cInterfaceWritten = YES_CHAR;    /*  set so process date can be updated */
             DPM_2520_UpdateProcessDate();
             
         }
      /***************************************************************************************************/
   }
/*} */

/******************************************************************
**                                                               **
** Function Name:   DPM_2520_UpdateProcessDate                   **
**                                                               **
** Description:     This functions updates the process date for  **
**                  records written to the A/R interface file.   **
**                                                               **
** Arguments:       None.                                        **
**                                                               **
** Return Values:   None.                                        **
**                                                               **
**                                                               **
******************************************************************/

void DPM_2520_UpdateProcessDate()
{

  short     nSvcRtnCd;      /* Service return code */


/******************************************************************/
/*** Set process date to today if:                              ***/ 
/***      1. record written to interface file, or               ***/ 
/***      2. charge type = fare, or                             ***/
/***      3. pass group = senior officer or board member.       ***/ 
/***      4. pass group = connection carrier (ACA,Skywest,Chataugua) **/
/******************************************************************/

  if (cInterfaceWritten == YES_CHAR     ||
       strcmp(A02665.A02665_appl_area.sSvcChrgCd, FARE) == 0  ||
       strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS) == 0  ||
       strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) == 0  ||
       strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) == 0  ||
       strcmp(A02666.A02666_appl_area.sPassGrpCd, BOARD_MEMBERS) == 0)
  {
    /****** Initialize Request and Answer Blocks *****/
    memset(&R02667.R02667_appl_area,LOW_VALUES, sizeof(R02667.R02667_appl_area));
    memset(&A02667,LOW_VALUES,sizeof(A02667));
    R02667.R02667_appl_area.lSeqID = A02665.A02665_appl_area.lSeqID;
    strcpy(R02667.R02667_appl_area.sProcDt, sCurrentTsDt);

    /****** Execute service to update process date on Charges table           *****/
    nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02667,&A02667,SERVICE_ID_02667,1,sizeof(R02667.R02667_appl_area));

    /****** Service Return Code Processing  ****/
    switch (nSvcRtnCd)
    {
      case ARC_SUCCESS:
        break;
      default:
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS02667");
        sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sSvcChrgCd = %s, lSeqID = %ld",
        sSavePprNbr,
        A02665.A02665_appl_area.sNrevNbr,
        A02665.A02665_appl_area.sSvcChrgCd,
        A02665.A02665_appl_area.lSeqID);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2520_UpdateProcessDate");
    }  
  }

  if (strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS) == 0  ||
       strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) == 0  ||
       strcmp(A02666.A02666_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) == 0)
  {
    memset(&R02754.R02754_appl_area,LOW_VALUES, sizeof(R02754.R02754_appl_area));
    memset(&A02754,LOW_VALUES,sizeof(A02754));
    R02754.R02754_appl_area.nSeqId = A02665.A02665_appl_area.lSeqID;

    /****** Execute service to update flight account effective date on Charges table *****/
    /****** for Senior Officers ******/
    nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02754,&A02754,SERVICE_ID_02754,1,sizeof(R02754.R02754_appl_area));

    /****** Service Return Code Processing  ****/
    switch (nSvcRtnCd)
    {
      case ARC_SUCCESS:
        break;
      default:
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS02754");
        sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sSvcChrgCd = %s, lSeqID = %ld",
        sSavePprNbr,
        A02665.A02665_appl_area.sNrevNbr,
        A02665.A02665_appl_area.sSvcChrgCd,
        A02665.A02665_appl_area.lSeqID);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2520_UpdateProcessDate");
    }  
  }

} /* End Function DPM_2520_UpdateProcessDate */

/******************************************************************
**                                                               **
** Function Name:   DPM_2550_WriteEmployeeAR                     **
**                                                               **
** Description:     Format and Write Employee AR Record          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2550_WriteEmployeeAR()
{
   int i;
   char sTemp1ChrgAmt[13];
   char sTemp2ChrgAmt[12];
   double   dTempChrgAmt;

   /*** initialize the record buffer area ***/
   memset(&RS.EPBF020_buffer, LOW_VALUES, sizeof(RS.EPBF020_buffer));

   /*** Modified 10/16/97 by L. Scott                                         ***/
   /*** All charges will now go to 12713, including pass card charges.        ***/
   /*** (the 'IF' logic has been commented out, in case Accounts Receivable   ***/
   /*** decides to use different account numbers again)                       ***/
   /*** Modified 8/17/98 by S. Makim                                          ***/
   /*** Uncommented out the 'IF' block. Non-flight related charges should go  ***/
   /*** to "12712". (i.e. pass card charges & certificate charges)            ***/
   /*** if the charge is for pass cards, send to employee AR's misc business  ***/

   /*** Modified 4/29/03 by L. Scott                                          ***/
   /*** All charges will go to 127100003 per A/R                              ***/
   /************************************
    if (strcmp(A02665.A02665_appl_area.sSvcChrgCd, PASSCARD_CHARGE) == 0   ||
       strcmp(A02665.A02665_appl_area.sSvcChrgCd, LOSTCARD1_CHARGE) == 0   ||
       strcmp(A02665.A02665_appl_area.sSvcChrgCd, LOSTCARD2_CHARGE) == 0   ||
       strcmp(A02665.A02665_appl_area.sSvcChrgCd, LOSTCARD3_CHARGE) == 0   ||
       strcmp(A02665.A02665_appl_area.sSvcChrgCd, REISSUE_CERT_CHARGE) == 0)
         strcpy(EmplAR.bus_nbr, "12712");
   else  
         strcpy(EmplAR.bus_nbr, "12713");
   *************************************/

   strcpy(EmplAR.bus_nbr, "12713");

   strcpy(EmplAR.cust_id, A02665.A02665_appl_area.sPprNbr);
   strcpy(EmplAR.ref_id, A02665.A02665_appl_area.sPprNbr);
   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   /**************************************************************************/
   /*** Transaction code is 170 for all charges and fees,  650 for refunds.***/
   /*** A charge is determined to be a refund if its negative.             ***/
   /**************************************************************************/
   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      {
      strcpy(EmplAR.trans_cd, "650");
      dTempChrgAmt *= -1;      /* negative numbers cant be passed to employee AR */
      }
   else
      strcpy(EmplAR.trans_cd, "170");
 
   /**********************************************************************/
   /*** remove the period from the charge amount and store as a string ***/
   /**********************************************************************/
   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%012.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,9);
   memcpy(sTemp2ChrgAmt+9, sTemp1ChrgAmt+10, 2);
 
   /**********************************************************************************************/
   /***  Terms code is blank for people on Delta's payroll; otherwise, a special terms code is ***/
   /***  needed so that Employee AR won't produce initial statements.                          ***/
   /**********************************************************************************************/
   if (cDLPayrollInd == YES_CHAR)
      strcpy(EmplAR.terms_cd, "  ");
   else
      strcpy(EmplAR.terms_cd, "  ");

   RS.LineNbr++;
   EmplAR.line_nbr = RS.LineNbr;

   /*************************************************************************************************/
   /*** if the charge is a negative number, indicating a refund, the Employee AR description will ***/
   /*** contain REFUND - followed by the original service charge description.                     ***/
   /*************************************************************************************************/
   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      sprintf(EmplAR.chg_desc, "%2s REFUND - %-15s",
                                A02665.A02665_appl_area.sNrevNbr, sSaveSvcChrgDs);
   else
      {
      /***********************************************************************************************/
      /*** Format the description so that it will contain the nrev nbr, description, orig and dest ***/
      /*** and departure date, if necessary.                                                       ***/
      /***********************************************************************************************/
      if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "   ") == 0 ||   /* non flt related charges */
          strcmp(A02665.A02665_appl_area.sFltOrigCtyId, NULL_STRING) == 0 ||
          strcmp(A02665.A02665_appl_area.sFltOrigCtyId, " ") == 0)
         sprintf(EmplAR.chg_desc, "%-2s %-15s",
                            A02665.A02665_appl_area.sNrevNbr,
                            sSaveSvcChrgDs);
      else if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0) /* day type charges  */
         sprintf(EmplAR.chg_desc, "%-2s %-15s %-7s %-8s",
                            A02665.A02665_appl_area.sNrevNbr,
                            sSaveSvcChrgDs,
                            A02665.A02665_appl_area.sSvcChrgDs,
                            A02665.A02665_appl_area.sFltDprtDt);
      else                                                                  /* leg charges       */
         sprintf(EmplAR.chg_desc, "%-2s %-15s %-3s/%-3s %-8s",
                            A02665.A02665_appl_area.sNrevNbr,
                            sSaveSvcChrgDs,
                            A02665.A02665_appl_area.sFltOrigCtyId,
                            A02665.A02665_appl_area.sFltDestCtyId,
                            A02665.A02665_appl_area.sFltDprtDt);
      }

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF020_buffer, EMPLAR_FORMAT,
                              EmplAR.batch_nbr,
                              EmplAR.batch_type,
                              EmplAR.bus_nbr,  
                              EmplAR.cust_id,   
                              EmplAR.curr_cd,  
                              EmplAR.oblig_id,
                              EmplAR.trans_cd, 
                              EmplAR.trans_dt, 
                              EmplAR.sales_dept,
                              sTemp2ChrgAmt,   
                              EmplAR.terms_cd, 
                              EmplAR.ref_id,   
                              EmplAR.vend_nm,    
                              EmplAR.line_cd,   
                              EmplAR.line_nbr, 
                              EmplAR.chg_desc);

   BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));
   RS.EPBF020_record_cnt++;

   /*** add amount written to record to total - to prevent rounding problems ***/
   RS.EPBF020_record_amt += (atof(sTemp2ChrgAmt) / 100);

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2560_WriteWorldspan                      **
**                                                               **
** Description:     Format and Write Worldspan Record            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2560_WriteWorldspan()
{
   int i;
   char sTemp1ChrgAmt[7];
   char sTemp2ChrgAmt[6];
   double   dTempChrgAmt;
 
   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      {
      strcpy(WSP_Dtl.chrg_typ, "REFUND");
      dTempChrgAmt *= -1;      /* negative numbers cant be passed to WS */
      }
   else
      strcpy(WSP_Dtl.chrg_typ, sSaveSvcChrgDs);

   /**********************************************************************/
   /*** remove the period from the charge amount and store as a string ***/
   /**********************************************************************/
   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,3);
   memcpy(sTemp2ChrgAmt+3, sTemp1ChrgAmt+4, 2);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF030_buffer, LOW_VALUES, sizeof(RS.EPBF020_buffer));
 
   /*** populate Worldspan detail record structure ***/
   strcpy(WSP_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(WSP_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(WSP_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(WSP_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(WSP_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(WSP_Dtl.flt_orig, "     ");
   else
      strcpy(WSP_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(WSP_Dtl.flt_dest, "     ");
   else
      strcpy(WSP_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(WSP_Dtl.flt_nbr, "     ");
   else
      strcpy(WSP_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF030_buffer, WSP_FORMAT,
                              WSP_Dtl.ppr_nbr,
                              WSP_Dtl.nrev_nbr,
                              WSP_Dtl.nrev_nm,
                              WSP_Dtl.nrev_typ_cd,
                              WSP_Dtl.trans_dt,
                              WSP_Dtl.chrg_typ,
                              sTemp2ChrgAmt,
                              WSP_Dtl.flt_orig,
                              WSP_Dtl.flt_dest,
                              WSP_Dtl.flt_nbr,
                              WSP_Dtl.pass_type,
                              WSP_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF030, RS.EPBF030_buffer, sizeof(RS.EPBF030_buffer));
   RS.EPBF030_record_cnt++;

   /*** add amount written to record to total - to prevent rounding problems ***/
   RS.EPBF030_record_amt += (atof(sTemp2ChrgAmt) / 100);

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}
/******************************************************************
**                                                               **
** Function Name:   DPM_2570_Song                                **
**                                                               **
** Description:     Format and Write Song Record                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2570_WriteSong()
{
   int i;
   char sTemp1ChrgAmt[7];
   char sTemp2ChrgAmt[7];
   double   dTempChrgAmt;
   cDelimiter = COMMA; 
   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   /**********************************************************************/
   /*** remove the period from the charge amount and store as a string ***/
   /**********************************************************************/
   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   memset(sSavePprNbr5, LOW_VALUES, sizeof(sSavePprNbr5));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   strcpy(sTemp2ChrgAmt, "0000.00");
   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
     {
     strncpy(sTemp2ChrgAmt, sTemp1ChrgAmt,4);
     strncpy(sTemp2ChrgAmt+5, sTemp1ChrgAmt+5, 2);
     }
     else
     {
     strncpy(sTemp2ChrgAmt+1, sTemp1ChrgAmt,3);
     strncpy(sTemp2ChrgAmt+5, sTemp1ChrgAmt+4, 2);
     }
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF040_buffer, LOW_VALUES, sizeof(RS.EPBF040_buffer));
   memset(Song_Dtl,  LOW_VALUES, sizeof(Song_Dtl));
 
   /*** populate Song detail record structure ***/

   if (strcmp(A02665.A02665_appl_area.sSvcChrgCd,"FP") == 0)
      {
      strcpy(Song_Dtl.pass_type, "PFP");
      }
   if (strcmp(A02665.A02665_appl_area.sSvcChrgCd,"IP") == 0)
      {
      strcpy(Song_Dtl.pass_type, "PFP");
      }
   if (strcmp(A02665.A02665_appl_area.sSvcChrgCd,"FT") == 0)
      {
      strcpy(Song_Dtl.pass_type, "PSV");
      }
   if (strcmp(A02665.A02665_appl_area.sSvcChrgCd,"SV") == 0)
      {
      strcpy(Song_Dtl.pass_type, "PSV");
      }
   if (strcmp(A02665.A02665_appl_area.sSvcChrgCd,"IF") == 0)
      {
      strcpy(Song_Dtl.pass_type, "PIF");
      }
   if (strcmp(A02665.A02665_appl_area.sSvcChrgCd,"L1") == 0)
      {
      strcpy(Song_Dtl.pass_type, "PLC");
      }
   if (strcmp(A02665.A02665_appl_area.sSvcChrgCd,"L2") == 0)
      {
      strcpy(Song_Dtl.pass_type, "PLC");
      }
   if (strcmp(A02665.A02665_appl_area.sSvcChrgCd,"L3") == 0)
      {
      strcpy(Song_Dtl.pass_type, "PLC");
      }

   strcpy(Song_Dtl.co_code, "S5A");
   strcpy(Song_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strncpy(sSavePprNbr5, A02665.A02665_appl_area.sPprNbr+2, 5);
   strcpy(Song_Dtl.ppr_nbr, sSavePprNbr5);
   strcpy(Song_Dtl.dlm4, cDelimiter);
   strcpy(Song_Dtl.chrg_amt, sTemp2ChrgAmt);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF040_buffer, SONG_FORMAT,
			      Song_Dtl.co_code,
			      cDelimiter,
                              Song_Dtl.trans_dt,
			      cDelimiter,
                              Song_Dtl.ppr_nbr,
			      cDelimiter,
                              Song_Dtl.pass_type,
			      cDelimiter,
                              Song_Dtl.chrg_amt);
 
 
   BCH_WriteRec(RS.EPBF040, RS.EPBF040_buffer, sizeof(RS.EPBF040_buffer));
   RS.EPBF040_record_cnt++;

   /*** add amount written to record to total - to prevent rounding problems ***/
   RS.EPBF040_record_amt += (atof(sTemp2ChrgAmt) / 100);

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2575_WriteGSA                            **
**                                                               **
** Description:     Format and Write GSA Record                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2575_WriteGSA()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2);
   strcpy(GSA_Dtl.chrg_amt, sTemp2ChrgAmt);

   /*** initialize the record buffer area ***/
   memset(&RS.EPBF040_buffer, LOW_VALUES, sizeof(RS.EPBF040_buffer));

   /*** populate GSA detail record structure ***/
   strcpy(GSA_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(GSA_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(GSA_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(GSA_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(GSA_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(GSA_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(GSA_Dtl.flt_orig, "     ");
   else
      strcpy(GSA_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(GSA_Dtl.flt_dest, "     ");
   else
      strcpy(GSA_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(GSA_Dtl.flt_nbr, "     ");
   else
      strcpy(GSA_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF040_buffer, GSA_FORMAT,
                              GSA_Dtl.ppr_nbr,
                              GSA_Dtl.nrev_nbr,
                              GSA_Dtl.nrev_nm,
                              GSA_Dtl.nrev_typ_cd,
                              GSA_Dtl.trans_dt,
                              GSA_Dtl.chrg_typ,
                              GSA_Dtl.chrg_amt,
                              GSA_Dtl.flt_orig,
                              GSA_Dtl.flt_dest,
                              GSA_Dtl.flt_nbr,
                              GSA_Dtl.filler);


   BCH_WriteRec(RS.EPBF040, RS.EPBF040_buffer, sizeof(RS.EPBF040_buffer));
   RS.EPBF040_record_cnt++;


   RS.EPBF040_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF040_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF040_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2580_WriteSkywest                        **
**                                                               **
** Description:     Format and Write Skywest Record              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2580_WriteSkywest()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

/**  elona commented this out   char sTemp3ChrgAmt[10];
   char sTempChrgTtl[8];
   char sTemp1TtlAmt[14];
   char sTemp2TtlAmt[13];
   memset(sTempChrgTtl, LOW_VALUES, sizeof(sTempChrgTtl));
   memcpy(sTemp3ChrgAmt, sTemp1ChrgAmt,4);
   memcpy(sTemp3ChrgAmt+7, sTemp1ChrgAmt+5,2);
   memcpy(sTempChrgTtl, sTemp1ChrgAmt,4);
   memcpy(sTempChrgTtl+4, sTemp1ChrgAmt+5,2);
  TESTING....TESTING....TESTING......***/
/** Elona commented out--take out if works   strcpy(sTemp2ChrgAmt, "0000.00");
   strcpy(sTemp3ChrgAmt, "000000.00"); **/
 
   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
/**   strcpy(sTemp2ChrgAmt, "0000.00");   **/
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(SKYWEST_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF050_buffer, LOW_VALUES, sizeof(RS.EPBF050_buffer));
 
   /*** populate Skywest detail record structure ***/
   strcpy(SKYWEST_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(SKYWEST_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(SKYWEST_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(SKYWEST_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(SKYWEST_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(SKYWEST_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(SKYWEST_Dtl.flt_orig, "     ");
   else
      strcpy(SKYWEST_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(SKYWEST_Dtl.flt_dest, "     ");
   else
      strcpy(SKYWEST_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(SKYWEST_Dtl.flt_nbr, "     ");
   else
      strcpy(SKYWEST_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF050_buffer, SKYWEST_FORMAT,
                              SKYWEST_Dtl.ppr_nbr,
                              SKYWEST_Dtl.nrev_nbr,
                              SKYWEST_Dtl.nrev_nm,
                              SKYWEST_Dtl.nrev_typ_cd,
                              SKYWEST_Dtl.trans_dt,
                              SKYWEST_Dtl.chrg_typ,
                              SKYWEST_Dtl.chrg_amt,
                              SKYWEST_Dtl.flt_orig,
                              SKYWEST_Dtl.flt_dest,
                              SKYWEST_Dtl.flt_nbr,
                              SKYWEST_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF050, RS.EPBF050_buffer, sizeof(RS.EPBF050_buffer));
   RS.EPBF050_record_cnt++;


   RS.EPBF050_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF050_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF050_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2581_WriteChatauqua                      **
**                                                               **
** Description:     Format and Write Chatauqua Record              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2581_WriteChatauqua()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(CHATAUQUA_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF060_buffer, LOW_VALUES, sizeof(RS.EPBF060_buffer));
 
   /*** populate Chatauqua detail record structure ***/
   strcpy(CHATAUQUA_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(CHATAUQUA_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(CHATAUQUA_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(CHATAUQUA_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(CHATAUQUA_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(CHATAUQUA_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(CHATAUQUA_Dtl.flt_orig, "     ");
   else
      strcpy(CHATAUQUA_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(CHATAUQUA_Dtl.flt_dest, "     ");
   else
      strcpy(CHATAUQUA_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(CHATAUQUA_Dtl.flt_nbr, "     ");
   else
      strcpy(CHATAUQUA_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF060_buffer, CHATAUQUA_FORMAT,
                              CHATAUQUA_Dtl.ppr_nbr,
                              CHATAUQUA_Dtl.nrev_nbr,
                              CHATAUQUA_Dtl.nrev_nm,
                              CHATAUQUA_Dtl.nrev_typ_cd,
                              CHATAUQUA_Dtl.trans_dt,
                              CHATAUQUA_Dtl.chrg_typ,
                              CHATAUQUA_Dtl.chrg_amt,
                              CHATAUQUA_Dtl.flt_orig,
                              CHATAUQUA_Dtl.flt_dest,
                              CHATAUQUA_Dtl.flt_nbr,
                              CHATAUQUA_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF060, RS.EPBF060_buffer, sizeof(RS.EPBF060_buffer));
   RS.EPBF060_record_cnt++;


   RS.EPBF060_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF060_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF060_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2582_WriteShuttle                        **
**                                                               **
** Description:     Format and Write Shuttle Record              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2582_WriteShuttle()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(SHUTTLE_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF070_buffer, LOW_VALUES, sizeof(RS.EPBF070_buffer));
 
   /*** populate Shuttle detail record structure ***/
   strcpy(SHUTTLE_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(SHUTTLE_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(SHUTTLE_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(SHUTTLE_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(SHUTTLE_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(SHUTTLE_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(SHUTTLE_Dtl.flt_orig, "     ");
   else
      strcpy(SHUTTLE_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(SHUTTLE_Dtl.flt_dest, "     ");
   else
      strcpy(SHUTTLE_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(SHUTTLE_Dtl.flt_nbr, "     ");
   else
      strcpy(SHUTTLE_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF070_buffer, SHUTTLE_FORMAT,
                              SHUTTLE_Dtl.ppr_nbr,
                              SHUTTLE_Dtl.nrev_nbr,
                              SHUTTLE_Dtl.nrev_nm,
                              SHUTTLE_Dtl.nrev_typ_cd,
                              SHUTTLE_Dtl.trans_dt,
                              SHUTTLE_Dtl.chrg_typ,
                              SHUTTLE_Dtl.chrg_amt,
                              SHUTTLE_Dtl.flt_orig,
                              SHUTTLE_Dtl.flt_dest,
                              SHUTTLE_Dtl.flt_nbr,
                              SHUTTLE_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF070, RS.EPBF070_buffer, sizeof(RS.EPBF070_buffer));
   RS.EPBF070_record_cnt++;


   RS.EPBF070_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF070_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF070_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2583_WriteFreedom                        **
**                                                               **
** Description:     Format and Write Freedom Record              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2583_WriteFreedom()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(FREEDOM_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF080_buffer, LOW_VALUES, sizeof(RS.EPBF080_buffer));
 
   /*** populate Freedom detail record structure ***/
   strcpy(FREEDOM_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(FREEDOM_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(FREEDOM_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(FREEDOM_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(FREEDOM_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(FREEDOM_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(FREEDOM_Dtl.flt_orig, "     ");
   else
      strcpy(FREEDOM_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(FREEDOM_Dtl.flt_dest, "     ");
   else
      strcpy(FREEDOM_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(FREEDOM_Dtl.flt_nbr, "     ");
   else
      strcpy(FREEDOM_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF080_buffer, FREEDOM_FORMAT,
                              FREEDOM_Dtl.ppr_nbr,
                              FREEDOM_Dtl.nrev_nbr,
                              FREEDOM_Dtl.nrev_nm,
                              FREEDOM_Dtl.nrev_typ_cd,
                              FREEDOM_Dtl.trans_dt,
                              FREEDOM_Dtl.chrg_typ,
                              FREEDOM_Dtl.chrg_amt,
                              FREEDOM_Dtl.flt_orig,
                              FREEDOM_Dtl.flt_dest,
                              FREEDOM_Dtl.flt_nbr,
                              FREEDOM_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF080, RS.EPBF080_buffer, sizeof(RS.EPBF080_buffer));
   RS.EPBF080_record_cnt++;


   RS.EPBF080_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF080_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF080_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2584_WriteASA                            **
**                                                               **
** Description:     Format and Write ASA Record                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2584_WriteASA()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(ASA_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF081_buffer, LOW_VALUES, sizeof(RS.EPBF081_buffer));
 
   /*** populate ASA detail record structure ***/
   strcpy(ASA_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(ASA_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(ASA_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(ASA_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(ASA_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(ASA_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(ASA_Dtl.flt_orig, "     ");
   else
      strcpy(ASA_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(ASA_Dtl.flt_dest, "     ");
   else
      strcpy(ASA_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(ASA_Dtl.flt_nbr, "     ");
   else
      strcpy(ASA_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF081_buffer, ASA_FORMAT,
                              ASA_Dtl.ppr_nbr,
                              ASA_Dtl.nrev_nbr,
                              ASA_Dtl.nrev_nm,
                              ASA_Dtl.nrev_typ_cd,
                              ASA_Dtl.trans_dt,
                              ASA_Dtl.chrg_typ,
                              ASA_Dtl.chrg_amt,
                              ASA_Dtl.flt_orig,
                              ASA_Dtl.flt_dest,
                              ASA_Dtl.flt_nbr,
                              ASA_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF081, RS.EPBF081_buffer, sizeof(RS.EPBF081_buffer));
   RS.EPBF081_record_cnt++;


   RS.EPBF081_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF081_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF081_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2585_WriteBigSky                         **
**                                                               **
** Description:     Format and Write Big Sky Record              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2585_WriteBigSky()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(BIGSKY_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF082_buffer, LOW_VALUES, sizeof(RS.EPBF082_buffer));
 
   /*** populate BIGSKY detail record structure ***/
   strcpy(BIGSKY_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(BIGSKY_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(BIGSKY_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(BIGSKY_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(BIGSKY_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(BIGSKY_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(BIGSKY_Dtl.flt_orig, "     ");
   else
      strcpy(BIGSKY_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(BIGSKY_Dtl.flt_dest, "     ");
   else
      strcpy(BIGSKY_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(BIGSKY_Dtl.flt_nbr, "     ");
   else
      strcpy(BIGSKY_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF082_buffer, BIGSKY_FORMAT,
                              BIGSKY_Dtl.ppr_nbr,
                              BIGSKY_Dtl.nrev_nbr,
                              BIGSKY_Dtl.nrev_nm,
                              BIGSKY_Dtl.nrev_typ_cd,
                              BIGSKY_Dtl.trans_dt,
                              BIGSKY_Dtl.chrg_typ,
                              BIGSKY_Dtl.chrg_amt,
                              BIGSKY_Dtl.flt_orig,
                              BIGSKY_Dtl.flt_dest,
                              BIGSKY_Dtl.flt_nbr,
                              BIGSKY_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF082, RS.EPBF082_buffer, sizeof(RS.EPBF082_buffer));
   RS.EPBF082_record_cnt++;


   RS.EPBF082_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF082_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF082_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2586_WriteExpressJet                     **
**                                                               **
** Description:     Format and Write EXPRESSJET Record           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2586_WriteExpressJet()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(EXPRESSJET_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF083_buffer, LOW_VALUES, sizeof(RS.EPBF083_buffer));
 
   /*** populate EXPRESSJET detail record structure ***/
   strcpy(EXPRESSJET_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EXPRESSJET_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EXPRESSJET_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EXPRESSJET_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EXPRESSJET_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(EXPRESSJET_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(EXPRESSJET_Dtl.flt_orig, "     ");
   else
      strcpy(EXPRESSJET_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(EXPRESSJET_Dtl.flt_dest, "     ");
   else
      strcpy(EXPRESSJET_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(EXPRESSJET_Dtl.flt_nbr, "     ");
   else
      strcpy(EXPRESSJET_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF083_buffer, EXPRESSJET_FORMAT,
                              EXPRESSJET_Dtl.ppr_nbr,
                              EXPRESSJET_Dtl.nrev_nbr,
                              EXPRESSJET_Dtl.nrev_nm,
                              EXPRESSJET_Dtl.nrev_typ_cd,
                              EXPRESSJET_Dtl.trans_dt,
                              EXPRESSJET_Dtl.chrg_typ,
                              EXPRESSJET_Dtl.chrg_amt,
                              EXPRESSJET_Dtl.flt_orig,
                              EXPRESSJET_Dtl.flt_dest,
                              EXPRESSJET_Dtl.flt_nbr,
                              EXPRESSJET_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF083, RS.EPBF083_buffer, sizeof(RS.EPBF083_buffer));
   RS.EPBF083_record_cnt++;


   RS.EPBF083_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF083_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF083_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2587_WritePinnacle                       **
**                                                               **
** Description:     Format and Write PINNACLE Record             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2587_WritePinnacle()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(PINNACLE_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF084_buffer, LOW_VALUES, sizeof(RS.EPBF084_buffer));
 
   /*** populate PINNACLE detail record structure ***/
   strcpy(PINNACLE_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(PINNACLE_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(PINNACLE_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(PINNACLE_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(PINNACLE_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(PINNACLE_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(PINNACLE_Dtl.flt_orig, "     ");
   else
      strcpy(PINNACLE_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(PINNACLE_Dtl.flt_dest, "     ");
   else
      strcpy(PINNACLE_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(PINNACLE_Dtl.flt_nbr, "     ");
   else
      strcpy(PINNACLE_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF084_buffer, PINNACLE_FORMAT,
                              PINNACLE_Dtl.ppr_nbr,
                              PINNACLE_Dtl.nrev_nbr,
                              PINNACLE_Dtl.nrev_nm,
                              PINNACLE_Dtl.nrev_typ_cd,
                              PINNACLE_Dtl.trans_dt,
                              PINNACLE_Dtl.chrg_typ,
                              PINNACLE_Dtl.chrg_amt,
                              PINNACLE_Dtl.flt_orig,
                              PINNACLE_Dtl.flt_dest,
                              PINNACLE_Dtl.flt_nbr,
                              PINNACLE_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF084, RS.EPBF084_buffer, sizeof(RS.EPBF084_buffer));
   RS.EPBF084_record_cnt++;


   RS.EPBF084_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF084_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF084_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}



/******************************************************************
**                                                               **
** Function Name:   DPM_2588_WriteXJ                             **
**                                                               **
** Description:     Format and Write Mesaba Record               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2588_WriteXJ()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(Mesaba_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF085_buffer, LOW_VALUES, sizeof(RS.EPBF085_buffer));
 
   /*** populate Mesaba detail record structure ***/
   strcpy(Mesaba_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(Mesaba_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(Mesaba_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(Mesaba_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(Mesaba_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(Mesaba_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(Mesaba_Dtl.flt_orig, "     ");
   else
      strcpy(Mesaba_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(Mesaba_Dtl.flt_dest, "     ");
   else
      strcpy(Mesaba_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(Mesaba_Dtl.flt_nbr, "     ");
   else
      strcpy(Mesaba_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF085_buffer, Mesaba_FORMAT,
                              Mesaba_Dtl.ppr_nbr,
                              Mesaba_Dtl.nrev_nbr,
                              Mesaba_Dtl.nrev_nm,
                              Mesaba_Dtl.nrev_typ_cd,
                              Mesaba_Dtl.trans_dt,
                              Mesaba_Dtl.chrg_typ,
                              Mesaba_Dtl.chrg_amt,
                              Mesaba_Dtl.flt_orig,
                              Mesaba_Dtl.flt_dest,
                              Mesaba_Dtl.flt_nbr,
                              Mesaba_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF085, RS.EPBF085_buffer, sizeof(RS.EPBF085_buffer));
   RS.EPBF085_record_cnt++;


   RS.EPBF085_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF085_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF085_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();


}


/******************************************************************
**                                                               **
** Function Name:   DPM_2589_WriteMLT                            **
**                                                               **
** Description:     Format and Write MLT Record                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2589_WriteMLT()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(MLT_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF086_buffer, LOW_VALUES, sizeof(RS.EPBF086_buffer));
 
   /*** populate MLT detail record structure ***/
   strcpy(MLT_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(MLT_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(MLT_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(MLT_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(MLT_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(MLT_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(MLT_Dtl.flt_orig, "     ");
   else
      strcpy(MLT_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(MLT_Dtl.flt_dest, "     ");
   else
      strcpy(MLT_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(MLT_Dtl.flt_nbr, "     ");
   else
      strcpy(MLT_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF086_buffer, MLT_FORMAT,
                              MLT_Dtl.ppr_nbr,
                              MLT_Dtl.nrev_nbr,
                              MLT_Dtl.nrev_nm,
                              MLT_Dtl.nrev_typ_cd,
                              MLT_Dtl.trans_dt,
                              MLT_Dtl.chrg_typ,
                              MLT_Dtl.chrg_amt,
                              MLT_Dtl.flt_orig,
                              MLT_Dtl.flt_dest,
                              MLT_Dtl.flt_nbr,
                              MLT_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF086, RS.EPBF086_buffer, sizeof(RS.EPBF086_buffer));
   RS.EPBF086_record_cnt++;


   RS.EPBF086_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF086_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF086_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2590_WriteCP                             **
**                                                               **
** Description:     Format and Write Compass Record              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2590_WriteCP()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(Compass_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF087_buffer, LOW_VALUES, sizeof(RS.EPBF087_buffer));
 
   /*** populate Compass detail record structure ***/
   strcpy(Compass_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(Compass_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(Compass_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(Compass_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(Compass_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(Compass_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(Compass_Dtl.flt_orig, "     ");
   else
      strcpy(Compass_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(Compass_Dtl.flt_dest, "     ");
   else
      strcpy(Compass_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(Compass_Dtl.flt_nbr, "     ");
   else
      strcpy(Compass_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF087_buffer, Compass_FORMAT,
                              Compass_Dtl.ppr_nbr,
                              Compass_Dtl.nrev_nbr,
                              Compass_Dtl.nrev_nm,
                              Compass_Dtl.nrev_typ_cd,
                              Compass_Dtl.trans_dt,
                              Compass_Dtl.chrg_typ,
                              Compass_Dtl.chrg_amt,
                              Compass_Dtl.flt_orig,
                              Compass_Dtl.flt_dest,
                              Compass_Dtl.flt_nbr,
                              Compass_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF087, RS.EPBF087_buffer, sizeof(RS.EPBF087_buffer));
   RS.EPBF087_record_cnt++;


   RS.EPBF087_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF087_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF087_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2591_WriteRS                             **
**                                                               **
** Description:     Format and Write Regional Record             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_2591_WriteRS()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(Regional_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF088_buffer, LOW_VALUES, sizeof(RS.EPBF085_buffer));
 
   /*** populate Regional detail record structure ***/
   strcpy(Regional_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(Regional_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(Regional_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(Regional_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(Regional_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(Regional_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(Regional_Dtl.flt_orig, "     ");
   else
      strcpy(Regional_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(Regional_Dtl.flt_dest, "     ");
   else
      strcpy(Regional_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(Regional_Dtl.flt_nbr, "     ");
   else
      strcpy(Regional_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF088_buffer, Regional_FORMAT,
                              Regional_Dtl.ppr_nbr,
                              Regional_Dtl.nrev_nbr,
                              Regional_Dtl.nrev_nm,
                              Regional_Dtl.nrev_typ_cd,
                              Regional_Dtl.trans_dt,
                              Regional_Dtl.chrg_typ,
                              Regional_Dtl.chrg_amt,
                              Regional_Dtl.flt_orig,
                              Regional_Dtl.flt_dest,
                              Regional_Dtl.flt_nbr,
                              Regional_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF088, RS.EPBF088_buffer, sizeof(RS.EPBF088_buffer));
   RS.EPBF088_record_cnt++;


   RS.EPBF088_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF088_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF088_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}


/******************************************************************
**                                                               **
** Function Name:   DPM_2592_WriteDGS                            **
**                                                               **
** Description:     Format and Write Delta Staffing              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2592_WriteDGS()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(DGS_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF089_buffer, LOW_VALUES, sizeof(RS.EPBF089_buffer));
 
   /*** populate DGS detail record structure ***/
   strcpy(DGS_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(DGS_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(DGS_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(DGS_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(DGS_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(DGS_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(DGS_Dtl.flt_orig, "     ");
   else
      strcpy(DGS_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(DGS_Dtl.flt_dest, "     ");
   else
      strcpy(DGS_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(DGS_Dtl.flt_nbr, "     ");
   else
      strcpy(DGS_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF089_buffer, DGS_FORMAT,
                              DGS_Dtl.ppr_nbr,
                              DGS_Dtl.nrev_nbr,
                              DGS_Dtl.nrev_nm,
                              DGS_Dtl.nrev_typ_cd,
                              DGS_Dtl.trans_dt,
                              DGS_Dtl.chrg_typ,
                              DGS_Dtl.chrg_amt,
                              DGS_Dtl.flt_orig,
                              DGS_Dtl.flt_dest,
                              DGS_Dtl.flt_nbr,
                              DGS_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF089, RS.EPBF089_buffer, sizeof(RS.EPBF089_buffer));
   RS.EPBF089_record_cnt++;


   RS.EPBF089_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF089_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF089_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2593_WriteG7                             **
**                                                               **
** Description:     Format and Write GoJet Staffing              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2593_WriteG7()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(G7_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF090_buffer, LOW_VALUES, sizeof(RS.EPBF090_buffer));
 
   /*** populate G7  detail record structure ***/
   strcpy(G7_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(G7_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(G7_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(G7_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(G7_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(G7_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(G7_Dtl.flt_orig, "     ");
   else
      strcpy(G7_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(G7_Dtl.flt_dest, "     ");
   else
      strcpy(G7_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(G7_Dtl.flt_nbr, "     ");
   else
      strcpy(G7_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF090_buffer, G7_FORMAT,
                              G7_Dtl.ppr_nbr,
                              G7_Dtl.nrev_nbr,
                              G7_Dtl.nrev_nm,
                              G7_Dtl.nrev_typ_cd,
                              G7_Dtl.trans_dt,
                              G7_Dtl.chrg_typ,
                              G7_Dtl.chrg_amt,
                              G7_Dtl.flt_orig,
                              G7_Dtl.flt_dest,
                              G7_Dtl.flt_nbr,
                              G7_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF090, RS.EPBF090_buffer, sizeof(RS.EPBF090_buffer));
   RS.EPBF090_record_cnt++;


   RS.EPBF090_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF090_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF090_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2594_WritePJ                             **
**                                                               **
** Description:     Format and Write Delta Private Jet           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2594_WritePJ()
{
   int i;
   char sTemp1ChrgAmt[9];
   char sTemp2ChrgAmt[8];
   double   dTempChrgAmt;
   char sTempDate[27];

   dTempChrgAmt = A02665.A02665_appl_area.dCostChrgAmt;

   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%06.2lf", dTempChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,6);
   memcpy(sTemp2ChrgAmt+6, sTemp1ChrgAmt+7,2); 
   strcpy(PJ_Dtl.chrg_amt, sTemp2ChrgAmt);
 
   /*** initialize the record buffer area ***/
   memset(&RS.EPBF091_buffer, LOW_VALUES, sizeof(RS.EPBF091_buffer));
 
   /*** populate PJ  detail record structure ***/
   strcpy(PJ_Dtl.ppr_nbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(PJ_Dtl.nrev_nbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(PJ_Dtl.nrev_nm, A02665.A02665_appl_area.sNrevNm);
   strcpy(PJ_Dtl.nrev_typ_cd, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(PJ_Dtl.trans_dt, A02665.A02665_appl_area.sPassRptSortDt);
   strcpy(PJ_Dtl.chrg_typ, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") == 0)
      strcpy(PJ_Dtl.flt_orig, "     ");
   else
      strcpy(PJ_Dtl.flt_orig,A02665.A02665_appl_area.sFltOrigCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltDestCtyId, "*****") == 0)
      strcpy(PJ_Dtl.flt_dest, "     ");
   else
      strcpy(PJ_Dtl.flt_dest,A02665.A02665_appl_area.sFltDestCtyId);
   if (strcmp(A02665.A02665_appl_area.sFltNbr, "*****") == 0)
      strcpy(PJ_Dtl.flt_nbr, "     ");
   else
      strcpy(PJ_Dtl.flt_nbr,A02665.A02665_appl_area.sFltNbr);

   /***  Format the write buffer, and then write the record       ***/
   sprintf(RS.EPBF091_buffer, PJ_FORMAT,
                              PJ_Dtl.ppr_nbr,
                              PJ_Dtl.nrev_nbr,
                              PJ_Dtl.nrev_nm,
                              PJ_Dtl.nrev_typ_cd,
                              PJ_Dtl.trans_dt,
                              PJ_Dtl.chrg_typ,
                              PJ_Dtl.chrg_amt,
                              PJ_Dtl.flt_orig,
                              PJ_Dtl.flt_dest,
                              PJ_Dtl.flt_nbr,
                              PJ_Dtl.filler);
 
 
   BCH_WriteRec(RS.EPBF091, RS.EPBF091_buffer, sizeof(RS.EPBF091_buffer));
   RS.EPBF091_record_cnt++;


   RS.EPBF091_record_amt += A02665.A02665_appl_area.dCostChrgAmt;
   /**RS.EPBF091_record_amt += (atof(sTemp2ChrgAmt));  **/
   /**RS.EPBF091_record_amt += (atof(sTemp2ChrgAmt) / 100);  **/

   cInterfaceWritten = YES_CHAR;  /*  show that the interface record has been written */
   DPM_2520_UpdateProcessDate();

}

/******************************************************************
/******************************************************************
/******************************************************************
**                                                               **
** Function Name:   DPM_3000_WriteTotals                         **
**                                                               **
** Description:     Write the header record                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3000_WriteTotals()
{
   int i,j;
   char sTemp1ChrgAmt[13];
   char sTemp2ChrgAmt[12];
   char sTemp1TtlAmt[14];
   char sTemp2TtlAmt[13];
   double dTempTotAmt;
   char sTempDate[27];
   char sTempTime[27];

   /********************************************************************************/
   /*** Remove the period from the total charge amount and store as a string     ***/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF020_record_amt);
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,10);
   memcpy(sTemp2TtlAmt+10, sTemp1TtlAmt+11, 2);

   /********************************************************************************/
   /*** Format the write buffer and then write out the employee AR header record ***/
   /********************************************************************************/
   
   // Convert the Date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));

   // Convert time to HHMMSS format
   strncpy(sTempTime, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_HHMMSS_ONLY),
    sizeof(sTempTime));

   sprintf(RS.EPBF020_buffer, HEADER_FORMAT,
                           "HDR",
                           sTempDate,
                           sTempTime,
                           RS.EPBF020_record_cnt,
                           sTemp2TtlAmt,
                           sEndOfHdr);

   BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));

   /********************************************************************************/
   /*** Remove the period from the total charge amount and store as a string     ***/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
   sprintf(sTemp1TtlAmt, "%09.2f", RS.EPBF030_record_amt);
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2);

   /********************************************************************************/
   /*** Format the write buffer and then write out the Worldspan header record   ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
 
   sprintf(RS.EPBF030_buffer, WSP_HEADER_FORMAT,
                           "WS",
                           sTempDate,
                           sTemp2TtlAmt,
                           sEndOfWSPHdr);
 
   BCH_WriteRec(RS.EPBF030, RS.EPBF030_buffer, sizeof(RS.EPBF030_buffer));

   /********************************************************************************/
   /*** Remove the period from the total charge amount and store as a string     ***/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
   /****
   sprintf(sTemp1TtlAmt, "%09.2f", RS.EPBF040_record_amt);
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2);
   ****/

   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF040_record_amt);
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,10);
   memcpy(sTemp2TtlAmt+10, sTemp1TtlAmt+11, 2);

   /********************************************************************************/
   /*** Format the write buffer and then write out the Song header record   ***/
   /********************************************************************************/

   // Convert the Date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));

   // Convert time to HHMMSS format
   strncpy(sTempTime, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_HHMMSS_ONLY),
    sizeof(sTempTime));

   sprintf(RS.EPBF040_buffer, SONG_HEADER_FORMAT,
			   "Co Code",
			   cDelimiter,
			   "Batch ID",
			   cDelimiter,
			   "File #",
			   cDelimiter,
			   "Adjust Ded Code",
			   cDelimiter,
			   "Adjust Ded Amount");
 
   BCH_WriteRec(RS.EPBF040, RS.EPBF040_buffer, sizeof(RS.EPBF040_buffer));
   /********************************************************************************/
   /******** Format total Skywest amount     ******************/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
/**dTempTotAmt = RS.OO_total_amt;  **/
/**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF050_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF050_record_amt); 
/**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the Skywest header record   ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF050_buffer, SKYWEST_HEADER_FORMAT,
                           "OO",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfSKYWESTHdr);
 
   BCH_WriteRec(RS.EPBF050, RS.EPBF050_buffer, sizeof(RS.EPBF050_buffer));

   /********************************************************************************/
   /******** Format total Chatauqua amount     ******************/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
/**dTempTotAmt = RS.RP_total_amt;  **/
/**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF060_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF060_record_amt); 
/**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the Chatauqua header record   ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF060_buffer, CHATAUQUA_HEADER_FORMAT,
                           "RP",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfCHATAUQUAHdr);
 
   BCH_WriteRec(RS.EPBF060, RS.EPBF060_buffer, sizeof(RS.EPBF060_buffer));

   /********************************************************************************/
   /******** Format total Shuttle amount     ******************/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
/**dTempTotAmt = RS.S5_total_amt;  **/
/**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF070_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF070_record_amt); 
/**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the Shuttle header record   ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF070_buffer, SHUTTLE_HEADER_FORMAT,
                           "S5",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfSHUTTLEHdr);
 
   BCH_WriteRec(RS.EPBF070, RS.EPBF070_buffer, sizeof(RS.EPBF070_buffer));

   /********************************************************************************/
   /******** Format total Freedom amount     ******************/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
/**dTempTotAmt = RS.F8_total_amt;  **/
/**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF080_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF080_record_amt); 
/**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the Freedom header record   ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF080_buffer, FREEDOM_HEADER_FORMAT,
                           "F8",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfFREEDOMHdr);
 
   BCH_WriteRec(RS.EPBF080, RS.EPBF080_buffer, sizeof(RS.EPBF080_buffer));

   /********************************************************************************/
   /******** Format total ASA amount     ******************/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
/**dTempTotAmt = RS.F8_total_amt;  **/
/**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF081_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF081_record_amt); 
/**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 



   /********************************************************************************/
   /*** Format the write buffer and then write out the ASA header record   ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF081_buffer, ASA_HEADER_FORMAT,
                           "AS",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfASAHdr);
 
   BCH_WriteRec(RS.EPBF081, RS.EPBF081_buffer, sizeof(RS.EPBF081_buffer));



   /********************************************************************************/
   /******** Format total Big Sky amount     ******************/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
/**dTempTotAmt = RS.GQ_total_amt;  **/
/**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF082_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF082_record_amt); 
/**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 



   /********************************************************************************/
   /*** Format the write buffer and then write out the Big Sky header record   ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF082_buffer, BIGSKY_HEADER_FORMAT,
                           "GQ",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfBIGSKYHdr);
 
   BCH_WriteRec(RS.EPBF082, RS.EPBF082_buffer, sizeof(RS.EPBF082_buffer));

   /********************************************************************************/
   /******** Format total Express Jet amount     ******************/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
/**dTempTotAmt = RS.XE_total_amt;  **/
/**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF083_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF083_record_amt); 
/**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the Express Jet header record  ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF083_buffer, EXPRESSJET_HEADER_FORMAT,
                           "XE",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfEXPRESSJETHdr);
 
   BCH_WriteRec(RS.EPBF083, RS.EPBF083_buffer, sizeof(RS.EPBF083_buffer));

   /********************************************************************************/
   /*** Format the write buffer and then write out the Pinnacle header record    ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF084_buffer, PINNACLE_HEADER_FORMAT,
                           "9E",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfPINNACLEHdr);
 
   BCH_WriteRec(RS.EPBF084, RS.EPBF084_buffer, sizeof(RS.EPBF084_buffer));


   /********************************************************************************/
   /******** Format total Mesaba Amount - XJ                              **********/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
  /**dTempTotAmt = RS.XJ_total_amt;  **/
  /**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF085_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF085_record_amt); 
  /**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the XJ header record          ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF085_buffer, Mesaba_HEADER_FORMAT,
                           "XJ",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfMesabaHdr);
 
   BCH_WriteRec(RS.EPBF085, RS.EPBF085_buffer, sizeof(RS.EPBF085_buffer));
 
   /********************************************************************************/
   /******** Format total Regional Amount - RS                            **********/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
  /**dTempTotAmt = RS.RS_total_amt;  **/
  /**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF088_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF088_record_amt); 
  /**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the RS header record          ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF088_buffer, Regional_HEADER_FORMAT,
                           "RS",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfRegionalHdr);
 
   BCH_WriteRec(RS.EPBF088, RS.EPBF088_buffer, sizeof(RS.EPBF088_buffer));
 
   /********************************************************************************/
   /******** Format total MLT Amount                                      **********/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
  /**dTempTotAmt = RS.MLT_total_amt;  **/
  /**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF086_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF086_record_amt); 
  /**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the MLT header record         ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF086_buffer, MLT_HEADER_FORMAT,
                           "ML",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfMLTHdr);
 
   BCH_WriteRec(RS.EPBF086, RS.EPBF086_buffer, sizeof(RS.EPBF086_buffer));
 
   /********************************************************************************/
   /******** Format total Compass - CP                                    **********/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
  /**dTempTotAmt = RS.CP_total_amt;  **/
  /**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF087_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF087_record_amt); 
  /**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the CP header record          ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF087_buffer, Compass_HEADER_FORMAT,
                           "CP",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfCompassHdr);

   BCH_WriteRec(RS.EPBF087, RS.EPBF087_buffer, sizeof(RS.EPBF087_buffer));


   /********************************************************************************/
   /******** Format total Delta Staffing - DS                             **********/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
  /**dTempTotAmt = RS.DeltaStaffing_amt; **/
  /**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF089_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF089_record_amt); 
  /**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the DGS header record         ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF089_buffer, DGS_HEADER_FORMAT,
                           "DS",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfDGSHdr);

   BCH_WriteRec(RS.EPBF089, RS.EPBF089_buffer, sizeof(RS.EPBF089_buffer));
  /******  }  commenting out this bracket due to error  ******/

   /********************************************************************************/
   /******** Format total GoJet  - G7                                     **********/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
  /**dTempTotAmt = RS.GoJet_amt; **/
  /**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF090_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF090_record_amt); 
  /**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the GoJet header record         ***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF090_buffer, G7_HEADER_FORMAT,
                           "G7",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfG7Hdr);

   BCH_WriteRec(RS.EPBF090, RS.EPBF090_buffer, sizeof(RS.EPBF090_buffer));
/*****    }  commenting out this bracket due to compile error     *******/

   /********************************************************************************/
   /******** Format total Delta Private Jet - OH                          **********/
   /********************************************************************************/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTemp2TtlAmt, LOW_VALUES, sizeof(sTemp2TtlAmt));
  /**dTempTotAmt = RS.DPJet_amt; **/
  /**   sprintf(sTemp1TtlAmt, "%013.2f", RS.EPBF091_record_amt); **/
   sprintf(sTemp1TtlAmt, "%09.2lf", RS.EPBF091_record_amt); 
  /**Elona2 sprintf(sTemp1TtlAmt, "%09.2lf", dTempTotAmt); **/
   strcpy(sTemp2TtlAmt, "000000.00");
   memcpy(sTemp2TtlAmt, sTemp1TtlAmt,6);
   memcpy(sTemp2TtlAmt+6, sTemp1TtlAmt+7, 2); 


   /********************************************************************************/
   /*** Format the write buffer and then write out the Delta Private Jet header rec***/
   /********************************************************************************/

   // Convert the date to YYYYMMDD format
   strncpy(sTempDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));
   sprintf(RS.EPBF091_buffer, PJ_HEADER_FORMAT,
                           "OH",
                           sTempDate,
                           sTemp1TtlAmt,
                           sEndOfPJHdr);

   BCH_WriteRec(RS.EPBF091, RS.EPBF091_buffer, sizeof(RS.EPBF091_buffer));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_4920_ProcessLUW()
{
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5000_GenerateEPB54011                    **
**                                                               **
** Description:     Write records for report EPB54011            **
**                  Pass Charges Invoices                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_5000_GenerateEPB54011()
{
   short     nRptIndex;     /* Index into the report control table */


   /** Initialize and Format report fields in sort and data layouts **/
   memset(&EPRF0540.F0540_RptDataStruct, LOW_VALUES, sizeof(_F0540_RPTDATASTRUCT));
   memset(&EPRS0540.S0540_RptDataStruct, LOW_VALUES, sizeof(_S0540_RPTDATASTRUCT));

   strcpy(EPRF0540.F0540_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm); 
   strcpy(EPRF0540.F0540_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0540.F0540_RptDataStruct.sPpr1Addr, A02666.A02666_appl_area.sPpr1Addr);
   strcpy(EPRF0540.F0540_RptDataStruct.sPpr2Addr, A02666.A02666_appl_area.sPpr2Addr);
   strcpy(EPRF0540.F0540_RptDataStruct.sPprCtyAddr, A02666.A02666_appl_area.sPprCtyAddr);
   strcpy(EPRF0540.F0540_RptDataStruct.sPprStCd, A02666.A02666_appl_area.sPprStCd);
   strcpy(EPRF0540.F0540_RptDataStruct.sPprZipAddr, A02666.A02666_appl_area.sPprZipAddr);
   strcpy(EPRF0540.F0540_RptDataStruct.sPprCtryCd, A02666.A02666_appl_area.sPprCtryCd);     
   strcpy(EPRF0540.F0540_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0540.F0540_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0540.F0540_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   strcpy(EPRF0540.F0540_RptDataStruct.sOthrEmptCd, A02665.A02665_appl_area.sOthrEmptCd); // DS: to support NW retirees

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0540.F0540_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0540.F0540_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   if (strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") != 0)
      {
      strcpy(EPRF0540.F0540_RptDataStruct.sFltOrigCtyId, A02665.A02665_appl_area.sFltOrigCtyId);
      strcpy(EPRF0540.F0540_RptDataStruct.sFltDestCtyId, A02665.A02665_appl_area.sFltDestCtyId);
      }
   else if(strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") ==0 && 
           strcmp(EPRF0540.F0540_RptDataStruct.sSvcChrgDs, "REFUND") !=0)
      {
      memset(EPRF0540.F0540_RptDataStruct.sSvcChrgDs, NULL, 15);
      strcpy(EPRF0540.F0540_RptDataStruct.sSvcChrgDs, A02665.A02665_appl_area.sSvcChrgDs);
      strcpy(EPRF0540.F0540_RptDataStruct.sSvcChrgCd, A02665.A02665_appl_area.sSvcChrgCd);
      }
   else if(strcmp(A02665.A02665_appl_area.sFltOrigCtyId, "*****") ==0 && 
           strcmp(EPRF0540.F0540_RptDataStruct.sSvcChrgDs, "REFUND") ==0)
      {
      memset(EPRF0540.F0540_RptDataStruct.sFltOrigCtyId, NULL, 5);
      memset(EPRF0540.F0540_RptDataStruct.sFltDestCtyId, NULL, 5);
      }

   //EPRF0540.F0540_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt; 
   sprintf(EPRF0540.F0540_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);
   EPRF0540.F0540_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;


   strcpy(EPRS0540.S0540_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0540.S0540_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0540.S0540_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54011", &EPRS0540, sizeof(EPRS0540), &EPRF0540, sizeof(EPRF0540));
}                        

/******************************************************************
**                                                               **
** Function Name:   DPM_5010_GenerateEPB54012                    **
**                                                               **
** Description:     Write report records for report EPB54012     **
**                  Worldspan Detail Report                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5010_GenerateEPB54012()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
 /** Initialize and Format report fields in sort and data layouts **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54012", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5020_GenerateEPB54013                    **
**                                                               **
** Description:     Write report records for report EPB54013     **
**                  TransQuest Detail Report                     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5020_GenerateEPB54013()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The TransQuest detail report is in the same format as the    **/
   /** WorldSpan report, so the same copybook is used for both      **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54013", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}


/******************************************************************
**                                                               **
** Function Name:   DPM_5030_GenerateEPB54014                    **
**                                                               **
** Description:     Write report records for report EPB54014     **
**                  Delta Staffing Detail Report                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5030_GenerateEPB54014()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Delta Staffing detail report is in the same format as the**/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54014", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}



/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54015                    **
**                                                               **
** Description:     Write report records for report EPB54015     **
**                  ASA Detail Report                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54015()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Delta Staffing detail report is in the same format as the**/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54015", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}


/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54016                    **
**                                                               **
** Description:     Write report records for report EPB54016     **
**                  OH Detail Report                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54016()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Delta Staffing detail report is in the same format as the**/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54016", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54017                    **
**                                                               **
** Description:     Write report records for report EPB54017     **
**                  SO Detail Report                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54017()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Song detail report is in the same format as the**/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54017", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54018                    **
**                                                               **
** Description:     Write report records for report EPB54018     **
**                  CA Detail Report                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54018()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Comair Academy detail report is in the same format as the**/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54018", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54019                    **
**                                                               **
** Description:     Write report records for report EPB54019     **
**                  Skywest Detail Report                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54019()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Skywest detail report is in the same format as the       **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54019", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54020                    **
**                                                               **
** Description:     Write report records for report EPB54020     **
**                  Chatauqua Detail Report                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54020()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Chatauqua detail report is in the same format as the     **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54020", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54021                    **
**                                                               **
** Description:     Write report records for report EPB54021     **
**                  Shuttle Detail Report                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54021()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Shuttle detail report is in the same format as the       **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54021", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54022                    **
**                                                               **
** Description:     Write report records for report EPB54022     **
**                  Freedom Detail Report                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54022()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Freedom detail report is in the same format as the       **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54022", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}


/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54023                    **
**                                                               **
** Description:     Write report records for report EPB54023     **
**                  Big Sky Detail Report                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54023()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Big Sky detail report is in the same format as the       **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54023", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}


/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54024                    **
**                                                               **
** Description:     Write report records for report EPB54024     **
**                  Express Jet Detail Report                    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54024()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Express Jet detail report is in the same format as the   **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54024", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}


/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54025                    **
**                                                               **
** Description:     Write report records for report EPB54025     **
**                  Pinnacle Detail Report                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54025()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The Pinnacle detail report is in the same format as the   **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54025", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}


/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54026                    **
**                                                               **
** Description:     Write report records for report EPB54026     **
**                  XJ Detail Report                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54026()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The XJ detail report is in the same format as the            **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54026", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54027                    **
**                                                               **
** Description:     Write report records for report EPB54027     **
**                  MLT Detail Report                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54027()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The MLT detail report is in the same format as the           **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54023", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54028                    **
**                                                               **
** Description:     Write report records for report EPB54028     **
**                  CP Detail Report                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54028()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The CP detail report is in the same format as the            **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54028", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}


/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54029                    **
**                                                               **
** Description:     Write report records for report EPB54029     **
**                  RS Detail Report                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54029()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The RS detail report is in the same format as the            **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54029", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54030                    **
**                                                               **
** Description:     Write report records for report EPB54030     **
**                  G7 Detail Report                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54030()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The G7 detail report is in the same format as the            **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of the all of them.                           **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54030", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}


/******************************************************************
**                                                               **
** Function Name:   DPM_5040_GenerateEPB54031                    **
**                                                               **
** Description:     Write report records for report EPB54031     **
**                  PJ Detail Report                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void    DPM_5040_GenerateEPB54031()
{
   short     nRptIndex;      /* Index into the report control table */
 
 
   /** Initialize and Format report fields in sort and data layouts **/
   /** The PJ detail report is in the same format as the            **/
   /** Worldspan and Transquest Detail report, so the same copybook **/
   /** is used in all of them.                                      **/
   memset(&EPRF0541.F0541_RptDataStruct, LOW_VALUES, sizeof(_F0541_RPTDATASTRUCT));
   memset(&EPRS0541.S0541_RptDataStruct, LOW_VALUES, sizeof(_S0541_RPTDATASTRUCT));

   strcpy(EPRF0541.F0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprNm, A02666.A02666_appl_area.sPprNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sPprSocSecNbr, '9');
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevNm, A02665.A02665_appl_area.sNrevNm);
   strcpy(EPRF0541.F0541_RptDataStruct.sNrevTypDs, A02529.A02529_appl_area.sNrevTypDs);
   strcpy(EPRF0541.F0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sFltDprtDt);
   //EPRF0541.F0541_RptDataStruct.dCostChrgAmt =  A02665.A02665_appl_area.dCostChrgAmt;
   sprintf(EPRF0541.F0541_RptDataStruct.sCostChrgAmt, "%9.2f", A02665.A02665_appl_area.dCostChrgAmt);

   if (A02665.A02665_appl_area.dCostChrgAmt < 0)
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, "REFUND");
   else
      strcpy(EPRF0541.F0541_RptDataStruct.sSvcChrgDs, sSaveSvcChrgDs);

   EPRF0541.F0541_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS0541.S0541_RptDataStruct.sPprNbr, A02665.A02665_appl_area.sPprNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sNrevNbr, A02665.A02665_appl_area.sNrevNbr);
   strcpy(EPRS0541.S0541_RptDataStruct.sFltDprtDt, A02665.A02665_appl_area.sPassRptSortDt);

   BCH_WriteRptRec("EPB54031", &EPRS0541, sizeof(EPRS0541), &EPRF0541, sizeof(EPRF0541));
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{
   BCH_Close(RS.EPBF020);
   BCH_Close(RS.EPBF030);
   BCH_Close(RS.EPBF040);
   BCH_Close(RS.EPBF050);
   BCH_Close(RS.EPBF060);
   BCH_Close(RS.EPBF070);
   BCH_Close(RS.EPBF080);
   BCH_Close(RS.EPBF081);
   BCH_Close(RS.EPBF082);
   BCH_Close(RS.EPBF083);
   BCH_Close(RS.EPBF084);
   BCH_Close(RS.EPBF085);
   BCH_Close(RS.EPBF086);
   BCH_Close(RS.EPBF087);
   BCH_Close(RS.EPBF088);
   BCH_Close(RS.EPBF089);
   BCH_Close(RS.EPBF090);
   
   /** write control totals here **/

   BCH_FormatMessage(1,TXT_INPUT_FILE, "T_CHRG");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.TblItemsRead);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF020");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF020_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF020_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF030");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF030_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF030_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF040");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF040_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF040_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF050");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF050_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF050_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF060");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF060_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF060_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF070");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF070_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF070_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF080");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF080_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF080_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF081");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF081_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF081_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF082");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF082_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF082_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF083");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF083_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF083_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF084");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF084_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF084_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF085");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF085_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF085_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
  
   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF086");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF086_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF086_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF087");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF087_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF087_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF088");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF088_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF088_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF089");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF089_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF089_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
   
   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF090");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF090_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF090_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF091");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF091_record_cnt);
   BCH_FormatMessage(3,TXT_AMT_TTL, RS.EPBF091_record_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
