/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    <EPB56001.c>                                           **
**                                                                         **
** Shell Used:      <shltmpc.c>                                            **
**                                                                         **
** Program Type:    Transaction Driven Process Module                      **
**                                                                         **
** Author :         Delta Technology                                       **
**                  Lorenzo Scott                                          **
**                                                                         **
** Date Written:    08/28/98                                               **
**                                                                         **
** Description:     This module updates the flt_certft table with          **
**                  Family & Friends and Above & Beyond certificate data   **
**                  passed on an interface file passed from Deltamatic.    **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
****************************************************************************/

#include "epb56001.h"


main()
{
   BCH_Init("EPB56001", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}



/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{

 
 /**** Initialize counters & accumulators ***/

 /**** Initialize RSAM variables ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sCertftExtnNbr, SPACE_CHAR);
   strcpy(RS.sFltCertftNbr, SPACE_CHAR);
   strcpy(RS.sCertftIssDt, SPACE_CHAR);
   strcpy(RS.sCertftExpDt, SPACE_CHAR);

 /**** Build thread table ***/

 /**** Initialize Message Request and Answer Copybooks ***/

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");


/**** NOTE: BCH_GetCurrentDate() will give current date and time in many 
             formats.  (including Sort, Display, and Timestamp)  ****/  



   /*********** Open Deltamatic Interface file            *********/
   RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_READ);
   if (RS.EPBF010 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

   /************ Read first interface record            ************/
   memset(RS.EPBF010_buffer,' ',sizeof(RS.EPBF010_buffer));
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));

   if (BCH_eof(RS.EPBF010))
   {
       BCH_FormatMessage(1,TXT_EMPTY_INPUT_FILE);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_1000_Initialize");
   }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
**                  Process the Deltamatic certificate records   **
**                                                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{


   while (!BCH_eof(RS.EPBF010))
      {
      DPM_3000_ProcessFileEPBF010();
      RS.Read++;
      }

   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);

}


/******************************************************************
**                                                               **
** Function Name:   DPM_3000_ProcessFileEPBF010                  **
**                                                               **
** Description:     Call function to process individual          **
**                  records then read next record from buffer.   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void DPM_3000_ProcessFileEPBF010()
{
  char PprNbr[10];
  char CertftExtnNbr[3];
  char FltCertftNbr[11];
  char CertftIssDt[9];
  char CertftExpDt[9];
  char cProcSw = 'Y';
  char cCertftSw = 'N';
  int i = 0;


   strcpy(PprNbr, RS.sPprNbr);
   strcpy(CertftExtnNbr, RS.sCertftExtnNbr);
   strcpy(FltCertftNbr, RS.sFltCertftNbr);
   strcpy(CertftIssDt, RS.sCertftIssDt);
   strcpy(CertftExpDt, RS.sCertftExpDt);

   strncpy(RS.sPprNbr, (char *)RS.EPBF010_buffer,9);
   strncpy(RS.sCertftExtnNbr, (char *)RS.EPBF010_buffer+9,2);
   strncpy(RS.sFltCertftNbr, (char *)RS.EPBF010_buffer+11,10);
   strncpy(RS.sCertftIssDt, (char *)RS.EPBF010_buffer+21,8);
   strncpy(RS.sCertftExpDt, (char *)RS.EPBF010_buffer+37,8);

   // Remove trailing spaces from string variables
   UTL_StripTrailingSpaces(RS.sPprNbr);
   UTL_StripTrailingSpaces(RS.sCertftExtnNbr);
   UTL_StripTrailingSpaces(RS.sFltCertftNbr);
   UTL_StripTrailingSpaces(RS.sCertftIssDt);
   UTL_StripTrailingSpaces(RS.sCertftExpDt);

   /*** Dont process record if ppr number is all zero's.  ***/
   if (strcmp(RS.sPprNbr,"000000000") == 0)
      cProcSw = 'N';

   /*** Dont process record if extn nbr < 60; less than the F&F or A&B extension   ***/
   /*** number range                                                               ***/

   if (strcmp(RS.sCertftExtnNbr,"60") < 0)
      cProcSw = 'N';
      
if (cProcSw == 'Y')
   {
    /*** Get flight certificate records from the flt_certft table that matches interface records ***/
    memset(&A04629,LOW_VALUES,sizeof(A04629));
    strcpy(R04629.R04629_appl_area.sPprNbr, RS.sPprNbr);
    strcpy(R04629.R04629_appl_area.sCertftExtnNbr, RS.sCertftExtnNbr);
    strcpy(R04629.R04629_appl_area.sCertftIssDt, UTL_ConvertDate(RS.sCertftIssDt, CNV_YYYYMMDD_TO_DB));

    nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04629,&A04629,SERVICE_ID_04629,1,sizeof(R04629.R04629_appl_area));
    
    switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
	   cCertftSw = 'Y';
           break;

         case ARC_ROW_NOT_FOUND:
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_FormatMessage(2,TXT_SVC, "FYS04629");
            sprintf(sErrorMessage, "Ppr = %s, ExtNbr = %s, CertftIssDt = %s",
                          R04629.R04629_appl_area.sPprNbr,
                          R04629.R04629_appl_area.sCertftExtnNbr,
                          R04629.R04629_appl_area.sCertftIssDt);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_3000_ProcessFileNameEPBF010");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04629");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_ProcessFileNameEPBF010");

         } /* end switch */

    if ('Y' == cCertftSw) 
         {
         strcpy(R04630.R04630_appl_area.sPprNbr, A04629.A04629_appl_area.sPprNbr);
         strcpy(R04630.R04630_appl_area.sCertftExtnNbr, A04629.A04629_appl_area.sCertftExtnNbr);
         strcpy(R04630.R04630_appl_area.sFltCertftNbr, RS.sFltCertftNbr);
         strcpy(R04630.R04630_appl_area.sCertftIssDt, A04629.A04629_appl_area.sCertftIssDt);
         strcpy(R04630.R04630_appl_area.sCertftExpDt, UTL_ConvertDate(RS.sCertftExpDt, CNV_YYYYMMDD_TO_DB));
         
         nSvcRtnCd1 = BCH_InvokeService(EPBUPD0,&R04630,&A04630,SERVICE_ID_04630,1,sizeof(_R04630_APPL_AREA));
         switch (nSvcRtnCd1)
            {
            case ARC_SUCCESS:
           break;

         case ARC_ROW_NOT_FOUND:
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_3000_ProcessFileNameEPBF010");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04630");
            sprintf(sErrorMessage, "Ppr = %s, ExtNbr = %s, FltCertftNbr = %s, CertftIssDt = %s",
                          R04630.R04630_appl_area.sPprNbr,
                          R04630.R04630_appl_area.sCertftExtnNbr,
                          R04630.R04630_appl_area.sFltCertftNbr,
                          R04630.R04630_appl_area.sCertftIssDt);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_ProcessFileNameEPBF010");
         }  
    }
  }
   /*** Read next interface record ***/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer,sizeof(RS.EPBF010_buffer)); 
   DPM_8000_ProcessLUW();

}


/******************************************************************
**                                                               **
** Function Name:   DPM_8000_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int  DPM_8000_ProcessLUW()
{
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{

   BCH_Close(RS.EPBF010);


} 
