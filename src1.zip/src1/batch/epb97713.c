/*######################################################################*/
/*                                                                      */
/* Copyright [2001] Delta Air Lines, Inc./Delta Technology, Inc.   */
/*                       All Rights Reserved                            */
/*               Access, Modification, or Use Prohibited                */
/* Without Express Permission of Delta Air Lines or Delta Technology.   */
/*                                                                      */
/*######################################################################*/
/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB97713.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest, Inc.                                       **
**                  Gayle Melton                                           **
**                                                                         **
** Date Written:    October 28, 1996                                       **
**                                                                         **
** Description:     This module has been modified to read the flight       **
**                  certificate table and find certificate records         **
**                  that have not been processed and create the family     **
**                  and friends certificate ouptput file.                  **
**                  and creates the following record types:                **
**                  Company mail:                                          **
**                          AC,AK,MA (except depts 30, 31, 35,             **
**                          610, 611, 741),                                **
**                          KR,KT,MR,MT,SK,SM,SO,SR,ST                     **
**                                                                         ** 
**                  US mail:                                               **
**                          AC,AK,MA (includes depts 30,31,35,             **
**                          610,611,741 only),                             **
**                          DA,DB,DS,FU,LK,LM,LP,LS,MD,                    **
**                          QK,QM,QT,RE,RL,RR,RT,WE,WR,                    **
**                          WA,WB,WC,WD,WF,WG,WH,WK,WM,WS,WT               **
**                                                                         **
**                  for use in production of Family and Friends            **
**                  Certificates for DL and WSP employees.                 **
**                  Control totals are recorded to the message log.        **
**                                                                         **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **  
** 04/24/98   S. Makim                    Process Delta Staffing ppr       **  
**                                        records as Delta Technology ppr  **  
**                                        records. Send F&F or A&B         **  
**                                        certificates to their home       **  
**                                        address.                         **  
**                                                                         **  
** 06/24/98   L. Scott                    Correct problem with Feb 29th    **
**                                        anniversary dates not being      **
**                                        processed.   Feb 28th effective  **
**                                        date will now process Feb 29th,  **
**                                        while any calculated Feb 29th    **
**                                        effective date will be skipped.  **
**                                                                         **  
** 08/29/00   E. Shelton                  Add LP to certft procesing       **
**                                                                         **
** 10/08/01   L. Scott                    Added VA, VB, VC and VR to       **
**                                        certificate processing.          **
**                                                                         **
** 11/30/01   L. Scott                    Added FP as an eligible pass     **
**                                        group.                           **
**                                                                         **
** 01/02/02   E. Shelton                  Added IN as an eligible pass     **
**                                        group.                           **
**                                                                         **
** 11/08/02   L. Scott                    Added FV as an eligible pass     **
**                                        group.                           **
**                                                                         **
** 10/02/03   L. Scott                    Added TM as an eligible pass     **
**                                        group.                           **
**                                                                         **
** 09/20/04   L. Scott                    Added CU as an eligible pass     **
**                                        group.                           **
**                                                                         **
** 10/01/04   L. Scott                    Added TS as an eligible group.   **
**                                                                         **
****************************************************************************/
#include "epb97713.h"

main()
{
   BCH_Init("EPB97713", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short nRptIndex;                 /* Report index */
   short nReqRptInd1 = FALSE;       /* Required report #1 indicator */

   /**** Initialize key fields ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);

   /**** Initialize counters & accumulators ****/
   RS.EPBF030_record_cntr = 0;
   RS.EPBF040_record_cntr = 0;
   RS.total_record_cntr = 0;
   RS.COMail_cntr = 0;
   RS.FakeZip_COMail_cntr = 0;
   RS.USMail_cntr = 0;
   nSOMailCntr = 0;
   nCOMailCntr = 0;
   nFakeZip_COMailCntr = 1;
   nUSMailCntr = 0;
   nCount  = 1;
   
   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   /****** Initialize request and answer blocks *****/ 
   memset(&R04619, LOW_VALUES, sizeof(_R04619)); 
   memset(&A04619, LOW_VALUES, sizeof(_A04619)); 
 
   /***********  Output file EPBF030 **********/
   RS.EPBF030 = BCH_Open("EPBF030",BCH_FILE_WRITE);
   if (RS.EPBF030 == BCH_FAIL)
   {
      BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
      BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF030");
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   /****** Initialize request and answer blocks *****/
   memset(&R04619.R04619_appl_area, LOW_VALUES, sizeof(_R04619_APPL_AREA));
   memset(&A04619.A04619_appl_area, LOW_VALUES, sizeof(_A04619_APPL_AREA));

   /**** Format service request block for initial DB cursor read ****/

   /**** Open the DB cursor ****/
   R04619.R04619_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /**** Execute service to select all active PPRs    ****/
   /**** with records on the flight certificate table ****/
   /**** that have not been processed                 ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04619,&A04619,SERVICE_ID_04619,1,sizeof(_R04619_APPL_AREA));

   /** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04619");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows ****/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      DPM_2500_ProcessRows();

      R04619.R04619_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04619.A04619_appl_area,LOW_VALUES,sizeof(_A04619_APPL_AREA));

      /**** Execute service to obtain next DB row ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04619,&A04619,SERVICE_ID_04619,1,sizeof(R04619.R04619_appl_area));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04619");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();

   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   char   sStrtMo[2];     /** PPR start month MM **/
   char   sStrtDy[2];     /** PPR start day DD   **/  

   /**** Initialize date fields ****/
   memset(&sStrtMo, LOW_VALUES, sizeof(sStrtMo));
   memset(&sStrtDy, LOW_VALUES, sizeof(sStrtDy));
 
   /**** Format PPR start date without slash delimiters ****/
   strncpy(sStrtMo, A04619.A04619_appl_area.sPprStrtDt+DB_TS_POS_MON, 2);
   strncpy(sStrtDy, A04619.A04619_appl_area.sPprStrtDt+DB_TS_POS_DAY, 2);

   /** Pass Groups: AC, AK, MA, KR, MR, SR, SO, SK, SM                                     **/
   /*****************************************************************************************/
   if (!strcmp(A04619.A04619_appl_area.sPassGrpCd, ACTIVE_DL)    ||
       !strcmp(A04619.A04619_appl_area.sPassGrpCd, ACTIVE_DL_WK)  ||
       !strcmp(A04619.A04619_appl_area.sPassGrpCd, ACTIVE_DL_MRD) ||
       !strcmp(A04619.A04619_appl_area.sPassGrpCd, RDYRSV_SINGLE_WK) ||
       !strcmp(A04619.A04619_appl_area.sPassGrpCd, RDYRSV_MARRIED)   ||
       !strcmp(A04619.A04619_appl_area.sPassGrpCd, RDYRSV_SINGLE) ||
       !strcmp(A04619.A04619_appl_area.sPassGrpCd, SENIOR_OFFICERS) ||
       !strcmp(A04619.A04619_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) ||
       !strcmp(A04619.A04619_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD))
   {
      /***************************************************************************************/
      /** AC, AK, MA, KR, MR, SR, SO, SK, SM:                                               **/
      /** Write US MAIL record if PPR department number is 30, 31, 35, 610, 611, or 741     **/
      /** or, if ppr is Delta Technology (TransQuest) or Delta Staffing employee            **/
      /** or, if country code is USA, US, or PUR.                                           **/
      /***************************************************************************************/
      if (!strcmp(A04619.A04619_appl_area.sPprDeptNbr,"030") ||
          !strcmp(A04619.A04619_appl_area.sPprDeptNbr,"031") ||
          !strcmp(A04619.A04619_appl_area.sPprDeptNbr,"035") ||
          !strcmp(A04619.A04619_appl_area.sPprDeptNbr,"610") ||
          !strcmp(A04619.A04619_appl_area.sPprDeptNbr,"611") ||
          !strcmp(A04619.A04619_appl_area.sPprDeptNbr,"741") ||
          !strcmp(A04619.A04619_appl_area.sNrevSrcCd,"TQ")   ||
          !strcmp(A04619.A04619_appl_area.sNrevSrcCd,"DS")   ||
          !strcmp(A04619.A04619_appl_area.sPprCtryCd, "USA") ||
          !strcmp(A04619.A04619_appl_area.sPprCtryCd, "US")  ||
          !strcmp(A04619.A04619_appl_area.sPprCtryCd, "PUR") ||
          !strcmp(A04619.A04619_appl_area.sPprCtryCd, "ISV"))  
      { 
         DPM_3000_WriteRecord(40, RS.EPBF030_buffer);
         nUSMailCntr++;
         DPM_4000_UpdtCrtftRecord();
      } 
      /*********************************************************/
      /** AC, AK, MA, KR, MR, SR, SO, SK, SM:                 **/
      /** Write COMPANY MAIL record for other departments     **/
      /*********************************************************/
      else
      {
         DPM_3000_WriteRecord(30, RS.EPBF030_buffer);
         nCOMailCntr++;
         DPM_4000_UpdtCrtftRecord();
      }
   }
      /************************************************************************************************/
      /** Write US Mail record if the Pass Group is:                                                 **/
      /** DA, DB, DS, DW, EW, FU, LK, LM, LP, LS, LW, MD, OW, QK, QM, QT, RE, RL, RR, RT, TW, UW, WR,    **/
      /** WA, WB, WC, WD, WF, WK, WM, WS, WT, LT                                                     **/
      /************************************************************************************************/
   else
   {
      if (!strcmp(A04619.A04619_appl_area.sPassGrpCd, "DA") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "DB") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "DS") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "DW") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "EW") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "FU") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "LK") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "LM") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "LP") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "LS") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "LS") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "LT") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "MD") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "OW") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "QK") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "QM") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "QT") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "RE") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "RL") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "RR") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "RT") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "TW") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "UW") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "WA") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "WB") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "WC") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "WD") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "WF") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "WK") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "WM") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "WR") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "WS") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "LW") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "WT") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "VA") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "VB") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "VC") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "VR") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "FP") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "IN") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "FV") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "TM") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "CU") ||
          !strcmp(A04619.A04619_appl_area.sPassGrpCd, "TS"))

      {
         DPM_3000_WriteRecord(40, RS.EPBF030_buffer); 
         nUSMailCntr++;
         DPM_4000_UpdtCrtftRecord();
      }
   }
   //else
   //{
      /** Do Nothing: Folloging pass groups are not eligible to receive  **/
      /** Friends and Family certificates.                               **/
      /** BM, FW, PA, TS, VS, WE, WG, WH, WN, XX  k                      **/
      /** KT, MT, ST, TD, TQ pass groups are no longer valid.            **/
   //}
} 
   
/******************************************************************
**                                                               **
** Function Name:   DPM_3000_WriteRecord                         **
**                                                               **
** Description:     Format the appropriate output buffer         **
**                  with the passenger data and write the        **
**                  passenger record to the appropriate file.    **
**                                                               **
** Arguments:       File number,                                 **
**                  Variable buffer                              **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_3000_WriteRecord(short  sFileNbr,
                             char *sVarBuffer)
{
   char   sPprStrtDt[7];     /** PPR start date in form MMDDYY **/
   char   sIssueDt[7];       /** Issue date in form MMDDYY **/
   char   sSpace;            /** Space character **/

   short  i;                 /** Counter **/

   /**** Initialize the output record buffers ****/
   memset(&RS.EPBF030_buffer, SPACE, sizeof(RS.EPBF030_buffer));
 
   /**** Initialize date fields ****/
   memset(&sPprStrtDt, LOW_VALUES, sizeof(sPprStrtDt));
   memset(&sIssueDt, LOW_VALUES, sizeof(sIssueDt));

   /**** Format PPR start date without slash delimiters ****/
   strncpy(sPprStrtDt, A04619.A04619_appl_area.sPprStrtDt+DB_TS_POS_MON, 2);
   strncpy(sPprStrtDt+2, A04619.A04619_appl_area.sPprStrtDt+DB_TS_POS_DAY, 2);
   strncpy(sPprStrtDt+4, A04619.A04619_appl_area.sPprStrtDt+DB_TS_POS_YEAR_2, 2);

   /**** Format Certficate issue date without slash delimiters ****/
   strncpy(sIssueDt, A04619.A04619_appl_area.sCertftIssDt+DB_TS_POS_MON, 2);
   strncpy(sIssueDt+2, A04619.A04619_appl_area.sCertftIssDt+DB_TS_POS_DAY, 2);
   strncpy(sIssueDt+4, A04619.A04619_appl_area.sCertftIssDt+DB_TS_POS_YEAR_2, 2);

   /**** Initialize space character ****/
   memset(&sSpace, SPACE, sizeof(sSpace));

   /**** Format name and address in upper case ****/
   for (i=0; i < sizeof(A04619.A04619_appl_area.sPprNm); i++)
      A04619.A04619_appl_area.sPprNm[i] = toupper(A04619.A04619_appl_area.sPprNm[i]);

   for (i=0; i < sizeof(A04619.A04619_appl_area.sPpr1Addr); i++)
      A04619.A04619_appl_area.sPpr1Addr[i] = toupper(A04619.A04619_appl_area.sPpr1Addr[i]);

   for (i=0; i < sizeof(A04619.A04619_appl_area.sPpr2Addr); i++)
      A04619.A04619_appl_area.sPpr2Addr[i] = toupper(A04619.A04619_appl_area.sPpr2Addr[i]);

   for (i=0; i < sizeof(A04619.A04619_appl_area.sPprCtyAddr); i++)
      A04619.A04619_appl_area.sPprCtyAddr[i] = toupper(A04619.A04619_appl_area.sPprCtyAddr[i]);

   for (i=0; i < sizeof(A04619.A04619_appl_area.sPprStCd); i++)
      A04619.A04619_appl_area.sPprStCd[i] = toupper(A04619.A04619_appl_area.sPprStCd[i]);

   for (i=0; i < sizeof(A04619.A04619_appl_area.sPprCtryCd); i++)
      A04619.A04619_appl_area.sPprCtryCd[i] = toupper(A04619.A04619_appl_area.sPprCtryCd[i]);

   if (strcmp(A04619.A04619_appl_area.sPprStCd, "--") == 0) 
   { 
      strcpy(A04619.A04619_appl_area.sPprStCd, SPACE_CHAR); 
   }

   /****************************************************************************************/
   /** If writing a company mail record, format the output buffer with the station ID and **/
   /** department number for addresses 1 and 2 respectively and format other address fields*/
   /** with spaces.  Add US only ppr zip code to all company mail addresses.              **/
   /** 11/04/1997 SMAKIM:                                                                 **/
   /**                                                                                    **/
   /** For company mail records, when adding US only zip codes move spaces to the postal  **/
   /** zip code field.                                                                    **/
   /** 01/08/1997 LSCOTT:
   /****************************************************************************************/
   
   if (sFileNbr == 30)
   {
      strcpy(A04619.A04619_appl_area.sPprCtyAddr, SPACE_CHAR);
      strcpy(A04619.A04619_appl_area.sPprStCd, SPACE_CHAR); 

      if (strcmp(A04619.A04619_appl_area.sPprCtryCd, USA) == 0 ||
          strcmp(A04619.A04619_appl_area.sPprCtryCd, US) == 0 ||
          strcmp(A04619.A04619_appl_area.sPprCtryCd, PUR) == 0 ||
          strcmp(A04619.A04619_appl_area.sPprCtryCd, ISV) == 0)
      {
         /********************************************************/
         /** if the country is USA, PUR (Puerto Rico) or        **/
         /** ISV (Virgin Islands) populate the sUSOnlyZip and   **/
         /** space out the country code                         **/
         /** otherwise, space out the sUSOnlyZip                **/
         /********************************************************/
         strncpy(sUSOnlyZip, A04619.A04619_appl_area.sPprZipAddr,5);
         strcpy(A04619.A04619_appl_area.sPprZipAddr, SPACE_CHAR);
         strcpy(A04619.A04619_appl_area.sPprCtryCd, SPACE_CHAR);
         RS.USOnlyMailCntr++;
      }
      else
      {
         strcpy(sUSOnlyZip, SPACE_CHAR);
         strcpy(A04619.A04619_appl_area.sPprZipAddr, SPACE_CHAR);
         strcpy(A04619.A04619_appl_area.sPprCtryCd, SPACE_CHAR);
         RS.IntlMailCntr++;
      }

      if (strcmp(sUSOnlyZip, "00000") == 0)
      {
         strcpy(sUSOnlyZip, SPACE_CHAR);
      }

      if (A04619.A04619_appl_area.cCertftTypCd = 'F')
      {
         nCount = 1;
         sAbvByd = 'N';
      }
      else
      {
         nCount = 1;
         sAbvByd = 'Y';
      }
      cCount = nCount;

      /******************************************************/
      /**** Format output buffer for Company Mail record ****/
      /******************************************************/
      sprintf(sVarBuffer, PASSENGER_FORMAT, A04619.A04619_appl_area.sPprNbr,
                                            A04619.A04619_appl_area.sPprNm,
                                            A04619.A04619_appl_area.sPprDeptNbr,
                                            A04619.A04619_appl_area.sPprStnId,
                                            A04619.A04619_appl_area.sPprCtyAddr,
                                            A04619.A04619_appl_area.sPprStCd, 
                                            A04619.A04619_appl_area.sPprZipAddr,
                                            A04619.A04619_appl_area.sPprCtryCd,
                                            sUSOnlyZip,
                                            sPprStrtDt,
                                            sIssueDt,
                                            A04619.A04619_appl_area.sCertftExtnNbr,
                                            cCount, 
                                            sAbvByd, 
                                            sSpace);    
   }
   else  /** sFileNbr == 40 **/
   {
      if (strcmp(A04619.A04619_appl_area.sPprCtryCd, USA) == 0 ||
          strcmp(A04619.A04619_appl_area.sPprCtryCd, US) == 0 ||
          strcmp(A04619.A04619_appl_area.sPprCtryCd, PUR) == 0 ||
          strcmp(A04619.A04619_appl_area.sPprCtryCd, ISV) == 0) 
      {
         /********************************************************/
         /** if the country is USA, PUR (Puerto Rico) or        **/
         /** ISV (Virgin Islands) populate the sUSOnlyZip and   **/
         /** space out the country code                         **/
         /** otherwise, space out the sUSOnlyZip                **/
         /********************************************************/
         strncpy(sUSOnlyZip, A04619.A04619_appl_area.sPprZipAddr,5);
         RS.USOnlyMailCntr++;
         strcpy(A04619.A04619_appl_area.sPprCtryCd, SPACE_CHAR);
      }
      else
      {
         strcpy(sUSOnlyZip, SPACE_CHAR);
         RS.IntlMailCntr++;
      }

      if (A04619.A04619_appl_area.cCertftTypCd = 'F')
      {
         nCount = 1;
         sAbvByd = 'N';
      }
      else  
      {
         nCount  = 1;
         sAbvByd = 'Y';
      }

      cCount = nCount;
      
      if (strncmp(A04619.A04619_appl_area.sPprZipAddr, "00000", 5) ==0)
      {
         strcpy(sUSOnlyZip, SPACE_CHAR);
         strcpy(A04619.A04619_appl_area.sPprZipAddr, SPACE_CHAR);
      }

      /*************************************************/
      /**** Format output buffer for US Mail record ****/
      /*************************************************/
      sprintf(sVarBuffer, PASSENGER_FORMAT, A04619.A04619_appl_area.sPprNbr,
                                            A04619.A04619_appl_area.sPprNm,
                                            A04619.A04619_appl_area.sPpr1Addr,
                                            A04619.A04619_appl_area.sPpr2Addr,
                                            A04619.A04619_appl_area.sPprCtyAddr,
                                            A04619.A04619_appl_area.sPprStCd, 
                                            A04619.A04619_appl_area.sPprZipAddr,
                                            A04619.A04619_appl_area.sPprCtryCd,
                                            sUSOnlyZip,
                                            sPprStrtDt,
                                            sIssueDt,
                                            A04619.A04619_appl_area.sCertftExtnNbr,
                                            cCount, 
                                            sAbvByd,  
                                            sSpace); 
   }

   /******************************************************************************************/
   /** Write passenger record to the appropriate file and the increment output file counter **/
   /******************************************************************************************/

   if (sFileNbr == 30)
   {
      BCH_WriteRec(RS.EPBF030, RS.EPBF030_buffer, sizeof(RS.EPBF030_buffer));
      RS.EPBF030_record_cntr++;
      RS.total_record_cntr++;
   }
   else
   {
      BCH_WriteRec(RS.EPBF030, RS.EPBF030_buffer, sizeof(RS.EPBF030_buffer));
      RS.EPBF040_record_cntr++;
      RS.total_record_cntr++;
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4000_UpdtCrtftRecord                     **
**                                                               **
** Description:     Update the process date of the flight        **
**                  certificate records processed with today's   **
**                  date.                                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_4000_UpdtCrtftRecord()
{
   /****** Initialize request and answer blocks *****/
 
   /**** Format service request block for initial DB cursor read ****/
   //strcpy(R04620.R04620_appl_area.sPprNbr, A04619.A04619_appl_area.sPprNbr);
   // strcpy(R04620.R04620_appl_area.sCertftExtnNbr, A04619.A04619_appl_area.sCertftExtnNbr);
   //strcpy(R04620.R04620_appl_area.sCertftIssDt, A04619.A04619_appl_area.sCertftIssDt);
   R04620.R04620_appl_area.lSeqID = A04619.A04619_appl_area.lSeqID;

   /**** Execute service to update the flight         ****/
   /**** certificate records changing the process date****/
   /**** to current date.                             ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04620,&A04620,SERVICE_ID_04620,1,sizeof(_R04620_APPL_AREA));

   /** Service Return Code Processing  ****/
   switch (nSvcRtnCd) 
   {
      case ARC_SUCCESS:
         break;
               
      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_4000_UpdtCrtftRecord");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04620");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4000_UpdtCrtftRecord");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   /**** Clean-up processing ****/
   RS.COMail_cntr = nCOMailCntr;
   RS.USMail_cntr = nUSMailCntr;

   BCH_Close(RS.EPBF030);

   /**** Write control totals ****/
   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF030");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF030_record_cntr);
   BCH_FormatMessage(3,TXT_REC_TTL, RS.EPBF040_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "Company Mail Record Total: %d", RS.COMail_cntr);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "US Mail Record Total: %d", RS.USMail_cntr);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "US Only Mail Record Count: %d", RS.USOnlyMailCntr);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "Intl Mail Record Count: %d", RS.IntlMailCntr);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
