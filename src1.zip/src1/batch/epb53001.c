/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    <EPB53001.c>                                           **
**                                                                         **
** Shell Used:      <shltmpc.c>                                            **
**                                                                         **
** Program Type:    Transaction Driven Process Module                      **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Kenneth Hancock                                        **
**                                                                         **
** Date Written:    10/19/95                                               **
**                                                                         **
** Description:     This module adds records to the flt_leg and            **
**                  imput_flt_leg tables. The information is obtained      **
**                  from a nightly interface file passed from Deltamatic.  **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 06/17/96      FFA                      1) Drop records that contain test**
**                                           cities.                       **
**                                        2) Write errors to suspense table**
**                                        3) If nrev uses a lower priority **
**                                           pass than they are eligible for*
**                                           use lowest priority.          **
**                                        4) More descriptive error msgs.  **
**                                        5) Dont process family and friends*
**                                           nrev >= '80'                  **
**                                                                         **
** 10/22/96     FFA                       For Associates parents, always use*
**                                        the pass type returned from the  **
**                                       airport pr typ table if they has  **
**                                       a brd priority of S3 and the flt  **
**                                       leg was TA or TP.                 **
**                                                                         **
** 06/15/98     BBE                       Don't process Family and Friends **
**                                        or Above and Beyond flights      **
**                                       where nrev >= '60'                **
**                                                                         **
** 03/15/05     EJS                       change code to allow buddy pass  **
**                                        flt les to be processed.         **
**                                                                         **
** 12/20/05     LAS                       Allow for processing of S3C and  **
**                                        S3CR boarding priority flights   **
**                                                                         **
** 07/18/08     LAS                       Allow for processing of SNWA,    **
**                                        SNWR, S3NW, and S3NR boarding    **
**                                        priorities of Northwest employees**
**                                        on Delta and DCI flights.        **
**                                                                         **
** 01/13/10     LAS                       For pass groups GC,GK,GM,GR,GS & **
**                                        GT if boarding priority from file**
**                                        is S3CR change it to S3C.        **
**                                                                         **
** 08/06/13     GLW                       for pass group GA if boarding    **
**                                        priority from file is S3CR       **
**                                        change it to S3C                 **
**                                                                         **
** 10/08/14     BBE                       for boarding priority S3B1       **
**                                        from file, change it to S3       **
**                                        for boarding priority S3D,       **
**                                        look at pass group and change    **
**                                        either to S3CR or                **
**                                                                         **
** 03/20/15     GLW                       S3CR issues for passgroups CB &  **
**                                        CW and correct S3B1 issues       **
****************************************************************************/

#include "epb53001.h"

main()
{
   BCH_Init("EPB53001", NUMBER_OF_THREADS);

   TPM_1000_Initialize();

   TPM_2000_Mainline();
}


/******************************************************************
**                                                               **
** Function Name:   TPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_1000_Initialize()
{

 
 /**** Initialize counters & accumulators ***/

 /**** Initialize RSAM variables ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sNrevNbr, SPACE_CHAR);
   strcpy(RS.sFltOrigCtyId, SPACE_CHAR);
   strcpy(RS.sFltNbr, SPACE_CHAR);
   strcpy(RS.sFltDestCtyId, SPACE_CHAR);

 /**** Build thread table ***/

 /**** Initialize Message Request and Answer Copybooks ***/
   memset(&R03962, LOW_VALUES, sizeof(_R03962));
   memset(&A03962, LOW_VALUES, sizeof(_A03962));
   memset(&R03952, LOW_VALUES, sizeof(_R03952));
   memset(&A03952, LOW_VALUES, sizeof(_A03952));
   memset(&R02792, LOW_VALUES, sizeof(_R02792));
   memset(&A02792, LOW_VALUES, sizeof(_A02792));
   memset(&R02496, LOW_VALUES, sizeof(_R02496));
   memset(&A02496, LOW_VALUES, sizeof(_A02496));
   memset(&R02511, LOW_VALUES, sizeof(_R02511));
   memset(&A02511, LOW_VALUES, sizeof(_A02511));
   memset(&R02797, LOW_VALUES, sizeof(_R02797));
   memset(&A02797, LOW_VALUES, sizeof(_A02797));

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_1000_Initialize");


/**** NOTE: BCH_GetCurrentDate() will give current date and time in many 
             formats.  (including Sort, Display, and Timestamp)  ****/  

   /*********** Open Incoming Deltamatic Interface file            *********/
   RS.EPBF010 = BCH_Open("EPBF010", BCH_FILE_READ);
   if (RS.EPBF010 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_1000_Initialize");
   }

   /************ Read first interface record            ************/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
   if (BCH_eof(RS.EPBF010))
   {
       BCH_FormatMessage(1,TXT_EMPTY_INPUT_FILE);
       BCH_FormatMessage(2,TXT_INPUT_FILE, "EPBF010");
       BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_1000_Initialize");
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                  The main processing populates the request 	 **
**                  block for the insert into the flt_leg or     **
**                  imput_flt_leg table, Depending on if the     **
**                  passenger is imputed or not.                 **
**                  If the record cannot be added it  will be    **
**                  posted to The Suspense table for the Pass    **
**                  Beaureu to process.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_2000_Mainline()
{
    while (!BCH_eof(RS.EPBF010))
    {
        TPM_3000_ProcessFileEPBF010();
        RS.Read++;
    }

    TPM_9500_ProcessEndOfProgram();

    BCH_Terminate();

    exit(0);
}


/******************************************************************
**                                                               **
** Function Name:   TPM_3000_ProcessFileEPBF010                  **
**                                                               **
** Description:     Call function to process individual          **
**                  records then read next record from buffer.   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_3000_ProcessFileEPBF010()
{
  char PprNbr[9+1];
  char NrevNbr[2+1];
  char FltNbr[4+1];
  char FltOrigCtyId[5+1];
  char FltDestCtyId[5+1];
  char DprtDt[27];
  char cProcSw = 'Y';
  char *pTemp;
  int i = 0;


   servid = '0';
   memset(&RS.sDTm, LOW_VALUES, sizeof(RS.sDTm));
   memset(&RS.sATm, LOW_VALUES, sizeof(RS.sATm));

   strcpy(PprNbr, RS.sPprNbr);
   strcpy(NrevNbr, RS.sNrevNbr);
   strcpy(FltNbr, RS.sFltNbr);
   strcpy(FltOrigCtyId, RS.sFltOrigCtyId);
   strcpy(FltDestCtyId, RS.sFltDestCtyId);
   strcpy(DprtDt, RS.sDprtDt);

   strncpy(RS.sPprNbr, (char *)RS.EPBF010_buffer+3,9);
   strncpy(RS.sNrevNbr, (char *)RS.EPBF010_buffer+12,2);
   strncpy(RS.sFltNbr, (char *)RS.EPBF010_buffer+15,4);
   strncpy(RS.sFltOrigCtyId, (char *)RS.EPBF010_buffer+35,5);
   strncpy(RS.sFltDestCtyId, (char *)RS.EPBF010_buffer+40,5);
   strncpy(RS.sDprtDt, (char *)RS.EPBF010_buffer+19,8);
   strncpy(RS.sArrDt,(char *)RS.EPBF010_buffer+27,8);
   strncpy(RS.sBrdPri,(char *)RS.EPBF010_buffer+55,4);
   strncpy(RS.sClsSvc, (char *)RS.EPBF010_buffer+53,2);
   strncpy(RS.sATm, (char *)RS.EPBF010_buffer+49,4);
   strncpy(RS.sDTm, (char *)RS.EPBF010_buffer+45,4);

   // Remove trailing spaces from string variables
   UTL_StripTrailingSpaces(RS.sPprNbr);
   UTL_StripTrailingSpaces(RS.sNrevNbr);
   UTL_StripTrailingSpaces(RS.sFltNbr);
   UTL_StripTrailingSpaces(RS.sFltOrigCtyId);
   UTL_StripTrailingSpaces(RS.sFltDestCtyId);
   UTL_StripTrailingSpaces(RS.sDprtDt);
   UTL_StripTrailingSpaces(RS.sArrDt);
   UTL_StripTrailingSpaces(RS.sBrdPri);
   UTL_StripTrailingSpaces(RS.sClsSvc);
   UTL_StripTrailingSpaces(RS.sATm);
   UTL_StripTrailingSpaces(RS.sDTm);

   // Now convert the dates to standard formats
   pTemp = UTL_ConvertDate(RS.sDprtDt, CNV_YYYYMMDD_TO_DB);
   strncpy(RS.sDprtDt, pTemp, sizeof(RS.sDprtDt));
   pTemp = UTL_ConvertDate(RS.sArrDt,  CNV_YYYYMMDD_TO_DB);   
   strncpy(RS.sArrDt, pTemp, sizeof(RS.sArrDt));

   /*** Dont process record if ppr number is all zero's.  ***/
   if (strcmp(RS.sPprNbr,"000000000") == 0)
      cProcSw = 'N';
   else
   {
      /*** Dont process record if orig or destination is one of the  test cities.   ***/
      for (i=0; i<25; i++)
      {
         if (strncmp(pTestCityStruct[i], RS.sFltOrigCtyId, 3) == 0  ||
             strncmp(pTestCityStruct[i], RS.sFltDestCtyId, 3) == 0)
         {
            cProcSw = 'N';
            break;
         }  /*** end if ***/
      }  /*** end for ***/
   }   /*** end else ***/

   /*** Dont process record if nrev nbr > 59, representing a family and friends leg ***/
   /*** 3/15/05 ejs comment out this code to allow buddy pass flt legs to process   ***/

  /**  if (strcmp(RS.sNrevNbr,"59") > 0)
      cProcSw = 'N';                       **/
      
if (cProcSw == 'Y')
   {
    /*** Get pass group code, imputed indicator, and nrev type code from ppr and nrev table  ***/
    strcpy(R03962.R03962_appl_area.sPprNbr, RS.sPprNbr);
    strcpy(R03962.R03962_appl_area.sNrevNbr, RS.sNrevNbr);
    memset(&A03962,LOW_VALUES,sizeof(A03962));
    nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03962,&A03962,SERVICE_ID_03962,1,sizeof(R03962.R03962_appl_area));
    
    switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
     /**  3/15/05 ejs check if buddy pass then write flt leg record to bdy_nrev_pax_fl table  **/
           if (strcmp(RS.sNrevNbr,"59") > 0)
	      servid = '3';
	   else
           if (A03962.A03962_appl_area.cPassImptInd == 'Y') 
            servid = '1';
           else
            servid = '2';
           break;

         case ARC_ROW_NOT_FOUND:
            strcpy(sErrMsg, "Invalid Ppr/Nrev Number ");
            servid = '0';
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03962");
            sprintf(sErrorMessage, "Ppr = %s, Nrev = %s",
                          R03962.R03962_appl_area.sPprNbr,
                          R03962.R03962_appl_area.sNrevNbr);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");

            break;
         } /* end switch */

    /*** If ppr/nrev successfully found, go get the airport pair type ***/
    if (servid != '0')
      {
       TPM_4000_Get_ArptPrTyp(); 
      }

     /*** if ppr/nrev/airport pair information found, get the boarding priority and airport information ***/
     if (servid != '0')
       {
         /*** Get the Max and Min pass type for the passed boarding priority ***/
         cBrdPriFound = 'Y';
         TPM_4025_Get_BrdPriority();

         /*** if brd priority is not valid, check to see if priority used was lower than the lowest ***/
         /*** priority, and if so, use the pass type with the lowest priority                  ***/
         if (cBrdPriFound  == 'N')
            {
               TPM_4075_Get_Lowest_Priority();

               if (cLowestPriFound == 'Y')
                  {
                  /*** if the lowest priority was found, process max and min pass type for this priority ***/
                  TPM_4025_Get_BrdPriority();
                  /*** if a max or min priority wasnt found for the lowest priority - error ***/
                  if (cBrdPriFound  == 'N')
                     {
                     servid = '0';
                     strcpy(sErrMsg, "Invalid Boarding Priority");
                     } /* end if cBrdPriFound == N  */
                  } /* end if cLowestPriFound == 'Y' */
               else
                  {
                  servid = '0';
                  strcpy(sErrMsg, "Invalid Boarding Priority");
                  }
            } /* end of if cBrdPriFound = 'N' ***/

      } /** endif for servid != 0   */

     /*** Next Determine if item should go to Imputed or non-imputed flight leg table and process accordingly ***/
     switch (servid)
         {
         /****** Imputed Flight Leg Process    ******/
         case '1':  
           memset(&R02496, LOW_VALUES, sizeof(_R02496));
           memset(&A02496, LOW_VALUES, sizeof(_A02496));
           strcpy(R02496.R02496_appl_area.sPprNbr, RS.sPprNbr);
           strcpy(R02496.R02496_appl_area.sNrevNbr, RS.sNrevNbr);
           strcpy(R02496.R02496_appl_area.sFltNbr, RS.sFltNbr);
           strcpy(R02496.R02496_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId);
           strcpy(R02496.R02496_appl_area.sFltDestCtyId, RS.sFltDestCtyId);
           strcpy(R02496.R02496_appl_area.sFltDprtDt,RS.sDprtDt);
           strcpy(R02496.R02496_appl_area.sFltArrDt,RS.sArrDt);
           R02496.R02496_appl_area.nFltDprtTm = atoi(RS.sDTm);
           R02496.R02496_appl_area.nFltArrTm = atoi(RS.sATm);

           /*** if a senior officer or board member, set the process date to today so no service charges or ***/
           /*** international fees will be processed against these legs.                                    ***/
           if (strcmp(A03962.A03962_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) == 0 ||
               strcmp(A03962.A03962_appl_area.sPassGrpCd, SENIOR_OFFICERS_MRD) == 0 || 
               strcmp(A03962.A03962_appl_area.sPassGrpCd, SENIOR_OFFICERS) == 0 || 
               strcmp(A03962.A03962_appl_area.sPassGrpCd, BOARD_MEMBERS) == 0) 
                 strcpy(R02496.R02496_appl_area.sProcDt,sCurrentTsDt);
          else   
                 strcpy(R02496.R02496_appl_area.sProcDt, LOW_DATE);

          strcpy(R02496.R02496_appl_area.sPassTypCd, sPassTypCd);   
          strcpy(R02496.R02496_appl_area.sFltClsSvcId,RS.sClsSvc);
          strcpy(R02496.R02496_appl_area.sFltArptPrTypCd,A02792.A02792_appl_area.sFltArptPrTypCd);
          strcpy(R02496.R02496_appl_area.sTktNbr,"9999999999");
          R02496.R02496_appl_area.cFltMatchInd = 'U';
          R02496.R02496_appl_area.lPassTripNbr = 0;
          R02496.R02496_appl_area.cFltLegSrcInd = 'I';
          R02496.R02496_appl_area.cFltRptInd = 'N';
          strcpy(R02496.R02496_appl_area.sFltOalFlnInd,"DL");
	  strcpy(R02496.R02496_appl_area.sOthrEmptCd,A03962.A03962_appl_area.sOthrEmptCd);
	  strcpy(R02496.R02496_appl_area.sSbPriCd,RS.sBrdPri);
	  strcpy(R02496.R02496_appl_area.sNwTktDocNb,"999999999999999");

          /*** If this record has the sam pprnbr, nrevnbr, flt nbt and orig city as the previous record ***/
          /*** then this is a double dated flight, and should have the same flight charge ref date.     ***/
          if ((strcmp(PprNbr, RS.sPprNbr)==0) && (strcmp(NrevNbr, RS.sNrevNbr)==0) &&
              (strcmp(FltNbr, RS.sFltNbr)==0) && (strcmp(FltDestCtyId, RS.sFltOrigCtyId)==0)) 
            {
                R02496.R02496_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(DprtDt);
            }
          else
            {
              R02496.R02496_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(RS.sDprtDt);
            }
 
            /******Write to imput_flt_leg ****/
            nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02496,&A02496,SERVICE_ID_02496,1,sizeof(R02496.R02496_appl_area)); 
            switch (nSvcRtnCd) 
            { 
            case ARC_SUCCESS: 
              RS.Imptfltleg++;
              break;
 
            case ARC_DUPLICATE_ROW: 
	    
              BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
              BCH_FormatMessage(2,TXT_SVC, "FYS02496"); 
              sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s", 
                          R02496.R02496_appl_area.sPprNbr,  
                          R02496.R02496_appl_area.sNrevNbr,
                          R02496.R02496_appl_area.sFltOrigCtyId,
                          R02496.R02496_appl_area.sFltNbr,
                          R02496.R02496_appl_area.sFltDprtDt);
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage); 
              BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_3000_ProcessFileEPBF010");
              break; 
            default:
              BCH_FormatMessage(1,TXT_SVC_UNSUCC); 
              BCH_FormatMessage(2,TXT_SVC, "FYS02496");
              sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s", 
                          R02496.R02496_appl_area.sPprNbr,   
                          R02496.R02496_appl_area.sNrevNbr, 
                          R02496.R02496_appl_area.sFltOrigCtyId, 
                          R02496.R02496_appl_area.sFltNbr, 
                          R02496.R02496_appl_area.sFltDprtDt); 
              BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage); 
              BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
              break;
            } /* end switch(nSvcRtnCd)*/
         break; /*** end of imputed flight leg process case 1***/

         /******** (non-imputed) Flight Leg Process    *******/
         case '2':
           memset(&R02511, LOW_VALUES, sizeof(_R02511));
           memset(&A02511, LOW_VALUES, sizeof(_A02511));

           strcpy(R02511.R02511_appl_area.sPprNbr, RS.sPprNbr);
           strcpy(R02511.R02511_appl_area.sNrevNbr, RS.sNrevNbr);
           strcpy(R02511.R02511_appl_area.sFltNbr, RS.sFltNbr);
           strcpy(R02511.R02511_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId);
           strcpy(R02511.R02511_appl_area.sFltDestCtyId, RS.sFltDestCtyId);
           strcpy(R02511.R02511_appl_area.sFltDprtDt,RS.sDprtDt);
           strcpy(R02511.R02511_appl_area.sFltArrDt,RS.sArrDt);
           R02511.R02511_appl_area.nFltDprtTm = atoi(RS.sDTm);
           R02511.R02511_appl_area.nFltArrTm = atoi(RS.sATm);
           strcpy(R02511.R02511_appl_area.sProcDt, LOW_DATE);
           strcpy(R02511.R02511_appl_area.sPassTypCd, sPassTypCd);
           strcpy(R02511.R02511_appl_area.sFltClsSvcId,RS.sClsSvc);
           strcpy(R02511.R02511_appl_area.sFltArptPrTypCd,A02792.A02792_appl_area.sFltArptPrTypCd);
	   strcpy(R02511.R02511_appl_area.sOthrEmptCd,A03962.A03962_appl_area.sOthrEmptCd);
	   strcpy(R02511.R02511_appl_area.sSbPriCd,RS.sBrdPri);
	   strcpy(R02511.R02511_appl_area.sNwTktDocNb,"999999999999999");


          /*** If this record has the sam pprnbr, nrevnbr, flt nbt and orig city as the previous record ***/
          /*** then this is a double dated flight, and should have the same flight charge ref date.     ***/
          if ((strcmp(PprNbr, RS.sPprNbr)==0) && (strcmp(NrevNbr, RS.sNrevNbr)==0) &&
              (strcmp(FltNbr, RS.sFltNbr)==0) && (strcmp(FltDestCtyId, RS.sFltOrigCtyId)==0)) 
            {
               R02511.R02511_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(DprtDt);
            }
          else
            {
              R02511.R02511_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(RS.sDprtDt);
            }
 
          /*******Write to flt_leg  ****/
          nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02511,&A02511,SERVICE_ID_02511,1,sizeof(R02511.R02511_appl_area));
          switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
           RS.Fltleg++;
           break;

         case ARC_DUPLICATE_ROW:
            BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
            BCH_FormatMessage(2,TXT_SVC, "FYS02511");
            sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s", 
                          R02511.R02511_appl_area.sPprNbr, 
                          R02511.R02511_appl_area.sNrevNbr,
                          R02511.R02511_appl_area.sFltOrigCtyId,
                          R02511.R02511_appl_area.sFltNbr,
                          R02511.R02511_appl_area.sFltDprtDt);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_3000_ProcessFileEPBF010");
            break;
         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02511");
            sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s", 
                          R02511.R02511_appl_area.sPprNbr,  
                          R02511.R02511_appl_area.sNrevNbr,
                          R02511.R02511_appl_area.sFltOrigCtyId,
                          R02511.R02511_appl_area.sFltNbr,
                          R02511.R02511_appl_area.sFltDprtDt);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF010");
            break;
         } /* end switch (nSvcRtnCd) */

         break;  /*** end of case 2 ***/

         /******** Buddy Flight Leg Process    *******/
	 case '3':

         memset(&R04714, LOW_VALUES, sizeof(_R04714));
	 memset(&A04714, LOW_VALUES, sizeof(_A04714));
         strcpy(R04714.R04714_appl_area.sPprNbr, RS.sPprNbr);
         strcpy(R04714.R04714_appl_area.sNrevNbr, RS.sNrevNbr);
	 strcpy(R04714.R04714_appl_area.sCertftIssDt, A03962.A03962_appl_area.sNrevBdayDt);
         strcpy(R04714.R04714_appl_area.sFltNbr, RS.sFltNbr);
         strcpy(R04714.R04714_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId);
	 strcpy(R04714.R04714_appl_area.sFltDestCtyId, RS.sFltDestCtyId);
	 strcpy(R04714.R04714_appl_area.sFltDprtDt,RS.sDprtDt);
	 strcpy(R04714.R04714_appl_area.sFltArrDt,RS.sArrDt);
	 R04714.R04714_appl_area.nFltDprtTm = atoi(RS.sDTm);
	 R04714.R04714_appl_area.nFltArrTm = atoi(RS.sATm);
	 strcpy(R04714.R04714_appl_area.sProcDt, LOW_DATE);
	 strcpy(R04714.R04714_appl_area.sPassTypCd, sPassTypCd);
         strcpy(R04714.R04714_appl_area.sFltClsSvcId,RS.sClsSvc);
	 strcpy(R04714.R04714_appl_area.sFltArptPrTypCd,A02792.A02792_appl_area.sFltArptPrTypCd);
	 strcpy(R04714.R04714_appl_area.sSbPriCd,RS.sBrdPri);
	 strcpy(R04714.R04714_appl_area.sOthrEmptCd,A03962.A03962_appl_area.sOthrEmptCd);
	 strcpy(R04714.R04714_appl_area.sNwTktDocNb,"999999999999999"); 

        /*** If this record has the sam pprnbr, nrevnbr, flt nbt and orig city as the previous record then this is a double dated flight, and should have the same flight charge ref date.     ***/
	 if ((strcmp(PprNbr, RS.sPprNbr)==0) && (strcmp(NrevNbr, RS.sNrevNbr)==0) &&
             (strcmp(FltNbr, RS.sFltNbr)==0) && (strcmp(FltDestCtyId, RS.sFltOrigCtyId)==0))
           {
	     R04714.R04714_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(DprtDt);
	   }
	  else
	   {
	   R04714.R04714_appl_area.lFltChrgRfrnDt = UTL_GetJulianFromDate(RS.sDprtDt);
	   }

	 /*******Write to buddy_flt_leg  ****/
	  nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04714,&A04714,SERVICE_ID_04714,1,sizeof(R04714.R04714_appl_area));
	  switch (nSvcRtnCd)
	  {
         case ARC_SUCCESS:
	   RS.BuddyFltleg++;
	   break;
	 case ARC_DUPLICATE_ROW: BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
	 BCH_FormatMessage(2,TXT_SVC, "FYS04714");
	 sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
	     R04714.R04714_appl_area.sPprNbr,
	     R04714.R04714_appl_area.sNrevNbr,
	     R04714.R04714_appl_area.sFltOrigCtyId,
	     R04714.R04714_appl_area.sFltNbr,
	     R04714.R04714_appl_area.sFltDprtDt);
	     BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	     BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_3000_ProcessFileEP BF010");
	     break;
	 default:
	     BCH_FormatMessage(1,TXT_SVC_UNSUCC);
	     BCH_FormatMessage(2,TXT_SVC, "FYS04714");
	     sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s",
	          R04714.R04714_appl_area.sPprNbr,
		  R04714.R04714_appl_area.sNrevNbr,
		  R04714.R04714_appl_area.sFltOrigCtyId,
		  R04714.R04714_appl_area.sFltNbr,
		  R04714.R04714_appl_area.sFltDprtDt);
	     BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
	     BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF 010");
	 break;
      } /* end switch (nSvcRtnCd) */

      break;  /*** end of case 3 ***/

      /***  servid is not 1, 2 or 3, so some error occurred - write to suspense table   ***/
         default:  
            TPM_3100_Insert_Suspense();
            break;
         } /***end switch for servid ***/

    }   /*** end if cProcSw == 'Y'   ***/
    else
     /*** This record was not processed  -  add to count of records dropped ***/
     RS.Dropped++;
  
   /*** Read next interface record ***/
   BCH_ReadRec(RS.EPBF010, RS.EPBF010_buffer,sizeof(RS.EPBF010_buffer)); 
   TPM_8000_ProcessLUW();
}


/******************************************************************
**                                                               **
** Function Name:   TPM_3100_Insert_Suspense                     **
**                                                               **
** Description:     function to insert a row into the Suspense   **
**                  table because some error occurred.           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_3100_Insert_Suspense()
{


   memset(&R04395, LOW_VALUES, sizeof(_R04395));
   memset(&A04395, LOW_VALUES, sizeof(_A04395));

   strcpy(R04395.R04395_appl_area.sPprNbr, RS.sPprNbr);
   strcpy(R04395.R04395_appl_area.sNrevNbr, RS.sNrevNbr);
   strcpy(R04395.R04395_appl_area.sFltNbr, RS.sFltNbr);
   strcpy(R04395.R04395_appl_area.sFltOrigCtyId, RS.sFltOrigCtyId);
   strcpy(R04395.R04395_appl_area.sFltDestCtyId, RS.sFltDestCtyId);
   strcpy(R04395.R04395_appl_area.sFltDprtDt,RS.sDprtDt);
   strcpy(R04395.R04395_appl_area.sFltArrDt,RS.sArrDt);
   R04395.R04395_appl_area.nFltDprtTm = atoi(RS.sDTm);
   R04395.R04395_appl_area.nFltArrTm = atoi(RS.sATm);
   strcpy(R04395.R04395_appl_area.sFltClsSvcId,RS.sClsSvc);
   strcpy(R04395.R04395_appl_area.sPassBrdPriId,RS.sBrdPri);
   strcpy(R04395.R04395_appl_area.sAudtChgTypNm,sErrMsg);
 
   /*******Write to T_suspense ***/
   nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04395,&A04395,SERVICE_ID_04395,1,sizeof(R04395.R04395_appl_area));
   switch (nSvcRtnCd)
   {
     case ARC_SUCCESS:
        RS.Error++;
        break;
     case ARC_DUPLICATE_ROW:
        BCH_FormatMessage(1,TXT_DUPLICATE_ROW);
        BCH_FormatMessage(2,TXT_SVC, "FYS04395");
        sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s", 
                 R04395.R04395_appl_area.sPprNbr, 
                 R04395.R04395_appl_area.sNrevNbr,
                 R04395.R04395_appl_area.sFltOrigCtyId,
                 R04395.R04395_appl_area.sFltNbr,
                 R04395.R04395_appl_area.sFltDprtDt);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_3100_Insert_Suspense");
        break;
     default:
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS04395");
        sprintf(sErrorMessage, "Ppr = %s, Nrev = %s, Orig = %s, FltNbr = %s, DprtDt = %s", 
                          R04395.R04395_appl_area.sPprNbr,  
                          R04395.R04395_appl_area.sNrevNbr,
                          R04395.R04395_appl_area.sFltOrigCtyId,
                          R04395.R04395_appl_area.sFltNbr,
                          R04395.R04395_appl_area.sFltDprtDt);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_3100_Insert_Suspense");
        break;
   }
}

/******************************************************************
**                                                               **
** Function Name:   TPM_4000_Get_ArptPrTyp                       **
**                                                               **
** Description:     function to get airport pair type from       **
**                  arpt_pr_mi table.                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_4000_Get_ArptPrTyp()
{


  /*** get the airport pair type from the airport pair mileage table ***/
  strcpy(R02792.R02792_appl_area.sFltOrigCtyId,RS.sFltOrigCtyId);
  strcpy(R02792.R02792_appl_area.sFltDestCtyId,RS.sFltDestCtyId);
  memset(&A02792,LOW_VALUES,sizeof(A02792));
  nSvcRtnCd1 = BCH_InvokeService(EPBINQ0,&R02792,&A02792,SERVICE_ID_02792,1,sizeof(R02792.R02792_appl_area));
   switch (nSvcRtnCd1)
         {
         case ARC_SUCCESS:
           break; 

           case ARC_ROW_NOT_FOUND:
            strcpy(sErrMsg, "Invalid orig/dest");
            servid = '0';
            break;

         default:  
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02792");
            sprintf(sErrorMessage, "PprNbr = %s, NrevNbr = %s, Orig = %s, Dest = %s",
                          RS.sPprNbr,
                          RS.sNrevNbr,
                          R02792.R02792_appl_area.sFltOrigCtyId,
                          R02792.R02792_appl_area.sFltDestCtyId);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4000_Get_ArptPrTyp");
 
            break;
         } /* end switch */
}


/******************************************************************
**                                                               **
** Function Name:   TPM_4025_Get_BrdPriority                     **
**                                                               **
** Description:     function to get the pass type code from      **
**                  The boarding priority table.                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_4025_Get_BrdPriority()
{

if (((strcmp(A03962.A03962_appl_area.sPassGrpCd, "CB") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "CC") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "CW") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GC") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GK") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GM") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GR") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GS") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GT") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GZ") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "VR") != 0) &&
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "WN") != 0)) &&
     (strcmp(RS.sBrdPri, "S3CR") == 0))
      strcpy(RS.sBrdPri, "S3B");

if (((strcmp(A03962.A03962_appl_area.sPassGrpCd, "GC") == 0) ||
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GK") == 0) ||
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GM") == 0) ||
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GR") == 0) ||
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GS") == 0) ||
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GT") == 0) ||
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "VR") == 0) ||
     (strcmp(A03962.A03962_appl_area.sPassGrpCd, "WN") == 0)) &&
     (strcmp(RS.sBrdPri, "S3CR") == 0))
      strcpy(RS.sBrdPri, "S3C");

if ((strcmp(A03962.A03962_appl_area.sPassGrpCd, "CC") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "CR") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GA") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GC") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GK") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GM") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GR") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GS") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "GT") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "VR") != 0) &&
    (strcmp(A03962.A03962_appl_area.sPassGrpCd, "WN") != 0) &&
    (strcmp(RS.sBrdPri, "S3C") == 0))
   strcpy(RS.sBrdPri, "S3");

if ((strcmp(A03962.A03962_appl_area.sPassGrpCd, "NW") == 0) &&
     (strcmp(RS.sBrdPri, "S3NW") == 0))
    strcpy(RS.sBrdPri, "S3");

if ((strcmp(A03962.A03962_appl_area.sPassGrpCd, "NW") == 0) &&
     (strcmp(RS.sBrdPri, "S3NR") == 0))
    strcpy(RS.sBrdPri, "S3B");

if (strcmp(RS.sBrdPri, "S3B1") == 0)
    strcpy(RS.sBrdPri, "S3");

if ((strcmp(A03962.A03962_appl_area.sPassGrpCd, "GZ") != 0) &&
   (strcmp(RS.sBrdPri, "S3D") == 0))
    strcpy(RS.sBrdPri, "S3CR");



        /*** first, get max and min pass type code from boarding priority table   ***/
        strcpy(R03952.R03952_appl_area.sPassGrpCd,A03962.A03962_appl_area.sPassGrpCd);
        strcpy(R03952.R03952_appl_area.sNrevTypCd,A03962.A03962_appl_area.sNrevTypCd); 
        strcpy(R03952.R03952_appl_area.sPassBrdPriId,RS.sBrdPri);
        memset(&A03952,LOW_VALUES,sizeof(A03952));
        nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03952,&A03952,SERVICE_ID_03952,1,sizeof(R03952.R03952_appl_area));
        switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
           if (A03952.A03952_appl_area.sPassTypCd[0] == ' ')
              cBrdPriFound = 'N';
           else
             {
             /*** save the max pass type code from the brd priority table ***/
             strcpy(sPassTypCd,A03952.A03952_appl_area.sPassTypCd); 
             strcpy(sMaxPassTypCd,A03952.A03952_appl_area.sPassTypCd); 
             strcpy(sMinPassTypCd,A03952.A03952_appl_area.sPassStsCd); 
             cBrdPriFound = 'Y';

             /*** if the max and min pass types are not the same, go to airport pr type table ***/
             /*** to make final determination of pass type to use                             ***/
             if ( strcmp(sMaxPassTypCd, sMinPassTypCd) != 0)
               {
               TPM_4050_Get_PassTypCd(); 
               }
             } 
             break; 

         case ARC_ROW_NOT_FOUND: 
            cBrdPriFound = 'N';
            break; 
 
         default: 
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03952");
            sprintf(sErrorMessage, "PprNbr = %s, NrevNbr = %s, Grp = %s, NrevTyp = %s, Pri = %s",
                          RS.sPprNbr,
                          RS.sNrevNbr,
                          R03952.R03952_appl_area.sPassGrpCd,
                          R03952.R03952_appl_area.sNrevTypCd,
                          R03952.R03952_appl_area.sPassBrdPriId);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4025_Get_BrdPriority"); 
 
            break;
         } /* end switch */


}

/******************************************************************
**                                                               **
** Function Name:   TPM_4050_Get_PassTypCd                       **
**                                                               **
** Description:     Call function to get PassTypCd from          **
**                  arpt_pr_typ table.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void TPM_4050_Get_PassTypCd()
{


   strcpy(R02797.R02797_appl_area.sFltArptPrTypCd,A02792.A02792_appl_area.sFltArptPrTypCd);
   nSvcRtnCd2 = BCH_InvokeService(EPBINQ0,&R02797,&A02797,SERVICE_ID_02797,1,sizeof(R02797.R02797_appl_area));
   switch (nSvcRtnCd2)
         {
         case ARC_SUCCESS:
           /*** if the pass type code from the airport pair type table is the max or min pass type ***/
           /*** from the boarding priority table, use the pass type from the airport pair type table ***/
           /*** if this is the parent of a single assoc w/o kids on a transoceanic flight leg using ***/
           /*** S3 boarding priority, use the pass type from the airport pair typ table.  This is    ***/
           /*** necessary because this group has S3's for 3 different pass types.                    ***/
           /*** otherwise, use the max pass type from the brd priority table                         ***/
           if ((! strcmp(A02797.A02797_appl_area.sPassTypCd, sMaxPassTypCd)) ||
               (! strcmp(A02797.A02797_appl_area.sPassTypCd, sMinPassTypCd))) 
           strcpy(sPassTypCd, A02797.A02797_appl_area.sPassTypCd);
	   if (strcmp(RS.sBrdPri, "S1  ") == 0)
              strcpy(sPassTypCd, sMinPassTypCd);
           if (strcmp(A03962.A03962_appl_area.sPassGrpCd, TEMPDL_SINGLE) == 0      &&
               strcmp(A03962.A03962_appl_area.sNrevTypCd, PARENT) == 0      &&
               strcmp(RS.sBrdPri, "S3  ") == 0                                &&
               (strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, TRANSATLANTIC) == 0   ||
                strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, TRANSPACIFIC) == 0))
                  strcpy(sPassTypCd, A02797.A02797_appl_area.sPassTypCd);
           break;

         case ARC_ROW_NOT_FOUND:
            strcpy(sErrMsg, "Invalid airport pair type");
            servid = '0';
            break;
 
         default:  
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02797");
            sprintf(sErrorMessage, "PprNbr = %s, NrevNbr = %s, Orig = %s, Dest = %s, ArptPrTyp = %s",
                          RS.sPprNbr,
                          RS.sNrevNbr,
                          R02792.R02792_appl_area.sFltOrigCtyId,
                          R02792.R02792_appl_area.sFltDestCtyId,
                          R02797.R02797_appl_area.sFltArptPrTypCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4050_Get_PassTypCd");
 
            break;
         } /* end switch */

}

/******************************************************************
**                                                               **
** Function Name:   TPM_4075_Get_Lowest_Priority                 **
**                                                               **
** Description:     Call function to get the lowest possible     **
**                  boarding priority from t_brd_priority.       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void TPM_4075_Get_Lowest_Priority()
{


        memset(&A04400,LOW_VALUES,sizeof(A04400));
        memset(&R04400,LOW_VALUES,sizeof(R04400));
        strcpy(R04400.R04400_appl_area.sPassGrpCd,A03962.A03962_appl_area.sPassGrpCd);
        strcpy(R04400.R04400_appl_area.sNrevTypCd,A03962.A03962_appl_area.sNrevTypCd); 
        nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04400,&A04400,SERVICE_ID_04400,1,sizeof(R04400.R04400_appl_area));
        switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
           if (A04400.A04400_appl_area.sPassBrdPriId[0] == ' ')
              cLowestPriFound = 'N';
           else
           {
             /*** if boarding priority used is > lowest boarding priority, use pass type for lowest ***/
             if (strcmp(RS.sBrdPri, A04400.A04400_appl_area.sPassBrdPriId) > 0)
             {
              cLowestPriFound = 'Y';
              strcpy(RS.sBrdPri, A04400.A04400_appl_area.sPassBrdPriId);
             }
             else 
               cLowestPriFound = 'N';
           }
             break; 

         case ARC_ROW_NOT_FOUND:
             cLowestPriFound = 'N';
             break;
 
         default: 
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04400");
            sprintf(sErrorMessage, "PprNbr = %s, NrevNbr = %s, Grp = %s, NrevTyp = %s",
                          RS.sPprNbr,
                          RS.sNrevNbr,
                          R04400.R04400_appl_area.sPassGrpCd,
                          R04400.R04400_appl_area.sNrevTypCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_4075_Get_Lowest_Priority"); 
 
            break;
         } /* end switch */
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8000_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

int  TPM_8000_ProcessLUW()
{
}


/******************************************************************
**                                                               **
** Function Name:   TPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    TPM_9500_ProcessEndOfProgram()
{

            sprintf(sErrorMessage, "Read = %6d, Errors Written = %5d, Dropped = %5d",
                          RS.Read,
                          RS.Error,
                          RS.Dropped);
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
            sprintf(sErrorMessage, "Flt_Leg = %6d, Impt_Flt_Leg = %6d, Bud_leg = %6d",
                          RS.Fltleg,
                          RS.Imptfltleg,
			  RS.BuddyFltleg);
            BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "TPM_9500_ProcessEndOfProgram");

   BCH_Close(RS.EPBF010);


} 
