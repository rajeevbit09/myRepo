/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB83001.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  kenneth hancock                                        **
**                                                                         **
** Date Written:                                                           **
**                                                                         **
** Description:     This module extracts information from the Employee     **
**                  A/R table and builds a file containig all new and      **
**                  changed information for PPR's who are manually added   **
**                                                                         **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **  
** 07/26/96     FFA                       Added processing counts          **
**                                                                         **
** 08/08/96     FFA                       Change records should always have**
**                                        a status of 'R' and a term date  **
**                                        of 12/31/90.  Add records will   **
**                                        have a status of 'A' and a term  **
**                                        date of 0.                       **
** 08/16/99     CDM                       Convert
**                                                                         **
** 02/25/13     BBE                       Modified how phone number is     **
**                                        handled.                         **
****************************************************************************/
#include "epb83001.h"

main()
{
   BCH_Init("EPB83001", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void DPM_1000_Initialize()
{

   /**** Set key to primary database to nulls/zero ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sPassDtTmTs, SPACE_CHAR);
   
   /**** Initialize counters & accumulators ****/
   RS.nRecsRead = 0;
   RS.nRecsWrit = 0;
   RS.nChngCnt = 0;
   RS.nAddCnt = 0;
   
   /**** Log program start message ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   /**** open  output file ****/
   RS.EPBF010 = BCH_Open("EPBF010",BCH_FILE_WRITE);

   if (RS.EPBF010 == BCH_FAIL)
   {
      BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
      BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF020");
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{

   /**** First, process  all items from the empl ar table that have not been processed ****/
   /**** these items have a proc date of 12/31/1899                                    ****/
   
   /**** Initialize service blocks ****/
   memset(&R02824.R02824_appl_area,LOW_VALUES, sizeof(_R02824_APPL_AREA));
   memset(&A02824.A02824_appl_area,LOW_VALUES, sizeof(_A02824_APPL_AREA));
   strcpy(R02824.R02824_appl_area.sPprNbr,RS.sPprNbr);
   strcpy(R02824.R02824_appl_area.sPassDtTmTs,RS.sPassDtTmTs);
   R02824.R02824_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /**** Execute service to select all manual PPRs from t_empl_ar table  ***/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02824,&A02824,SERVICE_ID_02824,1,sizeof(_R02824_APPL_AREA));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         RS.nRecsRead++;
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02824");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
 
   } /* end switch */ 

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      strcpy(RS.sPprNbr, R02824.R02824_appl_area.sPprNbr);
      strcpy(RS.sPassDtTmTs, R02824.R02824_appl_area.sPassDtTmTs);

      /*** move data to interface record    ***/
      memset(&ALL, ' ', sizeof(ALL));
      ALL.cEmplArRecInd = A02824.A02824_appl_area.cEmplArRecInd;
      strncpy(ALL.sPprNbr,A02824.A02824_appl_area.sPprNbr,strlen(A02824.A02824_appl_area.sPprNbr));
      strncpy(ALL.sPprNm,A02824.A02824_appl_area.sPprNm,strlen(A02824.A02824_appl_area.sPprNm));
      strncpy(ALL.sPpr1Addr,A02824.A02824_appl_area.sPpr1Addr,strlen(A02824.A02824_appl_area.sPpr1Addr));
      strncpy(ALL.sPpr2Addr,A02824.A02824_appl_area.sPpr2Addr,strlen(A02824.A02824_appl_area.sPpr2Addr));
      strncpy(ALL.sPprCtyAddr,A02824.A02824_appl_area.sPprCtyAddr,strlen(A02824.A02824_appl_area.sPprCtyAddr));
      strncpy(ALL.sPprStCd,A02824.A02824_appl_area.sPprStCd,strlen(A02824.A02824_appl_area.sPprStCd));
      strncpy(ALL.sPprZipAddr,A02824.A02824_appl_area.sPprZipAddr,strlen(A02824.A02824_appl_area.sPprZipAddr));
      strncpy(ALL.sPprCtryCd,A02824.A02824_appl_area.sPprCtryCd,strlen(A02824.A02824_appl_area.sPprCtryCd));
      if (A02824.A02824_appl_area.sPprPhNbr[0] != LOW_VALUES)
      {  /*  FOR masking phone number properly 0NNNNNNN   */
         if (strlen(A02824.A02824_appl_area.sPprPhNbr) == 12) 
	 { 
	      ALL.sPprPhNbr[0] = '0';
	      strncpy(ALL.sPprPhNbr+1,A02824.A02824_appl_area.sPprPhNbr, 3);
              strncpy(ALL.sPprPhNbr+4,A02824.A02824_appl_area.sPprPhNbr+4, 3);
              strncpy(ALL.sPprPhNbr+7,A02824.A02824_appl_area.sPprPhNbr+8, 4);
	 }
	 else 
	 {
	      ALL.sPprPhNbr[0] = '0';
	      strncpy(ALL.sPprPhNbr+1,A02824.A02824_appl_area.sPprPhNbr, 3);
	      strncpy(ALL.sPprPhNbr+4,A02824.A02824_appl_area.sPprPhNbr+3, 3);
	      strncpy(ALL.sPprPhNbr+7,A02824.A02824_appl_area.sPprPhNbr+6, 4);
         }
      } /* endif for phone  */

      if (strcmp(A02824.A02824_appl_area.sPprPhNbr, NULL_STRING) == 0 || 
	  strcmp(A02824.A02824_appl_area.sPprPhNbr, " ") == 0)
      /******if (A02824.A02824_appl_area.sPprPhNbr[0] == LOW_VALUES)*****/
      { 
	 strncpy(ALL.sPprPhNbr, "09999999999", 11);
      }


      strncpy(ALL.sEmplArActnCd,A02824.A02824_appl_area.sEmplArActnCd,strlen(A02824.A02824_appl_area.sEmplArActnCd));
      strncpy(ALL.sPprSocSecNbr,A02824.A02824_appl_area.sPprSocSecNbr,strlen(A02824.A02824_appl_area.sPprSocSecNbr));
     
	  /**** Write date in mmddyy format ****/
      strncpy(ALL.sPprStrtDt,A02824.A02824_appl_area.sPprStrtDt+5,2);
      strncpy(ALL.sPprStrtDt+2,A02824.A02824_appl_area.sPprStrtDt+8,2);
      strncpy(ALL.sPprStrtDt+4,A02824.A02824_appl_area.sPprStrtDt+2,2);

      /*** Since the window does not populate these fields properly, initialize the status and term ***/
      /*** date as it should be depending on if its an add or a change record                       ***/
      if ( A02824.A02824_appl_area.cEmplArRecInd == 'A')
      {
         ALL.cEmplArStsInd = 'A';   /*** add the ppr as active ***/
         strncpy(ALL.sEmplArTermDt,"000000",6);
      }
      else
      {
         ALL.cEmplArStsInd = 'R';  /*** change the PPR to retired ***/
         strncpy(ALL.sEmplArTermDt,sCurrentDispDt,2);
         strncpy(ALL.sEmplArTermDt+2,sCurrentDispDt+3,2);
         strncpy(ALL.sEmplArTermDt+4,sCurrentDispDt+6,2);
      }

      BCH_WriteRec(RS.EPBF010,(char *) &ALL, sizeof(ALL));
      RS.nRecsWrit++;
       
      if (A02824.A02824_appl_area.cEmplArRecInd == 'A')
         RS.nAddCnt++;
      else
         RS.nChngCnt++;

      /*** Get the next empl ar row ***/
      R02824.R02824_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A02824.A02824_appl_area,LOW_VALUES,sizeof(A02824.A02824_appl_area));
         
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02824,&A02824,SERVICE_ID_02824,1,sizeof(R02824.R02824_appl_area));
         
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            RS.nRecsRead++;
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02824");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      } /* end switch */ 

   } /* end while != ROW_NOT_FOUND */

   /* Move in HDR info */
   memset(&HDR, ' ', sizeof(HDR));
   strncpy(HDR.sInd, "HDR", 3);
   strncpy(HDR.sYear, sCurrentSortDt, 4);
   strncpy(HDR.sMonth, sCurrentDispDt, 2);
   strncpy(HDR.sDay, sCurrentDispDt+3, 2);
   strncpy(HDR.sHr, sCurrentHHMMSS, 2);
   strncpy(HDR.sMin, sCurrentHHMMSS+3, 2);
   strncpy(HDR.sSec, sCurrentHHMMSS+6, 2);
   sprintf(HDR.sicount,"%06d",RS.nRecsWrit);

   BCH_WriteRec(RS.EPBF010,(char *) &HDR, sizeof(HDR));

   /*** Next, Update the proc date of all empl ar items with a change indicator of 'C'  ***/
   /*** so that these items wont get processed again                                    ***/
   memset(&A02825,LOW_VALUES,sizeof(A02825));

   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02825,&A02825,SERVICE_ID_02825,1,sizeof(R02825));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02825");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   } /* end switch  */

   /*** Next, update the change indicator to 'C' of all items with a change indicator of 'A' ***/
   /*** so that on tomorrow, the items sent acros as adds will be retired                    ***/
   memset(&A02826,LOW_VALUES,sizeof(A02826));

   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02826,&A02826,SERVICE_ID_02826,1,sizeof(R02826));

   switch (nSvcRtnCd) 
   { 
      case ARC_SUCCESS: 
         break; 

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break; 
  
      default: 
         BCH_FormatMessage(1,TXT_SVC_UNSUCC); 
         BCH_FormatMessage(2,TXT_SVC, "FYS02826"); 
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   } /* end switch  */

    
   /*** Finally, delete all items that have been processed and the process date is > 3 days old ***/
   memset(&A02827,LOW_VALUES,sizeof(A02827));
  
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02827,&A02827,SERVICE_ID_02827,1,sizeof(R02827));

   switch (nSvcRtnCd)             
   {
      case ARC_SUCCESS:
         break;
 
      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02827");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   } /* end switch  */            
   
   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   sprintf(sErrorMessage, "Recs Read = %d, Recs Written = %d, Add Recs = %d, Chng Recs = %d",
                           RS.nRecsRead, RS.nRecsWrit, RS.nAddCnt, RS.nChngCnt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_Close(RS.EPBF010);
}
