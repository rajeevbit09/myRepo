/*######################################################################*/
/*                                                                      */
/* Copyright [2001] Delta Air Lines, Inc./Delta Technology, Inc.   */
/*                       All Rights Reserved                            */
/*               Access, Modification, or Use Prohibited                */
/* Without Express Permission of Delta Air Lines or Delta Technology.   */
/*                                                                      */
/*######################################################################*/
/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB85002.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  kenneth hancock                                        **
**                                                                         **
** Date Written:    03/18/96                                               **
**                                                                         **
** Description:     This module extracts information from the Remaining    **
**                  Allotment, PPR, Non-Rev Passenger, and Pass Card       **
**                  tbl depending on whats on the bdy_nrev_pax_dlm table.  **
**                  This information is written to an interface file that is*
**                  Then transferred to deltamatic via vector.             **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/
#include "epb85002.h"

main()
{
   BCH_Init("EPB85002", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{

   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sPprStrtDt, SPACE_CHAR);
   strcpy(RS.sNrevNbr, SPACE_CHAR);
   strcpy(RS.sPassTypCd, SPACE_CHAR);
   strcpy(RS.sPassDtTmTs, SPACE_CHAR);
   strcpy(RS.sPassGrpCd, SPACE_CHAR);
   strcpy(RS.sPsgrTypCd, SPACE_CHAR);
   strcpy(RS.sPsgrNm, SPACE_CHAR);
   strcpy(RS.sNrevBdayDt, SPACE_CHAR);
   strcpy(RS.sCardIssDt, SPACE_CHAR);
   strcpy(RS.sPassStsCd, SPACE_CHAR);
   strcpy(RS.sPassBrdPriId, SPACE_CHAR);
   strcpy(RS.sPassUpgrdPriId, SPACE_CHAR);
   RS.cImptInd = ' ';
   RS.cPassAddlInd = ' ';

   strcpy(RS.sNrevTypCd, SPACE_CHAR);
   RS.nNrevRemnDyQty = 0;
   RS.lNrevRemnMiQty = 0;
   RS.RemInd = '0';
   RS.AddInd = 0;
   RS.ReadCount = 0;
   RS.ErrCount = 0;
   RS.WrtCount = 0;
   RS.NonErrCnt = 0;
   RS.tempcnt = 0;
   RS.OkayToPrint = '0';
   nReward15 = FALSE;
   nCoBusiness = FALSE;

   /*** Write program start to log file ***/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   /*** Open output Deltamatic interface file ***/
   RS.EPBF010 = BCH_Open("EPBF010",BCH_FILE_WRITE);

   if (RS.EPBF010 == BCH_FAIL)
   {
      BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
      BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF010");
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   /*** Execute service to get all items from bdy_nrev_pax_dlm ***/
   memset(&R04719.R04719_appl_area,LOW_VALUES, sizeof(_R04719_APPL_AREA));
   memset(&A04719.A04719_appl_area,LOW_VALUES, sizeof(_A04719_APPL_AREA));
   R04719.R04719_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04719,&A04719,SERVICE_ID_04719,1,sizeof(_R04719_APPL_AREA));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04719");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
		 break;
   } /* end switch */ 

   DPM_2550_Deltamatic();

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Get PPR/nrev information from t_ppr,         **
**                  t_nrev_psgr, and t_pass_card                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   /*** get pass grp code and start date info for passenger if new PPR ***/
   if (strcmp(RS.sPprNbr, A04719.A04719_appl_area.sPprNbr))
   {
      memset(&R02864,LOW_VALUES,sizeof(R02864));
      memset(&A02864,LOW_VALUES,sizeof(A02864));
      strcpy(R02864.R02864_appl_area.sPprNbr,A04719.A04719_appl_area.sPprNbr);
      
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02864,&A02864,SERVICE_ID_02864,1,sizeof(R02864.R02864_appl_area));
      
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            strcpy(RS.sPprStrtDt, UTL_ConvertDate(A02864.A02864_appl_area.sPprStrtDt, CNV_DB_TO_YYMMDD));
            strcpy(RS.sPassGrpCd, A02864.A02864_appl_area.sPassGrpCd);
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02864");
            sprintf(sErrorMessage, "ppr = %s",  R02864.R02864_appl_area.sPprNbr);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
            break;

         } /* end switch  */

   } /* endif for ppr nbr   */

   /*** if new NREV get card info and nrev info***/
   if ((strcmp(RS.sPprNbr, A04719.A04719_appl_area.sPprNbr)) || (strcmp(RS.sNrevNbr, A04719.A04719_appl_area.sNrevNbr)))
   {
      /*** Get card issue date from t_pass_card ***/
      memset(&R02769,LOW_VALUES,sizeof(R02769));
      memset(&A02769,LOW_VALUES,sizeof(A02769));
      strcpy(R02769.R02769_appl_area.sPprNbr,A04719.A04719_appl_area.sPprNbr);
      strcpy(R02769.R02769_appl_area.sNrevNbr,A04719.A04719_appl_area.sNrevNbr);

      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02769,&A02769,SERVICE_ID_02769,1,sizeof(R02769.R02769_appl_area));
    
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            if (A02769.A02769_appl_area.sCardIssDt[0] == ' ')
               strcpy(A02769.A02769_appl_area.sCardIssDt, LOW_DATE);
            strcpy(RS.sCardIssDt, UTL_ConvertDate(A02769.A02769_appl_area.sCardIssDt, CNV_DB_TO_YYYYMMDD));
            break;

         case ARC_ROW_NOT_FOUND:
            strcpy(RS.sCardIssDt, "18991231");
            strcpy(A02769.A02769_appl_area.sCardIssDt, LOW_DATE);
            break;
 
         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02769");
            sprintf(sErrorMessage, "ppr = %s, nrev = %s",  R02769.R02769_appl_area.sPprNbr, R02769.R02769_appl_area.sNrevNbr); 
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage); 
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
            break;
      }  /* end switch */

      /******** Get birthday, nrev_type_cd, imput_ind, and pass status code from t_nrev_psgr ***/
      memset(&R04336,LOW_VALUES,sizeof(R04336));
      memset(&A04336,LOW_VALUES,sizeof(A04336));
      strcpy(R04336.R04336_appl_area.sPprNbr,A04719.A04719_appl_area.sPprNbr);
      strcpy(R04336.R04336_appl_area.sNrevNbr,A04719.A04719_appl_area.sNrevNbr);

      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04336,&A04336,SERVICE_ID_04336,1,sizeof(R04336.R04336_appl_area));
  
      switch (nSvcRtnCd)
      {  
         case ARC_SUCCESS:
            strcpy(RS.sPsgrNm, A04336.A04336_appl_area.sNrevNm);
            strcpy(RS.sNrevBdayDt, UTL_ConvertDate(A04336.A04336_appl_area.sNrevBdayDt, CNV_DB_TO_YYMMDD));
            strcpy(RS.sPassStsCd, A04336.A04336_appl_area.sPassStsCd);
            strcpy(RS.sNrevTypCd, A04336.A04336_appl_area.sNrevTypCd);
            RS.cImptInd = A04336.A04336_appl_area.cPassImptInd;
            break;
 
         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04336");
            sprintf(sErrorMessage, "ppr = %s, nrev = %s",  R04336.R04336_appl_area.sPprNbr, R04336.R04336_appl_area.sNrevNbr);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage); 
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
            break;
      }  /* end switch */                     
   } /* endif ppr and nrev */
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2510_ProcessRemAllot                     **
**                                                               **
** Description:     Get remaining allotment information          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2510_ProcessRemAllot()
{
   /*** Get REM ALLOT *******/
   memset(&R04338,LOW_VALUES,sizeof(R04338));
   memset(&A04338,LOW_VALUES,sizeof(A04338));
   strcpy(R04338.R04338_appl_area.sPprNbr,A04719.A04719_appl_area.sPprNbr);
   strcpy(R04338.R04338_appl_area.sNrevNbr,A04719.A04719_appl_area.sNrevNbr);
   strcpy(R04338.R04338_appl_area.sPassTypCd,A04719.A04719_appl_area.sPassTypCd);
 
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04338,&A04338,SERVICE_ID_04338,1,sizeof(R04338.R04338_appl_area));
   
   switch (nSvcRtnCd)
   {  
      case ARC_SUCCESS:
         RS.RemInd = '0';
         RS.cPassAddlInd = A04338.A04338_appl_area.cPassAddlInd;
         RS.nNrevRemnDyQty = A04338.A04338_appl_area.nNrevRemnDyQty;
         RS.lNrevRemnMiQty = A04338.A04338_appl_area.lNrevRemnMiQty;
         break;

      case ARC_ROW_NOT_FOUND:
         RS.RemInd = '1';
         RS.tempcnt++;
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04338");
         sprintf(sErrorMessage, "ppr = %s, nrev = %s, passtype = %s", 
                 R04338.R04338_appl_area.sPprNbr, R04338.R04338_appl_area.sNrevNbr, R04338.R04338_appl_area.sPassTypCd);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage); 
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2510_ProcessRemAllot");
         break;
   }  /* end switch */
} /* end of function  */

/******************************************************************
**                                                               **
** Function Name:   DPM_2550_Deltamatic                          **
**                                                               **
** Description:     Process each bdy_nrev_pax_dlm row                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/
void DPM_2550_Deltamatic()
{
   short compare;
   short x;
   short y;
   char sTempYr[3];
   char sTempMo[3];
   char sTempDy[3];
   char sTempMls[8];
   char name[31];
   char IND;
   char commaind;


   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      RS.ReadCount++;

      /*** Go get ppr and nrev information ***/
      DPM_2500_ProcessRows();

      strcpy(RS.sPprNbr, A04719.A04719_appl_area.sPprNbr);
      strcpy(RS.sNrevNbr, A04719.A04719_appl_area.sNrevNbr);
      strcpy(RS.sPassTypCd, A04719.A04719_appl_area.sPassTypCd);
      strcpy(RS.sPassDtTmTs, A04719.A04719_appl_area.sPassDtTmTs);
      if ((!strcmp(A04719.A04719_appl_area.sPprNbr, sSavePprNbr) == 0) ||
	 (!strcmp(A04719.A04719_appl_area.sNrevNbr, sSaveNrevNbr) == 0))
	  {
	  nReward15 = FALSE;
	  nCoBusiness = FALSE;
	  RS.OkayToPrint = '0';
	  }
      if (A04719.A04719_appl_area.cEmplArRecInd != 'D')
      {
         /*** Go get remaining allotment information ***/
         DPM_2510_ProcessRemAllot();
         if (RS.RemInd == '0')
         {
            /*** call service to get boarding priority ***/
            strcpy(R04054.R04054_appl_area.sPassTypCd,RS.sPassTypCd);
            strcpy(R04054.R04054_appl_area.sNrevTypCd, RS.sNrevTypCd);
            strcpy(R04054.R04054_appl_area.sPassGrpCd,RS.sPassGrpCd);
            memset(&A04054,LOW_VALUES,sizeof(A04054));

            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04054,&A04054,SERVICE_ID_04054,1,sizeof(R04054.R04054_appl_area));
 
            switch (nSvcRtnCd)
            {  
               case ARC_SUCCESS:
                  IND = '0';
                  break; 

               case ARC_ROW_NOT_FOUND:
                  if (strcmp(RS.sPassStsCd, "RV") == 0)
                  {
                     IND = '0';
                     strcpy(A04054.A04054_appl_area.sPassBrdPriId, SPACE_CHAR);
                     strcpy(A04054.A04054_appl_area.sPassUpgrdPriId, SPACE_CHAR);
                  }
                  else
                  {
                     IND = '1';
                     BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
                     BCH_FormatMessage(2,TXT_SVC, "FYS04054");
                     sprintf(sErrorMessage, "chng ind = %c, ppr = %s, nrev = %s, passtypcd = %s",
                             A04719.A04719_appl_area.cEmplArRecInd, A04719.A04719_appl_area.sPprNbr,
                             A04719.A04719_appl_area.sNrevNbr, A04719.A04719_appl_area.sPassTypCd);
                     BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
                     sprintf(sErrorMessage, "passgrpcd = %s,  nrevtypcd =%s",RS.sPassGrpCd, A04336.A04336_appl_area.sNrevTypCd);
                     BCH_FormatMessage(4,TXT_ERR_GENERIC_TXT, sErrorMessage);
                     BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2550_Deltamatic");
                     RS.ErrCount++;
                  }
                  break;

               default:
                  BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                  BCH_FormatMessage(2,TXT_SVC, "FYS04054");
                  sprintf(sErrorMessage, "chng ind = %c, ppr = %s, nrev = %s, passtypcd = %s",
                          A04719.A04719_appl_area.cEmplArRecInd, A04719.A04719_appl_area.sPprNbr,
                          A04719.A04719_appl_area.sNrevNbr, A04719.A04719_appl_area.sPassTypCd);
                  BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
                  sprintf(sErrorMessage, "passgrpcd = %s,  nrevtypcd =%s",RS.sPassGrpCd, A04336.A04336_appl_area.sNrevTypCd);
                  BCH_FormatMessage(4,TXT_ERR_GENERIC_TXT, sErrorMessage);
                  BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2550_Deltamatic");
                  IND = '1';
                  RS.ErrCount++;
                  break;
            } /* end switch */

            /*** If boarding priority found, build interface ***/
            if (IND== '0')
            {
               memset(&REM, ' ', sizeof(REM));
               memset(&name, ' ', sizeof(name));
               REM.cchngind = A04719.A04719_appl_area.cEmplArRecInd;
               sprintf(REM.spprnbr,"%-9s", A04719.A04719_appl_area.sPprNbr);
               sprintf(REM.spassbrdpriid, "%-4s", A04054.A04054_appl_area.sPassBrdPriId);
               sprintf(REM.spassupgrdpriid, "%-4s", A04054.A04054_appl_area.sPassUpgrdPriId);

               /*** convert start date from yymmdd to mmddyy format ***/
               strcpy(REM.sstrtdt, UTL_ConvertDate(RS.sPprStrtDt, CNV_YYMMDD_TO_MMDDYY)); 

               sprintf(REM.spassgrpcd,"%-2s", RS.sPassGrpCd);

               sprintf(REM.spsgrtypcd,"%-2s", RS.sNrevTypCd);

               /*** The following is for taking out non-alpha ****/
               for (x=0, y=0, commaind = '0'; x<30; x++)
               {
                  if (RS.sPsgrNm[x] != '\0') 
                  {
                     if ((RS.sPsgrNm[x] >= 'A' && RS.sPsgrNm[x] <= 'Z') || RS.sPsgrNm[x] == ' ' || 
                         (RS.sPsgrNm[x] == ',' && commaind == '0'))
                     {
                        if (RS.sPsgrNm[x] == ',') 
                           commaind = '1';
                        name[y] = RS.sPsgrNm[x];
                        y++;
                     }
                  } /* endif '/0' */
                  else
                     x = 30;
               } /* end for  */
               name[30] = '\0';

               sprintf(REM.spsgrnm, "%-30s", name); 
               strcpy(REM.snrevnbr,A04719.A04719_appl_area.sNrevNbr);

			   /*** convert birth  date from yymmdd to mmddyy format ***/
               strcpy(REM.sbrthdt, UTL_ConvertDate(RS.sNrevBdayDt, CNV_YYMMDD_TO_MMDDYY));

               /*** convert card issue date from yymmdd to mmddyy format ***/
               strcpy(REM.scardissdt, UTL_ConvertDate(RS.sCardIssDt, CNV_YYYYMMDD_TO_MMDDYY));

               /*** Get PassTyp should always be 90... ***/
	       if (strcmp(A04719.A04719_appl_area.sPassTypCd, "90") == 0)
		  sprintf(REM.spasstypcd, "%-2s", "CO");


               sprintf(REM.srembrdgs,"%03d",RS.nNrevRemnDyQty);

               /* Get last 5 digits of mileage - to prevent overflow **/
               memset(&sTempMls, LOW_VALUES, sizeof(sTempMls));
               memset(&REM.sremmiles, LOW_VALUES, sizeof(REM.sremmiles));
               if (RS.lNrevRemnMiQty < 0)
                  sprintf(sTempMls, "%-7s", "0000000");
               else
                  sprintf(sTempMls,"%07d",RS.lNrevRemnMiQty);
               strncpy(REM.sremmiles, sTempMls+2,5);

            /**** remove this code                               ****/
   /*****         if (A04719.A04719_appl_area.cEmplArRecInd == 'D')
		   sprintf(REM.spassstscd,"%-2s", "RD");
            else                       
	    *****/

               if (
		   ((strcmp(RS.sPassStsCd, "ER") == 0) || 
                    (strcmp(RS.sPassStsCd, "SU") == 0)) &&
                   (strcmp(RS.sNrevTypCd, "BU") == 0)
		  )
		   sprintf(REM.spassstscd,"%-2s", "RV");
                 else
               sprintf(REM.spassstscd,"%-2s", RS.sPassStsCd);

               REM.cimptind = RS.cImptInd;

               REM.cpassaddlind = RS.cPassAddlInd;
               
	       if ((((!strcmp(A04719.A04719_appl_area.sPassTypCd, "30") == 0) &&
	            (!strcmp(A04719.A04719_appl_area.sPassTypCd, "05") == 0) &&
	            (!strcmp(A04719.A04719_appl_area.sPassTypCd, "12") == 0)) &&
		   ((nReward15 == FALSE) || (nReward15 == TRUE))) ||
	           ((strcmp(A04719.A04719_appl_area.sPassTypCd, "30") == 0) &&
		    (nReward15 == FALSE)))
		    {
		    RS.OkayToPrint = '1';
		    }
           
	   if (RS.OkayToPrint == '1')
               {
               /*** format output interface record ***/
               sprintf(RS.EPBF010_buffer, REM_FORMAT,
                                          REM.cchngind,
                                          REM.spprnbr,
                                          REM.sstrtdt,
                                          REM.spassgrpcd,
                                          REM.spsgrtypcd,
                                          REM.spsgrnm,
                                          REM.snrevnbr,
                                          REM.sbrthdt,
                                          REM.scardissdt,
                                          REM.spassstscd,
                                          REM.cimptind,
                                          REM.spasstypcd,
                                          REM.srembrdgs,
                                          REM.sremmiles,
                                          REM.cpassaddlind,
                                          REM.spassbrdpriid,
                                          REM.spassupgrdpriid,
					  REM.sfiller);
                  BCH_WriteRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
                  RS.WrtCount++;
               }
	        /*** endif for Pass type 15 and Pass type 30  ***/

            } /*** endif for IND = 0  (boarding priority found)  ******/

         } /**** endif for RemInd = 0  (a remaining allotment was found  ***/
         else /*** no remaing allotment found for change ind 'C' or 'A' ***/
         {
            /*** print warning message ***/
            sprintf(sErrorMessage, "NO REM_ALLOT  chng ind = %c, ppr = %s, nrev = %s, passtypcd = %s",
            A04719.A04719_appl_area.cEmplArRecInd, RS.sPprNbr, RS.sNrevNbr, RS.sPassTypCd);
            BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2550_Deltamatic");
            RS.ErrCount++;
            RS.NonErrCnt = RS.NonErrCnt + (RS.tempcnt -1);
            RS.tempcnt = 0;
         } /* end else  */
    
         /*** delete bdy_nrev_pax_dlm ***/
         R04719.R04719_appl_area.cArchCursorOpTxt = DELETE_ROW;
         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04719,&A04719,SERVICE_ID_04719,1,sizeof(R04719.R04719_appl_area));

         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;                     

            default:  
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS04719");
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2550_Deltamatic");
         } /* end switch */                       
      
      } /*** endif for change indicator not delete *****/
      else  /** change indicator is delete ***/
      {
         RS.RemInd = '0';
         memset(&REM, ' ', sizeof(REM));
         memset(&RS.EPBF010_buffer, ' ', sizeof(RS.EPBF010_buffer));
 
         REM.cchngind = A04719.A04719_appl_area.cEmplArRecInd;

         sprintf(REM.spprnbr,"%-9s", A04719.A04719_appl_area.sPprNbr);
         sprintf(REM.snrevnbr,"%-2s", A04719.A04719_appl_area.sNrevNbr);
         sprintf(REM.sstrtdt,"%-6s", "      ");
         sprintf(REM.spassgrpcd,"%-2s", "  ");
         sprintf(REM.spsgrtypcd,"%-2s", "  ");
         sprintf(REM.spsgrnm,"%-30s", "                              ");
         sprintf(REM.sbrthdt,"%-6s", "      ");
         sprintf(REM.scardissdt,"%-6s", "      ");


        /**** If buddy status is "RV" change to "RD", all other   ****/
/****  remove for buddy 
        if ((strcmp(RS.sPassStsCd, "RV") == 0) &&
           (strcmp(RS.sNrevTypCd, "BU") == 0))
            sprintf(REM.spassstscd,"%-2s", "RD");
        else
            if ((strcmp(RS.sPassStsCd, "ER") == 0) &&
                (strcmp(RS.sNrevTypCd, "BU") == 0)) 
                sprintf(REM.spassstscd,"%-2s", "RV");
            else                         
        sprintf(REM.spassstscd,"%-2s", RS.sPassStsCd);   *****/
        sprintf(REM.spassstscd,"%-2s", "RD");

         REM.cimptind = ' ';
         sprintf(REM.srembrdgs,"%-3s", "   ");
         sprintf(REM.sremmiles,"%-5s", "     ");
         REM.cpassaddlind = ' ';
         sprintf(REM.spassbrdpriid,"%-4s", "    ");
         sprintf(REM.spassupgrdpriid,"%-4s", "    ");

         /*****pass typ should always be 90... ***/
		
	 if (strcmp(A04719.A04719_appl_area.sPassTypCd, "90") == 0)
	     sprintf(REM.spasstypcd, "%-2s", "CO");

         /*** format output interface record ***/
         sprintf(RS.EPBF010_buffer, REM_FORMAT,
                                    REM.cchngind,
                                    REM.spprnbr,
                                    REM.sstrtdt,
                                    REM.spassgrpcd,
                                    REM.spsgrtypcd,
                                    REM.spsgrnm,
                                    REM.snrevnbr,
                                    REM.sbrthdt,
                                    REM.scardissdt,
                                    REM.spassstscd,
                                    REM.cimptind,
                                    REM.spasstypcd,
                                    REM.srembrdgs,
                                    REM.sremmiles,
                                    REM.cpassaddlind,
                                    REM.spassbrdpriid,
                                    REM.spassupgrdpriid,
                                    REM.sfiller);

         BCH_WriteRec(RS.EPBF010, RS.EPBF010_buffer, sizeof(RS.EPBF010_buffer));
         RS.WrtCount++;

         /*** Delete the t_deletamatic row ***/
         R04719.R04719_appl_area.cArchCursorOpTxt = DELETE_ROW;
         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04719,&A04719,SERVICE_ID_04719,1,sizeof(R04719.R04719_appl_area));
             
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;
 
            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS04719");
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2550_Deltamatic");
         } /* end switch */
      } /*** end else  for change indicator = delete ***/

      /*** Get the next bdy_nrev_pax_dlm row ****/
      R04719.R04719_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04719.A04719_appl_area,LOW_VALUES,sizeof(A04719.A04719_appl_area));

      nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04719,&A04719,SERVICE_ID_04719,1,sizeof(R04719.R04719_appl_area));
    
      switch (nSvcRtnCd) 
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04719");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2550_Deltamatic");
 
      } /* end switch */ 
  } /* endwhile */
} /* end of function  */

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   sprintf(sErrorMessage, "Recs Read = %5d, Errors = %3d, Recs Written = %5d, Ignored Recs = %3d",
           RS.ReadCount, RS.ErrCount, RS.WrtCount, RS.NonErrCnt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_Close(RS.EPBF010);
}
