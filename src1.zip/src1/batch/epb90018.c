/**************************************************************************** 
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         ** 
** Sub-System :                                                            **
**                                                                         ** 
** Program Name:    EPB90018.c                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.c>                                           **
**                                                                         **
** Program Type:    Batch Report Format Module with zero control breaks    **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Gillian Lyth                                           **
**                                                                         **
** Date Written:    Feb 23, 1996                                           **
**                                                                         **
** Description:     This program reads the sort record created by program  **
**                  EPB90008 and formats the "READY RESERVE REPORT".       **
**                                                                         **
** Revision Trail:                                                         ** 
**                                                                         ** 
** Date       Revised by         SIR #    Description                      ** 
** ----       ----------         -----    -----------                      ** 
**                                                                         ** 
** 11/12/96   F. Ammons                   Add more useful instructions as  **
**                                        well as, a relationship column.  **
**                                        Also, changed the sort order.    **
**                                                                         **
****************************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "epb90018.h"
#include "bchrfmcd.h"

main()
{
   RFM_1000_InitializeFlds();
   while ((feof(stdin)) == 0)
      {
      RFM_3000_ProcessDetail();  
      }
   RFM_4000_ProcessEndOfJob();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1000_InitializeFlds                      **
**                                                               **
** Description:     Initialize fields, read initial record,      **
**                  zero accumulators                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1000_InitializeFlds()
{
   char   sCurrentDate[13];  /* current date in mm/dd/yy format */

   rfm_ReadNextRecord();

   /* Initialize totals */
   nRptPagesWritten = 0;

   /* No application accumulators */

   /* Get system date and time    */
   current = time((time_t *)0);
   strcpy(tu.t_str, ctime(&current));
   strftime(sCurrentDate,12,"%m/%d/%y",localtime(&current));

   tu.t_str[7] = tu.t_str[10]=tu.t_str[19]=tu.t_str[24]='\0';
 
   /* If report has an as of date, format the as of date here   */
   nCurrentLineCount = NEW_PAGE;
   memset(print_line,' ',PAGE_WIDTH);
   strcpy(sRequestId, input_area.rqst_id);

   /* Format and save standard headings */

   /* standard heading 1 */
   PRINT_SETUP(1,"CSR #:");
   PRINT_SETUP(11,"7932");
   PRINT_SETUP(56,STD_RPT_TITLE);
   PRINT_SETUP(115,"PAGE:");
   memcpy(std_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 2 */
   PRINT_SETUP(1,"REPORT:");
   PRINT_SETUP(11, "EPB90018");
   PRINT_SETUP(49, "READY RESERVE PASS USAGE REPORT");
   PRINT_SETUP(115,"DATE:");
   PRINT_SETUP(123, sCurrentDate);
   memcpy(std_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 3 */
   sprintf(sFormatFld, "PERIOD %s TO %s", rpt_data.F9008_RptDataStruct.sFltFeeBegDt, rpt_data.F9008_RptDataStruct.sFltFeeEndDt);
   PRINT_SETUP(51, sFormatFld);
   PRINT_SETUP(115,"TIME:");
   PRINT_SETUP(123,tu.ts.hh_mm_ss);
   memcpy(std_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 1 */
   PRINT_SETUP(10, "INSTRUCTIONS FOR USE:");
   memcpy(appl_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
 
   /* application heading 2 */
   PRINT_SETUP(15, 
      "THE FOLLOWING READY RESERVE NON-REVENUE PASSENGERS HAVE FLOWN FLIGHT DAYS DURING THE PERIOD");
   memcpy(appl_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 3 */
   PRINT_SETUP(15, 
      "SPECIFIED ABOVE.  THIS IS THE ONLY COPY OF THE REPORT PRODUCED FOR USE BY YOUR STATION AND DEPARTMENT.");
   memcpy(appl_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 4 */
   PRINT_SETUP(15, 
      "PLEASE ENSURE THAT THE REPORT IS REVIEWED BY ALL MANAGERS IN YOUR AREA.  VERIFY THAT ALL FLIGHT DAYS FLOWN");
   memcpy(appl_heading_4,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 5 */
   PRINT_SETUP(15, 
      "WERE AUTHORIZED.  REPORT ANY UNAUTHORIZED TRAVEL TO THE PASS BUREAU, DEPT 956, ATG, 404-715-2545.");
   memcpy(appl_heading_5,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 7 */
   PRINT_SETUP(10, "MANAGER");
   memcpy(appl_heading_7,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 8 is formatted in RFM_5000_PageHeadings */

   /* application heading 9 is formatted in RFM_5000_PageHeadings */

   /* application heading 10 */
   PRINT_SETUP(10, "PPR ID/NON-REV ID");
   PRINT_SETUP(31, "PPR/NON-REVENUE PASSENGER NAME");
   PRINT_SETUP(64, "RLTNSHP");
   PRINT_SETUP(76, "PASS TYPE");
   PRINT_SETUP(89, "FLT DATE");
   PRINT_SETUP(101, "FLT NBR");
   PRINT_SETUP(111, "ORIG / DEST");
   memcpy(appl_heading_10,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 11 */
   PRINT_SETUP(10, "_________________");
   PRINT_SETUP(31, "______________________________");
   PRINT_SETUP(64, "_______");
   PRINT_SETUP(76, "__________");
   PRINT_SETUP(88, "___________");
   PRINT_SETUP(101, "_______");
   PRINT_SETUP(110, "_____________");
   memcpy(appl_heading_11,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3000_ProcessDetail                       **
**                                                               **
** Description:     Process detail line, read next record and    **
**                  determine if there was a control break       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3000_ProcessDetail()
{
    RFM_3100_ProcessReportRecord();
    rfm_ReadNextRecord();
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3100_ProcessReportRecord                 **
**                                                               **
** Description:     Format detail line, add amounts to control   **
**                  totals.                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3100_ProcessReportRecord()
{
   nLinesInGroup = DETAIL_LINE;

   /* Set end of report indicator to no */
   cEndOfRpt = 'N';

   /* Save and print station ID and department number on new page if either
      is different than the saved fields                                      */
   if (strcmp(rpt_data.F9008_RptDataStruct.sPprStnId, sSavePprStnId) != 0  ||
       strcmp(rpt_data.F9008_RptDataStruct.sPprDeptNbr, sSavePprDeptNbr) != 0) 

      { 
      strcpy(sSavePprStnId, rpt_data.F9008_RptDataStruct.sPprStnId);
      strcpy(sSavePprDeptNbr, rpt_data.F9008_RptDataStruct.sPprDeptNbr);
      if (cFirstTime == 'N')
         {
         RFM_3500_CreateFooter();
         nCurrentLineCount = NEW_PAGE;
         }
      }

   /* Save and print  PPR number for new group line, if there is a new PPR Id */
   if ((strcmp(rpt_data.F9008_RptDataStruct.sPprNbr, sSavePprNbr) != 0 &&
        strcmp(rpt_data.F9008_RptDataStruct.sPprNbr, NULL_STRING) != 0)) 
      { 
      /* Start a new page if there is not enough room for new group line */
      if (nCurrentLineCount > (LINES_PER_PAGE - 4))
         nCurrentLineCount = NEW_PAGE;
      
      strcpy(sSavePprNbr, rpt_data.F9008_RptDataStruct.sPprNbr);

      /* Set first time record read indicator to false */
      cFirstTime = 'N';
     
      /* Print PPR fields */
      sprintf(sFormatFld, "%s00", rpt_data.F9008_RptDataStruct.sPprNbr);
      PRINT_SETUP(10, sFormatFld);    
      PRINT_SETUP(31, rpt_data.F9008_RptDataStruct.sPprNm);    
      if (nCurrentLineCount == 19)
         rfm_ControlPrint(SINGLE_SPACE, print_line);
      else
         rfm_ControlPrint(TRIPLE_SPACE, print_line);

      /* Save and print  NRev number */
      strcpy(sSaveNrevNbr, rpt_data.F9008_RptDataStruct.sNrevNbr);
      sprintf(sFormatFld, "%s%s", rpt_data.F9008_RptDataStruct.sPprNbr,
              rpt_data.F9008_RptDataStruct.sNrevNbr);
      PRINT_SETUP(11, sFormatFld);    
      PRINT_SETUP(32, rpt_data.F9008_RptDataStruct.sNrevNm);    
      PRINT_SETUP(64 + CenterPosition(7, rpt_data.F9008_RptDataStruct.sNrevTypCd),
              rpt_data.F9008_RptDataStruct.sNrevTypCd);    
      }

   /* Save and print  NRev number for new group line, if there is a new NRev number */
   else if (strcmp(rpt_data.F9008_RptDataStruct.sNrevNbr, sSaveNrevNbr) != 0 ||
           (nCurrentLineCount == LINES_PER_PAGE)) 
      { 
      strcpy(sSaveNrevNbr, rpt_data.F9008_RptDataStruct.sNrevNbr);
     
      /**** Print other heading fields ****/
      sprintf(sFormatFld, "%s%s", rpt_data.F9008_RptDataStruct.sPprNbr,
              rpt_data.F9008_RptDataStruct.sNrevNbr);
      PRINT_SETUP(11, sFormatFld);    
      PRINT_SETUP(32, rpt_data.F9008_RptDataStruct.sNrevNm);    
      PRINT_SETUP(64 + CenterPosition(7, rpt_data.F9008_RptDataStruct.sNrevTypCd),
              rpt_data.F9008_RptDataStruct.sNrevTypCd);    
      }

   /* Print detail information for non-revenue passenger */
   if (strcmp(rpt_data.F9008_RptDataStruct.sPassTypCd, "10") == 0)
      PRINT_SETUP(74, "Emergency");
   if (strcmp(rpt_data.F9008_RptDataStruct.sPassTypCd, "20") == 0)
      PRINT_SETUP(74, "Priority");
   if (strcmp(rpt_data.F9008_RptDataStruct.sPassTypCd, "30") == 0)
      PRINT_SETUP(74, "Honor Roll");
   if (strcmp(rpt_data.F9008_RptDataStruct.sPassTypCd, "40") == 0)
      PRINT_SETUP(74, "Transoceanic");
   if (strcmp(rpt_data.F9008_RptDataStruct.sPassTypCd, "50") == 0)
      PRINT_SETUP(74, "Domestic");
   if (strcmp(rpt_data.F9008_RptDataStruct.sPassTypCd, "90") == 0)
      PRINT_SETUP(74, "Comb Dom/To");
   PRINT_SETUP(88, rpt_data.F9008_RptDataStruct.sFltDprtDt);     
   PRINT_SETUP(101 + CenterPosition(7, rpt_data.F9008_RptDataStruct.sFltNbr), rpt_data.F9008_RptDataStruct.sFltNbr);    
   sprintf(sFormatFld, "%s / %s", rpt_data.F9008_RptDataStruct.sFltOrigCtyId,
           rpt_data.F9008_RptDataStruct.sFltDestCtyId);
   PRINT_SETUP(110 + CenterPosition(13, sFormatFld), sFormatFld);    
   rfm_ControlPrint(SINGLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3500_CreateFooter                        **
**                                                               **
** Description:     Write footer containing relationship         **
**                  descriptions.                                **
**                                                               **
** Arguments:                                                    **
**                                                               **
**                                                               **
** Return Values:                                                **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_3500_CreateFooter()
{
   while (nCurrentLineCount < (LINES_PER_PAGE - 6))
      rfm_ControlPrint(SINGLE_SPACE, print_line);

   PRINT_SETUP(10, 
      "SF=SELF   SP=SPOUSE   MC=MINOR DEPEND CHILD<19   ST=FT DEPEND STDNT CHILD<23   DA=DEPEND ADULT RELATIVE");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
   PRINT_SETUP(10, 
      "ND=NON-DEPEND CHILD   PR=PARENT");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_4000_ProcessEndOfJob                     **
**                                                               **
** Description:     Format grand total line, print end of report **
**                  line, close input file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4000_ProcessEndOfJob()
{
   /*  No grand total line  */

   /* Set end of report indicator to yes */
   cEndOfRpt = 'Y';

   RFM_3500_CreateFooter();

   /* Format end of report line */
   PRINT_SETUP(3,"END OF REPORT");
   rfm_PrintLine(DOUBLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_5000_PageHeadings                        **
**                                                               **
** Description:     Format and print heading line                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_5000_PageHeadings()
{
   char sNbrOfReportPages[4];  /* Number of report pages written */
 
   nRptPagesWritten++;
 
   /*  Format first standard heading line */
   memcpy(print_line,std_heading_1,PAGE_WIDTH);
   sprintf(sNbrOfReportPages,"%3i",nRptPagesWritten);
   PRINT_SETUP(128,sNbrOfReportPages);
   rfm_PrintLine(NEW_PAGE,print_line);
 
   /*  Format second standard heading line */
   memcpy(print_line,std_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   /*  Format third standard heading line */
   memcpy(print_line,std_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
   rfm_PrintLine(TRIPLE_SPACE, print_line);
 
   /* Print application headings if end of report indicator is no */
   if (cEndOfRpt == 'N')
      {
      /*  Format application headings */
      memcpy(print_line,appl_heading_1,PAGE_WIDTH);
      rfm_PrintLine(DOUBLE_SPACE, print_line);

      memcpy(print_line,appl_heading_2,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_3,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_4,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_5,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_7,PAGE_WIDTH);
      rfm_PrintLine(TRIPLE_SPACE, print_line);

      /* variable application heading 8 */
      sprintf(sFormatFld, "DEPARTMENT - %s", rpt_data.F9008_RptDataStruct.sPprDeptNbr); 
      PRINT_SETUP(10, sFormatFld);
      memcpy(appl_heading_8,print_line,PAGE_WIDTH);
      memcpy(print_line,appl_heading_8,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      /* variable application heading 9 */
      sprintf(sFormatFld, "STATION - %s", rpt_data.F9008_RptDataStruct.sPprStnId); 
      PRINT_SETUP(10, sFormatFld);
      memcpy(appl_heading_9,print_line,PAGE_WIDTH);
      memcpy(print_line,appl_heading_9,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_10,PAGE_WIDTH);
      rfm_PrintLine(TRIPLE_SPACE, print_line);

      memcpy(print_line,appl_heading_11,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      rfm_PrintLine(SINGLE_SPACE, print_line);
      }
}


/******************************************************************
**                                                               **
** Function Name:   CenterPosition                               **
**                                                               **
** Description:     Calculates number of positions to move       **
**                  to position text in center of field          **
**                                                               **
** Arguments:       Length of field                              **
**                  Input character string                       **
**                                                               **
** Return Values:   Position to center character string          **
**                                                               **
**                                                               **
******************************************************************/
 
int CenterPosition(int nLength, char sInput[])
{
   int nNbr;      /* Position to center string */

   nNbr = (nLength - (int)strlen(sInput)) / 2;
   return nNbr;
} 
