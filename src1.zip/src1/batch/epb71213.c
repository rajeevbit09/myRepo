/**************************************************************************** 
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         ** 
** Sub-System :                                                            **
**                                                                         ** 
** Program Name:    EPB71213.c                                             ** 
**                                                                         ** 
** Shell Used:      <shlrfmc0.c>                                           ** 
**                                                                         **
** Program Type:    Batch Report Format Module with zero control breaks    ** 
**                                                                         ** 
** Author :         <Transquest>                                           ** 
**                  <Kimberly Gordon>                                      ** 
**                                                                         ** 
** Date Written:    October 24, 1995                                       ** 
**                                                                         ** 
** Description:     This module creates the Western Early Out and          **
**                  Voluntary Severance Imputed Wage Notifications.        **
**                                                                         **
** Revision Trail:                                                         ** 
**                                                                         ** 
** Date       Revised by         SIR #    Description                      ** 
** ----       ----------         -----    -----------                      ** 
**                                                                         **
** 01/08/96     FFA                       Revised                          **
**                                                                         ** 
****************************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "frapecep.h"
#include "epb71213.h"
#include "bchrfmcd.h"

main()
{
   	RFM_1000_InitializeFlds();
   	while ((feof(stdin)) == 0)
      	{
      		RFM_3000_ProcessDetail();  
      	}
   		RFM_4000_ProcessEndOfJob();
   	exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1000_InitializeFlds                      **
**                                                               **
** Description:     Initialize fields, read initial record,      **
**                  zero accumulators                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1000_InitializeFlds()
{
char   sCurrentDate[13];  /* current date in mm/dd/yy format */

   rfm_ReadNextRecord();

   /*  Initialize fields      */
   nRptPagesWritten = 0;
   strcpy(sSaveNrevNbr, "  ");
   strcpy(sSaveNrevNm, SPACE_CHAR);
   cEndOfRpt = 'N';
   fTotImpWgs = 0.0;
   strcpy(sSavePprNbr, rpt_data.F7123_RptDataStruct.sPprNbr);

   /* Get system date and time    */
   current = time((time_t *)0);
   strcpy(tu.t_str, ctime(&current));
   strftime(sCurrentDate,12,"%m/%d/%y",localtime(&current));
   tu.t_str[7] = tu.t_str[10]=tu.t_str[19]=tu.t_str[24]='\0';
 
   /* If report has an as of date, format the as of date here   */
   nCurrentLineCount = NEW_PAGE;
   memset(print_line,' ',PAGE_WIDTH);
   strcpy(sRequestId, input_area.rqst_id);

   /* Format and save standard headings */
   /* standard heading 1 */
   PRINT_SETUP(1,"CSR #:");
   PRINT_SETUP(10,"7914");
   PRINT_SETUP(56,STD_RPT_TITLE);
   PRINT_SETUP(115,"PAGE:");
   memcpy(std_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 2 */
   PRINT_SETUP(1,"REPORT:");
   PRINT_SETUP(10,"EPB71213");
   PRINT_SETUP(38,"WESTERN AND VOLUNTARY SEVERANCE IMPUTED WAGE NOTIFICATION");
   PRINT_SETUP(115,"DATE:");
   PRINT_SETUP(123,sCurrentDate);
   memcpy(std_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 3 */
   PRINT_SETUP(59, "AS OF ");
   PRINT_SETUP(65, sCurrentDate);
   PRINT_SETUP(115,"TIME:");
   PRINT_SETUP(123,tu.ts.hh_mm_ss);
   memcpy(std_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* Format 3 lines of verbage */
   PRINT_SETUP(1,"PLEASE REVIEW THE FOLLOWING TRAVEL INFORMATION FOR DISCREPANCIES.  IF THERE ARE");
   PRINT_SETUP(81, "ANY CORRECTIONS, PLEASE RETURN A COPY OF YOUR");
   memcpy(appl_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   PRINT_SETUP(1,"NOTIFICATION ALONG WITH AN EXPLANATION OF THE PROBLEM TO THE PASS BUREAU, DEPT 956,");
   PRINT_SETUP(85, "ATL - PHONE NUMBER (404)715-2545.  THESE");
   memcpy(appl_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   PRINT_SETUP(1,"AMOUNTS WILL BE REPORTED AT THE END OF THE YEAR ON A 1099 FORM.");
   memcpy(appl_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* Format 1st line of column heading */
   PRINT_SETUP(88, "IMPUTED");
   PRINT_SETUP(102, "EMPLOYEE");
   PRINT_SETUP(116, "IMPUTED");
   memcpy(appl_heading_4,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* Format 2nd line of column heading */
   PRINT_SETUP(39, "TRIP");
   PRINT_SETUP(50, "FLIGHT");
   PRINT_SETUP(63, "TRIP");   
   PRINT_SETUP(89, "VALUE");
   PRINT_SETUP(102, "PAYMENT");
   PRINT_SETUP(117, "WAGE");
   memcpy(appl_heading_5,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
 
   /* Format 3rd line of column heading */
   PRINT_SETUP(11, "PASSENGER NAME");
   PRINT_SETUP(39, "DATE");
   PRINT_SETUP(50, "NUMBER");
   PRINT_SETUP(60, "ORIG / DEST");
   PRINT_SETUP(75, "MI FLOWN");
   PRINT_SETUP(89, "(USD)");
   PRINT_SETUP(103, "(USD)");
   PRINT_SETUP(117, "(USD)");
   memcpy(appl_heading_6,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* Format 4th line of column heading */
   PRINT_SETUP(3, "______________________________");
   PRINT_SETUP(36,"___________");
   PRINT_SETUP(50,"______");
   PRINT_SETUP(59,"_____________");
   PRINT_SETUP(75,"________");
   PRINT_SETUP(86,"___________");
   PRINT_SETUP(100,"___________");
   PRINT_SETUP(114,"___________");
   memcpy(appl_heading_7,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

}

/******************************************************************
**                                                               **
** Function Name:   RFM_3000_ProcessDetail                       **
**                                                               **
** Description:     Process detail line, read next record and    **
**                  determine if there was a control break       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3000_ProcessDetail()
{
    RFM_3100_ProcessReportRecord();
    rfm_ReadNextRecord();
    if (strcmp(rpt_data.F7123_RptDataStruct.sPprNbr, sSavePprNbr) != 0) 
    {
        /* if new ppr, print the totals and trailer verbage for this PPR */
        RFM_4100_PrintTrailerLines();

        /* After printing the trailer for this PPR, start a new page for the new PPR */
        strcpy(sSavePprNbr, rpt_data.F7123_RptDataStruct.sPprNbr);
        strcpy(sSaveNrevNbr, "  ");
        fTotImpWgs = 0.00;
        nRptPagesWritten = 0;
        RFM_5000_PageHeadings();
     }
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3100_ProcessReportRecord                 **
**                                                               **
** Description:     Format detail line, add amounts to control   **
**                  totals.                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3100_ProcessReportRecord()
{
   char sPrintFld[14];

   /* If the nrev nbr changes, print the name on the first line only, */
   /* dont repeat the nrev name for multiple occurrances              */
   if (strcmp(rpt_sort.S7123_RptDataStruct.sNrevNbr, sSaveNrevNbr) != 0)
   {
        rfm_ControlPrint(SINGLE_SPACE, print_line);
        strcpy(sSaveNrevNbr, rpt_sort.S7123_RptDataStruct.sNrevNbr);
        PRINT_SETUP(3, rpt_data.F7123_RptDataStruct.sNrevNm);
   }
   else
        PRINT_SETUP(3, sSaveNrevNm);

   PRINT_SETUP(36, rpt_data.F7123_RptDataStruct.sFltDprtDt);
   sprintf(sPrintFld, "%s", rpt_data.F7123_RptDataStruct.sFltNbr);
   PRINT_SETUP(50+CenterPosition(6,sPrintFld), sPrintFld);
   sprintf(sPrintFld, "%5s / %-5s", rpt_data.F7123_RptDataStruct.sFltTripOrigId, 
                                    rpt_data.F7123_RptDataStruct.sFltTripDestId);
   PRINT_SETUP(59, sPrintFld);
   
   //sprintf(sPrintFld, "%ld", rpt_data.F7123_RptDataStruct.lFltArptPrNbr);
   //PRINT_SETUP(75+CenterPosition(8,sPrintFld), sPrintFld);
   PRINT_SETUP(75+CenterPosition(8,sPrintFld), rpt_data.F7123_RptDataStruct.sFltArptPrNbr);

   //sprintf(sPrintFld, "%11.2lf", rpt_data.F7123_RptDataStruct.fFltImptValAmt);
   //PRINT_SETUP(86, sPrintFld);
   PRINT_SETUP(86, rpt_data.F7123_RptDataStruct.sFltImptValAmt);

   //sprintf(sPrintFld, "(%9.2f)", rpt_data.F7123_RptDataStruct.fNrevPmtAmt);
   //PRINT_SETUP(100, sPrintFld);
   PRINT_SETUP(100, rpt_data.F7123_RptDataStruct.sNrevPmtAmt);

   //sprintf(sPrintFld, "%11.2lf", rpt_data.F7123_RptDataStruct.fFltImptWageAmt);
   //PRINT_SETUP(114, sPrintFld);
   PRINT_SETUP(114, rpt_data.F7123_RptDataStruct.sFltImptWageAmt);


   rfm_ControlPrint(SINGLE_SPACE, print_line);

   //fTotImpWgs +=  rpt_data.F7123_RptDataStruct.fFltImptWageAmt;
   fTotImpWgs +=  atof(rpt_data.F7123_RptDataStruct.sFltImptWageAmt);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_4000_ProcessEndOfJob                     **
**                                                               **
** Description:     Format grand total line, print end of report **
**                  line, close input file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4000_ProcessEndOfJob()
{
   /*** Print trailer for final PPR ***/
   RFM_4100_PrintTrailerLines();

   cEndOfRpt = 'Y';
   RFM_5000_PageHeadings();
   /* Format end of report line */
   PRINT_SETUP(3,"END OF REPORT");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_4100_PrintTrailerLines                   **
**                                                               **
** Description:     Print the Trailer Lines for a notification   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4100_PrintTrailerLines()
{
   char sAmtFld[12];

   PRINT_SETUP(114,"___________");
   rfm_ControlPrint(DOUBLE_SPACE, print_line);
   PRINT_SETUP(86, "TOTAL IMPUTED WAGES (USD):");
   sprintf(sAmtFld, "%11.2lf", fTotImpWgs);
   PRINT_SETUP(114, sAmtFld);
   rfm_ControlPrint(SINGLE_SPACE, print_line);
}


/******************************************************************
**                                                               **
** Function Name:   RFM_5000_PageHeadings                        **
**                                                               **
** Description:     Format and print heading line                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_5000_PageHeadings()
{
char sNbrOfReportPages[4];  /* Number of report pages written */
 
   nRptPagesWritten++;
 
   /*** print standard headings 1, 2 and 3  ***/
   memcpy(print_line,std_heading_1,PAGE_WIDTH);
   sprintf(sNbrOfReportPages,"%3i",nRptPagesWritten);
   PRINT_SETUP(128,sNbrOfReportPages);
   rfm_PrintLine(NEW_PAGE,print_line);
   memcpy(print_line,std_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
   memcpy(print_line,std_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
  
   /* Print application headings if end of report indicator is no */
   if (cEndOfRpt == 'N')
   {
      /* print name                         */
      PRINT_SETUP(66,"TO:  ");
      PRINT_SETUP(71,rpt_data.F7123_RptDataStruct.sPprNm);
      rfm_PrintLine(DOUBLE_SPACE, print_line);

      /* print address line 1               */
      PRINT_SETUP(71,rpt_data.F7123_RptDataStruct.sPpr1Addr);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      /* print address line 2, if present   */
      if(   (strcmp(rpt_data.F7123_RptDataStruct.sPpr2Addr, NULL_STRING) != 0)
         || (strcmp(rpt_data.F7123_RptDataStruct.sPpr2Addr, " ") != 0))
      {
         PRINT_SETUP(71,rpt_data.F7123_RptDataStruct.sPpr2Addr);
         rfm_PrintLine(SINGLE_SPACE, print_line);
      }

      /* print city, state, and zip         */
      PRINT_SETUP(71,rpt_data.F7123_RptDataStruct.sPprCtyAddr);
      PRINT_SETUP(95,rpt_data.F7123_RptDataStruct.sPprStCd);
      PRINT_SETUP(99,rpt_data.F7123_RptDataStruct.sPprZipAddr);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      /* print country code                 */
      PRINT_SETUP(71,rpt_data.F7123_RptDataStruct.sPprCtryCd);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      /* print pprid and ppr name */
      PRINT_SETUP(1,"PPR ID:  ");
      PRINT_SETUP(10,rpt_data.F7123_RptDataStruct.sPprNbr);    
      PRINT_SETUP(21,"PPR NAME:  ");
      PRINT_SETUP(32,rpt_data.F7123_RptDataStruct.sPprNm);    
      rfm_PrintLine(DOUBLE_SPACE, print_line);

      /* print the 3 lines of verbage */
      memcpy(print_line,appl_heading_1,PAGE_WIDTH);
      rfm_PrintLine(DOUBLE_SPACE, print_line);
      memcpy(print_line,appl_heading_2,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
      memcpy(print_line,appl_heading_3,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
 
      /* Print the Column Headings */
      memcpy(print_line,appl_heading_4,PAGE_WIDTH);
      rfm_PrintLine(DOUBLE_SPACE, print_line);
      memcpy(print_line,appl_heading_5,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
      memcpy(print_line,appl_heading_6,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
      memcpy(print_line,appl_heading_7,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
 
   }
}

/******************************************************************
**                                                               **
** Function Name:   CenterPosition                               **
**                                                               **
** Description:     Calculates number of positions to move       **
**                  to position text in center of field          **
**                                                               **
** Arguments:       Length of field                              **
**                  Input character string                       **
**                                                               **
** Return Values:   Position to center character string          **
**                                                               **
**                                                               **
******************************************************************/

int CenterPosition(int nLength, char *sInput)
{
   int nNbr;      /* Position to center string */

   nNbr = (nLength - (int)strlen(sInput)) / 2;
   return nNbr;
}


