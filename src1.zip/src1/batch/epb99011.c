/**************************************************************************** 
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         ** 
** Sub-System :                                                            **
**                                                                         ** 
** Program Name:    EPB99011.c                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.c>                                           **
**                                                                         **
** Program Type:    Batch Report Format Module with zero control breaks    **
**                                                                         **
** Author :         LaShawnda Walker         		                   **
**                                                                         **
** Date Written:    July 16, 1999                                          **
**                                                                         **
** Description:     This program reads the sort records created by program **
**                  EPB99001 and formats the "MULTIPLE COMPANION" report.  **
**                                                                         **
** Revision Trail:                                                         ** 
**                                                                         ** 
** Date       Revised by         SIR #    Description                      ** 
** ----       ----------         -----    -----------                      ** 
**                                                                         ** 
**                                                                         ** 
****************************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "epb99011.h"
#include "bchrfmcd.h"

main()
{
   RFM_1000_InitializeFlds();
   while ((feof(stdin)) == 0)
      {
      RFM_3000_ProcessDetail();  
      }
   RFM_4000_ProcessEndOfJob();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1000_InitializeFlds                      **
**                                                               **
** Description:     Initialize fields, read initial record,      **
**                  zero accumulators                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1000_InitializeFlds()
{
   char   sCurrentDate[13];  /* current date in mm/dd/yy format */

   rfm_ReadNextRecord();
   
   /* Initialize totals */
   nRptPagesWritten = 0;
   
   /* No application accumulators */

   /* Get system date and time    */
   current = time((time_t *)0);
   strcpy(tu.t_str, ctime(&current));
   strftime(sCurrentDate,12,"%m/%d/%y",localtime(&current));

   tu.t_str[7] = tu.t_str[10]=tu.t_str[19]=tu.t_str[24]='\0';
 
   /* If report has an as of date, format the as of date here   */
   nCurrentLineCount = NEW_PAGE;
   memset(print_line,' ',PAGE_WIDTH);
   strcpy(sRequestId, input_area.rqst_id);

   /* Format and save standard headings */

   /* standard heading 1 */
   PRINT_SETUP(1,"CSR #:");
   PRINT_SETUP(11,"7985");
   PRINT_SETUP(56,STD_RPT_TITLE);
   PRINT_SETUP(115,"PAGE:");
   memcpy(std_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 2 */
   PRINT_SETUP(1,"REPORT:");
   PRINT_SETUP(11, "EPB99011");
   PRINT_SETUP(48, "MULTIPLE COMPANION SUMMARY");
   memcpy(std_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
 
   /* standard heading 3 */
   memset(&sFormatFld, LOW_VALUES, sizeof(sFormatFld));
   PRINT_SETUP(57, "AS OF ");
   PRINT_SETUP(63, sCurrentDate);
   memcpy(std_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 4 */
   memset(&sFormatFld, LOW_VALUES, sizeof(sFormatFld));
   PRINT_SETUP(17, "THE FOLLOWING IS A REPORT FOR MULTIPLE COMPANIONS AS OF ");
   PRINT_SETUP(73, sCurrentDate);
   memcpy(std_heading_4,print_line,PAGE_WIDTH); 
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 1 */
   PRINT_SETUP(17, "PPR NUMBER");
   PRINT_SETUP(31, "NON-REV NUMBER");
   PRINT_SETUP(49, "DATE ADDED");
   PRINT_SETUP(64, "HIRE DATE");
   memcpy(appl_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 2 */
   PRINT_SETUP(17, "__________");
   PRINT_SETUP(31, "______________");
   PRINT_SETUP(49, "__________");
   PRINT_SETUP(64, "_________");
   memcpy(appl_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3000_ProcessDetail                       **
**                                                               **
** Description:     Process detail line, read next record and    **
**                  determine if there was a control break       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3000_ProcessDetail()
{
    RFM_3100_ProcessReportRecord();
    rfm_ReadNextRecord();
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3100_ProcessReportRecord                 **
**                                                               **
** Description:     Format detail line, add amounts to control   **
**                  totals.                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3100_ProcessReportRecord()
{
   nLinesInGroup = DETAIL_LINE;

   /* Set end of report indicator to no */
   cEndOfRpt = 'N';
     
  if (nCurrentLineCount > 56)
     {
      RFM_5000_PageHeadings();
     }   

  /* Print PPR information */   
  PRINT_SETUP(17, rpt_data.F9901_RptDataStruct.sPprNbr);
  PRINT_SETUP(31, rpt_data.F9901_RptDataStruct.sNrevNbr);
  PRINT_SETUP(49, rpt_data.F9901_RptDataStruct.sPassStsChgDt);
  PRINT_SETUP(64, rpt_data.F9901_RptDataStruct.sPprStrtDt);
  rfm_ControlPrint(SINGLE_SPACE, print_line); 
     
}

/******************************************************************
**                                                               **
** Function Name:   RFM_4000_ProcessEndOfJob                     **
**                                                               **
** Description:     Format grand total line, print end of report **
**                  line, close input file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4000_ProcessEndOfJob()
{

   /* Format end of report line */
   PRINT_SETUP(3,"END OF REPORT");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_5000_PageHeadings                        **
**                                                               **
** Description:     Format and print heading line                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_5000_PageHeadings()
{
   char sNbrOfReportPages[4];  /* Number of report pages written */
 
   nRptPagesWritten++;
 
   /*  Format first standard heading line */
   memcpy(print_line,std_heading_1,PAGE_WIDTH);
   sprintf(sNbrOfReportPages,"%3i",nRptPagesWritten);
   PRINT_SETUP(127,sNbrOfReportPages);
   rfm_PrintLine(NEW_PAGE,print_line);
 
   /*  Format second standard heading line */
   memcpy(print_line,std_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   /*  Format third standard heading line */
   memcpy(print_line,std_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);

   /* Format 4th heading */
   memset(print_line,' ',PAGE_WIDTH);
   rfm_PrintLine(TRIPLE_SPACE, print_line);
   memcpy(print_line,std_heading_4,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);

   /*  Format application headings */
    memcpy(print_line,appl_heading_1,PAGE_WIDTH);
    rfm_PrintLine(TRIPLE_SPACE, print_line);

    memcpy(print_line,appl_heading_2,PAGE_WIDTH);
    rfm_PrintLine(SINGLE_SPACE, print_line);

    memset(print_line,' ',PAGE_WIDTH);
    rfm_PrintLine(SINGLE_SPACE, print_line);

}
