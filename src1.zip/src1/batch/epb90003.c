/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB90003.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Written:    May 24, 1995                                           **
**                                                                         **
** Description:     Database driven programs use, as their primary input,  **
**                  a Sybase database.  This report reads from  the        **
**                  Pass System and extracts information on pass usage     **
**                  from which a non-revenue passenger has accrued a       **
**                  flight penalty fee.                                    **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 11/21/96    FFA                       Removed datediff processing from  **
**                                       svc 2746, pass nrev typ cd to rpt **
****************************************************************************/
#include "epb90003.h"

main()
{
   BCH_Init("EPB90003", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short   nRptIndex,                 /* Report index */
	       nReqRptInd1 = FALSE;       /* Required report #1 indicator */

   char *pEndDate;                    /* Pointer to report end date */

   /**** Initialize RSAM Save fields with space ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sNrevNbr, SPACE_CHAR);
   RS.lPenaltyCnt = 0;

   /**** Assign report beginning and ending dates to variables ****/
   pEndDate = (char *) getenv("DATE2");
   strcpy(RS.sFltFeeEndDt, pEndDate);

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{

   /*** First, calculate the start date to be used when getting the flight penalties ***/
   /*** This date will be 6 months (182 days) from end date passed from script ***/
   memset(&R04403.R04403_appl_area, LOW_VALUES, sizeof(_R04403_APPL_AREA));
   memset(&A04403.A04403_appl_area, LOW_VALUES, sizeof(_A04403_APPL_AREA));
   strcpy(R04403.R04403_appl_area.sFltFeeBegDt, RS.sFltFeeEndDt);   
   R04403.R04403_appl_area.nPassSeqNbr = -182;

   /****** Execute service to get beginning date   ***/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04403,&A04403,SERVICE_ID_04403,1,sizeof(_R04403_APPL_AREA));
   
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
	     break;

      default:
      BCH_FormatMessage(1,TXT_SVC_UNSUCC);
      BCH_FormatMessage(2,TXT_SVC, "FYS04403");
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /*** Next, begin processing the flight penalties that fall within the date range ***/
   /****** Initialize 02746 Request and Answer Blocks *****/
   memset(&R02746.R02746_appl_area, LOW_VALUES, sizeof(_R02746_APPL_AREA));
   memset(&A02746.A02746_appl_area, LOW_VALUES, sizeof(_A02746_APPL_AREA));
   R02746.R02746_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   strcpy(R02746.R02746_appl_area.sPprNbr, RS.sPprNbr);
   strcpy(R02746.R02746_appl_area.sNrevNbr, RS.sNrevNbr);
   strcpy(R02746.R02746_appl_area.sFltDprtDt, A04403.A04403_appl_area.sPprStrtDt);

   /****** Execute service to get flight penalty data from the Charges table, and the ppr and nrev ***/
   /****** name form the PPR and Nrev tables    ***/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02746,&A02746,SERVICE_ID_02746,1,sizeof(_R02746_APPL_AREA));

   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
	     break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02746");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows ****/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      DPM_2500_ProcessRows();

      R02746.R02746_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A02746,LOW_VALUES,sizeof(_A02746));

      /**** Execute service to obtain next flight penalty *****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02746,&A02746,SERVICE_ID_02746,1,sizeof(_R02746_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02746");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
 
      }  
   }

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   /**** Generate a report extract record ****/
   DPM_5010_Generate(); 
   RS.lPenaltyCnt++;

   /**** Fill restart structure with restart key variables ****/
   strcpy(RS.sPprNbr, A02746.A02746_appl_area.sPprNbr);
   strcpy(RS.sNrevNbr, A02746.A02746_appl_area.sNrevNbr);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5010_Generate                            **
**                                                               **
** Description:     Write report records for report              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_5010_Generate()
{
   short     nRptIndex;                    /* Index into the report control table */
  
   /**** Initialize report sort and data copybooks ****/
   memset(&EPRF9003.F9003_RptDataStruct, LOW_VALUES, sizeof(_F9003_RPTDATASTRUCT));
   memset(&EPRS9003.S9003_RptDataStruct, LOW_VALUES, sizeof(_S9003_RPTDATASTRUCT));

   /**** Format report fields in sort and data layouts ****/
   strcpy(EPRF9003.F9003_RptDataStruct.sPprNbr, A02746.A02746_appl_area.sPprNbr);
   strcpy(EPRF9003.F9003_RptDataStruct.sNrevNbr, A02746.A02746_appl_area.sNrevNbr);
   strcpy(EPRF9003.F9003_RptDataStruct.sPprNm, A02746.A02746_appl_area.sPprNm);
   strcpy(EPRF9003.F9003_RptDataStruct.sNrevNm, A02746.A02746_appl_area.sNrevNm);
   strcpy(EPRF9003.F9003_RptDataStruct.sFltDprtDt, 
          UTL_ConvertDate(A02746.A02746_appl_area.sFltDprtDt,CNV_DB_TO_DD_MMM_YYYY));
   strcpy(EPRF9003.F9003_RptDataStruct.sNrevTypCd, A02746.A02746_appl_area.sNrevTypCd);
   strcpy(EPRF9003.F9003_RptDataStruct.sSvcChrgDs, A02746.A02746_appl_area.sSvcChrgDs);
   //EPRF9003.F9003_RptDataStruct.dCostChrgAmt = A02746.A02746_appl_area.dCostChrgAmt;
   sprintf(EPRF9003.F9003_RptDataStruct.sCostChrgAmt, "%7.2f", A02746.A02746_appl_area.dCostChrgAmt);
   EPRF9003.F9003_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS9003.S9003_RptDataStruct.sPprNbr, A02746.A02746_appl_area.sPprNbr);
   strcpy(EPRS9003.S9003_RptDataStruct.sNrevNbr, A02746.A02746_appl_area.sNrevNbr);
   strcpy(EPRS9003.S9003_RptDataStruct.sPassRptSortDt, 
          UTL_ConvertDate(A02746.A02746_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD));
 
   /**** Write report record ****/
   BCH_WriteRptRec("EPB90013",&EPRS9003, sizeof(EPRS9003), &EPRF9003, sizeof(EPRF9003));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   sprintf(sErrorMessage, "Total Nbr of penalties processed = %d",
                           RS.lPenaltyCnt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
