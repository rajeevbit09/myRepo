/*######################################################################*/
/*                                                                      */
/* Copyright [2001] Delta Air Lines, Inc./Delta Technology, Inc.   */
/*                       All Rights Reserved                            */
/*               Access, Modification, or Use Prohibited                */
/* Without Express Permission of Delta Air Lines or Delta Technology.   */
/*                                                                      */
/*######################################################################*/
/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB91001.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Faith Ammons                                           **
**                                                                         **
** Date Written:    11/01/95                                               **
**                                                                         **
** Description:     This program runs nightly to create the DMSS Interface **
**                  file.  This file contains accounting entries for       **
**                  employee pass charges and their corresponding taxes.   **
**                  The program reads the Charges table to get all items   **
**                  whose accounting effective date = 12/31/1899, indicating*
**                  that is has not been processed.  For each item, the    **
**                  program builds a debit and credit accounting entry for **
**                  the charge. Next the program calculates the domestic   **  
**                  tax on the sum of all of the revenues charges for the  **
**                  day.  Next, the program calcualtes the Canadian tax by **
**                  determining the percentage of Canadian flight legs flown*
**                  for the day,and then  multiplying that percentage by the*
**                  total taxable abount to get the amount subject to      **
**                  to Canadian tax.  Finally, on the monthly cycle, the   **
**                  program reads the Imputed trip Table to get all items  **
**                  whose accounting effective date = 12/31/1899, indicating*
**                  that is has not been processed.  For each item, the    **
**                  program builds a debit and credit accounting entry for **
**                  the imputed wage amount.                               **  
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 1/96        FFA               1) changed statid to GLRV instead of EPRV **
**                                  for revenues.                          **
**                               2) Changed activity and resource ID to be **
**                                  REVENUE and REVX for revenues only, all**
**                                  others contains '#''s in the activity  **
**                                  and resource id.                       **
**                               3)Changed product id to be EPAS for revenues
**                                 only, roduct id is blank for all other. **
**                               4) changed the voucher number to be left- **
**                                  justified followed by blanks instead of**
**                                  leading 0 numerics.                    **
** 2/96        FFA               5) Changed calculation of Canadian Tax to **
**                                  and 4 canadian tax dollars per Canadian**
**                                  flight leg, instead of a flat 4 Canadian*
**                                  dollars.                               **
**                               6) All entries will have voucher gj165    **
**                                  instead of multiple voucher numbers.   **
**                                                                         **
** 4/17/96      JFB              7) Added condition to process imputed wage**
**                                  only if imputed wage amount is not zero**
**                                                                         **
** 4/19/96     FFA               8) Put the city incurring certain inter-  **   
**                                  national charges in the dtl record.    **
**                                  Changed REVX to be MSRV.               **
**                                                                         **
** 11/5/96      FFA              9) Changed service 03934 to be a cursor on**
**                                  flt leg/imp flt leg tables to get the  **
**                                  orig/dest city and then let the program**
**                                  determine if its a canadian city.  This**
**                                  is to prevent a timeout problem.       **
**                                  removed svc 03969.                     **
**                                                                         **
** 5/27/97     LAS              10) Added condition to check to see if     **
**                                  charge code is pass card related so    **
**                                  that Emp A/R account nbr 127100002     **
**                                  is used.                               **
**                                                                         **
** 8/15/97     SKM              11) For TQ Employees' charge records send  **
**                                  127100008 as a debit GL account number **
**                                  to DMSS interface file.                **
**                                                                         **
** 10/16/97    LAS              12) For TQ and WS employee charge records  **
**                                  send 127100008 as a debit GL account   **
**                                  number and for all other charges       **
**                                  including pass card charges send to    **
**                                  127100003.                             **
**                                                                         **
** 4/22/98     SKM              13) Added processing for DSS Employee      **
**                                  charge records. Send these charge      **
**                                  records to 127100008 debit GL account  **
**                                  number.                                **
**                                                                         **
** 8/27/98     SKM              14) Send records for inactive DL, DT, DSS  **
**                                  and WSP during monthly processing      **
**                                  instead of daily.                      **
**                                  When sending charge records to DMSS,   **
**                                  use account number stored in pass      **
**                                  group table for active & inactive DL   **
**                                  employees. For DT, DSS and WSP, use    **
**                                  account number 127000794.              **
**                                                                         **
** 10/8/98     BBE              15) Changed pass card charges and reissued **
**                                  certificate charges to be sent to      **
**                                  127100002.                             **
**                                                                         **
** 5/3/99      LAS              16) Added a check for spaces when looking  **
**                                  at the intertax number to determine    **
**                                  account numbers for domestic and       **
**                                  German imputed charges.                **
**                                                                         **
** 11/17/99    LAS              17) Added code to check for 'AS' source    **
**                                  code for ASA employees.                **
**                                                                         **
** 9/04/01     EJS              18) Send charge records for ComAir empls   **
**                                   to account number 127000794.          **
**                                                                         **
** 3/10/03     LAS              19) Added code to check for 'SO' source.   **
**                                  Also changed so that all pass card and **
**                                  certificate charges go to 127100003    **
**                                                                         **
** 2/8/04      LAS              20) Added code to check for source code of **
**                                  'DH','RP' and 'OO'.                    **
**                                                                         **
** 2/17/05     EJS              21) change walker acct nbrs to SAP acct    **
**                                  nbrs                                   **
**                                                                         **
** 5/30/06     LAS              22) changed SAP account nbr 1270625 to     **
**                                  1275150 for pass card charges of DL    **
**                                  payroll employees.                     **
**                                                                         **
** 9/27/06     EJS              23) Added code to check for source code of **
**                                  'F8' and 'S5'.                         **
**                                                                         **
** 5/31/07     LAS              24) Added code to check for source code of **
**                                  'GQ' and 'XE'.                         **
**                                                                         **
** 1/08/08     LAS              25) Added code to check for source code of **
**                                  '9E'.                                  **
** 07/01/10    GLW              26) Add company code 0604 for Compass      **
**                                                                         **
** 01/01/11    GLW              27) Change Compass processing to DCI       **
**                                  processing Compass sold to TransState  **
**                                                                         **
** 11/29/11    MLL              28) Added code for G7-GoJet                **                  
**                                                                         **
** 12/19/12    BBE              29) Added code for PJ-Delta Private Jet    **
** 02/26/2013  GLW              30) Added code for Comair employees - 60   **
**                                  employee numbers will produce a invoice**
**                                  and will go to SAP with account number **
**                                  1275150 and MN employee numbers will   **
**                                  with pass_grp_cd 'CW' will also go to  **
**                                  SAP with account number 1275150        **
** 08/06/2013 GLW               31) Added Code to process GSAs as a DCI    **
**                                  and send bill to Tim Lotter            **
** 01/03/2014 GLW               32) Add company code 0116 for MLT and      **
**                                  change account number to 1275150       **
**                                  MLT to be processed in TZ              **
****************************************************************************/

#include "epb91001.h"
#include "stdio.h"

main()
{
   BCH_Init("EPB91001", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}


void writetologX(char x[], char y[])
{
   FILE *fp = fopen("GWlog.txt","a");
   fprintf(fp,"%s%s\n",x,y);
   fclose(fp);
}

 

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{
   int i, j;
   char *pCycleType;   /* point to cycle from script   */

 /*** Initialize fields          ***/
   RS.EPBF020_record_cnt = 0;
   RS.EPBF020_debit_amt = 0.0;
   RS.EPBF020_credit_amt = 0.0;
   RS.dTotalRevChrgAmt = 0.0; 
   RS.cTaxInd = NO_CHAR;
   strcpy(RS.sPprNbr, "         ");
   strcpy(RS.sImptdPprNbr, "         ");
   strcpy(sSavePprNbr, "         ");
   cEndOfItems = NO_CHAR;

 /***  Get cycle from script ***/
   pCycleType = (char *) getenv("CYCLES");
   strcpy(RS.sCycleId, pCycleType);

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");


 /**** NOTE: BCH_GetCurrentDate() will give current date and time in many
	     formats.  (including Sort, Display, and Timestamp)  ****/


   /*** remove slashes from current CCYY/MM/YY to create the header date in CCYYMMDD format ***/
   strncpy(sCreateDate, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sCreateDate));
     
   /***  remove colons from current HH:MM:SS to create the header time in HHMMSS format ***/
   strncpy(sCreateTime, UTL_ConvertDate(sCurrentTsDt, CNV_DB_TO_HHMMSS_ONLY),
           sizeof(sCreateTime));
   // This module needs an extra zero on the end of the time
   strcat(sCreateTime, "0");

    /*********** Call RSAM to open for output the DMSS Interface file ************/
   RS.EPBF020 = BCH_Open("EPBF020", BCH_FILE_WRITE);

   if (RS.EPBF020 == BCH_FAIL)
   {
       BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
       BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF020");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */
   nPassGrpCnt = 0;

   /*** First, go get all of the Pass Group codes and debit account nbrs and store in array ***/
   memset(&R03970.R03970_appl_area,LOW_VALUES, sizeof(R03970.R03970_appl_area));
   memset(&A03970,LOW_VALUES,sizeof(A03970));
   R03970.R03970_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03970,&A03970,SERVICE_ID_03970,1,sizeof(R03970.R03970_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03970");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {   
      /*** store pass group code and acct nbr in array   ***/
      strcpy(pass_group[nPassGrpCnt].sPassGrpCd, A03970.A03970_appl_area.sPassGrpCd);
      strcpy(pass_group[nPassGrpCnt].sAcctNbr, A03970.A03970_appl_area.sFltFeeAcctNbr);
      nPassGrpCnt++;

      /*** go get next pass Group information**/
      R03970.R03970_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A03970,LOW_VALUES,sizeof(A03970));
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03970,&A03970,SERVICE_ID_03970,1,sizeof(R03970.R03970_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03970");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   /****** next, begin processing charges items *****/
   memset(&R02753.R02753_appl_area,LOW_VALUES, sizeof(R02753.R02753_appl_area));
   memset(&A02753,LOW_VALUES,sizeof(A02753));
   strcpy(R02753.R02753_appl_area.sPprNbr, RS.sPprNbr);
   /** writetologX("PPR Nbr. before calling service",R02753.R02753_appl_area.sPprNbr); **/
   R02753.R02753_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to retrieve first charges item whose acct effective date = 12/31/1899****/
   /****** and its associated ppr item                                                         *****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02753,&A02753,SERVICE_ID_02753,1,sizeof(R02753.R02753_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         strcpy(sSavePprNbr, A02753.A02753_appl_area.sPprNbr); 
         break;

         case ARC_ROW_NOT_FOUND: 
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02753");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows ****/

   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {
         /* commit after all items for 1 PPR has been processed */
         if(strcmp(A02753.A02753_appl_area.sPprNbr, sSavePprNbr) != 0)
         {
            DPM_4920_ProcessLUW();
            strcpy(sSavePprNbr, A02753.A02753_appl_area.sPprNbr); 
         }
      DPM_2500_ProcessRows();
      strcpy(RS.sPprNbr, A02753.A02753_appl_area.sPprNbr);
      /**** after processing row, get the next charges item and associated ppr item   ***/
      R02753.R02753_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A02753,LOW_VALUES,sizeof(A02753));

      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02753,&A02753,SERVICE_ID_02753,1,sizeof(R02753.R02753_appl_area));

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02753");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
         }  
      }

   cEndOfItems = YES_CHAR;
   DPM_4920_ProcessLUW(); 

   /*** Next, calculate domestic and Canadian taxes ***/  
   if (RS.cTaxInd == NO_CHAR)  /*** make sure taxes havent already been processed - for restart purposes ***/
   {
      if (RS.dTotalRevChrgAmt > 0.0) /* If charges were processed, calculate taxes */
         DPM_3000_ProcessTaxes();
      RS.cTaxInd = YES_CHAR;
   }

   /*** Finally,  process Imputed Trip items if this is a monthly cycle ***/
   if (strcmp(RS.sCycleId, MONTHLY) == 0) 
      DPM_3500_ProcessImputedWages();

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();

   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessRows()
{
   short     nSvcRtnCd;      /* Service return code */
   int       i = 0;
   cPassGrpFound = NO_CHAR;

   strcpy(sSaveEmpCo, "0100");
   strcpy(sSaveFltCo, "0100");
   
 /***********************************************************************
 **   remove check for NW so that all charges are 0100
 ************************************************************************
 ** Check othr_empt_cd to see if employee is former NW and GEAC paid **
 **********************************************************************
 **if (strcmp(A02753.A02753_appl_area.sOthrEmptCd, "NW") == 0) 
 **   strcpy(sSaveEmpCo, "0600");
 **   else
 **   strcpy(sSaveEmpCo, "0100");
 *********************************************************************
 ** Check last 2 digits of flight fee account number if NW flight   **
 *********************************************************************
 **if (strcmp(A02753.A02753_appl_area.sFltFeeAcctNbr+7, "NW", 2) == 0)
 **   strcpy(sSaveFltCo, "0600");
 **   else
 **   strcpy(sSaveFltCo, "0100");
 **
 **if (strcmp(A02753.A02753_appl_area.sFltNbr+4, "N", 1) == 0)
 **   strcpy(sSaveFltCo, "0600");
 ************************************************************************/

 /*****************************************************************************
 ** Check othr_empt_cd to see if employee is Compass employee,TesserAct paid **
 *****************************************************************************/
    if (strcmp(A02753.A02753_appl_area.sOthrEmptCd, "CP") == 0)
        strcpy(sSaveEmpCo, "0100");
        else
        strcpy(sSaveEmpCo, "0100");

 /*****************************************************************************
 ** Check othr_empt_cd to see if employee is MLT employee and TesserAct paid **
 *****************************************************************************/
   if (strcmp(A02753.A02753_appl_area.sOthrEmptCd, "ML") == 0)
       strcpy(sSaveEmpCo, "0116");

     
   /*********************************************************************/
   /*** Determine if the ppr is one that is on Delta's payroll        ***/
   /*********************************************************************/
   if ((strcmp(A02753.A02753_appl_area.sPassGrpCd, ACTIVE_DL)      == 0 ||
        strcmp(A02753.A02753_appl_area.sPassGrpCd, ACTIVE_DL_WK)   == 0 ||
        strcmp(A02753.A02753_appl_area.sPassGrpCd, ACTIVE_DL_MRD)  == 0 ||
        strcmp(A02753.A02753_appl_area.sPassGrpCd, RDYRSV_MARRIED) == 0 ||
        strcmp(A02753.A02753_appl_area.sPassGrpCd, RDYRSV_SINGLE) ==  0 ||
        strcmp(A02753.A02753_appl_area.sPassGrpCd, RDYRSV_SINGLE_WK) ==  0 ||
	strcmp(A02753.A02753_appl_area.sPassGrpCd, COOPINT_MARRIED) == 0 ||
	strcmp(A02753.A02753_appl_area.sPassGrpCd, COOPINT_SINGLE) ==  0 ||
	strcmp(A02753.A02753_appl_area.sPassGrpCd, COOPINT_SINGLE_WK) ==  0 ||
        strcmp(A02753.A02753_appl_area.sPassGrpCd, TEMPDL_MARRIED) == 0 ||
        strcmp(A02753.A02753_appl_area.sPassGrpCd, TEMPDL_SINGLE)  == 0 ||
        strcmp(A02753.A02753_appl_area.sPassGrpCd, TEMPDL_SINGLE_WK) == 0) &&
       (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "TQ") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "WS") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "DS") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "AS") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "OH") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "SO") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "CA") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "DH") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "RP") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "F8") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "S5") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "OO") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "GQ") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "XE") != 0 &&
	strcmp(A02753.A02753_appl_area.sNrevSrcCd, "XJ") != 0 &&
	strcmp(A02753.A02753_appl_area.sNrevSrcCd, "RS") != 0 &&
	strcmp(A02753.A02753_appl_area.sNrevSrcCd, "CP") != 0 &&
	strcmp(A02753.A02753_appl_area.sNrevSrcCd, "G7") != 0 &&
	strcmp(A02753.A02753_appl_area.sNrevSrcCd, "PJ") != 0 &&
        strcmp(A02753.A02753_appl_area.sNrevSrcCd, "9E") != 0 ))
       cDLPayrollInd = YES_CHAR;
   else
       cDLPayrollInd = NO_CHAR;

   if (strncmp(sSavePprNbr, "60", 2) == 0)
      cDLPayrollInd = YES_CHAR;

   if (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "RS") == 0)
      cDLPayrollInd = YES_CHAR;
    
   /** Shridev Makim (8/27/98):                                          **/
   /** Process charge records for inactive DL, DT, DSS, WSP, ASA, Comair **/
   /** and Song employees during monthly processing only.                **/

   if (strcmp(RS.sCycleId, MONTHLY) == 0 || cDLPayrollInd == YES_CHAR ||
       strcmp(RS.sCycleId, BIWEEKLY) ==0 )
   {

      /*** First, get the debit account number and description for the pass group from the array    ***/
      while (i < nPassGrpCnt)
      {
         if (strcmp(A02753.A02753_appl_area.sPassGrpCd, pass_group[i].sPassGrpCd) == 0)
         {
            strcpy(sSaveDebitAcctNbr, pass_group[i].sAcctNbr);
            cPassGrpFound = YES_CHAR;
            break;
         }
         i++;
      }
  /******************************************************************************
  ** ppr_nbr starting with MN but in pass_grp_cd 'CW' should be in 1275150 and **
  ** should produce an individual invoice for the employee 
  ** Checking sNrevSrcCd now -PPatnaik
  ******************************************************************************/
      if ((strcmp(A02753.A02753_appl_area.sNrevSrcCd, "MN") == 0) &&
	  strcmp(A02753.A02753_appl_area.sPassGrpCd, "CW") == 0)
	  strcpy(sSaveDebitAcctNbr, "1275150");
  /***********************************************************************************
   ** ppr_nbr starting with MN but in pass_grp_cd 'GA' should be in 1270625 and will**
   ** go on report for GSA to be processed for payment from commission              **
   ***********************************************************************************/
      if (strcmp(A02753.A02753_appl_area.sPassGrpCd, "GA") == 0)
	  strcpy(sSaveDebitAcctNbr, "1270625");
 /********************************************************************************
  ** Check othr_empt_cd to see if employee is Compass employee,TesserAct paid   **
  ** should have AcctNbr "1275150" even though they are pass group "CB" or "CW" **
  ********************************************************************************
       if (strcmp(A02753.A02753_appl_area.sOthrEmptCd, "CP") == 0 &&
	   strcmp(sSaveDebitAcctNbr, "1270625") == 0)
	   strcpy(sSaveDebitAcctNbr, "1275150");
  ********************************************************************************
  ** Compass sold to TransState Holding and should be processed as a DCI no     **
  ** longer a need to for SAP account number to 1275150       12/04/201         **
  ********************************************************************************/

    
      /*** If the PPR's pass group isnt valid, send an error message to the msg log ***/
      if (cPassGrpFound == NO_CHAR)
      {
         BCH_FormatMessage(1,TXT_MISSING_PASS_GRP);
         BCH_FormatMessage(2,TXT_PASS_GROUP, A02753.A02753_appl_area.sPassGrpCd);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2500_ProcessRows");
      }


      /*** If the charge is for pass cards or certificates, send to employee AR's pass card 
                   account ***/
      if (cPassGrpFound == YES_CHAR)  
      {    
       
      /***  THE FOLLOWING IS COMMMENTED OUT TO LOOK AT ALL RECORDS IN CASE THE ACCOUNT NUMBER IS 
            CHANGED IN THE FUTURE FROM 127100003.  
                if (((strcmp(sSaveDebitAcctNbr, "127100003") ==0))
                   &&
		   new sap acct nbr for 127100003 is 1270625
       ***/

           if  ((strcmp(A02753.A02753_appl_area.sSvcChrgCd, PASSCARD_CHARGE) == 0)  ||
               (strcmp(A02753.A02753_appl_area.sSvcChrgCd, LOSTCARD1_CHARGE) == 0) ||
               (strcmp(A02753.A02753_appl_area.sSvcChrgCd, LOSTCARD2_CHARGE) == 0) ||
               (strcmp(A02753.A02753_appl_area.sSvcChrgCd, LOSTCARD3_CHARGE) == 0) ||
               (strcmp(A02753.A02753_appl_area.sSvcChrgCd, REISSUE_CERT_CHARGE) == 0))
            {    
                strcpy(sSaveDebitAcctNbr, "1275150"); 
            }          
      }

      /*** Added by Shridev Makim, 8/15/97                                   ***/
      /*** If the PPR's pass group is valid and if he is TQ employee, assign ***/
      /*** 127100008 as a debit GL account number. sap nbr is 1275170        ***/
      /***                                                                   ***/
      /*** Modified by L. Scott, 10/16/97                                    ***/
      /*** Include WS employee when assigning 127100008 debit GL account     ***/
      /*** number, otherwise all other charges should go to 127100003.       ***/
      /***                                                                   ***/
      /*** Modified by Shridev Makim, 4/22/98                                ***/
      /*** Send DSS Employee charge records to 127100008 debit GL account    ***/
      /*** number also.                                                      ***/
      /***                                                                   ***/
      /*** Modified by Shridev Makim, 8/19/98                                ***/
      /*** Send DT, DSS, WSP and ASA records to 127000794 debit GL account number.***/
      /***  sap nbr is 1270625                                               ***/

      if (cPassGrpFound == YES_CHAR)
      {
      /**if((strcmp(A02753.A02753_appl_area.sNrevSrcCd, "TQ") == 0) ||     ***/
         if((strcmp(A02753.A02753_appl_area.sNrevSrcCd, "WS") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "DS") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "AS") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "OH") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "SO") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "CA") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "DH") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "RP") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "F8") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "S5") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "OO") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "GQ") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "XE") == 0) ||
	    (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "XJ") == 0) ||
	    (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "RS") == 0) ||
	    (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "CP") == 0) ||
	    (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "G7") == 0) ||
	    (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "PJ") == 0) ||
            (strcmp(A02753.A02753_appl_area.sNrevSrcCd, "9E") == 0))
             strcpy(sSaveDebitAcctNbr, "1270625"); 
      }
      if (strncmp(sSavePprNbr, "60", 2) == 0)
	 strcpy(sSaveDebitAcctNbr, "1275150");

        /** Checking sNrevSrcCd now -PPatnaik **/
	  if ((strcmp(A02753.A02753_appl_area.sNrevSrcCd, "MN") == 0) &&
	strcmp(A02753.A02753_appl_area.sPassGrpCd, "CW") == 0)
	strcpy(sSaveDebitAcctNbr, "1275150");

      if (cPassGrpFound == YES_CHAR)
      {
         strcpy(sSaveCreditAcctNbr, A02753.A02753_appl_area.sFltFeeAcctNbr, 7);
         DPM_2600_CreateDMSSEntries();

      
         /*** Next, update the charge items to show that it has been processed ***/
         /*** set the acct eff date = today for this charge item.              ***/

         memset(&R04626.R04626_appl_area,LOW_VALUES, sizeof(R04626.R04626_appl_area));
         memset(&A04626,LOW_VALUES,sizeof(A04626));
         R04626.R04626_appl_area.lSeqID = A02753.A02753_appl_area.lSeqID;
         strcpy(R04626.R04626_appl_area.sFltAcctEffDt, sCurrentTsDt);
         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04626,&A04626,SERVICE_ID_04626,1,sizeof(&R04626));

         /****** Service Return Code Processing  ****/
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;
      
               default:
                  BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                  BCH_FormatMessage(2,TXT_SVC, "FYS04626");
                  BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
         }
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2600_CreateDMSSEntries                   **
**                                                               **
** Description:     This function creates the DMSS debit and     **
**                  credit entries for the items from the Charges**
**                  Table.                                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2600_CreateDMSSEntries()
{
   char sTemp1ChrgAmt[17];
   char sTemp2ChrgAmt[16];
   short     nSvcRtnCd;      /* Service return code */

   strcpy(sExpActy, "        ");
   strcpy(sRsrcId, "    ");
   strcpy(sLocId1, "    ");
   strcpy(sLocId2, "    ");
   strcpy(sFltNbr, FLTNBR0);
   memset(&sSaveAcctDs, LOW_VALUES, sizeof(sSaveAcctDs));

   strcpy(sDprtDt, A02753.A02753_appl_area.sFltDprtDt);
   strcpy(sPprNbr, A02753.A02753_appl_area.sPprNbr);
   strcpy(sNrevNbr, A02753.A02753_appl_area.sNrevNbr);
 
   /*** remove the period from the charge amount and store as a string ***/
   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%016.2f", A02753.A02753_appl_area.dCostChrgAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,13);
   memcpy(sTemp2ChrgAmt+13, sTemp1ChrgAmt+14, 2);
   strcpy(sCharChrgAmt, sTemp2ChrgAmt);

   /***  format the remaining debit entry fields   ***/
   cDbtCrdInd = DEBIT;
   strcpy(sStatId, ASSET);
   strcpy(sSaveAcctNbr, sSaveDebitAcctNbr);
   strcpy(sSaveCoCd, sSaveEmpCo);

   /*** Continue Formatting debit entry and then write DMSS interface record ***/
   DPM_4000_WriteDMSSEntry();
 

   /*** next, format the remaining credit entry fields   ***/
   cDbtCrdInd = CREDIT;
   strcpy(sSaveAcctNbr, sSaveCreditAcctNbr);
   strcpy(sSaveCoCd, sSaveFltCo);

   /*** If the charge is an international fee, this is a liabilty account ***/
   /*** otherwise, the credit goes to the revenue account                 ***/
   if (strcmp(A02753.A02753_appl_area.sSvcChrgCd, INTL_FEE) == 0)
      strcpy(sStatId, LIABILITY);
   else
   {
      strcpy(sStatId, REVENUE);
      RS.dTotalRevChrgAmt +=  A02753.A02753_appl_area.dCostChrgAmt;
   }

   /*** For activation fee and penalties the amount should follow the employee not the metal ***/
   if (strcmp(A02753.A02753_appl_area.sFltFeeAcctNbr, "4807865",7) == 0)
      strcpy(sSaveCoCd, sSaveEmpCo);

   /*** Continue formatting credit entry and then write DMSS interface record ***/
   DPM_4000_WriteDMSSEntry();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3000_ProcessTaxes                        **
**                                                               **
** Description:     This function calculates taxes for an entire **
**                  day of travel.                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3000_ProcessTaxes()
{
   char *pInput;             /* pointer to input date */
   time_t       lSeconds;              /** Flight date in seconds **/
   char         sString[4];            /** String for date components **/
   short     nSvcRtnCd;      /* Service return code */

   /*** Get the processing date from the script, this date is in the format ccyymmdd ***/
   pInput = (char *)getenv("DATE1");
   strcpy(RS.sInputDt, pInput);

   // Convert to Julian & subtract 2
   // Error if before Jan 2nd.  We're not sure why??? just because the old code had
   // a bug and we don't know the business rule to fix
   lRfrnDt = UTL_GetJulianFromDate(RS.sInputDt);
   if (lRfrnDt % 1000 < 2)
   {
       BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "Can't run before Jan 2nd");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_ProcessTaxes");
   }
   else
   {
       lRfrnDt -= 2;
   }
 
   /*** Initialize fields for interface record   ***/
   strcpy(sExpActy, "        ");
   strcpy(sRsrcId, "    ");
   strcpy(sLocId1, "    ");
   strcpy(sLocId2, "    ");
   strcpy(sFltNbr, FLTNBR0);
   strcpy(sDprtDt, sCreateDate);
   strcpy(sPprNbr, "         ");
   strcpy(sNrevNbr, "  ");
 
   /***  go calculate what the domestic tax should be for the day   ***/
   DPM_3100_ProcessDomesticTaxes();
 
   /***  Finally, go calculate what the Canadian tax should be for the day   ***/
   // No longer wish to process & create DMSS feed.  This account is inactive
   // DPM_3200_ProcessCanadianTaxes();

   /*** Show that the taxes have been processed, and thn commit the tax records   ***/
   RS.cTaxInd = YES_CHAR;
   DPM_4920_ProcessLUW();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_3100_ProcessDomesticTaxes                **
**                                                               **
** Description:     This function calculates Domestic Taxes      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3100_ProcessDomesticTaxes()
{
   char sTemp1ChrgAmt[17];
   char sTemp2ChrgAmt[16];
   short     nSvcRtnCd;      /* Service return code */

   dTotalTaxAmt = 0.0;

   /*** Multiply the total amount by 10% to get the total tax amount ***/
   /*** commented out July 20, 2009 per Rick Burden                  ***/
   /*** dTotalTaxAmt = RS.dTotalRevChrgAmt * DOM_TAXRATE;            ***/
 
   /*** remove the period from the total tax amount and store as a string ***/
   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%016.2f", dTotalTaxAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,13);
   memcpy(sTemp2ChrgAmt+13, sTemp1ChrgAmt+14, 2);
   strcpy(sCharChrgAmt, sTemp2ChrgAmt);

   /***  format the remaining debit entry fields   ***/
   cDbtCrdInd = DEBIT;
   strcpy(sStatId, REVENUE);
   strcpy(sSaveAcctNbr, REV_ACCTNBR);
   strcpy(sSaveAcctDs, DOMTAX_DB);

   /*** Continue formatting debit entry and then write DMSS interface record ***/
   DPM_4000_WriteDMSSEntry();

   /***  format the remaining credit entry fields   ***/
   cDbtCrdInd = CREDIT;
   strcpy(sStatId, LIABILITY);
   strcpy(sSaveAcctNbr, DOMTAX_ACCTNBR);
   strcpy(sSaveAcctDs, DOMTAX_CR);

   /*** Continue formatting credit entry and then write DMSS interface record ***/
   DPM_4000_WriteDMSSEntry();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3200_ProcessCanadianTaxes                **
**                                                               **
** Description:     This function calculates Canadians Taxes     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3200_ProcessCanadianTaxes()
{
   char    sTemp1ChrgAmt[17],
           sTemp2ChrgAmt[16];
   double  dTaxableRevAmt,
           dAmtToTax,
           dConvtdAmt;
   float   dPctCanFltLegs,
           lTotalFltLegs,
           lTotalCanFltLegs;
   short     nSvcRtnCd;      /* Service return code */

   dTaxableRevAmt = RS.dTotalRevChrgAmt - dTotalTaxAmt; /* Taxable revenue amt less dom tax amt */
   lTotalFltLegs = 0;
   lTotalCanFltLegs = 0;

   /*** First,convert 4 Canadian dollars to US dollars, which will be used later   ***/
   memset(&R03208.R03208_appl_area,LOW_VALUES, sizeof(R03208.R03208_appl_area));
   memset(&A03208,LOW_VALUES,sizeof(A03208));                                 
   strcpy(R03208.R03208_appl_area.sCurrSrcCd, CAN_CURR);
   strcpy(R03208.R03208_appl_area.sCurrDestCd, USD_CURR);           

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R03208,&A03208,SERVICE_ID_03208,1,sizeof(R03208.R03208_appl_area));    

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         if (A03208.A03208_appl_area.cCurrRatOperId == MULTIPLY)
            dConvtdAmt = A03208.A03208_appl_area.dPassExchgRatNbr * 4;    
         else
            dConvtdAmt = 4 / A03208.A03208_appl_area.dPassExchgRatNbr;    
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS03208");
         sprintf(sErrorMessage, "src currency = %s, dest currency = %s ",
                       R03208.R03208_appl_area.sCurrSrcCd,
                       R03208.R03208_appl_area.sCurrDestCd);             
         BCH_FormatMessage(3,TXT_XCHG_RT_RETRIEVE_ERR, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3200_ProcessCanadianTaxes");
   }

   /*** Next, Get the total number of flight legs for the day being processed ***/
   memset(&R03933.R03933_appl_area,LOW_VALUES, sizeof(R03933.R03933_appl_area));
   memset(&A03933,LOW_VALUES,sizeof(A03933));
   R03933.R03933_appl_area.lFltChrgRfrnDt = lRfrnDt;
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R03933,&A03933,SERVICE_ID_03933,1,sizeof(R03933.R03933_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         lTotalFltLegs = A03933.A03933_appl_area.lFltLegsFlnNbr;
         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS03933");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3200_ProcessCanadianTaxes");
   }  

   /*** Get the total number of imputed flight legs for the day being processed ***/
   memset(&R03968.R03968_appl_area,LOW_VALUES, sizeof(R03968.R03968_appl_area));
   memset(&A03968,LOW_VALUES,sizeof(A03968));
   R03968.R03968_appl_area.lFltChrgRfrnDt = lRfrnDt;
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R03968,&A03968,SERVICE_ID_03968,1,sizeof(R03968.R03968_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         lTotalFltLegs += A03968.A03968_appl_area.lFltLegsFlnNbr;  /* add total imputed to total cnt */
         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS03968");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3200_ProcessCanadianTaxes");
   }  

   /*** Next, Get the total number of Canadian flight legs for the day being processed ***/
   /*** Get first all flight leg for day being processed ***/
   memset(&R03934.R03934_appl_area,LOW_VALUES, sizeof(R03934.R03934_appl_area));
   memset(&A03934,LOW_VALUES,sizeof(A03934));
   R03934.R03934_appl_area.lFltChrgRfrnDt = lRfrnDt;
   R03934.R03934_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R03934,&A03934,SERVICE_ID_03934,1,sizeof(R03934.R03934_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS03934");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3200_ProcessCanadianTaxes");
   }  

   /*** begin processing the flight legs to determine if they are Canadian ***/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
      {
      /*** If either the orig city or dest city is canadian, add 1 to Canadian flt leg count ***/
      if (strcmp(A03934.A03934_appl_area.sFltOrigCtyId, "YEG") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltOrigCtyId, "YHZ") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltOrigCtyId, "YQB") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltOrigCtyId, "YQM") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltOrigCtyId, "YQR") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltOrigCtyId, "YUL") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltOrigCtyId, "YVR") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltOrigCtyId, "YYC") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltOrigCtyId, "YYZ") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltDestCtyId, "YEG") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltDestCtyId, "YHZ") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltDestCtyId, "YQB") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltDestCtyId, "YQM") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltDestCtyId, "YQR") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltDestCtyId, "YUL") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltDestCtyId, "YVR") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltDestCtyId, "YYC") == 0       ||
          strcmp(A03934.A03934_appl_area.sFltDestCtyId, "YYZ") == 0)
             lTotalCanFltLegs++;


      /*** Get next flight leg for day being processed ***/
      memset(&A03934,LOW_VALUES,sizeof(A03934));
      R03934.R03934_appl_area.cArchCursorOpTxt = FETCH_ROW;
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R03934,&A03934,SERVICE_ID_03934,1,sizeof(R03934.R03934_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03934");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3200_ProcessCanadianTaxes");
         }  
      }


   /*** if flight legs were found, calculate the Canadian tax ***/
   if (lTotalFltLegs != 0 && lTotalCanFltLegs != 0)
   {
      /*** 1st, determine the percentage of Canadian flight legs for the day ***/
      dPctCanFltLegs = lTotalCanFltLegs / lTotalFltLegs;

      /*** next, determine amount that is subject to Canadian Tax    ***/
      dAmtToTax = dPctCanFltLegs * dTaxableRevAmt;

      /*** Multiply the amount subject to Canadian tax by Canadian tax rate and then add the converted***/ 
      /*** 4 canadian dollars to get the total Canadian tax amount                                    ***/
      dTotalTaxAmt = (dAmtToTax * CAN_TAXRATE) + (dConvtdAmt * lTotalCanFltLegs);
 
      /*** remove the period from the total Canadian tax amount and store as a string ***/
      memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
      memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
      sprintf(sTemp1ChrgAmt, "%016.2f", dTotalTaxAmt);
      memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,13);
      memcpy(sTemp2ChrgAmt+13, sTemp1ChrgAmt+14, 2);
      strcpy(sCharChrgAmt, sTemp2ChrgAmt);

      /***  format the remaining debit entry fields   ***/
      cDbtCrdInd = DEBIT;
      strcpy(sStatId, REVENUE);
      strcpy(sSaveAcctNbr, REV_ACCTNBR);
      strcpy(sSaveAcctDs, DOMTAX_DB);

      /*** Continue formatting debit entry and then write DMSS interface record ***/
      DPM_4000_WriteDMSSEntry();

      /***  format the remaining credit entry fields   ***/
      cDbtCrdInd = CREDIT;
      strcpy(sStatId, LIABILITY);
      strcpy(sSaveAcctNbr, CANTAX_ACCTNBR);
      strcpy(sSaveAcctDs, CANTAX_CR);

      /*** Continue formatting credit entry and then write DMSS interface record ***/
      DPM_4000_WriteDMSSEntry();
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3500_ProcessImputedWages                 **
**                                                               **
** Description:     This function creates DMSS debit and credit  **
**                  entries for items from the Imputed Trip Table**
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3500_ProcessImputedWages()
{
   short     nSvcRtnCd;      /* Service return code */
   cEndOfItems = NO_CHAR;
   strcpy(sSavePprNbr, "         ");

   /****** Initialize request and answer block to  begin processing imputed trip items *****/
   memset(&R02751.R02751_appl_area,LOW_VALUES, sizeof(R02751.R02751_appl_area));
   memset(&A02751,LOW_VALUES,sizeof(A02751));
   strcpy(R02751.R02751_appl_area.sPprNbr, RS.sImptdPprNbr);
   R02751.R02751_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to retrieve first imputed trip item whose acct effective date = 12/31/1899****/
   /****** and its associated ppr information                                                  *****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02751,&A02751,SERVICE_ID_02751,1,sizeof(R02751.R02751_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         strcpy(sSavePprNbr, A02751.A02751_appl_area.sPprNbr);

         // Strip any trailing space, so an empty tax Number is NULL
         UTL_StripTrailingSpaces(A02751.A02751_appl_area.sPprInttxNbr);
         break;

         case ARC_ROW_NOT_FOUND: 
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_3500_ProcessImputedWages");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02751");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3500_ProcessImputedWages");
   }  

   /**** Process driving database rows ****/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      /* commit after all items for 1 PPR has been processed */
      if(strcmp(A02751.A02751_appl_area.sPprNbr, sSavePprNbr) != 0)
      {
         DPM_4920_ProcessLUW();
         strcpy(sSavePprNbr, A02751.A02751_appl_area.sPprNbr); 
      }

      /* process imputed wage only if imputed wage is not zero */
      if (A02751.A02751_appl_area.fFltImptWageAmt != 0.0)
         DPM_3600_ProcessImputedTrip();
      strcpy(RS.sImptdPprNbr, A02751.A02751_appl_area.sPprNbr);

      /**** after processing row, get the next imputed trip  item and associated ppr item   ***/
      R02751.R02751_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A02751,LOW_VALUES,sizeof(A02751));

      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02751,&A02751,SERVICE_ID_02751,1,sizeof(R02751.R02751_appl_area));

      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
             // Strip any trailing space, so an empty tax Number is NULL
             UTL_StripTrailingSpaces(A02751.A02751_appl_area.sPprInttxNbr);
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02751");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3500_ProcessImputedWages");
         }  
   }

   cEndOfItems = YES_CHAR;
   DPM_4920_ProcessLUW();

   /*** Finally, update all imputed trip items to show that they have been processed ***/
   /*** set the acct eff dt = today for all items with acct eff dt = 12/31/1899 ***/
   memset(&A02750,LOW_VALUES,sizeof(A02750));
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02750,&A02750,SERVICE_ID_02750,1,sizeof(&R02750));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02750");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3500_ProcessImputedWages");
   }

   DPM_4920_ProcessLUW();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3600_ProcessImputedTrip                  **
**                                                               **
** Description:     This function creates the DMSS debit and     **
**                  credit entries for the items from the Imputed**
**                  Trip Table.                                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3600_ProcessImputedTrip()
{
   char sTemp1ChrgAmt[17];
   char sTemp2ChrgAmt[16];
   short     nSvcRtnCd;      /* Service return code */

   strcpy(sExpActy, "        ");
   strcpy(sRsrcId, "    ");
   strcpy(sLocId1, "     ");
   strcpy(sLocId2, "     ");
   strcpy(sFltNbr, FLTNBR0);
   memset(&sSaveAcctDs, LOW_VALUES, sizeof(sSaveAcctDs));

   /***  Determine appropriate debit and credit account nbrs and voucher codes -   ***/
   /*** this information is different for domestic and German employees            ***/
   if (strcmp(A02751.A02751_appl_area.sPprInttxNbr, NULL_STRING) != 0)
   {
        strcpy(sSaveDebitAcctNbr, GRMIMP_DBACCT);
        strcpy(sSaveCreditAcctNbr, GRMIMP_CRACCT);
   }
   else
   {
        strcpy(sSaveDebitAcctNbr, DOMIMP_DBACCT);
        strcpy(sSaveCreditAcctNbr, DOMIMP_CRACCT);
   }
 
   strcpy(sDprtDt, A02751.A02751_appl_area.sFltDprtDt);
   strcpy(sPprNbr, A02751.A02751_appl_area.sPprNbr);
   strcpy(sNrevNbr, A02751.A02751_appl_area.sNrevNbr);
 
   /*** remove the period from the charge amount and store as a string ***/
   memset(sTemp1ChrgAmt, LOW_VALUES, sizeof(sTemp1ChrgAmt));
   memset(sTemp2ChrgAmt, LOW_VALUES, sizeof(sTemp2ChrgAmt));
   sprintf(sTemp1ChrgAmt, "%016.2f", A02751.A02751_appl_area.fFltImptWageAmt);
   memcpy(sTemp2ChrgAmt, sTemp1ChrgAmt,13);
   memcpy(sTemp2ChrgAmt+13, sTemp1ChrgAmt+14, 2);
   strcpy(sCharChrgAmt, sTemp2ChrgAmt);

   /***  format the remaining debit entry fields   ***/
   cDbtCrdInd = DEBIT;
   strcpy(sStatId, ASSET);
   strcpy(sSaveAcctNbr, sSaveDebitAcctNbr);
   strcpy(sSaveCoCd, sSaveEmpCo);

   /*** Continue formatting debit entry and then write DMSS interface record ***/
   DPM_4000_WriteDMSSEntry();
 
   /*** next, format the remaining credit entry fields   ***/
   cDbtCrdInd = CREDIT;
   strcpy(sStatId, ASSET);
   strcpy(sSaveAcctNbr, sSaveCreditAcctNbr);
   strcpy(sSaveCoCd, sSaveFltCo);
   /*** For activation fee and penalties the amount should follow the employee not the metal ***/
   if (strcmp(A02753.A02753_appl_area.sFltFeeAcctNbr, "4807865",7) == 0)  
	 strcpy(sSaveCoCd, sSaveEmpCo);

      
   /*** Continue formatting credit entry and then write DMSS interface record ***/
   DPM_4000_WriteDMSSEntry();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4000_WriteDMSSEntry                      **
**                                                               **
** Description:     This function finishes the formatting of the **
**                  DMSS Interface record and then writes it.    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_4000_WriteDMSSEntry()
{
   char sTempDate[27];

   memset(sTempDate, 0, sizeof(sTempDate));

   /*** Format the activity, resource id, and product id ***/
   if (strcmp(sStatId, REVENUE) == 0)
   {
      strcpy(sExpActy, ACTIVITY_REV);
      strcpy(sRsrcId, RESOURCE_REV);
      strcpy(sProdId, PRODUCT_ID);
   }
   else
   {
      strcpy(sExpActy, ACTIVITY_LB);
      strcpy(sRsrcId, RESOURCE_LB);
      strcpy(sProdId, "    ");
   }


   /*** for certain international fees, the perform by location will be the city that ***/
   /*** incurred the international fee, which is saved in the description of the charge ***/
   if (strcmp(sSaveAcctNbr, "7208150") == 0)  
     strncpy(sLocId1, A02753.A02753_appl_area.sSvcChrgDs, 5);

   // Conver the date
   strncpy(sTempDate, UTL_ConvertDate(sDprtDt, CNV_DB_TO_YYYYMMDD),
    sizeof(sTempDate));

   /*** initialize the record buffer area                                     ***/
   memset(&RS.EPBF020_buffer, LOW_VALUES, sizeof(RS.EPBF020_buffer));
   /***  Format the record buffer, and then write the record       ***/
   sprintf(RS.EPBF020_buffer, DMSS_DTL_FORMAT,
                              DTL_RECID,
                              cDbtCrdInd,
                              SOURCEID,
                              sStatId,
                              sTempDate, 
                              sCreateDate,
                              USD_CURR,
                              sSaveAcctDs,
                              sExpActy,
                              sRsrcId,
                              sSaveAcctNbr,
                              sLocId1,
                              sLocId2,
                              sFltNbr,
                              sSaveCoCd,
                              sProdId,
                              sPprNbr,
                              sNrevNbr,
                              VCHRNBR,
                              sCharChrgAmt);
   BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));

   /*** After writing record, add to totals   ***/
   RS.EPBF020_record_cnt++;
   
   /* convert character amount to double and then divide by 100 to get 2 decimal places  */
   /* this is done because the atof adds 2 0's to end of number.                         */
   if (cDbtCrdInd == DEBIT)
      RS.EPBF020_debit_amt += (atof(sCharChrgAmt) / 100);   
   else
      RS.EPBF020_credit_amt += (atof(sCharChrgAmt) / 100);   

}

/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void DPM_4920_ProcessLUW()
{
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     This function write the footer record, closes**
**                  the file and then ends the program.          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{
   char    sTemp1TtlAmt[15],
           sTempDbAmt[14],
           sTempCrAmt[14];

   /*** If the total debit amount does not = the total credit amount, send an error message and abort ***/
   if (RS.EPBF020_credit_amt != RS.EPBF020_debit_amt)
   {
      BCH_FormatMessage(1,TXT_CREDITS_NE_DEBITS);
      BCH_FormatMessage(3,TXT_DR_AMT_TTL, RS.EPBF020_debit_amt);
      BCH_FormatMessage(3,TXT_CR_AMT_TTL, RS.EPBF020_credit_amt);
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_9500_ProcessEndOfProgram");
   }

   /***  remove the period from the total debit amount and store as a string ***/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTempDbAmt, LOW_VALUES, sizeof(sTempDbAmt));
   sprintf(sTemp1TtlAmt, "%014.2f", RS.EPBF020_debit_amt);
   memcpy(sTempDbAmt, sTemp1TtlAmt,11);
   memcpy(sTempDbAmt+11, sTemp1TtlAmt+12, 2);

   /*** remove the period from the total credit amount and store as a string ***/
   memset(sTemp1TtlAmt, LOW_VALUES, sizeof(sTemp1TtlAmt));
   memset(sTempCrAmt, LOW_VALUES, sizeof(sTempCrAmt));
   sprintf(sTemp1TtlAmt, "%014.2f", RS.EPBF020_credit_amt);
   memcpy(sTempCrAmt, sTemp1TtlAmt,11);
   memcpy(sTempCrAmt+11, sTemp1TtlAmt+12, 2);

   /*** initialize the record buffer area                                     ***/
   memset(&RS.EPBF020_buffer, LOW_VALUES, sizeof(RS.EPBF020_buffer));

  /*** format the write buffer and then write out the DMSS footer record   ***/
   sprintf(RS.EPBF020_buffer, DMSS_FTR_FORMAT,
                              FTR_RECID,
                              sCreateDate,
                              sCreateTime,
                              sTempDbAmt,
                              sTempCrAmt,
                              RS.EPBF020_record_cnt);
   BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));

   /*** Close the output file    ***/
   BCH_Close(RS.EPBF020); 

   /*** send record count and amounts to message log   ***/
   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF020");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPBF020_record_cnt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF020");
   BCH_FormatMessage(2,TXT_DR_AMT_TTL, RS.EPBF020_debit_amt);
   BCH_FormatMessage(3,TXT_CR_AMT_TTL, RS.EPBF020_credit_amt);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");


}

