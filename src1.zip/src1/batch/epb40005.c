/*##########################################################################*/
/*                                                                          */
/* Copyright 2012 - Delta Air Lines, Inc.                                   */
/*                       All Rights Reserved                                */
/*               Access, Modification, or Use Prohibited                    */
/* Without Express Permission of Delta Air Lines                            */
/*                                                                          */
/*##########################################################################*/
/*                                                                         **
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    epb40005.c                                             **
**                                                                         **
** Program Type:    Transaction Driven Process Module                      **
**                                                                         **
** Author:          Duane Ellis                                            **
**                                                                         **
** Date Written:    Aug 2012                                               **
**                                                                         **
** Description:     Transaction driven process module to read an eNCI file **
**                  record by record.  The module will perform             **
**                  some action on each input record (e.g. update          **
**                  database table).                                       **
**                                                                         **
**                  This module performs the daily insert or update of     **
**                  eNCI certificates into the NRAP_CRTF table in the      **
**                  Pass System database. The eNCI Data is received daily  **
**                  via ftp from the eNCI group and contains certificate   **
**                  data, redepmtion codes, ticket data, and PPR info.     **
**                                                                         **
**                  This module reads in the ENCI file and loads or        **
**                  updates records in the NRAP_CRTF table.                **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by    Description                                    **
** ----       ----------    --------------------                           **
** 08/06/2012 Duane Ellis   Inital Program Creation                        **
** 05/02/2013 Duane Ellis   Code added to handle and Ignore PPR 000000000  **
**                                                                         **
****************************************************************************/

#include "epb40005.h"

char VersionStr[]    = "epb40005 v1.0.0.1";
char gCompile_Date[] = __DATE__;
char gCompile_Time[] = __TIME__;

time_t startupTime_;
time_t endTime_;

main(int argc, char **argv)
{

   BCH_Init("EPB40005", NUMBER_OF_THREADS);

   TPM_1000_Initialize();

   TPM_2000_Mainline();

   TPM_9000_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);
}


/******************************************************************
**                                                               **
** Function Name:   TPM_1000_Initialize                          **
**                                                               **
** Description:     Performs startup initialization and opens    **
**                  ENCI data file.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_1000_Initialize()
{
 /**** Initialize counters & accumulators ***/

   startupTime_ = time(0);

   // Init Counters
   RS.Rec_Cnt         = 0;
   RS.Insert_Cnt      = 0;
   RS.Update_Cnt      = 0;
   RS.Duplicate_Cnt   = 0;
   RS.Error_Cnt       = 0;
   RS.reclen          = 0;

  /**** Initialize flags ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, VersionStr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_1000_Initialize");

  /*******************************************************************/
  /************    Open ENCI file and read first record    ***********/
  /*******************************************************************/
   RS.EPBF005 = BCH_Open("EPBF005", BCH_FILE_READ);
   if (RS.EPBF005 != BCH_FAIL)
   {
      // Read First Record
      RS.reclen = BCH_ReadRec(RS.EPBF005, RS.EPBF005_buffer, sizeof(RS.EPBF005_buffer));
      if (BCH_eof(RS.EPBF005))
      {
         printf("\n***** Error: ENCI Data File zero length! *****\n\n");

         BCH_Close(RS.EPBF005);

         RS.EPBF005 = BCH_FAIL;
      }
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                  The main processing thread to processes      **
**                  ENCI data and insert it into the NRAP_CRTF   **
**                  table.                                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_2000_Mainline()
{

   //---------  Process ENCI File  -------------------
   //
   // While there are ENCI Records to process....
   //
   if (RS.EPBF005 != BCH_FAIL)
   {
      printf("Processing ENCI Certificates Data File...\n\n");

      while (!BCH_eof(RS.EPBF005))
      {
         if (RS.reclen > 0)
         {
            printf("ENCI Record %ld\n", ++RS.Rec_Cnt);
            TPM_3000_ProcessFileEPBF005();

            // Process ENCI Item
            TPM_4000_ProcessENCIRecord();
         }

         // Read Next ENCI Record
         RS.reclen = BCH_ReadRec(RS.EPBF005, RS.EPBF005_buffer, sizeof(RS.EPBF005_buffer));
      }
   }
}


/******************************************************************
**                                                               **
** Function Name:   TPM_3000_ProcessFileEPBF005                  **
**                                                               **
** Description:     Call function to process individual          **
**                  records from ENCI file.  Loads and martials  **
**                  the record data into memory.                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void TPM_3000_ProcessFileEPBF005()
{
   char *pTemp;

   // Initialize and Fetch data from ENCI Record
   ENCI_REC = (struct _ENCI_REC *)RS.EPBF005_buffer;
   strncpy(RS.sPprNbr,         ENCI_REC->PPR_NBR,              9);
   strncpy(RS.sCustFirstNm,    ENCI_REC->CUST_FIRST_NM,       50);  // Fetch, but field is never used
   strncpy(RS.sCustLastNm,     ENCI_REC->CUST_LAST_NM,        50);  // Fetch, but field is never used
   strncpy(RS.sTktDesignator,  ENCI_REC->TKT_DSGTR_TXT,       15);
   strncpy(RS.sInitTktDocNb,   ENCI_REC->INIT_TKT_DOC_NB,     15);
   strncpy(RS.sInitTkDcIssLdt, ENCI_REC->INIT_TKT_DOC_ISS_LDT, 8);
   strncpy(RS.sRedemptionCd,   ENCI_REC->REDEMPTION_CD,       10);  // Fetch, but field is never used
   strncpy(RS.sCurTktDocNb,    ENCI_REC->XCHG_TKT_DOC_NB,     15);
   strncpy(RS.sCurTkDcIssLdt,  ENCI_REC->XCHG_TKT_DOC_ISS_LDT, 8);
   strcpy (RS.sNrapCd,         NULL_STRING);
   strcpy (RS.sNrapFrstBkgLdt, NULL_STRING);
   RS.nNrapSpgmNb = 0;
   RS.cNrapCrtfSttCd = 'A';    // 'A'=Allocated; 'B'=Booked; 'C'=Closed/Complete

   // Remove trailing spaces from string variables
   UTL_StripTrailingSpaces(RS.sPprNbr);
   UTL_StripTrailingSpaces(RS.sCustFirstNm);
   UTL_StripTrailingSpaces(RS.sCustLastNm);
   UTL_StripTrailingSpaces(RS.sTktDesignator);
   UTL_StripTrailingSpaces(RS.sInitTktDocNb);
   UTL_StripTrailingSpaces(RS.sInitTkDcIssLdt);
   UTL_StripTrailingSpaces(RS.sCurTktDocNb);
   UTL_StripTrailingSpaces(RS.sCurTkDcIssLdt);
   UTL_StripTrailingSpaces(RS.sRedemptionCd);

   // Convert Initial Ticket Issue Date from YYYYMMDD to standard database format
   if (isdigit(RS.sInitTkDcIssLdt[0])) {
      pTemp = UTL_ConvertDate(RS.sInitTkDcIssLdt, CNV_YYYYMMDD_TO_DB);
      strncpy(RS.sInitTkDcIssLdt, pTemp, sizeof(RS.sInitTkDcIssLdt));
   }

   // Convert Exchange Ticket Issue Date from YYYYMMDD to standard database format
   if (isdigit(RS.sCurTkDcIssLdt[0])) {
      pTemp = UTL_ConvertDate(RS.sCurTkDcIssLdt, CNV_YYYYMMDD_TO_DB);
      strncpy(RS.sCurTkDcIssLdt, pTemp, sizeof(RS.sCurTkDcIssLdt));
   }

}


/******************************************************************
**                                                               **
** Function Name:   TPM_4000_ProcessENCIRecord                   **
**                                                               **
** Description:     Main function to process ENCI data and data  **
**                  from suspense and insert records into the    **
**                  NRAP_CRTF table.                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
******************************************************************/

void TPM_4000_ProcessENCIRecord()
{
   /*********   Ignore this record if PPR="000000000"  */
   if (strcmp(RS.sPprNbr, "000000000")==0) {
      printf("Error - PPR is 000000000. Unable to process ENCI Certificate: %s (Tkt Designator: %s)\n",
              RS.sInitTktDocNb, RS.sTktDesignator);
      ++RS.Error_Cnt;
      return;
   }


   /*********   See if the certificate is already on file  ***********/
   if (TPM_8001_FindExistingCert(RS.sInitTktDocNb) == true) {
      ++RS.Duplicate_Cnt;
      return;
   }


   /*****  Look up Award using Ticket Designator  ****/
   if (TPM_8002_GetAwardInfoUsingTktDsgtr() == false) {
      printf("Error - Ticket Designator (%s) not on file. Unable to process ENCI Certificate: %s\n",
              RS.sTktDesignator, RS.sInitTktDocNb);
      ++RS.Error_Cnt;
      return;
   }

   // We can now insert Certificate info into NRAP_CRTF
   TPM_5000_InsertCertificate();
}


/******************************************************************
**                                                               **
** Function Name:   TPM_5000_InsertCertificate                   **
**                                                               **
** Description:     Call function to insert a record into the    **
**                  NRAP_CRTF table                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void  TPM_5000_InsertCertificate()
{
   printf("Loading Certificate %s into NRAP_CRTF Table.\n", RS.sInitTktDocNb);

   memset(&R04756, LOW_VALUES, sizeof(_R04756));
   memset(&A04756, LOW_VALUES, sizeof(_A04756));

   // Apply Rule: If a certificate hasn't been exchanged for a ticket yet,
   //             then use the Initial Ticket info as Cur_Tkt_Doc_Nb (Key Field)
   if (!isdigit(RS.sCurTktDocNb[0]) && isdigit(RS.sInitTktDocNb[0])) {
      strncpy(RS.sCurTktDocNb,   RS.sInitTktDocNb,   sizeof(RS.sCurTktDocNb));
      strncpy(RS.sCurTkDcIssLdt, RS.sInitTkDcIssLdt, sizeof(RS.sCurTkDcIssLdt));
      memset( RS.sInitTktDocNb,  0, sizeof(RS.sInitTktDocNb));
      memset( RS.sInitTkDcIssLdt,0, sizeof(RS.sInitTkDcIssLdt));
   }

   strcpy(R04756.R04756_appl_area.sCurTktDocNb,       RS.sCurTktDocNb);
   strcpy(R04756.R04756_appl_area.sCurTkDcIssLdt,     RS.sCurTkDcIssLdt);
   strcpy(R04756.R04756_appl_area.sInitTktDocNb,      RS.sInitTktDocNb);
   strcpy(R04756.R04756_appl_area.sInitTkDcIssLdt,    RS.sInitTkDcIssLdt);
   strcpy(R04756.R04756_appl_area.sNrapCd,            RS.sNrapCd);
   R04756.R04756_appl_area.nNrapSpgmNb              = RS.nNrapSpgmNb;
   strcpy(R04756.R04756_appl_area.sNrapFrstBkgLdt,    RS.sNrapFrstBkgLdt);
   strcpy(R04756.R04756_appl_area.sPprNbr,            RS.sPprNbr);
   R04756.R04756_appl_area.cNrapCrtfSttCd           = RS.cNrapCrtfSttCd;
   strcpy(R04756.R04756_appl_area.sLstUpdtId,         MODULE_NAME);

   /*** Write to NRAP_CRTF ***/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0, &R04756, &A04756, SERVICE_ID_04756, 1, sizeof(R04756.R04756_appl_area));

   switch (nSvcRtnCd)
   {
     case ARC_SUCCESS:
        RS.Insert_Cnt++;
        break;
     case ARC_DUPLICATE_ROW:
        RS.Duplicate_Cnt++;
        break;
     default:
        RS.Error_Cnt++;   // Log runtime error
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS04756");
        sprintf(sErrorMessage,
           "\n  Insert Error: CurTkt=%s, InitTkt=%s, NrapCd=%s, PprNbr=%s\n",
           R04756.R04756_appl_area.sCurTktDocNb,
           R04756.R04756_appl_area.sInitTktDocNb,
           R04756.R04756_appl_area.sNrapCd,
           R04756.R04756_appl_area.sPprNbr);
        BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "TPM_5000_InsertCertificate");
        break;
   }

}

/******************************************************************
**                                                               **
** Function Name:   TPM_8001_FindExistingCert                    **
**                                                               **
** Description:     Call function to obtain PPR and related      **
**                  Award Program data from the NRAP_CRTF table  **
**                  using a certificate.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F (true = Certificate found in NRAP_CRTF)  **
**                                                               **
******************************************************************/

int TPM_8001_FindExistingCert(char *eCert)
{
   int certificate_found;

   //--------------------------------------------------------
   // Locate Certificate in Cross-Reference table: NRAP_CRTF
   // Try 2 different lookups...
   //--------------------------------------------------------

   // Compare Certificate (InitTktDocNb) to NRAP_CRTF.Cur_Tkt_Doc_Nb
   memset(&R04741, LOW_VALUES, sizeof(R04741));
   memset(&A04741, LOW_VALUES, sizeof(A04741));
   strcpy(R04741.R04741_appl_area.sCertificate, eCert);

   nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04741, &A04741, SERVICE_ID_04741, 1, sizeof(R04741.R04741_appl_area));
   if (nSvcRtnCd == ARC_SUCCESS) {
      printf("Certificate %s already on file (Cur_Tkt_Doc_Nb). Record Ignored.\n", eCert);
      return certificate_found = true;
   }


   // Compare Certificate (InitTktDocNb) to NRAP_CRTF.Init_Tkt_Doc_Nb
   memset(&R04742, LOW_VALUES, sizeof(R04742));
   memset(&A04742, LOW_VALUES, sizeof(A04742));
   strcpy(R04742.R04742_appl_area.sCertificate, eCert);

   nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04742, &A04742, SERVICE_ID_04742, 1, sizeof(R04742.R04742_appl_area));
   if (nSvcRtnCd == ARC_SUCCESS) {
      printf("Certificate %s already on file (Init_Tkt_Doc_Nb). Record Ignored.\n", eCert);
      return certificate_found = true;
   }

   return certificate_found = false;
}


/******************************************************************
**                                                               **
** Function Name:   TPM_8002_GetAwardInfoUsingTktDsgtr           **
**                                                               **
** Description:     Call function to obtain the award program    **
**                  information using the Ticket Designator      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   T/F  (true = award found using TktDsgtr)     **
**                                                               **
**                                                               **
******************************************************************/

int TPM_8002_GetAwardInfoUsingTktDsgtr()
{
   int award_found = false;

   if (strlen(RS.sTktDesignator) > 0)
   {
       memset(&R04744, LOW_VALUES, sizeof(_R04744));
       memset(&A04744, LOW_VALUES, sizeof(_A04744));
       strcpy(R04744.R04744_appl_area.sTktDsgtrTxt, RS.sTktDesignator);

       nSvcRtnCd = BCH_InvokeService(EPBINQ0, &R04744, &A04744, SERVICE_ID_04744, 1, sizeof(R04744.R04744_appl_area));

       if (nSvcRtnCd == ARC_SUCCESS)
       {
          strcpy(RS.sNrapCd,         A04744.A04744_appl_area.sNrapCd);
          strcpy(RS.sNrapFrstBkgLdt, A04744.A04744_appl_area.sNrapFrstBkgLdt);
          RS.nNrapSpgmNb           = A04744.A04744_appl_area.nNrapSpgmNb;
          award_found = true;
       }
   }

   return award_found;
}


/******************************************************************
**                                                               **
** Function Name:   TPM_9000_ProcessEndOfProgram                 **
**                                                               **
** Description:     Call function to perform end of program      **
**                  housekeeping (close files, print summary)    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void TPM_9000_ProcessEndOfProgram()
{
   static char totals_buffer[1024];

   endTime_ = time(0);

   /** Include any logic here for final clean-up processing  **/

   /************************/
   /**    CLOSE FILES     **/
   /************************/
   if (RS.EPBF005 != BCH_FAIL) {
      BCH_Close(RS.EPBF005);
   }

   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, VersionStr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "TPM_9000_ProcessEndOfProgram");


   /************************/
   /**    CONTROL TOTALS  **/
   /************************/

   sprintf(totals_buffer,
      "\n********* Module Information **********\n"
      "  Processing Totals:\n"
      "    ENCI Records Processed       : %lu\n"
      "    Certificate Records Inserted : %lu\n"
      "    Certificate Records Updated  : %lu\n"
      "    Duplicate Records (Ignored)  : %lu\n"
      "    Runtime Errors               : %lu",
      RS.Rec_Cnt,
      RS.Insert_Cnt,
      RS.Update_Cnt,
      RS.Duplicate_Cnt,
      RS.Error_Cnt);
   puts(totals_buffer);        // print totals

   // Print start and end time;
   //     Note: can't call these both in the same call because
   //     time is stored in a static buffer.
   printf("    Time Job started:      %s",   asctime(localtime(&startupTime_)));
   printf("    Time Job completed:    %s\n", asctime(localtime(&endTime_)));

}




