/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB54003.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  LaShawnda Walker                                       **
**                                                                         **
** Date Written:    8/13/98                                                **
**                                                                         **
** Description:     This program processes all Penalty Charge items on the **
**                  Charges Table for the current Pass Date Time Stamp.    **
**                  Where the following conditions are true:               **
**                  svc_chrg_cd = "FP" or "IP"                             **
**                  svc_chrg_cd = "FT" and pass_grp_cd = "AK" or "AC"      **
**                  pass_dt_tm_ts = "getdate()"                            **
**                  cost_chrg_amt > 0                                      **
**                  proc_dt = "12/31/1899"                                 **
**                                                                         **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 05/29/02   L.Scott                     Added a second address line to   **
**                                        file EPFI7984 (CSR 7984).        **
**                                                                         **
****************************************************************************/


#include "epb54003.h"

main()
{
  BCH_Init("EPB54003", NUMBER_OF_THREADS);
  
  DPM_1000_Initialize();

  DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{
  char *pCycleType;               /*  pointer to cycle            */

  int i, j;


     
 /*** get cycle from script   ***/

  pCycleType = (char *) getenv("CYCLES");
  strcpy(RS.sCycleId, pCycleType);

 /**** Build thread table ***/

 

 /************** call RSAM to start program ****************/


  BCH_FormatMessage(1,TXT_PROG_STRT);
  BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");


  /**** NOTE: BCH_GetCurrentDate() will give current date and time in many
               formats.  (including Sort, Display, and Timestamp)  ****/

     
  /**************************************************/
  /** set up today's date in CCYYMMDD format       **/
  /**************************************************/
  memset(&RS.sTodayDt, LOW_VALUES, sizeof(RS.sTodayDt));
  strncpy(RS.sTodayDt, sCurrentSortDt,4);    /* CCYY */
  strncat(RS.sTodayDt, sCurrentSortDt+5,2);  /* MM   */
  strncat(RS.sTodayDt, sCurrentSortDt+8,2);  /* DD   */

  /*********** Call RSAM to open output file for Penalty Charge Records ************/

  RS.EPBF040 = BCH_Open("EPBF040", BCH_FILE_WRITE);

  if (RS.EPBF040 == BCH_FAIL)
  {
    BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
    BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF040");
    BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
  }

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Process all penalty charge records for the   **
**                  current day and write each record to an      **
**                  output file to be sent to printing.          **
**                                                               **
** Arguments:       None.                                        **
**                                                               **
** Return Values:   None.                                        **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
  int FOUND,
      nSvcRtnCd,
      nRecCnt=0,
      nNbrOfChrgs=0,
      nPrevRecCnt=0;

  char sErrorMessage[250],
       sCostChrgAmt[20],
       sPrevPprNbr[10],
       sSvcChrgDs[40],
       cCardCd,
       cIndicator='W';


/*** First, go get all of the charge codes and descriptions and store in an array  ***/
  memset(&R03932.R03932_appl_area,LOW_VALUES,sizeof(R03932.R03932_appl_area));
  memset(&A03932,LOW_VALUES,sizeof(A03932));
  R03932.R03932_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
  nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03932,&A03932,SERVICE_ID_03932,1,sizeof(R03932.R03932_appl_area));
 
  /****** Service Return Code Processing  ****/
  switch (nSvcRtnCd)
  {  
    case ARC_SUCCESS:
      break;
    default:
      BCH_FormatMessage(1,TXT_SVC_UNSUCC);
      BCH_FormatMessage(2,TXT_SVC, "FYS03932");
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
  }  
 
  while (nSvcRtnCd != ARC_ROW_NOT_FOUND && nNbrOfChrgs < 3)
  {  
    /*** store charge code and description in array   ***/
    if ( strcmp(A03932.A03932_appl_area.sSvcChrgCd,"FP") == 0 || \
         strcmp(A03932.A03932_appl_area.sSvcChrgCd,"FT") == 0 || \
         strcmp(A03932.A03932_appl_area.sSvcChrgCd,"IP") == 0 )
    {
      strcpy(svc_chrg[nNbrOfChrgs].sSvcChrgCd, A03932.A03932_appl_area.sSvcChrgCd);
      strcpy(svc_chrg[nNbrOfChrgs].sSvcChrgDs, A03932.A03932_appl_area.sSvcChrgDs);
      nNbrOfChrgs++;
    }

    /*** go get next charge description   ***/
    R03932.R03932_appl_area.cArchCursorOpTxt = FETCH_ROW;
    memset(&A03932,LOW_VALUES,sizeof(A03932));
    nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R03932,&A03932,SERVICE_ID_03932,1,sizeof(R03932.R03932_appl_area));

    switch (nSvcRtnCd)
    {
      case ARC_SUCCESS:
        break;
      case ARC_ROW_NOT_FOUND:
        break;
      default:
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC, "FYS03932");
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
    }
  }

  memset(&R04621.R04621_appl_area,LOW_VALUES,sizeof(R04621.R04621_appl_area));
  memset(&A04621,LOW_VALUES,sizeof(A04621));
  R04621.R04621_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
  nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04621,&A04621,SERVICE_ID_04621,1,sizeof(R04621));
 
  /****** Service Return Code Processing  ****/
  switch (nSvcRtnCd)
  {
    case ARC_SUCCESS:
      memset(&sPrevPprNbr,LOW_VALUES,sizeof(sPrevPprNbr));
      break;
    case ARC_ROW_NOT_FOUND:
      break;
    default:
      BCH_FormatMessage(1,TXT_SVC_UNSUCC);
      BCH_FormatMessage(2,TXT_SVC, "FYS04621");
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
  }

  while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
  {
    if ( (strcmp(A04621.A04621_appl_area.sPprCtryCd,"US") == 0) || \
(strcmp(A04621.A04621_appl_area.sPprCtryCd,"USA") == 0) || \
(strcmp(A04621.A04621_appl_area.sPprCtryCd,"PUR") == 0) || \
(strcmp(A04621.A04621_appl_area.sPprCtryCd,"ISV") == 0) )
      cIndicator='H';
    else
      cIndicator='W';

    sprintf(sCostChrgAmt,"%.2lf",A04621.A04621_appl_area.dCostChrgAmt);
    if ( strlen(sCostChrgAmt) > COST_CHRG_MAX_LEN )
    {
      BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF040");
      memset(sErrorMessage,LOW_VALUES,sizeof(sErrorMessage));
      sprintf(sErrorMessage,"%s%s%d","Cost charge amount exceeds max length limit.","  Max Length Allowed: ",COST_CHRG_MAX_LEN);
      BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
      memset(sErrorMessage,LOW_VALUES,sizeof(sErrorMessage));
      sprintf(sErrorMessage,"%s%9s%s%2s%s%.2lf","PPR Number: ",A04621.A04621_appl_area.sPprNbr,"  NRev Number: ",A04621.A04621_appl_area.sNrevNbr,"\nCost Charge Amount: ",A04621.A04621_appl_area.dCostChrgAmt);
      BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
      BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");
      break;
    }

    if ( strcmp(A04621.A04621_appl_area.sPprNbr,sPrevPprNbr) == 0 )
    {
      ++nPrevRecCnt;
      cCardCd=' ';
      if ( nPrevRecCnt > 20 )
      {
        cCardCd='1';
        nPrevRecCnt=1;
      }
    }
    else
    {
      nPrevRecCnt=1;
      cCardCd='1';
      strcpy(sPrevPprNbr,A04621.A04621_appl_area.sPprNbr);
    }
    ++nRecCnt;

    if ( strcmp(A04621.A04621_appl_area.sSvcChrgCd,"IP") == 0 )
    {
      /* Do nothing data is already in correct format */
    }
    else
    {
      memset(&(A04621.A04621_appl_area.sFltOrigCtyId),LOW_VALUES,sizeof(A04621.A04621_appl_area.sFltOrigCtyId));
      memset(&(A04621.A04621_appl_area.sFltDestCtyId),LOW_VALUES,sizeof(A04621.A04621_appl_area.sFltDestCtyId));
      strncpy(A04621.A04621_appl_area.sFltOrigCtyId,A04621.A04621_appl_area.sSvcChrgDs,3);
      strncpy(A04621.A04621_appl_area.sFltDestCtyId,A04621.A04621_appl_area.sSvcChrgDs+6,3);
    }

    FOUND=0;
    nNbrOfChrgs=0;
    while ( FOUND != 1 && nNbrOfChrgs < 3 )
    {
      if ( strcmp(A04621.A04621_appl_area.sSvcChrgCd,svc_chrg[nNbrOfChrgs].sSvcChrgCd) == 0 )
      {
        memset(&(A04621.A04621_appl_area.sSvcChrgDs),LOW_VALUES,sizeof(A04621.A04621_appl_area.sSvcChrgDs));
        strncpy(A04621.A04621_appl_area.sSvcChrgDs,svc_chrg[nNbrOfChrgs].sSvcChrgDs,15);
        FOUND = 1;
      }
      nNbrOfChrgs++;
    }

    memset(&RS.EPBF040_buffer,LOW_VALUES,sizeof(RS.EPBF040_buffer));
    sprintf(RS.EPBF040_buffer,
"%-2c%-2c%-31s%-10s%-6s%-6s%-31s%-27s%-16s%5s/%-6s%-3s%-7.2lf%-25s%-25s%-25s%-3s%-10s%-4s%-9s%05d",
cCardCd,cIndicator,
A04621.A04621_appl_area.sPprNm,A04621.A04621_appl_area.sPprNbr,
A04621.A04621_appl_area.sPprDeptNbr,A04621.A04621_appl_area.sPprStnId,
A04621.A04621_appl_area.sNrevNm,A04621.A04621_appl_area.sFltDprtDt,
A04621.A04621_appl_area.sSvcChrgDs,A04621.A04621_appl_area.sFltOrigCtyId,
A04621.A04621_appl_area.sFltDestCtyId,A04621.A04621_appl_area.sNrevTypCd,
A04621.A04621_appl_area.dCostChrgAmt,A04621.A04621_appl_area.sPpr1Addr,
A04621.A04621_appl_area.sPpr2Addr,
A04621.A04621_appl_area.sPprCtyAddr,A04621.A04621_appl_area.sPprStCd,
A04621.A04621_appl_area.sPprZipAddr,A04621.A04621_appl_area.sPprCtryCd,
RS.sTodayDt,nRecCnt);
    BCH_WriteRec(RS.EPBF040,RS.EPBF040_buffer,sizeof(RS.EPBF040_buffer));
    memset(&R04621.R04621_appl_area,LOW_VALUES,sizeof(R04621.R04621_appl_area));
    memset(&A04621,LOW_VALUES,sizeof(A04621));
    R04621.R04621_appl_area.cArchCursorOpTxt = FETCH_ROW;
    nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04621,&A04621,SERVICE_ID_04621,1,sizeof(R04621));
    switch (nSvcRtnCd)
    {
      case ARC_SUCCESS:
        break;
      case ARC_ROW_NOT_FOUND:
        break;
      default:
        BCH_FormatMessage(1,TXT_SVC_UNSUCC);
        BCH_FormatMessage(2,TXT_SVC,"FYS04621");
        BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
    }
  }

  BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF040");
  BCH_FormatMessage(2,TXT_REC_TTL, nRecCnt);
  BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");

  BCH_Close(RS.EPBF040);

  BCH_Terminate();
  exit(0);
}
