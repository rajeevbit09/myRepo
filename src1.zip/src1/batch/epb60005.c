/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    <EPB60005.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  C.Eachus                                               **
**                                                                         **
** Date Written:    5/5/95                                                 **
**                                                                         **
** Description:     Database driven programs use, as their primary input,  **
**                  a Sybase database.  The database is scanned and        **
**                  updated and/or transactions are generated for          **
**                  subsequent processing steps. This module is            **
**                  responsible for retrieving the Pass History table,     **
**                  the Imputed Trip table, and the Charges History        **
**                  table.  It searches each table and removes rows        **
**                  older than 3 years.                                    **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date      Revised by                      Description                   **
** ----      ----------                      ------------                  **
** 8/27/96     FFA                       Added service 04118 to calculate  **
**                                       date of today - 3 years.  This    **
**                                       date is then passed to the services*
**                                       which are revised to use the date **
**                                       instead of doing a datediff.      **
**                                                                         **
** 1/24/01     LAS                       Updated to search and remove rows **
**                                       older than 5 years.               **
**                                                                         **
****************************************************************************/

/*** Include header files ***/

#include "epb60005.h"
#include "epbcmncd.h"


main()
{
   BCH_Init("EPB60005", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{
    /*** Initialize request and answer copybooks ***/
    memset(&A02823, LOW_VALUES, sizeof(_A02823));
    memset(&R02823, LOW_VALUES, sizeof(_R02823));

    BCH_FormatMessage(1,TXT_PROG_STRT);
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}


/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing. This function contains  **
**                  three service calls.  The services are       **
**		    advanced deletes.  They delete all rows off  **
**                  of the history tables that have a flight     **
**                  departure date more than 3 years old.        **  
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{
   short   nSvcRtnCd;   /* Service return code */

    /*** Calculate date of today - 5 years(1825 days) ***/
    memset(&R04118, LOW_VALUES, sizeof(_R04118));
    memset(&A04118, LOW_VALUES, sizeof(_A04118));
    strcpy(R04118.R04118_appl_area.sPassRptSortDt, sCurrentTsDt);
    UTL_ZeroDatesTime(sCurrentTsDt);
    R04118.R04118_appl_area.nFltArrTm = -5*365;

    nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04118,&A04118,SERVICE_ID_04118,1,sizeof(_R04118));

    /****** Service Return Code Processing  ****/
    switch (nSvcRtnCd)
    {
        case ARC_SUCCESS:
            break;

        default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04118");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
    }
 

    sprintf(sErrorMessage, "Beginning delete of Pass History, Imputed Trip, & Charges History records older than %s",
            A04118.A04118_appl_area.sFltDprtDt);
    BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT,sErrorMessage);
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");


    /****** Initialize Request and Answer Blocks *****/
    memset(&R02823, LOW_VALUES, sizeof(_R02823));
    memset(&A02823, LOW_VALUES, sizeof(_A02823));
    strcpy(R02823.R02823_appl_area.sFltDprtDt, A04118.A04118_appl_area.sFltDprtDt);
    nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02823,&A02823,SERVICE_ID_02823,1,sizeof(_R02823));

    /****** Service Return Code Processing  ****/
    switch (nSvcRtnCd)
    {
        case ARC_SUCCESS:
            DPM_4920_ProcessLUW(); 
            break;

        default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02823");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
    }  

   /*** write messages to log ***/
    BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "Rows Archived");
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");

    BCH_FormatMessage(2,TXT_PROC_SUCC_COMPL);
    BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_2000_Mainline");
    
    DPM_9500_ProcessEndOfProgram();
    BCH_Terminate();

    exit(0);
}


/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.  Currently the checkpoint    **
**                  interval is set at 2 if nCkptCntr is greater **
**                  than or equal to the checkpoint interval a   **
**                  commit is performed.                         **
**                                                               ** 
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void DPM_4920_ProcessLUW()                                          
{
}


/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{
}
