
/*                                                                      */
/* Copyright [2001] Delta Air Lines, Inc./Delta Technology, Inc.   */
/*                       All Rights Reserved                            */
/*               Access, Modification, or Use Prohibited                */
/* Without Express Permission of Delta Air Lines or Delta Technology.   */
/*                                                                      */
/*######################################################################*/
/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass System                                            **
**                                                                         **
** Program Name:    <EPB54001.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Faith Ammons                                           **
**                                                                         **
** Date Written:    05/03/95                                               **
**                                                                         **
** Description:     This module calculates service charges and International*
**                  fees for all flight legs (imputed and non-inmputed)    **
**                  that have not already been processed.  After each      **
**                  flight leg is processed, the process date is set to    **
**                  the current date to show that it has been processed.   **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 1/22/96    khancock           22/25    Add slash to orig dest; deduct   **
**                                        allotment pass_typ '90' for PANAM**
** 1/24/96    khancock           28       Put check into program for       **
**                                        Spanish stations not to have fees**
**                                        processed.                       **
** 3/7/96     FFA                219/225  No penalties should be assessed  **
**                                        for pass type 30 and 10.         **
** 3/16/96    FFA                         1) new updateable cursors.       **
**                                           4317 replaces 2599 & 2660 on  **
**                                           the flight leg table.  4343   **
**                                           replaces 4343 & 2661 on the   **
**                                           imptd flt leg table.          **
**                                        2) New Pass Group changes.       **
**                                        3) write to Deltamatic Changes   **
**                                           table after updating the Remn **
**                                           Allotment Table.              **
**                                        4) A penalty for pass type 10, 20**
**                                           30 should be doubled if flight**
**                                           day is tranoceanic.           **
**3/27/96     FFA                         Dont create a charge record if   **
**                                        the charge amount is 0.          **
**3/28/96     FFA                         If the parent of single active   **
**                                        empl flies on a 20 or 40 pass,   **
**                                        decrement both parents allotments**
**4/19/96     FFA               255       Put a space between orig and /   **
**                                        and dest for day type charges.   **
**4/19/96     FFA                         Put city incurring int'l fee in  **
**                                        description on chrg record (DMSS)**
**4/23/96     FFA               242       HR intl penalty should only be   **
**                                        charged for Transatlantic and Trans
**                                        pacific flights.                 **
**5/2/96      FFA               244       If the flight day is transoceanic**
**                                        (40), check to see if nrev has 90**
**                                        allotments if the nrev has no more*
**                                        40's, and decrement, penalize, or**
**                                        service charge accordingly.      **
**5/10/96     FFA                         Spanish stations will now be     **
**                                        processed. Commented out changes **
**                                        made by KCH on 1/24              **
**7/30/96     FFA                         Dont try to convert 'USD' currency*
**8/9/96      FFA                         When certain disabled pass grps  **
**                                        with 120 mths of svc fly trans - **
**                                        oceanic, decrement both domestic **
**                                        and transoceanic allotments.     **
**8/13/96     FFA                         Added count and amount of charges**
**                                        processed.                       **
**10/4/96     FFA                         Allow combined domestic/TO allots**
**                                        to have day or mile option.      **
**11/16/96    FFA                         1-No US landing fees from US     **
**                                          territories (UT)               **
**                                        2_no intl fees for ticketed psgrs**
**                                        3-remove check for tkt'd when    **
**                                          chkng for svc chg.             **
**11/19/96     FFA                        If no allotments for parents of  **
**                                        assoc, domest or transoceanic,   **
**                                        decrement their priority allotment*
**                                                                         **
**                                                                         **
**05/27/97     FFA                        If an old flight leg comes thru  **
**                                        and the pass type doesnt change  **
**                                        but the new leg is an internatl  **
**                                        and there wasnt one originally,  **
**                                        go thru old data processing.     **
**                                                                         **
**09/30/98     LSW                        Added changes for Parents of AC  **
**                                        or AK groups with pass_typ_cd    **
**                                        of 90 with nrev_remn_dy_qty = 0  **
**                                        if flight was domestic (DM) and  **
**                                        the nrev_remn_dy_qty is not 0    **
**                                        then the pass_typ_cd is updated  **
**                                        to 20 and the flight leg is      **
**                                        processed; if the flight was     **
**                                        transoceanic (AC or AK) and the  **
**                                        nrev_remn_dy_qty is not 0 then   **
**                                        the pass_typ_cd is updated to 40 **
**                                        and then the flight leg is       **
**                                        processed                        **
**                                                                         **
**11/11/98     BBE                        Commented out LSW's code due to  **
**                                        a production problem.            **
**                                                                         **
**11/19/98     LSW                        Made modifications to the changes**
**                                        added on 09/30/98 due to process **
**                                        not running in production.       **
**                                                                         **
**11/30/98     LSW                        YC Fee will no longer be         **
**                                        collected for travel originating **
**                                        outside of the US for the        **
**                                        following locations: US          **
**                                        Territories, Canada, Mexico,     **
**                                        Bahamas or adjacent islands that **
**                                        is destined for one of the 50 US **
**                                        cities or the District of        **
**                                        Columbia.                        **
**                                                                         **
** 7/23/99     LAS                        Added a check for 'CP' Companions**
**                                        when decrementing both 40 & 50   **
**                                        pass types when a transoceanic   **
**                                        flight day is used by a disabled **
**                                        pass group.                      **
**                                                                         **
** 4/18/01     LAS                        Transoceanic flight days for     **
**                                        specific pass riders in DGS pass **
**                                        groups should be decremented from**
**                                        40 & 50 pass types.              **
**
** 8/3/01      LAS                        Commented out code where priority**
**                                        passes were used on transoceanic **
**                                        flights but no allotments exist, **
**                                        which was causing doubling of    **
**                                        flight penalties.                **
**                                                                         **
** 10/04/01    LAS                        Added code for the Delta Recovery**
**                                        Plan pass groups VA, VB and VC   **
**                                        to mirror what is happening with **
**                                        QTO pass groups.                 **
**                                                                         **
** 03/29/02    EJS                        Added code for Canadian Sec Fee  **
**                                                                         **
** 05/15/02    EJS                        Fix code for doubling problem    **
**                                        added check for SuspRvkInd = 'N' **
**                                        where executing CalcPenalty      **
**                                                                         **
** 08/01/02    LAS                        Added code for U.S. Security Fee;**
**                                        Also removed code that checked   **
**                                        pass groups before assessing $75 **
**                                        flate fee charge for parents     **
**                                        travelling international on a    **
**                                        combo(90) pass type because all  **
**                                        parents should be charged.       **
**                                                                         **
** 09/16/02    LAS                        Added code for Mexican Tourism   **
**                                        Tax to be assessed on all flights**
**                                        departing Mexico, but to exclude **
**                                        Mexican citizens.                **
**                                                                         **
** 11/18/02    LAS                        Added code for Montego Bay (MBJ) **
**                                        tax to be assessed on all flights**
**                                        departing MBJ on Delta aircraft  **
**                                        only since Air Jamaica collects  **
**                                        the tax on their flights prior   **
**                                        to departure.                    **
**                                                                         **
** 12/09/03    LAS                        Added code to force proc date and**
**                                        flt_acct_eff_dt to today's date  **
**                                        inorder to keep from processing  **
**                                        charges created from Positive    **
**                                        Space flight legs.               **
**                                                                         **
** 04/15/04    LAS                        Added code to exclude parents    **
**                                        with a ticketed indicator set to **
**                                        'T' when flat fee is charged.    **
**                                                                         **
** 10/19/06    LAS                        As of 10/01/06 all flights on    **
**                                        Air Jamaica are ID 96, so their  **
**                                        flight legs should no longer     **
**                                        come through this system.  So,   **
**                                        there is no need to exclude      **
**                                        certain flights departing        **
**                                        Jamaica from being charged the   **
**                                        Jamaica departure tax.           **
**                                                                         **
** 09/18/07    LAS                        Added code to exclude citizens   **
**                                        of Belize from the Belize Airport**
**                                        Development tax and the Belize   **
**                                        Conservation tax.                **
**                                                                         **
** 08/29/08    LAS                        Corrected code for intl fees     **
**                                        not being charged for employees  **
**                                        in the FP and FV pass groups,    **
**                                        since employees (SF) are not     **
**                                        ticketed in Deltamatic even      **
**                                        though Pass shows them as        **
**                                        ticketed.                        **
**                                                                         **
** 04/17/09    GLW                        added code to process NW ticket  **
**                                        number to identify charges on NW **
**                                        flights to send correct company  **
**                                        code to SAP                      **
**                                                                         **
** 07/16/09    AKT                        added code to process NW ticket  **
**                                        number to identify charges on NW **
**                                        flights to send correct company  **
**                                        code to SAP                      **
**                                                                         **
** 08/11/10    LAS                        When processing for S2 flight    **
**                                        days check to see if the flight  **
**                                        is a continuation from the       **
**                                        previous day (within 24 hours)   **
**                                        and if the final destination is  **
**                                        not the same as the origination  **
**                                        city from the previous day's S2. **
**                                        If the criteria is met then an   **
**                                        extra S2 day is not decremented. **
**                                                                         **
** 12/07/10    LAS                        Include additional regions       **
**                                        when looking at Latin America, so**
**                                        that Caribbean is now included.  **
**                                                                         **
** 12/10/10    LAS                        Include Co-op pass group KR when **
**                                        looking at parents of single     **
**                                        people when using pass type 20   **
**                                        and 40.                          **
**                                                                         **
** 03/02/11    LAS                        Added brackets in function       **
**                                        DPM_3300_CalcSvcChgs where flat  **
**                                        fee and transoceanic svc charge  **
**                                        was created.  This corrected a   **
**                                        problem where the flat fee was   **
**                                        being charged.                   **
**                                        Removed the Write_to_log code    **
**                                                                         **
** 05/26/11    LAS                        St Thomas and St Croix departures**
**                                        to main land US, Alaska and      **
**                                        Hawaii should be charged the     **
**                                        APHIS landing fees.              **
**                                                                         **
****************************************************************************/

#include "epb54001.h"
#include "stdio.h"

main()
{
   BCH_Init("EPB54001", NUMBER_OF_THREADS);

   DPM_1000_Initialize();

   DPM_2000_Mainline();
}

void Write_to_log(char xxxxxxxxxxxxxxxxxxxxxxxx[])
{
  FILE *fp;
  fp=fopen("mylog.txt","a");
  fprintf(fp,"%s \n", xxxxxxxxxxxxxxxxxxxxxxxx);
  fclose(fp);
}

void Write_to_log_s(char x)
{
  FILE *fp;
  fp=fopen("mylog.txt","a");
  fprintf(fp,"%c \n", x);
  fclose(fp);
}

void Write_to_log_long(long n)
{
  FILE *fp;
  fp=fopen("mylog.txt","a");
  fprintf(fp,"%d \n", n);
  fclose(fp);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_1000_Initialize()
{
   char *pInput;                        /* pointer to Input Date    */

 /**** Initialize fields ****/
   memset(save_fltleg_data,' ', sizeof(save_fltleg_data));  /** initialize save fltleg data area **/
   RS.sFltLegCnt = 0;
   RS.sImpFltLegCnt = 0;
   RS.sBdyFltLegCnt = 0;
   RS.nSvcChrgCnt = 0;
   RS.dSvcChrgAmt = 0.0;
   RS.nIntlFeeCnt = 0;
   RS.dIntlFeeAmt = 0.0;
   RS.nPenaltyCnt = 0;
   RS.dPenaltyAmt = 0.0;
   RS.nRefundCnt = 0;
   RS.dRefundAmt = 0.0;
   cFirstTimeInd = YES_CHAR;
   strcpy(sOldPprNbr, "         ");
   strcpy(sOldNrevNbr, "  ");
   lOldRfrnDt = 0;
   cTransHawaiiAlaska = NO_CHAR;
   cOldTransHawaiiAlaska = NO_CHAR;

   /*** Get the processing date from the script, this date is in the format ccyymmdd ***/
   pInput = (char *)getenv("DATE1");
   strcpy(RS.sInputDt, pInput);

   // Convert to Julian & subtract 2
   // Error if before Jan 2nd.  We're not sure why??? just because the old code had
   // a bug and we don't know the business rule to fix
   lRfrnDt = UTL_GetJulianFromDate(RS.sInputDt);
   if (lRfrnDt % 1000 < 2)
   {
       BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, "Can't run before Jan 2nd");
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_ProcessTaxes");
   }
   else
   {
       lRfrnDt -= 2;
   }

   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2000_Mainline()
{
   cCommitAnyway = NO_CHAR;

/**  First, Read all of the flight legs that havent been processed and calculate service  */
/**  charges and International fees                                                       */
   DPM_2100_ProcessFltlegs();
   cCommitAnyway = YES_CHAR;                  /* After processing all of the legs,    */
   DPM_4920_ProcessLUW();                 /* do a final commit to save the data   */
   cCommitAnyway = NO_CHAR;

/** Next, Read all of the Imputed flight legs that havent been processed and   */
/**  calculate service charges and international fees                          */
   cFirstTimeInd = YES_CHAR;
   strcpy(sOldPprNbr, "         ");
   strcpy(sOldNrevNbr, "  ");
   lOldRfrnDt = 0;

   DPM_2300_ProcessImpFltlegs();
   cCommitAnyway = YES_CHAR;                  /* After processing all of the Imputed  */
   DPM_4920_ProcessLUW();                 /* flight legs, do a final commit       */

   cCommitAnyway = NO_CHAR;
   DPM_2500_ProcessBdyFltlegs();
   cCommitAnyway = YES_CHAR;
   DPM_4920_ProcessLUW();                 /* flight legs, do a final commit       */

   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2100_ProcessFltlegs                      **
**                                                               **
** Description:     This function reads each of the items on the **
** non-imputed flight leg table and begins the process to        **
** calculate service charges and international fees.  After      **
** processing each flight leg, the process date is set to today. **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2100_ProcessFltlegs()
{
   short     nSvcRtnCd;      /* Service return code */
   char *pTemp;
   cImpFltlegInd = NO_CHAR;
   cBdyFltlegInd = NO_CHAR;
   cEndOfFltlegData = NO_CHAR;
   nDayIndex = 0;

      /****** Initialize Request and Answer Blocks for service to retreive 1st flight leg *****
       ****** row that has not been processed (process date = 12/31/1899)                 *****/
      memset(&R04317.R04317_appl_area,LOW_VALUES, sizeof(R04317.R04317_appl_area));
      memset(&A04317,LOW_VALUES,sizeof(A04317));
      strcpy(R04317.R04317_appl_area.sProcDt, LOW_DATE);
      R04317.R04317_appl_area.lFltChrgRfrnDt = lRfrnDt;
      R04317.R04317_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

      /****** Execute service to retrieve driving rows  ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD4,&R04317,&A04317,SERVICE_ID_04317,1,sizeof(R04317.R04317_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
	    pTemp = UTL_ConvertDate(A04317.A04317_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	    strcpy(A04317.A04317_appl_area.sPassRptSortDt, pTemp);
            DPM_4100_SaveFltlegData();
            break;

         case ARC_ROW_NOT_FOUND:
            cEndOfFltlegData = YES_CHAR;
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2100_ProcessFltlegs");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04317");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2100_ProcessFltlegs");
         }

 /**** Process flight leg items      ****/
   while (cEndOfFltlegData == NO_CHAR)
      {
      DPM_2200_ProcessRows();
      }

/*** After processing all of the legs, make sure that the day process has been done for the last group ***/
/*** of flight legs.                                                                                   ***/
   if (nDayIndex != 0)
      DPM_3050_DayProcess();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2200_ProcessRows                         **
**                                                               **
** Description:     Process Flight Leg Table until end of rows   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2200_ProcessRows()
{
   char      *pTemp;
   short     nSvcRtnCd;      /* Service return code */
   char      PRIOR_PER_REMN_ALLOT='N';  /* indicator for checking if prior period allot */                                        /* will be used */


/*** Check for Parents of AC or AK group and determine if an update of ***/
/*** the pass_typ_cd is necessary.  pass_typ_cd is updated if a Parent ***/
/*** has a nrev_remn_dy_qty of 0 and the flight day is domestic or     ***/
/*** transoceanic.  If the flight day is domestic                      ***/
/*** (ie: flt_arpt_pr_typ_cd=DM) the pass_typ_cd will be changed from  ***/
/*** '90' to '20'.  If the flight day is transoceanic                  ***/
/*** (ie: flt_arpt_pr_typ_cd=TP or TA) the pass_typ_cd will be changed ***/
/*** from '90' to '40'.                                                ***/

 if ( strncmp(A04317.A04317_appl_area.sPassTypCd,"90",2) == 0 )
 {
   /*** execute service to get remaining allotment row ****/
   memset(&R02688.R02688_appl_area,LOW_VALUES, sizeof(R02688.R02688_appl_area));
   memset(&A02688,LOW_VALUES,sizeof(A02688));
   strcpy(R02688.R02688_appl_area.sPprNbr, A04317.A04317_appl_area.sPprNbr);
   strcpy(R02688.R02688_appl_area.sNrevNbr, A04317.A04317_appl_area.sNrevNbr);
   strcpy(R02688.R02688_appl_area.sPassTypCd, A04317.A04317_appl_area.sPassTypCd);

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02688,&A02688,SERVICE_ID_02688,1,sizeof(R02688.R02688_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
     case ARC_SUCCESS:
       pTemp = UTL_ConvertDate(A02688.A02688_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
       strcpy(A02688.A02688_appl_area.sPassRptSortDt, pTemp);
       if (strcmp(A04317.A04317_appl_area.sPassRptSortDt,A02688.A02688_appl_area.sPassRptSortDt) < 0)
         PRIOR_PER_REMN_ALLOT = 'Y';
       break;
     case ARC_ROW_NOT_FOUND:
       break;
     default:
       BCH_FormatMessage(1,TXT_SVC_UNSUCC);
       BCH_FormatMessage(2,TXT_SVC, "FYS02688");
       sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sPassTypCd = %s",
                       R02688.R02688_appl_area.sPprNbr,
                       R02688.R02688_appl_area.sNrevNbr,
                       R02688.R02688_appl_area.sPassTypCd);
       BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
       BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessRows");
   }
   if ( PRIOR_PER_REMN_ALLOT == 'N' )
   {
     memset(&R04650.R04650_appl_area,LOW_VALUES,sizeof(R04650.R04650_appl_area));
     memset(&A04650,LOW_VALUES,sizeof(A04650));
     strcpy(R04650.R04650_appl_area.sPprNbr,A04317.A04317_appl_area.sPprNbr);
     strcpy(R04650.R04650_appl_area.sNrevNbr,A04317.A04317_appl_area.sNrevNbr);
     strcpy(R04650.R04650_appl_area.sPassTypCd,A04317.A04317_appl_area.sPassTypCd);
     nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04650,&A04650,SERVICE_ID_04650,1,sizeof(R04650.R04650_appl_area));

     switch (nSvcRtnCd)
     {
       case ARC_SUCCESS:
         break;
       case ARC_ROW_NOT_FOUND:
         break;
       default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04650");
         sprintf(sErrorMessage,"%s","Service was unsuccessful.  Process aborted.");
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessRows");
     }
   }
   else if ( PRIOR_PER_REMN_ALLOT == 'Y' )
   {
     memset(&R04655.R04655_appl_area,LOW_VALUES,sizeof(R04655.R04655_appl_area));
     memset(&A04655,LOW_VALUES,sizeof(A04655));
     strcpy(R04655.R04655_appl_area.sPprNbr,A04317.A04317_appl_area.sPprNbr);
     strcpy(R04655.R04655_appl_area.sNrevNbr,A04317.A04317_appl_area.sNrevNbr);
     strcpy(R04655.R04655_appl_area.sPassTypCd,A04317.A04317_appl_area.sPassTypCd);
     nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04655,&A04655,SERVICE_ID_04655,1,sizeof(R04655.R04655_appl_area));

     switch (nSvcRtnCd)
     {
       case ARC_SUCCESS:
         break;
       case ARC_ROW_NOT_FOUND:
         break;
       default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04655");
         sprintf(sErrorMessage,"%s","Service was unsuccessful.  Process aborted.");
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessRows");
     }
   }

   if (nSvcRtnCd == ARC_SUCCESS)
   {
     if ( PRIOR_PER_REMN_ALLOT == 'N' )
     {
       memset(&R04651.R04651_appl_area,LOW_VALUES,sizeof(R04651.R04651_appl_area));
       memset(&A04651,LOW_VALUES,sizeof(A04651));
       strcpy(R04651.R04651_appl_area.sPprNbr,A04317.A04317_appl_area.sPprNbr);
       strcpy(R04651.R04651_appl_area.sNrevNbr,A04317.A04317_appl_area.sNrevNbr);
       strcpy(R04651.R04651_appl_area.sFltArptPrTypCd,A04317.A04317_appl_area.sFltArptPrTypCd);
       nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04651,&A04651,SERVICE_ID_04651,1,sizeof(R04651.R04651_appl_area));

       switch (nSvcRtnCd)
       {
         case ARC_SUCCESS:
           break;
         case ARC_ROW_NOT_FOUND:
           break;
         default:
           BCH_FormatMessage(1,TXT_SVC_UNSUCC);
           BCH_FormatMessage(2,TXT_SVC, "FYS04651");
           sprintf(sErrorMessage,"%s","Service was unsuccessful.  Process aborted.");
           BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
           BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessRows");
       }
     }
     else if ( PRIOR_PER_REMN_ALLOT == 'Y' )
     {
       memset(&R04656.R04656_appl_area,LOW_VALUES,sizeof(R04656.R04656_appl_area));
       memset(&A04656,LOW_VALUES,sizeof(A04656));
       strcpy(R04656.R04656_appl_area.sPprNbr,A04317.A04317_appl_area.sPprNbr);
       strcpy(R04656.R04656_appl_area.sNrevNbr,A04317.A04317_appl_area.sNrevNbr);
       strcpy(R04656.R04656_appl_area.sFltArptPrTypCd,A04317.A04317_appl_area.sFltArptPrTypCd);
       nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04656,&A04656,SERVICE_ID_04656,1,sizeof(R04656.R04656_appl_area));

       switch (nSvcRtnCd)
       {
         case ARC_SUCCESS:
           break;
         case ARC_ROW_NOT_FOUND:
           break;
         default:
           BCH_FormatMessage(1,TXT_SVC_UNSUCC);
           BCH_FormatMessage(2,TXT_SVC, "FYS04656");
           sprintf(sErrorMessage,"%s","Service was unsuccessful.  Process aborted.");
           BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
           BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessRows");
       }
     }
     if ( nSvcRtnCd == ARC_SUCCESS)
     {
       R04317.R04317_appl_area.cArchCursorOpTxt = UPDATE_ROW;
       strcpy(R04317.R04317_appl_area.sProcDt,LOW_DATE);
       if ( PRIOR_PER_REMN_ALLOT == 'N' )
         strcpy(A04317.A04317_appl_area.sPassTypCd,A04651.A04651_appl_area.sPassTypCd);
       else if ( PRIOR_PER_REMN_ALLOT == 'Y' )
         strcpy(A04317.A04317_appl_area.sPassTypCd,A04656.A04656_appl_area.sPassTypCd);

       /****** Execute service to update database        ****/
       nSvcRtnCd = BCH_InvokeService(EPBUPD4,&R04317,&A04317,SERVICE_ID_04317,1,sizeof(R04317.R04317_appl_area));

       /****** Service Return Code Processing  ****/
       switch (nSvcRtnCd)
       {
         case ARC_SUCCESS:
           if ( PRIOR_PER_REMN_ALLOT == 'N' )
             strcpy(save_fltleg_data.sSavePassTyp,A04651.A04651_appl_area.sPassTypCd);
           else if ( PRIOR_PER_REMN_ALLOT == 'Y' )
             strcpy(save_fltleg_data.sSavePassTyp,A04656.A04656_appl_area.sPassTypCd);
           break;
         default:
           BCH_FormatMessage(1,TXT_SVC_UNSUCC);
           BCH_FormatMessage(2,TXT_SVC, "FYS04317");
           BCH_FormatMessage(3,TXT_FLT_LEG_UPDATE_ERR, save_fltleg_data.sSavePprNbr,
                                                        save_fltleg_data.sSaveNrevNbr,
                                                        save_fltleg_data.sSaveFltNbr,
                                                        save_fltleg_data.sSaveDprtDt);
           BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessRows");
       }
     }
   }
 }


/*** First, perform service charge and international fee function                       ***/

      DPM_3000_CalcChgsAndFees();

/*** next, set the process date to today to show that this leg has been processed ***/

      /****** Initialize Request Block for service to update the process date to today    *****/
      R04317.R04317_appl_area.cArchCursorOpTxt = UPDATE_ROW;
      strcpy(R04317.R04317_appl_area.sProcDt, sCurrentTsDt);

      /****** Execute service to update database        ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD4,&R04317,&A04317,SERVICE_ID_04317,1,sizeof(R04317.R04317_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04317");
            BCH_FormatMessage(3,TXT_FLT_LEG_UPDATE_ERR, save_fltleg_data.sSavePprNbr,
                                                        save_fltleg_data.sSaveNrevNbr,
                                                        save_fltleg_data.sSaveFltNbr,
                                                        save_fltleg_data.sSaveDprtDt);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessRows");
         }

/*** after processing this row, increment the leg counter  and then get the next row ***/
   RS.sFltLegCnt++;

   R04317.R04317_appl_area.cArchCursorOpTxt = FETCH_ROW;
   memset(&A04317,LOW_VALUES,sizeof(A04317));

   nSvcRtnCd = BCH_InvokeService(EPBUPD4,&R04317,&A04317,SERVICE_ID_04317,1,sizeof(R04317.R04317_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
	 pTemp = UTL_ConvertDate(A04317.A04317_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	 strcpy(A04317.A04317_appl_area.sPassRptSortDt, pTemp);
         DPM_4100_SaveFltlegData();
         break;

      case ARC_ROW_NOT_FOUND:
         cEndOfFltlegData = YES_CHAR;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04317");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2200_ProcessRows");
       }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2300_ProcessImpFltlegs                   **
**                                                               **
** Description:     This function reads each of the items on the **
** imputed flight leg table and begins the process to calculate  **
** service charges and international fees.  This function calls  **
** the same functions as DPM_2100_ProceesFltlegs.  After         **
** processing each imputed flight leg, the process date is set to**
** today.                                                        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2300_ProcessImpFltlegs()
{
   char      *pTemp;
   short     nSvcRtnCd;      /* Service return code */
   cImpFltlegInd = YES_CHAR;
   cBdyFltlegInd = NO_CHAR;
   cEndOfImpFltlegData = NO_CHAR;
   nDayIndex = 0;

      /****** Initialize Request and Answer Blocks for service to retreive 1st Imputed    *****
       ****** Flight Leg row that has not been processed (process date = 12/31/1899)      *****/
      memset(&R04343.R04343_appl_area,LOW_VALUES, sizeof(R04343.R04343_appl_area));
      memset(&A04343,LOW_VALUES,sizeof(A04343));
      strcpy(R04343.R04343_appl_area.sProcDt, LOW_DATE);
      R04343.R04343_appl_area.lFltChrgRfrnDt = lRfrnDt;
      R04343.R04343_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

      /****** Execute service to retrieve driving rows  ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD5,&R04343,&A04343,SERVICE_ID_04343,1,sizeof(R04343.R04343_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
	    pTemp = UTL_ConvertDate(A04343.A04343_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	    strcpy(A04343.A04343_appl_area.sPassRptSortDt, pTemp);
            DPM_4100_SaveFltlegData();
            break;

         case ARC_ROW_NOT_FOUND:
            cEndOfImpFltlegData = YES_CHAR;
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2300_ProcessImpFltlegs");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04343");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2300_ProcessImpFltlegs");
         }


 /**** Process Imputed flight leg items      ****/
   while (cEndOfImpFltlegData == NO_CHAR)
      {
      DPM_2400_ProcessRows();
      }

/*** After processing all of the Imputed flight legs, make sure that the day process has been done for ***/
/*** the last group of flight legs.                                                                    ***/
   if (nDayIndex != 0)
       DPM_3050_DayProcess();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2400_ProcessRows                         **
**                                                               **
** Description:     Process Imputed Flight Leg Table until end   **
**                  of rows                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2400_ProcessRows()
{
   short     nSvcRtnCd;      /* Service return code */
   char      *pTemp;

/*** perform service charge and international fee function only if DL flight leg ***/
   if (strcmp(A04343.A04343_appl_area.sTktNbr, TKT_NBR_NINES) == 0)
      {
      DPM_3000_CalcChgsAndFees();
      }

/*** next, set the process date to today to show that this leg has been processed ***/

      /****** Initialize Request Block for service to update the process date to today    *****/
      R04343.R04343_appl_area.cArchCursorOpTxt = UPDATE_ROW;
      strcpy(R04343.R04343_appl_area.sProcDt, sCurrentTsDt);

      /****** Execute service to update database        ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD5,&R04343,&A04343,SERVICE_ID_04343,1,sizeof(R04343.R04343_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04343");
            BCH_FormatMessage(3,TXT_FLT_LEG_UPDATE_ERR, save_fltleg_data.sSavePprNbr,
                                                        save_fltleg_data.sSaveNrevNbr,
                                                        save_fltleg_data.sSaveFltNbr,
                                                        save_fltleg_data.sSaveDprtDt);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2400_ProcessRows");
         }

/*** Finally increment the leg counter and then get the next row ***/
   RS.sImpFltLegCnt++;

   R04343.R04343_appl_area.cArchCursorOpTxt = FETCH_ROW;
   memset(&A04343,LOW_VALUES,sizeof(A04343));
   nSvcRtnCd = BCH_InvokeService(EPBUPD5,&R04343,&A04343,SERVICE_ID_04343,1,sizeof(R04343.R04343_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
	 pTemp = UTL_ConvertDate(A04343.A04343_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	 strcpy(A04343.A04343_appl_area.sPassRptSortDt, pTemp);
         DPM_4100_SaveFltlegData();
         break;

      case ARC_ROW_NOT_FOUND:
         cEndOfImpFltlegData = YES_CHAR;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04343");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2400_ProcessRows");
       }
}
/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessBdyFltlegs                   **
**                                                               **
** Description:     This function reads each of the items on the **
** bdy flight leg table and begins the process to                **
** calculate service charges and international fees.  After      **
** processing each flight leg, the process date is set to today. **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2500_ProcessBdyFltlegs()
{
   short     nSvcRtnCd;      /* Service return code */
   char *pTemp;
   cImpFltlegInd = NO_CHAR;
   cBdyFltlegInd = YES_CHAR;
   cEndOfBdyFltlegData = NO_CHAR;
   nDayIndex = 0;

      /****** Initialize Request and Answer Blocks for service to retreive 1st flight leg *****
       ****** row that has not been processed (process date = 12/31/1899)                 *****/
      memset(&R04417.R04417_appl_area,LOW_VALUES, sizeof(R04417.R04417_appl_area));
      memset(&A04417,LOW_VALUES,sizeof(A04417));
      strcpy(R04417.R04417_appl_area.sProcDt, LOW_DATE);
      R04417.R04417_appl_area.lFltChrgRfrnDt = lRfrnDt;
      R04417.R04417_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

      /****** Execute service to retrieve driving rows  ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD6,&R04417,&A04417,SERVICE_ID_04417,1,sizeof(R04417.R04417_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
	    pTemp = UTL_ConvertDate(A04417.A04417_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	    strcpy(A04417.A04417_appl_area.sPassRptSortDt, pTemp);
            DPM_4100_SaveFltlegData();
            break;

         case ARC_ROW_NOT_FOUND:
            cEndOfBdyFltlegData = YES_CHAR;
            BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
            BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2500_ProcessBdyFltlegs");
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04417");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessBdyFltlegs");
         }

 /**** Process flight leg items      ****/
   while (cEndOfBdyFltlegData == NO_CHAR)
   {
      DPM_2600_ProcessRows();
   }

}
/******************************************************************
**                                                               **
** Function Name:   DPM_2600_ProcessRows                         **
**                                                               **
** Description:     Process Buddydy Flight Leg Table until end   **
**                  of rows                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_2600_ProcessRows()
{
   char      *pTemp;
   short     nSvcRtnCd;      /* Service return code */


/*** First, perform service charge and international fee function                       ***/

   DPM_3010_CalcBuddyFees();

/*** next, set the process date to today to show that this leg has been processed ***/

      /****** Initialize Request Block for service to update the process date to today    *****/
      R04417.R04417_appl_area.cArchCursorOpTxt = UPDATE_ROW;
      strcpy(R04417.R04417_appl_area.sProcDt, sCurrentTsDt);

      /****** Execute service to update database        ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD6,&R04417,&A04417,SERVICE_ID_04417,1,sizeof(R04417.R04417_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04417");
            BCH_FormatMessage(3,TXT_FLT_LEG_UPDATE_ERR, save_fltleg_data.sSavePprNbr,
                                                        save_fltleg_data.sSaveNrevNbr,
                                                        save_fltleg_data.sSaveFltNbr,
                                                        save_fltleg_data.sSaveDprtDt);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_ProcessRows");
         }

/*** after processing this row, increment the leg counter  and then get the next row ***/
   RS.sBdyFltLegCnt++;

   R04417.R04417_appl_area.cArchCursorOpTxt = FETCH_ROW;
   memset(&A04417,LOW_VALUES,sizeof(A04417));

   nSvcRtnCd = BCH_InvokeService(EPBUPD6,&R04417,&A04417,SERVICE_ID_04417,1,sizeof(R04417.R04417_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
	 pTemp = UTL_ConvertDate(A04417.A04417_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	 strcpy(A04417.A04417_appl_area.sPassRptSortDt, pTemp);
         DPM_4100_SaveFltlegData();
         break;

      case ARC_ROW_NOT_FOUND:
         cEndOfBdyFltlegData = YES_CHAR;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04417");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_ProcessRows");
       }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3000_CalcChgsAndFees                     **
**                                                               **
** Description:     This function begins the process to calculate**
** service charges and international fees.  First, the function  **
** calculates all of the day type charges for a group of flight  **
** legs with the same ppr/nrev/rfrn dt.  Then, this function     **
** gathers all of the needed information from the various tables **
** for the new ppr/nrev/rfrn dt.  Next, any leg-type charges are **
** calculated, such as, Honor Roll/intl abuse penalties, first   **
** or business class premiums and international fees.  Finally,  **
** the information for each flight leg is saved in an array to   **
** be used by day processing.                                    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3000_CalcChgsAndFees()
{
   short     nSvcRtnCd;      /* Service return code */

   /*** Determine if this is a new group of flight legs for day processing        ***/
   if (strcmp(save_fltleg_data.sSavePprNbr, sOldPprNbr) != 0     ||
       strcmp(save_fltleg_data.sSaveNrevNbr, sOldNrevNbr) != 0   ||
       save_fltleg_data.lSaveRfrnDt != lOldRfrnDt)
      {
      if (cFirstTimeInd == NO_CHAR)  /* If this is not the first time thru, do day processing */
         {
         DPM_3050_DayProcess();
         nDayIndex = 0;
         }
      else
         cFirstTimeInd = NO_CHAR;

      lOldRfrnDt = save_fltleg_data.lSaveRfrnDt;

     /*** Get the birthday, nrev type code, board/miles indicator, pass group code,       ***
      *** imputed indicator, and months of service from the PPR and Nrev Psgr Tables if   ***
      *** we havent already gotten this information                                       ***/
      if (strcmp(save_fltleg_data.sSavePprNbr, sOldPprNbr) != 0     ||
          strcmp(save_fltleg_data.sSaveNrevNbr, sOldNrevNbr) != 0)
      {
         memset(&R02652.R02652_appl_area,LOW_VALUES, sizeof(R02652.R02652_appl_area));  /* Initialize Request  */
         memset(&A02652,LOW_VALUES,sizeof(A02652));                                     /* and Answer block    */
         strcpy(R02652.R02652_appl_area.sPprNbr, save_fltleg_data.sSavePprNbr);
         strcpy(R02652.R02652_appl_area.sNrevNbr, save_fltleg_data.sSaveNrevNbr);

         /****** Execute service to get PPR and Nrev data  ****/
         nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02652,&A02652,SERVICE_ID_02652,1,sizeof(R02652.R02652_appl_area));

         /****** Service Return Code Processing  ****/
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               strcpy(sOldPprNbr, save_fltleg_data.sSavePprNbr);
               strcpy(sOldNrevNbr, save_fltleg_data.sSaveNrevNbr);
               break;

            case ARC_ROW_NOT_FOUND:
               BCH_FormatMessage(1,TXT_ROW_NOT_FOUND);
               BCH_FormatMessage(2,TXT_SVC, "FYS02652");
               BCH_FormatMessage(3,TXT_PPR_NREV_NOT_FOUND, R02652.R02652_appl_area.sPprNbr,
                                                        R02652.R02652_appl_area.sNrevNbr);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_CalcChgsAndFees");

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS02652");
               sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s",
                          R02652.R02652_appl_area.sPprNbr,
                          R02652.R02652_appl_area.sNrevNbr);
               BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_CalcChgsAndFees");
         }
      }
   }

   /*** go get all necessary information to calculate charges and fees ***/
   memset(&F3100_data, LOW_VALUES, sizeof(F3100_data));
   strcpy(F3100_data.sOrigCty, save_fltleg_data.sSaveOrig);
   strcpy(F3100_data.sDestCty, save_fltleg_data.sSaveDest);
   DPM_3100_GetRelatedInfo();
   save_fltleg_data.cSaveOrigIntlInd = F3100_data.cOrigIntlInd;
   save_fltleg_data.cSaveDestIntlInd = F3100_data.cDestIntlInd;
   strcpy(save_fltleg_data.sSaveOrigRegCd, F3100_data.sOrigReg);
   strcpy(save_fltleg_data.sSaveDestRegCd, F3100_data.sDestReg);

   /*** calculate penalty for transoceanic travel with honor roll pass     ***/
   if (strcmp(save_fltleg_data.sSavePassTyp, HONOR_ROLL) == 0    &&
       (strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, TRANSATLANTIC) == 0  ||
       strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, TRANSPACIFIC)  == 0))
   {
      strcpy(sChargeCd, HONORROLL_PENALTY_INTL);
      strcpy(sPassTypCd, save_fltleg_data.sSavePassTyp);
      DPM_3600_CalcLegChgs();
   }

   /*** Calculate premiums for first or business class travel   ***/
   if (strcmp(save_fltleg_data.sSaveClass, FIRST_CLASS) == 0     ||
       strcmp(save_fltleg_data.sSaveClass, BUSINESS_CLASS) == 0)
   {
      /*** determine whether to use the domestic or transoceanic premium charge ***/
      if (strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, TRANSATLANTIC)  == 0    ||
          strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, TRANSPACIFIC) == 0)
         strcpy(sPassTypCd, TRANSOCEANIC);
      else
         strcpy(sPassTypCd, DOMESTIC);
      strcpy(sChargeCd, PREMIUM_CHARGE);
      DPM_3600_CalcLegChgs();
   }

   /*** Calculate international fees for all items except reduced rate travel    ***/
   /*** senior officers, and positive space travel.            ***/

      if (A02652.A02652_appl_area.cPassImptInd != REDUCED_RATE &&
       strcmp(A02652.A02652_appl_area.sPassGrpCd,  SENIOR_OFFICERS) != 0  &&
       strcmp(A02652.A02652_appl_area.sPassGrpCd,  SENIOR_OFFICERS_WK) != 0  &&
       strcmp(A02652.A02652_appl_area.sPassGrpCd,  SENIOR_OFFICERS_MRD) != 0)
      DPM_3700_CalcIntlFees();

   /*** Calculate international fees for employees only in the FP and FV         ***/
   /*** pass groups.                     8-29-08 (L.Scott)     ***/

      if (A02652.A02652_appl_area.cPassImptInd == REDUCED_RATE &&
       (strcmp(A02652.A02652_appl_area.sPassGrpCd,  FURL_PILOT) == 0  ||
       strcmp(A02652.A02652_appl_area.sPassGrpCd,  FURL_INACTIVE) == 0)  &&
       strcmp(A02652.A02652_appl_area.sNrevTypCd,  SELF) == 0)
      DPM_3700_CalcIntlFees();

   /*** determine if the airport pair is transoeanic, transatlantic, Hawaiian***/
   /*** or Alaskan, to help with the S2 processing when spanning two days of travel ***/

      if (strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, TRANSATLANTIC)  == 0    ||
          strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, TRANSPACIFIC) == 0 ||
          strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, HAWAII ) == 0   ||
          strcmp(A02792.A02792_appl_area.sFltArptPrTypCd, ALASKA) == 0)
	  {
	  cTransHawaiiAlaska = YES_CHAR;
	  }

   /*** Finally, save all of the flight leg information for a ppr/nrev in an array   ***/
   strcpy(day_data[nDayIndex].sOrigCty, save_fltleg_data.sSaveOrig);
   strcpy(day_data[nDayIndex].sDestCty, save_fltleg_data.sSaveDest);
   strcpy(day_data[nDayIndex].sDprtDt, save_fltleg_data.sSaveDprtDt);
   day_data[nDayIndex].nDprtTm =  save_fltleg_data.nSaveDprtTm;
   strcpy(day_data[nDayIndex].sSortDprtDt, save_fltleg_data.sSaveSortDprtDt);
   strcpy(day_data[nDayIndex].sPassTyp, save_fltleg_data.sSavePassTyp);
   strcpy(day_data[nDayIndex].sArptPrTyp, A02792.A02792_appl_area.sFltArptPrTypCd);
   day_data[nDayIndex].lMilesFlown =  A02792.A02792_appl_area.lFltArptPrNbr;
   day_data[nDayIndex].cOrigIntlInd =  save_fltleg_data.cSaveOrigIntlInd;
   strcpy(day_data[nDayIndex].sOrigReg, save_fltleg_data.sSaveOrigRegCd);
   day_data[nDayIndex].cDestIntlInd = save_fltleg_data.cSaveDestIntlInd;
   strcpy(day_data[nDayIndex].sDestReg, save_fltleg_data.sSaveDestRegCd);

   nDayIndex++;
}
/******************************************************************
**                                                               **
** Function Name:   DPM_3010_CalcBuddyFees()                     **
**                                                               **
** Description:     This function begins the process to calculate**
** international fees for Buddy Nrev Passenger.Then,this function**
** gathers all of the needed information from the various tables **
** for the new ppr/nrev/rfrn dt.  Next, international fees are   **
** calculated, 				                                     **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3010_CalcBuddyFees()
{
   short     nSvcRtnCd;      /* Service return code */

   /*** Get the birthday, nrev type code, board/miles indicator, pass group code,       ***
   *** imputed indicator, and months of service from the PPR and Buddy Nrev Psgr Tables if   ***
      *** we havent already gotten this information                                       ***/
      if (strcmp(save_fltleg_data.sSavePprNbr, sOldPprNbr) != 0     ||
          strcmp(save_fltleg_data.sSaveNrevNbr, sOldNrevNbr) != 0)
      {
         memset(&R02653.R02653_appl_area,LOW_VALUES, sizeof(R02653.R02653_appl_area));  /* Initialize Request  */
         memset(&A02653,LOW_VALUES,sizeof(A02653));                                     /* and Answer block    */
         strcpy(R02653.R02653_appl_area.sPprNbr, save_fltleg_data.sSavePprNbr);
         strcpy(R02653.R02653_appl_area.sNrevNbr, save_fltleg_data.sSaveNrevNbr);

         /****** Execute service to get PPR and Nrev data  ****/
         nSvcRtnCd = BCH_InvokeService(EPBINQ3,&R02653,&A02653,SERVICE_ID_02653,1,sizeof(R02653.R02653_appl_area));

         /****** Service Return Code Processing  ****/
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               strcpy(A02652.A02652_appl_area.sNrevBdayDt,A02653.A02653_appl_area.sNrevBdayDt);
               strcpy(A02652.A02652_appl_area.sNrevTypCd,A02653.A02653_appl_area.sNrevTypCd);
               A02652.A02652_appl_area.cNrevDyMiInd = A02653.A02653_appl_area.cNrevDyMiInd;
               A02652.A02652_appl_area.cPassImptInd = A02653.A02653_appl_area.cPassImptInd;
               strcpy(A02652.A02652_appl_area.sPassStsCd,A02653.A02653_appl_area.sPassStsCd);
               strcpy(A02652.A02652_appl_area.sPassGrpCd,A02653.A02653_appl_area.sPassGrpCd);
               A02652.A02652_appl_area.nFltMoSvcNbr = A02653.A02653_appl_area.nFltMoSvcNbr;
               strcpy(A02652.A02652_appl_area.sPprStnId,A02653.A02653_appl_area.sPprStnId);
               A02652.A02652_appl_area.nPassAnsRowsNbr = A02653.A02653_appl_area.nPassAnsRowsNbr;
               strcpy(A02652.A02652_appl_area.sCtryCtznpCd,A02653.A02653_appl_area.sCtryCtznpCd);
               strcpy(sOldPprNbr, save_fltleg_data.sSavePprNbr);
               strcpy(sOldNrevNbr, save_fltleg_data.sSaveNrevNbr);
               break;

            case ARC_ROW_NOT_FOUND:
               BCH_FormatMessage(1,TXT_ROW_NOT_FOUND);
               BCH_FormatMessage(2,TXT_SVC, "FYS02653");
               BCH_FormatMessage(3,TXT_PPR_NREV_NOT_FOUND, R02653.R02653_appl_area.sPprNbr,
                                                        R02653.R02653_appl_area.sNrevNbr);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3010_CalcBuddyFees");

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS02653");
               sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s",
                          R02653.R02653_appl_area.sPprNbr,
                          R02653.R02653_appl_area.sNrevNbr);
               BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3010_CalcBuddyFees");
         }
      }

   /*** go get all necessary information to calculate charges and fees ***/
   memset(&F3100_data, LOW_VALUES, sizeof(F3100_data));
   strcpy(F3100_data.sOrigCty, save_fltleg_data.sSaveOrig);
   strcpy(F3100_data.sDestCty, save_fltleg_data.sSaveDest);
   DPM_3100_GetRelatedInfo();
   save_fltleg_data.cSaveOrigIntlInd = F3100_data.cOrigIntlInd;
   save_fltleg_data.cSaveDestIntlInd = F3100_data.cDestIntlInd;
   strcpy(save_fltleg_data.sSaveOrigRegCd, F3100_data.sOrigReg);
   strcpy(save_fltleg_data.sSaveDestRegCd, F3100_data.sDestReg);

   DPM_3700_CalcIntlFees();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_3050_DayProcess                          **
**                                                               **
** Description:     This function begins the process to calculate**
** any charges that apply to an entire day's travel, such as     **
** service charges and most penalties.  Finally, the Remaining   **
** Allotment day or mileage amount is decremented.               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3050_DayProcess()
{
   short     nSvcRtnCd;      /* Service return code */
   char      *pTemp;


   nLegCnt = --nDayIndex;   /* Number of legs for ppr/nrev */
   nDayIndex = 0;
   nDprtTm = 0;
   nPriorityDprtTm = 0;
   cAllotFound = YES_CHAR;
   strcpy(sDayPassTyp, "99");
   cTransOceanicInd = NO_CHAR;
   cFltPenaltyInd = NO_CHAR;
   cSuspRvkInd = NO_CHAR;
   lTotalMilesFlown = 0;
   cDisableTransOceanicInd = NO_CHAR;
   cParentOfAssocInd = NO_CHAR;
   cTransOceanicSvcChrgInd = NO_CHAR;
   cSkipPriority = NO_CHAR;
   cFirstPriority = NO_CHAR;

/*** First, determine the pass type for the day.  The pass types have numeric values ***/
/*** and have been assigned according to their priority.  The lowest value has the   ***/
/*** highest priority. Also, determine if a transoceanic leg exists, and add up the  ***/
/*** total mileage                                                                   ***/
   while (nDayIndex <= nLegCnt)
   {
     if (strcmp(day_data[nDayIndex].sPassTyp, sDayPassTyp) < 0)
         strcpy(sDayPassTyp, day_data[nDayIndex].sPassTyp);
         nDprtTm = day_data[nDayIndex].nDprtTm;
     if (strcmp(sDayPassTyp, PRIORITY) == 0 &&
	 cFirstPriority == NO_CHAR)
	 {
	 nPriorityDprtTm = nDprtTm;
	 cFirstPriority = YES_CHAR;
	 }
     if (strcmp(day_data[nDayIndex].sArptPrTyp, TRANSATLANTIC) == 0  ||
         strcmp(day_data[nDayIndex].sArptPrTyp, TRANSPACIFIC) == 0)
           cTransOceanicInd = YES_CHAR;
     lTotalMilesFlown += day_data[nDayIndex].lMilesFlown;
     nDayIndex++;
   }

/*** Next, determine if this is the parent of a single assoc flying domestic or transoceanic ***/
/*** there is some special processing of allotments for this case.                           ***/
   if (strcmp(A02652.A02652_appl_area.sNrevTypCd, PARENT) == 0      &&
       strcmp(A02652.A02652_appl_area.sPassGrpCd, TEMPDL_SINGLE) == 0   &&
       strcmp(sDayPassTyp, TRANSOCEANIC) == 0)
           cParentOfAssocInd = 'T';
   if (strcmp(A02652.A02652_appl_area.sNrevTypCd, PARENT) == 0      &&
       strcmp(A02652.A02652_appl_area.sPassGrpCd, TEMPDL_SINGLE) == 0   &&
       strcmp(sDayPassTyp, DOMESTIC) == 0)
           cParentOfAssocInd = 'D';


/*** Next, if the reference date of the flight leg is less than the process reference date, ***/
/*** which indicates that this is data that came in late, perform special processing which  ***/
/*** checks to see if any day charges previously applied need to be refunded.               ***/
   cContDayProcInd = YES_CHAR;
   if (lOldRfrnDt < lRfrnDt)
   {
      DPM_3800_OldDataProcess();
   }

   /*** cContDayProcInd is only set (in DPM_3800_OldDataProcess) to NO when the day pass type ***/
   /*** changes for a previously processed day. no further processing is necessay in this case***/
   if (cContDayProcInd == NO_CHAR)
      return;

/*** check for priority passes - LAS ***/
   if (strcmp(sDayPassTyp, PRIORITY) == 0) 
   {
      DPM_3900_OldPriority();
   }

/*** Next,  get the remaining boarding quantity and remaining mileage quantity     ***/
/*** from the Remaining Allotment Table.                                           ***/
   strcpy(sPassTyp, sDayPassTyp);

   /*** if the pass group is PANAM, only the ppr's remaining domestic allotment should be decremented ***/
   if (strcmp(A02652.A02652_appl_area.sPassGrpCd, PANAM) == 0)
   {
      strcpy(sPassTyp, COMB_DOM_TO); /* change from DOMESTIC  sir 25 kch 1/96 */
      strcpy(sNrevNbr, "00");
   }
   else
      strcpy(sNrevNbr, sOldNrevNbr);

   /*** If one of the disabled pass groups, psgr type is self or spouse, at least 120 months of      ***/
   /*** service, and this is a transoceanic day, both the domestic and transoceanic allotment should***/
   /*** be decremented, starting with the domestic allotment.                                       ***/
   /*********WITH THE EXCEPTION OF 120 MONTHS OF SERVICE THE SAME SHOULD HOLD FOR THE FOLLOWING     ***/
   /**** Pass group GS for SF, ST, MC and DA                                            ****/
   /**** Pass group GT for SF, SP, MC, ST and DA                                        ****/
   /**** Pass group GR for SF and PR                                                    ****/
   /****************************************************************************************/

  if (((strcmp(A02652.A02652_appl_area.sPassGrpCd, DISABLED_DL_SDW) == 0       ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, DISABLED_DL_MRD) == 0       ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, DISABLED_LIM_WIDOW) == 0    ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, RETIRED_EARLY_SIX) == 0     ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, WORLDSPAN_DSABLD_SDW) == 0  ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, WORLDSPAN_DSABLD_MRD) == 0)    &&
       (strcmp(A02652.A02652_appl_area.sNrevTypCd, SELF) == 0                  ||
        strcmp(A02652.A02652_appl_area.sNrevTypCd, SPOUSE) == 0                ||
        strcmp(A02652.A02652_appl_area.sNrevTypCd, COMPANION) == 0)            &&
        A02652.A02652_appl_area.nFltMoSvcNbr >= 120                            &&
        strcmp(sDayPassTyp, TRANSOCEANIC) == 0)                                ||

      ((strcmp(A02652.A02652_appl_area.sPassGrpCd, DGS_TEMP_STAFF_SDW_WK) == 0   ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, DGS_TEMP_STAFF_MRD) == 0      ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, DGS_TEMP_STAFF_SDW) == 0)     &&
       (strcmp(A02652.A02652_appl_area.sNrevTypCd, SELF) == 0                    ||
        strcmp(A02652.A02652_appl_area.sNrevTypCd, SPOUSE) == 0                  ||
        strcmp(A02652.A02652_appl_area.sNrevTypCd, DEP_CHILD) == 0               ||
        strcmp(A02652.A02652_appl_area.sNrevTypCd, DEP_CHILD_STUDENT) == 0       ||
        strcmp(A02652.A02652_appl_area.sNrevTypCd, DEP_ADULT) == 0)              &&
        strcmp(sDayPassTyp, TRANSOCEANIC) == 0)                                  ||

     ((strcmp(A02652.A02652_appl_area.sPassGrpCd, DGS_TEMP_STAFF_SDW) == 0       ||
       strcmp(A02652.A02652_appl_area.sPassGrpCd, DGS_TEMP_STAFF_SDW_WK) == 0    ||
       strcmp(A02652.A02652_appl_area.sPassGrpCd, DGS_AVTN_SEC_SDW_WK) == 0)     &&
       strcmp(A02652.A02652_appl_area.sNrevTypCd, PARENT) == 0                   &&
       strcmp(sDayPassTyp, TRANSOCEANIC) == 0))
      {
      strcpy(sPassTyp, DOMESTIC);
      cDisableTransOceanicInd = YES_CHAR;
      }

   DPM_3110_GetRemainAllot();
   if (cAllotment == NO_CHAR)
      cAllotFound = NO_CHAR;


  if (A02652.A02652_appl_area.cNrevDyMiInd == MILEAGE)
      lPrevAllot = lRemMiles;
   else
      lPrevAllot = lRemDays;

   /*** next, update the remaining allotments            ***/
   cDecrementInd = YES_CHAR;

   if (cSkipPriority == NO_CHAR)
      {
      DPM_3200_UpdateAllotments(); 
      }
   /*****
      else
      {
      cSkipPriority = NO_CHAR;
      }
   ******/

   cSvcChgCalc = NO_CHAR;

   /*** Reset the pass type to one of the special groups ***/
   if (cDisableTransOceanicInd == YES_CHAR)
      strcpy(sPassTyp, DOMESTIC);

   /*** calculate service charge if dom or trans pass falls below the allotted amount and they are allowed additional passes and not ticketed          ***/
      if ((strcmp(sDayPassTyp, DOMESTIC) == 0 ||
           strcmp(sDayPassTyp, COMB_DOM_TO) == 0 ||
           strcmp(sDayPassTyp, TRANSOCEANIC) == 0)  &&
	   A02652.A02652_appl_area.cPassImptInd != REDUCED_RATE &&
	   A02652.A02652_appl_area.sPassGrpCd != CONN_CARR_PRORATE &&
	/*
        strcmp(A02652.A02652_appl_area.cPassImptInd, REDUCED_RATE) != 0 &&
	*/
       (cAllotFound == YES_CHAR  &&  lPrevAllot <= 0  &&  cAddlPass == YES_CHAR))
      {
      cFlatFeeInd = NO_CHAR;
      cTransOceanicSvcChrgInd = NO_CHAR;
      DPM_3300_CalcSvcChgs();
      }

   /*** calculate service charge if dom or trans pass falls below the allotted amount and they are allowed additional passes and in   pass group FP or FV and nonrev type code is SF.     8-29-08 L.Scott       ***/
      if ((strcmp(sDayPassTyp, DOMESTIC) == 0 ||
           strcmp(sDayPassTyp, COMB_DOM_TO) == 0 ||
           strcmp(sDayPassTyp, TRANSOCEANIC) == 0)  &&
           A02652.A02652_appl_area.cPassImptInd == REDUCED_RATE &&
	   (A02652.A02652_appl_area.sPassGrpCd == FURL_PILOT ||
	   A02652.A02652_appl_area.sPassGrpCd == FURL_INACTIVE) &&
	   A02652.A02652_appl_area.sNrevTypCd == SELF &&
       (cAllotFound == YES_CHAR  &&  lPrevAllot <= 0  &&  cAddlPass == YES_CHAR))
      {
      cFlatFeeInd = NO_CHAR;
      cTransOceanicSvcChrgInd = NO_CHAR;
      DPM_3300_CalcSvcChgs();
      }


   /*** calculate transoceanic service charge if transoceanic allotment falls below the allotted amount and the pass rider is allowed additional passes and is in either CA, CC or CZ pass group.    12-29-10 L.Scott     ***/
      
      if (strcmp(sDayPassTyp, TRANSOCEANIC) == 0  &&
           A02652.A02652_appl_area.cPassImptInd != REDUCED_RATE &&
           cAllotFound == YES_CHAR  && 
	   lPrevAllot <= 0  && 
	   cAddlPass == YES_CHAR &&
	    (strcmp(A02652.A02652_appl_area.sPassGrpCd,"CA")  == 0 ||
	     strcmp(A02652.A02652_appl_area.sPassGrpCd,"CC")  == 0 ||
	     strcmp(A02652.A02652_appl_area.sPassGrpCd,"CZ")  == 0))
    /**** 
      if (strcmp(sDayPassTyp, TRANSOCEANIC) == 0  &&
           A02652.A02652_appl_area.cPassImptInd != REDUCED_RATE &&
	   A02652.A02652_appl_area.sPassGrpCd == CONN_CARR_PRORATE &&
           cAllotFound == YES_CHAR  && 
	   lPrevAllot <= 0  && 
	   cAddlPass == YES_CHAR)
	   ****/

      {
      cTransOceanicSvcChrgInd = YES_CHAR;
      cFlatFeeInd = NO_CHAR;
      DPM_3300_CalcSvcChgs();
      }


   /*** Always calculate flat fee charges for parents flying transoceanic using ***/
   /*** their 90 (COMBO) pass type ***/
   if (strcmp(A02652.A02652_appl_area.sNrevTypCd, PARENT) == 0      &&
       strcmp(sDayPassTyp,  COMB_DOM_TO) == 0                      &&
       cTransOceanicInd == YES_CHAR &&
       A02652.A02652_appl_area.cPassImptInd != REDUCED_RATE)
       /*
       strcmp(A02652.A02652_appl_area.cPassImptInd, REDUCED_RATE) != 0)
       */
       {
         cFlatFeeInd = YES_CHAR;
         cTransOceanicSvcChrgInd = NO_CHAR;
         DPM_3300_CalcSvcChgs();
       }


   /*** calculate a penalty if the passenger's flight priviliges were suspended or revoked ***/
   /*** before the date of the flight leg                                               ***/
    if (strcmp(A02652.A02652_appl_area.sPassStsCd, SUSPENDED) == 0 ||
       strcmp(A02652.A02652_appl_area.sPassStsCd, REVOKED) == 0)
   {
      /*** Go to the comment table to get the suspension or revocation date ***/
      memset(&R04076.R04076_appl_area,LOW_VALUES, sizeof(R04076.R04076_appl_area)); /* initialize request   */
      memset(&A04076,LOW_VALUES,sizeof(A04076));                                    /* and Answer block     */
      strcpy(R04076.R04076_appl_area.sPprNbr, sOldPprNbr);
      strcpy(R04076.R04076_appl_area.sNrevNbr, sOldNrevNbr);
      strcpy(R04076.R04076_appl_area.sPassStsCd, A02652.A02652_appl_area.sPassStsCd);
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04076,&A04076,SERVICE_ID_04076,1,sizeof(R04076.R04076_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
	    pTemp = UTL_ConvertDate(A04076.A04076_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	    strcpy(A04076.A04076_appl_area.sPassRptSortDt, pTemp);
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04076");
            sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sPassStsCd = %s",
                       R04076.R04076_appl_area.sPprNbr,
                       R04076.R04076_appl_area.sNrevNbr,
                       R04076.R04076_appl_area.sPassStsCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3050_DayProcess");
      }
      /***  if the date of the revocation or suspension is before the data of the flight ***/
      /***  then a penalty penalty should be assessed.                                   ***/
      if (strcmp(A04076.A04076_appl_area.sPassRptSortDt, " ") != 0    &&
          strcmp(A04076.A04076_appl_area.sPassRptSortDt, day_data[1].sSortDprtDt) < 0)
      {
         cSuspRvkInd = YES_CHAR;
          DPM_3400_CalcPenalties();  
      }
   }

   /*** calculate penalties for domestic and transoceanic passes if no remaining allotment record found
        or the psgr's allotment is used up and they are not allowed additional passes    ***/
        
   if ((strcmp(sDayPassTyp, DOMESTIC) == 0  || strcmp(sDayPassTyp, TRANSOCEANIC)== 0  ||
        strcmp(sDayPassTyp, COMB_DOM_TO) == 0)   &&
       (cAllotFound == NO_CHAR  || (lPrevAllot <= 0 && cAddlPass == NO_CHAR))   &&
       (cSuspRvkInd = NO_CHAR))
         DPM_3400_CalcPenalties(); 
       

   /*** calculate penalties for all other types of passes if no remaining allotment record found   ***/
   /*** or the psgr's allotment is used up - dont process EM and HR here                           ***/
        
   if (strcmp(sDayPassTyp, DOMESTIC) != 0  &&  strcmp(sDayPassTyp, TRANSOCEANIC)!= 0   &&
        strcmp(sDayPassTyp, COMB_DOM_TO) != 0   &&
        strcmp(sDayPassTyp, HONOR_ROLL) != 0  &&  strcmp(sDayPassTyp, EMERGENCY)!= 0   &&
        strcmp(sDayPassTyp, POSTV_SPACE) != 0  &&  strcmp(sDayPassTyp, CO_BUSINESS)!= 0  &&
      (cAllotFound == NO_CHAR || ((lPrevAllot <= 0)  && (cSkipPriority == NO_CHAR)))   &&
	     (cSuspRvkInd = NO_CHAR))
            DPM_3400_CalcPenalties(); 
         

   /*** issue penalties for Emergency or Honor Roll if they dont have an allotment row       ***/
        
   if (((strcmp(sDayPassTyp, HONOR_ROLL) == 0 || strcmp(sDayPassTyp, EMERGENCY) == 0 ||
        strcmp(sDayPassTyp, POSTV_SPACE) == 0 || strcmp(sDayPassTyp, CO_BUSINESS) == 0) &&
        cAllotFound == NO_CHAR)   && (cSuspRvkInd = NO_CHAR))
            DPM_3400_CalcPenalties();
        
   /*** if a priority pass type was used for a transoceanic day, issue a service charge if remaining Trans-***/
   /*** oceanic allotments < 0 and additional passes are allowed.                                          ***/
        
   if (strcmp(sDayPassTyp, PRIORITY) == 0  &&  cTransOceanicInd == YES_CHAR   &&
      cParentOfAssocInd == 'N'      &&
      cTransAllotFound == YES_CHAR && lRemTransAllot < 0 && cTransAddlPass == YES_CHAR)
   {
            cFlatFeeInd = NO_CHAR;
	    cTransOceanicSvcChrgInd = NO_CHAR;
            DPM_3300_CalcSvcChgs();
   }
       

   /*** if a priority pass type was used for a transoceanic day, issue a penalty if no transoceanic allots ***/
   /*** or there were transoceanic allotments, but no additional passes are allowed                        ***/
   /***********COMMENTING OUT....NOT NEEDED *********************
   if (strcmp(sDayPassTyp, PRIORITY) == 0  &&  cTransOceanicInd == YES_CHAR   &&
       cParentOfAssocInd == 'N'     &&
      (cTransAllotFound == NO_CHAR  || (lRemTransAllot < 0 && cTransAddlPass == NO_CHAR)))
            DPM_3400_CalcPenalties();
*********************************************/
   /*** if parent of associate took a transoceanic flight, but no more transoceanic allotments were left ***/
   /*** so priority allotments were decremented, $75.00 svc charge will be given                         ***/
        
   if (strcmp(sDayPassTyp, PRIORITY) == 0  &&
      cParentOfAssocInd == 'T')
   {
            cFlatFeeInd = NO_CHAR;
	    cTransOceanicSvcChrgInd = NO_CHAR;
            DPM_3300_CalcSvcChgs();
   }
          

   /*** if one of the special disabled pass grps used a transoceanic day, issue a service charge if remaining ***/
   /*** transoceanic allotments < 0 and additional passes are allowed.                                        ***/
          
   if (cDisableTransOceanicInd == YES_CHAR   &&
       cTransAllotFound == YES_CHAR && lRemTransAllot < 0 && cTransAddlPass == YES_CHAR)
   {
            strcpy(sPassTyp, TRANSOCEANIC);
            cFlatFeeInd = NO_CHAR;
	    cTransOceanicSvcChrgInd = NO_CHAR;
            DPM_3300_CalcSvcChgs();
   }
        

   /*** if one of the special disabled pass grps used a transoceanic day, issue a penalty if no        ***/
   /*** transoceanic allots or there were transoceanic allotments, but no additional passes are allowed    ***/
          
   if (cDisableTransOceanicInd == YES_CHAR   &&
      (cTransAllotFound == NO_CHAR  || (lRemTransAllot < 0 && cTransAddlPass == NO_CHAR))
      && (cSuspRvkInd = NO_CHAR))
   {
            strcpy(sPassTyp, TRANSOCEANIC);
            DPM_3400_CalcPenalties();
   }
           

   cSkipPriority = NO_CHAR;
   cTransHawaiiAlaska = NO_CHAR;
   cOldTransHawaiiAlaska = NO_CHAR;

   /*** after processing all of the rows for a ppr/nrev, perform commit processing  ***/
   DPM_4920_ProcessLUW();

}

/******************************************************************
**                                                               **
** Function Name:   DPM_3100_GetRelatedInfo                      **
**                                                               **
** Description:     This function gathers all of the related     **
** information needed to calculated service charges and interntl **
** fees.  It gets information from the Remaining Allotment Table,**
** the Airport Pair Table, and the Airport Codes Table.          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3100_GetRelatedInfo()
{
   short     nSvcRtnCd;      /* Service return code */

/*** First, get the airport pair type and mileage from the Airport Pair Table          ***/
   memset(&R02792.R02792_appl_area,LOW_VALUES, sizeof(R02792.R02792_appl_area)); /* initialize request   */
   memset(&A02792,LOW_VALUES,sizeof(A02792));                                    /* and Answer block     */
   strcpy(R02792.R02792_appl_area.sFltOrigCtyId, F3100_data.sOrigCty);
   strcpy(R02792.R02792_appl_area.sFltDestCtyId, F3100_data.sDestCty);

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02792,&A02792,SERVICE_ID_02792,1,sizeof(R02792.R02792_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         strcpy(F3100_data.sArptPrTyp, A02792.A02792_appl_area.sFltArptPrTypCd);
         F3100_data.lMilesFlown =  A02792.A02792_appl_area.lFltArptPrNbr;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02792");
         BCH_FormatMessage(3,TXT_ARPT_PR_RETRIEVE_ERR, R02792.R02792_appl_area.sFltOrigCtyId,
                                                       R02792.R02792_appl_area.sFltDestCtyId);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3100_GetRelatedInfo");
      }

/*** Next, get the Origin International indicator and region code from the Airport Code Table  ***/
   memset(&R02554.R02554_appl_area,LOW_VALUES, sizeof(R02554.R02554_appl_area)); /* initialize request   */
   memset(&A02554,LOW_VALUES,sizeof(A02554));                                    /* and Answer block     */
   strcpy(R02554.R02554_appl_area.sFltArptCd, F3100_data.sOrigCty);

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02554,&A02554,SERVICE_ID_02554,1,sizeof(R02554.R02554_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         F3100_data.cOrigIntlInd = A02554.A02554_appl_area.cFltIntlInd;
         strcpy(F3100_data.sOrigReg, A02554.A02554_appl_area.sFltRgnCd);
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02554");
         BCH_FormatMessage(3,TXT_ARPT_CD_RETRIEVE_ERR, R02554.R02554_appl_area.sFltArptCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3100_GetRelatedInfo");
      }

/*** Finally, get the Destination International indicator and region code from the Airport Code Table  ***/
   memset(&R02554.R02554_appl_area,LOW_VALUES, sizeof(R02554.R02554_appl_area)); /* initialize request   */
   memset(&A02554,LOW_VALUES,sizeof(A02554));                                    /* and Answer block     */
   strcpy(R02554.R02554_appl_area.sFltArptCd, F3100_data.sDestCty);

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02554,&A02554,SERVICE_ID_02554,1,sizeof(R02554.R02554_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         F3100_data.cDestIntlInd = A02554.A02554_appl_area.cFltIntlInd;
         strcpy(F3100_data.sDestReg, A02554.A02554_appl_area.sFltRgnCd);
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02554");
         BCH_FormatMessage(3,TXT_ARPT_CD_RETRIEVE_ERR, R02554.R02554_appl_area.sFltArptCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3100_GetRelatedInfo");
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3110_GetRemainAllot                      **
**                                                               **
** Description:     This function retrieves remaining allotment  **
** data from the Remaining Allotment Table.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3110_GetRemainAllot()
{
   char      *pTemp;
   short     nSvcRtnCd;      /* Service return code */
   cAllotment = YES_CHAR;
   cPriorPeriod = NO_CHAR;
   cSaveAddlPass = NO_CHAR;

   /*** execute service to get remaining allotment row ****/
   memset(&R02688.R02688_appl_area,LOW_VALUES, sizeof(R02688.R02688_appl_area)); /* initialize request   */
   memset(&A02688,LOW_VALUES,sizeof(A02688));                                    /* and Answer block     */
   strcpy(R02688.R02688_appl_area.sPprNbr, sOldPprNbr);
   strcpy(R02688.R02688_appl_area.sNrevNbr, sNrevNbr);
   strcpy(R02688.R02688_appl_area.sPassTypCd, sPassTyp);


   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02688,&A02688,SERVICE_ID_02688,1,sizeof(R02688.R02688_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
	 pTemp = UTL_ConvertDate(A02688.A02688_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	 strcpy(A02688.A02688_appl_area.sPassRptSortDt, pTemp);
         lRemDays = A02688.A02688_appl_area.nNrevRemnDyQty;
         lRemMiles = A02688.A02688_appl_area.lNrevRemnMiQty;
         cSaveAddlPass = A02688.A02688_appl_area.cPassAddlInd;
         break;

      case ARC_ROW_NOT_FOUND:
         cAllotment = NO_CHAR;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02688");
         sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sPassTypCd = %s",
                       R02688.R02688_appl_area.sPprNbr,
                       R02688.R02688_appl_area.sNrevNbr,
                       R02688.R02688_appl_area.sPassTypCd);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3110_GetRemainAllot");
      }

/*** If a remaining Allotment row was found for the current period, the process date must be ***/
/*** less than the departure date of the group of legs being processed.  If not, then the    ***/
/*** prior period remaining allotment row must be used.                                      ***/
     if (cAllotment == YES_CHAR     &&
       strcmp(day_data[0].sSortDprtDt, A02688.A02688_appl_area.sPassRptSortDt) < 0)
   {
      memset(&R02760.R02760_appl_area,LOW_VALUES, sizeof(R02760.R02760_appl_area)); /* initialize request   */
      memset(&A02760,LOW_VALUES,sizeof(A02760));                                    /* and Answer block     */
      strcpy(R02760.R02760_appl_area.sPprNbr, sOldPprNbr);
      strcpy(R02760.R02760_appl_area.sNrevNbr, sNrevNbr);
      strcpy(R02760.R02760_appl_area.sPassTypCd, sPassTyp);

      /****** Execute service   ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R02760,&A02760,SERVICE_ID_02760,1,sizeof(R02760.R02760_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            cPriorPeriod = YES_CHAR;
            lRemDays = A02760.A02760_appl_area.nNrevRemnDyQty;
            lRemMiles = A02760.A02760_appl_area.lNrevRemnMiQty;
            cSaveAddlPass = A02760.A02760_appl_area.cPassAddlInd;
            break;

         case ARC_ROW_NOT_FOUND:
            cAllotment = NO_CHAR;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02760");
            sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sPassTypCd = %s",
                       R02760.R02760_appl_area.sPprNbr,
                       R02760.R02760_appl_area.sNrevNbr,
                       R02760.R02760_appl_area.sPassTypCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3110_GetRemainAllot");
      }

   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3200_UpdateAllotments                    **
**                                                               **
** Description:     This function updates the boarding and/or    **
** mileage quantities in the Remaining Allotment Table.          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3200_UpdateAllotments()
{
   short     nSvcRtnCd;      /* Service return code */
   lRemDomAllot = 0;
   lRemTransAllot = 0;
   cAddlPass = cSaveAddlPass;
   cTransAddlPass = NO_CHAR;


   /*** Save the previous allotment quantity ***/
   /*** only domestic or combo get the day OR mileage option ***/
   if ((strcmp(sDayPassTyp, DOMESTIC) == 0 || strcmp(sDayPassTyp, COMB_DOM_TO) == 0)   &&
       A02652.A02652_appl_area.cNrevDyMiInd == MILEAGE)
      lPrevAllot = lRemMiles;
   else
      lPrevAllot = lRemDays;


   /*** If a remaining allotment record was found, go update the remaining allotments ***/
   /*** allotments are not updated for emergency and honor roll passes                ***/
   if (cAllotFound == YES_CHAR &&
       strcmp(sDayPassTyp,  EMERGENCY) != 0 &&
       strcmp(sDayPassTyp,  HONOR_ROLL) != 0 &&
       strcmp(sDayPassTyp,  POSTV_SPACE) != 0 &&
       strcmp(sDayPassTyp,  CO_BUSINESS) != 0)
      {
      /*** If pass type for the day was transoceanic, and no transoceanic allotments remain ***/
      /*** go see if the the nrev gets combined dom/to (90) allotments, and if so, process  ***/
      /*** the day as such. Dont do this for parents of Associates (ST).                    ***/
      if (strcmp(sDayPassTyp,TRANSOCEANIC) == 0   &&  lPrevAllot <=0  && cParentOfAssocInd == 'N')
         {
         DPM_3210_GetRemain90Allot();
         }
      /*** if the parent of assoc took a domestic or transoceanic pass, and no allotments remain ***/
      /*** go see if any priority remaining allotment records remain, and if so, process the day **/
      /*** as priority.     ***/
      if ((cParentOfAssocInd == 'D' ||  cParentOfAssocInd == 'T') && lPrevAllot <= 0)
         {
         DPM_3220_GetRemainPriorityAllot();
         }
      DPM_4200_UpdateRemAllot();  
      lRemDomAllot = lRemAllot;
      }

   /*** If the pass type used was priority for a transoceanic flight leg, or one of the special ***/
   /*** disabled pass gps used a transocianic day, the transoceanic allotments must be updated also.  ***/
   /*** Dont do this for parents of associates (ST).      ***/
   cTransAllotFound = NO_CHAR;
   if ((strcmp(sDayPassTyp,  PRIORITY) == 0 && cTransOceanicInd == YES_CHAR && cParentOfAssocInd == 'N')  ||
        cDisableTransOceanicInd == YES_CHAR)
      {
      strcpy(sPassTyp, TRANSOCEANIC);
      strcpy(sNrevNbr, sOldNrevNbr);
      DPM_3110_GetRemainAllot();
      if (cAllotment == YES_CHAR)
         cTransAllotFound = YES_CHAR;
         cTransAddlPass = cSaveAddlPass;
      }

   if (cTransAllotFound == YES_CHAR)
      {
      DPM_4200_UpdateRemAllot(); 
      lRemTransAllot = lRemAllot;
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3210_GetRemain90Allot                    **
**                                                               **
** Description:     This function retrieves remaining allotment  **
** data for combo dom/to pass type. This function is only activated
** if the original day pass type is transoceanic and the nrev does*
** not have any to allotments left.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3210_GetRemain90Allot()
{
   char      *pTemp;
   short     nSvcRtnCd;      /* Service return code */
   char      cAllotment90,
             cPriorPeriod90,
             cSaveAddlPass90;
   long      lRemDays90,
             lRemMiles90;
   cAllotment90 = NO_CHAR;
   cPriorPeriod90 = NO_CHAR;
   cSaveAddlPass90 = NO_CHAR;

   /*** execute service to get 90 remaining allotment row ****/
   memset(&R02688.R02688_appl_area,LOW_VALUES, sizeof(R02688.R02688_appl_area)); /* initialize request   */
   memset(&A02688,LOW_VALUES,sizeof(A02688));                                    /* and Answer block     */
   strcpy(R02688.R02688_appl_area.sPprNbr, sOldPprNbr);
   strcpy(R02688.R02688_appl_area.sNrevNbr, sNrevNbr);
   strcpy(R02688.R02688_appl_area.sPassTypCd, COMB_DOM_TO);

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02688,&A02688,SERVICE_ID_02688,1,sizeof(R02688.R02688_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
	 pTemp = UTL_ConvertDate(A02688.A02688_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	 strcpy(A02688.A02688_appl_area.sPassRptSortDt, pTemp);
         lRemDays90 = A02688.A02688_appl_area.nNrevRemnDyQty;
         lRemMiles90 = A02688.A02688_appl_area.lNrevRemnMiQty;
         cSaveAddlPass90 = A02688.A02688_appl_area.cPassAddlInd;
         cAllotment90 = YES_CHAR;
         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02688");
         sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sPassTypCd = %s",
                       R02688.R02688_appl_area.sPprNbr,
                       R02688.R02688_appl_area.sNrevNbr,
                       R02688.R02688_appl_area.sPassTypCd);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3210_GetRemain90Allot");
      }

/*** If a remaining Allotment row was found for the current period, the process date must be ***/
/*** less than the departure date of the group of legs being processed.  If not, then the    ***/
/*** prior period remaining allotment row must be used.                                      ***/
     if (cAllotment90 == YES_CHAR     &&
       strcmp(day_data[0].sSortDprtDt, A02688.A02688_appl_area.sPassRptSortDt) < 0)
   {
      memset(&R02760.R02760_appl_area,LOW_VALUES, sizeof(R02760.R02760_appl_area)); /* initialize request   */
      memset(&A02760,LOW_VALUES,sizeof(A02760));                                    /* and Answer block     */
      strcpy(R02760.R02760_appl_area.sPprNbr, sOldPprNbr);
      strcpy(R02760.R02760_appl_area.sNrevNbr, sNrevNbr);
      strcpy(R02760.R02760_appl_area.sPassTypCd, COMB_DOM_TO);

      /****** Execute service   ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R02760,&A02760,SERVICE_ID_02760,1,sizeof(R02760.R02760_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            cPriorPeriod90 = YES_CHAR;
            lRemDays90 = A02760.A02760_appl_area.nNrevRemnDyQty;
            lRemMiles90 = A02760.A02760_appl_area.lNrevRemnMiQty;
            cSaveAddlPass90 = A02760.A02760_appl_area.cPassAddlInd;
            cAllotment90 = YES_CHAR;
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02760");
            sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sPassTypCd = %s",
                       R02760.R02760_appl_area.sPprNbr,
                       R02760.R02760_appl_area.sNrevNbr,
                       R02760.R02760_appl_area.sPassTypCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3210_GetRemain90Allot");
      }

   }
   /*** if a combined dom/to remaining allotment row was found, then this will be the nrev's ***/
   /*** pass type for service chargve and penalty processing.                               ***/
   if (cAllotment90 == YES_CHAR)
   {
      strcpy(sDayPassTyp, COMB_DOM_TO);
      strcpy(sPassTyp, COMB_DOM_TO);
      cAllotment = cAllotment90;
      cPriorPeriod = cPriorPeriod90;
      cAddlPass = cSaveAddlPass90;
      lRemDays = lRemDays90;
      lRemMiles = lRemMiles90;
      if (A02652.A02652_appl_area.cNrevDyMiInd == MILEAGE)
         lPrevAllot = lRemMiles90;
      else
         lPrevAllot = lRemDays90;
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3220_GetRemainPriorityAllot              **
**                                                               **
** Description:     This function retrieves remaining allotment  **
** data for priority pass type. This function is only activated  **
** if the original day pass type is transoceanic or domestic and **
** this is the parent of an associate, and there are no allotments*
** left for domestic or  tranocreanic.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3220_GetRemainPriorityAllot()
{
   char      *pTemp;
   short     nSvcRtnCd;      /* Service return code */
   char      cAllotment20,
             cPriorPeriod20,
             cSaveAddlPass20;
   long      lRemDays20,
             lRemMiles20;
   cAllotment20 = NO_CHAR;
   cPriorPeriod20 = NO_CHAR;
   cSaveAddlPass20 = NO_CHAR;

   /*** execute service to get 20 remaining allotment row ****/
   memset(&R02688.R02688_appl_area,LOW_VALUES, sizeof(R02688.R02688_appl_area)); /* initialize request   */
   memset(&A02688,LOW_VALUES,sizeof(A02688));                                    /* and Answer block     */
   strcpy(R02688.R02688_appl_area.sPprNbr, sOldPprNbr);
   strcpy(R02688.R02688_appl_area.sNrevNbr, sNrevNbr);
   strcpy(R02688.R02688_appl_area.sPassTypCd, PRIORITY);

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02688,&A02688,SERVICE_ID_02688,1,sizeof(R02688.R02688_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
	 pTemp = UTL_ConvertDate(A02688.A02688_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	 strcpy(A02688.A02688_appl_area.sPassRptSortDt, pTemp);
         lRemDays20 = A02688.A02688_appl_area.nNrevRemnDyQty;
         lRemMiles20 = A02688.A02688_appl_area.lNrevRemnMiQty;
         cSaveAddlPass20 = A02688.A02688_appl_area.cPassAddlInd;
         cAllotment20 = YES_CHAR;
         break;

      case ARC_ROW_NOT_FOUND:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02688");
         sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sPassTypCd = %s",
                       R02688.R02688_appl_area.sPprNbr,
                       R02688.R02688_appl_area.sNrevNbr,
                       R02688.R02688_appl_area.sPassTypCd);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3220_GetRemainPriorityAllot");
      }

/*** If a remaining Allotment row was found for the current period, the process date must be ***/
/*** less than the departure date of the group of legs being processed.  If not, then the    ***/
/*** prior period remaining allotment row must be used.                                      ***/
     if (cAllotment20 == YES_CHAR     &&
       strcmp(day_data[0].sSortDprtDt, A02688.A02688_appl_area.sPassRptSortDt) < 0)
   {
      memset(&R02760.R02760_appl_area,LOW_VALUES, sizeof(R02760.R02760_appl_area)); /* initialize request   */
      memset(&A02760,LOW_VALUES,sizeof(A02760));                                    /* and Answer block     */
      strcpy(R02760.R02760_appl_area.sPprNbr, sOldPprNbr);
      strcpy(R02760.R02760_appl_area.sNrevNbr, sNrevNbr);
      strcpy(R02760.R02760_appl_area.sPassTypCd, PRIORITY);

      /****** Execute service   ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R02760,&A02760,SERVICE_ID_02760,1,sizeof(R02760.R02760_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            cPriorPeriod20 = YES_CHAR;
            lRemDays20 = A02760.A02760_appl_area.nNrevRemnDyQty;
            lRemMiles20 = A02760.A02760_appl_area.lNrevRemnMiQty;
            cSaveAddlPass20 = A02760.A02760_appl_area.cPassAddlInd;
            cAllotment20 = YES_CHAR;
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02760");
            sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sPassTypCd = %s",
                       R02760.R02760_appl_area.sPprNbr,
                       R02760.R02760_appl_area.sNrevNbr,
                       R02760.R02760_appl_area.sPassTypCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3220_GetRemainPriorityAllot");
      }

   }
   /*** if a combined dom/to remaining allotment row was found, then this will be the nrev's ***/
   /*** pass type for service chargve and penalty processing.                               ***/
   if (cAllotment20 == YES_CHAR && lRemDays20 > 0)
   {
      strcpy(sDayPassTyp, PRIORITY);
      strcpy(sPassTyp, PRIORITY);
      cAllotment = cAllotment20;
      cPriorPeriod = cPriorPeriod20;
      cAddlPass = cSaveAddlPass20;
      lRemDays = lRemDays20;
      lRemMiles = lRemMiles20;
      lPrevAllot = lRemDays20;
   }
}


/******************************************************************
**                                                               **
** Function Name:   DPM_3300_CalcSvcChgs                         **
**                                                               **
** Description:     This function determines the service charge  **
** that should be assessed.                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3300_CalcSvcChgs()
{
   short     nSvcRtnCd;      /* Service return code */


   if (cFlatFeeInd == YES_CHAR)
      {
      strcpy(sChargeCd,  FLAT_FEE_SVCCHG);
      strcpy(sPassTypCd, COMB_DOM_TO);
      }

   if (cTransOceanicSvcChrgInd == YES_CHAR)
      {
      strcpy(sChargeCd,  TRANSOCEANIC_SVCCHG);
      strcpy(sPassTypCd, TRANSOCEANIC);
      }

   if (cFlatFeeInd == NO_CHAR && cTransOceanicSvcChrgInd == NO_CHAR)
   {
      strcpy(sChargeCd,  SERVICE_CHARGE);

      /*** use the day pass type if not combined or priority    ***/
      /*** or if it is priority and no transoceanic             ***/
      if ((strcmp(sDayPassTyp, COMB_DOM_TO) != 0  && strcmp(sDayPassTyp, PRIORITY) != 0) ||
         (strcmp(sDayPassTyp, PRIORITY) == 0  && cTransOceanicInd == NO_CHAR))
            strcpy(sPassTypCd, sDayPassTyp);

      /*** use pass type = Transoceanic if combined or priority transoceanic travel   ***/
      if ((strcmp(sDayPassTyp, COMB_DOM_TO) == 0  || strcmp(sDayPassTyp, PRIORITY) == 0)  &&
           cTransOceanicInd == YES_CHAR)
            strcpy(sPassTypCd, TRANSOCEANIC);

      /*** use pass type = Domestic if combined non-transoceanic travel   ***/
      if (strcmp(sDayPassTyp, COMB_DOM_TO) == 0  && cTransOceanicInd == NO_CHAR)
            strcpy(sPassTypCd, DOMESTIC);

      /*** if one of special disabled groups using a transoceanic day, use pass type passed***/
      if (cDisableTransOceanicInd == YES_CHAR)
         strcpy(sPassTypCd, sPassTyp);
   }

   /*** Go get the service charge amt and GL Account number from    ***/
   /*** the Pass Charge Amount Table                                       ***/
   DPM_4300_GetCharges();

/*** Next, calculate the service charge amount and write it to the     ***/
/*** the Charges Table.                                                ***/
   if (cChargeFound == YES_CHAR)
      {
      fChgAmt = A02662.A02662_appl_area.dCostChrgAmt;
      strcpy(sChgAcctNbr, A02662.A02662_appl_area.sFltFeeAcctNbr);
      DPM_4450_InsertDayChrg();
      cSvcChgCalc = YES_CHAR;
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3400_CalcPenalties                       **
**                                                               **
** Description:     This function determines the day penalty     **
** charge that should be assessed for pass overuse/abuse.        **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3400_CalcPenalties()
{
   short     nSvcRtnCd;      /* Service return code */

   strcpy(sChargeCd,  FLIGHT_PENALTY);

   /*** Get domestic or Transoceanic charge if pass type 90, otherwise, use the day pass type ***/
   if (strcmp(sDayPassTyp, COMB_DOM_TO) == 0)
   {
      if (cTransOceanicInd == YES_CHAR)
         strcpy(sPassTypCd, TRANSOCEANIC);
      else
         strcpy(sPassTypCd, DOMESTIC);
   }
   else
      strcpy(sPassTypCd, sDayPassTyp);

   /*** if one of special disabled groups using a transoceanic day, use pass type passed***/
   if (cDisableTransOceanicInd == YES_CHAR)
      strcpy(sPassTypCd, sPassTyp);

   /*** Go get the penalty amount and the GL Account number from    ***/
   /*** the Pass Charge Amount Table                                ***/
   DPM_4300_GetCharges();

/*** Next, if a penalty charge was found for the pass type,            ***/
/*** write it to the Charges Table.                                    ***/
   if (cChargeFound == YES_CHAR)
      {
      /*** if emergency, priority or honoroll used on transoceanic day, double the penalty amount ***/
      if ((strcmp(sDayPassTyp, EMERGENCY) == 0    ||
          strcmp(sDayPassTyp, PRIORITY) == 0    ||
          strcmp(sDayPassTyp, HONOR_ROLL) == 0)         &&
          cTransOceanicInd == YES_CHAR)
            fChgAmt = A02662.A02662_appl_area.dCostChrgAmt * 2;
      else
            fChgAmt = A02662.A02662_appl_area.dCostChrgAmt;
      strcpy(sChgAcctNbr, A02662.A02662_appl_area.sFltFeeAcctNbr);
      DPM_4450_InsertDayChrg();
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3600_CalclegChgs                         **
**                                                               **
** Description:     This function determines the premium charge  **
** that should be assessed for first or business class travel.   **
** It also determines the penalty for transoceanic travel with   **
** and Honor Roll Pass.                                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3600_CalcLegChgs()
{
   short     nSvcRtnCd;      /* Service return code */

/*** Go get the amount and the GL Account number from    ***/
/*** the Pass Charge Amount Table                        ***/
   DPM_4300_GetCharges();

/*** Next, if a  charge was found for the airport pair type,    ***/
/*** write it to the Charges Table.                             ***/
   if (cChargeFound == YES_CHAR)
      {
      if (strcmp(sChargeCd, HONORROLL_PENALTY_INTL) == 0)
	   fChgAmt = (A02662.A02662_appl_area.dCostChrgAmt * 2);
      else
           fChgAmt = A02662.A02662_appl_area.dCostChrgAmt;
      strcpy(sChgAcctNbr, A02662.A02662_appl_area.sFltFeeAcctNbr);
      DPM_4400_InsertCharge();
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3700_CalcIntlFees                        **
**                                                               **
** Description:     This function determines any International   **
** fees that should be assessed on the origin and destination    **
** city.                                                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3700_CalcIntlFees()
{
   short     nSvcRtnCd;      /* Service return code */

/*** First, determine if any fees apply to the origin city ***/
   cIntlFeeInd = DEPARTURE;          /* departure fee   */
   strcpy(sIntlFeeCity, save_fltleg_data.sSaveOrig);
   strcpy(sIntlFeeDate, save_fltleg_data.sSaveDprtDt);
   DPM_4500_ProcessIntlFees();

/*** Next, determine if any fees apply to the destination city ***/
   cIntlFeeInd = LANDING;             /* landing fee   */
   strcpy(sIntlFeeCity, save_fltleg_data.sSaveDest);
   strcpy(sIntlFeeDate, save_fltleg_data.sSaveArrvDt);
   DPM_4500_ProcessIntlFees();

/*** Next, Calculate US landing fees if origin is non_US and destination is US ***/
   cIntlFeeInd = LANDING;
   strcpy(sIntlFeeCity,  USA);
   strcpy(sIntlFeeDate, save_fltleg_data.sSaveArrvDt);

   /*** if origin is not US mainland, Alaska or Hawaii, and destination is US mainland - landing fee  ***/
   if (strcmp(save_fltleg_data.sSaveOrigRegCd,  US_REGION) != 0  &&
   /** strcmp(save_fltleg_data.sSaveOrigRegCd,  US_TERRITORIES) != 0  &&  **/
       strcmp(save_fltleg_data.sSaveOrigRegCd,  HAWAII) != 0  &&
       strcmp(save_fltleg_data.sSaveOrigRegCd,  ALASKA) != 0  &&
       strcmp(save_fltleg_data.sSaveOrig, SANJUAN) != 0 &&
   /** strcmp(save_fltleg_data.sSaveOrig, STTHOMAS) != 0 &  **/
   /** strcmp(save_fltleg_data.sSaveOrig, STCROIX) != 0 &&  **/
       strcmp(save_fltleg_data.sSaveDestRegCd,  US_REGION) == 0)
         DPM_4600_ProcessUSFees();

   /*** if origin is not US mainland or Hawaii, and destination is Hawaii - landing fee  ***/
   if (strcmp(save_fltleg_data.sSaveOrigRegCd,  US_REGION) != 0  &&
   /** strcmp(save_fltleg_data.sSaveOrigRegCd,  US_TERRITORIES) != 0  && **/
       strcmp(save_fltleg_data.sSaveOrig, SANJUAN) != 0 &&
   /** strcmp(save_fltleg_data.sSaveOrig, STTHOMAS) != 0 &&  **/
   /** strcmp(save_fltleg_data.sSaveOrig, STCROIX) != 0 &&  **/
       strcmp(save_fltleg_data.sSaveOrigRegCd,  HAWAII) != 0  &&
       strcmp(save_fltleg_data.sSaveDestRegCd,  HAWAII) == 0)
         DPM_4600_ProcessUSFees();

   /*** if origin is not US mainland or Alaska, and destination is Alaska - landing fee  ***/
   if (strcmp(save_fltleg_data.sSaveOrigRegCd,  US_REGION) != 0  &&
   /** strcmp(save_fltleg_data.sSaveOrigRegCd,  US_TERRITORIES) != 0  &&  **/
       strcmp(save_fltleg_data.sSaveOrig, SANJUAN) != 0 &&
   /** strcmp(save_fltleg_data.sSaveOrig, STTHOMAS) != 0 &&  **/
   /** strcmp(save_fltleg_data.sSaveOrig, STCROIX) != 0 &&   **/
       strcmp(save_fltleg_data.sSaveOrigRegCd,  ALASKA) != 0  &&
       strcmp(save_fltleg_data.sSaveDestRegCd,  ALASKA) == 0)
         DPM_4600_ProcessUSFees();

/*** Finally, Calculate US departure fees if origin is US and destination is International.***/
/*** Departure fees apply if the origin is Hawaii and the destination is not Hawaii; or,   ***/
/*** if the origin is Alaska and the destination is not Alaska; or, if the origin is US    ***/
/*** mainland and the destination is not US mainland and is not one of 4 Canadian cities.  ***/
   if ((strcmp(save_fltleg_data.sSaveOrigRegCd, HAWAII) == 0    &&
           strcmp(save_fltleg_data.sSaveDestRegCd,  HAWAII) != 0)  ||
        (strcmp(save_fltleg_data.sSaveOrigRegCd,  ALASKA) == 0  &&
           strcmp(save_fltleg_data.sSaveDestRegCd,  ALASKA) != 0)  ||
        (strcmp(save_fltleg_data.sSaveOrigRegCd,  US_REGION) == 0      &&
           strcmp(save_fltleg_data.sSaveDestRegCd,  US_REGION) != 0   &&
           strcmp(save_fltleg_data.sSaveDest,  CALGARY) != 0           &&
           strcmp(save_fltleg_data.sSaveDest,  VANCOUVER) != 0            &&
           strcmp(save_fltleg_data.sSaveDest,  MONTREAL) != 0            &&
           strcmp(save_fltleg_data.sSaveDest,  TORONTO) != 0))
      {
      cIntlFeeInd = DEPARTURE;	         /* departure fee */
      strcpy(sIntlFeeCity,  USA);
      strcpy(sIntlFeeDate, save_fltleg_data.sSaveDprtDt);
      DPM_4600_ProcessUSFees();
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3800_OldDataProcess                      **
**                                                               **
** Description:     This function gets any old flight leg data   **
** to determine if any refund charges should be created.         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3800_OldDataProcess()
{
   char      *pTemp;
   short     nSvcRtnCd;      /* Service return code */
   cEndOfOldData = NO_CHAR;
   nOldDayIndex = 0;

   if (cImpFltlegInd == NO_CHAR)    /* get first non-imputed flight leg */
   {
      /****** Initialize Request and Answer Blocks for service to retreive 1st old flight leg ****/
      memset(&R03875.R03875_appl_area,LOW_VALUES, sizeof(R03875.R03875_appl_area));
      memset(&A03875,LOW_VALUES,sizeof(A03875));
      strcpy(R03875.R03875_appl_area.sPprNbr, sOldPprNbr);
      strcpy(R03875.R03875_appl_area.sNrevNbr, sOldNrevNbr);
      R03875.R03875_appl_area.lFltChrgRfrnDt = lOldRfrnDt;
      strcpy(R03875.R03875_appl_area.sProcDt, sCurrentTsDt);
      R03875.R03875_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

      /****** Execute service to retrieve driving rows  ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R03875,&A03875,SERVICE_ID_03875,1,sizeof(R03875.R03875_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
	    pTemp = UTL_ConvertDate(A03875.A03875_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	    strcpy(A03875.A03875_appl_area.sPassRptSortDt, pTemp);
            DPM_3850_SaveOldData();
            break;

         case ARC_ROW_NOT_FOUND:
            cEndOfOldData = YES_CHAR;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03875");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3800_OldDataProcess");
      }
   }
   else                             /* get first imputed flight leg */
   {
      /****** Initialize Request and Answer Blocks for service to retreive 1st old flight leg ****/
      memset(&R03876.R03876_appl_area,LOW_VALUES, sizeof(R03876.R03876_appl_area));
      memset(&A03876,LOW_VALUES,sizeof(A03876));
      strcpy(R03876.R03876_appl_area.sPprNbr, sOldPprNbr);
      strcpy(R03876.R03876_appl_area.sNrevNbr, sOldNrevNbr);
      R03876.R03876_appl_area.lFltChrgRfrnDt = lOldRfrnDt;
      strcpy(R03876.R03876_appl_area.sProcDt, sCurrentTsDt);
      R03876.R03876_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

      /****** Execute service to retrieve driving rows  ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R03876,&A03876,SERVICE_ID_03876,1,sizeof(R03876.R03876_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
	    pTemp = UTL_ConvertDate(A03876.A03876_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	    strcpy(A03876.A03876_appl_area.sPassRptSortDt, pTemp);
            DPM_3850_SaveOldData();
            break;

         case ARC_ROW_NOT_FOUND:
            cEndOfOldData = YES_CHAR;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03876");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3800_OldDataProcess");
      }
   }

   /*** If a row was found, go and process the flight legs to determine if there is a pass type change  ***/
   /*** otherwise, continue normal day processing.                                                      ***/
   if (cEndOfOldData == NO_CHAR)
      DPM_3810_ProcessOldFltLegs();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3810_ProcessOldFltLegs                   **
**                                                               **
** Description:     This function gets any old flight leg data   **
** to determine if any refund charges should be created.         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3810_ProcessOldFltLegs()
{
   short     nSvcRtnCd;      /* Service return code */
   char      *pTemp;

   while (cEndOfOldData == NO_CHAR)
   {
      /*** Build entire array of old data for the reference date       ***/
      if (cImpFltlegInd == NO_CHAR)    /* get non-imputed flight legs */
      {
         /****** Initialize Request and Answer Blocks for service to retreive next old flight leg ****/
         memset(&A03875,LOW_VALUES,sizeof(A03875));
         R03875.R03875_appl_area.cArchCursorOpTxt = FETCH_ROW;

         /****** Execute service to retrieve driving rows  ****/
         nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R03875,&A03875,SERVICE_ID_03875,1,sizeof(R03875.R03875_appl_area));

         /****** Service Return Code Processing  ****/
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
	       pTemp = UTL_ConvertDate(A03875.A03875_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	       strcpy(A03875.A03875_appl_area.sPassRptSortDt, pTemp);
               DPM_3850_SaveOldData();
               break;

            case ARC_ROW_NOT_FOUND:
               cEndOfOldData = YES_CHAR;
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS03875");
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3800_OldDataProcess");
         }
      }
      else                             /* else get imputed flight legs */
      {
         /****** Initialize Request and Answer Blocks for service to retreive next  old flight leg ****/
         memset(&A03876,LOW_VALUES,sizeof(A03876));
         R03876.R03876_appl_area.cArchCursorOpTxt = FETCH_ROW;

         /****** Execute service to retrieve driving rows  ****/
         nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R03876,&A03876,SERVICE_ID_03876,1,sizeof(R03876.R03876_appl_area));

         /****** Service Return Code Processing  ****/
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
	       pTemp = UTL_ConvertDate(A03876.A03876_appl_area.sPassRptSortDt, CNV_DB_TO_YYYYMMDD);
	       strcpy(A03876.A03876_appl_area.sPassRptSortDt, pTemp);
               DPM_3850_SaveOldData();
               break;

            case ARC_ROW_NOT_FOUND:
               cEndOfOldData = YES_CHAR;
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS03876");
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3800_OldDataProcess");
         }
      }
   }

   /*** After building the array of flight leg items, determine the original pass type for that day  ***/
   /*** Also, go get the airport pair type and origin and dest region codes                          ***/
   nOldLegCnt = --nOldDayIndex;
   nOldDayIndex = 0;
   lOrigMilesFlown = 0;
   strcpy(sOldDayPassTyp, "99");
   cOrigTAInd = NO_CHAR;
   cOldDisableTransOceanicInd = NO_CHAR;
   while (nOldDayIndex <= nOldLegCnt)
   {
     if (strcmp(oldday_data[nOldDayIndex].sPassTyp, sOldDayPassTyp) < 0)
         strcpy(sOldDayPassTyp, oldday_data[nOldDayIndex].sPassTyp);

     /*** go get all necessary information to calculate charges and fees ***/
     memset(&F3100_data, LOW_VALUES, sizeof(F3100_data));
     strcpy(F3100_data.sOrigCty, oldday_data[nOldDayIndex].sOrigCty);
     strcpy(F3100_data.sDestCty, oldday_data[nOldDayIndex].sDestCty);
     DPM_3100_GetRelatedInfo();
     oldday_data[nOldDayIndex].cOrigIntlInd = F3100_data.cOrigIntlInd;
     oldday_data[nOldDayIndex].cDestIntlInd = F3100_data.cDestIntlInd;
     strcpy(oldday_data[nOldDayIndex].sOrigReg, F3100_data.sOrigReg);
     strcpy(oldday_data[nOldDayIndex].sDestReg, F3100_data.sDestReg);
     strcpy(oldday_data[nOldDayIndex].sArptPrTyp, F3100_data.sArptPrTyp);
     oldday_data[nOldDayIndex].lMilesFlown = F3100_data.lMilesFlown;
     lOrigMilesFlown += oldday_data[nOldDayIndex].lMilesFlown;

     if (strcmp(F3100_data.sArptPrTyp, TRANSATLANTIC) == 0 ||
         strcmp(F3100_data.sArptPrTyp, TRANSPACIFIC) == 0)
          cOrigTAInd = YES_CHAR;
     nOldDayIndex++;
   }

   /***  If the pass type being processed has a higher priority that the original pass type, or the original ***/
   /***  day type was not international and the day type will be changed to international, then the          ***/
   /***  module must do the following:  1 - update the remaining allotment to restore the day or mileage     ***/
   /*** that was decremented(except for emergency and honor roll passes);  2 - refund any day type charges   ***/
   /*** that were assessed for the original pass type; 3 - Incorporate the original flt leg data and the     ***/
   /*** new flight leg data so that any new day charges can be calculated thru normal day processing.        ***/
   if (strcmp(sDayPassTyp, sOldDayPassTyp) < 0      ||
         (cTransOceanicInd == YES_CHAR && cOrigTAInd == NO_CHAR))
   {
      if (strcmp(sOldDayPassTyp, EMERGENCY) != 0   &&
          strcmp(sOldDayPassTyp, HONOR_ROLL) != 0  &&
          strcmp(sOldDayPassTyp, POSTV_SPACE) != 0  &&
          strcmp(sOldDayPassTyp, CO_BUSINESS) != 0)
         DPM_3820_UpdateAllotments();
      DPM_3830_ProcessOrigDayChrgs();
      DPM_3840_RebuildDayData();
   }
   else
      cContDayProcInd = NO_CHAR;
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3820_UpdateAllotments                    **
**                                                               **
** Description:     This function adds either a day or original  **
** miles flown to the remaining allotment table for the original **
** day pass type.                                                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3820_UpdateAllotments()
{
   short     nSvcRtnCd;      /* Service return code */
   char      *pTemp;

/*** First, get the remaining boarding quantity and remaining mileage quantity     ***/
/*** from the Remaining Allotment Table.                                           ***/
   strcpy(sPassTyp, sOldDayPassTyp);

   /*** if the pass group is PANAM, only the ppr's remaining domestic allotment should be decremented ***/
   if (strcmp(A02652.A02652_appl_area.sPassGrpCd, PANAM) == 0)
   {
      strcpy(sPassTyp, DOMESTIC);
      strcpy(sNrevNbr, "00");
   }
   else
      strcpy(sNrevNbr, sOldNrevNbr);

   /*** If one of the disabled pass groups, psgr type is self or spuse, at least 120 months of      ***/
   /*** service, and this is a transoceanic day, both the domestic and transoceanic allotment should***/
   /*** be decremented, starting with the domestic allotment.                                       ***/
   if ((strcmp(A02652.A02652_appl_area.sPassGrpCd, DISABLED_DL_SDW) == 0       ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, DISABLED_DL_MRD) == 0       ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, DISABLED_LIM_WIDOW) == 0    ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, RETIRED_EARLY_SIX) == 0     ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, WORLDSPAN_DSABLD_SDW) == 0 ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, WORLDSPAN_DSABLD_MRD) == 0)    &&
       (strcmp(A02652.A02652_appl_area.sNrevTypCd, SELF) == 0      ||
        strcmp(A02652.A02652_appl_area.sNrevTypCd, SPOUSE) == 0)                   &&
        A02652.A02652_appl_area.nFltMoSvcNbr >= 120                                &&
        strcmp(sOldDayPassTyp, TRANSOCEANIC) == 0)
      {
      strcpy(sPassTyp, DOMESTIC);
      cOldDisableTransOceanicInd = YES_CHAR;
      }

   DPM_3110_GetRemainAllot();   /*** Go get ppr/nrev's remaining allotment row   ***/
   cDecrementInd = NO_CHAR;

   /*** If a remaining allotment record was found, go update the remaining allotments ***/
   if (cAllotment == YES_CHAR)
      {
       DPM_4200_UpdateRemAllot(); 
      }

   /*** If the pass type used was priority for a transoceanic flight leg, the transoceanic ***/
   /*** allotments must be updated also.                                                   ***/
   if ((strcmp(sOldDayPassTyp,  PRIORITY) == 0 && cOrigTAInd == YES_CHAR)   ||
        cOldDisableTransOceanicInd == YES_CHAR)
   {
      strcpy(sPassTyp, TRANSOCEANIC);
      strcpy(sNrevNbr, sOldNrevNbr);
      DPM_3110_GetRemainAllot();
      if (cAllotment == YES_CHAR)
      {
         DPM_4200_UpdateRemAllot();  
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3830_ProcessOrigDayChrgs                 **
**                                                               **
** Description:     This function gets all of the day charges for**
** the original pass type and creates a refund charge for each   **
** item found.                                                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3830_ProcessOrigDayChrgs()
{
   short     nSvcRtnCd;      /* Service return code */
   cEndOfOldData = NO_CHAR;

   /****** Initialize Request and Answer Blocks for service to retreive first charge item    ****/
   memset(&R03877.R03877_appl_area,LOW_VALUES, sizeof(R03877.R03877_appl_area));
   memset(&A03877,LOW_VALUES,sizeof(A03877));
   strcpy(R03877.R03877_appl_area.sPprNbr, sOldPprNbr);
   strcpy(R03877.R03877_appl_area.sNrevNbr, sOldNrevNbr);
   R03877.R03877_appl_area.lFltChrgRfrnDt = lOldRfrnDt;
   strcpy(R03877.R03877_appl_area.sFltOrigCtyId, STARS5);
   R03877.R03877_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R03877,&A03877,SERVICE_ID_03877,1,sizeof(R03877.R03877_appl_area));
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         cEndOfOldData = YES_CHAR;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS03877");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3830_ProcessOrigDayChrgs");
   }

   /*** for each charge item, create a refund item     ***/
   while (cEndOfOldData == NO_CHAR)
   {
      if (A03877.A03877_appl_area.dCostChrgAmt >  0)  /* dont refund a refund */
      {
         memset(&R02526.R02526_appl_area,LOW_VALUES, sizeof(R02526.R02526_appl_area));
         memset(&A02526,LOW_VALUES,sizeof(A02526));
         strcpy(R02526.R02526_appl_area.sPprNbr, sOldPprNbr);
         strcpy(R02526.R02526_appl_area.sNrevNbr, sOldNrevNbr);
         strcpy(R02526.R02526_appl_area.sFltDprtDt, oldday_data[0].sDprtDt);
         strcpy(R02526.R02526_appl_area.sPassDtTmTs, sCurrentTsDt);
         strcpy(R02526.R02526_appl_area.sFltOrigCtyId, STARS5);
         strcpy(R02526.R02526_appl_area.sFltDestCtyId, STARS5);
         strcpy(R02526.R02526_appl_area.sFltNbr, STARS5);
         strcpy(R02526.R02526_appl_area.sSvcChrgCd, A03877.A03877_appl_area.sSvcChrgCd);
         strcpy(R02526.R02526_appl_area.sSvcChrgDs, A03877.A03877_appl_area.sSvcChrgDs);
         R02526.R02526_appl_area.dCostChrgAmt = A03877.A03877_appl_area.dCostChrgAmt * -1;
         R02526.R02526_appl_area.lPassTripNbr = A03877.A03877_appl_area.lPassTripNbr;
         strcpy(R02526.R02526_appl_area.sFltClsSvcId, STARS2);
         strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, A03877.A03877_appl_area.sFltFeeAcctNbr);
         strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
         strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
         R02526.R02526_appl_area.lFltChrgRfrnDt = lOldRfrnDt;

         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               RS.nRefundCnt++;
               RS.dRefundAmt += A03877.A03877_appl_area.dCostChrgAmt;
               break;
            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS02526");
               BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
                                                  R02526.R02526_appl_area.sNrevNbr,
                                                  R02526.R02526_appl_area.sFltDprtDt,
                                                  R02526.R02526_appl_area.sSvcChrgCd);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3830_ProcessOrigDayChrgs");

         }
      }

      /******  retreive the next charge item    ****/
      memset(&A03877,LOW_VALUES,sizeof(A03877));
      R03877.R03877_appl_area.cArchCursorOpTxt = FETCH_ROW;

      nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R03877,&A03877,SERVICE_ID_03877,1,sizeof(R03877.R03877_appl_area));
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            cEndOfOldData = YES_CHAR;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS03877");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3830_ProcessOrigDayChrgs");
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3840_RebuildDayData                      **
**                                                               **
** Description:     This function combines both day_data arrays  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3840_RebuildDayData()
{
   short     nSvcRtnCd;      /* Service return code */
   nDayIndex = 0;
   nOldDayIndex = 0;
   nCombinedIndex = 0;

   /** First, combine the 2 arrays into the combined array   **/
   while (nDayIndex <= nLegCnt || nOldDayIndex <= nOldLegCnt)
   {
      if (nOldDayIndex > nOldLegCnt)
      {
         memcpy(&combined_data[nCombinedIndex], &day_data[nDayIndex], sizeof(combined_data[nCombinedIndex]));
         nDayIndex++;
         nCombinedIndex++;
         continue;
      }
      if (nDayIndex > nLegCnt)
      {
         memcpy(&combined_data[nCombinedIndex], &oldday_data[nOldDayIndex], sizeof(combined_data[nCombinedIndex]));
         nOldDayIndex++;
         nCombinedIndex++;
         continue;
      }
      if (day_data[nDayIndex].nDprtTm < oldday_data[nOldDayIndex].nDprtTm)
      {
         memcpy(&combined_data[nCombinedIndex], &day_data[nDayIndex], sizeof(combined_data[nCombinedIndex]));
         nDayIndex++;
         nCombinedIndex++;
      }
      else
      {
         memcpy(&combined_data[nCombinedIndex], &oldday_data[nOldDayIndex], sizeof(combined_data[nCombinedIndex]));
         nOldDayIndex++;
         nCombinedIndex++;
      }
   }

   /*** Next, move all of the items in the combined array back to the day_data array   ***/
   /*** and determine total mileage and if a transoceanic flight leg was flown         ***/
   nLegCnt = --nCombinedIndex;
   nDayIndex = 0;
   cTransOceanicInd = NO_CHAR;
   lTotalMilesFlown = 0;

   while (nDayIndex <= nLegCnt)
   {
      memcpy(&day_data[nDayIndex], &combined_data[nDayIndex], sizeof(day_data[nDayIndex]));
      if (strcmp(day_data[nDayIndex].sArptPrTyp, TRANSATLANTIC) == 0  ||
          strcmp(day_data[nDayIndex].sArptPrTyp, TRANSPACIFIC) == 0)
           cTransOceanicInd = YES_CHAR;
      lTotalMilesFlown += day_data[nDayIndex].lMilesFlown;
      nDayIndex++;
   }



}
/******************************************************************
**                                                               **
** Function Name:   DPM_3850_SaveOldData                         **
**                                                               **
** Description:     This function saves the flight leg and imputed*
** flight leg data that was returned from services 03875 and 03876*
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_3850_SaveOldData()
{
   short     nSvcRtnCd;      /* Service return code */

   if (cImpFltlegInd == YES_CHAR)           /*  save imputed flight leg data */
      {
      strcpy(oldday_data[nOldDayIndex].sDprtDt, A03876.A03876_appl_area.sFltDprtDt);
      strcpy(oldday_data[nOldDayIndex].sSortDprtDt, A03876.A03876_appl_area.sPassRptSortDt);
      oldday_data[nOldDayIndex].nDprtTm = A03876.A03876_appl_area.nFltDprtTm;
      strcpy(oldday_data[nOldDayIndex].sOrigCty, A03876.A03876_appl_area.sFltOrigCtyId);
      strcpy(oldday_data[nOldDayIndex].sDestCty, A03876.A03876_appl_area.sFltDestCtyId);
      strcpy(oldday_data[nOldDayIndex].sPassTyp, A03876.A03876_appl_area.sPassTypCd);
      }
   else
      {
      strcpy(oldday_data[nOldDayIndex].sDprtDt, A03875.A03875_appl_area.sFltDprtDt);
      strcpy(oldday_data[nOldDayIndex].sSortDprtDt, A03875.A03875_appl_area.sPassRptSortDt);
      oldday_data[nOldDayIndex].nDprtTm = A03875.A03875_appl_area.nFltDprtTm;
      strcpy(oldday_data[nOldDayIndex].sOrigCty, A03875.A03875_appl_area.sFltOrigCtyId);
      strcpy(oldday_data[nOldDayIndex].sDestCty, A03875.A03875_appl_area.sFltDestCtyId);
      strcpy(oldday_data[nOldDayIndex].sPassTyp, A03875.A03875_appl_area.sPassTypCd);
      }
   nOldDayIndex++;
}


/******************************************************************
**                                                               **
** Function Name:   DPM_3900_OldPriorty                          **
**                                                               **
** Description:     This function gets any old flight leg data   **
** when the passrider had a priority pass (pass type 20) on the  **
** the previous day of the priority pass that is currently       **
** processing.                                                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
        
void    DPM_3900_OldPriority()
{
   char      *pTemp;
   short     nSvcRtnCd;      /* Service return code */
   cEndOfOldPriority = NO_CHAR;
   cOldPriority = NO_CHAR;
   cSkipPriority = NO_CHAR;
/** nOldDayIndex = 0;  **/
   nDprtTmCalculated = 0;
   nOldPriorityCnt = 0;
   nOldPriorityTm = 0;


      /****** Initialize Request and Answer Blocks for service to retreive 1st old S2 flight leg ****/
      memset(&R04772.R04772_appl_area,LOW_VALUES, sizeof(R04772.R04772_appl_area));
      memset(&A04772,LOW_VALUES,sizeof(A04772));
      strcpy(R04772.R04772_appl_area.sPprNbr, sOldPprNbr);
      strcpy(R04772.R04772_appl_area.sNrevNbr, sOldNrevNbr);
      R04772.R04772_appl_area.lFltChrgRfrnDt = lOldRfrnDt;
      strcpy(R04772.R04772_appl_area.sProcDt, sCurrentTsDt);

 while (cEndOfOldPriority == NO_CHAR)
    {
   nOldPriorityCnt++;
   if (nOldPriorityCnt == 1) 
      {
      R04772.R04772_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
      }
      else
      {
      memset(&A04772,LOW_VALUES,sizeof(A04772));
      R04772.R04772_appl_area.cArchCursorOpTxt = FETCH_ROW;
      }
      /****** Execute service to retrieve driving rows  ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD3,&R04772,&A04772,SERVICE_ID_04772,1,sizeof(R04772.R04772_appl_area));


      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
	    cOldPriority = YES_CHAR;
            break;

         case ARC_ROW_NOT_FOUND:
            cEndOfOldPriority = YES_CHAR;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04772");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3900_OldPriorty");
      }

     if ((cOldPriority == YES_CHAR) &&  (nOldPriorityCnt == 1))     
	{
        nOldPriorityTm = A04772.A04772_appl_area.nFltDprtTm;
	strcpy(sOldPriorityOrigin, A04772.A04772_appl_area.sFltOrigCtyId);
        }

     if (strcmp(A04772.A04772_appl_area.sFltArptPrTypCd, TRANSATLANTIC) == 0   ||
         strcmp(A04772.A04772_appl_area.sFltArptPrTypCd, TRANSPACIFIC) == 0    ||
         strcmp(A04772.A04772_appl_area.sFltArptPrTypCd, ALASKA)  == 0    ||
         strcmp(A04772.A04772_appl_area.sFltArptPrTypCd, HAWAII)  == 0)
        { 
	cOldTransHawaiiAlaska = YES_CHAR;
	}

  }  /** end of while **/

  if ((cOldPriority == YES_CHAR) &&                      /*  previous S2 */
     (strcmp(day_data[nLegCnt].sDestCty, sOldPriorityOrigin) != 0))

     {

     if ((cTransHawaiiAlaska == YES_CHAR) || (cOldTransHawaiiAlaska == YES_CHAR))
	 {
         cSkipPriority = YES_CHAR;
	 }
     if (cSkipPriority == NO_CHAR)
	{
    /** nDprtTmCalculated = (A04772.A04772_appl_area.nFltDprtTm - nDprtTm); ***/
        nDprtTmCalculated = (nOldPriorityTm - nPriorityDprtTm);
        if (nDprtTmCalculated > 0) 
          {
            cSkipPriority = YES_CHAR;
          }
        }
     }
  cOldPriority = NO_CHAR;
  strcpy(sOldPriorityOrigin, "     ");

}

/******************************************************************
/******************************************************************
**                                                               **
** Function Name:   DPM_4100_SaveFltlegData                      **
**                                                               **
** Description:     This function saves the flight leg and imputed*
** flight leg data that was returned from services 04317 and 04343*
** this is necessary so that the same functions can process the  **
** data regardless of where the data came from.                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4100_SaveFltlegData()
{
   short     nSvcRtnCd;      /* Service return code */
   if (cImpFltlegInd == YES_CHAR)           /*  save imputed flight leg data */
      {
      strcpy(save_fltleg_data.sSavePprNbr, A04343.A04343_appl_area.sPprNbr);
      strcpy(save_fltleg_data.sSaveNrevNbr, A04343.A04343_appl_area.sNrevNbr);
      strcpy(save_fltleg_data.sSaveDprtDt, A04343.A04343_appl_area.sFltDprtDt);
      strcpy(save_fltleg_data.sSaveSortDprtDt, A04343.A04343_appl_area.sPassRptSortDt);
      strcpy(save_fltleg_data.sSaveArrvDt, A04343.A04343_appl_area.sFltArrDt);
      save_fltleg_data.nSaveDprtTm = A04343.A04343_appl_area.nFltDprtTm;
      strcpy(save_fltleg_data.sSaveOrig, A04343.A04343_appl_area.sFltOrigCtyId);
      strcpy(save_fltleg_data.sSaveDest, A04343.A04343_appl_area.sFltDestCtyId);
      strcpy(save_fltleg_data.sSavePassTyp, A04343.A04343_appl_area.sPassTypCd);
      strcpy(save_fltleg_data.sSaveClass, A04343.A04343_appl_area.sFltClsSvcId);
      strcpy(save_fltleg_data.sSaveFltNbr, A04343.A04343_appl_area.sFltNbr);
      strcpy(save_fltleg_data.sSaveTktNbr, A04343.A04343_appl_area.sTktNbr);
      save_fltleg_data.lSaveRfrnDt =  A04343.A04343_appl_area.lFltChrgRfrnDt;
      strcpy(save_fltleg_data.sSaveNwTktDocNb, A04343.A04343_appl_area.sNwTktDocNb);
      }
   else if (cBdyFltlegInd == YES_CHAR)
      {
      strcpy(save_fltleg_data.sSavePprNbr, A04417.A04417_appl_area.sPprNbr);
      strcpy(save_fltleg_data.sSaveNrevNbr, A04417.A04417_appl_area.sNrevNbr);
      strcpy(save_fltleg_data.sSaveDprtDt, A04417.A04417_appl_area.sFltDprtDt);
      strcpy(save_fltleg_data.sSaveSortDprtDt, A04417.A04417_appl_area.sPassRptSortDt);
      strcpy(save_fltleg_data.sSaveArrvDt, A04417.A04417_appl_area.sFltArrDt);
      save_fltleg_data.nSaveDprtTm = A04417.A04417_appl_area.nFltDprtTm;
      strcpy(save_fltleg_data.sSaveOrig, A04417.A04417_appl_area.sFltOrigCtyId);
      strcpy(save_fltleg_data.sSaveDest, A04417.A04417_appl_area.sFltDestCtyId);
      strcpy(save_fltleg_data.sSavePassTyp, A04417.A04417_appl_area.sPassTypCd);
      strcpy(save_fltleg_data.sSaveClass, A04417.A04417_appl_area.sFltClsSvcId);
      strcpy(save_fltleg_data.sSaveFltNbr, A04417.A04417_appl_area.sFltNbr);
      strcpy(save_fltleg_data.sSaveNwTktDocNb, A04417.A04417_appl_area.sNwTktDocNb);
      save_fltleg_data.lSaveRfrnDt =  A04417.A04417_appl_area.lFltChrgRfrnDt;

	  }
   else
      {
      strcpy(save_fltleg_data.sSavePprNbr, A04317.A04317_appl_area.sPprNbr);
      strcpy(save_fltleg_data.sSaveNrevNbr, A04317.A04317_appl_area.sNrevNbr);
      strcpy(save_fltleg_data.sSaveDprtDt, A04317.A04317_appl_area.sFltDprtDt);
      strcpy(save_fltleg_data.sSaveSortDprtDt, A04317.A04317_appl_area.sPassRptSortDt);
      strcpy(save_fltleg_data.sSaveArrvDt, A04317.A04317_appl_area.sFltArrDt);
      save_fltleg_data.nSaveDprtTm = A04317.A04317_appl_area.nFltDprtTm;
      strcpy(save_fltleg_data.sSaveOrig, A04317.A04317_appl_area.sFltOrigCtyId);
      strcpy(save_fltleg_data.sSaveDest, A04317.A04317_appl_area.sFltDestCtyId);
      strcpy(save_fltleg_data.sSavePassTyp, A04317.A04317_appl_area.sPassTypCd);
      strcpy(save_fltleg_data.sSaveClass, A04317.A04317_appl_area.sFltClsSvcId);
      strcpy(save_fltleg_data.sSaveFltNbr, A04317.A04317_appl_area.sFltNbr);
      strcpy(save_fltleg_data.sSaveNwTktDocNb, A04317.A04317_appl_area.sNwTktDocNb);
      save_fltleg_data.lSaveRfrnDt =  A04317.A04317_appl_area.lFltChrgRfrnDt;

      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4200_UpdateRemAllot                      **
**                                                               **
** Description:     This function decrements a nrev psgr's       **
** remaining allotments or miles on the remaining allotment table**
** or on the Prior Period Remaining Allotment Table.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4200_UpdateRemAllot()
{
   short     nSvcRtnCd;      /* Service return code */

   cParentSingleActive = NO_CHAR;

/*** if the board/miles indicator indicates the mileage option, subtract the number of miles ***/
/*** traveled from the remaining mileage, otherwise, subtract 1 from the number of days;     ***/
/*** if restoring an allotment, add the original mileage or add 1 to the number of days      ***/
   if (A02652.A02652_appl_area.cNrevDyMiInd == MILEAGE      &&
             (strcmp(sPassTyp, DOMESTIC) == 0 || strcmp(sPassTyp, COMB_DOM_TO) == 0))
      {
         if (cDecrementInd == YES_CHAR)
         {
            lRemMiles -= lTotalMilesFlown;
            lRemAllot = lRemMiles;
         }
         else
            lRemMiles += lOrigMilesFlown;
      }
   else
      {
         if (cDecrementInd == YES_CHAR)
         {
            --lRemDays;
            lRemAllot = lRemDays;
         }
         else
            ++lRemDays;
      }

  if (lRemDays > 999)
     {
     lRemDays = 999;
     }

   /*** Determine if this is the parent of one of the Single, active pass groups with kids ***/
   /*** and if they used a priority (20) or transoceanic (40) pass                         ***/
   if ((strcmp(A02652.A02652_appl_area.sNrevTypCd, PARENT) == 0)  &&
       (strcmp(A02652.A02652_appl_area.sPassGrpCd, ACTIVE_DL_WK) == 0         ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, RDYRSV_SINGLE_WK) == 0     ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, COOPINT_SINGLE_WK) == 0    ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, TEMPDL_SINGLE_WK) == 0     ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, LOA_SICK_SDW_WK) == 0      ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, QTO_SDW_WK) == 0           ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, SENIOR_OFFICERS_WK) == 0   ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, WORLDSPAN_FROMDL_WK) == 0  ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, WORLDSPAN_TEMP_SDW_WK) == 0  ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, DGS_AVTN_SEC_SDW_WK) == 0   ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, DGS_TEMP_STAFF_SDW_WK) == 0 ||
        strcmp(A02652.A02652_appl_area.sPassGrpCd, VOL_LEAVE_SDW_WK) == 0)   &&
             (strcmp(sPassTyp, PRIORITY) == 0    ||
              strcmp(sPassTyp, TRANSOCEANIC) == 0 || strcmp(sPassTyp, REWARD) == 0))

   {
      cParentSingleActive = YES_CHAR;
   }

   /*** Update remaining Allotment ****/
   if (cPriorPeriod == NO_CHAR)
   {
      /*** If this is the parent of one of the Single, active pass groups with kids, update ***/
      /*** the remaining allotment for both parents                                         ***/
      if (cParentSingleActive == YES_CHAR)
      {
         memset(&R04331.R04331_appl_area,LOW_VALUES, sizeof(R04331.R04331_appl_area));
         memset(&A04331,LOW_VALUES,sizeof(A04331));
         strcpy(R04331.R04331_appl_area.sPprNbr, sOldPprNbr);
         strcpy(R04331.R04331_appl_area.sPassTypCd, sPassTyp);
         R04331.R04331_appl_area.nNrevRemnDyQty = lRemDays;
         R04331.R04331_appl_area.lNrevRemnMiQty = lRemMiles;

         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04331,&A04331,SERVICE_ID_04331,1,sizeof(R04331.R04331_appl_area));
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               /*** If successful,  update the Deltamatic table ***/
               DPM_4225_Deltamatic();
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS04331");
               BCH_FormatMessage(3,TXT_REMAIN_ALLOT_UPDATE_ERR, R04331.R04331_appl_area.sPprNbr,
                                                     sNrevNbr,
                                                     R04331.R04331_appl_area.sPassTypCd);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4200_UpdateRemAllot");
         }
      }
      /*** If not a parent of the single, active pass group with kids, update 1 row ***/
      else
      {
         /*** Initialize rqst and ans block in order to update the Remaining Allotment  Row   ***/
         memset(&R02689.R02689_appl_area,LOW_VALUES, sizeof(R02689.R02689_appl_area));
         memset(&A02689,LOW_VALUES,sizeof(A02689));
         strcpy(R02689.R02689_appl_area.sPprNbr, sOldPprNbr);
         strcpy(R02689.R02689_appl_area.sNrevNbr, sNrevNbr);
         strcpy(R02689.R02689_appl_area.sPassTypCd, sPassTyp);
         R02689.R02689_appl_area.nNrevRemnDyQty = lRemDays;
         R02689.R02689_appl_area.lNrevRemnMiQty = lRemMiles;

         /****** Execute service   ****/
         nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02689,&A02689,SERVICE_ID_02689,1,sizeof(R02689.R02689_appl_area));
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               /*** If successful,  update the Deltamatic table ***/
               DPM_4225_Deltamatic();
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS02689");
               BCH_FormatMessage(3,TXT_REMAIN_ALLOT_UPDATE_ERR, R02689.R02689_appl_area.sPprNbr,
                                                     R02689.R02689_appl_area.sNrevNbr,
                                                     R02689.R02689_appl_area.sPassTypCd);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4200_UpdateRemAllot");
         }
      }
   }
   /*** Otherwise, update prior period Remaining Allotment ***/
   else
   {
      /*** If this is the parent of one of the Single, active pass groups with kids, update ***/
      /*** the prior period remaining allotment for both parents                            ***/
      if (cParentSingleActive == YES_CHAR)
      {
         memset(&R04332.R04332_appl_area,LOW_VALUES, sizeof(R04332.R04332_appl_area));
         memset(&A04332,LOW_VALUES,sizeof(A04332));
         strcpy(R04332.R04332_appl_area.sPprNbr, sOldPprNbr);
         strcpy(R04332.R04332_appl_area.sPassTypCd, sPassTyp);
         R04332.R04332_appl_area.nNrevRemnDyQty = lRemDays;
         R04332.R04332_appl_area.lNrevRemnMiQty = lRemMiles;

         nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R04332,&A04332,SERVICE_ID_04332,1,sizeof(R04332.R04332_appl_area));
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS04332");
               BCH_FormatMessage(3,TXT_REMAIN_ALLOT_UPDATE_ERR, R04332.R04332_appl_area.sPprNbr,
                                                     sNrevNbr,
                                                     R04332.R04332_appl_area.sPassTypCd);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4200_UpdateRemAllot");
         }
      }
      /*** otherwise update 1 row on prior period remaining allotment ***/
      else
      {
         /*** Init rqst and ans block in order to update the Prior Period Remaining Allotment  Row   ***/
         memset(&R02763.R02763_appl_area,LOW_VALUES, sizeof(R02763.R02763_appl_area));
         memset(&A02763,LOW_VALUES,sizeof(A02763));
         strcpy(R02763.R02763_appl_area.sPprNbr, sOldPprNbr);
         strcpy(R02763.R02763_appl_area.sNrevNbr, sNrevNbr);
         strcpy(R02763.R02763_appl_area.sPassTypCd, sPassTyp);
         R02763.R02763_appl_area.nNrevRemnDyQty = lRemDays;
         R02763.R02763_appl_area.lNrevRemnMiQty = lRemMiles;
         R02763.R02763_appl_area.cPassAddlInd = A02760.A02760_appl_area.cPassAddlInd;
         strcpy(R02763.R02763_appl_area.sArchLastUpdtTs, A02760.A02760_appl_area.sArchLastUpdtTs);

         /****** Execute service   ****/
         nSvcRtnCd = BCH_InvokeService(EPBUPD1,&R02763,&A02763,SERVICE_ID_02763,1,sizeof(R02763.R02763_appl_area));
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS02763");
               BCH_FormatMessage(3,TXT_REMAIN_ALLOT_UPDATE_ERR, R02763.R02763_appl_area.sPprNbr,
                                                     R02763.R02763_appl_area.sNrevNbr,
                                                     R02763.R02763_appl_area.sPassTypCd);
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4200_UpdateRemAllot");
         }
      }
   }

}


/******************************************************************
**                                                               **
** Function Name:   DPM_4225_Deltamatic                          **
**                                                               **
** Description:     This function begins the process to add or   **
**  change an item in the Deltamatic table.                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4225_Deltamatic()
{
   char cSendInd;
   short     nSvcRtnCd;      /* Service return code */

   cSendInd = YES_CHAR;

   /*** if mileage > 20,000 miles or remaining days > 100, dont send an item to Deltamatic ***/
   if (A02652.A02652_appl_area.cNrevDyMiInd == MILEAGE  &&
       (strcmp(sPassTyp, DOMESTIC) == 0 || strcmp(sPassTyp, COMB_DOM_TO) == 0)  &&
       lRemMiles > MILEAGE_LIMIT)
      cSendInd = NO_CHAR;

   if (A02652.A02652_appl_area.cNrevDyMiInd != MILEAGE  &&
       lRemDays > DAY_LIMIT)
      cSendInd = NO_CHAR;

   if (cSendInd == YES_CHAR)
   {
      /*** Update a single Deltamatic row if NOT the parent of a single active ppr   ***/
      if (cParentSingleActive == NO_CHAR)
      {
         strcpy(sNrev4250, sNrevNbr);
         DPM_4250_UpdateDeltamatic();
      }
      /*** Otherwise, create or update Deltamatic rows for both parents  ***/
      else
      {
         /*** get the nrev nbr for each parent from the nrev psgr table   ***/
         memset(&R04339.R04339_appl_area,LOW_VALUES, sizeof(R04339.R04339_appl_area));
         memset(&A04339,LOW_VALUES,sizeof(A04339));
         strcpy(R04339.R04339_appl_area.sPprNbr, sOldPprNbr);
         R04339.R04339_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
         nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04339,&A04339,SERVICE_ID_04339,1,sizeof(R04339.R04339_appl_area));
         switch (nSvcRtnCd)
         {
            case ARC_SUCCESS:
               break;

            case ARC_ROW_NOT_FOUND:
               break;

            default:
               BCH_FormatMessage(1,TXT_SVC_UNSUCC);
               BCH_FormatMessage(2,TXT_SVC, "FYS04339");
               BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4200_UpdateRemAllot");
        }

         /*** for each nrev nbr, update the Deltamatic table     ***/
         while (nSvcRtnCd == ARC_SUCCESS)
         {
            strcpy(sNrev4250, A04339.A04339_appl_area.sNrevNbr);
            DPM_4250_UpdateDeltamatic();

            /******  retreive the next nrev  item     ***/
            memset(&A04339,LOW_VALUES,sizeof(A04339));
            R04339.R04339_appl_area.cArchCursorOpTxt = FETCH_ROW;
            nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04339,&A04339,SERVICE_ID_04339,1,sizeof(R04339.R04339_appl_area));
            switch (nSvcRtnCd)
            {
               case ARC_SUCCESS:
                  break;

               case ARC_ROW_NOT_FOUND:
                  break;

               default:
                  BCH_FormatMessage(1,TXT_SVC_UNSUCC);
                  BCH_FormatMessage(2,TXT_SVC, "FYS04339");
                  BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4200_UpdateRemAllot");
            }
         }
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4250_UpdateDeltamatic                    **
**                                                               **
** Description:     This function adds or changes an item in the **
**  Deltamatic Table.                                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4250_UpdateDeltamatic()
{
   short     nSvcRtnCd;      /* Service return code */

   /*** Initialize rqst and ans block to add an entry to the Deltamatic Interface Table ***/
   /*** for this ppr/nrev/pass type                                                     ***/
   memset(&R04325.R04325_appl_area,LOW_VALUES, sizeof(R04325.R04325_appl_area));
   memset(&A04325,LOW_VALUES,sizeof(A04325));
   strcpy(R04325.R04325_appl_area.sPprNbr, sOldPprNbr);
   strcpy(R04325.R04325_appl_area.sNrevNbr, sNrev4250);
   strcpy(R04325.R04325_appl_area.sPassTypCd, sPassTyp);
   R04325.R04325_appl_area.cEmplArRecInd = 'C';

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R04325,&A04325,SERVICE_ID_04325,1,sizeof(R04325.R04325_appl_area));
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_DUPLICATE_ROW:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04325");
         sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sPass Type = %s ",
                                                  R04325.R04325_appl_area.sPprNbr,
                                                  R04325.R04325_appl_area.sNrevNbr,
                                                  R04325.R04325_appl_area.sPassTypCd);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4250_UpdateDeltamatic");
   }
   /*** If a row already exist on the Deltamatic table, go update the timestamp ***/
   if (nSvcRtnCd = ARC_DUPLICATE_ROW)
   {
      memset(&R04330.R04330_appl_area,LOW_VALUES, sizeof(R04330.R04330_appl_area));
      memset(&A04330,LOW_VALUES,sizeof(A04330));
      strcpy(R04330.R04330_appl_area.sPprNbr, sOldPprNbr);
      strcpy(R04330.R04330_appl_area.sNrevNbr, sNrev4250);
      strcpy(R04330.R04330_appl_area.sPassTypCd, sPassTyp);
      R04330.R04330_appl_area.cEmplArRecInd = 'C';

      /****** Execute service   ****/
      nSvcRtnCd = BCH_InvokeService(EPBUPD2,&R04330,&A04330,SERVICE_ID_04330,1,sizeof(R04330.R04330_appl_area));
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04330");
            sprintf(sErrorMessage, "sPprNbr = %s, sNrevNbr = %s, sPass Type = %s ",
                                                  R04330.R04330_appl_area.sPprNbr,
                                                  R04330.R04330_appl_area.sNrevNbr,
                                                  R04330.R04330_appl_area.sPassTypCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4250_UpdateDeltamatic");
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4300_GetCharges                          **
**                                                               **
** Description:     This function gets the appropriate row from  **
**  the Pass Charge Amount Table.                                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4300_GetCharges()
{
   short     nSvcRtnCd;      /* Service return code */

   memset(&R02662.R02662_appl_area,LOW_VALUES, sizeof(R02662.R02662_appl_area)); /* initialize request   */
   memset(&A02662,LOW_VALUES,sizeof(A02662));                                    /* and Answer block     */
   strcpy(R02662.R02662_appl_area.sPassTypCd, sPassTypCd);
   strcpy(R02662.R02662_appl_area.sSvcChrgCd, sChargeCd);

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02662,&A02662,SERVICE_ID_02662,1,sizeof(R02662.R02662_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         if (A02662.A02662_appl_area.dCostChrgAmt == 0)
            cChargeFound = NO_CHAR;
         else
            cChargeFound = YES_CHAR;
         break;

      case ARC_ROW_NOT_FOUND:
         cChargeFound = NO_CHAR;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02662");
         sprintf(sErrorMessage, "sPassTypCd = %s, sSvcChrgCd = %s",
                          R02662.R02662_appl_area.sPassTypCd,
                          R02662.R02662_appl_area.sSvcChrgCd);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4300_GetCharges");
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4400_InsertCharge                        **
**                                                               **
** Description:     This function inserts a calculated leg Charge**
** into the Charges Table.                                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_4400_InsertCharge()
{
   short     nSvcRtnCd;      /* Service return code */

   memset(&R02526.R02526_appl_area,LOW_VALUES, sizeof(R02526.R02526_appl_area)); /* initialize request   */
   memset(&A02526,LOW_VALUES,sizeof(A02526));                                    /* and Answer block     */
   strcpy(R02526.R02526_appl_area.sPprNbr, save_fltleg_data.sSavePprNbr);
   strcpy(R02526.R02526_appl_area.sNrevNbr, save_fltleg_data.sSaveNrevNbr);
   strcpy(R02526.R02526_appl_area.sFltDprtDt, save_fltleg_data.sSaveDprtDt);
   strcpy(R02526.R02526_appl_area.sPassDtTmTs, sCurrentTsDt);
   strcpy(R02526.R02526_appl_area.sFltOrigCtyId, save_fltleg_data.sSaveOrig);
   strcpy(R02526.R02526_appl_area.sFltDestCtyId, save_fltleg_data.sSaveDest);
   strcpy(R02526.R02526_appl_area.sFltNbr, save_fltleg_data.sSaveFltNbr);
   strcpy(R02526.R02526_appl_area.sSvcChrgCd, sChargeCd);
   strcpy(R02526.R02526_appl_area.sSvcChrgDs, "               ");
   R02526.R02526_appl_area.dCostChrgAmt = fChgAmt;
   strcpy(R02526.R02526_appl_area.sFltClsSvcId, save_fltleg_data.sSaveClass);
   if (strncmp(save_fltleg_data.sSaveNwTktDocNb, "012",3) == 0)
      {
       strncpy(sChgAcctNbr +7, "NW", 2);
      }
   strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, sChgAcctNbr);

   /*** if a senior officer or positive space flight, set proc date and acct eff date to today so that charge wont be ***/
   /*** sent to Empl ar or DMSS                                                              ***/
   if (strcmp(A02652.A02652_appl_area.sPassGrpCd,  SENIOR_OFFICERS) == 0  ||
       strcmp(A02652.A02652_appl_area.sPassGrpCd,  SENIOR_OFFICERS_WK) == 0  ||
       strcmp(A02652.A02652_appl_area.sPassGrpCd,  SENIOR_OFFICERS_MRD) == 0 ||
       strcmp(save_fltleg_data.sSavePassTyp, POSTV_SPACE) == 0 ||
       strcmp(save_fltleg_data.sSavePassTyp, CO_BUSINESS) == 0)
   {
      strcpy(R02526.R02526_appl_area.sFltAcctEffDt, sCurrentTsDt);
      strcpy(R02526.R02526_appl_area.sProcDt, sCurrentTsDt);
   }
   else
   {
      strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
      strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
   }

   /*** if this is an internationational fee, put the city incurring the fee in the ***/
   /*** description of the charge. This is for DMSS purposes.                       ***/
   if (strcmp(sChargeCd, INTL_FEE) == 0)
      sprintf(R02526.R02526_appl_area.sSvcChrgDs, "%s", sIntlFeeCity);
      sleep (1);

   R02526.R02526_appl_area.lFltChrgRfrnDt = save_fltleg_data.lSaveRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02526");
         BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
                                                  R02526.R02526_appl_area.sNrevNbr,
                                                  R02526.R02526_appl_area.sFltDprtDt,
                                                  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4300_GetCharges");
      }

   /*** Add count and amount of charge to total   ***/
   if (strcmp(sChargeCd, SERVICE_CHARGE) == 0      ||
       strcmp(sChargeCd, FLAT_FEE_SVCCHG) == 0)
   {
      RS.nSvcChrgCnt++;
      RS.dSvcChrgAmt += fChgAmt;
   }
   else
   {
      if (strcmp(sChargeCd, INTL_FEE) == 0)
      {
         RS.nIntlFeeCnt++;
         RS.dIntlFeeAmt += fChgAmt;
      }
      else
      {
         RS.nPenaltyCnt++;
         RS.dPenaltyAmt += fChgAmt;
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4450_InsertDayChrg                       **
**                                                               **
** Description:     This function inserts a calculated Day Charge**
** into the Charges Table.                                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4450_InsertDayChrg()
{
   short     nSvcRtnCd;      /* Service return code */

   memset(&R02526.R02526_appl_area,LOW_VALUES, sizeof(R02526.R02526_appl_area)); /* initialize request   */
   memset(&A02526,LOW_VALUES,sizeof(A02526));                                    /* and Answer block     */
   strcpy(R02526.R02526_appl_area.sPprNbr, sOldPprNbr);
   strcpy(R02526.R02526_appl_area.sNrevNbr, sOldNrevNbr);
   strcpy(R02526.R02526_appl_area.sFltDprtDt, day_data[0].sDprtDt);
   strcpy(R02526.R02526_appl_area.sPassDtTmTs, sCurrentTsDt);
   strcpy(R02526.R02526_appl_area.sFltOrigCtyId, STARS5);
   strcpy(R02526.R02526_appl_area.sFltDestCtyId, STARS5);
   strcpy(R02526.R02526_appl_area.sFltNbr, STARS5);
   strcpy(R02526.R02526_appl_area.sSvcChrgCd, sChargeCd);

   /*** always use the origin of the first leg and the destination of the last leg unless there are ***/
   /*** only 2 legs, and the origin of 1st leg and dest of the 2nd leg are the same.  In this case, ***/
   /*** use the orig and dest of the 1st leg.                                                       ***/
   if (nLegCnt != 1)
      sprintf(R02526.R02526_appl_area.sSvcChrgDs, "%s / %s",         /* changed */
              day_data[0].sOrigCty, day_data[nLegCnt].sDestCty);   /* to add  */
   else                                                            /* "/" to  */
   {                                                               /* orig    */
      if (strcmp(day_data[0].sOrigCty, day_data[1].sDestCty) != 0) /* dest    */
         sprintf(R02526.R02526_appl_area.sSvcChrgDs, "%s / %s",      /* sir 22  */
                 day_data[0].sOrigCty, day_data[1].sDestCty);      /* kch 1/96*/
      else
         sprintf(R02526.R02526_appl_area.sSvcChrgDs, "%s / %s",
                 day_data[0].sOrigCty, day_data[0].sDestCty);
   }

   R02526.R02526_appl_area.dCostChrgAmt = fChgAmt;
   strcpy(R02526.R02526_appl_area.sFltClsSvcId, STARS2);
   strcpy(R02526.R02526_appl_area.sFltFeeAcctNbr, sChgAcctNbr);

   /*** if a senior officer, set proc date and acct eff date to today so that charge wont be ***/
   /*** sent to Empl ar or DMSS                                                              ***/
   if (strcmp(A02652.A02652_appl_area.sPassGrpCd,  SENIOR_OFFICERS) == 0  ||
       strcmp(A02652.A02652_appl_area.sPassGrpCd,  SENIOR_OFFICERS_WK) == 0  ||
       strcmp(A02652.A02652_appl_area.sPassGrpCd,  SENIOR_OFFICERS_MRD) == 0 ||
       strcmp(save_fltleg_data.sSavePassTyp, POSTV_SPACE) == 0 ||
       strcmp(save_fltleg_data.sSavePassTyp, CO_BUSINESS) == 0)
   {
      strcpy(R02526.R02526_appl_area.sFltAcctEffDt, sCurrentTsDt);
      strcpy(R02526.R02526_appl_area.sProcDt, sCurrentTsDt);
   }
   else
   {
      strcpy(R02526.R02526_appl_area.sFltAcctEffDt, LOW_DATE);
      strcpy(R02526.R02526_appl_area.sProcDt, LOW_DATE);
   }

   R02526.R02526_appl_area.lFltChrgRfrnDt = lOldRfrnDt;

   /****** Execute service   ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02526,&A02526,SERVICE_ID_02526,1,sizeof(R02526.R02526_appl_area));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02526");
         BCH_FormatMessage(3,TXT_CHRG_INSERT_ERR, R02526.R02526_appl_area.sPprNbr,
                                                  R02526.R02526_appl_area.sNrevNbr,
                                                  R02526.R02526_appl_area.sFltDprtDt,
                                                  R02526.R02526_appl_area.sSvcChrgCd);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4450_InsertDayChrg");
      }

   /*** Add count and amount of charge to total   ***/
   if (strcmp(sChargeCd, SERVICE_CHARGE) == 0      ||
       strcmp(sChargeCd, FLAT_FEE_SVCCHG) == 0)
   {
      RS.nSvcChrgCnt++;
      RS.dSvcChrgAmt += fChgAmt;
   }
   else
   {
      if (strcmp(sChargeCd, INTL_FEE) == 0)
      {
         RS.nIntlFeeCnt++;
         RS.dIntlFeeAmt += fChgAmt;
      }
      else
      {
         RS.nPenaltyCnt++;
         RS.dPenaltyAmt += fChgAmt;
      }
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4500_ProcessIntlFees                     **
**                                                               **
** Description:     This function retreives all international    **
** fees associated with a flight leg.  Then, it converts the     **
** international fee to USD currency if necessary, and then write**
** the fee out to the Charges table.                             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4500_ProcessIntlFees()
{
   short     nSvcRtnCd;      /* Service return code */
   cEndOfIntlfeeData = NO_CHAR;
   cIntraEuroFeeFound = NO_CHAR;
   strcpy(sChargeCd,  INTL_FEE);

      /****** Initialize Request and Answer Blocks for service to retreive 1st International***
       ****** Fee item that is a US Departure or Arrival Tax                              *****/
      memset(&R02664.R02664_appl_area,LOW_VALUES, sizeof(R02664.R02664_appl_area));
      memset(&A02664,LOW_VALUES,sizeof(A02664));
      R02664.R02664_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
      R02664.R02664_appl_area.cFltFeeInd = cIntlFeeInd;
      strcpy(R02664.R02664_appl_area.sFltArptCd, sIntlFeeCity);
      strcpy(R02664.R02664_appl_area.sFltFeeBegDt, sIntlFeeDate);
      strcpy(R02664.R02664_appl_area.sFltFeeEndDt, sIntlFeeDate);

      /****** Execute service to retrieve driving rows  ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02664,&A02664,SERVICE_ID_02664,1,sizeof(R02664.R02664_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            cEndOfIntlfeeData = YES_CHAR;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02664");
            sprintf(sErrorMessage, "FeeInd = %c,ArptCd = %s,FeeBegDt = %s,FeeEndDt = %s",
                          R02664.R02664_appl_area.cFltFeeInd,
                          R02664.R02664_appl_area.sFltArptCd,
                          R02664.R02664_appl_area.sFltFeeBegDt,
                          R02664.R02664_appl_area.sFltFeeEndDt);
            BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4500_ProcessIntlFees");
         }

   /*** Canadian Security Fee      EShelton     ***/
   if ((strcmp(R02664.R02664_appl_area.sFltArptCd,  MONTREAL) == 0   ||
       strcmp(R02664.R02664_appl_area.sFltArptCd,  EDMONTON) == 0   ||
       strcmp(R02664.R02664_appl_area.sFltArptCd, OTTAWA) == 0    ||
       strcmp(R02664.R02664_appl_area.sFltArptCd,  VANCOUVER) == 0   ||
       strcmp(R02664.R02664_appl_area.sFltArptCd,  CALGARY) == 0    ||
       strcmp(R02664.R02664_appl_area.sFltArptCd, TORONTO) == 0    ||
       strcmp(R02664.R02664_appl_area.sFltArptCd,  MONTREAL) == 0)
       &&
       (strcmp(A02554.A02554_appl_area.sFltRgnCd, US_REGION) != 0    &&
        strcmp(A02554.A02554_appl_area.sFltRgnCd, DOMESTIC_ARPTPR) != 0   &&
        strcmp(A02554.A02554_appl_area.sFltRgnCd, CANADA) != 0))
        A02664.A02664_appl_area.dFltFeeAmt = A02664.A02664_appl_area.dFltFeeAmt * 2;


   /**** Mexico Tourism Tax     LScott                                     ***/
   /***  If departure city is in Mexico and passenger is a Mexican citizen ***/
   /***  the charge is not assessed.                                       ***/

   if (strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, MEXICO_TOURISM_TAX) == 0 &&
      (strcmp(A02652.A02652_appl_area.sCtryCtznpCd, "MEX") == 0))
      A02664.A02664_appl_area.dFltFeeAmt = A02664.A02664_appl_area.dFltFeeAmt * 0;


   /**** Belize Development and Belize Conservation taxes.     LScott       ***/
   /***  If departure city is in Belize and passenger is a citizen of       ***/
   /***  Belize the charge is not assessed.                                 ***/

   if ((strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, BELIZE_DEVELOP_TAX) == 0 ||
       strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, BELIZE_CONSERV_TAX) == 0)
       &&
      (strcmp(A02652.A02652_appl_area.sCtryCtznpCd, "BIZ") == 0))
      A02664.A02664_appl_area.dFltFeeAmt = A02664.A02664_appl_area.dFltFeeAmt * 0;

   /**** Montego Bay Jamaica  -   LScott                                   ***/
   /**** If departure city is MBJ and the flight is on a Delta aircraft    ***/
   /**** then the tax is assessed.  If the flight is on Air Jamaica then   ***/
   /**** the tax is not assessed because they collect the tax prior to     ***/
   /**** departure.                                                        ***/

   /**** Jamaica departure tax -  LScott                                   ***/
   /**** As of 10/1/06 all flights on Air Jamaica require ID 96 passes     ***/
   /**** to travel, so those flight legs should no longer come though      ***/
   /**** this system.  All fights departing Jamaica should now be charged  ***/
   /**** the Jamaica departure tax.                                        ***/
   /**** THE FOLLOWING LINES OF CODE HAVE BEEN COMMENTED OUT               ***/

   /***********************
   strcpy (sFltNbr, "     ");
   strcpy (sFltNbr,save_fltleg_data.sSaveFltNbr);
   if (strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, MONTEGO_BAY_TAX) == 0 &&
      (strcmp(sFltNbr,"3399 ") > 0))
      A02664.A02664_appl_area.dFltFeeAmt = A02664.A02664_appl_area.dFltFeeAmt * 0;
   ***********************/

   /*** if airport pair type is intr-european and first fee found is also, set indicator ***/
   if (cEndOfIntlfeeData == NO_CHAR && strcmp(A02792.A02792_appl_area.sFltArptPrTypCd,  INTRAEURO) == 0  &&
        A02664.A02664_appl_area.cFltFeeIntraInd == YES_CHAR)
      cIntraEuroFeeFound = YES_CHAR;

 /**** Process International Fee Items***/
   while (cEndOfIntlfeeData == NO_CHAR)
      {
      DPM_4550_ProcessRows();
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4550_ProcessRows                         **
**                                                               **
** Description:     Process International Fees until end of rows **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4550_ProcessRows()
{
   short     nSvcRtnCd;      /* Service return code */
   cProcessIntlFee = YES_CHAR;

/*** determine if we need to process this international fee.  If so,   ***/
/*** convert it to USD and then write it to the Charges Table.         ***/

   /*** if this fee has a mileage requirement, the mileage between o&d must fall between ***/
   /*** the minimum and maximum mileage of this item                                      ***/
   if (A02664.A02664_appl_area.cFltFeeMiInd == YES_CHAR    &&
         (A02792.A02792_appl_area.lFltArptPrNbr < A02664.A02664_appl_area.lFltFeeMiMinNbr ||
          A02792.A02792_appl_area.lFltArptPrNbr > A02664.A02664_appl_area.lFltFeeMiMaxNbr))
            cProcessIntlFee = NO_CHAR;

   /*** if this fee has an age requirement, the age must fall of the nrev psgr must fall***/
   /*** between the minimum and maximum age of this item                                ***/
   if (A02664.A02664_appl_area.cFltFeeAgeInd == YES_CHAR  &&
         (A02652.A02652_appl_area.nPassAnsRowsNbr < A02664.A02664_appl_area.nFltFeeMinNbr  ||
          A02652.A02652_appl_area.nPassAnsRowsNbr > A02664.A02664_appl_area.nFltFeeMaxNbr))
            cProcessIntlFee = NO_CHAR;

   /*** if this fee is an intr-european fee, the airport pair type of the flight leg    ***/
   /*** must also be intr-european                                                      ***/
   if (A02664.A02664_appl_area.cFltFeeIntraInd == YES_CHAR  &&
         strcmp(A02792.A02792_appl_area.sFltArptPrTypCd,  INTRAEURO) != 0)
            cProcessIntlFee = NO_CHAR;

   /*** if the airport pair type of the flight leg is intra-european, and intra-european***/
   /*** fee items have been found, dont use any fee item not marked as intra-european   ***/
   if (strcmp(A02792.A02792_appl_area.sFltArptPrTypCd,  INTRAEURO) == 0  &&
       cIntraEuroFeeFound == YES_CHAR  && A02664.A02664_appl_area.cFltFeeIntraInd != YES_CHAR)
            cProcessIntlFee = NO_CHAR;

   /**** Mexico Tourism Tax     LScott                                     ***/
   /***  If departure city is in Mexico and passenger is a Mexican citizen ***/
   /***  the charge is not assessed.                                       ***/

   if (strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, MEXICO_TOURISM_TAX) == 0
      &&
      (strcmp(A02652.A02652_appl_area.sCtryCtznpCd, "MEX") == 0))
      A02664.A02664_appl_area.dFltFeeAmt = A02664.A02664_appl_area.dFltFeeAmt * 0;


   /**** Belize Development and Belize Conservation taxes.     LScott       ***/
   /***  If departure city is in Belize and passenger is a citizen of       ***/
   /***  Belize the charge is not assessed.                                 ***/

   if ((strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, BELIZE_DEVELOP_TAX) == 0 ||
       strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, BELIZE_CONSERV_TAX) == 0)
       &&
      (strcmp(A02652.A02652_appl_area.sCtryCtznpCd, "BIZ") == 0))
      A02664.A02664_appl_area.dFltFeeAmt = A02664.A02664_appl_area.dFltFeeAmt * 0;

   /**** Montego Bay Jamaica  -   LScott                                   ***/
   /**** If departure city is MBJ and the flight is on a Delta aircraft    ***/
   /**** then the tax is assessed.  If the flight is on Air Jamaica then   ***/
   /**** the tax is not assessed because they collect the tax prior to     ***/
   /**** departure.                                                        ***/

   /**** Jamaica departure tax -  LScott                                   ***/
   /**** As of 10/1/06 all flights on Air Jamaica require ID 96 passes     ***/
   /**** to travel, so those flight legs should no longer come though      ***/
   /**** this system.  All fights departing Jamaica should now be charged  ***/
   /**** the Jamaica departure tax.                                        ***/
   /**** THE FOLLOWING LINES OF CODE HAVE BEEN COMMENTED OUT               ***/

   /***********************
   strcpy (sFltNbr, "     ");
   strcpy (sFltNbr,save_fltleg_data.sSaveFltNbr);
   if (strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, MONTEGO_BAY_TAX) == 0 &&
      (strcmp(sFltNbr,"3399 ") > 0))
      A02664.A02664_appl_area.dFltFeeAmt = A02664.A02664_appl_area.dFltFeeAmt * 0;
    ***********************/

   /*** Finally, if all the checks are passed, convert the international fee and write ***/
   /*** it out to the Charges Table                                                    ***/
   if (cProcessIntlFee == YES_CHAR && A02664.A02664_appl_area.dFltFeeAmt != 0.0)
      {
      fConvtdAmt = 0.0;
      if (strcmp(A02664.A02664_appl_area.sFltFeeCurrCd, USD_CURR) != 0)
         {
         DPM_4575_ConvertCurrency();
         }
      if (fConvtdAmt == 0.0)
         fChgAmt = A02664.A02664_appl_area.dFltFeeAmt;
      else
         fChgAmt = fConvtdAmt;
      strcpy(sChgAcctNbr, A02664.A02664_appl_area.sFltFeeAcctNbr);
      DPM_4400_InsertCharge();
      }

/*** After processing this row, get next international fee row ***/
   R02664.R02664_appl_area.cArchCursorOpTxt = FETCH_ROW;
   memset(&A02664,LOW_VALUES,sizeof(A02664));

   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02664,&A02664,SERVICE_ID_02664,1,sizeof(R02664.R02664_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         cEndOfIntlfeeData = YES_CHAR;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02664");
         sprintf(sErrorMessage, "FeeInd = %c, ArptCd = %s, FeeBegDt = %s, FeeEndDt = %s",
                       R02664.R02664_appl_area.cFltFeeInd,
                       R02664.R02664_appl_area.sFltArptCd,
                       R02664.R02664_appl_area.sFltFeeBegDt,
                       R02664.R02664_appl_area.sFltFeeEndDt);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4550_ProcessRows");
       }

}

/******************************************************************
**                                                               **
** Function Name:   DPM_4575_ConvertCurrency                    **
**                                                               **
** Description:     This function goes to the the exchange rate  **
** table for a non_USD currency and then converts the inter-     **
** national fee amount to USD.                                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4575_ConvertCurrency()
{
   short     nSvcRtnCd;      /* Service return code */

   /*  initialize Request and Answer block   */
   memset(&R03208.R03208_appl_area,LOW_VALUES, sizeof(R03208.R03208_appl_area));
   memset(&A03208,LOW_VALUES,sizeof(A03208));
   strcpy(R03208.R03208_appl_area.sCurrSrcCd, A02664.A02664_appl_area.sFltFeeCurrCd);
   strcpy(R03208.R03208_appl_area.sCurrDestCd, USD_CURR);

   /****** Execute service   ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R03208,&A03208,SERVICE_ID_03208,1,sizeof(R03208.R03208_appl_area));

   /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         if (A03208.A03208_appl_area.cCurrRatOperId == MULTIPLY)
            fConvtdAmt = A03208.A03208_appl_area.dPassExchgRatNbr * A02664.A02664_appl_area.dFltFeeAmt;
         else
            fConvtdAmt = A03208.A03208_appl_area.dPassExchgRatNbr / A02664.A02664_appl_area.dFltFeeAmt;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS03208");
         sprintf(sErrorMessage, "src currency = %s, dest currency = %s ",
                       R03208.R03208_appl_area.sCurrSrcCd,
                       R03208.R03208_appl_area.sCurrDestCd);
         BCH_FormatMessage(3,TXT_XCHG_RT_RETRIEVE_ERR, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4575_ConvertCurrency");
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4600_ProcessUSFees                       **
**                                                               **
** Description:     This function gets all of the US landing or  **
** departure taxes from the International fee Table.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4600_ProcessUSFees()
{
   short     i,
             nSvcRtnCd;      /* Service return code */
   cEndOfIntlfeeData = NO_CHAR;
   strcpy(sChargeCd,  INTL_FEE);

      /****** Initialize Request and Answer Blocks for service to retreive 1st International***
       ****** Fee item that is a US Departure or Arrival Tax                              *****/
      memset(&R02664.R02664_appl_area,LOW_VALUES, sizeof(R02664.R02664_appl_area));
      memset(&A02664,LOW_VALUES,sizeof(A02664));
      R02664.R02664_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;
      R02664.R02664_appl_area.cFltFeeInd = cIntlFeeInd;
      strcpy(R02664.R02664_appl_area.sFltArptCd, sIntlFeeCity);
      strcpy(R02664.R02664_appl_area.sFltFeeBegDt, sIntlFeeDate);
      strcpy(R02664.R02664_appl_area.sFltFeeEndDt, sIntlFeeDate);

      /****** Execute service to retrieve driving rows  ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02664,&A02664,SERVICE_ID_02664,1,sizeof(R02664.R02664_appl_area));

      /****** Service Return Code Processing  ****/
      switch (nSvcRtnCd)
         {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            cEndOfIntlfeeData = YES_CHAR;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02664");
            sprintf(sErrorMessage, "FeeInd = %c, ArptCd = %s, FeeBegDt = %s, FeeEndDt = %s",
                       R02664.R02664_appl_area.cFltFeeInd,
                       R02664.R02664_appl_area.sFltArptCd,
                       R02664.R02664_appl_area.sFltFeeBegDt,
                       R02664.R02664_appl_area.sFltFeeEndDt);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4600_ProcessUSFees");
         }

 /**** Process International Fee Items***/
  if (cEndOfIntlfeeData == NO_CHAR)
  {
    nArptCdInd=0;
    i = 0;
    while ( i < ARPT_CD_ARY_LIMIT && nArptCdInd != 1 )
    {
       if ( strncmp(save_fltleg_data.sSaveOrig, aArptCd[i], 3) == 0 )
         nArptCdInd = 1;
       else
         i++;
    }
  }

   while (cEndOfIntlfeeData == NO_CHAR)
      {
      DPM_4650_ProcessRows();
      }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4650_ProcessRows                         **
**                                                               **
** Description:     Process International Fees until end of rows **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_4650_ProcessRows()
{
   short     nSvcRtnCd;      /* Service return code */


/*** Next, for all departure fees, or landing fees except APHIS fee    ***/
/*** when the orign is Canada or Puerto Rico, write to Charges Table   ***/

/*** The following comments added by L. Walker 11/30/1998; YC Fee will ***/
/*** no longer be collected for travel originating outside of the US   ***/
/*** for the following locations US Territories, Canada, Mexico,       ***/
/*** Bahamas or adjacent islands that is destined for one of the 50 US ***/
/*** cities or the District of Columbia.                               ***/

     if (cIntlFeeInd == LANDING &&
        (strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr,  APHIS_FEE) == 0   &&
          (strcmp(save_fltleg_data.sSaveOrigRegCd,  CANADA) == 0   ||
           strcmp(save_fltleg_data.sSaveOrig,  SANJUAN) == 0
          )
        ) ||
        (strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr,  YC_FEE) == 0 &&
          (strcmp(save_fltleg_data.sSaveOrigRegCd, CANADA) == 0 ||
           strcmp(save_fltleg_data.sSaveOrigRegCd, US_TERRITORIES) == 0 ||
           strcmp(save_fltleg_data.sSaveOrigRegCd, CARIBBEAN_REGION) == 0 ||
           strcmp(save_fltleg_data.sSaveOrigRegCd, C_AMERICA_REGION) == 0 ||
           strcmp(save_fltleg_data.sSaveOrigRegCd, S_AMERICA_REGION) == 0 ||
           strcmp(save_fltleg_data.sSaveOrigRegCd, MEXICO_REGION) == 0 ||
           (strcmp(save_fltleg_data.sSaveOrigRegCd, LATIN_AMERICA) == 0 &&
            nArptCdInd == 0
           )
          )
        ) ||
        (strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr,  INS_FEE) == 0 &&
          (strcmp(save_fltleg_data.sSaveOrigRegCd, US_TERRITORIES) == 0 ||
           strcmp(save_fltleg_data.sSaveOrig,  SANJUAN) == 0 ||
           strcmp(save_fltleg_data.sSaveOrig, STTHOMAS) == 0 ||
           strcmp(save_fltleg_data.sSaveOrig, STCROIX) == 0 
          )
        ) ||
        (strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, US_SECURITY_FEE) == 0 &&
	 strcmp(A02652.A02652_appl_area.sNrevTypCd, PARENT) != 0
        ) ||
        (strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, US_SECURITY_FEE) == 0 &&
	 (strcmp(A02652.A02652_appl_area.sNrevTypCd, PARENT) == 0 &&
	  strcmp(save_fltleg_data.sSavePassTyp, COMB_DOM_TO) == 0 &&
	 (strcmp(save_fltleg_data.sSaveOrigRegCd, HAWAII) == 0 ||
	  strcmp(save_fltleg_data.sSaveOrigRegCd, US_TERRITORIES) == 0 ||
	  strcmp(save_fltleg_data.sSaveOrigRegCd, US_REGION) == 0 ||
	  strcmp(save_fltleg_data.sSaveOrigRegCd, ALASKA) == 0 ||
	  strcmp(save_fltleg_data.sSaveOrigRegCd, CANADA) == 0 ||
          strcmp(save_fltleg_data.sSaveOrig, SANJUAN) == 0 ||
          strcmp(save_fltleg_data.sSaveOrig, STTHOMAS) == 0 ||
          strcmp(save_fltleg_data.sSaveOrig, STCROIX) == 0 ||
	  (strcmp(save_fltleg_data.sSaveOrigRegCd, "XX") == 0)
	 )
         )
        ) ||
        (strcmp(A02664.A02664_appl_area.sFltFeeAcctNbr, US_SECURITY_FEE) == 0 &&
	 (strcmp(A02652.A02652_appl_area.sNrevTypCd, PARENT) == 0 &&
	  strcmp(save_fltleg_data.sSavePassTyp, COMB_DOM_TO) != 0
         )
	)
     )
      {
      }
   else
      {
      fChgAmt = A02664.A02664_appl_area.dFltFeeAmt;
      strcpy(sChgAcctNbr, A02664.A02664_appl_area.sFltFeeAcctNbr);
      DPM_4400_InsertCharge();
      }

/*** After processing this row, get next international fee row ***/
   R02664.R02664_appl_area.cArchCursorOpTxt = FETCH_ROW;
   memset(&A02664,LOW_VALUES,sizeof(A02664));
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R02664,&A02664,SERVICE_ID_02664,1,sizeof(R02664.R02664_appl_area));

   switch (nSvcRtnCd)
      {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND:
         cEndOfIntlfeeData = YES_CHAR;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02664");
         sprintf(sErrorMessage, "FeeInd = %c, ArptCd = %s, FeeBegDt = %s, FeeEndDt = %s",
                       R02664.R02664_appl_area.cFltFeeInd,
                       R02664.R02664_appl_area.sFltArptCd,
                       R02664.R02664_appl_area.sFltFeeBegDt,
                       R02664.R02664_appl_area.sFltFeeEndDt);
         BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_4650_ProcessRows");
       }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_4920_ProcessLUW                          **
**                                                               **
** Description:     Commit records.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void DPM_4920_ProcessLUW()
{
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void    DPM_9500_ProcessEndOfProgram()
{

   sprintf(sErrorMessage, "Total Flight Legs = %d, Total Imputed Flight Legs = %d",
                           RS.sFltLegCnt, RS.sImpFltLegCnt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   sprintf(sErrorMessage, "Total Service Charges - Cnt = %d, amt = %6.2f",
                           RS.nSvcChrgCnt, RS.dSvcChrgAmt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   sprintf(sErrorMessage, "Total Penalty Charges - Cnt = %d, amt = %6.2f",
                           RS.nPenaltyCnt, RS.dPenaltyAmt);
   BCH_FormatMessage(2,TXT_ERR_GENERIC_TXT, sErrorMessage);
   sprintf(sErrorMessage, "Total International Fees - Cnt = %d, amt = %6.2f",
                           RS.nIntlFeeCnt, RS.dIntlFeeAmt);
   BCH_FormatMessage(3,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");

   if (RS.nRefundCnt != 0)
   {
      sprintf(sErrorMessage, "Total Refunds - Cnt = %d, amt = %6.2f",
                           RS.nRefundCnt, RS.dRefundAmt);
      BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   }

}
