/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB71301.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Written:    October 4, 1995                                        **
**                                                                         **
** Description:     This module creates the Payroll interface file.        **
**                  The sum of imputed wages for Senior Officers, who      **
**                  were notified more than 30 days from the effective     **
**                  processing date, is written to an interface record.    **
**                  The processing status of the corresponding database    **
**                  records is changed from notified to processed.         **
**                  Similarly, interface records are written for corrected **
**                  data, and the processing status of these records is    **
**                  changed from corrected to processed.                   **
**                                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 3/7/95     GML                210      Change get env date to DATE1     **   
**                                                                         **
****************************************************************************/
#include "epb71301.h"

main()
{
   BCH_Init("EPB71301", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   char   *pEffDt;                /* Pointer to effective date */
 
   /**** Initialize keys in RSAM saved area ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);
   RS.fFltImptWageAmt = 0;
   memset(&RS.sPassEffDt, LOW_VALUES, sizeof(RS.sPassEffDt));
 
   /**** Initialize counters & accumulators ***/          
   RS.EPBF020_record_cntr = 0;

   /**** Initialize output buffer ****/ 
   memset(&RS.EPBF020_buffer, LOW_VALUES, sizeof(RS.EPBF020_buffer));

   /**** Assign effective date to variable ****/
   pEffDt = (char *) getenv("DATE1");
   strcpy(RS.sEffDt, pEffDt);
  
   /**** Initialize architecture area of service answer and request blocks ****/
   memset(&A02597, LOW_VALUES, sizeof(_A02597));
   memset(&R02597, LOW_VALUES, sizeof(_R02597));
   memset(&A02649, LOW_VALUES, sizeof(_A02649));
   memset(&R02649, LOW_VALUES, sizeof(_R02649));
   memset(&A02650, LOW_VALUES, sizeof(_A02650));
   memset(&R02650, LOW_VALUES, sizeof(_R02650));

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   /**** Open output file ****/
   RS.EPBF020 = BCH_Open("EPBF020", BCH_FILE_WRITE);
   if (RS.EPBF020 == BCH_FAIL)
   {
      BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
      BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF020");
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   /**** Format current date to form YYMMDD ****/
   //strncpy(RS.sPassEffDt, sCurrentSortDt+2, 2);
  //strncat(RS.sPassEffDt, sCurrentSortDt+5, 2);
  //strncat(RS.sPassEffDt, sCurrentSortDt+8, 2);

   /****** Initialize service request and answer blocks *****/
   memset(&R02649.R02649_appl_area, LOW_VALUES, sizeof(_R02649_APPL_AREA));
   memset(&A02649.A02649_appl_area, LOW_VALUES, sizeof(_A02649_APPL_AREA));

   /**** Format service request block for initial DB cursor read ****/
   strcpy(R02649.R02649_appl_area.sPprNbr, RS.sPprNbr);
   strcpy(R02649.R02649_appl_area.sFltFeeEndDt, RS.sEffDt); 

   /**** Open the initial DB cursor ****/
   R02649.R02649_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /**** Execute service to select imputed wages for Senior Officers from the Imputed Trip table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02649,&A02649,SERVICE_ID_02649,1,sizeof(_R02649_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02649");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows ****/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      /**** Save imputed wage record information ****/
      strcpy(RS.sPprNbr, A02649.A02649_appl_area.sPprNbr);
      RS.fFltImptWageAmt += A02649.A02649_appl_area.fFltImptWageAmt;

      /**** Execute service to obtain next db row ****/
      R02649.R02649_appl_area.cArchCursorOpTxt = FETCH_ROW;

      memset(&A02649.A02649_appl_area, LOW_VALUES,sizeof(_A02649_APPL_AREA));

      /**** Execute service to select imputed wages for Senior Officers from the Imputed Trip table ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02649,&A02649,SERVICE_ID_02649,1,sizeof(_R02649_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            /**** Compare answer block PPR ID with saved PPR ID; if different,
                  write an imputed wage record and process the LUW ****/
            if(strcmp(A02649.A02649_appl_area.sPprNbr, RS.sPprNbr) != 0)
            {
               DPM_2500_WriteImputedRecord();
               RS.fFltImptWageAmt = 0;
            }
            break;

         case ARC_ROW_NOT_FOUND:
            /**** Write an imputed wage record and process the LUW ****/
            DPM_2500_WriteImputedRecord();
            RS.fFltImptWageAmt = 0;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02649");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   DPM_2600_UpdateMatchInd();
   DPM_9500_ProcessEndOfProgram();

   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_WriteImputedRecord                  **
**                                                               **
** Description:     Write imputed wage record to Payroll         **
**                  interface file.                              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_WriteImputedRecord()
{
   char sTempString[10];         /** Imputed wage amount with decimal **/
   char sImptWage[9];            /** Imputed wage amount without decimal **/

   /**** Initialize fields ****/
   memset(&sTempString, LOW_VALUES, sizeof(sTempString));
   memset(&sImptWage, LOW_VALUES, sizeof(sImptWage));
   memset(&RS.EPBF020_buffer, LOW_VALUES, sizeof(RS.EPBF020_buffer));

   /**** Format imputed wage amount without decimal ****/
   sprintf(sTempString, "%+09.2lf", RS.fFltImptWageAmt);
   strncpy(sImptWage, sTempString, 6);
   strncat(sImptWage, sTempString+7, 2);

   /**** Format output buffer ****/
   strncpy(RS.EPBF020_buffer, RECORD_CD, 2);
   strncpy(RS.EPBF020_buffer+2, RS.sPprNbr, 9);
   strncpy(RS.EPBF020_buffer+11, UTL_ConvertDate(RS.sEffDt,CNV_DB_TO_YYMMDD),6);
   strncpy(RS.EPBF020_buffer+17, FILLER, 28);
   strncpy(RS.EPBF020_buffer+45, sImptWage, 8);
   strncpy(RS.EPBF020_buffer+53, FILLER, 28);

   /**** Write record to output file ****/
   BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));
  
   /**** Increment output counter ****/
   RS.EPBF020_record_cntr++;
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2600_UpdateMatchInd                      **
**                                                               **
** Description:     Update Match Indicator to 'P' for processed  **
**                  status on the Imputed Trip and Imputed       **
**                  Flight Leg tables.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2600_UpdateMatchInd()
{
   /**** Initialize service request and answer blocks ****/
   memset(&R02650.R02650_appl_area, LOW_VALUES, sizeof(_R02650_APPL_AREA));

   /**** Format Request block with specifics ****/
   strcpy(R02650.R02650_appl_area.sFltFeeEndDt, RS.sEffDt);

   /**** Execute service to update match indicator to 'P' for processed status on the Imputed Trip table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02650,&A02650,SERVICE_ID_02650,1,sizeof(_R02650_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02650");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_UpdateMatchInd");
   }

   /**** Initialize service request and answer blocks ****/
   memset(&R02597.R02597_appl_area, LOW_VALUES, sizeof(_R02597_APPL_AREA));

   /**** Format Request block with specifics ****/
   strcpy(R02597.R02597_appl_area.sFltFeeEndDt, RS.sEffDt);

   /**** Execute service to update match indicator to 'P' for processed status on the Imputed Flight Leg table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R02597,&A02597,SERVICE_ID_02597,1,sizeof(_R02597_APPL_AREA));

   /**** Service return code processing ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02597");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_UpdateMatchInd");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   /**** Close output file ****/
   BCH_Close(RS.EPBF020);
 
   /**** Write control total ****/
   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_FormatMessage(2,TXT_OUT_FILE, "RS.EPBF020");
   BCH_FormatMessage(3,TXT_REC_TTL, RS.EPBF020_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
