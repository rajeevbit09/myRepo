/**************************************************************************** 
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         ** 
** Sub-System :     Pass Accounting                                        **
**                                                                         ** 
** Program Name:    EPB50032.c                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.c>                                           **
**                                                                         **
** Program Type:    Batch Report Format Module with zero control breaks    **
**                                                                         **
** Author :         Delta Air Lines                                        **
**                  Beverly Ellison                                        **
**                                                                         **
** Date Written:    Nov  08, 2011                                          **
**                                                                         **
** Description:     This program reads the report records created by       **
**                  program EPB50001 and formats the HR Update Error       **
**                  report for GoJet.                                      **
**                                                                         **
** Revision Trail:                                                         ** 
**                                                                         ** 
** Date       Revised by         SIR #    Description                      ** 
** ----       ----------         -----    -----------                      ** 
**                                                                         **
**                                                                         **   
****************************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "epb50032.h"
#include "bchrfmcd.h"

main()
{
   RFM_1000_InitializeFlds();
   while ((feof(stdin)) == 0)
      {
      RFM_3000_ProcessDetail();  
      }
   RFM_4000_ProcessEndOfJob();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1000_InitializeFlds                      **
**                                                               **
** Description:     Initialize fields, read initial record,      **
**                  zero accumulators                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1000_InitializeFlds()
{
   char sCurrentDate[13]; /* current date in mm/dd/yy format */

   rfm_ReadNextRecord();
   cSaveRecInd = rpt_data.F5032_RptDataStruct.cEmplArRecInd;
   strcpy(sSaveSource, rpt_data.F5032_RptDataStruct.sNrevSrcCd);
   strcpy(sSavePprNbr, rpt_data.F5032_RptDataStruct.sPprNbr);
   strcpy(sSaveNrevNbr, rpt_data.F5032_RptDataStruct.sNrevNbr);
   
   cEndOfRpt = 'N';
   cFirstTime = 'Y';
   nRptPagesWritten = 0;
   strncpy(sErrorText, " ",sizeof(sErrorText));
   strncpy(sErrorMsg, " ",sizeof(sErrorMsg));

   /* Get system date and time */
   current = time((time_t *)0);
   strcpy(tu.t_str, ctime(&current));
   strftime(sCurrentDate,12,"%m/%d/%y",localtime(&current));

   tu.t_str[7] = tu.t_str[10]=tu.t_str[19]=tu.t_str[24]='\0';
 
   nCurrentLineCount = NEW_PAGE;
   memset(print_line,' ',PAGE_WIDTH);
   strcpy(sRequestId, input_area.rqst_id);

   /*************************************/
   /* Format and save standard headings */
   /*************************************/

   /* standard heading 1 */
   PRINT_SETUP(1,"CSR #:");
   PRINT_SETUP(10,"79G7");
   PRINT_SETUP(56,STD_RPT_TITLE);
   PRINT_SETUP(115,"PAGE:");
   memcpy(std_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 2 */
   PRINT_SETUP(1,"REPORT:");
   PRINT_SETUP(10, "EPB50032");
   PRINT_SETUP(56, "HR UPDATE ERRORS - ");
   PRINT_SETUP(75, sSaveSource);
   PRINT_SETUP(115,"DATE:");
   PRINT_SETUP(123, sCurrentDate);
   memcpy(std_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 3 */
   PRINT_SETUP(59,"AS OF");
   PRINT_SETUP(65, sCurrentDate);
   PRINT_SETUP(115,"TIME:");
   PRINT_SETUP(123,tu.ts.hh_mm_ss);
   memcpy(std_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 1 */
   PRINT_SETUP(10, "PPR");
   PRINT_SETUP(24, "NREV");
   PRINT_SETUP(62, "PASS");
   PRINT_SETUP(68, "PSGR");
   PRINT_SETUP(102, "PASS");
   memcpy(appl_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
  
   /* application heading 2 */
   PRINT_SETUP(10, "NBR");
   PRINT_SETUP(24, "NBR");
   PRINT_SETUP(30, "NAME");
   PRINT_SETUP(62, "GRP");
   PRINT_SETUP(68, "TYPE");
   PRINT_SETUP(74, "EMPCC");
   PRINT_SETUP(81, "STAIN");
   PRINT_SETUP(88, "STACT");
   PRINT_SETUP(95, "DSSTA");
   PRINT_SETUP(102, "START DT");
   PRINT_SETUP(112, "BIRTH DT");
   memcpy(appl_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
  
   /* application heading 3 */
   PRINT_SETUP(10, "____________");
   PRINT_SETUP(24, "____");
   PRINT_SETUP(30, "______________________________");
   PRINT_SETUP(62, "____");
   PRINT_SETUP(68, "____");
   PRINT_SETUP(74, "_____");
   PRINT_SETUP(81, "_____");
   PRINT_SETUP(88, "_____");
   PRINT_SETUP(95, "_____");
   PRINT_SETUP(102, "________");
   PRINT_SETUP(112, "________");
   memcpy(appl_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 4 */
   PRINT_SETUP(10, "ERROR - ");
   memcpy(appl_heading_4,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3000_ProcessDetail                       **
**                                                               **
** Description:     Process detail line, read next record and    **
**                  determine if there was a control break       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3000_ProcessDetail()
{
    RFM_3100_ProcessReportRecord();
    rfm_ReadNextRecord();
}



/******************************************************************
**                                                               **
** Function Name:   RFM_3100_ProcessReportRecord                 **
**                                                               **
** Description:     Format detail line, add amounts to control   **
**                  totals.                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3100_ProcessReportRecord()
{
   /*********************************************************/
   /* Save Error Type if it changes, and start a new page   */
   /*********************************************************/
   if (rpt_data.F5032_RptDataStruct.cEmplArRecInd != cSaveRecInd)
      {
      cSaveRecInd = rpt_data.F5032_RptDataStruct.cEmplArRecInd;
      strcpy(sSaveSource, rpt_data.F5032_RptDataStruct.sNrevSrcCd);
      strcpy(sSavePprNbr, rpt_data.F5032_RptDataStruct.sPprNbr);
      strcpy(sSaveNrevNbr, rpt_data.F5032_RptDataStruct.sNrevNbr);

      if (cFirstTime == 'N')
         {
         RFM_3200_ProcessTotals();
         }
      }
    
   if (cFirstTime == 'Y')
      cFirstTime = 'N';

   /***************************************/                                       
   /* Format and print the detail line    */                                       
   /***************************************/                                       
   PRINT_SETUP(10, rpt_data.F5032_RptDataStruct.sPprNbr);        /* PPR Nbr */
   PRINT_SETUP(24, rpt_data.F5032_RptDataStruct.sNrevNbr);       /* Nrev Nbr */
   PRINT_SETUP(30, rpt_data.F5032_RptDataStruct.sNrevNm);        /* Name */
   PRINT_SETUP(62, rpt_data.F5032_RptDataStruct.sPassGrpCd);     /* Pass Grp Cd */
   PRINT_SETUP(68, rpt_data.F5032_RptDataStruct.sNrevTypCd);     /* Psgr Type Code */
   PRINT_SETUP(74, rpt_data.F5032_RptDataStruct.sPprStCd);       /* EMPCC */

   memset(sCharString,rpt_data.F5032_RptDataStruct.cEmplArStsInd,1);
   PRINT_SETUP(81,sCharString);

   PRINT_SETUP(88, rpt_data.F5032_RptDataStruct.sEmplArActnCd);  /* STACT */
   PRINT_SETUP(95, rpt_data.F5032_RptDataStruct.sFltClsSvcId);   /* DSSTA */

   PRINT_SETUP(102, rpt_data.F5032_RptDataStruct.sPprStrtDt);    /* Pass Start Date */
   PRINT_SETUP(112, rpt_data.F5032_RptDataStruct.sNrevBdayDt);   /* Pass Rider Birth Date */
   rfm_ControlPrint(SINGLE_SPACE, print_line);

   /* Add detail amounts to accumulators */

 }



/******************************************************************
**                                                               **
** Function Name:   RFM_3200_ProcessTotals                       **
**                                                               **
** Description:     Format and print Total Lines                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3200_ProcessTotals()
{

   /** print the group total **/

   if (cEndOfRpt == 'N')
      RFM_5000_PageHeadings();
}

/******************************************************************
**                                                               **
** Function Name:   RFM_4000_ProcessEndOfJob                     **
**                                                               **
** Description:     Format grand total line, print end of report **
**                  line, close input file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4000_ProcessEndOfJob()
{
   /* Set end of report indicator to yes */
   cEndOfRpt = 'Y';

   /* print group totals   */
   RFM_3200_ProcessTotals();

   PRINT_SETUP(3, "END OF REPORT");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_5000_PageHeadings                        **
**                                                               **
** Description:     Format and print heading line                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_5000_PageHeadings()
{
   char sNbrOfReportPages[4];  /* Number of report pages written */
 
   nRptPagesWritten++;
 
   /**********************************************/
   /* Format standard report headings            */
   /**********************************************/
   memcpy(print_line,std_heading_1,PAGE_WIDTH);
   sprintf(sNbrOfReportPages,"%3i",nRptPagesWritten);
   PRINT_SETUP(128,sNbrOfReportPages);
   rfm_PrintLine(NEW_PAGE,print_line);
 
   memcpy(print_line,std_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   memcpy(print_line,std_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
 
   /**********************************************/
   /* Format and  print the application headings */
   /**********************************************/
   memcpy(print_line,appl_heading_1,PAGE_WIDTH);
   rfm_PrintLine(DOUBLE_SPACE, print_line);
   
   memcpy(print_line,appl_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);

   memcpy(print_line,appl_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
   rfm_PrintLine(SINGLE_SPACE, print_line);

   memcpy(print_line,appl_heading_4,PAGE_WIDTH);
   if (cSaveRecInd == ERROR_1)
      sprintf(sErrorText,"%s",ERROR_1_MSG);
   if (cSaveRecInd == ERROR_2)
      sprintf(sErrorText,"%s",ERROR_2_MSG);
   if (cSaveRecInd == ERROR_3)
      sprintf(sErrorText,"%s",ERROR_3_MSG);
   if (cSaveRecInd == ERROR_4)
      sprintf(sErrorText,"%s",ERROR_4_MSG);
   if (cSaveRecInd == ERROR_5)
      sprintf(sErrorText,"%s",ERROR_5_MSG);
   if (cSaveRecInd == ERROR_6)
      sprintf(sErrorText,"%s",ERROR_6_MSG);
   if (cSaveRecInd == ERROR_7)
      sprintf(sErrorText,"%s",ERROR_7_MSG);
   if (cSaveRecInd == ERROR_8)
      sprintf(sErrorText,"%s",ERROR_8_MSG);
   if (cSaveRecInd == ERROR_9)
      sprintf(sErrorText,"%s",ERROR_9_MSG);
   if (cSaveRecInd == ERROR_0)
      sprintf(sErrorText,"%s",ERROR_0_MSG);

   /** format and print the application sub-heading **/
   PRINT_SETUP(17,sErrorText);
   rfm_PrintLine(SINGLE_SPACE, print_line);
   rfm_PrintLine(SINGLE_SPACE, print_line);

}



/******************************************************************
**                                                               **
** Function Name:   CenterPosition                               **
**                                                               **
** Description:     Calculates number of positions to move       **
**                  to position text in center of field          **
**                                                               **
** Arguments:       Length of field                              **
**                  Input character string                       **
**                                                               **
** Return Values:   Position to center character string          **
**                                                               **
**                                                               **
******************************************************************/
 
int CenterPosition(int nLength, char sInput[])
{
   int nNbr;      /* Position to center string */
 
   nNbr = (nLength - (int)strlen(sInput)) / 2;
   return nNbr;
}
