/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB90008.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Gillian Lyth                                           **
**                                                                         **
** Date Written:    Feb 22, 1996                                           **
**                                                                         **
** Description:     Database driven programs use, as their primary input,  **
**                  a Sybase database.  The database is scanned and        **
**                  updated and/or transactions are generated for          **
**                  subsequent processing steps. This program reads from   **
**                  the Pass System and extracts information on pass usage **
**                  by Ready Reserve passengers. It writes the report      **
**                  records for the Ready Reserve report.                  **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 11/12/96     FFA                       Rewrote service 4247 to only     **
**                                        extract information for Ready    **
**                                        reserve passengers - Sick Leave  **
**                                        is no longer part of this report.**
**                                                                         **
****************************************************************************/
#include "epb90008.h"

main()
{
   BCH_Init("EPB90008", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short   nRptIndex,                 /* Report index */
           nReqRptInd1 = FALSE;       /* Required report #1 indicator */

   char   *pDate1,                    /* Pointer to reporting beginning and end dates */
          *pDate2;                     


   /**** Initialize RSAM Save fields with space ****/
   strcpy(sSavePprNbr, SPACE_CHAR);
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sFltFeeBegDt, SPACE_CHAR);
   strcpy(RS.sFltFeeEndDt, SPACE_CHAR);
   RS.lTotalLegCnt = 0;

   /**** Assign report ending date to variables ****/
   pDate1 = (char *) getenv("DATE1");
   strcpy(RS.sFltFeeBegDt, pDate1);
   pDate2 = (char *) getenv("DATE2");
   strcpy(RS.sFltFeeEndDt, pDate2);

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */

   /****** Initialize Request and Answer Blocks *****/
   memset(&R04247.R04247_appl_area, LOW_VALUES, sizeof(_R04247_APPL_AREA));
   memset(&A04247.A04247_appl_area, LOW_VALUES, sizeof(_A04247_APPL_AREA));
   strcpy(R04247.R04247_appl_area.sPprNbr, RS.sPprNbr);
   strcpy(R04247.R04247_appl_area.sFltFeeBegDt, RS.sFltFeeBegDt);
   strcpy(R04247.R04247_appl_area.sFltFeeEndDt, RS.sFltFeeEndDt);
   R04247.R04247_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to retrieve Ready Reserve Flight Leg data ***/                       
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04247,&A04247,SERVICE_ID_04247,1,sizeof(_R04247_APPL_AREA));
 
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         strcpy(sSavePprNbr, A04247.A04247_appl_area.sPprNbr);
         strcpy(RS.sPprNbr, A04247.A04247_appl_area.sPprNbr);
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS4247");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows for Ready Reserve  Report ****/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND) 
   {
      DPM_2500_ProcessRows();
      RS.lTotalLegCnt++;

      /*** Get next Ready Reserve row ***/
      R04247.R04247_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04247, LOW_VALUES, sizeof(_A04247));
   
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04247,&A04247,SERVICE_ID_04247,1,sizeof(_R04247_APPL_AREA));
   
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS4247");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{

   /*** If the ppr number changes save the ppr information ***/
   if (strcmp(A04247.A04247_appl_area.sPprNbr, sSavePprNbr) != 0)
   {
      strcpy(sSavePprNbr, A04247.A04247_appl_area.sPprNbr);
      strcpy(RS.sPprNbr, A04247.A04247_appl_area.sPprNbr);
   }  

   /*** Generate the report record ***/
   DPM_5010_Generate();                                          

}

/******************************************************************
**                                                               **
** Function Name:   DPM_5010_Generate                            **
**                                                               **
** Description:     Write report records for report              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_5010_Generate()
{
   short     nRptIndex;                 /* Index into the report control table */
   char      cRecEndLineTxt = '\n';
  
   /**** Initialize report sort and data copybooks ****/
   memset(&EPRF9008.F9008_RptDataStruct, LOW_VALUES, sizeof(_F9008_RPTDATASTRUCT));
   memset(&EPRS9008.S9008_RptDataStruct, LOW_VALUES, sizeof(_S9008_RPTDATASTRUCT));

   /**** Format report fields in sort and data layouts ****/
   strcpy(EPRF9008.F9008_RptDataStruct.sPprStnId, A04247.A04247_appl_area.sPprStnId);
   strcpy(EPRF9008.F9008_RptDataStruct.sPprDeptNbr, A04247.A04247_appl_area.sPprDeptNbr);
   strcpy(EPRF9008.F9008_RptDataStruct.sPprNbr, A04247.A04247_appl_area.sPprNbr);
   strcpy(EPRF9008.F9008_RptDataStruct.sNrevNbr, A04247.A04247_appl_area.sNrevNbr);
   strcpy(EPRF9008.F9008_RptDataStruct.sPprNm, A04247.A04247_appl_area.sPprNm);
   strcpy(EPRF9008.F9008_RptDataStruct.sNrevNm, A04247.A04247_appl_area.sNrevNm);
   strcpy(EPRF9008.F9008_RptDataStruct.sNrevTypCd, A04247.A04247_appl_area.sNrevTypCd);
   strcpy(EPRF9008.F9008_RptDataStruct.sPassTypCd, A04247.A04247_appl_area.sPassTypCd);
   strcpy(EPRF9008.F9008_RptDataStruct.sFltOrigCtyId, A04247.A04247_appl_area.sFltOrigCtyId);
   strcpy(EPRF9008.F9008_RptDataStruct.sFltDestCtyId, A04247.A04247_appl_area.sFltDestCtyId);
   strcpy(EPRF9008.F9008_RptDataStruct.sFltNbr, A04247.A04247_appl_area.sFltNbr);
   strcpy(EPRF9008.F9008_RptDataStruct.sFltDprtDt, 
          UTL_ConvertDate(A04247.A04247_appl_area.sFltDprtDt,CNV_DB_TO_DD_MMM_YYYY));
   strcpy(EPRF9008.F9008_RptDataStruct.sFltFeeBegDt, 
          UTL_ConvertDate(RS.sFltFeeBegDt,CNV_DB_TO_MM_DD_YY));
   strcpy(EPRF9008.F9008_RptDataStruct.sFltFeeEndDt, 
          UTL_ConvertDate(RS.sFltFeeEndDt,CNV_DB_TO_MM_DD_YY));
   EPRF9008.F9008_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS9008.S9008_RptDataStruct.sPprStnId, A04247.A04247_appl_area.sPprStnId);
   strcpy(EPRS9008.S9008_RptDataStruct.sPprDeptNbr, A04247.A04247_appl_area.sPprDeptNbr);
   strcpy(EPRS9008.S9008_RptDataStruct.sPprNm, A04247.A04247_appl_area.sPprNm);
   strcpy(EPRS9008.S9008_RptDataStruct.sPprNbr, A04247.A04247_appl_area.sPprNbr);
   strcpy(EPRS9008.S9008_RptDataStruct.sNrevNbr, A04247.A04247_appl_area.sNrevNbr);
   strcpy(EPRS9008.S9008_RptDataStruct.sPassRptSortDt, 
          UTL_ConvertDate(A04247.A04247_appl_area.sPassRptSortDt,CNV_DB_TO_YYYYMMDD));

   /**** Write report record ****/
   BCH_WriteRptRec("EPB90018",&EPRS9008, sizeof(EPRS9008), &EPRF9008, sizeof(EPRF9008));
 
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   sprintf(sErrorMessage, "Total nbr of flt legs processed = %d", RS.lTotalLegCnt);
   BCH_FormatMessage(1,TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
