/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :                                                            **
**                                                                         **
** Program Name:    <EPB90006.c>                                           **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest                                             **
**                  kenneth hancock                                        **
**                                                                         **
** Date Written:                                                           **
**                                                                         **
** Description:     This program looks for non-rev passengers flying       **
**                  through British airports and generates the Air         **
**                  Passsenger Duty Tax Report.                            **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/
#include "epb90006.h"

main()
{
   BCH_Init("EPB90006", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short   nRptIndex,                 /* Report index */
           nReqRptInd1 = FALSE;       /* Required report #1 indicator */

   char    *pBegDate,
           *pEndDate;                /* pointers for dates    */

   /**** Set key to primary database to nulls/zero ****/
   strcpy(RS.sFltNbr, SPACE_CHAR);
   strcpy(RS.sFltArptPrTypCd, SPACE_CHAR);

   /**** Assign report beginning and ending dates to variables ****/
   pBegDate = (char *) getenv("DATE1");
   pEndDate = (char *) getenv("DATE2");
   memcpy(RS.sFltFeeBegDt, pBegDate, sizeof(RS.sFltFeeBegDt));
   memcpy(RS.sFltFeeEndDt, pEndDate, sizeof(RS.sFltFeeEndDt));

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */

   /****** Initialize Request and Answer Blocks *****/
   memset(&R02768.R02768_appl_area,LOW_VALUES, sizeof(_R02768_APPL_AREA));
   memset(&A02768.A02768_appl_area,LOW_VALUES,sizeof(_A02768_APPL_AREA));

   /****** Format R02768 keys for initial DB Read *****/
   strcpy(R02768.R02768_appl_area.sFltNbr, RS.sFltNbr);
   strcpy(R02768.R02768_appl_area.sFltArptPrTypCd, RS.sFltArptPrTypCd);
   strcpy(R02768.R02768_appl_area.sFltFeeBegDt, RS.sFltFeeBegDt);
   strcpy(R02768.R02768_appl_area.sFltFeeEndDt, RS.sFltFeeEndDt);

   R02768.R02768_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to retrieve driving rows  ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02768,&A02768,SERVICE_ID_02768,1,sizeof(_R02768_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         RS.nProcessedAllRows = TRUE;
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02768");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows ****/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      DPM_5010_Generate();

      R02768.R02768_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A02768,LOW_VALUES,sizeof(A02768));

      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02768,&A02768,SERVICE_ID_02768,1,sizeof(R02768.R02768_appl_area));

      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            RS.nProcessedAllRows = TRUE;
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02768");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   /*** NOTE: To generate a control report call the following report ***/
   /*** NOTE: This function is used to generate a control            ***/
   /*** NOTE: report based on the entire input file.                 ***/

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5010_Generate                            **
**                                                               **
** Description:     Write report records for report              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_5010_Generate()
{
   short     nRptIndex;      /* Index into the report control table */
  
   /*** Initialize copybooks ***/
   memset(&EPRF9006.F9006_RptDataStruct, LOW_VALUES, sizeof(_F9006_RPTDATASTRUCT));
   memset(&EPRS9006.S9006_RptDataStruct, LOW_VALUES, sizeof(_S9006_RPTDATASTRUCT));

   /** Format report fields in sort and data layouts **/
   strcpy(EPRF9006.F9006_RptDataStruct.sFltNbr, A02768.A02768_appl_area.sFltNbr);

   if (strcmp(A02768.A02768_appl_area.sFltArptPrTypCd, INTRAEURO) == 0)
   {
	  //EPRF9006.F9006_RptDataStruct.lPsgr5RatNbr =  A02768.A02768_appl_area.lPassTripNbr;
      sprintf(EPRF9006.F9006_RptDataStruct.sPsgr5RatNbr, "%8ld", A02768.A02768_appl_area.lPassTripNbr);
   }
   else
   {
	  //EPRF9006.F9006_RptDataStruct.lPsgr10RatNbr =  A02768.A02768_appl_area.lPassTripNbr;
      sprintf(EPRF9006.F9006_RptDataStruct.sPsgr10RatNbr, "%8ld", A02768.A02768_appl_area.lPassTripNbr);
   }
   EPRF9006.F9006_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS9006.S9006_RptDataStruct.sFltNbr, A02768.A02768_appl_area.sFltNbr);

   /**** Write report record ****/
   BCH_WriteRptRec("EPB90016",&EPRS9006, sizeof(EPRS9006), &EPRF9006, sizeof(EPRF9006));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_9500_ProcessEndOfProgram()
{
   /** include any logic here for final clean-up processing  **/
   /** e.g. producing a final summary record  **/
   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
