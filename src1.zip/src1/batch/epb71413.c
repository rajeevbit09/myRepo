/**************************************************************************** 
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         ** 
** Sub-System :                                                            **
**                                                                         ** 
** Program Name:    EPB71413.c                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.c>                                           **
**                                                                         **
** Program Type:    Batch Report Format Module with zero control breaks    **
**                                                                         **
** Author :         L. Scott                  		                   **
**                                                                         **
** Date Written:    May 14, 1998                                           **
**                                                                         **
** Description:     This program is a copy of EPB71412 modified to create  **
**                  the German Employee Nonrevenue Report                  **
**                                                                         **
** Revision Trail:                                                         ** 
**                                                                         ** 
** Date       Revised by         SIR #    Description                      ** 
** ----       ----------         -----    -----------                      ** 
**                                                                         ** 
**                                                                         ** 
****************************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "epb71413.h"
#include "bchrfmcd.h"

main()
{
   RFM_1000_InitializeFlds();
   while ((feof(stdin)) == 0)
      {
      RFM_3000_ProcessDetail();  
      }
   RFM_4000_ProcessEndOfJob();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1000_InitializeFlds                      **
**                                                               **
** Description:     Initialize fields, read initial record,      **
**                  zero accumulators                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1000_InitializeFlds()
{
   char   sCurrentDate[13];  /* current date in mm/dd/yy format */

   rfm_ReadNextRecord();
   
   /* Initialize totals */
   nRptPagesWritten = 0;
   
   /* No application accumulators */

   /* Get system date and time    */
   current = time((time_t *)0);
   strcpy(tu.t_str, ctime(&current));
   strftime(sCurrentDate,12,"%m/%d/%y",localtime(&current));

   tu.t_str[7] = tu.t_str[10]=tu.t_str[19]=tu.t_str[24]='\0';
 
   /* If report has an as of date, format the as of date here   */
   nCurrentLineCount = NEW_PAGE;
   memset(print_line,' ',PAGE_WIDTH);
   strcpy(sRequestId, input_area.rqst_id);

   /* Format and save standard headings */

   /* standard heading 1 */
   PRINT_SETUP(1,"CSR #:");
   PRINT_SETUP(11,"7983");
   PRINT_SETUP(56,STD_RPT_TITLE);
   PRINT_SETUP(115,"PAGE:");
   memcpy(std_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 2 */
   PRINT_SETUP(1,"REPORT:");
   PRINT_SETUP(11, "EPB71413");
   PRINT_SETUP(48, "GERMAN EMPLOYEE NONREVENUE TRAVEL");
   memcpy(std_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
 
   /* standard heading 3 */
   memset(&sFormatFld, LOW_VALUES, sizeof(sFormatFld));
   PRINT_SETUP(57, "AS OF ");
   PRINT_SETUP(63, sCurrentDate);
   memcpy(std_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 4 */
   PRINT_SETUP(17, "ACCOUNTING ADMINISTRATION");
   memcpy(std_heading_4,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 5 */
   PRINT_SETUP(17, "834");
   memcpy(std_heading_5,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 6 */
   PRINT_SETUP(17, "FRA");
   memcpy(std_heading_6,print_line, PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 7 */
   memset(&sFormatFld, LOW_VALUES, sizeof(sFormatFld));
   PRINT_SETUP(17, "FOLLOWING IS LAST MONTH'S TRAVEL FOR GERMAN EMPLOYEES AS OF ");
   PRINT_SETUP(77, sCurrentDate);
   PRINT_SETUP(86, "AND MAY ALSO");
   memcpy(std_heading_7,print_line,PAGE_WIDTH); 
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 8 */
   PRINT_SETUP(17, "INCLUDE TRAVEL FOR OTHER MONTHS NOT PREVIOUSLY REPORTED, THIS REPORT SERVES ONLY TO");
   memcpy(std_heading_8,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 9 */
   PRINT_SETUP(17, "PROVIDE INFORMATION TO DELTA'S FRANKFURT ACCOUNTING ADMINSTRATION OFFICE.  GERMAN");
   memcpy(std_heading_9,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH); 

   /* standard heading 10 */
/* PRINT_SETUP(17, "EMPLOYEES ARE RESPONSIBLE FOR REPORTING IMPUTED INCOME ASSOCIATED WITH NONREVENUE");
   memcpy(std_heading_10,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);   */

   /* standard heading 11 */
/* PRINT_SETUP(17, "TRAVEL TO THE TAX AUTHORITIES VIA THE SELF DECLARATION FORM NUMBER 0412-XXXXX.");
   memcpy(std_heading_11,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);  */

   /* application heading 1 */
   PRINT_SETUP(117, "EMPLOYEE");
   memcpy(appl_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 2 */
   PRINT_SETUP(66, "INTERTAX");
   PRINT_SETUP(80, "FLT");
   PRINT_SETUP(93, "FLT/TICKET");
   PRINT_SETUP(117, "PAYMENT");
   memcpy(appl_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 3 */
   PRINT_SETUP(17, "PPR ID");
   PRINT_SETUP(34, "PASSENGER NAME");
   PRINT_SETUP(66, "NUMBER");
   PRINT_SETUP(80, "DATE");
   PRINT_SETUP(93, "NUMBER");
   PRINT_SETUP(106, "ORIG-DEST");
   PRINT_SETUP(117, "(USD)");
   memcpy(appl_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 4 */
   PRINT_SETUP(17, "____________");
   PRINT_SETUP(34, "______________________________");
   PRINT_SETUP(66, "__________");
   PRINT_SETUP(80, "___________");
   PRINT_SETUP(93, "__________");
   PRINT_SETUP(106, "_________");
   PRINT_SETUP(117, "_____________");
   memcpy(appl_heading_4,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3000_ProcessDetail                       **
**                                                               **
** Description:     Process detail line, read next record and    **
**                  determine if there was a control break       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3000_ProcessDetail()
{
    RFM_3100_ProcessReportRecord();
    rfm_ReadNextRecord();
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3100_ProcessReportRecord                 **
**                                                               **
** Description:     Format detail line, add amounts to control   **
**                  totals.                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3100_ProcessReportRecord()
{
   nLinesInGroup = DETAIL_LINE;

   /* Set end of report indicator to no */
   cEndOfRpt = 'N';
     
  if (nCurrentLineCount > 56)
     {
      RFM_5000_PageHeadings();
     }   

  /* Print PPR information */   
  PRINT_SETUP(17, rpt_data.F7143_RptDataStruct.sPprNbr);
  PRINT_SETUP(27, rpt_data.F7143_RptDataStruct.sNrevNbr);
  PRINT_SETUP(34, rpt_data.F7143_RptDataStruct.sNrevNm);
  PRINT_SETUP(66, rpt_data.F7143_RptDataStruct.sPprInttxNbr);
  PRINT_SETUP(80, rpt_data.F7143_RptDataStruct.sFltDprtDt);
  PRINT_SETUP(93, rpt_data.F7143_RptDataStruct.sTktNbr);
  sprintf(sFormatFld, "%s-%s", rpt_data.F7143_RptDataStruct.sFltOrigCtyId,
                               rpt_data.F7143_RptDataStruct.sFltDestCtyId);
  PRINT_SETUP(106, sFormatFld);
  
  //sprintf(sFormatFld, "% 11.2f", rpt_data.F7143_RptDataStruct.fNrevPmtAmt);
  //PRINT_SETUP(117, sFormatFld);     
  PRINT_SETUP(117, rpt_data.F7143_RptDataStruct.sNrevPmtAmt);

  rfm_ControlPrint(SINGLE_SPACE, print_line); 
     
}

/******************************************************************
**                                                               **
** Function Name:   RFM_4000_ProcessEndOfJob                     **
**                                                               **
** Description:     Format grand total line, print end of report **
**                  line, close input file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4000_ProcessEndOfJob()
{

   /* Format end of report line */
   PRINT_SETUP(3,"END OF REPORT");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_5000_PageHeadings                        **
**                                                               **
** Description:     Format and print heading line                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_5000_PageHeadings()
{
   char sNbrOfReportPages[4];  /* Number of report pages written */
 
   nRptPagesWritten++;
 
   /*  Format first standard heading line */
   memcpy(print_line,std_heading_1,PAGE_WIDTH);
   sprintf(sNbrOfReportPages,"%3i",nRptPagesWritten);
   PRINT_SETUP(127,sNbrOfReportPages);
   rfm_PrintLine(NEW_PAGE,print_line);
 
   /*  Format second standard heading line */
   memcpy(print_line,std_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   /*  Format third standard heading line */
   memcpy(print_line,std_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);

   /* Format 4th heading */
   memset(print_line,' ',PAGE_WIDTH);
   rfm_PrintLine(TRIPLE_SPACE, print_line);
   memcpy(print_line,std_heading_4,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);

   /* Format 5th heading */
   memcpy(print_line,std_heading_5,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
   
   /* Format 6th heading */
   memcpy(print_line,std_heading_6,PAGE_WIDTH); 
   rfm_PrintLine(SINGLE_SPACE,print_line);      
  
   /* Format 7th heading */
   memcpy(print_line,std_heading_7,PAGE_WIDTH); 
   rfm_PrintLine(DOUBLE_SPACE,print_line);      
  
   /* Format 8th heading */
   memcpy(print_line,std_heading_8,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   /* Format 9th heading */
   memcpy(print_line,std_heading_9,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   /* Format 10th heading */
   PRINT_SETUP(17, "EMPLOYEES ARE RESPONSIBLE FOR REPORTING IMPUTED INCOME ASSOCIATED WITH NONREVENUE");
   rfm_ControlPrint(SINGLE_SPACE, print_line); 

   /* standard 11th heading */
   PRINT_SETUP(17, "TRAVEL TO THE TAX AUTHORITIES VIA THE SELF DECLARATION FORM NUMBER 0412-XXXXX.");
   rfm_ControlPrint(SINGLE_SPACE, print_line); 

 
   /*  Format application headings */
    memcpy(print_line,appl_heading_1,PAGE_WIDTH);
    rfm_PrintLine(TRIPLE_SPACE, print_line);

    memcpy(print_line,appl_heading_2,PAGE_WIDTH);
    rfm_PrintLine(SINGLE_SPACE, print_line);

    memcpy(print_line,appl_heading_3,PAGE_WIDTH);
    rfm_PrintLine(SINGLE_SPACE, print_line);

    memcpy(print_line,appl_heading_4,PAGE_WIDTH);
    rfm_PrintLine(SINGLE_SPACE, print_line);
    
    memset(print_line,' ',PAGE_WIDTH);
    rfm_PrintLine(SINGLE_SPACE, print_line);

}
