/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB90004.c                                             **
**                                                                         **
** Shell Used:      shldpmc.c                                              **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  C.Eachus                                               **
**                                                                         **
** Date Written:    6/21/95                                                **
**                                                                         **
** Description:     Database driven programs use, as their primary input,  **
**                  a Sybase database.  The database is scanned and        **
**                  updated and/or transactions are generated for          **
**                  subsequent processing steps. This program reads from   **
**                  the Audit Trail, Pass Type and Pass Group tables and   ** 
**                  extracts information on those attributes that have     **
**                  been modified within the last month.  It processes     **
**                  the records and generates the Pass Office Audit report.**
**                                                                         **
**                                                                         **
****************************************************************************/
#include "epb90004.h"

main()
{
   BCH_Init("EPB90004", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short   nRptIndex,                 /* Report index */
           nReqRptInd1 = FALSE;       /* Required report #1 indicator */

   char    *pDate1,                   /* Pointer to reporting beginning and end dates */
           *pDate2;

   /**** Set key to primary database to nulls/zero ****/
   //memset(&RS.sPassDtTmTs, LOW_VALUES, sizeof(RS.sPassDtTmTs));
   strcpy(RS.sPassDtTmTs, LOW_DATE);

   /**** Insert space into saved RS variables ****/
   //strcpy(RS.sPassDtTmTs, SPACE_CHAR);
   strcpy(RS.sFltFeeBegDt, SPACE_CHAR);
   strcpy(RS.sFltFeeEndDt, SPACE_CHAR);

   /**** Assign report ending date to variables ****/
   pDate1 = (char *) getenv("DATE1");
   strcpy(RS.sFltFeeBegDt, pDate1);
   pDate2 = (char *) getenv("DATE2");
   strcpy(RS.sFltFeeEndDt, pDate2);

   /**** Initialize flags ****/
   RS.nProcessedAllRows = FALSE; 

 
   memset(&R02808,LOW_VALUES, sizeof(_R02808));
   memset(&A02808,LOW_VALUES, sizeof(_A02808));
   
   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */

   /*** If it's the programs first run through set the nFirstTime flag to false and
        perform normal processing ***/

   /****** Initialize Request and Answer Blocks *****/
   memset(&R02808.R02808_appl_area, LOW_VALUES, sizeof(_R02808_APPL_AREA));
   memset(&A02808.A02808_appl_area, LOW_VALUES, sizeof(_A02808_APPL_AREA)); 

   R02808.R02808_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Format R02808 keys for initial DB Read ******/
   strcpy(R02808.R02808_appl_area.sPassDtTmTs, RS.sPassDtTmTs);
   strcpy(R02808.R02808_appl_area.sFltFeeBegDt, RS.sFltFeeBegDt);
   strcpy(R02808.R02808_appl_area.sFltFeeEndDt, RS.sFltFeeEndDt);
      
   /****** Execute service to retrieve driving rows  ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02808,&A02808,SERVICE_ID_02808,1,sizeof(_R02808_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS02808");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows for Pass Audit Report ****/
   while ((nSvcRtnCd != ARC_ROW_NOT_FOUND) && (RS.nProcessedAllRows == FALSE))
   {
      DPM_2500_ProcessRows();
      R02808.R02808_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A02808.A02808_appl_area, LOW_VALUES, sizeof(_A02808_APPL_AREA));

      /*** Call service to select any additional rows on the Audit Trail table that
           may have been updated within the last month ***/ 
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R02808,&A02808,SERVICE_ID_02808,1,sizeof(_R02808_APPL_AREA));

      /*** Service return code processing ***/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;
     
         case ARC_ROW_NOT_FOUND:
            /*** Set end of processing flag to true ***/       
            RS.nProcessedAllRows = TRUE;
            break;
 
         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS02808");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   /*** NOTE: To generate a control report call the following report ***/
   /*** NOTE: This function is used to generate a control            ***/
   /*** NOTE: report based on the entire input file.                 ***/

   /*** The control report is not generated for this program ***/

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   short nSvcRtnCd;   /*RSAM commit return code*/

   /*** Add program logic here to process the selected database row ***/

   /*** Call paragraph that formats the data and sort copybooks for the RfM module ***/
  
   DPM_5010_Generate();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_5010_Generate                            **
**                                                               **
** Description:     Write report records for report              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_5010_Generate()
{
   short nRptIndex;      /* Index into the report control table */
 
   /** Initialize report sort and data copybooks **/

   memset(&EPRF9004.F9004_RptDataStruct, LOW_VALUES, sizeof(_F9004_RPTDATASTRUCT));
   memset(&EPRS9004.S9004_RptDataStruct, LOW_VALUES, sizeof(_S9004_RPTDATASTRUCT));

   /** Format report fields in sort and data layouts **/
 
   /** sAcrlEffDt was used because an 8 byte char field was needed for the converted timestamp - 
   I realize this field doesn't make much sense in relation to the other audit trail fields but it
   serves the programs purposes **/

   strcpy(EPRF9004.F9004_RptDataStruct.sAcrlEffDt, 
          UTL_ConvertDate(A02808.A02808_appl_area.sPassDtTmTs,CNV_DB_TO_MM_DD_YY));
   strcpy(EPRF9004.F9004_RptDataStruct.sAudtUserId, A02808.A02808_appl_area.sAudtUserId);
   strcpy(EPRF9004.F9004_RptDataStruct.sPprNbr, A02808.A02808_appl_area.sPprNbr);
   strcpy(EPRF9004.F9004_RptDataStruct.sNrevNbr, A02808.A02808_appl_area.sNrevNbr);
   strcpy(EPRF9004.F9004_RptDataStruct.sPassGrpCd, A02808.A02808_appl_area.sPassGrpCd);
   strcpy(EPRF9004.F9004_RptDataStruct.sPassTypCd, A02808.A02808_appl_area.sPassTypCd);
   strcpy(EPRF9004.F9004_RptDataStruct.sAudtChgTypNm, A02808.A02808_appl_area.sAudtChgTypNm);
   strcpy (EPRF9004.F9004_RptDataStruct.sAudtChgFrNm, A02808.A02808_appl_area.sAudtChgFrNm);
   strcpy(EPRF9004.F9004_RptDataStruct.sAudtChgToNm, A02808.A02808_appl_area.sAudtChgToNm);
   strcpy(EPRF9004.F9004_RptDataStruct.sFltFeeBegDt, 
          UTL_ConvertDate(RS.sFltFeeBegDt,CNV_DB_TO_MM_DD_YY));
   strcpy(EPRF9004.F9004_RptDataStruct.sFltFeeEndDt, 
          UTL_ConvertDate(RS.sFltFeeEndDt,CNV_DB_TO_MM_DD_YY));
  
   EPRF9004.F9004_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS9004.S9004_RptDataStruct.sAcrlEffDt, 
          UTL_ConvertDate(A02808.A02808_appl_area.sPassDtTmTs,CNV_DB_TO_MM_DD_YY));
   strcpy(EPRS9004.S9004_RptDataStruct.sAudtUserId, A02808.A02808_appl_area.sAudtUserId);
   strcpy(EPRS9004.S9004_RptDataStruct.sPprNbr, A02808.A02808_appl_area.sPprNbr);
   strcpy(EPRS9004.S9004_RptDataStruct.sNrevNbr, A02808.A02808_appl_area.sNrevNbr);
   strcpy(EPRS9004.S9004_RptDataStruct.sPassGrpCd, A02808.A02808_appl_area.sPassGrpCd);
   strcpy(EPRS9004.S9004_RptDataStruct.sAudtChgTypNm, A02808.A02808_appl_area.sAudtChgTypNm);

   /*** Write report record ***/
   BCH_WriteRptRec("EPB90014",&EPRS9004, sizeof(EPRS9004), &EPRF9004, sizeof(EPRF9004));
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_9500_ProcessEndOfProgram()
{
   /** include any logic here for final clean-up processing  **/
   /** e.g. producing a final summary record  **/
   BCH_FormatMessage(1,TXT_PROC_SUCC_COMPL);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
