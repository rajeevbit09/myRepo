/*######################################################################*/
/*                                                                      */
/* Copyright [2001] Delta Air Lines, Inc./Delta Technology, Inc.   */
/*                       All Rights Reserved                            */
/*               Access, Modification, or Use Prohibited                */
/* Without Express Permission of Delta Air Lines or Delta Technology.   */
/*                                                                      */
/*######################################################################*/
/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB97712.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest, Inc.                                       **
**                  Gayle Melton                                           **
**                                                                         **
** Date Written:    October 28, 1996                                       **
**                                                                         **
** Description:     This module extracts ppr data from the PPR table       **
**                  based on hire dates and creates flight certificate     **
**                  records for the following pass groups:                 **
**                          AC,AK,MA,DA,DB,DS,DW,EW,FU,LK,LM,LS,LW,        **
**                          MD,OW,QK,QM,QT,RE,RL,RR,RT,TW,UW,WE,WR,        **
**                          WA,WB,WC,WD,WF,WG,WH,WK,WM,WS,WT,LP,LT,        **
**                          VA,VB,VC,VR,FP,IN,FV,TM,CU,TS,CZ,DP,KT,        **
**                          MT,ST,CB,CW,JK,JM and JS.                      **
**                                                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **  
** 04/24/98   S. Makim                    Process Delta Staffing ppr       **  
**                                        records as Delta Technology ppr  **  
**                                        records. Send F&F or A&B         **  
**                                        certificates to their home       **  
**                                        address.                         **  
**                                                                         **  
** 06/24/98   L. Scott                    Correct problem with Feb 29th    **
**                                        anniversary dates not being      **
**                                        processed.   Feb 28th effective  **
**                                        date will now process Feb 29th,  **
**                                        while any calculated Feb 29th    **
**                                        effective date will be skipped.  **
**                                                                         **
** 11/17/99   L. Scott                    Changed the starting extension   **
**                                        number for F&F certificates from **
**                                        80 to 60. Also restricting ppr   **
**                                        numbers starting with '7' (ASA   **
**                                        employees from getting F & F     **
**                                        certificates.                    **
**                                                                         **
** 03/31/00   L. Scott                    Added pass group LP to list of   **
**                                        pass groups eligible for F & F   **
**                                        certificates.                    **
**                                                                         **
** 08/11/00   E. Shelton                  Restrict ppr numbers that start  **
**                                        with '6' (OH) for F&F            **
**                                        certificates.                    **
**                                                                         **
** 12/01/00   L. Scott                    Remove code that restricts ASA   **
**                                        and Comair employees, ppr numbers**
**                                        starting with '7' and '6' from   **
**                                        receiving F&F certificates.      **
**                                                                         **
** 1/08/01    L. Scott                    Added VA,VB,VC and VR as eligible**
**                                        pass groups.                     **
**                                                                         **
** 11/30/01   L. Scott                    Added FP as an eligible pass     **
**                                        group.                           **
**                                                                         **
** 01/02/02   E. Shelton                  Added IN as an eligible pass     **
**                                        group.                           **
**                                                                         **
** 11/08/02   L. Scott                    Added FV as an eligible pass     **
**                                        group.                           **
**                                                                         **
**                                                                         **
** 10/02/03   L. Scott                    Added TM as an eligible pass     **
**                                        group.                           **
**                                                                         **
** 09/20/04   L. Scott                    Added CU as an eligible pass     **
**                                        group.                           **
**                                                                         **
** 10/01/04   L. Scott                    Added TS as an eligible group    **
**                                                                         **
** 03/03/05   L. Scott                    Changes for ESS2 to generate     **
**                                        buddy passes for curent date     **
**                                        only.  
**                                        Also made changes to make 98 the **
**                                        last extension number issued, so **
**                                        that 99 can be of special use for**
**                                        a lap child on intl flights.     **
**                                                                         **
** 12/06/07   L. Scott                    Added CZ as an eliglble group.   **
**                                                                         **
** 7/10/09    L. Scott                    Added DP,KT,MT,ST,CB and CW as   **
**                                        eligible pass groups.            **
**                                                                         **
** 12/10/10   L. Scot                     Added JK,JM and JS as eligible   **
**                                        pass groups.                     **
**                                                                         **
****************************************************************************/
#include "epb97712.h"

main()
{
   BCH_Init("EPB97712", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   /**** Initialize key fields ****/
   strcpy(sPprNbr, SPACE_CHAR);
 /*  strcpy(RS.sPprNbr, SPACE_CHAR); */

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   memset(&R04572, LOW_VALUES, sizeof(_R04572)); 
   memset(&A04572, LOW_VALUES, sizeof(_A04572)); 
   memset(&R04603, LOW_VALUES, sizeof(_R04603)); 
   memset(&A04603, LOW_VALUES, sizeof(_A04603)); 
   memset(&R04599, LOW_VALUES, sizeof(_R04599)); 
   memset(&A04599, LOW_VALUES, sizeof(_A04599)); 
   memset(&R04586, LOW_VALUES, sizeof(_R04586)); 
   memset(&A04586, LOW_VALUES, sizeof(_A04586)); 

}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   char   *pEffDt;                    /* Pointer to effective date */

   /**** Assign start date to variable ****/
   pEffDt = (char *) getenv("DATE1");
   strcpy(sEffDt, pEffDt);
 /*strcpy(RS.sEffDt, pEffDt);  */

  
   /**** Initialize effective month and day ****/ 
   memset(&sEffMo, LOW_VALUES, sizeof(sEffMo)); 
   memset(&sEffDy, LOW_VALUES, sizeof(sEffDy)); 
   memset(&sEffYr, LOW_VALUES, sizeof(sEffYr)); 
  
   /**** Assign effective month and day from pass effective date ****/ 
   strncpy(sEffMo, sEffDt+5, 2); 
   strncpy(sEffDy, sEffDt+8, 2); 
   strncpy(sEffYr, sEffDt+2, 2); 
   /****
   RS.nMonth = atoi(sEffMo); 
   RS.nDay = atoi(sEffDy); 
   ****/
   nMonth = atoi(sEffMo); 
   nDay = atoi(sEffDy); 

   /****** Initialize request and answer blocks *****/
   memset(&R04572.R04572_appl_area, LOW_VALUES, sizeof(_R04572_APPL_AREA));
   memset(&A04572.A04572_appl_area, LOW_VALUES, sizeof(_A04572_APPL_AREA));

   /**** Format service request block for initial DB cursor read ****/
   strcpy(R04572.R04572_appl_area.sPprNbr, sPprNbr);
 /*strcpy(R04572.R04572_appl_area.sPprNbr, RS.sPprNbr);  */

   /**** Open the DB cursor ****/
   R04572.R04572_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /**** Execute service to select all active PPRs ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04572,&A04572,SERVICE_ID_04572,1,sizeof(_R04572_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04572");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  
   
   /**** Process driving database rows ****/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      DPM_2500_ProcessRows();

      R04572.R04572_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04572.A04572_appl_area,LOW_VALUES,sizeof(_A04572_APPL_AREA));

      /**** Execute service to obtain next DB row ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04572,&A04572,SERVICE_ID_04572,1,sizeof(R04572.R04572_appl_area));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04572");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
 
      }  
   }

   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void    DPM_2500_ProcessRows()
{
   char   sStrtMo[2];     /** PPR start month MM **/
   char   sStrtDy[2];     /** PPR start day DD   **/  


   /**** Initialize date fields ****/
   memset(&sStrtMo, LOW_VALUES, sizeof(sStrtMo));
   memset(&sStrtDy, LOW_VALUES, sizeof(sStrtDy));
 
   /**** Format PPR start date without slash delimiters ****/
   strncpy(sStrtMo, A04572.A04572_appl_area.sPprStrtDt+DB_TS_POS_MON, 2);
   strncpy(sStrtDy, A04572.A04572_appl_area.sPprStrtDt+DB_TS_POS_DAY, 2);

   /**** Skip records with a Feb 29th start date ***/
   if ((strcmp(sEffMo, "02") == 0) && (strcmp(sEffDy, "29") == 0))
   {
       /******************************************************/
       /** Do not process Feb 29th effective dates         ***/
       /******************************************************/
   }
   else
   {
      /**** Process records with start dates matching input date ****/ 
      /**** or process Feb 29th start dates if the effective     ****/
      /**** date is Mar 1st.                                     ****/

      if (((strncmp(sStrtMo, sEffMo, 2) == 0) && (strncmp(sStrtDy, sEffDy, 2) == 0)) ||
         ((strncmp(sEffMo, "03", 2) == 0) && (strncmp(sEffDy, "01", 2) == 0) &&
         (strncmp(sStrtMo, "02", 2) == 0) && (strncmp(sStrtDy, "29", 2) == 0))) 
      {

         if (((strcmp(A04572.A04572_appl_area.sNrevSrcCd, "MN") == 0) &&
            (strncmp(A04572.A04572_appl_area.sPprNbr, "MN", 2) != 0)) ||
            (strncmp(A04572.A04572_appl_area.sPprNbr, "TQ", 2) == 0))
         {  
            /*****************************************************************/
            /** Do not process Manual PPR unless it has a Manual PPR number **/
            /** or do not process PPR number starting with 'TQ'.            **/
            /*****************************************************************/
         }
         else
         {
            /*******************************************************************************************/
            /*  Process valid pass goups                                                               */
            /*******************************************************************************************/
            if (!strcmp(A04572.A04572_appl_area.sPassGrpCd, "AC") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "AK") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "CB") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "CU") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "CW") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "CZ") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "DP") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "DA") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "DB") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "DS") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "DW") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "EW") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "FP") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "FU") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "FV") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "IN") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "JK") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "JM") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "JS") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "KR") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "KT") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "LK") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "LM") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "LP") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "LS") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "LT") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "LW") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "MA") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "MD") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "MR") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "MT") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "OW") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "QK") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "QM") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "QT") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "RE") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "RL") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "RR") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "RT") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "SK") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "SM") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "SO") || 
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "SR") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "ST") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "TM") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "TS") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "TW") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "UW") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "VA") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "VB") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "VC") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "VR") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "WA") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "WB") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "WC") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "WD") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "WF") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "WK") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "WM") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "WR") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "WS") ||
                !strcmp(A04572.A04572_appl_area.sPassGrpCd, "WT"))
            {
               DPM_3000_WriteRecord(); 
            }
            else
            {
               /** Do Nothing: Some pass groups are not eligible to receive  **/
               /** Friends and Family certificates.                               **/
	        }
         }
      } 
   } 
}
   
/******************************************************************
**                                                               **
** Function Name:   DPM_3000_WriteRecord                         **
**                                                               **
** Description:     Format data for the flight certificate       **
**                  table records.                               **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_3000_WriteRecord()
{
   char   sSpace;            /** Space character **/
   short  i;                 /** Counter **/

   /**** Initialize date fields ****/
   memset(&sIssueDt, LOW_VALUES, sizeof(sIssueDt));

   /**** Format Certficate issue date without slash delimiters ****/
   strcpy(sIssueDt, sEffMo);
   strcpy(sIssueDt+2, sEffDy);
   strcpy(sIssueDt+4, sEffYr);

   /****** Initialize request and answer blocks *****/
   memset(&R04603, LOW_VALUES, sizeof(_R04603));
   memset(&A04603, LOW_VALUES, sizeof(_A04603));
 
   /**** Format service request block ****/
   strcpy(R04603.R04603_appl_area.sPassGrpCd, A04572.A04572_appl_area.sPassGrpCd);
   strcpy(R04603.R04603_appl_area.sNrevTypCd, NREV_TYP);
   strcpy(R04603.R04603_appl_area.sPassTypCd, PASS_TYP);
 
   /**** Execute service to find certificate count from pass allotment table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04603,&A04603,SERVICE_ID_04603,1,sizeof(_R04603_APPL_AREA));
 
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd) 
   {
      case ARC_SUCCESS:
         nFltAllotDyNbr = A04603.A04603_appl_area.nFltAllotDyNbr;
         break;
 
      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_3000_WriteRecord");
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04603");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_WriteRecord");
   }

   /******************************************************************************/
   /* execute service to get the last certificate number issued for the ppr   ****/    
   /******************************************************************************/
   /****** Initialize request and answer blocks *****/
   memset(&R04599, LOW_VALUES, sizeof(_R04599));
   memset(&A04599, LOW_VALUES, sizeof(_A04599));
 
   /**** Format service request block  ****/
   strcpy(R04599.R04599_appl_area.sPprNbr, A04572.A04572_appl_area.sPprNbr);
   R04599.R04599_appl_area.cCertftTypCd = 'F';
 
   /**** Execute service to get last certificate number *****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ2,&R04599,&A04599,SERVICE_ID_04599,1,sizeof(_R04599_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {   
      case ARC_SUCCESS:
         
         /*********************************************/
         /*                                           */
         /* calculate next certificate number         */
         /*                                           */
         /*********************************************/
         nLastExtnNbr = atoi(A04599.A04599_appl_area.sCertftExtnNbr);
         nExtnNbr = nLastExtnNbr;

         for(i = 1; i <= nFltAllotDyNbr; i++)
         {
            nExtnNbr++;
            if (R04599.R04599_appl_area.cCertftTypCd == 'F' && nExtnNbr >= 98)
               nExtnNbr = 60;

            /*******************************************/
            /*  write certificate record               */
            /*******************************************/
            DPM_3100_WriteRecord();
         }
         break;

      case ARC_ROW_NOT_FOUND:
         
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_3000_WriteRecord");
 
         /*************************************************/
         /* No certificate numbers exist for ppr; insert  */
         /* records starting with 60                      */
         /*************************************************/ 

         if (R04599.R04599_appl_area.cCertftTypCd = 'F')
            nExtnNbr = 59;
         
         for(i = 1; i <= nFltAllotDyNbr; i++)
         {
            nExtnNbr++;
            if (R04599.R04599_appl_area.cCertftTypCd == 'F' && nExtnNbr >= 98)
               nExtnNbr = 60;

            /*******************************************/  
            /*  write certificate record               */
            /*******************************************/ 
            DPM_3100_WriteRecord();
         }
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04599");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3000_WriteRecord");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3100_WriteRecord                         **
**                                                               **
** Description:     Write certificate records to the             **
**                  certificate table.                           **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
int DPM_3100_WriteRecord()
{
   short     nSvcRtnCd;      /* Service return code */

   /**** Initialize Service Request and Answer blocks ****/
   memset(&A04586.A04586_appl_area, LOW_VALUES, sizeof(_A04586_APPL_AREA));
   memset(&R04586.R04586_appl_area, LOW_VALUES, sizeof(_R04586_APPL_AREA));

   R04586.R04586_appl_area.cFltCrtfSttCd = 'U';
   strcpy(R04586.R04586_appl_area.sPprNbr, A04572.A04572_appl_area.sPprNbr);
   sprintf(R04586.R04586_appl_area.sCertftExtnNbr, "%d", nExtnNbr);
   strcpy(R04586.R04586_appl_area.sPassDtTmTs, STP_GetDBTimestamp());
   strcpy(R04586.R04586_appl_area.sFltCertftNbr, NULL_STRING);
   R04586.R04586_appl_area.cCertftTypCd = 'F';
   strcpy(R04586.R04586_appl_area.sCertftIssDt, sEffDt);
   strcpy(R04586.R04586_appl_area.sProcDt, DEFAULT_DATE);
   strcpy(R04586.R04586_appl_area.sCertftExpDt, DEFAULT_DATE);
   R04586.R04586_appl_area.cBlklstResnCd = 'N';
   strcpy(R04586.R04586_appl_area.sBlklstProcDt, DEFAULT_DATE);
   strcpy(R04586.R04586_appl_area.sSvcChrgCd, NO_CHRG);
   strncpy(R04586.R04586_appl_area.sCertftIssYr, sEffDt, 4);
   R04586.R04586_appl_area.cCertftUseInd = 'N';
   strcpy(R04586.R04586_appl_area.sArchLastUpdtTs, STP_GetDBTimestamp());
   R04586.R04586_appl_area.lSeqID = 0;
   /*
   strcpy(R04586.R04586_appl_area.cFltCrtfSttCd, NO_IND);
*/
   /**** Execute service to perform primitive insert to pass card table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04586,&A04586,SERVICE_ID_04586,1,sizeof(_R04586_APPL_AREA));
 
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;
 
      case ARC_DUPLICATE_ROW:
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04586");
         BCH_FormatMessage(3,TXT_PPR,R04586.R04586_appl_area.sPprNbr);
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3100_WriteRecord");
   } 

}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
