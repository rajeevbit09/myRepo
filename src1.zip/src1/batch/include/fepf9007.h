/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF9007                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/29/96                                                */
/*              Time: 10:48:34                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF9007                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY003585_LEN                                                          
#define   FY003585_LEN                         27                               
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F9007_RPTDATASTRUCT_z                                                  
#define _F9007_RPTDATASTRUCT_z                                                  
typedef struct __F9007_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltOrigCtyId[FY002521_LEN];                             
   char                sFltNbr[FY002553_LEN];                                   
   char                sFltDprtDt[FY003584_LEN];                                
   char                sFltDestCtyId[FY002522_LEN];                             
   char                sNrevNm[FY002531_LEN];                                   
   char                sPprNm[FY002480_LEN];                                    
   char                sFltFeeBegDt[FY003585_LEN];                              
   char                sFltFeeEndDt[FY003586_LEN];                              
   char                cRecEndLineTxt;                                          
}  _F9007_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF9007_z                                                             
#define _EPRF9007_z                                                             
                                                                                
   typedef struct __EPRF9007                                                    
   {                                                                            
      _F9007_RPTDATASTRUCT F9007_RptDataStruct;                                 
   }  _EPRF9007;                                                                
#endif                                                                          
                                                                                
