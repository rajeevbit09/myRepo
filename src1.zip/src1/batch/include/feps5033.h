/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5033                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 12/19/2012                                              */
/*              Time: 10:00:00                                                */
/******************************************************************************/

/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5033                           */
/******************************************************************************/

#ifndef   FY003334_LEN
#define   FY003334_LEN                         1
#endif
#ifndef   FY002479_LEN
#define   FY002479_LEN                         10
#endif
#ifndef   FY002516_LEN
#define   FY002516_LEN                         3
#endif
#ifndef _S5033_RPTDATASTRUCT_z
#define _S5033_RPTDATASTRUCT_z
typedef struct __S5033_RptDataStruct
{
   char                cEmplArRecInd;
   char                sPprNbr[FY002479_LEN];
   char                sNrevNbr[FY002516_LEN];
}  _S5033_RPTDATASTRUCT;
#endif

#ifndef _EPRS5033_z
#define _EPRS5033_z

   typedef struct __EPRS5033
   {
      _S5033_RPTDATASTRUCT S5033_RptDataStruct;
   }  _EPRS5033;
#endif

