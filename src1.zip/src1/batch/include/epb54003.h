/****************************************************************************
**                                                                         **
** File Name :      EPB54003.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Transquest Information Solutions                       **
**                  LaShawnda Walker                                       **
**                                                                         **
** Date Created:    8/13/98                                                **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include <time.h>

/* Service request and answer blocks  */
#include "fyr03932.h"  
#include "fya03932.h" 
#include "fyr04621.h"  
#include "fya04621.h" 
 
_R03932 R03932;   
_A03932 A03932;   
_R04621 R04621;   
_A04621 A04621;   

#define SERVICE_ID_03932  3932
#define SERVICE_ID_04621  4621

/* Function definitions   */
void DPM_1000_Initialize();
void DPM_2000_Mainline();

/* #defines and global variables   */
#define NUMBER_OF_THREADS 3
#define EPBUPD0 0        
#define EPBINQ0 1        
#define EPBINQ1 2        
#define COST_CHRG_MAX_LEN 6        

struct {
  char sSvcChrgCd[3],
  sSvcChrgDs[16];
} svc_chrg[3];


static struct
{
  char start_of_save;
  int EPBF040;
  char EPBF040_buffer[262];
  char sCycleId[3];
  char sTodayDt[9];
  char end_of_save;
} RS;
