/****************************************************************************
**                                                                         **
** File Name :      EPB40000.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author:          Duane Ellis                                            **
**                                                                         **
** Date Created:    3/2010                                                 **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         Description                               **
** ----       ----------         --------------------                      **
** 03/04/2010 DHE                Inital Program Creation                   **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/* Service request and answer blocks */

#include "fyr02437.h"
#include "fya02437.h"
#include "fyr03834.h"
#include "fya03834.h"
#include "fyr04728.h"
#include "fya04728.h"
#include "fyr04732.h"
#include "fya04732.h"
#include "fyr04733.h"
#include "fya04733.h"
#include "fyr04734.h"
#include "fya04734.h"
#include "fyr04735.h"
#include "fya04735.h"
#include "fyr04736.h"
#include "fya04736.h"
#include "fyr04737.h"
#include "fya04737.h"
#include "fyr04738.h"
#include "fya04738.h"
#include "fyr04740.h"
#include "fya04740.h"
#include "fyr04741.h"
#include "fya04741.h"
#include "fyr04742.h"
#include "fya04742.h"
#include "fyr04743.h"
#include "fya04743.h"
#include "fyr04744.h"
#include "fya04744.h"
#include "fyr04746.h"
#include "fya04746.h"
#include "fyr04748.h"
#include "fya04748.h"
#include "fyr04755.h"
#include "fya04755.h"

_R02437 R02437;
_A02437 A02437;
_R03834 R03834;
_A03834 A03834;
_R04728 R04728;
_A04728 A04728;
_R04732 R04732;
_A04732 A04732;
_R04733 R04733;
_A04733 A04733;
_R04734 R04734;
_A04734 A04734;
_R04735 R04735;
_A04735 A04735;
_R04736 R04736;
_A04736 A04736;
_R04737 R04737;
_A04737 A04737;
_R04738 R04738;
_A04738 A04738;
_R04740 R04740;
_A04740 A04740;
_R04741 R04741;
_A04741 A04741;
_R04742 R04742;
_A04742 A04742;
_R04743 R04743;
_A04743 A04743;
_R04744 R04744;
_A04744 A04744;
_R04746 R04746;
_A04746 A04746;
_R04748 R04748;
_A04748 A04748;
_R04755 R04755;
_A04755 A04755;


#define SERVICE_ID_03834  3834   /** SELECT T_PPR using PPR_NBR                           **/
#define SERVICE_ID_02437  2437   /** VALIDATE NRev_Nbr in T_NREV_PSGR                     **/
#define SERVICE_ID_04728  4728   /** SELECT ppr_nbr from t_ppr using NW employee number   **/
#define SERVICE_ID_04732  4732   /** INSERT record INTO RPAD_FLWN_FL_SPNS                 **/
#define SERVICE_ID_04733  4733   /** SELECT record from RPAD_FLWN_FL_SPNS by LstUpdtId    **/
#define SERVICE_ID_04734  4734   /** SELECT pk fld from INTO RPAD_FLWN_FL_SPNS by many    **/
#define SERVICE_ID_04735  4735   /** UPDATE RPAD_FLWN_FL_SPNS set LstUpdtId by spns_sq_nb **/
#define SERVICE_ID_04736  4736   /** SELECT records from NRAP_FLWN_FL by PPR / Award      **/
#define SERVICE_ID_04737  4737   /** SELECT record from NRAP_FLWN_FL (by PK)              **/
#define SERVICE_ID_04738  4738   /** SELECT record from NRAP_FLWN_FL (by Tkt Info)        **/
#define SERVICE_ID_04740  4740   /** INSERT record into NRAP_FLWN_FL                      **/
#define SERVICE_ID_04741  4741   /** SELECT NRAP_CRTF where cur_tkt = certificate         **/
#define SERVICE_ID_04742  4742   /** SELECT NRAP_CRTF WHERE init_tkt = certificate        **/
#define SERVICE_ID_04743  4743   /** UPDATE NRAP_CRTF;  Set nrap_crtf_stt_cd              **/
#define SERVICE_ID_04744  4744   /** SELECT NRAP by TKT_DSGTR_TXT                         **/
#define SERVICE_ID_04746  4746   /** SELECT Records from NRAP_FLWN_FL by PrmyTktNbr       **/
#define SERVICE_ID_04748  4748   /** SELECT NRAP_BKG by specific TRIP INFO                **/
#define SERVICE_ID_04755  4755   /** SELECT NRAP_BKG by PPR, NRAP_CD, FLT_DPRT_DT         **/


#define MODULE_NAME                  "epb40000"
#define DELETE_UPDT_ID               "epb40000-IT"
#define PASS2000_MODULE              "PASS2000"
#define RECOGNITION_AWARD_DOMESTIC   "FR009"
#define RECOGNITION_AWARD_ASIA       "FR109"

#define SPNS_TXT_FILTER_ENABLED      "Recognition Award Filter Enabled"
#define SPNS_TXT_UNKNOWN_DESIGNATOR  "Invalid or Unknown Tkt Designator"
#define SPNS_TXT_NEED_PPR_NBR        "Invalid PPR or PPR not on File"
#define SPNS_TXT_NEED_NREV_NBR       "Invalid NRev Number or not on File"
#define SPNS_TXT_MISSING_CERTIFICATE "Missing Certificate for ENCI Award"
#define SPNS_TXT_NO_CROSS_REFERENCE  "No Cross-Reference for ENCI Award"
#define SPNS_TXT_MISSING_TKT_DATA    "Required Ticket Data Missing"
#define SPNS_TXT_MISSING_FLT_DATA    "Required Flight Data Missing"
#define SPNS_TXT_MISSING_AWARD_DATA  "Required Award Data Missing"
#define SPNS_TXT_INVALID_TKT_DATA    "Invalid Ticket Data"
#define SPNS_TXT_DUPLICATE_LEG       "Multiple Tkts/Cpns for Psgr on Same Flt"


/* #defines and global variables */
#define RPAD_MODE         1
#define REPROCESS_MODE    2

#define NUMBER_OF_THREADS 3
#define EPBUPD0 0
#define EPBINQ0 1
#define EPBINQ1 2

short   nSvcRtnCd;
int     retval;

#ifndef true
#define true   1
#define false  0
#endif

#define NULL_CHAR   '\0'

/* This is the structure for the detail record layout */

struct _RPAD_REC
{
   char PRI_TKT_DOC_NB[15];
   char TKT_DOC_NB[15];
   char TKT_DOC_ISS_LDT[10];   // Format YYYY-MM-DD
   char TKT_DOC_SQ_NB[3];
   char ORGL_TKT_NBR_TXT[15];
   char FILLER[3];             // Extraneous digits in field OpAsFltNbr
   char OPAS_FLT_NB[5];
   char CPN_NB[3];
   char PAX_FRST_NM[50];
   char PAX_LST_NM[50];
   char PAX_INFO_TXT[49];
   char SCHD_DPRT_LDT[10];     // Format YYYY-MM-DD
   char CPN_ORIG_TRSTN_CD[5];
   char CPN_DEST_TRSTN_CD[5];
   char FARE_BAS_TXT[8];
   char TKT_DSGTR_TXT[15];
   char GREAT_CRCL_MI[8];
   char RND_TRP_IND;
   char TKT_DOC_EXCG_IND;
   char PPR_NBR[9];
   char PPR_NB_EXT[2];
   char TOUR_CODE_TXT[20];
   char END_OF_REC;
} * RPAD_REC;



/* Function definitions */

void  TPM_1000_Initialize(int mode);
void  TPM_2000_Mainline(int mode);
void  TPM_3000_ProcessFileEPBF010();
void  TPM_4000_ProcessFlownLeg();
void  TPM_5000_InsertFlownFLeg();
void  TPM_6000_SuspendRecord(char *reason);

void  TPM_8001_GetPPRfromPaxInfo();
void  TPM_8002_GetPPRfromTourCode();
void  TPM_8003_GetPPRandNRevNbr(char *pstr);
int   TPM_8004_ValidatePPR();
int   TPM_8005_ValidateNRevNbr();
int   TPM_8006_GetPPRusingNWEmplNb();
int   TPM_8007_GetAwardInfoFromNRAP_CRTF();
int   TPM_8008_GetAwardInfoUsingTktDsgtr();
int   TPM_8009_FindBooking();
int   TPM_8010_AssignNRevNbr();
int   TPM_8011_FindDuplicateFlownFLeg();
int   TPM_8012_FindRelatedTkt();

long  TPM_8100_GetSuspenseRecToReprocess();
void  TPM_8200_DeleteSpnsRecord(long lSpnsSqNb);
int   TPM_8300_UpdateBooking();

void  TPM_9000_ProcessEndOfProgram(int mode);

static void write_to_log(char a[],char b[],char c[]);
static int EnvValueToBOOL(const char *value);
static int isAllNumeric(char *str, int len);


static struct
{
   char    start_of_save;

   // File handle and input buffer for RPAD file
   int   EPBF010;              // Input RPAD file from EDW
   char  EPBF010_buffer[500];  // Should be ample Buffer!
   int   reclen;               // Record Length


   //---- RPAD_FLWN_FL_SPNS fields ------
   char  sPprNbr[9+1];
   char  sNrevNbr[2+1];

   char  sPriTktDocNb[15+1];
   char  sTktDocNbr[15+1];
   char  sTktDocIssDt[27];    // DB Format: YYYY-MM-DD-HH24:MI:SS
   char  sTktDocSqNb[3+1];
   short nTktDocSqNb;
   char  sOrglTktNbr[15+1];
   char  sTktCpnNb[3+1];
   short nTktCpnNb;

   char  sPaxFirstName[50+1];
   char  sPaxLastName[50+1];

   char  sFltNbr[5+1];
   char  sFltDprtDt[27];       // DB Format: YYYY-MM-DD-HH24:MI:SS
   char  sFltOrigCtyId[5+1];
   char  sFltDestCtyId[5+1];
   char  sLegMileage[8+1];
   long  lLegMileage;

   char  sPsgrInfo[49+1];
   char  sTourCode[20+1];
   char  sFareBasis[8+1];
   char  sTktDesignator[15+1];
   char  cRoundTripInd;
   char  cTktExchdInd;
   char  sErrRsnTxt[40+1];


   // NRAP_FLWN_FL fields (those exclusive of RPAD_FLWN_FL_SPNS fields)
   char  sNrapCd[8+1];
   short nNrapSpgmNb;
   char  sNrapFrstBkgLdt[27];
   short nNrapTrpSqNb;
   char  sProcdForImptnDt[27];

   //----

   int   fIgnoreRecognitionAwardPgm;        // Flag to ignore FR009 and FR109 ENCI awards

   long  RPAD_Rec_Cnt;    // Number of RPAD records processed
   long  SPNS_Rec_Cnt;    // Number of Suspense items reprocessed
   long  SPNS_Delete_Cnt; // Number of Suspense items deleted
   long  Flown_FL_Cnt;    // Number of records written to NRAP_FLWN_FL table
   long  Suspense_Cnt;    // Number of records written to RPAD_FLWN_FL SPNS table
   long  DupSuspense_Cnt; // Number of matching Suspense records (therefore not written again to suspense)
   long  DupFlownFL_Cnt;  // Number of matching records in Flown_FL (therefore ignored)
   long  Ignore_Cnt;      // Number of records simply ignored due to various rules
   long  Error_Cnt;       // Number of Runtime Errors encountered

   char  end_of_save;

} RS;














