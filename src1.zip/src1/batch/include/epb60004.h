/****************************************************************************
**                                                                         **
** File Name :      EPB60004.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  C.Eachus                                               **
**                                                                         **
** Date Created:    5/2/95                                                 **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 8/15/96    G. Melton                   Added sTodayDt and               **
**                                        rows_archived_cntr to RS struct. **
**                                        Also added new service (4118),   **
**                                        used to calculate the date a     **
**                                        year ago today.                  **
**                                                                         **
**                                                                         **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"

#include "frapecep.h"
/*
 * You should include any subsytem header files here. For example:
 * #include "subsystem_db_io/current_date.h"
 *
 */


/*
 * Service request and answer blocks
 */

#include "fyr02874.h"      /** service request layout fyr02874 **/
#include "fya02874.h"      /** service answer layout fya02874 **/
#include "fyr04118.h"      /** service request layout fya02816 **/
#include "fya04118.h"      /** service answer layout fya02816 **/
 
_R02874 R02874;        /** Service Request Layout **/
_A02874 A02874;        /** Service Answer Layout **/
_R04118 R04118;        /** Service Request Layout **/
_A04118 A04118;        /** Service Answer Layout **/

#define SERVICE_ID_02874  2874
#define SERVICE_ID_04118  4118

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
int     DPM_2100_ConvertDate();
void    DPM_2500_ProcessRows();
void    DPM_4920_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS 2        /** enter number of threads needed **/
#define EPBUPD0 0                   /** enter the associated thread number **/
#define EPBINQ0 1                   /** enter the associated thread number **/

static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/



   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   char         sPprNbr[10];
   char         sNrevNbr[3];
   char         sPassDtTmTs[27];   
   char         sFltDprtDt[27];  
   char         sTodayDt[27];

   /*** Flags and counters ***/
   short        nProcessedAllRows;
   long         rows_archived_cntr;

   char    end_of_save;

}  RS;
