/****************************************************************************
**                                                                         **
** File Name :      EPB90005.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB90001 module.                                   **
**                                                                         **
** Author :         TransQuest                                             **
**                  kenneth hancock                                        **
**                                                                         **
** Date Created:    Oct 14, 1995                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/*
 * Report sort and data layouts
 */

#include "feps9005.h"      /** report sort layout (name of copybook) **/
#include "fepf9005.h"      /** report data layout (name of copybook) **/

_EPRF9005 EPRF9005;        /** Report1 Data Layout **/
_EPRS9005 EPRS9005;        /** Report1 Sort Layout **/

/*
 * Service request and answer blocks
 */

#include "fyr02747.h"      /** service request layout (name of copybook) **/
#include "fya02747.h"      /** service answer layout (name of copybook) **/
#include "fyr02767.h"      /** service request layout (name of copybook) **/
#include "fya02767.h"      /** service answer layout (name of copybook) **/
#include "fyr03845.h"      /** service request layout (name of copybook) **/
#include "fya03845.h"      /** service answer layout (name of copybook) **/
#include "fyr03917.h"      /** service request layout (name of copybook) **/
#include "fya03917.h"      /** service answer layout (name of copybook) **/
 
_R02747 R02747;        /** Service Request Layout **/
_A02747 A02747;        /** Service Answer Layout **/
_R02767 R02767;        /** Service Request Layout **/
_A02767 A02767;        /** Service Answer Layout **/
_R03845 R03845;        /** Service Request Layout **/
_A03845 A03845;        /** Service Answer Layout **/
_R03917 R03917;        /** Service Request Layout **/
_A03917 A03917;        /** Service Answer Layout **/


#define SERVICE_ID_02747  2747
#define SERVICE_ID_02767  2767
#define SERVICE_ID_03845  3845
#define SERVICE_ID_03917  3917

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_5010_Generate();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS     2         /** enter number of threads needed **/
#define EPBINQ0               0         /** enter the associated thread number **/
#define EPBINQ1               1         /** enter the associated thread number **/

char GOOD;

static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/

   int PRAF010;        /** Report output file **/


   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   char    sPprNbr[10];
   char    sNrevNbr[3];
   char    sSvcChrgCd[3];
   char    sFltDprtDt[27];
   char    sPassDtTmTs[27];
   char    sFltFeeBegDt[27];
   char    sFltFeeEndDt[27];
  /***** For checking for 3845   ***/
   char    sFltOrigCtyId[6];
   char    sFltDestCtyId[6];
   long    lFltChrgRfrnDt;

   /**** Flag for all rows processed ****/
   short        nProcessedAllRows;

   /** Part of Report request table saved to "re_sync" report requests at restart **/


   /* The following accumulators are not used in this module. */

   short   accumulator_field1;
   double  accumulator_field2;

   char    end_of_save;

}  RS;
