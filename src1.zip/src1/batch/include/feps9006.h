/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS9006                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/11/95                                                */
/*              Time: 13:34:01                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS9006                           */
/******************************************************************************/
                                                                                
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef _S9006_RPTDATASTRUCT_z                                                  
#define _S9006_RPTDATASTRUCT_z                                                  
typedef struct __S9006_RptDataStruct                                            
{                                                                               
   char                sFltNbr[FY002553_LEN];                                   
}  _S9006_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS9006_z                                                             
#define _EPRS9006_z                                                             
                                                                                
   typedef struct __EPRS9006                                                    
   {                                                                            
      _S9006_RPTDATASTRUCT S9006_RptDataStruct;                                 
   }  _EPRS9006;                                                                
#endif                                                                          
                                                                                
