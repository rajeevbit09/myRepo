/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS7142                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 03/07/96                                                */
/*              Time: 11:20:18                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS7142                           */
/******************************************************************************/
                                                                                
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef _S7142_RPTDATASTRUCT_z                                                  
#define _S7142_RPTDATASTRUCT_z                                                  
typedef struct __S7142_RptDataStruct                                            
{                                                                               
   char                sPassGrpCd[FY002488_LEN];                                
   char                sPprNm[FY002480_LEN];                                   
}  _S7142_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS7142_z                                                             
#define _EPRS7142_z                                                             
                                                                                
   typedef struct __EPRS7142                                                    
   {                                                                            
      _S7142_RPTDATASTRUCT S7142_RptDataStruct;                                 
   }  _EPRS7142;                                                                
#endif                                                                          
                                                                                
