/****************************************************************************
**                                                                         **
** File Name :      EPB53003.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author :         Delta                                                  **
**                  L. Scott                                               **
**                                                                         **
** Date Created:    3/31/09                                                **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/* Service request and answer blocks */

#include "fyr02496.h"
#include "fya02496.h"     
#include "fyr02511.h"    
#include "fya02511.h"   
#include "fyr02792.h" 
#include "fya02792.h"
#include "fyr02797.h"  
#include "fya02797.h" 
#include "fyr03952.h"   
#include "fya03952.h"  
#include "fyr03962.h"     
#include "fya03962.h"    
#include "fyr04395.h"     
#include "fya04395.h"    
#include "fyr04400.h"     
#include "fya04400.h"    
#include "fyr04714.h"    
#include "fya04714.h"   
#include "fyr04724.h"    
#include "fya04724.h"   
 
_R02496 R02496; 
_A02496 A02496;       
_R02511 R02511;      
_A02511 A02511;     
_R02792 R02792;   
_A02792 A02792;  
_R02797 R02797;    
_A02797 A02797;   
_R03952 R03952;     
_A03952 A03952;    
_R03962 R03962;       
_A03962 A03962;      
_R04395 R04395;       
_A04395 A04395;      
_R04400 R04400;       
_A04400 A04400;      
_R04714 R04714;      
_A04714 A04714;     
_R04724 R04724;      
_A04724 A04724;     

#define SERVICE_ID_02496  2496   /** insert t_imput_flt_leg **/ 
#define SERVICE_ID_02511  2511   /** insert t_flt_leg **/ 
#define SERVICE_ID_02792  2792   /** select t_arpt_pr_mi **/ 
#define SERVICE_ID_02797  2797   /** select t_arpt_pr_typ **/ 
#define SERVICE_ID_03952  3952   /** select t_brd_priority **/ 
#define SERVICE_ID_03962  3962   /** select t_ppr, t_nrev_psgr **/
#define SERVICE_ID_04395  4395   /** Insert t_suspense **/
#define SERVICE_ID_04400  4400   /** select max t_brd_priority **/
#define SERVICE_ID_04714  4714   /** insert bdy_nrev_pax_fl **/ 
#define SERVICE_ID_04724  4724   /** select t_ppr, t_nrev_psgr, bdy_nrev_pax **/ 

/* Function definitions */

void    TPM_1000_Initialize();
void    TPM_2000_Mainline();
void    TPM_3000_ProcessFileEPBF010();
void    Write_to_log(char arg[]);
void    TPM_3100_Insert_Suspense();
void    TPM_4000_Get_ArptPrTyp();
void    TPM_4025_Get_BrdPriority();
void    TPM_4050_Get_PassTypCd();
void    TPM_4075_Get_Lowest_Priority();
int     TPM_8000_ProcessLUW();
void    TPM_9500_ProcessEndOfProgram();

/* #defines and global variables */

#define NUMBER_OF_THREADS 3        
#define EPBUPD0 0                 
#define EPBUPD1 1                 
#define EPBINQ0 2                

char    isodt[8+1];
char    sErrMsg[26];
char    servid;
char sCertftIssDt[27];
char    cBrdPriFound;
char    cLowestPriFound;
char    sPassTypCd[3];
char    sMaxPassTypCd[3];
char    sMinPassTypCd[3];
short   nTm;
short   nSvcRtnCd;
short   nSvcRtnCd1;
short   nSvcRtnCd2;
short   nSvcRtnCd3;
short   nSvcRtnCd4;
short   nSvcRtnCd5;
short   nSvcRtnCd6;
short   nSvcRtnCd7;
short   nSvcRtnCd8;
short   nSvcRtnCd9;


static struct
{
   char    start_of_save;

   int EPBF010;        /** Input PARS file **/


   char    EPBF010_buffer[226];

   char sEtId[3];
   char sTranDt[11];
   char sArLnTktId[4];
   char sTktSrlNum3[4];
   char sTktSrlNum7[8];
   char sTktCpnNum[3];
   char sPsgrTyp[4];
   char sSgmtTvlCd[3];
   char sPsgrLstNm[16];
   char sPsgrFrstNm[11];
   char sTripOrig[6];
   char sTripDest[6];
   char sSegOrig[6];
   char sSegDest[6];
   char sSegFltNum[5];
   char sSegCls[3];
   char sEmpNum[7];
   char sFiller1[5];
   char sSegFltDtYr[5];
   char cSegFltDtDsh1;
   char sSegFltDtMo[3];
   char cSegFltDtDsh2;
   char sSegFltDtDy[3];
   char sSegArlnCd[4];
   char cSegArcftType;
   char sFmPyCd[3];
   char sFmPyCcCd[3];
   char sFmPymnt[20];
   char sAgncyNum[8];
   char sAgncyNm[16];
   char sEmpCpCd[4];
   char sPnrNum[7];
   char sTktDsg[6];
   char sTktTag[6];
   char sConjTktNum[22];
   char cTrpTyp;
   char cTrpRtg;
   char sOneWy[3];
   char sTurnArnd[4];
   char cTurnArnd4;
   char sCrjInd[4];
   char sTktIssDt[11];
   char sTktSegMlg[5];
   char sFiller2[8];

   char sPprNbr[9+1];
   char sNrevNbr[2+1];
   char sFltNbr[5+1];
   char sFltOrigCtyId[5+1];
   char sFltDestCtyId[5+1];
   char sDprtDt[27];
   char sArrDt[27];
   char sClsSvc[3];
   char sBrdPri[5];
   char sATm[5];
   char sDTm[5];
   char sFltYr[5];
   char sFltYrMo[7];
   char sFltYrMoDy[9];
   short   Read;
   short   Error;
   short   Dropped;
   short   Fltleg;
   short   BuddyFltleg;
   short   Imptfltleg;
   char    end_of_save;
}  RS;
