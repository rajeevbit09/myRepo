/****************************************************************************
**                                                                         **
** File Name :      EPB71402.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB71402 module.                                   **
**                                                                         **
** Author :         Lorenzo Scott                                          **
**                                                                         **
** Date Created:    May  8, 1998                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/*
 * Report sort and data layouts
 */

#include "fepf7143.h"      /** report data layout **/
#include "feps7143.h"      /** report sort layout **/

_EPRF7143 EPRF7143;        /** Report2 Data Layout **/
_EPRS7143 EPRS7143;        /** Report2 Sort Layout **/

/*
 * Service request and answer blocks
 */

#include "fyr04589.h"      /** service request layout **/
#include "fya04589.h"      /** service answer layout **/
#include "fyr04590.h"      /** service request layout **/
#include "fya04590.h"      /** service answer layout **/
#include "fyr04591.h"      /** service request layout **/
#include "fya04591.h"      /** service answer layout **/
#include "fyr04592.h"      /** service request layout **/
#include "fya04592.h"      /** service answer layout **/
 
_R04589 R04589;        /** Service Request Layout **/
_A04589 A04589;        /** Service Answer Layout **/
_R04590 R04590;        /** Service Request Layout **/
_A04590 A04590;        /** Service Answer Layout **/
_R04591 R04591;        /** Service Request Layout **/
_A04591 A04591;        /** Service Answer Layout **/
_R04592 R04592;        /** Service Request Layout **/
_A04592 A04592;        /** Service Answer Layout **/

#define SERVICE_ID_04589  4589
#define SERVICE_ID_04590  4590
#define SERVICE_ID_04591  4591
#define SERVICE_ID_04592  4592

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_2600_UpdateMatchInd();
void    DPM_5010_GenerateEPB71413();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS     3         /** Number of threads needed **/
#define EPBINQ0               0         /** First inquiry thread number **/
#define EPBINQ1               1         /** Second inquiry thread number **/
#define EPBUPD0               2         /** First update thread number **/

#define ACTIVE                "AC"
#define NON_ACTIVE            "NA"

short   nSvcRtnCd;                      /** Service return code **/


float   fDemFareAmt,                    /** Fare amount **/
        fDemNrevPmtAmt;                 /** Non-revenue passenger payment **/


static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/

   int PRAF010;        /** Report output file **/


   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   short   EPB71413_record_cntr;
 
   char    sPprNbr[10],
           sNrevNbr[3],
           sEffDt[27];
  /*       sFltNbr[6],
           sFltDprtDt[27],
           sTktNbr[11],
           sFltOrigCtyId[6]; */

   /**** Flag for all rows processed ****/
   short        nProcessedAllRows;

   /** Part of Report request table saved to "re_sync" report requests at restart **/


   char    end_of_save;

}  RS;
