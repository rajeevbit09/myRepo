/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5018                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/08/2003                                              */
/*              Time: 10:00:00                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5018                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5018_RPTDATASTRUCT_z                                                  
#define _S5018_RPTDATASTRUCT_z                                                  
typedef struct __S5018_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5018_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5018_z                                                             
#define _EPRS5018_z                                                             
                                                                                
   typedef struct __EPRS5018                                                    
   {                                                                            
      _S5018_RPTDATASTRUCT S5018_RptDataStruct;                                 
   }  _EPRS5018;                                                                
#endif                                                                          
                                                                                
