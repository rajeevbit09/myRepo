/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5013                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/01/96                                                */
/*              Time: 13:44:25                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5013                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5013_RPTDATASTRUCT_z                                                  
#define _S5013_RPTDATASTRUCT_z                                                  
typedef struct __S5013_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5013_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5013_z                                                             
#define _EPRS5013_z                                                             
                                                                                
   typedef struct __EPRS5013                                                    
   {                                                                            
      _S5013_RPTDATASTRUCT S5013_RptDataStruct;                                 
   }  _EPRS5013;                                                                
#endif                                                                          
                                                                                
