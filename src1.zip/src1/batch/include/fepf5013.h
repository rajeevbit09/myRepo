/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF5013                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 06/11/96                                                */
/*              Time: 13:47:23                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF5013                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002831_LEN                                                          
#define   FY002831_LEN                         3                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002495_LEN                                                          
#define   FY002495_LEN                         3                                
#endif                                                                          
#ifndef   FY002482_LEN                                                          
#define   FY002482_LEN                         3                                
#endif                                                                          
#ifndef   FY003335_LEN                                                          
#define   FY003335_LEN                         1                                
#endif                                                                          
#ifndef   FY003336_LEN                                                          
#define   FY003336_LEN                         3                                
#endif                                                                          
#ifndef   FY002703_LEN                                                          
#define   FY002703_LEN                         3                                
#endif                                                                          
#ifndef   FY003592_LEN                                                          
#define   FY003592_LEN                         27                               
#endif                                                                          
#ifndef   FY003582_LEN                                                          
#define   FY003582_LEN                         27                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F5013_RPTDATASTRUCT_z                                                  
#define _F5013_RPTDATASTRUCT_z                                                  
typedef struct __F5013_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sNrevSrcCd[FY002831_LEN];                                
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevNm[FY002531_LEN];                                   
   char                sPassGrpCd[FY002488_LEN];                                
   char                sNrevTypCd[FY002495_LEN];                                
   char                sPprStCd[FY002482_LEN];                                  
   char                cEmplArStsInd;                                           
   char                sEmplArActnCd[FY003336_LEN];                             
   char                sFltClsSvcId[FY002703_LEN];                              
   char                sPprStrtDt[FY003592_LEN];                                
   char                sNrevBdayDt[FY003582_LEN];                               
   char                cRecEndLineTxt;                                          
}  _F5013_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF5013_z                                                             
#define _EPRF5013_z                                                             
                                                                                
   typedef struct __EPRF5013                                                    
   {                                                                            
      _F5013_RPTDATASTRUCT F5013_RptDataStruct;                                 
   }  _EPRF5013;                                                                
#endif                                                                          
                                                                                
