/****************************************************************************
**                                                                         **
** File Name :      EPB56001.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author :         Delta Technology                                       **
**                  Lorenzo Scott                                          **
**                                                                         **
** Date Created:    09/02/98                                               **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"


/* Service request and answer blocks */

#include "fyr04629.h"
#include "fya04629.h"     
#include "fyr04630.h"    
#include "fya04630.h"   
 
_R04629 R04629; 
_A04629 A04629;       
_R04630 R04630;      
_A04630 A04630;     

#define SERVICE_ID_04629  4629   /** select t_fltcertft **/ 
#define SERVICE_ID_04630  4630   /** update t_fltcertft **/ 

/* Function definitions */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_3000_ProcessFileEPBF010();
int     DPM_8000_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();

/* #defines and global variables */

#define NUMBER_OF_THREADS 2        
#define EPBUPD0 0                 
#define EPBINQ0 1                

char    sErrMsg[26];
short   nSvcRtnCd;
short   nSvcRtnCd1;

static struct
{
   char    start_of_save;

   int EPBF010;        /** Input Deltamatic file **/


   char    EPBF010_buffer[45];


   char sPprNbr[9+1];
   char sCertftExtnNbr[2+1];
   char sFltCertftNbr[10+1];
   char sCertftIssDt[8+1];
   char sCertftExpDt[8+1];
   char sProcDt[8+1];
   short   Read;

   char    end_of_save;

}  RS;
