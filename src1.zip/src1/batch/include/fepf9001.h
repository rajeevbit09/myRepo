/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF9001                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 12/07/95                                                */
/*              Time: 20:30:40                                                */
/*                                                                            */
/* Date    Revised By       Description                                       */
/* ----    ----------       -----------                                       */
/* 09/04/96  FFA            Revised fields                                    */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF9001                           */
/******************************************************************************/
                                                                                
#ifndef   FY002489_LEN                                                          
#define   FY002489_LEN                         26                               
#endif                                                                          
#ifndef   FY002497_LEN                                                          
#define   FY002497_LEN                         26                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F9001_RPTDATASTRUCT_z                                                  
#define _F9001_RPTDATASTRUCT_z                                                  
typedef struct __F9001_RptDataStruct                                            
{                                                                               
   char                sPassGrpDs[FY002489_LEN];                                
   char                sPassTypDs[FY002497_LEN];                                
   //long                lFltDyCnt;                                               
   char                sFltDyCnt[20];
   //long                lFltLegCnt;
   char                sFltLegCnt[20];                                              
   //long                lSvcChgCnt;  
   char                sSvcChgCnt[20];                                            
   // double              dTotSvcChgAmt;
   char                sTotSvcChgAmt[20]; 
   // double              dTotPenaltyAmt;
   char                sTotPenaltyAmt[20];                                          
   // double              dTotIntlFeeAmt; 
   char                sTotIntlFeeAmt[20];                                         
   // double              dTotChgAmt;     
   char                sTotChgAmt[20];                                     
   char                cRecEndLineTxt;                                          
}  _F9001_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF9001_z                                                             
#define _EPRF9001_z                                                             
                                                                                
   typedef struct __EPRF9001                                                    
   {                                                                            
      _F9001_RPTDATASTRUCT F9001_RptDataStruct;                                 
   }  _EPRF9001;                                                                
#endif                                                                          
                                                                                
