/****************************************************************************
**                                                                         **
** File Name :      EPB40001.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author:          Duane Ellis                                            **
**                                                                         **
** Date Created:    3/2010                                                 **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by      Description                                  **
** ----       ----------      --------------------                         **
** 03/04/2010 DHE             Inital Program Creation                      **
** 10/19/2010 D Ellis         Added nrap_trp_impd_val.Trp_Dprt_Dt Column   **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/* Service request and answer blocks */

#include "fyr02792.h"
#include "fya02792.h"
#include "fyr04739.h"
#include "fya04739.h"
#include "fyr04745.h"
#include "fya04745.h"
#include "fyr04746.h"
#include "fya04746.h"
#include "fyr04749.h"
#include "fya04749.h"
#include "fyr04750.h"
#include "fya04750.h"
#include "fyr04751.h"
#include "fya04751.h"
#include "fyr04752.h"
#include "fya04752.h"


_R02792 R02792;
_A02792 A02792;
_R04739 R04739;
_A04739 A04739;
_R04745 R04745;
_A04745 A04745;
_R04746 R04746;
_A04746 A04746;
_R04749 R04749;
_A04749 A04749;
_R04750 R04750;
_A04750 A04750;
_R04751 R04751;
_A04751 A04751;
_R04752 R04752;
_A04752 A04752;

#define SERVICE_ID_02792  2792   /** SELECT FROM T_ARPT_PR_MI table by city pair          **/
#define SERVICE_ID_04739  4739   /** UPDATE NRAP_FLWN_FL SET PROCD_FOR_IMPTN_DT           **/
#define SERVICE_ID_04745  4745   /** SELECT DISTINCT PRMY_TKT_DOC_NBR FROM NRAP_FLWN_FL   **/
#define SERVICE_ID_04746  4746   /** SELECT Records from NRAP_FLWN_FL by PrmyTktNbr       **/
#define SERVICE_ID_04749  4749   /** UPATE  NRAP_TRP_IMPD_VAL record with values          **/
#define SERVICE_ID_04750  4750   /** INSERT Record into NRAP_TRP_IMPD_VAL table           **/
#define SERVICE_ID_04751  4751   /** SELECT from IMPD_TRVL_BAND by date & mileage         **/
#define SERVICE_ID_04752  4752   /** SELECT from NRAP_TRP_IMPD_VAL by PK fields           **/


#define MODULE_NAME                  "epb40001"

/* #defines and global variables */
#define NUMBER_OF_THREADS 4
#define EPBUPD0 0
#define EPBINQ0 1
#define EPBINQ1 2
#define EPBINQ2 3

short   nSvcRtnCd;
int     retval;

#ifndef true
#define true   1
#define false  0
#endif


/* Function definitions */

void  TPM_1000_Initialize();
void  TPM_2000_Mainline();
void  TPM_3000_ProcessTrip(char *);
void  TPM_5000_InsertTrpImpdVal(short,float);

short TPM_8001_GetDistinctTrip(char, char *);
void  TPM_8002_LoadTripCoupons(char *sPrmyTktDocNb);
int   TPM_8003_DetermineOrigDest();
int   TPM_8004_ApplyTravelBand();
void  TPM_8005_LoadTripImpdValRecords();
void  TPM_8006_UpdateImpdValRecord(short,char,long,char*,char*,char*,float);
void  TPM_8009_UpdateFlwnFlegAsProcessed();


void  TPM_9000_ProcessEndOfProgram();


typedef struct _COUPONS
{
   char  sPprNbr[9+1];
   char  sNrevNbr[2+1];
   char  sFltOrigCtyId[5+1];
   char  sFltDestCtyId[5+1];
   char  sFltDprtDt[27];       // DB Format: YYYY-MM-DD-HH:MM:SS
   char  sFltNbr[5+1];

   char  sNrapCd[8+1];
   short nNrapSpgmNb;
   char  sNrapFrstBkgLdt[27];
   short nNrapTrpSqNb;

   char  sPrmyTktDocNb[15+1];
   char  sTktDocNbr[15+1];
   char  sTktDocIssDt[27];    // DB Format: YYYY-MM-DD-HH:MM:SS
   short nTktDocSqNb;
   short nTktCpnNb;

   char  cRoundTripInd;
   long  lLegMileage;
   char  sProcdForImptnDt[27];

} COUPONS;


typedef struct _IMPDVALRECS
{
   char  sPprNbr[9+1];
   char  sNrevNbr[2+1];
   char  sNrapCd[8+1];
   short nNrapSpgmNb;
   char  sNrapFrstBkgLdt[27];
   short nNrapTrpSqNb;
   short nImpdValSqlNb;
   char  cImpdTrvlBandCd;
   long  lTotImpdMiCt;
   float fImpdNetAmt;
   char  sTrpOrigCtyId[5+1];
   char  sTrpDestCtyId[5+1];
   char  sTrpDprtDt[27];      // DB Format: YYYY-MM-DD-00:00:00
   char  sSentToPyrlDt[27];   // DB Format: YYYY-MM-DD-HH:MM:SS

} IMPDVALRECS;

//-------- Application Work Area --------------------------------------
static struct
{
   char    start_of_save;

   short   numDaysPastFltDepartDate;  // When to begin processing Flown Flight legs (e.g. 40)

   COUPONS TripCoupons[16];         // Set aside space for 4 Coupon books.  Surely that's enough!!!
   short TotalCoupons;

   IMPDVALRECS TripImpdValRecs[4];  // Set aside space for 4 Trip Impd Val Recs.  Surely that's enough!!!!
   short TotalTrpImpdValRecs;


   //---- NRAP_TRP_IMP_VAL fields for Current Record ------
   char  sPprNbr[9+1];
   char  sNrevNbr[2+1];
   char  sNrapCd[8+1];
   short nNrapSpgmNb;
   char  sNrapFrstBkgLdt[27]; // DB Format: YYYY-MM-DD-HH:MM:SS
   short nNrapTrpSqNb;
   short nImpdValSqlNb;
   //--
   char  cImpdTrvlBandCd;
   char  cOwrtCd;
   char  cTrp1099Ind;
   long  lTotalImpdMiCt;      // Round Trip Mileage
   float fImpdNetAmt;
   char  sSentToPyrlDt[27];   // DB Format: YYYY-MM-DD-HH:MM:SS

   char  sTrpOrigCtyId[5+1];
   char  sTrpDestCtyId[5+1];
   char  sTrpDprtDt[27];      // DB Format: YYYY-MM-DD-00:00:00

   //-----------------------------------

   long  lTripOWMileage;      // Trip One Way Mileage
   char  sFltDprtDt[27];      // Flight Departure date of first leg (used to determine Travel Band)

   long  Tot_Trip_Cnt;        // Number of Trips successfully imputed
   long  New_Trip_Cnt;        // Number of records written to NRAP_TRP_IMPD_VAL table
   long  Upd_Trip_Cnt;        // Number of records updated in NRAP_TRP_IMPD_VAL table
   long  Match_Trip_Cnt;      // Number of Trips matched in NRAP_TRP_IMPD_VAL table and not updated.
   long  Ignore_Cnt;          // Number of Trips ignored
   long  Error_Cnt;           // Number of Runtime Errors encountered

   char  end_of_save;

} RS;















