/****************************************************************************
**                                                                         **
** File Name :      EPB51002.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB51002.c module.                                 **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Created:    September 19, 1995                                     **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 03/25/96   J. Bowser                   Revised to accomodate changes    **
**                                        to source code.                  **
**                                                                         **
** 04/02/96   J. Bowser                   Revised to accomodate changes    **
**                                        to source code.                  **
**                                                                         **
** 07/26/96   FFA                         added counts                     **
**                                                                         **
** 07/29/96   FFA                         added new service to write to    **
**                                        audit trail table.               **
**                                                                         **
** 03/01/01   L.Scott                     added nReward ind and save ppr   **
**                                        and nrev fields.                 **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/** Service request and answer blocks */

#include "fyr02388.h"      
#include "fya02388.h"     
#include "fyr02441.h"    
#include "fya02441.h"   
#include "fyr02483.h"      
#include "fya02483.h"     
#include "fyr02561.h"    
#include "fya02561.h"   
#include "fyr02567.h"    
#include "fya02567.h"   
#include "fyr02596.h"      
#include "fya02596.h"     
#include "fyr02748.h"    
#include "fya02748.h"   
#include "fya03270.h"      
#include "fyr03270.h"     
#include "fya03716.h"    
#include "fyr03716.h"   
#include "fya04003.h"      
#include "fyr04003.h"     
#include "fya04323.h"    
#include "fyr04323.h"   
#include "fya04325.h"      
#include "fyr04325.h"     
#include "fya04326.h"    
#include "fyr04326.h"   
 
_R02388 R02388;        
_A02388 A02388;       
_R02441 R02441;      
_A02441 A02441;     
_R02483 R02483;        
_A02483 A02483;       
_R02561 R02561;      
_A02561 A02561;     
_R02567 R02567;      
_A02567 A02567;     
_R02596 R02596;        
_A02596 A02596;       
_R02748 R02748;      
_A02748 A02748;     
_R03270 R03270;    
_A03270 A03270;       
_R03716 R03716;      
_A03716 A03716;     
_R04003 R04003;    
_A04003 A04003;   
_R04323 R04323;        
_A04323 A04323;       
_R04325 R04325;      
_A04325 A04325;     
_R04326 R04326;    
_A04326 A04326;   

#define SERVICE_ID_02388  2388
#define SERVICE_ID_02441  2441
#define SERVICE_ID_02483  2483
#define SERVICE_ID_02561  2561
#define SERVICE_ID_02567  2567
#define SERVICE_ID_02596  2596
#define SERVICE_ID_02748  2748
#define SERVICE_ID_03270  3270
#define SERVICE_ID_03716  3716
#define SERVICE_ID_04003  4003
#define SERVICE_ID_04323  4323
#define SERVICE_ID_04325  4325
#define SERVICE_ID_04326  4326

/** Function definitions */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2100_PopulateLinkedList();
void    DPM_2200_ProcessPassTypes();
void    DPM_2500_ProcessRows();
void    DPM_2550_EvaluateGroupType();
void    DPM_2600_UpdateToActive();
void    DPM_2650_WriteNewPassCardRec();
void    DPM_2700_UpdateToRevoked();
void    DPM_2750_DeactivatePassCards();
void    DPM_2800_WriteComment();
void    DPM_3000_WriteDlmaticRecord(char cRecTyp);
void    DPM_3100_ReadDlmaticRecord();
void    DPM_2950_ReadRemnAllot();
void    DPM_4920_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();

/** #defines and global variables */

#define NUMBER_OF_THREADS     2     /** Number of threads needed **/
#define EPBINQ0               0     /** Inquiry thread     **/
#define EPBUPD0               1     /** Update thread      **/

#define ACTIVE_COMMENT        "EPB51002-Pass suspension period expired."
#define EXPIRED_COMMENT       "EPB51002-Revoked due to expired pass benefits."
#define INELIGIBLE_COMMENT    "EPB51002-Revoked due to invalid PassGp/PsgrType."
#define MAX_PASSTYPES         10    /** Maximum number of pass types **/
#define UNSUSPENDED_STAT      'U'
#define REVOKED_STAT          'R'
#define CHANGE_REC            'C'
#define DELETE_REC            'D'
#define ACTIVATED             'A'
#define DEACTIVATED           'D'
#define PROCESSED             'P'
#define NOT_PROCESSED         'N'
#define TRANSQUEST            "TQ"
#define WORLDSPAN             "WS"
#define NA_CHARGE             "NA"

short           nSvcRtnCd,          /** Service return code      **/
                nAllRowsProcessed,  /** Flag for cursor rows processed **/
                nActive,            /** Active pass status flag  **/
                nRevoked,           /** Revoked pass status flag (for invalid pass grp/psgr type) **/
                nReward15,          /** Pass type 15 flag  **/
                nPassTypCtr,        /** Pass type counter **/
                nOldAllotInd,       /** Flag for existence of allotments **/
                z;                  /** Pass type index **/

long            lJulEffDt,          /** Effective date in Julian **/
                lJulRvkDt;          /** PPR revoke date in Julian **/

char            sSavePprNbr[10];
char            sSaveNrevNbr[3];



typedef struct
{
char    sPassTypCd[3];
}passtype;

passtype   pass_type[MAX_PASSTYPES];


/**** Linked list for non-revenue passengers to be unsuspended and revoked ****/
struct nonrev_psgr
{
char    sPprNbr[10],
        sNrevNbr[3],
        sNrevNm[31],
        sPassGrpCd[3],
        sNrevTypCd[3],
        sPassStsCd[3],
        cStatInd;

struct  nonrev_psgr *pNext;    /** Pointer to next structure **/
};

/**** Head, previous, and current pointers for linked list ****/
struct  nonrev_psgr    *pHead,
                       *pPrev,
                       *pCurr;


static struct
{
   char     start_of_save;


   char    sEffDt[27];          /** Effective processing date **/

   short   nTotalCnt,
           nActiveCnt,
           nRvkCnt;

   char    end_of_save;

} RS;
