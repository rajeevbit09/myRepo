/****************************************************************************
**                                                                         **
** File Name :      EPB90001.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB90001 module.                                   **
**                                                                         **
** Author :         TransQuest Inc.                                        **
**                  Faith Ammons                                           **
**                                                                         **
** Date Created:    September 04, 1996                                     **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/
#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"

#include "feps9001.h" 
#include "fepf9001.h"

_EPRF9001 EPRF9001; 
_EPRS9001 EPRS9001;

/** Service request and answer blocks **/

#include "fyr04429.h"  
#include "fya04429.h" 
#include "fyr04430.h"  
#include "fya04430.h" 
#include "fyr04472.h"    
#include "fya04472.h"   
 
_R04429 R04429;    
_A04429 A04429;   
_R04430 R04430;    
_A04430 A04430;   
_R04472 R04472;      
_A04472 A04472;     

#define SERVICE_ID_04429  4429
#define SERVICE_ID_04430  4430
#define SERVICE_ID_04472  4472

/** Function definitions **/

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_2600_ProcessFltLegGrp();
void    DPM_2610_ProcessLegCharges();
void    DPM_2620_ProcessDayCharges();
void    DPM_4100_InitPassTypArray();
void    DPM_4200_GetPassGrpDs();
void    DPM_4300_AddToTotals();
void    DPM_5010_Generate();
void    DPM_9500_ProcessEndOfProgram();

/** #defines and global variables **/

#define NUMBER_OF_THREADS     3  
#define EPBINQ0               0 
#define EPBINQ1               1
#define EPBINQ2               2

char    sSavePassGrpDs[26],
        sSavePassGrpCd[3],
        sSavePprNbr[10],
        sSaveNrevNbr[3],
        sPassTyp[3],
        sDayPassTyp[3],
        cEndOfData;
short   nType,
        nFltLegCnt,
        nPassTypCnt,
        nPassGrpCnt;
long    lSaveRfrnDt;
double  dAmt;


typedef struct
{
   char    sPassTypCd[3],
           sPassTypDs[16];
   long    lFltDyCnt,
           lFltLegCnt,                
           lSvcChgCnt;       
   double  dTotSvcChgAmt,
           dTotPenaltyAmt,         
           dTotIntlFeeAmt;
}passtyp;            

passtyp pass_typ[10];

typedef struct
{
   char sPassGrpCd[3],
        sPassGrpDs[26];
}passgrp;

passgrp pass_grp[100];

typedef struct
{
   char   sPassTypCd[3],
          sFltDprtDt[27],
          sFltOrigCtyId[6],
          sFltDestCtyId[6];
}fltleg;

fltleg flt_leg[100];


static struct
{
   char    start_of_save;


   int PRAF010;        /** Report output file **/


   char    sPprNbr[10],             
           sPassGrpCd[3],             
           sBegDt[27],            
           sEndDt[27];         
        
   long    nLegCnt,           
           nChrgCnt;


   char    end_of_save;

}  RS;
