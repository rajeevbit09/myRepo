/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF9004                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/09/96                                                */
/*              Time: 14:12:19                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF9004                           */
/******************************************************************************/
                                                                                
#ifndef   FY003087_LEN                                                          
#define   FY003087_LEN                         9                                
#endif                                                                          
#ifndef   FY003585_LEN                                                          
#define   FY003585_LEN                         27                               
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY003080_LEN                                                          
#define   FY003080_LEN                         7                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY003084_LEN                                                          
#define   FY003084_LEN                         26                               
#endif                                                                          
#ifndef   FY003082_LEN                                                          
#define   FY003082_LEN                         31                               
#endif                                                                          
#ifndef   FY003083_LEN                                                          
#define   FY003083_LEN                         31                               
#endif                                                                          
#ifndef   FY002489_LEN                                                          
#define   FY002489_LEN                         26                               
#endif                                                                          
#ifndef   FY002497_LEN                                                          
#define   FY002497_LEN                         26                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F9004_RPTDATASTRUCT_z                                                  
#define _F9004_RPTDATASTRUCT_z                                                  
typedef struct __F9004_RptDataStruct                                            
{                                                                               
   char                sAcrlEffDt[FY003087_LEN];                                
   char                sFltFeeBegDt[FY003585_LEN];                              
   char                sFltFeeEndDt[FY003586_LEN];                              
   char                sAudtUserId[FY003080_LEN];                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPassGrpCd[FY002488_LEN];                                
   char                sPassTypCd[FY002496_LEN];                                
   char                sAudtChgTypNm[FY003084_LEN];                             
   char                sAudtChgFrNm[FY003082_LEN];                              
   char                sAudtChgToNm[FY003083_LEN];                              
   char                sPassGrpDs[FY002489_LEN];                                
   char                sPassTypDs[FY002497_LEN];                                
   char                cRecEndLineTxt;                                          
}  _F9004_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF9004_z                                                             
#define _EPRF9004_z                                                             
                                                                                
   typedef struct __EPRF9004                                                    
   {                                                                            
      _F9004_RPTDATASTRUCT F9004_RptDataStruct;                                 
   }  _EPRF9004;                                                                
#endif                                                                          
                                                                                
