/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS9901                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/12/98                                                */
/*              Time: 18:54:14                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS9901                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN
#define   FY002479_LEN                         10
#endif
#ifndef   FY002516_LEN
#define   FY002516_LEN                         3 
#endif
#ifndef   FY002868_LEN
#define   FY002868_LEN                         27
#endif
#ifndef _S9901_RPTDATASTRUCT_z                                                  
#define _S9901_RPTDATASTRUCT_z                                                  
typedef struct __S9901_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];
   char                sNrevNbr[FY002516_LEN];
   char                sPassDtTmTs[FY002868_LEN];
}  _S9901_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS9901_z                                                             
#define _EPRS9901_z                                                             
                                                                                
   typedef struct __EPRS9901                                                    
   {                                                                            
      _S9901_RPTDATASTRUCT S9901_RptDataStruct;                                 
   }  _EPRS9901;                                                                
#endif                                                                          
                                                                                
