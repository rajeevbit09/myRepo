/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS7141                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/23/95                                                */
/*              Time: 18:54:14                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS7141                           */
/******************************************************************************/
                                                                                
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                                
#endif                                                                          
#ifndef _S7141_RPTDATASTRUCT_z                                                  
#define _S7141_RPTDATASTRUCT_z                                                  
typedef struct __S7141_RptDataStruct                                            
{                                                                               
   char                sPprNm[FY002480_LEN];                                   
   char                sNrevNm[FY002531_LEN];                                  
   long                lPassTripNbr;                                            
}  _S7141_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS7141_z                                                             
#define _EPRS7141_z                                                             
                                                                                
   typedef struct __EPRS7141                                                    
   {                                                                            
      _S7141_RPTDATASTRUCT S7141_RptDataStruct;                                 
   }  _EPRS7141;                                                                
#endif                                                                          
                                                                                
