
/****************************************************************************
**                                                                         **
** File Name :      EPB90016.h                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.h>                                           **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB90016 module.                                   **
**                                                                         **
** Author :         TransQuest                                             **
**                  kenneth hancock                                        **
**                                                                         **
** Date Created:    Aug 11, 1995                                            **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

/***************************************************************************/
/*  FUNCTION PROTOTYPES                                                    */
/***************************************************************************/

void RFM_1000_InitializeFlds();
void RFM_3000_ProcessDetail();
void RFM_3100_ProcessReportRecord();
void RFM_4000_ProcessEndOfJob();
void RFM_5000_PageHeadings();


/**************************************************************************/
/*   CONSTANTS                                                            */
/**************************************************************************/
/* these constants should be customized for each particular format module */

#define LINES_PER_PAGE 41
#define PAGE_WIDTH 132
#define DETAIL_LINE 1
#define STD_RPT_TITLE "DELTA AIR LINES, INC."

/**************************************************************************/
/*   INPUT AREA                                                           */
/**************************************************************************/

/*
 * Report sort and data layouts
 */

#include "frapecep.h"
#include "feps9006.h"     /** report sort layout (name of copybook) **/
#include "fepf9006.h"     /** report data layout (name of copybook) **/

_EPRF9006 rpt_data;       /** Report1 Data Layout **/
_EPRS9006 rpt_sort;       /** Report1 Sort Layout **/

/**************************************************************************/
/*    ACCUMULATORS                                                        */
/**************************************************************************/


/**************************************************************************/
/*     WORK AREAS                                                         */
/**************************************************************************/

long   current;

char   cEndOfRpt,                 /* End of report indicator */
       sTempFld[8+1],     /* String representation of input value before commas */
       sFormatFld[35],    /* String representation of input field */
       sFormatFld2[30],   /* String representation of input field 2 */
       sInputFld[10+1];             /* String representation of input value */

