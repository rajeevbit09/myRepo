/****************************************************************************
**                                                                         **
** File Name :      EPB97712.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB97701 module.                                   **
**                                                                         **
** Author :         TransQuest, Inc.                                       **
**                  Gayle Melton                                           **
**                                                                         **
** Date Created:    November 11, 1996                                      **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 11/04/1997   S MAKIM		          Added new counters for senior    **
**                                        officer mail file and fake zip   **
**                                        code for company mail file.      **
**                                        Removed some unused RSAM File    **
**                                        variables.                       **
**                                                                         **
**                                                                         **
** 02/23/2005   L. Scott		  Added ST_CD for status code on   **
**                                        t_flt_certft.                    **
**                                        Removed references to service    **
**                                        fys04118 since it no longer      **
**                                        needed because of ESS2 project.  **
****************************************************************************/
#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/*
 * You should include any subsytem header files here. For example:
 * #include "subsystem_db_io/current_date.h"
 *
 */

/*
 * No report sort and data layouts  
 */

/*
 * Service request and answer blocks
 */

#include "fyr04572.h"      /* service request layout */
#include "fya04572.h"      /* service answer layout  */
#include "fyr04603.h"      /* service request layout */
#include "fya04603.h"      /* service answer layout  */
#include "fyr04599.h"      /* service request layout */
#include "fya04599.h"      /* service answer layout  */
#include "fyr04586.h"      /* service request layout */
#include "fya04586.h"      /* service answer layout  */
#include "fyr04711.h"      /* service request layout */
#include "fya04711.h"      /* service answer layout  */

_R04572 R04572;            /* Service Request Layout */
_A04572 A04572;            /* Service Answer Layout  */
_R04603 R04603;            /* Service Request Layout */
_A04603 A04603;            /* Service Answer Layout  */
_R04599 R04599;            /* Service Request Layout */
_A04599 A04599;            /* Service Answer Layout  */
_R04586 R04586;            /* Service Request Layout */
_A04586 A04586;            /* Service Answer Layout  */
_R04711 R04711;            /* Service Request Layout */
_A04711 A04711;            /* Service Answer Layout  */

#define SERVICE_ID_04572  4572
#define SERVICE_ID_04603  4603
#define SERVICE_ID_04599  4599
#define SERVICE_ID_04586  4586
#define SERVICE_ID_04711  4711

/*
 * Function definitions
 */
void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_3000_WriteRecord();
int     DPM_3100_WriteRecord();
void    DPM_4000_WriteNrevBud();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */
#define NUMBER_OF_THREADS 5   /** Number of threads used **/
#define EPBINQ0 0             /** Inquiry thread **/
#define EPBINQ1 1             /** Inquiry thread **/
#define EPBINQ2 2             /** Inquiry thread **/
#define EPBUPD0 3             /** Update thread **/
#define EPBUPD1 4             /** Update thread **/

#define SPACE               ' '
#define DEFAULT_DATE        "1899-12-31-00:00:00"
#define NO_IND              "N"
#define NO_CHRG             "NC"
#define NULL_STRING         ""	 
#define NULL_CHAR           ' '
#define NREV_TYP            "SF"
#define PASS_TYP            "80"
#define F_F                 "F"
#define ISSUE_DT            "  /  /    "
#define STT_CD              "U"
#define BUDDY               "BU"
#define BATCH               "BATCH"
#define TKT_SEQ             "00000"

short     nSvcRtnCd;          /** Service return code **/
short     nExtnNbr;           /** calculated extension nbr **/
short     nLastExtnNbr;       /** last extension nbr used **/
char      sEffMo[3];          /** start month ***/
char      sEffDy[3];          /** start day   ***/
char      sEffYr[5];          /** start year  ***/
short     nFltAllotDyNbr;     /** Allotment day number ***/
char      sIssueDt[7];       /** Issue date in form MMDDYY **/
char      sPprNbr[10];        /** PPR ID **/
char      sEffDt[27];         /** Date of run **/
char      sTodayDt[27];       /** Run date in CCYYMMDD **/
char      sStrtMo[3];         /** PPR start month ***/
char      sStrtDy[3];        /** PPR start day   ***/
short     nMonth;                      
short     nDay;
int       nTktDoc;           /**Ticket document seq number **/

static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/


   /******   Save database buffer here:              ******/
   /*
   char   sPprNbr[10], 
          sEffDt[27], 
          sTodayDt[27], 
          sStrtMo[3],  
          sStrtDy[5]; 

   short  nMonth,                      
          nDay;
   */

   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   /*******   counters and accumulators              ******/

   char    end_of_save;

}  RS;
