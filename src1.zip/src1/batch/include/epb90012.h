/****************************************************************************
**                                                                         **
** File Name :      EPB90012.h                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.h>                                           **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB90012 module.                                   **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Created:    May 11, 1995                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

/***************************************************************************/
/*  FUNCTION PROTOTYPES                                                    */
/***************************************************************************/

void RFM_1000_InitializeFlds();
void RFM_3000_ProcessDetail();
void RFM_3100_ProcessReportRecord();
void RFM_3500_CreateFooter();
void RFM_4000_ProcessEndOfJob();
void RFM_5000_PageHeadings();
int CenterPosition(int nLength, char sInput[]);


/**************************************************************************/
/*   CONSTANTS                                                            */
/**************************************************************************/
/* these constants should be customized for each particular format module */

#define LINES_PER_PAGE 59
#define PAGE_WIDTH 132
#define DETAIL_LINE 1
#define GRAND_TOTAL_BREAK 13
#define STD_RPT_TITLE "DELTA AIR LINES, INC."

/**************************************************************************/
/*   INPUT AREA                                                           */
/**************************************************************************/

/*
 * Report sort and data layouts
 */

#include "feps9002.h"     /** report sort layout (name of copybook) **/
#include "fepf9002.h"     /** report data layout (name of copybook) **/
#include "frapecep.h"

_EPRF9002 rpt_data;       /** Report1 Data Layout **/
_EPRS9002 rpt_sort;       /** Report1 Data Layout **/

/**************************************************************************/
/*    ACCUMULATORS                                                        */
/**************************************************************************/


/**************************************************************************/
/*     WORK AREAS                                                         */
/**************************************************************************/

long   current;

char   sSavePprNbr[10] = NULL_STRING,       /* Saved PPR number */
       sSaveNrevNbr[3] = NULL_STRING,       /* Saved Nrev number */
       sSavePprStnId[6]   = NULL_STRING,    /* Saved station ID */
       sSavePprDeptNbr[6] = NULL_STRING,    /* Saved station ID */
       sFormatFld[35],                      /* Formatted print field */
       cFirstTime = 'Y',                    /* First time processing data indicator */
       cEndOfRpt;                           /* End of report indicator */

char   appl_heading_10[PAGE_WIDTH];          /* Add additional heading lines */
char   appl_heading_11[PAGE_WIDTH];          /* Add additional heading lines */

