//***************************************************************************
//* Common code for PASS batch modules
//*
//* History
//*
//* Date       Developer Description
//  08/04/99   JPR       Created with UTL_ZeroDatesTime
//
//***************************************************************************

#include "time.h"

//***************************************************************************
// Constants
//***************************************************************************
// Standard timestamp is YYYY-MM-DD-HH:MI:SS (0<=HH<=23)
#define DB_TS_POS_DAY     8         // Position where day information starts
#define DB_TS_POS_HOUR   11         // Position where hour information starts
#define DB_TS_POS_MIN    14         // Position where month information starts
#define DB_TS_POS_MON     5         // Position where month information starts
#define DB_TS_POS_TIME   11         // Postion where time information starts
#define DB_TS_POS_SEC    17         // Postion where second information starts
#define DB_TS_POS_YEAR    0         // Postion where year information starts
#define DB_TS_POS_YEAR_2  2         // Position where 2 digit year starts
#define DB_TS_ZERO_TIME "00:00:00"
#define DB_TS_DATE_SEPARATOR_STR "-"

// UTL_ConvertDate constants
#define CNV_DB_TO_YYYYMMDD         1     // For conversion functions DB is considered
#define CNV_YYYYMMDD_TO_DB         2     // the standard timestamp from above
#define CNV_DB_TO_MMDDYY           3
#define CNV_DB_TO_YYMMDD           4
#define CNV_DB_TO_HHMMSS_ONLY      5     // Removes all date info and returns reformatted time
#define CNV_DB_TO_DD_MMM_YYYY      6     // Format of 01 Jan 1999 (spaces, not delimiters)
#define CNV_DD_MMM_YYYY_TO_DB      7
#define CNV_YYYYMMDD_TO_MMDDYY     8
#define CNV_YYMMDD_TO_MMDDYY       9
#define CNV_MM_DD_YYYY_TO_YYYYMMDD 10    // from date is actually mm/dd/yyyy
#define CNV_MM_DD_YYYY_TO_DB       11    // from date is actually mm/dd/yyyy
#define CNV_DB_TO_MM_DD_YY         12    // to date is actually mm/dd/yy

//***************************************************************************
// Prototypes
//***************************************************************************
long       UTL_GetJulianFromDate(char *pszDate);
struct tm  UTL_GetTmFromDate(char *pszDate);
void       UTL_ZeroDatesTime(char *pszDate);
char *     UTL_ConvertDate(char *pszDate, int nConvertFlag);
void       UTL_StripTrailingSpaces(char *psz);

//***************************************************************************
// Functions
//***************************************************************************



//***************************************************************************
// Converts the database timestamp from YYYY-DD-MM-HH24:MI:SS to YYYY-DDD
//***************************************************************************
long UTL_GetJulianFromDate(char *pszDate)
{
    char sTemp[] = "YYYYDDD";

    struct tm    sInTimeStruct, /** Flight departure date time components **/
    *pOutTimeStruct;            /** Pointer to populated time components **/

    time_t       lSeconds;      /** Flight date in seconds **/
    int          nMonth, nDay, nYear;

   /**** Initialize time structure ****/
    memset(&sInTimeStruct, 0, sizeof(sInTimeStruct));

   /**** Allocate space and set pointer to correct block ****/
    pOutTimeStruct = (struct tm*) malloc(sizeof(sInTimeStruct));

    nYear  = atoi(&pszDate[DB_TS_POS_YEAR]);
    nMonth = atoi(&pszDate[DB_TS_POS_MON]);
    nDay   = atoi(&pszDate[DB_TS_POS_DAY]);

   /**** Format components of time structure ****/
    sInTimeStruct.tm_mon = nMonth - 1;
    sInTimeStruct.tm_mday = nDay;
    sInTimeStruct.tm_year = nYear - 1900;

   /**** Convert flight departure date to seconds from Jan 1, 1970 to flight departure date ****/
    lSeconds = mktime(&sInTimeStruct);

   /**** Populate all time components for flight departure date ****/
    pOutTimeStruct = gmtime(&lSeconds);

   /**** Format Julian flight departure date ****/
    strftime(sTemp, sizeof(sTemp), "%Y%j", pOutTimeStruct);

    return(atol(sTemp));
}


//***************************************************************************
// Zeroes the time on the database timestamp format.
// pszDate must be of the format YYYY-DD-MM-HH24:MI:SS
//****************************************************************************
void UTL_ZeroDatesTime(char *pszDate)
{
   strcpy(&pszDate[DB_TS_POS_TIME], DB_TS_ZERO_TIME);
}


//***************************************************************************
// Converts the database timestamp YYYY-DD-MM-HH24:MI:SS into the tm structure
// doesn't convert sec, wday, yday or isdst
//
// NOTE:  tm_mon flies in the face of the time.h standard and returns 1-12
//
//****************************************************************************
struct tm  UTL_GetTmFromDate(char *pszDate)
{
    struct tm    Tm;

   /**** Initialize time structure ****/
    memset(&Tm, 0, sizeof(Tm));

    Tm.tm_year = atoi(pszDate);
    Tm.tm_mon = atoi(&pszDate[DB_TS_POS_MON]);
    Tm.tm_mday = atoi(&pszDate[DB_TS_POS_DAY]);
    Tm.tm_hour = atoi(&pszDate[DB_TS_POS_HOUR]);
    Tm.tm_min = atoi(&pszDate[DB_TS_POS_MIN]);

    return Tm;
}

//***************************************************************************
// Converts a date string from one format to another.  See the constants at
// the top of this file for available conversions.  This function is primarily
// used for conversion from the standard date format into alternate formats for
// output files, reports, etc. 
//****************************************************************************
char *UTL_ConvertDate(char *pszDate, int nConvertFlag)
{
    static char sOutDt[27];
    char   *ppszMonths[] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
    short  i;
    char   szTemp[16];

    
    // Fill the string with \0 
    memset(sOutDt, 0, sizeof(sOutDt));

    // Perform the conversion based upon the the specified conversion flag
    switch( nConvertFlag )
    {
        case CNV_DB_TO_DD_MMM_YYYY:
	        strncpy(sOutDt, &pszDate[DB_TS_POS_DAY], 2);
	        strcat(sOutDt, " ");
	
	        // Convert the month to integer & subtract one as array is zero based
	        i = atoi(&pszDate[DB_TS_POS_MON]) - 1;

	        strcat(sOutDt, ppszMonths[i]);
	        strcat(sOutDt, " ");
	        strncat(sOutDt, &pszDate[DB_TS_POS_YEAR],  4);
	        break;

        case CNV_DD_MMM_YYYY_TO_DB:
	        // Use hardcoded offsets {7,3,0} for YYYYMMDD
	        // and lengths           {4,3,2} 
	        strncpy(sOutDt, &pszDate[7], 4);
	
	        // Find matching month and convert to integer (add one as array is zero based)
		    for (i=0; i < sizeof(ppszMonths)/sizeof(ppszMonths[0]); i++)
		    {
		        if (0 == strncmp(&pszDate[3], ppszMonths[i], 3))
			    {
			        sprintf(szTemp, "%02d", i+1);
			        strcat(sOutDt, szTemp);
	 		    }
		    }

		    strncat(sOutDt, &pszDate[0], 2);

	        // Shouldn't have to be this accurate, but doesn't hurt
            strncat(sOutDt, DB_TS_ZERO_TIME, sizeof(sOutDt) - strlen(sOutDt) - 1);
	        break;

        
	    case CNV_DB_TO_HHMMSS_ONLY:
	        strncpy(sOutDt, &pszDate[DB_TS_POS_HOUR], 2);
	        strncat(sOutDt, &pszDate[DB_TS_POS_MIN],  2);
	        strncat(sOutDt, &pszDate[DB_TS_POS_SEC],  2);
	        break;
	
        case CNV_DB_TO_MMDDYY:
	        strncpy(sOutDt, &pszDate[DB_TS_POS_MON],    2);
	        strncat(sOutDt, &pszDate[DB_TS_POS_DAY],    2);
	        strncat(sOutDt, &pszDate[DB_TS_POS_YEAR_2], 2);
	        break;
    
        case CNV_DB_TO_YYMMDD:
	        strncpy(sOutDt, &pszDate[DB_TS_POS_YEAR_2], 2);
            strncat(sOutDt, &pszDate[DB_TS_POS_MON],    2);
            strncat(sOutDt, &pszDate[DB_TS_POS_DAY],    2);
 	        break;

        case CNV_DB_TO_YYYYMMDD:
            strncpy(sOutDt, &pszDate[DB_TS_POS_YEAR], 4);
            strncat(sOutDt, &pszDate[DB_TS_POS_MON], 2);
            strncat(sOutDt, &pszDate[DB_TS_POS_DAY], 2);
            break;

        case CNV_YYYYMMDD_TO_DB:
	        // Use hardcoded offsets {0,4,6} for YYYYMMDD
	        // and lengths           {4,2,2} 
	        strncpy(sOutDt, &pszDate[0], 4);
	        strcat(sOutDt, DB_TS_DATE_SEPARATOR_STR);
	        strncat(sOutDt, &pszDate[4], 2);
	        strcat(sOutDt, DB_TS_DATE_SEPARATOR_STR);
	        strncat(sOutDt, &pszDate[6], 2);
	        strcat(sOutDt, DB_TS_DATE_SEPARATOR_STR);
	        // Shouldn't have to be this accurate, but doesn't hurt
                strncat(sOutDt, DB_TS_ZERO_TIME, sizeof(sOutDt) - strlen(sOutDt) - 1);
	        break;

        case CNV_YYYYMMDD_TO_MMDDYY:
		    // Uses hardcoded offsets and lengths 
            strncpy(sOutDt, &pszDate[4], 2);
            strncat(sOutDt, &pszDate[6], 2);
            strncat(sOutDt, &pszDate[2], 2);
            break;

        case CNV_YYMMDD_TO_MMDDYY:
            // Uses hardcoded offsets and lengths
            strncpy(sOutDt, &pszDate[2], 2);
            strncat(sOutDt, &pszDate[4], 2);
            strncat(sOutDt, &pszDate[0], 2);
            break;

	    case CNV_MM_DD_YYYY_TO_YYYYMMDD:
            // Uses hardcoded offsets and lengths
            strncpy(sOutDt, &pszDate[6], 4);
            strncat(sOutDt, &pszDate[0], 2);
            strncat(sOutDt, &pszDate[3], 2);
            break;

	    case CNV_MM_DD_YYYY_TO_DB:
            // Use hardcoded offsets and lengths 
	        strncpy(sOutDt, &pszDate[6], 4);
	        strcat(sOutDt, DB_TS_DATE_SEPARATOR_STR);
	        strncat(sOutDt, &pszDate[0], 2);
	        strcat(sOutDt, DB_TS_DATE_SEPARATOR_STR);
	        strncat(sOutDt, &pszDate[3], 2);
	        strcat(sOutDt, DB_TS_DATE_SEPARATOR_STR);
	        strncat(sOutDt, DB_TS_ZERO_TIME, sizeof(sOutDt) - strlen(sOutDt) - 1);
            break;

        
        case CNV_DB_TO_MM_DD_YY:
	        strncpy(sOutDt, &pszDate[DB_TS_POS_MON],    2);
            strcat(sOutDt, "/");
	        strncat(sOutDt, &pszDate[DB_TS_POS_DAY],    2);
            strcat(sOutDt, "/"); 
	        strncat(sOutDt, &pszDate[DB_TS_POS_YEAR_2], 2);
	        break;

	    default:
	        // we should never be here.  If so the user will get a pointer to a 
	        // null string 
	        break;
    }

	// return a pointer to the output string
	return sOutDt;
}

//****************************************************************************
// Removes any trailing spaces from the passed in string                  
//****************************************************************************
void UTL_StripTrailingSpaces(char *psz)
{
   int nPos;

   for (nPos=(strlen(psz)-1); nPos >= 0; nPos--)
   {
      if( psz[nPos] == '\0' || psz[nPos] == ' ' )
      {
         strcpy(&psz[nPos], '\0');
      }
      else
      {
         break;
      }
   }
}
