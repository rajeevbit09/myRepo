/****************************************************************************
**                                                                         **
** File Name :      EPB60005.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  C. Eachus                                              **
**                                                                         **
** Date Created:    5/5/95                                                 **
**                                                                         **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"

#include "frapecep.h"

 /* Service request and answer blocks
 */

#include "fyr02823.h"      /** service request layout fyr02823 **/
#include "fya02823.h"      /** service answer layout fya02823 **/
#include "fyr04118.h"    
#include "fya04118.h"  
 
_R02823 R02823;        /** Service Request Layout **/
_A02823 A02823;        /** Service Answer Layout **/
_R04118 R04118;        /** Service Request Layout **/
_A04118 A04118;        /** Service Answer Layout **/

#define SERVICE_ID_02823  2823
#define SERVICE_ID_04118  4118

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_4920_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS 2         /** enter number of threads needed **/
#define EPBUPD0 0                   /** enter the associated thread number **/
#define EPBINQ0 1                   /** enter the associated thread number **/
#define FALSE_FLAG 0                /** define false as value 0 **/	
#define TRUE_FLAG  1                /** define true as value 1 **/


static struct
{
   char    start_of_save;




   /*** Flags defined ***/
   
   short nPassHistDel,
         nImputTripHistDel,
         nChgHistDel;
           

   char    end_of_save;

}  RS;
