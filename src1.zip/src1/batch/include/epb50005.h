/****************************************************************************
**                                                                         **
** File Name :      EPB50005.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author           L.Scott                                                **
**                                                                         **
** Date Created:    4/2005                                                 **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"


/* This is the structure for the detail record layout */

  struct detail
  {
     char sPprNbr[10];
     char sPsgrNm[26];
     char sBirthDt[9];
     char sAddrLn1[25];
     char sAddrLn2[25];
     char sCity[51];
     char sState[3];
     char sZip[10];
     char sPhone[21];
  } DTL_REC;


 /* Service request and answer blocks */

#include "fyr04716.h"      /** service request layout (name of copybook **/
#include "fya04716.h"      /** service answer layout (name of copybook  **/
#include "fyr04717.h"      /** service request layout (name of copybook **/
#include "fya04717.h"      /** service answer layout (name of copybook  **/
#include "fyr04718.h"      /** service request layout (name of copybook **/
#include "fya04718.h"      /** service answer layout (name of copybook  **/
#include "fyr04721.h"      /** service request layout (name of copybook **/
#include "fya04721.h"      /** service answer layout (name of copybook  **/

_R04716 R04716;        /** Service Request Layout **/
_A04716 A04716;        /** Service Answer Layout  **/
_R04717 R04717;        /** Service Request Layout **/
_A04717 A04717;        /** Service Answer Layout  **/
_R04718 R04718;        /** Service Request Layout **/
_A04718 A04718;        /** Service Answer Layout  **/
_R04721 R04721;        /** Service Request Layout **/
_A04721 A04721;        /** Service Answer Layout  **/


#define SERVICE_ID_04716  4716   /** select bdy_nrev_pax                     **/
#define SERVICE_ID_04717  4717   /** insert bdy_nrev_pax_dlm                 **/
#define SERVICE_ID_04718  4718   /** update bdy_nrev_pax                     **/
#define SERVICE_ID_04721  4721   /** insert bdy_nrev_pax_dlm                 **/

/*
 * Function definitions
 */

void    TPM_1000_Initialize();
void    TPM_2000_Mainline();
void    TPM_3000_ProcessFileEPBF010();
void    TPM_4000_ProcessFileRecords();
void    TPM_4005_FormatDetailRecord();
void    TPM_4510_UpdateBudNrev();
void    TPM_7100_ParseOutName();
void    TPM_7200_CheckForBudNrev();
void    TPM_7300_Write_BdyNrevPaxDlm();
void    TPM_7500_UpdateFltCertft();
void    TPM_8000_ProcessLUW();
void    TPM_9500_ProcessEndOfProgram();

  
/* #defines and global variables */
   
#define ZERO_DATE         "00000000"
#define NUMBER_OF_THREADS 3        /** enter number of threads needed **/
#define EPBINQ0 1                  // Reserved for      
#define EPBUPD0 2                  /** enter the associated thread number **/
#define EPBUPD1 3                  /** enter the associated thread number **/

#define ATHZ_REC          "A"      /** Authorized record        **/
#define SLASH             '/'
#define DLM_ID            "DLM_BUD"


#define HRUPDATE          "HRUPDT"
#define TRM_COMMENT               "EPB50005-Revoked due to termination of employment."
#define INELIGIBLE_COMMENT        "EPB50005-No longer eligible."
#define PROCESSED_REVOKED_COMMENT "EPB50005-Processed as revoked."
#define PPR_REVOKED_COMMENT       "EPB50005-Pass Rider added w/ PPR already revoked."
#define PPR_UNREVOKED_COMMENT     "EPB50005-Revoked Pass Rider unrevoked."
#define COMPANION_ADDED_COMMENT   "EPB50005-Companion added."
#define COMPANION_REVOKED_COMMENT "EPB50005-Companion revoked."
#define SPOUSE_ADDED_COMMENT      "EPB50005-Spouse added."
#define SPOUSE_REVOKED_COMMENT    "EPB50005-Spouse revoked."

/* global flags */

short nPPRPresent;
short nNrevPresent;

char  sEffdtYr[5];
char  sEffdtMo[3];
char  sEffdtDy[3];

char  cNameChgInd;
char  cMultNmInd;
char  cBdayChgInd;
char  cValidPsgrType;
char  cValidateError;
char  cNameError;
char  cErrorCode;

char  sLstNm[16];
char  sFrstNm[15];
char  sName[31];
char  sDbName[30];
char  sMidNm;
char  sFrstNmSpace[15];
char  sInputPsgrNm[26];
char  sTempMonth[3];
char  sTempDay[3];
char  sSourceSys[3];
char  sPprNbr[10];
char  sNrevNbr[3];
char  sStrtMo[3];
char  sStrtDy[3];
char  sPcPprNbr[10];
char  sPcNrevNbr[3];
 

int   q;

static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/

   int EPBF010;        /** Input file         **/

   /****  @read_into structure/buffers go here  ****/

   char    EPBF010_buffer[382];
/* char    EPBF010_buffer[128]; */

   /* Replace the following with values that will need to be saved for each commit. */

   char   sTodayDt[9]; // Format of YYYYMMDD
   char   sEffdtYr[5];
   char   sEffdtMo[3];
   char   sEffdtDy[3];



   char end_of_save;

}  RS;
