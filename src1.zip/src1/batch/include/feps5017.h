                                                                                
/*                                                                            */
/*   Header name  :   FEPS5017                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/10/2003                                              */
/*              Time: 10:44:15                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5017                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5017_RPTDATASTRUCT_z                                                  
#define _S5017_RPTDATASTRUCT_z                                                  
typedef struct __S5017_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5017_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5017_z                                                             
#define _EPRS5017_z                                                             
                                                                                
   typedef struct __EPRS5017                                                    
   {                                                                            
      _S5017_RPTDATASTRUCT S5017_RptDataStruct;                                 
   }  _EPRS5017;                                                                
#endif                                                                          
                                                                                
