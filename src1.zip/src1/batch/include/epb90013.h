/****************************************************************************
**                                                                         **
** File Name :      EPB90013.h                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.h>                                           **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB90013 module.                                   **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Created:    May 24, 1995                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

/***************************************************************************/
/*  FUNCTION PROTOTYPES                                                    */
/***************************************************************************/

void RFM_1000_InitializeFlds();
void RFM_3000_ProcessDetail();
void RFM_3100_ProcessReportRecord();
void RFM_4000_ProcessEndOfJob();
void RFM_5000_PageHeadings();
int  CenterPosition(int nLength, char sInput[]);

/**************************************************************************/
/*   CONSTANTS                                                            */
/**************************************************************************/
/* these constants should be customized for each particular format module */

#define LINES_PER_PAGE 59
#define PAGE_WIDTH 132
#define DETAIL_LINE 1
#define GRAND_TOTAL_BREAK 13
#define STD_RPT_TITLE "DELTA AIR LINES, INC."

/**************************************************************************/
/*   INPUT AREA                                                           */
/**************************************************************************/

/*
 * Report sort and data layouts
 */

#include "feps9003.h"     /** report sort layout (name of copybook) **/
#include "fepf9003.h"     /** report data layout (name of copybook) **/
#include "frapecep.h"

_EPRF9003 rpt_data;       /** Report1 Data Layout **/
_EPRS9003 rpt_sort;       /** Report1 Sort Layout **/

/**************************************************************************/
/*    ACCUMULATORS                                                        */
/**************************************************************************/


/**************************************************************************/
/*     WORK AREAS                                                         */
/**************************************************************************/

long   current;

char   sSavePprNbr[10] = NULL_STRING,     /* Saved PPR number */
       sSaveNrevNbr[3],                   /* Saved print field */
       sFormatFld[65],                    /* Formatted print field */
       sFormatFld2[35],
       sAmtFld[10],
       cEndOfRpt;                         /* End of report indicator */
