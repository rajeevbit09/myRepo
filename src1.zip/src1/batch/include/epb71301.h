/****************************************************************************
**                                                                         **
** File Name :      EPB71301.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB71301.c module.                                 **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Created:    October 4, 1995                                        **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/
#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/*
 * You should include any subsytem header files here. For example:
 * #include "subsystem_db_io/current_date.h"
 *
 */

/*
 * No Report sort and data layouts
 */

/*
 * Service request and answer blocks
 */

#include "fyr02597.h"      /** service request layout **/
#include "fya02597.h"      /** service answer layout **/
#include "fyr02649.h"      /** service request layout **/
#include "fya02649.h"      /** service answer layout **/
#include "fyr02650.h"      /** service request layout **/
#include "fya02650.h"      /** service answer layout **/
 
_R02597 R02597;        /** Service Request Layout **/
_A02597 A02597;        /** Service Answer Layout **/
_R02649 R02649;        /** Service Request Layout **/
_A02649 A02649;        /** Service Answer Layout **/
_R02650 R02650;        /** Service Request Layout **/
_A02650 A02650;        /** Service Answer Layout **/

#define SERVICE_ID_02597  2597
#define SERVICE_ID_02649  2649
#define SERVICE_ID_02650  2650


/*
 * Function definitions
 */
void     DPM_1000_Initialize();
void     DPM_2000_Mainline();
void     DPM_2500_WriteImputedRecord();
void     DPM_2600_UpdateMatchInd();
void     DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS     2          /** Number of threads needed **/
#define EPBINQ0               0          /** Cursor thread **/
#define EPBUPD0               1          /** First update thread **/

#define RECORD_CD       "27"
#define FILLER          "                            "

short      nSvcRtnCd;                    /** Service return code **/

static struct
{
   char     start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declaration  ******/
   int EPBF020;


   /*******   @read_into structure/buffer ******/
   char    EPBF020_buffer[81];
 
   /** Replace the next line with structure/buffer for **/
   /** header, footer, & transaction records **/
 

   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   char    sEffDt[27],              /** Effective processing date **/
           sPassEffDt[7];           /** Effective processing date **/

   short   EPBF020_record_cntr;     /** Output file record counter **/

   char    sPprNbr[10];             /** PPR number **/

   float   fFltImptWageAmt;         /** Imputed wage amount **/

   char    end_of_save;

} RS;
