/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS9005                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/02/95                                                */
/*              Time: 16:46:24                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS9005                           */
/******************************************************************************/
                                                                                
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef   FY002704_LEN                                                          
#define   FY002704_LEN                         6                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002635_LEN                                                          
#define   FY002635_LEN                         3                                
#endif                                                                          
#ifndef _S9005_RPTDATASTRUCT_z                                                  
#define _S9005_RPTDATASTRUCT_z                                                  
typedef struct __S9005_RptDataStruct                                            
{                                                                               
   char                sPprStnId[FY002711_LEN];                                 
   char                sPprDeptNbr[FY002704_LEN];                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltDprtDt[FY003584_LEN];                                
   char                sSvcChrgCd[FY002635_LEN];                                
}  _S9005_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS9005_z                                                             
#define _EPRS9005_z                                                             
                                                                                
   typedef struct __EPRS9005                                                    
   {                                                                            
      _S9005_RPTDATASTRUCT S9005_RptDataStruct;                                 
   }  _EPRS9005;                                                                
#endif                                                                          
                                                                                
