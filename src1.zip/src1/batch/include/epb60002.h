/****************************************************************************
**                                                                         **
** File Name :      EPB60002.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB60002.c module.                                 **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Created:    May 1, 1995                                            **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"

#include "frapecep.h"

/*
 * You should include any subsytem header files here. For example:
 * #include "subsystem_db_io/current_date.h"
 *
 */

/*
 * No Report sort and data layouts
 */

/*
 * Service request and answer blocks
 */

#include "fyr02872.h"      /** service request layout (name of copybook) **/
#include "fya02872.h"      /** service answer layout (name of copybook) **/
#include "fyr04118.h"      /** service request layout (name of copybook) **/
#include "fya04118.h"      /** service answer layout (name of copybook) **/
 
_R02872 R02872;        /** Service Request Layout **/
_A02872 A02872;        /** Service Answer Layout **/
_R04118 R04118;        /** Service Request Layout **/
_A04118 A04118;        /** Service Answer Layout **/

#define SERVICE_ID_02872  2872
#define SERVICE_ID_04118  4118

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
int     DPM_2100_ConvertDate();
void    DPM_2500_ProcessRows();
void    DPM_4920_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS     2     /** enter number of threads needed **/
#define EPBUPD0               0     /** enter the associated thread number **/
#define EPBINQ0               1     /** enter the associated thread number **/

static struct
{
   char     start_of_save;

   /****   Restart save area                      ******/

   /****   no RSAMFILE filename declarations  ******/


   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   char         sPprNbr[10];
   char 	sNrevNbr[3];
   char   	sFltNbr[6];
   char		sFltDprtDt[27];
   char         sTktNbr[11];
   char         sTodayDt[27];

   /**** Flag for all rows processed ****/
   short        nProcessedAllRows;

   /** No Report request table **/

   /* Values saved for each commit. */
   long         rows_archived_cntr;

   char    end_of_save;

} RS;

