/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5027                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 07/14/2008                                              */
/*              Time: 10:00:00                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5027                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5027_RPTDATASTRUCT_z                                                  
#define _S5027_RPTDATASTRUCT_z                                                  
typedef struct __S5027_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5027_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5027_z                                                             
#define _EPRS5027_z                                                             
                                                                                
   typedef struct __EPRS5027                                                    
   {                                                                            
      _S5027_RPTDATASTRUCT S5027_RptDataStruct;                                 
   }  _EPRS5027;                                                                
#endif                                                                          
                                                                                
