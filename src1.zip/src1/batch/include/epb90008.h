/****************************************************************************
**                                                                         **
** File Name :      EPB90008.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB90008 module.                                   **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Gillian Lyth                                           **
**                                                                         **
** Date Created:    Feb 22, 1996                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**  11/13/96    FFA                                                        **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/*
 * Report sort and data layouts
 */

#include "fepf9008.h"      /** report data layout (name of copybook) **/
#include "feps9008.h"      /** report sort layout (name of copybook) **/

_EPRF9008 EPRF9008;        /** Report1 Data Layout **/
_EPRS9008 EPRS9008;        /** Report1 Sort Layout **/

/*
 * Service request and answer blocks
 */

#include "fyr04247.h"      /** service request layout (name of copybook) **/
#include "fya04247.h"      /** service answer layout (name of copybook) **/
 
_R04247 R04247;        /** Service Request Layout **/
_A04247 A04247;        /** Service Answer Layout **/

#define SERVICE_ID_04247  4247

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_5010_Generate();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS     1         /** enter number of threads needed **/
#define EPBINQ0               0         /** enter the associated thread number **/

char       sSavePprNbr[10],
           sSavePprNm[31];

static struct
{
   char    start_of_save;

   int PRAF010;        /** Report output file **/

   char    sPprNbr[10],
           sFltFeeBegDt[27],
           sFltFeeEndDt[27];
   long    lTotalLegCnt;
   char    end_of_save;
}  RS;
