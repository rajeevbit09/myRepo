/****************************************************************************
**                                                                         **
** File Name :      EPB99002.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Delta Technologies                                     **
**                  LaShawnda Walker                                       **
**                                                                         **
** Date Created:    6/21/99                                                **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"
#include <time.h>

#include "feps9902.h"     /** report sort layout (name of copybook) **/
#include "fepf9902.h"     /** report data layout (name of copybook) **/

/* Report sort and data layouts */

_EPRF9902 EPRF9902;       /** Report1 Data Layout **/
_EPRS9902 EPRS9902;       /** Report1 Data Layout **/

/* Service request and answer blocks  */
#include "fyr04702.h"
#include "fya04702.h"

_R04702 R04702;
_A04702 A04702;

#define SERVICE_ID_04702  4702

/* Function definitions   */
void DPM_1000_Initialize();
void DPM_2000_Mainline();

/* #defines and global variables   */
#define NUMBER_OF_THREADS 3
#define EPBUPD0 0
#define EPBINQ0 1
#define EPBINQ1 2

static struct
{
   char    start_of_save;

   int PRAF010;        /** Report output file **/


   char    sTodayDt[27],
           sBegDt[27],
           sEndDt[27],
           PRAF010_buffer[236];


   char    end_of_save;
}  RS;
