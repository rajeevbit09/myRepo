/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS9008                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/23/95                                                */
/*              Time: 09:13:06                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS9008                           */
/******************************************************************************/
                                                                                
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef   FY002704_LEN                                                          
#define   FY002704_LEN                         6                                
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef _S9008_RPTDATASTRUCT_z                                                  
#define _S9008_RPTDATASTRUCT_z                                                  
typedef struct __S9008_RptDataStruct                                            
{                                                                               
   char                sPprStnId[FY002711_LEN];                                 
   char                sPprDeptNbr[FY002704_LEN];                               
   char                sPprNm[FY002480_LEN];                                   
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPassRptSortDt[FY003821_LEN];                            
}  _S9008_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS9008_z                                                             
#define _EPRS9008_z                                                             
                                                                                
   typedef struct __EPRS9008                                                    
   {                                                                            
      _S9008_RPTDATASTRUCT S9008_RptDataStruct;                                 
   }  _EPRS9008;                                                                
#endif                                                                          
                                                                                
