/****************************************************************************
**                                                                         **
** File Name :      EPB71203.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description : Imputed Wage NOtification Reports                         **
**                                                                         **
** Author :         TransQuest                                             **
**                  Gayle J. Swafford                                      **
**                                                                         **
** Date Created:    Novermber 18, 1996                                     **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 01/06/96     FFA                       Revised                          **
**                                                                         **
** 03/20/96     JFB                       Removed Voluntary Severance and  **
**                                        Former Western preprocessor      **
**                                        directives.                      **
**                                                                         **
** 04/10/96      JFB                     Added true cursor 4365.           **
**                                                                         **
** 11/18/96      GJS                     Copied EPB71201.h to EPB71203.h   **
**                                       and modified to only report on    **
**                                       Western and VolSev to enable      **
**                                       reports to be produced seperately.**
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"
//#include "frapcsr.h"

 /* Report sort and data layouts  */

#include "fepf7123.h"  
#include "feps7123.h" 

_EPRF7123 EPRF7123;     
_EPRS7123 EPRS7123;    

/* Service request and answer blocks   */
#include "fyr02576.h"      
#include "fya02576.h"     
#include "fyr02635.h"    
#include "fya02635.h"   
#include "fyr02668.h"  
#include "fya02668.h" 
#include "fyr02675.h"
#include "fya02675.h"      
#include "fyr02730.h"     
#include "fya02730.h"    
#include "fyr02869.h"   
#include "fya02869.h"  
#include "fyr04365.h"     
#include "fya04365.h"    
 
_R02576 R02576;        
_A02576 A02576;       
_R02635 R02635;      
_A02635 A02635;     
_R02668 R02668;    
_A02668 A02668;   
_R02675 R02675;  
_A02675 A02675; 
_R02730 R02730;
_A02730 A02730;        
_R02869 R02869;       
_A02869 A02869;      
_R04365 R04365;       
_A04365 A04365;      

#define SERVICE_ID_02576  2576
#define SERVICE_ID_02635  2635
#define SERVICE_ID_02668  2668
#define SERVICE_ID_02675  2675
#define SERVICE_ID_02730  2730
#define SERVICE_ID_02869  2869
#define SERVICE_ID_04365  4365

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2050_ProcessPprs();
void    DPM_2100_ProcessRows();
void    DPM_2120_SumImpWges();
void    DPM_2130_UpdateImputedTrip();
void	DPM_2200_ProcessTrip();
void    DPM_5013_GenerateEPB71213();
void    DPM_9500_ProcessEndOfProgram();

#define NUMBER_OF_THREADS 5       
#define EPBINQ0 0                
#define EPBINQ1 1               
#define EPBUPD0 2              
#define EPBUPD1 3
#define EPBCSR0 4             

char       sSaveNrevNbr[3],
           sNrevNbr[3],
           sFltOrig[4], 
           sFltDest[4], 
           sFlightNbr[6],
           sFlightDprtDt[27],
           sSortDprtDt[27],
           sTicketNbr[11],
           sPassGrp1[3],
           sPassGrp2[3],
           sPassGrp3[3],
           sPassGrp4[3],
           sPassGrp5[3],
           sPassGrp6[3];
double     fNrevPmt,
           fFltImptWage, 
           fFltImptVal,
           fCurrXChgRte;
long       lPassTripNbr;
static struct
{
   char    start_of_save;
   /****   Restart save area                      ******/
   int PRAF010;        /** Report output file **/

   short	nProcessedAllRows;

   char    sPprNbr[10],
           sCycle[3];
   int     recsproc;
   char    end_of_save;
}  RS;
