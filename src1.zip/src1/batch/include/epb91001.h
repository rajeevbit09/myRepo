/****************************************************************************
**                                                                         **
** File Name :      EPB91001.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Transquest Information Solutions                       **
**                  Faith Ammons>                                          **
**                                                                         **
** Date Created:    11/01/95                                               **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 05/03/99   L.Scott                     Swapped DMSS accounts for imputed**
**                                        travel to match what the GL and  **
**                                        DMSS said the accounts should be **
**                                        even though the accounts have    **
**                                        hard coded the other way for     **
**                                        over 2 years without problems.   **
**                                                                         **
**                                        The new accounts are as follows: **
**                                        domestic debit  189000104        **
**                                        domestic credit 189000105        **
**                                        German debit    189000102        **
**                                        German credit   189000103        **
**                                                                         ** 
** 02/18/05   E.Shelton                   Changed walker acct nbrs to SAP  **
**                                        acct nbrs                        **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/* Service request and answer blocks  */
#include "fyr02750.h"  
#include "fya02750.h" 
#include "fyr02751.h"  
#include "fya02751.h" 
#include "fyr02753.h"  
#include "fya02753.h" 
#include "fyr03208.h"  
#include "fya03208.h" 
#include "fyr03933.h"  
#include "fya03933.h" 
#include "fyr03934.h"  
#include "fya03934.h" 
#include "fyr03968.h"  
#include "fya03968.h" 
#include "fyr03970.h"  
#include "fya03970.h" 
#include "fyr04626.h"  
#include "fya04626.h" 
 
_R02750 R02750;    
_A02750 A02750;   
_R02751 R02751;    
_A02751 A02751;   
_R02753 R02753;    
_A02753 A02753;   
_R03208 R03208;   
_A03208 A03208;   
_R03933 R03933;   
_A03933 A03933;   
_R03934 R03934;   
_A03934 A03934;   
_R03968 R03968;   
_A03968 A03968;   
_R03970 R03970;   
_A03970 A03970;   
_R04626 R04626;   
_A04626 A04626;   

#define SERVICE_ID_02750  2750
#define SERVICE_ID_02751  2751
#define SERVICE_ID_02753  2753
#define SERVICE_ID_03208  3208
#define SERVICE_ID_03933  3933
#define SERVICE_ID_03934  3934
#define SERVICE_ID_03968  3968
#define SERVICE_ID_03970  3970
#define SERVICE_ID_04626  4626

/* Function definitions   */
void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_2600_CreateDMSSEntries();
void    DPM_3000_ProcessTaxes();
void    DPM_3100_ProcessDomesticTaxes();
void    DPM_3200_ProcessCanadianTaxes();
void    DPM_3500_ProcessImputedWages();
void    DPM_3600_ProcessImputedTrip();
void    DPM_4000_WriteDMSSEntry();      
void    DPM_4920_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();
void    writetolog(char x[], char y[]);

/* #defines and global variables   */
#define NUMBER_OF_THREADS 3
#define EPBUPD0           0         
#define EPBINQ0           1        
#define EPBINQ1           2        
#define YES_CHAR         'Y'
#define NO_CHAR          'N'
#define FTR_RECID        'F'
#define DTL_RECID        'D'
#define DEBIT            'D'
#define CREDIT           'C'
#define MULTIPLY         'M'
#define MONTHLY          "MM"
#define BIWEEKLY         "BW"
#define GERMANY          "FRG"
#define CAN_CURR         "CAD"
#define ACTIVITY_REV     "REVENUE "
#define ACTIVITY_LB      "########"
#define RESOURCE_REV     "MSRV"
#define RESOURCE_LB      "####"
#define REVENUE          "GLRV"
#define ASSET            "ASST"
#define LIABILITY        "LIAB"
#define PRODUCT_ID       "EPAS"
#define VCHRNBR          "165  GJ"
#define FLTNBR0          "00000"
#define SOURCEID         "B91001"
/********* new sap acct numbers ******/
#define REV_ACCTNBR      "4807865"
#define DOMTAX_ACCTNBR   "2140160"
#define CANTAX_ACCTNBR   "2190949"
#define GRMIMP_DBACCT    "2130102"
#define GRMIMP_CRACCT    "2130103"
#define DOMIMP_DBACCT    "2130105"
#define DOMIMP_CRACCT    "2130110"
/************** new sap acct numbers ***/
#define DOMTAX_DB        "PASS TAX ADJUSTMENT"
#define DOMTAX_CR        "PASS DOMESTIC TAX"
#define CANTAX_CR        "PASS CANADIAN TAX"
#define DOM_TAXRATE      .1
#define CAN_TAXRATE      .07
#define MAX_PASSGRPS     200
#define DMSS_FTR_FORMAT  "%c%8s%7s%13s%13s%09d"
#define DMSS_DTL_FORMAT  "%c%c%-6s%-4s%-8s%-8s%-3s%-20s%-8s%-4s%-9s%-5s%-5s%-5s%-4s%-4s%-9s%-2s%-7s%-15s"

char sCreateDate[9],
     sCreateTime[8],
     sSaveAcctNbr[10],
     sSaveAcctDs[61],
     sSaveDebitAcctNbr[10],
     sSaveDebitAcctDs[61],
     sSaveCreditAcctNbr[10],
     sSaveCreditAcctDs[61],
     sStatId[5],
     sExpActy[9],
     sRsrcId[5],
     sLocId1[6],
     sLocId2[6],
     sFltNbr[6],
     sDprtDt[9],
     sProdId[5],
     sPprNbr[10],
     sNrevNbr[3],
     sCharChrgAmt[16],
     sSavePprNbr[10],
     sSaveFltCo[5],
     sSaveEmpCo[5],
     sSaveCoCd[5],
     cDbtCrdInd,
     cPassGrpFound,
     cEndOfItems,  
     cDLPayrollInd;
double dTotalTaxAmt;
short  nPassGrpCnt;
long lRfrnDt;

typedef struct
{
char    sPassGrpCd[3],
        sAcctNbr[10];
}passgrp;

passgrp  pass_group[MAX_PASSGRPS];

static struct
{
   char    start_of_save;
   int EPBF020;        /** DMSS Interface file **/
   int  EPBF020_record_cnt;
   double EPBF020_debit_amt,
          EPBF020_credit_amt,
          dTotalRevChrgAmt;
   char EPBF020_buffer[150],
        cTaxInd,
        sInputDt[27],   
        sCycleId[3],    
        sPprNbr[10],
        sImptdPprNbr[10],
        end_of_save;
}  RS;
