/****************************************************************************
**                                                                         **
** File Name :      EPB71213.h                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.h>                                           **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shlrfmc0 module.                                   **
**                                                                         **
** Author :         <TransQuest>                                           **
**                  <Kimberly Gordon>                                      **
**                                                                         **
** Date Created:    October 25, 1995                                       **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 01/08/96     FFA                       Revised                          **
**                                                                         **
**                                                                         **
**                                                                         **
****************************************************************************/

/***************************************************************************/
/*  FUNCTION PROTOTYPES                                                    */
/***************************************************************************/

void RFM_1000_InitializeFlds();
void RFM_3000_ProcessDetail();
void RFM_3100_ProcessReportRecord();
void RFM_4000_ProcessEndOfJob();
void RFM_4100_PrintTrailerLines();
void RFM_5000_PageHeadings();
int  CenterPosition(int nLength, char *sInput);


/**************************************************************************/
/*   CONSTANTS                                                            */
/**************************************************************************/
/* these constants should be customized for each particular format module */

#define LINES_PER_PAGE 59
#define PAGE_WIDTH 132
#define DETAIL_LINE 1
#define GRAND_TOTAL_BREAK 13
#define STD_RPT_TITLE "DELTA AIR LINES, INC."

char	cEndOfRpt,
	sSaveNrevNm[31],
	sSaveNrevNbr[3],
	sSavePprNbr[10];
 

/**************************************************************************/
/*   INPUT AREA                                                           */
/**************************************************************************/

/*
 * Report sort and data layouts
 */

#include "fepf7123.h" 
#include "feps7123.h"

_EPRF7123 rpt_data; 
_EPRS7123 rpt_sort;

/**************************************************************************/
/*    ACCUMULATORS                                                        */
/**************************************************************************/

float	fTotImpWgs;

/**************************************************************************/
/*     WORK AREAS                                                         */
/**************************************************************************/

long current;
