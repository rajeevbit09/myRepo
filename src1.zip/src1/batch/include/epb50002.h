/****************************************************************************
**                                                                         **
** File Name :      EPB50002.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Gayle H. Melton                                        **
**                                                                         **
** Date Created:    December, 1995                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 07/23/96      FFA                      Added effective date to o/p file **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"


/*
 * Service request and answer blocks
 */

#include "fyr02856.h" 
#include "fya02856.h"
#include "fyr03834.h" 
#include "fya03834.h"
#include "fyr04182.h" 
#include "fya04182.h"
#include "fyr04183.h" 
#include "fya04183.h"
 
_R02856 R02856;     
_A02856 A02856;    
_R03834 R03834;   
_A03834 A03834;  
_A04182 A04182;  
_R04182 R04182;  
_A04183 A04183;  
_R04183 R04183;  

#define SERVICE_ID_02856  2856
#define SERVICE_ID_03834  3834
#define SERVICE_ID_04182  4182
#define SERVICE_ID_04183  4183

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_2505_ReadPprRec();
int     DPM_2510_PrintDetail();
void    DPM_3000_HRClientProcess();
void    DPM_3500_ProcessHRClientRows();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS 3        /** enter number of threads needed **/
#define EPBINQ0 0            
#define EPBINQ1 1           
#define EPBUPD0 2           


#define HR_FORMAT "%c%-9s%-3s%-2s%-30s%-24s%-24s%-24s%-2s%-9s%-3s%-15s%-10s%-5s%-2s%c%-2s%-12s%-8s%-8s%-8s%-8s%-2s%-8s%-2s%-2s%-3s%-2s%-2s%-2s%-8s%-8s%-8s%-10s"
struct
   {
   char RecordId,
        PprNbr[10],
        DtlFiller1[4],
        NrevNbr[3],
        NrevNm[31],
        AddrLn1[25],
        AddrLn2[25],
        City[25],
        State[3],
        Zip[10],
        CtryCd[4],
        Phone[16],
        Dept[11],
        Station[6],
        EmpCatCd[3],
        StsInd,
        StsActCd[3],
        AltId[13],
        StrtDt[9],
        EmpTermDt[9],
        PassRvkDt[9],
        InttaxNbr[9],
        RecType[3],
        NrevBdayDt[9],
        NrevTypCd[3],
        PassGrpCd[3],
        CitzCtryCd[4],
        ResdSts[3],
        DesStsActCd[3],
        SourceSys[3],
        CardIssDt[9],
        ErrorDt[9],
        EffDt[9],
        DtlFiller2[9];
  }hr_data;


/* This is the structure for the header record layout */
 
  struct header
  {
     char sHdrId[3];
     char sProcYear[4];
     char sProcMonth[2];
     char sProcDay[2];
     char sProcHr[2];
     char sProcMin[2];
     char sProcSec[2];
     char sProcXx[2];
     char sNbrItems[8];
     char sSysId[3];
     char sHdrFiller[238];
  } header;


int   nReset19Year;
int   nResetNDYear;
char  cCommitInd;
char  sEffDt[9];


static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/

   int EPBF020;        /** HR data file  **/


   /*******   Save database buffer here:             ******/
   char sPprNbr[10];
   char sNrevNbr[3];
   char sHRPprNbr[10];
   char sHRNrevNbr[3];
   char cEndOfNrevInd;

   /******   @read_into structure/buffers go here:   ******/
   char   EPBF020_buffer[268];


   int   EPBF020_record_cntr;
   int   nNrevCnt;
   int   nHRClientCnt;
   int   nReset19Year;
   int   nResetNDYear;

   char sReset19Date[27];
   char sResetNDDate[27];

   char    end_of_save;

}  RS;
