/****************************************************************************
**                                                                         **
** File Name :      EPB54099.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Faith Ammons                                           **
**                                                                         **
** Date Created:    04/28/95                                               **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
** 3/29/02     E. Shelton                 Added Canadian Sec Fee           **
** 04-APR-01  L.Scott                     Added the following cities to    **
**                                        airport array:  BOG, CUN, EZE,   **
**                                        GDL, MEX, PBC and SJD.           **
**                                                                         **
** 29-MAR-02  E.Shelton                   Added Canadian Sec Fee           **
**                                                                         **
** 26-JUN-02  L.Scott                     Added US_SECURITY_FEE acct number**
**                                        "219000500".                     **
**                                                                         **
** 09-SEP-02  L.Scott                     Added MEXICO_TOURISM_TAX acct    **
**                                        number "219000461".              **
**                                                                         **
** 18-NOV-02  L.Scott                     Added MONTEGO_BAY_TAX account    **
**                                        number "219000478".              **
**                                                                         **
** 04-NOV-03  L.Scott                     Changed MEXICO_TOURISM_TAX acct  **
**                                        number to "219000867".           **
**                                                                         **
** 02-FEB-05  E.Shelton                   Changed walker acct nbrs to SAP  **
**                                        acct. nbrs.                      **
**                                                                         **
** 18-SEP-7   L.Scott                     Added BELIZE_DEVELOP_TAX account **
**                                        number "2190505" and             **
**                                        BELIZE_CONSERV_TAX account       **
**                                        number "2190507".                **
**                                                                         **
** 04-MAY-09 G.Whitman                   Add variable for processing       **
**                                       NW ticket number                  **
**                                                                         **
** 16-JUL-09 A.Tripathi                  Added processing of Buddy Flight  **
**                                       Leg                               **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

#include "fyr02526.h"
#include "fya02526.h"
#include "fyr02554.h"
#include "fya02554.h"
#include "fyr02652.h"
#include "fya02652.h"
#include "fyr02653.h"
#include "fya02653.h"
#include "fyr02662.h"
#include "fya02662.h"
#include "fyr02664.h"
#include "fya02664.h"
#include "fyr02688.h"
#include "fya02688.h"
#include "fyr02689.h"
#include "fya02689.h"
#include "fyr02760.h"
#include "fya02760.h"
#include "fyr02763.h"
#include "fya02763.h"
#include "fyr02792.h"
#include "fya02792.h"
#include "fyr03208.h"
#include "fya03208.h"
#include "fyr03875.h"
#include "fya03875.h"
#include "fyr03876.h"
#include "fya03876.h"
#include "fyr03877.h"
#include "fya03877.h"
#include "fyr04076.h"
#include "fya04076.h"
#include "fyr04317.h"
#include "fya04317.h"
#include "fyr04325.h"
#include "fya04325.h"
#include "fyr04330.h"
#include "fya04330.h"
#include "fyr04331.h"
#include "fya04331.h"
#include "fyr04332.h"
#include "fya04332.h"
#include "fyr04339.h"
#include "fya04339.h"
#include "fyr04343.h"
#include "fya04343.h"
#include "fyr04417.h"
#include "fya04417.h"
#include "fyr04650.h"
#include "fya04650.h"
#include "fyr04651.h"
#include "fya04651.h"
#include "fyr04655.h"
#include "fya04655.h"
#include "fyr04656.h"
#include "fya04656.h"

_R02526 R02526;
_A02526 A02526;
_R02554 R02554;
_A02554 A02554;
_R02652 R02652;
_A02652 A02652;
_R02653 R02653;
_A02653 A02653;
_R02662 R02662;
_A02662 A02662;
_R02664 R02664;
_A02664 A02664;
_R02688 R02688;
_A02688 A02688;
_R02689 R02689;
_A02689 A02689;
_R02760 R02760;
_A02760 A02760;
_R02763 R02763;
_A02763 A02763;
_R02792 R02792;
_A02792 A02792;
_R03208 R03208;
_A03208 A03208;
_R03875 R03875;
_A03875 A03875;
_R03876 R03876;
_A03876 A03876;
_R03877 R03877;
_A03877 A03877;
_R04076 R04076;
_A04076 A04076;
_R04317 R04317;
_A04317 A04317;
_R04325 R04325;
_A04325 A04325;
_R04330 R04330;
_A04330 A04330;
_R04331 R04331;
_A04331 A04331;
_R04332 R04332;
_A04332 A04332;
_R04339 R04339;
_A04339 A04339;
_R04343 R04343;
_A04343 A04343;
_R04417 R04417;
_A04417 A04417;
_R04650 R04650;
_A04650 A04650;
_R04651 R04651;
_A04651 A04651;
_R04655 R04655;
_A04655 A04655;
_R04656 R04656;
_A04656 A04656;

#define SERVICE_ID_02526  2526
#define SERVICE_ID_02554  2554
#define SERVICE_ID_02652  2652
#define SERVICE_ID_02653  2653
#define SERVICE_ID_02662  2662
#define SERVICE_ID_02663  2663
#define SERVICE_ID_02664  2664
#define SERVICE_ID_02688  2688
#define SERVICE_ID_02689  2689
#define SERVICE_ID_02760  2760
#define SERVICE_ID_02763  2763
#define SERVICE_ID_02792  2792
#define SERVICE_ID_03208  3208
#define SERVICE_ID_03875  3875
#define SERVICE_ID_03876  3876
#define SERVICE_ID_03877  3877
#define SERVICE_ID_04076  4076
#define SERVICE_ID_04317  4317
#define SERVICE_ID_04325  4325
#define SERVICE_ID_04330  4330
#define SERVICE_ID_04331  4331
#define SERVICE_ID_04332  4332
#define SERVICE_ID_04339  4339
#define SERVICE_ID_04343  4343
#define SERVICE_ID_04417  4417
#define SERVICE_ID_04650  4650
#define SERVICE_ID_04651  4651
#define SERVICE_ID_04655  4655
#define SERVICE_ID_04656  4656


void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2100_ProcessFltlegs();
void    DPM_2200_ProcessRows();
void    DPM_2300_ProcessImpFltlegs();
void    DPM_2400_ProcessRows();
void    DPM_2500_ProcessBdyFltlegs();
void    DPM_2600_ProcessRows();
void    DPM_3000_CalcChgsAndFees();
void    DPM_3010_CalcBuddyFees();
void    DPM_3050_DayProcess();
void    DPM_3100_GetRelatedInfo();
void    DPM_3110_GetRemainAllot();
void    DPM_3200_UpdateAllotments();
void    DPM_3210_GetRemain90Allot();
void    DPM_3220_GetRemainPriorityAllot();
void    DPM_3300_CalcSvcChgs();
void    DPM_3400_CalcPenalties();
void    DPM_3600_CalcLegChgs();
void    DPM_3700_CalcIntlFees();
void    DPM_3800_OldDataProcess();
void    DPM_3810_ProcessOldFltLegs();
void    DPM_3820_UpdateAllotments();
void    DPM_3830_ProcessOrigDayChrgs();
void    DPM_3840_RebuildDayData();
void    DPM_3850_SaveOldData();
void    DPM_4100_SaveFltlegData();
void    DPM_4200_UpdateRemAllot();
void    DPM_4225_Deltamatic();
void    DPM_4250_UpdateDeltamatic();
void    DPM_4300_GetCharges();
void    DPM_4400_InsertCharge();
void    DPM_4450_InsertDayChrg();
void    DPM_4500_ProcessIntlFees();
void    DPM_4550_ProcessRows();
void    DPM_4575_ConvertCurrency();
void    DPM_4600_ProcessUSFees();
void    DPM_4650_ProcessRows();
void    DPM_4920_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();
void    writetolog(char xx[]);

#define NUMBER_OF_THREADS  11
#define EPBUPD0            0
#define EPBUPD1            1
#define EPBUPD2            2
#define EPBUPD3            3
#define EPBUPD4            4  // Reserved for True Cursor 4317
#define EPBUPD5            5  // Reserved for True Cursor 4343
#define EPBUPD6            9  // Reserved for True Cursor 4417
#define EPBINQ0            6
#define EPBINQ1            7
#define EPBINQ2            8
#define EPBINQ3            10
#define LANDING            'L'
#define DEPARTURE          'D'
#define DAYS               'D'
#define MILEAGE            'M'
#define REDUCED_RATE       'T'
#define YES_CHAR           'Y'
#define NO_CHAR            'N'
#define MULTIPLY           'M'
#define BUSINESS_CLASS     "B"
#define FIRST_CLASS        "F"
#define TKT_NBR_NINES      "9999999999"  /** default ticket number for DL flt legs **/
#define APHIS_FEE          "2140190"
#define YC_FEE             "2140195"
#define CAD_SEC_FEE        "2190503"
#define US_SECURITY_FEE    "2140175"
#define MEXICO_TOURISM_TAX "2190461"
#define MONTEGO_BAY_TAX    "2190478"
#define BELIZE_DEVELOP_TAX "2190505"
#define BELIZE_CONSERV_TAX "2190507"
#define STARS5             "*****"
#define STARS2             "**"
#define SANJUAN            "SJU"
#define CALGARY            "YYC"
#define VANCOUVER          "YVR"
#define MONTREAL           "YUL"
#define TORONTO            "YYZ"
#define EDMONTON           "YEG"
#define HALIFAX            "YHZ"
#define OTTAWA             "YOW"
#define MILEAGE_LIMIT      20000
#define DAY_LIMIT          100
#define ARPT_CD_ARY_LIMIT  14

struct
{
   char    sSavePprNbr[10];
   char    sSaveNrevNbr[3];
   char    sSaveDprtDt[27];
   char    sSaveSortDprtDt[27];
   char    sSaveArrvDt[27];
   short   nSaveDprtTm;
   char    sSaveOrig[6];
   char    sSaveDest[6];
   char    sSavePassTyp[3];
   char    sSaveClass[3];
   char    sSaveFltNbr[6];
   char    sSaveTktNbr[11];
   long    lSaveRfrnDt;
   double  fSaveChgAmt;
   char    sSaveChrgAcctNbr [10];
   char    cSaveOrigIntlInd;
   char    sSaveOrigRegCd[3];
   char    cSaveDestIntlInd;
   char    sSaveDestRegCd[3];
   char    sSaveNwTktDocNb[16];
} save_fltleg_data;

struct
{
   char    sOrigCty[6];
   char    sDestCty[6];
   char    sDprtDt[27];
   char    sSortDprtDt[27];
   char    sPassTyp[3];
   char    sArptPrTyp[3];
   char    cOrigIntlInd;
   char    sOrigReg[3];
   char    cDestIntlInd;
   char    sDestReg[3];
   double  lMilesFlown;
   short   nDprtTm;
} day_data[20];

struct
{
   char    sOrigCty[6];
   char    sDestCty[6];
   char    sDprtDt[27];
   char    sSortDprtDt[27];
   char    sPassTyp[3];
   char    sArptPrTyp[3];
   char    cOrigIntlInd;
   char    sOrigReg[3];
   char    cDestIntlInd;
   char    sDestReg[3];
   double  lMilesFlown;
   short   nDprtTm;
} oldday_data[20];

struct
{
   char    sOrigCty[6];
   char    sDestCty[6];
   char    sDprtDt[27];
   char    sSortDprtDt[27];
   char    sPassTyp[3];
   char    sArptPrTyp[3];
   char    cOrigIntlInd;
   char    sOrigReg[3];
   char    cDestIntlInd;
   char    sDestReg[3];
   double  lMilesFlown;
   short   nDprtTm;
}  combined_data[20];

struct
{
   char    sOrigCty[6];
   char    sDestCty[6];
   char    sArptPrTyp[3];
   char    cOrigIntlInd;
   char    sOrigReg[3];
   char    cDestIntlInd;
   char    sDestReg[3];
   double  lMilesFlown;
}  F3100_data;


char    sOldPprNbr[10];
char    sOldNrevNbr[3];
char    sKeyFields[30];
char    sPassTyp[3];
char    sPassTypCd[3];
char    sDayPassTyp[3];
char    sOldDayPassTyp[3];
char    sNrevNbr[3];
char    sNrev4250[3];
char    sArptPrTyp[3];
char    sChargeCd[3];
char    sChgDescr[16];
char    sChgAcctNbr[10];
char    sChgAcctNbr2[10];
char    sIntlFeeCity[6];
char    sIntlFeeDate[27];
char    aArptCd[ARPT_CD_ARY_LIMIT][3] = {"BOG","CCS","CMW","CNF","EZE","GIG","GRU","GUA","HAV","LIM","MAR","PTY","SJO","SCL"}; /* The airport codes listed are not exempt from the YC Fee */
int     nArptCdInd; /* Set to 1 if airport code for origination city is */
                    /* found in the aArptCd array */
char    sFltNbr[6];
int     nDayIndex;
int     nLegCnt;
int     nOldDayIndex;
int     nOldLegCnt;
int     nCombinedIndex;
long    lRfrnDt;
long    lOldRfrnDt;
long    lRemDomAllot;
long    lRemTransAllot;
long    lRemAllot;
long    lRemMiles;
long    lTotalMilesFlown;
long    lOrigMilesFlown;
long    lRemDays;
long    lPrevAllot;
double  fConvtdAmt;
double  fChgAmt;

char    cTransAllotFound;          /* various indicators   */
char    cAllotFound;
char    cPassAllotFound;
char    cChargeFound;
char    cEndOfFltlegData;
char    cEndOfImpFltlegData;
char    cEndOfBdyFltlegData;
char    cSvcChgCalc;
char    cEndOfIntlfeeData;
char    cCommitAnyway;
char    cImpFltlegInd;
char    cBdyFltlegInd;
char    cIntraEuroFeeInd;
char    cIntraEuroFeeFound;
char    cAllotment;
char    cProcessIntlFee;
char    cIntlFeeInd;
char    cFlatFeeInd;
char    cFirstTimeInd;
char    cTransOceanicInd;
char    cPriorPeriod;
char    cSaveAddlPass;
char    cAddlPass;
char    cTransAddlPass;
char    cFltPenaltyInd;
char    cSuspRvkInd;
char    cContDayProcInd;
char    cEndOfOldData;
char    cDecrementInd;
char    cOrigTAInd;
char    cParentSingleActive;
char    cParentOfAssocInd;
char    cDisableTransOceanicInd;
char    cOldDisableTransOceanicInd;

 struct
{
   char    start_of_save;


   short   sFltLegCnt,
           sImpFltLegCnt,
           sBdyFltLegCnt,
           nSvcChrgCnt,
           nIntlFeeCnt,
           nPenaltyCnt,
           nRefundCnt;
   double  dSvcChrgAmt,
           dIntlFeeAmt,
           dPenaltyAmt,
           dRefundAmt;
   char    sInputDt[27];

   char    end_of_save;
}  RS;
