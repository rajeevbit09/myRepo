/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS0541                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/18/95                                                */
/*              Time: 14:18:14                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS0541                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef _S0541_RPTDATASTRUCT_z                                                  
#define _S0541_RPTDATASTRUCT_z                                                  
typedef struct __S0541_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltDprtDt[FY003584_LEN];                                
}  _S0541_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS0541_z                                                             
#define _EPRS0541_z                                                             
                                                                                
   typedef struct __EPRS0541                                                    
   {                                                                            
      _S0541_RPTDATASTRUCT S0541_RptDataStruct;                                 
   }  _EPRS0541;                                                                
#endif                                                                          
                                                                                
