/****************************************************************************
**                                                                         **
** File Name :      EPB50001.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Gayle Melton                                           **
**                                                                         **
** Date Created:    9/95                                                   **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 7/28/98    S. Makim                    Added new function definitions   **
**                                        and some variables for Friends   **
**                                        and family certificate           **
**                                        processing.                      **
**                                                                         **
** 6/25/99    L. Scott                    Added comments for adding and    **
**                                        revoking of Companion and Spouse **
**                                        passenger types.                 **
**                                                                         **
**11/17/99    L. Scott                    Changed the starting extension   **
**                                        number for Friends and Family    **
**                                        certificates from 80 to 60.      **
**                                        Also added code for ASA          **
**                                        employees.                       **
**                                                                         **
**08/02/00    L. Scott                    Added code for Comair employees. **
**                                                                         **
**02/10/03    L. Scott                    Added code for Song employees.   **
**                                                                         **
**08/06/03    L. Scott                    Added code for Academy, SkyWest, **
**                                        ACA and Chautauqua employees.    **
**                                                                         **
**02/12/07    L. Scott                    Added code for Big Sky and       **
**                                        Express Jet employees.           **
**                                                                         **
**05/10/07    L. Scott                    Added code for domestic partners.**
**                                                                         **
**09/18/07    L. Scott                    Added code for Pinnacle          **
**                                        employees.                       **
**                                                                         **
**07/11/08    L. Scott                    Added code for Northwest         **
**                                        employee numbers.                **
**                                                                         **
**12/10/08    L. Scott                    Added code for Mesaba employees. **
**                                                                         **
**05/01/09    L. Scott                    Added code for Compass and MLT   **
**                                        employees.                       **
**                                                                         **
**09/08/09    M. Lewis                    Added code for Regional Elite    **
**                                                                         **
**12/09/09    L. Scott                    Added services fys04730 and      **
**                                        fys04741, function name          **
**                                        TPM_5525_DisableNrap for the OGT **
**                                        processing.                      **
**                                                                         **
**02/25/2010  L.SCOTT                     Added (short) nOneInitialLstNm   **
**                                        to check for one characer last   **
**                                        name.                            **
**                                                                         **
**09/09/2011  L.Scott                     For MAX_PASSTYPES increased the  **
**                                        number from 10 to 15.            **
**                                                                         **
**11/01/2011  B. Ellison                  Added code for GoJet Airlines    **
**                                                                         **
**11/01/2011  M. Hall                     Added Carrier Code for record    **
**                                                                         **
**12/18/2012  B. Ellison                  Added code for Delta Private Jet **
**                                                                         **
**10/27/2014  G. Whitman	          Added code for Air Wisconsin     **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"


/* This is the structure for the detail record layout */

  struct detail
  {
     char cRecordId;
     char sPprNbr[10];
     char sDtlFiller1[4];
     char sDesNrevNbr[3];
     char sPsgrNm[31];
     char sAddrLn1[25];
     char sAddrLn2[25];
     char sCity[25];
     char sState[3];
     char sZip[10];
     char sCtryCd[4];
     char sPhone[16];
     char sDept[11];
     char sStation[6];
     char sEmpCatCd[3];
     char cStsInd;
     char sStsActCd[3];
     char sAltId[13];
     char sStrtDt[9];
     char sEmpTermDt[9];
     char sPassRvkDt[9];
     char sInttaxNbr[9];
     char sRecType[3];
     char sBirthDt[9];
     char sPsgrTypeCd[3];
     char sPassGrpCd[3];
     char sCitzCtryCd[4];
     char sResdSts[3];
     char sDesStsActCd[3];
     char sSourceSys[3];
     char sCardIssDt[9];
     char sErrorDt[9];
     char sEffDt[9];      // Format YYYYMMDD
     char sOthrEmptCd[3];
     char cGndr[2];
     char sSlrySclId[4];
     char sDtlFiller2[5];
  } DTL_REC;


/* This is the structure for the header record layout */

  struct header
  {
     char sHdrId[3];
     char sProcYear[4];
     char sProcMonth[2];
     char sProcDay[2];
     char sProcHr[2];
     char sProcMin[2];
     char sProcSec[2];
     char sProcXx[2];
     char sNbrItems[7];
     char sSysId[2];
     char sHdrFiller[238];
     char sSortByte[1];
  }header;


/*
 * Report sort and data layouts
 */

#include "fepf5011.h"      /** report data layout (name of copybook) **/
#include "feps5011.h"      /** report sort layout (name of copybook) **/

#include "fepf5012.h"      /** report data layout (name of copybook) **/
#include "feps5012.h"      /** report sort layout (name of copybook) **/

#include "fepf5013.h"      /** report data layout (name of copybook) **/
#include "feps5013.h"      /** report sort layout (name of copybook) **/

#include "fepf5014.h"      /** report data layout (name of copybook) **/
#include "feps5014.h"      /** report sort layout (name of copybook) **/

#include "fepf5015.h"      /** report data layout (name of copybook) **/
#include "feps5015.h"      /** report sort layout (name of copybook) **/

#include "fepf5016.h"      /** report data layout (name of copybook) **/
#include "feps5016.h"      /** report sort layout (name of copybook) **/

#include "fepf5017.h"      /** report data layout (name of copybook) **/
#include "feps5017.h"      /** report sort layout (name of copybook) **/

#include "fepf5018.h"      /** report data layout (name of copybook) **/
#include "feps5018.h"      /** report sort layout (name of copybook) **/

#include "fepf5019.h"      /** report data layout (name of copybook) **/
#include "feps5019.h"      /** report sort layout (name of copybook) **/

#include "fepf5020.h"      /** report data layout (name of copybook) **/
#include "feps5020.h"      /** report sort layout (name of copybook) **/

#include "fepf5021.h"      /** report data layout (name of copybook) **/
#include "feps5021.h"      /** report sort layout (name of copybook) **/

#include "fepf5022.h"      /** report data layout (name of copybook) **/
#include "feps5022.h"      /** report sort layout (name of copybook) **/

#include "fepf5023.h"      /** report data layout (name of copybook) **/
#include "feps5023.h"      /** report sort layout (name of copybook) **/

#include "fepf5024.h"      /** report data layout (name of copybook) **/
#include "feps5024.h"      /** report sort layout (name of copybook) **/

#include "fepf5025.h"      /** report data layout (name of copybook) **/
#include "feps5025.h"      /** report sort layout (name of copybook) **/

#include "fepf5026.h"      /** report data layout (name of copybook) **/
#include "feps5026.h"      /** report sort layout (name of copybook) **/

#include "fepf5027.h"      /** report data layout (name of copybook) **/
#include "feps5027.h"      /** report sort layout (name of copybook) **/

#include "fepf5028.h"      /** report data layout (name of copybook) **/
#include "feps5028.h"      /** report sort layout (name of copybook) **/

#include "fepf5029.h"      /** report data layout (name of copybook) **/
#include "feps5029.h"      /** report sort layout (name of copybook) **/

#include "fepf5030.h"      /** report data layout (name of copybook) **/
#include "feps5030.h"      /** report sort layout (name of copybook) **/

#include "fepf5031.h"      /** report data layout (name of copybook) **/
#include "feps5031.h"      /** report sort layout (name of copybook) **/

#include "fepf5032.h"      /** report data layout (name of copybook) **/
#include "feps5032.h"      /** report sort layout (name of copybook) **/

#include "fepf5033.h"      /** report data layout (name of copybook) **/
#include "feps5033.h"      /** report sort layout (name of copybook) **/

_EPRF5011 EPRF5011;        /** Report1 (DL error report) Data Layout **/
_EPRS5011 EPRS5011;        /** Report1 Sort Layout **/

_EPRF5012 EPRF5012;        /** Report2 (WS error report) Data Layout **/
_EPRS5012 EPRS5012;        /** Report2 Sort Layout **/

_EPRF5013 EPRF5013;        /** Report3 (TQ error report) Data Layout **/
_EPRS5013 EPRS5013;        /** Report3 Sort Layout **/

_EPRF5014 EPRF5014;        /** Report4 (DS error report) Data Layout **/
_EPRS5014 EPRS5014;        /** Report4 Sort Layout **/

_EPRF5015 EPRF5015;        /** Report5 (AS error report) Data Layout **/
_EPRS5015 EPRS5015;        /** Report5 Sort Layout **/

_EPRF5016 EPRF5016;        /** Report6 (OH error report) Data Layout **/
_EPRS5016 EPRS5016;        /** Report6 Sort Layout **/

_EPRF5017 EPRF5017;        /** Report7 (ZW error report) Data Layout **/
_EPRS5017 EPRS5017;        /** Report7 Sort Layout **/

_EPRF5018 EPRF5018;        /** Report8 (CA error report) Data Layout **/
_EPRS5018 EPRS5018;        /** Report8 Sort Layout **/

_EPRF5019 EPRF5019;        /** Report9 (SW error report) Data Layout **/
_EPRS5019 EPRS5019;        /** Report9 Sort Layout **/

_EPRF5020 EPRF5020;        /** Report10 (AC error report) Data Layout **/
_EPRS5020 EPRS5020;        /** Report10 Sort Layout **/

_EPRF5021 EPRF5021;        /** Report11 (CT error report) Data Layout **/
_EPRS5021 EPRS5021;        /** Report11 Sort Layout **/

_EPRF5022 EPRF5022;        /** Report12 (Shuttle America error report) Data Layout **/
_EPRS5022 EPRS5022;        /** Report12 Sort Layout **/

_EPRF5023 EPRF5023;        /** Report13 (Freedom error report) Data Layout **/
_EPRS5023 EPRS5023;        /** Report13 Sort Layout **/

_EPRF5024 EPRF5024;        /** Report14 (Big Sky error report) Data Layout **/
_EPRS5024 EPRS5024;        /** Report14 Sort Layout **/

_EPRF5025 EPRF5025;        /** Report15 (Express Jet error report) Data Layout **/
_EPRS5025 EPRS5025;        /** Report12 Sort Layout **/

_EPRF5026 EPRF5026;        /** Report16 (Pinnacle error report) Data Layout **/
_EPRS5026 EPRS5026;        /** Report16 Sort Layout **/

_EPRF5027 EPRF5027;        /** Report17 (Northwest error report) Data Layout **/
_EPRS5027 EPRS5027;        /** Report17 Sort Layout **/

_EPRF5028 EPRF5028;        /** Report18 (Mesaba error report) Data Layout **/
_EPRS5028 EPRS5028;        /** Report18 Sort Layout **/

_EPRF5029 EPRF5029;        /** Report19 (Compass error report) Data Layout **/
_EPRS5029 EPRS5029;        /** Report19 Sort Layout **/

_EPRF5030 EPRF5030;        /** Report20 (MLT error report) Data Layout **/
_EPRS5030 EPRS5030;        /** Report20 Sort Layout **/

_EPRF5031 EPRF5031;        /** Report21 (Regional Elite error report) Data Layout **/
_EPRS5031 EPRS5031;        /** Report21 Sort Layout **/

_EPRF5032 EPRF5032;        /** Report22 (GoJet error report) Data Layout **/
_EPRS5032 EPRS5032;        /** Report22 Sort Layout **/

_EPRF5033 EPRF5033;        /** Report23 (Delta Private Jet error report) Data Layout **/
_EPRS5033 EPRS5033;        /** Report23 Sort Layout **/

/*
 * Service request and answer blocks
 */

#include "fyr02383.h"      /** service request layout (name of copybook **/
#include "fya02383.h"      /** service answer layout (name of copybook  **/
#include "fyr02384.h"      /** service request layout (name of copybook **/
#include "fya02384.h"      /** service answer layout (name of copybook  **/
#include "fyr02388.h"      /** service request layout (name of copybook **/
#include "fya02388.h"      /** service answer layout (name of copybook  **/
#include "fyr02389.h"      /** service request layout (name of copybook **/
#include "fya02389.h"      /** service answer layout (name of copybook  **/
#include "fyr02438.h"      /** service request layout (name of copybook **/
#include "fya02438.h"      /** service answer layout (name of copybook  **/
#include "fyr02441.h"      /** service request layout (name of copybook **/
#include "fya02441.h"      /** service answer layout (name of copybook  **/
#include "fyr02443.h"      /** service request layout (name of copybook **/
#include "fya02443.h"      /** service answer layout (name of copybook  **/
#include "fyr02444.h"      /** service request layout (name of copybook **/
#include "fya02444.h"      /** service answer layout (name of copybook  **/
#include "fyr02445.h"      /** service request layout (name of copybook **/
#include "fya02445.h"      /** service answer layout (name of copybook  **/
#include "fyr02475.h"      /** service request layout (name of copybook **/
#include "fya02475.h"      /** service answer layout (name of copybook  **/
#include "fyr02483.h"      /** service request layout (name of copybook **/
#include "fya02483.h"      /** service answer layout (name of copybook  **/
#include "fyr02529.h"      /** service request layout (name of copybook **/
#include "fya02529.h"      /** service answer layout (name of copybook  **/
#include "fyr02561.h"      /** service request layout (name of copybook **/
#include "fya02561.h"      /** service answer layout (name of copybook  **/
#include "fyr02564.h"      /** service request layout (name of copybook **/
#include "fya02564.h"      /** service answer layout (name of copybook  **/
#include "fyr02567.h"      /** service request layout (name of copybook **/
#include "fya02567.h"      /** service answer layout (name of copybook  **/
#include "fyr02645.h"      /** service request layout (name of copybook **/
#include "fya02645.h"      /** service answer layout (name of copybook  **/
#include "fyr02760.h"      /** service request layout (name of copybook **/
#include "fya02760.h"      /** service answer layout (name of copybook  **/
#include "fyr02762.h"      /** service request layout (name of copybook **/
#include "fya02762.h"      /** service answer layout (name of copybook  **/
#include "fyr02763.h"      /** service request layout (name of copybook **/
#include "fya02763.h"      /** service answer layout (name of copybook  **/
#include "fyr02764.h"      /** service request layout (name of copybook **/
#include "fya02764.h"      /** service answer layout (name of copybook  **/
#include "fyr02769.h"      /** service request layout (name of copybook **/
#include "fya02769.h"      /** service answer layout (name of copybook  **/
#include "fyr02861.h"      /** service request layout (name of copybook **/
#include "fya02861.h"      /** service answer layout (name of copybook  **/
#include "fyr02865.h"      /** service request layout (name of copybook **/
#include "fya02865.h"      /** service answer layout (name of copybook  **/
#include "fyr03341.h"      /** service request layout (name of copybook **/
#include "fya03341.h"      /** service answer layout (name of copybook  **/
#include "fyr03834.h"      /** service request layout (name of copybook **/
#include "fya03834.h"      /** service answer layout (name of copybook  **/
#include "fyr04000.h"      /** service request layout (name of copybook **/
#include "fya04000.h"      /** service request layout (name of copybook **/
#include "fyr04003.h"      /** service request layout (name of copybook **/
#include "fya04003.h"      /** service answer layout (name of copybook  **/
#include "fyr04036.h"      /** service request layout (name of copybook **/
#include "fya04036.h"      /** service answer layout (name of copybook  **/
#include "fyr04025.h"      /** service request layout (name of copybook  **/
#include "fya04025.h"      /** service answer layout (name of copybook  **/
#include "fyr04118.h"      /** service request layout (name of copybook  **/
#include "fya04118.h"      /** service answer layout (name of copybook  **/
#include "fyr04187.h"      /** service request layout (name of copybook  **/
#include "fya04187.h"      /** service answer layout (name of copybook  **/
#include "fyr04309.h"      /** service request layout (name of copybook  **/
#include "fya04309.h"      /** service answer layout (name of copybook  **/
#include "fyr04323.h"      /** service request layout (name of copybook  **/
#include "fya04323.h"      /** service answer layout (name of copybook  **/
#include "fyr04325.h"      /** service request layout (name of copybook  **/
#include "fya04325.h"      /** service answer layout (name of copybook  **/
#include "fyr04326.h"      /** service request layout (name of copybook  **/
#include "fya04326.h"      /** service answer layout (name of copybook  **/
#include "fyr04477.h"      /** service request layout (name of copybook  **/
#include "fya04477.h"      /** service answer layout (name of copybook  **/
#include "fyr04478.h"      /** service request layout (name of copybook  **/
#include "fya04478.h"      /** service answer layout (name of copybook  **/
#include "fyr04586.h"      /** service request layout (name of copybook  **/
#include "fya04586.h"      /** service answer layout (name of copybook  **/
#include "fyr04603.h"      /** service request layout (name of copybook  **/
#include "fya04603.h"      /** service answer layout (name of copybook  **/
#include "fyr04604.h"      /** service request layout (name of copybook  **/
#include "fya04604.h"      /** service answer layout (name of copybook  **/
#include "fyr04654.h"      /** service request layout (name of copybook  **/
#include "fya04654.h"      /** service answer layout (name of copybook  **/
#include "fyr04710.h"      /** service request layout (name of copybook  **/
#include "fya04710.h"      /** service answer layout (name of copybook  **/
#include "fyr04730.h"      /** service request layout (name of copybook  **/
#include "fya04730.h"      /** service answer layout (name of copybook  **/
#include "fyr04731.h"      /** service request layout (name of copybook  **/
#include "fya04731.h"      /** service answer layout (name of copybook  **/

_R02383 R02383;        /** Service Request Layout **/
_A02383 A02383;        /** Service Answer Layout  **/
_R02384 R02384;        /** Service Request Layout **/
_A02384 A02384;        /** Service Answer Layout  **/
_R02388 R02388;        /** Service Request Layout **/
_A02388 A02388;        /** Service Answer Layout  **/
_R02389 R02389;        /** Service Request Layout **/
_A02389 A02389;        /** Service Answer Layout  **/
_R02438 R02438;        /** Service Request Layout **/
_A02438 A02438;        /** Service Answer Layout  **/
_R02441 R02441;        /** Service Request Layout **/
_A02441 A02441;        /** Service Answer Layout  **/
_R02443 R02443;        /** Service Request Layout **/
_A02443 A02443;        /** Service Answer Layout  **/
_R02444 R02444;        /** Service Request Layout **/
_A02444 A02444;        /** Service Answer Layout  **/
_R02445 R02445;        /** Service Request Layout **/
_A02445 A02445;        /** Service Answer Layout  **/
_R02475 R02475;        /** Service Request Layout **/
_A02475 A02475;        /** Service Answer Layout  **/
_R02483 R02483;        /** Service Request Layout **/
_A02483 A02483;        /** Service Answer Layout  **/
_R02529 R02529;        /** Service Request Layout **/
_A02529 A02529;        /** Service Answer Layout  **/
_R02561 R02561;        /** Service Request Layout **/
_A02561 A02561;        /** Service Answer Layout  **/
_R02564 R02564;        /** Service Request Layout **/
_A02564 A02564;        /** Service Answer Layout  **/
_R02567 R02567;        /** Service Request Layout **/
_A02567 A02567;        /** Service Answer Layout  **/
_R02645 R02645;        /** Service Request Layout **/
_A02645 A02645;        /** Service Answer Layout  **/
_R02760 R02760;        /** Service Request Layout **/
_A02760 A02760;        /** Service Answer Layout  **/
_R02762 R02762;        /** Service Request Layout **/
_A02762 A02762;        /** Service Answer Layout  **/
_R02763 R02763;        /** Service Request Layout **/
_A02763 A02763;        /** Service Answer Layout  **/
_R02764 R02764;        /** Service Request Layout **/
_A02764 A02764;        /** Service Answer Layout  **/
_R02769 R02769;        /** Service Request Layout **/
_A02769 A02769;        /** Service Answer Layout  **/
_R02861 R02861;        /** Service Request Layout **/
_A02861 A02861;        /** Service Answer Layout  **/
_R02865 R02865;        /** Service Request Layout **/
_A02865 A02865;        /** Service Answer Layout  **/
_R03341 R03341;        /** Service Request Layout **/
_A03341 A03341;        /** Service Answer Layout  **/
_R03834 R03834;        /** Service Request Layout **/
_A03834 A03834;        /** Service Answer Layout  **/
_R04000 R04000;        /** Service Request Layout **/
_A04000 A04000;        /** Service Answer Layout  **/
_R04003 R04003;        /** Service Request Layout **/
_A04003 A04003;        /** Service Answer Layout  **/
_R04036 R04036;        /** Service Request Layout **/
_A04036 A04036;        /** Service Answer Layout  **/
_R04025 R04025;        /** Service Request Layout  **/
_A04025 A04025;        /** Service Answer Layout  **/
_R04118 R04118;        /** Service Request Layout  **/
_A04118 A04118;        /** Service Answer Layout  **/
_R04187 R04187;        /** Service Request Layout  **/
_A04187 A04187;        /** Service Answer Layout  **/
_R04309 R04309;        /** Service Request Layout  **/
_A04309 A04309;        /** Service Answer Layout  **/
_R04323 R04323;        /** Service Request Layout  **/
_A04323 A04323;        /** Service Answer Layout  **/
_R04325 R04325;        /** Service Request Layout  **/
_A04325 A04325;        /** Service Answer Layout  **/
_R04326 R04326;        /** Service Request Layout  **/
_A04326 A04326;        /** Service Answer Layout  **/
_R04477 R04477;        /** Service Request Layout  **/
_A04477 A04477;        /** Service Answer Layout  **/
_R04478 R04478;        /** Service Request Layout  **/
_A04478 A04478;        /** Service Answer Layout  **/
_R04586 R04586;        /** Service Request Layout  **/
_A04586 A04586;        /** Service Answer Layout  **/
_R04603 R04603;        /** Service Request Layout  **/
_A04603 A04603;        /** Service Answer Layout  **/
_R04604 R04604;        /** Service Request Layout  **/
_A04604 A04604;        /** Service Answer Layout  **/
_R04654 R04654;        /** Service Request Layout  **/
_A04654 A04654;        /** Service Answer Layout  **/
_R04710 R04710;        /** Service Request Layout  **/
_A04710 A04710;        /** Service Answer Layout  **/
_R04730 R04730;        /** Service Request Layout  **/
_A04730 A04730;        /** Service Answer Layout  **/
_R04731 R04731;        /** Service Request Layout  **/
_A04731 A04731;        /** Service Answer Layout  **/


#define SERVICE_ID_02383  2383   /** insert t_ppr                            **/
#define SERVICE_ID_02384  2384   /** update t_ppr                            **/
#define SERVICE_ID_02388  2388   /** insert t_pass_card                      **/
#define SERVICE_ID_02389  2389   /** update t_pass_card                      **/
#define SERVICE_ID_02438  2438   /** insert t_nrev_psgr                      **/
#define SERVICE_ID_02441  2441   /** primitive select t_remn_allot           **/
#define SERVICE_ID_02443  2443   /** primitive insert t_remn_allot           **/
#define SERVICE_ID_02444  2444   /** primitive update t_remn_allot           **/
#define SERVICE_ID_02445  2445   /** primitive delete t_remn_allot           **/
#define SERVICE_ID_02475  2475   /** select t_pass_grp                       **/
#define SERVICE_ID_02483  2483   /** insert t_cmnt                           **/
#define SERVICE_ID_02529  2529   /** select t_psgr_typ                       **/
#define SERVICE_ID_02561  2561   /** insert t_audit_trail                    **/
#define SERVICE_ID_02564  2564   /** revoke t_nrev_psgr(Rider)               **/
#define SERVICE_ID_02567  2567   /** update t_pass_card                      **/
#define SERVICE_ID_02645  2645   /** cursor t_pass_allot                     **/
#define SERVICE_ID_02760  2760   /** primitive select t_prior_per_remn_allot **/
#define SERVICE_ID_02762  2762   /** insert t_prior_per_remn_allot           **/
#define SERVICE_ID_02763  2763   /** update t_prior_per_remn_allot           **/
#define SERVICE_ID_02764  2764   /** primitive delete t_prior_per_remn_allot **/
#define SERVICE_ID_02769  2769   /** select mas card iss dt from t_pass_card **/
#define SERVICE_ID_02861  2861   /** select t_pass_grp_psgr_type             **/
#define SERVICE_ID_02865  2865   /** cursor t_remn_allot                     **/
#define SERVICE_ID_03341  3341   /** select count t_nrev_psgr - PARENTS      **/
#define SERVICE_ID_03834  3834   /** select t_ppr                            **/
#define SERVICE_ID_04000  4000   /** cursor t_pass_allot                     **/
#define SERVICE_ID_04003  4003   /** distinct cursor t_pass_typ_cd from t_pass_allot **/
#define SERVICE_ID_04025  4025   /** update pass_card                        **/
#define SERVICE_ID_04036  4036   /** select t_nrev_psgr                      **/
#define SERVICE_ID_04118  4118   /** convert date                            **/
#define SERVICE_ID_04187  4187   /** select ppr's t_nrev_psgr days/miles ind **/
#define SERVICE_ID_04309  4309   /** cursor t_nrev_psgr with update          **/
#define SERVICE_ID_04323  4323   /** primitive select t_deltamatic           **/
#define SERVICE_ID_04325  4325   /** primitive insert t_deltamatic           **/
#define SERVICE_ID_04326  4326   /** primitive update t_deltamatic           **/
#define SERVICE_ID_04477  4477   /** advanced cursor t_pass_card             **/
#define SERVICE_ID_04478  4478   /** advanced cursor t_pass_card             **/
#define SERVICE_ID_04586  4586   /** primitive insert t_flt_certft           **/
#define SERVICE_ID_04603  4603   /** select t_pass_allot                     **/
#define SERVICE_ID_04604  4604   /** update t_flt_certft                     **/
#define SERVICE_ID_04654  4654   /** update t_flt_certft                     **/
#define SERVICE_ID_04710  4710   /** select t_nrev_psgr - COMPANION/SPOUSE   **/
#define SERVICE_ID_04730  4730   /** update nrap_ppr_elgy                    **/
#define SERVICE_ID_04731  4731   /** delete nrap_bkg                         **/

/*
 * Function definitions
 */

void    TPM_1000_Initialize();
void    TPM_2000_Mainline();
void    TPM_3000_ProcessFileEPBF010();
void    TPM_4000_ProcessFileRecords();
int     TPM_4005_FormatDetailRecord();

int     TPM_4200_ProcessAddRecord();
int     TPM_4210_FormatPprInsertArea();
int     TPM_4215_InsertPprRecord();
int     TPM_4220_ProcessA1Add();
int     TPM_4230_ProcessC2Add();

int     TPM_4310_ProcessPprUpdate();
int     TPM_4315_FormatPprUpdateArea();
int     TPM_4320_UpdatePprRecord();

int     TPM_4400_ProcessNrevRecAdd();
int     TPM_4405_FormatNrevAddRec();
int     TPM_4410_InsertNrevRec();
int     TPM_4415_SelectNrevPprDyMiInd();

int     TPM_4510_UpdateNrevRecordCursor();
int     TPM_4515_UpdateNrevRecordSingle();
int     TPM_4520_UpdateAllNrevRecs();
int     TPM_4530_FormatNrevUpdtFromCursor();
int     TPM_4532_RvkCursorNrevInvldPgpPsgr();
int     TPM_4535_UpdateNrevSinglePsgr();
int     TPM_4540_FormatUpdateNrevSinglePsgr();

int     TPM_5500_ProcessChangeRecord();
int     TPM_5505_DetermineTypeOfChange();
int     TPM_5510_CheckForParents();
int     TPM_5512_CheckForCompanionOrSpouse();
int     TPM_5514_RevokeCompanionOrSpouse();
int     TPM_5515_GetCardIssDt();
void    TPM_5520_ProcessA1Change();
void    TPM_5525_DisableNrap();
void    TPM_5530_ProcessC2Change();

int     TPM_6500_ProcessDeleteRecord();
int     TPM_6510_RevokeAllPassRiders();
int     TPM_6515_RevokeSinglePassRider();
int     TPM_6520_RevokeC2PassRider();

int     TPM_7000_WriteToErrorFile();
int     TPM_7001_WriteFutureDatedRec();
short   TPM_7005_CalculateMonthsSvc(char *sStrtDt);
short   TPM_7006_CalculateEffMonthsSvc(char *sStrtDt);
short   TPM_7007_CalculateYearsSvc(char *sStrtDt);
int     TPM_7008_ConvertDate();
int     TPM_7010_CheckForPpr();
int     TPM_7015_EvalValidPsgrType();
int     TPM_7020_ParseOutName();
int     TPM_7025_CheckPprRevoked();
int     TPM_7030_CheckForNrevRecord();
int     TPM_7040_DetermineImputedTravelInd();
int     TPM_7041_ReadPassGpCodeTable();
int     TPM_7045_CheckPsgrTypeCdTbl();
void    TPM_7050_CursorNrevPsgr();
void    TPM_7055_NextNrevPsgr();

int     TPM_7100_BadDate();

void    TPM_7200_InsertComment();
void    TPM_7205_UpdateComment();
void    TPM_7206_ReadComment();
void    TPM_7210_WriteAuditTrail();

void    TPM_7310_WriteToPassCardTableRider();
void    TPM_7320_InsertPassCardTableRider();
void    TPM_7330_UpdatePassCardRecord();
void    TPM_7340_CursorPassCardTable();
void    TPM_7350_UpdatePassCardRecord();

void    TPM_7400_CreateAllotRecordRider();
void    TPM_7405_UpdateAllotRecordsRider();
void    TPM_7410_UpdateAllotRecordsAll();
void    TPM_7450_DeletePriorRemnAllotAll();
void    TPM_7455_InsertPriorRemnAllotRider();
void    TPM_7457_UpdatePriorRemnAllotRider();
void    TPM_7458_FormatUpdateRemnAllot();
void    TPM_7459_UpdateRemnAllotRider();
void    TPM_7460_DeleteRemnAllotRider();
void    TPM_7465_ResetAllotAll();

void    TPM_7470_StorePassTypeCodes();
void    TPM_7475_ReadPassTypeCodes();

void    TPM_7480_UpdateAllotments();
void    TPM_7484_FormatInsertRemnAllot();
void    TPM_7485_InsertNewRemnAllotRider();

void    TPM_7500_WriteDlmaticRecord();
void    TPM_7505_ReadDlmaticRecord();
void    TPM_7520_FormatDlmaticRec();

void    TPM_7530_CreateFAndFCertRecord();
void    TPM_7535_BlklstCertRecord();
void    TPM_7540_CheckElligibilityForCerts();

void    TPM_7611_GenerateEPB50011();
void    TPM_7612_GenerateEPB50012();
void    TPM_7613_GenerateEPB50013();
void    TPM_7614_GenerateEPB50014();
void    TPM_7615_GenerateEPB50015();
void    TPM_7616_GenerateEPB50016();
void    TPM_7617_GenerateEPB50017();
void    TPM_7618_GenerateEPB50018();
void    TPM_7619_GenerateEPB50019();
void    TPM_7620_GenerateEPB50020();
void    TPM_7621_GenerateEPB50021();
void    TPM_7622_GenerateEPB50022();
void    TPM_7623_GenerateEPB50023();
void    TPM_7624_GenerateEPB50024();
void    TPM_7625_GenerateEPB50025();
void    TPM_7626_GenerateEPB50026();
void    TPM_7627_GenerateEPB50027();
void    TPM_7628_GenerateEPB50028();
void    TPM_7629_GenerateEPB50029();
void    TPM_7630_GenerateEPB50030();
void    TPM_7631_GenerateEPB50031();
void    TPM_7632_GenerateEPB50032();
void    TPM_7633_GenerateEPB50033();
void    writetolog(char x[], char y);
void    writetologX(char x[], char y[]);

int     TPM_8000_ProcessLUW();
void    TPM_9500_ProcessEndOfProgram();


/* #defines and global variables */


#define NUMBER_OF_THREADS 28       /** enter number of threads needed **/
#define EPBINQ0 0                  /** enter the associated thread number **/
#define EPBINQ1 1                  // Reserved for 2865
#define EPBINQ2 2                  /** enter the associated thread number **/
#define EPBINQ3 3                  // Reserved for 4003
#define EPBINQ4 4                  // Reserved for 4000

#define EPBUPD0 5                  /** enter the associated thread number **/
#define EPBUPD1 6                  /** enter the associated thread number **/
#define EPBUPD2 7                  /** enter the associated thread number **/
#define EPBUPD3 8                  /** enter the associated thread number **/
#define EPBUPD4 9                  /** enter the associated thread number **/
#define EPBUPD5 10                 /** enter the associated thread number **/
#define EPBUPD6 11                 /** enter the associated thread number **/
#define EPBUPD7 12                 /** enter the associated thread number **/
#define EPBUPD8 13                 // Reserved for True Cursor 4309
#define EPBINQ5 14                 // Reserved for 2645
#define EPBINQ6 15                 // Reserved for 4003
#define EPBINQ7 16                 // Reserved for 4477

#define ADD_REC           'A'      /** ADD record        **/
#define CHANGE_REC        'C'      /** CHANGE record     **/
#define DELETE_REC        'D'      /** DELETE record     **/
#define HEADER_REC        'H'      /** HEADER record     **/
#define A1_REC            "A1"     /** A1 record         **/
#define C2_REC            "C2"     /** C2 record         **/
#define DELTA             "DL"     /** DELTA             **/
#define TRANSQUEST        "TQ"     /** TRANSQUEST        **/
#define WORLDSPAN         "WS"     /** WORLDSPAN         **/
#define DELTA_STAFFING    "DS"     /** DELTA_STAFFING    **/
#define ASA               "AS"     /** ASA               **/
#define COMAIR            "OH"     /** COMAIR            **/
#define SONG              "SO"     /** SONG              **/
#define COMAIR_ACADEMY    "CA"     /** COMAIR_ACADEMY    **/
#define SKYWEST           "OO"     /** SKYEST            **/
#define ACA               "DH"     /** ACA               **/
#define CHAUTAUQUA        "RP"     /** CHAUTAUQUA        **/
#define SHUTTLE_AMERICA   "S5"     /** SHUTTLE AMERICA   **/
#define FREEDOM           "F8"     /** FREEDOM           **/
#define BIG_SKY           "GQ"     /** BIG SKY           **/
#define EXPRESS_JET       "XE"     /** EXPRESS JET       **/
#define PINNACLE          "9E"     /** PINNACLE          **/
#define NORTHWEST         "NW"     /** NORTHWEST         **/
#define MANUAL            "MN"     /** MANUAL PPR        **/
#define MESABA            "XJ"     /** MESABA            **/
#define COMPASS           "CP"     /** COMPASS           **/
#define MLT               "ML"     /** MLT               **/
#define REGIONAL_ELITE    "RS"     /** Regional Elite    **/
#define GOJET             "G7"     /** GoJet             **/
#define DL_PRIVATE_JET    "PJ"     /** Delta Private Jet **/
#define AIR_WISCONSIN     "ZW"     /** AIR_WISCONSIN     **/
#define DECEASED_A1       "TH"     /** Deceased Employee **/
#define DECEASED_A1_BG    "BG"     /** Deceased Employee **/
#define DECEASED_C2       "DD"     /** Deceased Designee **/
#define DEATH_OF_SPOUSE   "DS"     /** Death of Spouse   **/
#define DEATH_OF_CHILD    "DC"     /** Death of Child    **/
#define PASS_TERM         "PT"     /** Pass Terminate    **/
#define YES_IND           'Y'      /** YES Indicator     **/
#define NO_IND            'N'      /** NO Indicator      **/
#define ACTIVE_IND        "A"      /** ACTIVE Indicator  **/
#define DAYS              "D"      /** Days indicator    **/
#define MILES             "M"      /** Miles indicator   **/
#define NULLSPACE         '\0'
#define GRD_SPACE         "   "
#define ZERO_GRD          "000"
#define ZERO_DATE         "00000000"
#define ZERO_EMP          "000000000"
#define ERROR_FILE        "ER"
#define FUTURE_FILE       "FU"
#define APOSTROPHE        '\''
#define NO_CHARGE         "NC"
#define MAX_PASSTYPES     15
#define F_and_F_IND       'F'
#define BEGIN_FF_EXTN_NBR 60
#define FF_PASS_TYPE      "80"
#define AB_PASS_TYPE      "70"
#define FAMFARE_PASS_TYPE "FA"
#define REWARD_PASS_TYPE  "15"
#define TERMINATE_BLKLST_CD 'X'
#define CRTF_STT_CD        'U'
#define MALE               'M'      /** ADD record        **/
#define FEMALE             'F'      /** ADD record        **/

#define HRUPDATE          "HRUPDT"
#define TRM_COMMENT               "EPB50001-Revoked due to termination of employment."
#define DECEASED_EMP_COMMENT      "EPB50001-Revoked due to death of employee."
#define DECEASED_DSG_COMMENT      "EPB50001-Revoked due to death of designee."
#define INELIGIBLE_COMMENT        "EPB50001-No longer eligible."
#define EX_SPOUSE_COMMENT         "EPB50001-Revoked due to divorce."
#define MAX_PARENT_COMMENT        "EPB50001-Maximum parents present-added as revoked."
#define PROCESSED_REVOKED_COMMENT "EPB50001-Processed as revoked."
#define PPR_REVOKED_COMMENT       "EPB50001-Pass Rider added w/ PPR already revoked."
#define PPR_UNREVOKED_COMMENT     "EPB50001-Revoked Pass Rider unrevoked."
#define COMPANION_ADDED_COMMENT   "EPB50001-Companion added."
#define COMPANION_REVOKED_COMMENT "EPB50001-Companion revoked."
#define SPOUSE_ADDED_COMMENT      "EPB50001-Spouse added."
#define SPOUSE_REVOKED_COMMENT    "EPB50001-Spouse revoked."
#define DOMPARTNER_ADDED_COMMENT  "EPB50001-Partner added."
#define DOMPARTNER_REVOKED_COMMENT "EPB50001-Partner revoked."

/* global flags */
long  lNrevRemnMiQty;
long  lUsedAllotMi;
short nNrevRemnDyQty;
short nUsedAllotDy;

short nPPRPresent;
short nNrevPresent;
short nValidPgpPtyp;
short nYrSvcCmpl;
short nMthSvcCmpl;
short nEndOfPassType;
short nEndOfPassRiders;
short nEndOfRemnAllot;
short nUpdateAll;
short nResetAll;
short nPassTypCnt;
short nOldAllotInd;
short nNewAllotInd;
short nMaxParentInd;
short nPprRevoked;
short nUnRevokedInd;
short nRvkYear;
short nRvkMonth;
short nRvkDay;
short nProcessAsRevoked;
short nChgToIneligible;
short nPriorRemnAllotInd;
short nPPRemnAllot;
short nCardIssDtChg;
short nDateFound;
short nPcRecFound;
short nPprFFElligible;
short nPprABElligible;
short nCertftQty;
short nSpouseInd;
short nCompanionInd;
short nDomPartnerInd;
short nSpouseRevoked;
short nCompanionRevoked;
short nDomPartnerRevoked;
short nRewardInd;
short nRemoveRewardInd;
short nIntlStation;
short nOneInitialLstNm;

char  sEffdtYr[5];
char  sEffdtMo[3];
char  sEffdtDy[3];
//char  sCrrCd[2];

char  cImputedInd;
char  cImputedIndChg;
char  cPGpChgInd;
char  cHireDtChgInd;
char  cNameChgInd;
char  cBdayChgInd;
char  cNrevTypChgInd;
char  cInttxChgInd;
char  cPassCardUpdated;
char  cThirdParentAdded;
char  cValidPsgrType;
char  cValidateError;
char  cNameError;
char  cErrorCode;
char  cParentChgInd;
char  cCpInd;
char  cServId;

char  sLstNm[16];
char  sFrstNm[15];
char  sName[31];
char  sDbName[30];
char  cMidNm;
char  sFrstNmSpace[15];
char  sInputPsgrNm[31];
char  sFullNm[31];
char  sFltDprtDt[8];
char  sTempMonth[3];
char  sTempDay[3];
char  sSourceSys[3];
char  sPprNbr[10];
char  sNrevNbr[3];
char  sStrtMo[3];
char  sStrtDy[3];
char  sPcPprNbr[10];
char  sPcNrevNbr[3];
char  sPcCardIssDt[27];
char  sSavePrvAtvnLupdtLts[27];
char  sSaveCurAtvnLupdtLts[27];
char  sSaveNxtAtvnLupdtLts[27];

char  sSavePassGrpCd[3];
char  cSavePrvAtvnFeeCd;
char  cSaveCurAtvnFeeCd;
char  cSaveNxtAtvnFeeCd;
char  sCrrCd[2];

int   q;


typedef struct
{
char sPassTypCd[3];
}passtype;

passtype  pass_type[MAX_PASSTYPES];


static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/

   int EPBF010;        /** Input file         **/
   int EPBF030;        /** Output Future Dated Records file **/

   int PRAF010;        /** DL Report output file **/
   int PRAF030;        /** DL Report output file **/



   /****  @read_into structure/buffers go here  ****/

   char    EPBF010_buffer[268];
   char    EPBF030_buffer[267+1];

   /** Replace the next line with structure/buffer for **/
   /** header, footer, & transaction records **/


   /* Replace the following with values that will need to be saved for each commit. */

   long   EPBF010_record_cntr;
   long   EPBF030_record_cntr;
   long   A1_record_cntr;
   long   C2_record_cntr;
   long   add_ppr_record_cntr;
   long   add_nrev_record_cntr;
   long   updt_ppr_record_cntr;
   long   updt_nrev_record_cntr;
   long   max_parent_record_cntr;
   long   records_not_processed;

   char   sLastPprNbr[10];

   char   sTodayDt[9]; // Format of YYYYMMDD
   char   sEffdtYr[5];
   char   sEffdtMo[3];
   char   sEffdtDy[3];

   /** Part of Report request table saved to "re_sync" report requests at restart **/


   char end_of_save;

}  RS;
