/****************************************************************************
**                                                                         **
** File Name :      EPB90014.h                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.h>                                           **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shlrfmc0 module.                                   **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  C. Eachus                                              **
**                                                                         **
** Date Created:    6/21/95                                                **
**                                                                         **
**                                                                         **
****************************************************************************/

/***************************************************************************/
/*  FUNCTION PROTOTYPES                                                    */
/***************************************************************************/

void RFM_1000_InitializeFlds();
void RFM_3000_ProcessDetail();
void RFM_3100_ProcessReportRecord();
void RFM_4000_ProcessEndOfJob();
void RFM_5000_PageHeadings();


/**************************************************************************/
/*   CONSTANTS                                                            */
/**************************************************************************/
/* these constants should be customized for each particular format module */

#define LINES_PER_PAGE 59
#define PAGE_WIDTH 132 
#define DETAIL_LINE 1
#define GRAND_TOTAL_BREAK 13
#define STD_RPT_TITLE "DELTA AIR LINES, INC."
#define LOW_VALUES '\0'


/** Define variable for end of report processing */

 char  cEndOfRpt;   

/**************************************************************************/
/*   INPUT AREA                                                           */
/**************************************************************************/

/*
 * Report sort and data layouts
 */

#include "feps9004.h"     /** report sort layout (name of copybook) **/
#include "fepf9004.h"     /** report data layout (name of copybook) **/

_EPRF9004 rpt_data;       /** Report1 Data Layout **/
_EPRS9004 rpt_sort;       /** Report1 Sort Layout **/


/**************************************************************************/
/*     WORK AREAS                                                         */
/**************************************************************************/

long current;
char sInputFld[35];           /* String representation of input value */
