/****************************************************************************
**                                                                         **
** File Name :      EPB90007.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB90007 module.                                   **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Gillian Lyth                                           **
**                                                                         **
** Date Created:    Feb 29, 1996                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/*
 * Report sort and data layouts
 */

#include "feps9007.h"      /** report sort layout (name of copybook) **/
#include "fepf9007.h"      /** report data layout (name of copybook) **/

_EPRF9007 EPRF9007;        /** Report1 Data Layout **/
_EPRS9007 EPRS9007;        /** Report1 Sort Layout **/

/*
 * Service request and answer blocks
 */

#include "fyr04274.h"      /** service request layout (name of copybook) **/
#include "fya04274.h"      /** service answer layout (name of copybook) **/
 
_R04274 R04274;        /** Service Request Layout **/
_A04274 A04274;        /** Service Answer Layout **/


#define SERVICE_ID_04274  4274

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_5010_Generate();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS     1         /** enter number of threads needed **/
#define EPBINQ0               0         /** enter the associated thread number **/



static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/

   int PRAF010;        /** Report output file **/


   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   char    sPprNbr[10];
   char    sNrevNbr[3];
   char    sFltDprtDt[27];
   char    sFltNbr[6],
           sFltOrigCtyId[6],
           sFltFeeBegDt[27],
           sFltFeeEndDt[27];

   /**** Flag for all rows processed ****/
   short        nProcessedAllRows;

   /** Part of Report request table saved to "re_sync" report requests at restart **/


   /* The following accumulators are not used in this module. */

   char    end_of_save;

}  RS;
