/****************************************************************************
**                                                                         **
** File Name :      EPB99012.h                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.h>                                           **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB99012 module.                                   **
**                                                                         **
** Author :         LaShawnda Walker                                       **
**                                                                         **
** Date Created:    July 16, 1999                                          **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

/***************************************************************************/
/*  FUNCTION PROTOTYPES                                                    */
/***************************************************************************/

void RFM_1000_InitializeFlds();
void RFM_3000_ProcessDetail();
void RFM_3100_ProcessReportRecord();
void RFM_4000_ProcessEndOfJob();
void RFM_5000_PageHeadings();


/**************************************************************************/
/*   CONSTANTS                                                            */
/**************************************************************************/
/* these constants should be customized for each particular format module */

#define LINES_PER_PAGE 59
#define PAGE_WIDTH 132
#define DETAIL_LINE 1
#define STD_RPT_TITLE "DELTA AIR LINES, INC."

#define ACTIVE       "AC"

/**************************************************************************/
/*   INPUT AREA                                                           */
/**************************************************************************/

/*
 * Report sort and data layouts
 */

#include "feps9902.h"     /** report sort layout (name of copybook) **/
#include "fepf9902.h"     /** report data layout (name of copybook) **/
#include "frapecep.h"

_EPRF9902 rpt_data;       /** Report1 Data Layout **/
_EPRS9902 rpt_sort;       /** Report1 Data Layout **/


/**************************************************************************/
/*     WORK AREAS                                                         */
/**************************************************************************/

long   current;
 
char   sFormatFld[35],                      /* Formatted print field */
       cEndOfRpt;                           /* End of report indicator */
