/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5015                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 04/20/00                                                */
/*              Time: 13:44:15                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5015                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5015_RPTDATASTRUCT_z                                                  
#define _S5015_RPTDATASTRUCT_z                                                  
typedef struct __S5015_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5015_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5015_z                                                             
#define _EPRS5015_z                                                             
                                                                                
   typedef struct __EPRS5015                                                    
   {                                                                            
      _S5015_RPTDATASTRUCT S5015_RptDataStruct;                                 
   }  _EPRS5015;                                                                
#endif                                                                          
                                                                                
