/****************************************************************************
**                                                                         **
** File Name :      EPB50021.h                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.h>                                           **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shlrfmc0 module.                                   **
**                                                                         **
** Author :         Delta Technology                                       **
**                  Lorenzo Scott                                          **
**                                                                         **
** Date Created:    August 8, 2003                                         **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
****************************************************************************/


/***************************************************************************/
/*  FUNCTION PROTOTYPES                                                    */
/***************************************************************************/

void RFM_1000_InitializeFlds();
void RFM_3000_ProcessDetail();
void RFM_3100_ProcessReportRecord();
void RFM_3200_ProcessTotals();
void RFM_4000_ProcessEndOfJob();
void RFM_5000_PageHeadings();
void RFM_5100_FormatNmCtyStZip();
int CenterPosition(int nLength, char sInput[]);

/**************************************************************************/
/*   CONSTANTS                                                            */
/**************************************************************************/

#define LINES_PER_PAGE 59
#define PAGE_WIDTH 132
#define DETAIL_LINE 1
#define GRAND_TOTAL_BREAK 13
#define STD_RPT_TITLE "DELTA AIR LINES, INC."

/**************************************************************************/
/*   INPUT AREA                                                           */
/**************************************************************************/


#include "fepf5021.h" 
#include "feps5021.h"

_EPRF5021 rpt_data; 
_EPRS5021 rpt_sort;


/**************************************************************************/
/*     WORK AREAS                                                         */
/**************************************************************************/

#define ERROR_1 '1'
#define ERROR_2 '2'
#define ERROR_3 '3'
#define ERROR_4 '4'
#define ERROR_5 '5'
#define ERROR_6 '6'
#define ERROR_7 '7'
#define ERROR_8 '8'
#define ERROR_9 '9'
#define ERROR_0 '0'

#define ERROR_1_MSG " Incorrect NAME format             "
#define ERROR_2_MSG " Parent Status Change - must verify"
#define ERROR_3_MSG " Record Type not A1 or C2          "
#define ERROR_4_MSG " Invalid Start Date                "
#define ERROR_5_MSG " Allotments Not Set                "
#define ERROR_6_MSG " Invalid Pass Group/Passenger Type "
#define ERROR_7_MSG " PPR Not Found                     "
#define ERROR_8_MSG " Nrev Passenger Not Found          " 
#define ERROR_9_MSG " Invalid Date Of Birth             " 
#define ERROR_0_MSG " Invalid Start Date                " 

long current;

char cEndOfRpt,
     cSaveRecInd,
     cFirstTime,
     sErrorText[36],
     sErrorMsg[36],
     sCharString[2],
     sSaveSource[3],
     sSavePprNbr[10],
     sSaveNrevNbr[3];

double dNrevTtlAmt = 0.0;
double dPprTtlAmt = 0.0;
