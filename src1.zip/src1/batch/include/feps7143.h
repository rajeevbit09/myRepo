/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS7143                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/12/98                                                */
/*              Time: 18:54:14                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS7143                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN
#define   FY002479_LEN                         10
#endif
#ifndef   FY002516_LEN
#define   FY002516_LEN                         3 
#endif
#ifndef   FY003581_LEN
#define   FY003581_LEN                         27
#endif
#ifndef   FY002778_LEN
#define   FY002778_LEN                         11
#endif
#ifndef   FY002521_LEN
#define   FY002521_LEN                         6 
#endif
#ifndef _S7143_RPTDATASTRUCT_z                                                  
#define _S7143_RPTDATASTRUCT_z                                                  
typedef struct __S7143_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];
   char                sNrevNbr[FY002516_LEN];
   char                sFltArrDt[FY003581_LEN];
   //short               nFltDprtTm;
   char                sFltDprtTm[5];
   char                sTktNbr[FY002778_LEN];
   char                sFltOrigCtyId[FY002521_LEN];
}  _S7143_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS7143_z                                                             
#define _EPRS7143_z                                                             
                                                                                
   typedef struct __EPRS7143                                                    
   {                                                                            
      _S7143_RPTDATASTRUCT S7143_RptDataStruct;                                 
   }  _EPRS7143;                                                                
#endif                                                                          
                                                                                
