/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF7101                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/14/96                                                */
/*              Time: 18:11:49                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF7101                           */
/******************************************************************************/
                                                                                
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002838_LEN                                                          
#define   FY002838_LEN                         6                                
#endif                                                                          
#ifndef   FY002839_LEN                                                          
#define   FY002839_LEN                         6                                
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F7101_RPTDATASTRUCT_z                                                  
#define _F7101_RPTDATASTRUCT_z                                                  
typedef struct __F7101_RptDataStruct                                            
{                                                                               
   char                sFltDprtDt[FY003584_LEN];                                
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevNm[FY002531_LEN];                                   
   char                sPprNbr[FY002479_LEN];                                   
   //long                lPassTripNbr;                                            
   char                sPassTripNbr[11];
   char                sFltTripOrigId[FY002838_LEN];                            
   char                sFltTripDestId[FY002839_LEN];                            
   char                cRecEndLineTxt;                                          
}  _F7101_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF7101_z                                                             
#define _EPRF7101_z                                                             
                                                                                
   typedef struct __EPRF7101                                                    
   {                                                                            
      _F7101_RPTDATASTRUCT F7101_RptDataStruct;                                 
   }  _EPRF7101;                                                                
#endif                                                                          
                                                                                
