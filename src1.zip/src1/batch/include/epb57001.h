/****************************************************************************
**                                                                         **
** File Name :      EPB57001.h                                             **
**                                                                         **
** Shell Used:      <shltpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shltpmc module.                                    **
**                                                                         **
** Author :         Delta Technology                                       **
**                  Lorenzo Scott                                          **
**                                                                         **
** Date Created:    12/15/2000                                             **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
**                                                                         **
**                                                                         **
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"


/* Service request and answer blocks */

#include "fyr09999.h"
#include "fya09999.h"     
#include "fyr08888.h"    
#include "fya08888.h"   
 
_R09999 R09999; 
_A09999 A09999;       
_R08888 R08888;      
_A08888 A08888;     

#define SERVICE_ID_09999  9999   /** select t_fltcertft **/ 
#define SERVICE_ID_08888  8888   /** update t_fltcertft **/ 

/* Function definitions */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_3000_ProcessFileEPBF010();
int     DPM_8000_ProcessLUW();
void    DPM_9500_ProcessEndOfProgram();

/* #defines and global variables */

#define NUMBER_OF_THREADS 2        
#define EPBUPD0 0                 
#define EPBINQ0 1                

char    sErrMsg[26];
short   nSvcRtnCd;
short   nSvcRtnCd1;

static struct
{
   char    start_of_save;

   int EPBF010;        /** Input Deltamatic file **/


   char    EPBF010_buffer[23];


   char sFltCertftNbr[10+1];
   char sCertftUseInd[1+1];
   short   Read;

   char    end_of_save;

}  RS;
