/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF7141                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/24/95                                                */
/*              Time: 14:14:20                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF7141                           */
/******************************************************************************/
                                                                                
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef   FY002704_LEN                                                          
#define   FY002704_LEN                         6                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002794_LEN                                                          
#define   FY002794_LEN                         9                               
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002838_LEN                                                          
#define   FY002838_LEN                         6                                
#endif                                                                          
#ifndef   FY002839_LEN                                                          
#define   FY002839_LEN                         6                                
#endif                                                                          
#ifndef   FY003586_LEN                                                          
#define   FY003586_LEN                         27                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F7141_RPTDATASTRUCT_z                                                  
#define _F7141_RPTDATASTRUCT_z                                                  
typedef struct __F7141_RptDataStruct                                            
{                                                                               
   char                sPprStnId[FY002711_LEN];                                 
   char                sPprDeptNbr[FY002704_LEN];                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sPprInttxNbr[FY002794_LEN];                                   
   char                sPprNm[FY002480_LEN];                                    
   char                sNrevNm[FY002531_LEN];                                   
   char                sFltDprtDt[FY003584_LEN];                                
   char                sFltTripOrigId[FY002838_LEN];                            
   char                sFltTripDestId[FY002839_LEN];                            
   long                lFltArptPrKmNbr;                                         
   double              fFltImptValAmt;                                          
   float               fNrevPmtAmt;                                             
   double              fFltImptWageAmt;                                         
   char                sFltFeeEndDt[FY003586_LEN];                              
   char                cRecEndLineTxt;                                          
}  _F7141_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF7141_z                                                             
#define _EPRF7141_z                                                             
                                                                                
   typedef struct __EPRF7141                                                    
   {                                                                            
      _F7141_RPTDATASTRUCT F7141_RptDataStruct;                                 
   }  _EPRF7141;                                                                
#endif                                                                          
                                                                                
