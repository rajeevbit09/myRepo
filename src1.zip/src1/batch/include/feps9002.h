/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS9002                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/23/95                                                */
/*              Time: 09:13:06                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS9002                           */
/******************************************************************************/
                                                                                
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef   FY002704_LEN                                                          
#define   FY002704_LEN                         6                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002480_LEN
#define   FY002480_LEN                         31
#endif
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef _S9002_RPTDATASTRUCT_z                                                  
#define _S9002_RPTDATASTRUCT_z                                                  
typedef struct __S9002_RptDataStruct                                            
{                                                                               
   char                sPprStnId[FY002711_LEN];                                 
   char                sPprDeptNbr[FY002704_LEN];                               
   char                sPassTypCd[FY002496_LEN];                                
   char                sPprNm[FY002480_LEN];
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPassRptSortDt[FY003821_LEN];                            
   char                sFltNbr[FY002553_LEN];                                   
   char                sFltOrigCtyId[FY002521_LEN];                             
}  _S9002_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS9002_z                                                             
#define _EPRS9002_z                                                             
                                                                                
   typedef struct __EPRS9002                                                    
   {                                                                            
      _S9002_RPTDATASTRUCT S9002_RptDataStruct;                                 
   }  _EPRS9002;                                                                
#endif                                                                          
                                                                                
