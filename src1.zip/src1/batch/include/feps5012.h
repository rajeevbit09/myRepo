/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5012                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/01/96                                                */
/*              Time: 13:44:15                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5012                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5012_RPTDATASTRUCT_z                                                  
#define _S5012_RPTDATASTRUCT_z                                                  
typedef struct __S5012_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5012_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5012_z                                                             
#define _EPRS5012_z                                                             
                                                                                
   typedef struct __EPRS5012                                                    
   {                                                                            
      _S5012_RPTDATASTRUCT S5012_RptDataStruct;                                 
   }  _EPRS5012;                                                                
#endif                                                                          
                                                                                
