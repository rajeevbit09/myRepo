/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS9001                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 12/12/95                                                */
/*              Time: 16:10:05                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS9001                           */
/******************************************************************************/
                                                                                
#ifndef   FY002489_LEN                                                          
#define   FY002489_LEN                         26                               
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef _S9001_RPTDATASTRUCT_z                                                  
#define _S9001_RPTDATASTRUCT_z                                                  
typedef struct __S9001_RptDataStruct                                            
{                                                                               
   char                sPassGrpDs[FY002489_LEN];                                
   char                sPassTypCd[FY002496_LEN];                                
}  _S9001_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS9001_z                                                             
#define _EPRS9001_z                                                             
                                                                                
   typedef struct __EPRS9001                                                    
   {                                                                            
      _S9001_RPTDATASTRUCT S9001_RptDataStruct;                                 
   }  _EPRS9001;                                                                
#endif                                                                          
                                                                                
