/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPF0541                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/31/95                                                */
/*              Time: 09:19:23                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRF0541                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002779_LEN                                                          
#define   FY002779_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002494_LEN                                                          
#define   FY002494_LEN                         26                               
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002636_LEN                                                          
#define   FY002636_LEN                         16                               
#endif                                                                          
#ifndef   FY000477_LEN                                                          
#define   FY000477_LEN                         1                                
#endif                                                                          
#ifndef _F0541_RPTDATASTRUCT_z                                                  
#define _F0541_RPTDATASTRUCT_z                                                  
typedef struct __F0541_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sPprNm[FY002480_LEN];                                   
   char                sPprSocSecNbr[FY002779_LEN];                             
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevNm[FY002531_LEN];                                   
   char                sNrevTypDs[FY002494_LEN];                                
   char                sFltDprtDt[FY003584_LEN];                                
   char                sSvcChrgDs[FY002636_LEN];                                
   //double              dCostChrgAmt;
   char                sCostChrgAmt[20];                                            
   char                cRecEndLineTxt;                                          
}  _F0541_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRF0541_z                                                             
#define _EPRF0541_z                                                             
                                                                                
   typedef struct __EPRF0541                                                    
   {                                                                            
      _F0541_RPTDATASTRUCT F0541_RptDataStruct;                                 
   }  _EPRF0541;                                                                
#endif                                                                          
                                                                                
