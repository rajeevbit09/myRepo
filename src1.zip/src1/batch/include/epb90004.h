/****************************************************************************
**                                                                         **
** File Name :      EPB90004.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  C. Eachus                                              **
**                                                                         **
** Date Created:     6/21/95                                               **
**                                                                         **
**                                                                         **
****************************************************************************/
#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "epbcmncd.h"

#include "frapecep.h"
/*
 * Report sort and data layouts
 */

#include "feps9004.h"      /** report sort layout (name of copybook) **/
#include "fepf9004.h"      /** report data layout (name of copybook) **/

_EPRF9004 EPRF9004;        /** Report1 Data Layout **/
_EPRS9004 EPRS9004;        /** Report1 Sort Layout **/

/*
 * Service request and answer blocks
 */

#include "fyr02808.h"      /** service request layout (name of copybook **/
#include "fya02808.h"      /** service answer layout (name of copybook **/
 
_R02808 R02808;        /** Service Request Layout **/
_A02808 A02808;        /** Service Answer Layout **/

#define SERVICE_ID_02808  2808

/*
 * Function definitions
 */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_5010_Generate();
void    DPM_9500_ProcessEndOfProgram();

/*
 * #defines and global variables
 */

#define NUMBER_OF_THREADS 1         /** enter number of threads needed **/
#define EPBINQ0 0                   /** enter the associated thread number **/

 
static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   int PRAF010;        /** Report output file **/


   /*******   Save database buffer here:             ******/
   /*******                                          ******/
   /*******   primary_database_key will need to be   ******/
   /*******   modified to the unique key of your     ******/
   /*******   driving database table                 ******/

   char    sPassDtTmTs[27],
           sFltFeeBegDt[27],
           sFltFeeEndDt[27];


   /*** Flag for processed all rows ***/

   short   nProcessedAllRows;

   /** Part of Report request table saved to "re_sync" report requests at restart **/


   /* Replace the following with values that will need to be saved for each commit. */
   
   /* THere are no accumulators in this report */ 

   short   accumulator_field1;
   double  accumulator_field2;

   char    end_of_save;

}  RS;
