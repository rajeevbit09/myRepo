/****************************************************************************
**                                                                         **
** File Name :      EPB53000.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the shldpmc module.                                    **
**                                                                         **
** Author :         TransQuest Information Solutions                       **
**                  Faith Ammons                                           **
**                                                                         **
** Date Created:    07/09/96                                               **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
**                                                                         **
****************************************************************************/
#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/* Service request and answer blocks */
#include "fyr04399.h" 
#include "fya04399.h"
#include "fyr04402.h" 
#include "fya04402.h"
 
_R04399 R04399;     
_A04399 A04399;    
_R04402 R04402;   
_A04402 A04402;  

#define SERVICE_ID_04399  4399
#define SERVICE_ID_04402  4402

/* Function definitions */

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_9500_ProcessEndOfProgram();

/* #defines and global variables */
#define NUMBER_OF_THREADS 2 
#define EPBINQ0 0            
#define EPBUPD0 1           

char cCommitInd;

#define INTF_FORMAT "%-3s%-9s%-2s%5s%-8s%-8s%-5s%-5s%-4s%-4s%-2s%-4s"

static struct
{
   char    start_of_save;

   /****   Restart save area                      ******/

   /****   RSAMFILE filename declarations go here  ******/

   int EPBF010;        /** Output suspense data file  **/
   char   EPBF010_buffer[59];

   char sPprNbr[10];
   char cEndOfSuspInd;
   int   EPBF010_record_cntr;
   int   nSuspCnt;

   char    end_of_save;

}  RS;
