/****************************************************************************
**                                                                         **
** File Name :      EPB90011.h                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.h>                                           **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB90011 module.                                   **
**                                                                         **
** Author :         Transquest Inc.                                        **
**                  Faith Ammons                                           **
**                                                                         **
** Date Created:    November 05, 1996                                      **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/

/***************************************************************************/
/*  FUNCTION PROTOTYPES                                                    */
/***************************************************************************/

void RFM_1000_InitializeFlds();
void RFM_1300_Initialize_SubTotals();
void RFM_3000_ProcessDetail();
void RFM_3100_ProcessReportRecord();
void RFM_3200_ProcessPassGroup();
void RFM_4000_ProcessEndOfJob();
void RFM_5000_PageHeadings();


/**************************************************************************/
/*   CONSTANTS                                                            */
/**************************************************************************/
/* these constants should be customized for each particular format module */

#define LINES_PER_PAGE 59
#define PAGE_WIDTH 132
#define DETAIL_LINE 1
#define GRAND_TOTAL_BREAK 13
#define STD_RPT_TITLE "DELTA AIR LINES, INC."

/**************************************************************************/
/*   INPUT AREA                                                           */
/**************************************************************************/

/*
 * Report sort and data layouts
 */
#include "frapecep.h"
#include "feps9001.h"           /* report sort layout */
#include "fepf9001.h"           /* report data layout */

_EPRF9001 rpt_data;             /* Report1 Data Layout */
_EPRS9001 rpt_sort;             /* Report1 Sort Layout */

/**************************************************************************/
/*    ACCUMULATORS                                                        */
/**************************************************************************/

long   lSubTotFltDyCnt,       
       lSubTotFltLegCnt,      
       lSubTotSvcChgCnt,      
       lGrandTotFltDyCnt,       
       lGrandTotFltLegCnt,      
       lGrandTotSvcChgCnt;      

double dSubTotSvcChgAmt,     
       dSubTotPenaltyAmt,   
       dSubTotIntlFeeAmt,  
       dSubTotChgAmt,
       dGrandTotSvcChgAmt,     
       dGrandTotPenaltyAmt,   
       dGrandTotIntlFeeAmt,  
       dGrandTotChgAmt;

/**************************************************************************/
/*     WORK AREAS                                                         */
/**************************************************************************/

long   current;

char   cEndOfRpt,               /* End of report flag */
       sInputFld[35],           /* String representation of input value */
       sSavePassGrpDs[26],        /* Saved Pass Group description */
       sSavePassTypDs[26];        /* Saved Pass type description */
