/****************************************************************************
**                                                                         **
** File Name :      EPB90003.h                                             **
**                                                                         **
** Shell Used:      <shldpmc.h>                                            **
**                                                                         **
** Description :                                                           **
**                                                                         **
** This header file contains all macros, typedefs, function prototypes,    **
** etc. required by the EPB90003 module.                                   **
**                                                                         **
** Author :         Andersen Consulting                                    **
**                  Julie Bowser                                           **
**                                                                         **
** Date Created:    May 24, 1995                                           **
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
****************************************************************************/
#include <stdio.h>
#include "frap.h"
#include "frapbch.h"
#include "frapecep.h"
#include "epbcmncd.h"

/** Report sort and data layouts**/

#include "feps9003.h"    
#include "fepf9003.h"   

_EPRF9003 EPRF9003;    
_EPRS9003 EPRS9003;   

/** Service request and answer blocks **/

#include "fyr02746.h"      
#include "fya02746.h"     
#include "fyr04403.h"    
#include "fya04403.h"   
 
_R02746 R02746;        
_A02746 A02746;       
_R04403 R04403;      
_A04403 A04403;     

#define SERVICE_ID_02746  2746
#define SERVICE_ID_04403  4403

/** Function definitions **/

void    DPM_1000_Initialize();
void    DPM_2000_Mainline();
void    DPM_2500_ProcessRows();
void    DPM_5000_GenerateFYEP9003();
void    DPM_5010_Generate();
void    DPM_9500_ProcessEndOfProgram();

/** #defines and global variables **/

#define NUMBER_OF_THREADS     2        /** Number of threads needed **/
#define EPBINQ0               0        /** First inquiry thread number **/
#define EPBINQ1               1        /** Second inquiry thread number **/
short   nSvcRtnCd;                     /** Service return code **/
static struct
{
   char    start_of_save;
   int PRAF010;        /** Report output file **/

   char    sPprNbr[10],
           sNrevNbr[3],
           sFltFeeEndDt[27];
   long    lPenaltyCnt;

   char    end_of_save;
}  RS;
