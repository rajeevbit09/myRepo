/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS7123                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 03/06/96                                                */
/*              Time: 18:27:17                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS7123                           */
/******************************************************************************/
                                                                                
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef _S7123_RPTDATASTRUCT_z                                                  
#define _S7123_RPTDATASTRUCT_z                                                  
typedef struct __S7123_RptDataStruct                                            
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltDprtDt[FY003584_LEN];                                
  //long                lPassTripNbr;
   char                sPassTripNbr[11];
}  _S7123_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS7123_z                                                             
#define _EPRS7123_z                                                             
                                                                                
   typedef struct __EPRS7123                                                    
   {                                                                            
      _S7123_RPTDATASTRUCT S7123_RptDataStruct;                                 
   }  _EPRS7123;                                                                
#endif                                                                          
                                                                                
