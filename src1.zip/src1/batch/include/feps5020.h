/******************************************************************************/
/*                                                                            */
/*   Header name  :   FEPS5020                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/08/2003                                              */
/*              Time: 10:00:00                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _EPRS5020                           */
/******************************************************************************/
                                                                                
#ifndef   FY003334_LEN                                                          
#define   FY003334_LEN                         1                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef _S5020_RPTDATASTRUCT_z                                                  
#define _S5020_RPTDATASTRUCT_z                                                  
typedef struct __S5020_RptDataStruct                                            
{                                                                               
   char                cEmplArRecInd;                                           
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
}  _S5020_RPTDATASTRUCT;                                                        
#endif                                                                          
                                                                                
#ifndef _EPRS5020_z                                                             
#define _EPRS5020_z                                                             
                                                                                
   typedef struct __EPRS5020                                                    
   {                                                                            
      _S5020_RPTDATASTRUCT S5020_RptDataStruct;                                 
   }  _EPRS5020;                                                                
#endif                                                                          
                                                                                
