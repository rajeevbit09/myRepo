/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB97201.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         TransQuest, Inc.                                       **
**                  Shridev Makim                                          **
**                                                                         **
** Date Written:    August 25, 1998                                        **
**                                                                         **
** Description:     This module extracts Blacklist records that are not    **
**                  yet processed and builds the file EPFI9702. Then it    **  
**                  marks all of these records as processed. Eventually    **  
**                  that file has been sent to Deltamatic via VECTR.       **  
**                                                                         **  
****************************************************************************/
#include "epb97201.h"

main()
{
   BCH_Init("EPB97201", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   /**** Initialize fields ****/
   strcpy(RS.sPprNbr, SPACE_CHAR);
   strcpy(RS.sCertftExtnNbr, SPACE_CHAR);

   /**** Initialize counters & accumulators ****/
   RS.total_record_cntr = 0;

   /**** Initialize message request and answer copybooks ****/
   memset(&R04627, LOW_VALUES, sizeof(_R04627));
   memset(&A04627, LOW_VALUES, sizeof(_A04627));
   memset(&R04628, LOW_VALUES, sizeof(_R04628));
   memset(&A04628, LOW_VALUES, sizeof(_A04628));

   /**** Log start of program ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");

   /**** open output file EPBF020 ****/
   RS.EPBF020 = BCH_Open("EPBF020",BCH_FILE_WRITE);
   if (RS.EPBF020 == BCH_FAIL)
   {
      BCH_FormatMessage(1,TXT_FILE_OPN_ERR);
      BCH_FormatMessage(2,TXT_OUT_FILE, "EPBF020");
      BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_1000_Initialize");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   ntotal_record_cntr = 0;

   /****** Initialize request and answer blocks *****/
   memset(&R04627.R04627_appl_area, LOW_VALUES, sizeof(_R04627_APPL_AREA));
   memset(&A04627.A04627_appl_area, LOW_VALUES, sizeof(_A04627_APPL_AREA));

   /**** Format service request block for initial DB cursor read ****/
   strcpy(R04627.R04627_appl_area.sPprNbr, RS.sPprNbr);
   strcpy(R04627.R04627_appl_area.sCertftExtnNbr, RS.sCertftExtnNbr);

   /**** Open the DB cursor ****/
   R04627.R04627_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /**** Execute service to select blacklisted records which are ****/
   /**** not processed yet.                                      ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04627,&A04627,SERVICE_ID_04627,1,sizeof(_R04627_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04627");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  
   
   /**** Process driving database rows ****/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      DPM_2500_ProcessRows();

      R04627.R04627_appl_area.cArchCursorOpTxt = FETCH_ROW;
      memset(&A04627.A04627_appl_area,LOW_VALUES,sizeof(_A04627_APPL_AREA));

      /**** Execute service to obtain next DB row ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04627,&A04627,SERVICE_ID_04627,1,sizeof(R04627.R04627_appl_area));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS04627");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
      }  
   }

   /**** After processing all of the records mark them as processed ****/
   DPM_3500_MarkRecordsProcessed();

   /**** Terminate the program ****/
   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();

   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows.             **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   char scertnbr[10];

   /********** PROCESS DATA TO THE APPROPRIATE OUTPUT FILE **********/

   /** Convert 15 char flightnbr into 10 char flight nbr **/
   strncpy(scertnbr, A04627.A04627_appl_area.sFltCertftNbr, 10);

   /**** Initialize the output record buffers ****/
   memset(&RS.EPBF020_buffer, SPACE, sizeof(RS.EPBF020_buffer));
 
   /****************************************************/
   /**** Format output buffer for black list record ****/
   /****************************************************/
   sprintf(RS.EPBF020_buffer, BLCKLIST_REC_FORMAT, BLCKLIST_IDENTIFIER,
           scertnbr, A04627.A04627_appl_area.cBlklstResnCd);

   BCH_WriteRec(RS.EPBF020, RS.EPBF020_buffer, sizeof(RS.EPBF020_buffer));
   ntotal_record_cntr++;
}

/******************************************************************
**                                                               **
** Function Name:   DPM_3500_MarkRecordsProcessed                **
**                                                               **
** Description:     Mark all of the BlackList records sent       **
**                  to Deltamatic as Processed                   **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_3500_MarkRecordsProcessed()
{
   /*** Next, update blach listed records to show that they have been processed ***/
   /*** set the blklst proc date = today for all items with blklst proc date =  ***/
   /*** 12/31/1899                                                              ***/
   memset(&R04628,LOW_VALUES,sizeof(R04628));
   memset(&A04628,LOW_VALUES,sizeof(A04628));

   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04628,&A04628,SERVICE_ID_04628,1,sizeof(&R04628));
 
   switch (nSvcRtnCd)
   {  
      case ARC_SUCCESS:
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04628");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_3500_MarkRecordsProcessed");
   }
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   RS.total_record_cntr = ntotal_record_cntr;

   BCH_Close(RS.EPBF020);

   /**** Write control totals ****/
   BCH_FormatMessage(1,TXT_OUT_FILE, "EPBF020");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.total_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}
