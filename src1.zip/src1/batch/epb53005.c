#include "epb53005.h"


main () {
   BCH_Init ("EPB53005", NUMBER_OF_THREADS);

   TPM_1000_Initialize();
   
   TPM_2000_Mainline();

   TPM_9500_ProcessEndOfProgram();

   BCH_Terminate();

   exit(0);
}


void TPM_1000_Initialize () {
   BCH_FormatMessage (1, TXT_PROG_STRT);
   BCH_HandleMessage (BCH_ERR_INFORMATION, __FILE__, "TPM_1000_Initialize");

   /*********** Open Incoming Deltamatic Interface file            *********/
   RS.EPBF5305 = BCH_Open ("EPBF5305", BCH_FILE_READ);
   if (RS.EPBF5305 == BCH_FAIL) {
      BCH_FormatMessage (1, TXT_FILE_OPN_ERR);
      BCH_FormatMessage (2, TXT_INPUT_FILE, "EPBF5305");
      BCH_HandleMessage (BCH_ERR_ABORT, __FILE__, "TPM_1000_Initialize");
   }

   /************ Read first interface record            ************/
   BCH_ReadRec (RS.EPBF5305, RS.EPBF5305_buffer, sizeof (RS.EPBF5305_buffer));
   if (BCH_eof (RS.EPBF5305)) {
      BCH_FormatMessage (1, TXT_EMPTY_INPUT_FILE);
      BCH_FormatMessage (2, TXT_INPUT_FILE, "EPBF5305");
      BCH_HandleMessage (BCH_ERR_WARNING, __FILE__, "TPM_1000_Initialize");
   }

   RS.Read = 0;
   RS.Dropped = 0;
   RS.Processed = 0;
   RS.FTI18DNCnt = 0;

   /**** Initialize Message Request and Answer Copybooks ***/
   memset(&R04724, LOW_VALUES, sizeof(_R04724));
   memset(&A04724, LOW_VALUES, sizeof(_A04724));
}


void TPM_2000_Mainline () {
   while (!BCH_eof (RS.EPBF5305)) {
      TPM_3000_ProcessFileEPBF5305 ();
      RS.Read++;
   }
}

                                             
void TPM_9500_ProcessEndOfProgram () {
   //int recSize = sizeof (RS.EPBF5305_buffer) - 1;
   int recSize = sizeof (RS.EPBF5305_buffer);
   time_t currTime = time (0);
   struct tm* pTmCurrTime = gmtime (&currTime);
   char* pszFilePath;
   FILE* pFileOut;
   int recIndx;

   BCH_Close (RS.EPBF5305);

   if (RS.FTI18DNCnt >= 0) {
      /*RS.EPBF5305_out = BCH_Open ("EPBF5305_out", BCH_FILE_WRITE);
      if (RS.EPBF5305_out == BCH_FAIL) {
         BCH_FormatMessage (1, TXT_FILE_OPN_ERR);
         BCH_FormatMessage (2, TXT_OUT_FILE, "EPBF5305_out");
         BCH_HandleMessage (BCH_ERR_ABORT, __FILE__, "TPM_9500_ProcessEndOfProgram");
      }
      
      sprintf (RS.EPBF5305_buffer, "%2s%04d%02d%02d%02d%02d%02d%06d% 191s", identHeaderRec, 
         pTmCurrTime->tm_year + 1900, pTmCurrTime->tm_mon + 1, pTmCurrTime->tm_mday, 
         pTmCurrTime->tm_hour, pTmCurrTime->tm_min, pTmCurrTime->tm_sec, 
         RS.FTI18DNCnt, "");

      BCH_WriteRec (RS.EPBF5305_out, RS.EPBF5305_buffer, recSize);

      for (recIndx = 0; recIndx < RS.FTI18DNCnt; recIndx++) {
         BCH_WriteRec (RS.EPBF5305_out, FTI18DN_recs + recSize * recIndx, recSize);
      }*/

      pszFilePath = (char*) getenv ("EPBF5305_out");
      // Make sure environment variable was set
      if (pszFilePath == NULL) {
         BCH_FormatMessage (1, "Environment variable for file %s wasn't set.", "EPBF5305_out");
         BCH_HandleMessage (BCH_ERR_ARCH, __FILE__, "TPM_9500_ProcessEndOfProgram");
      }

      // Make sure file path contains a value
      if (strlen (pszFilePath) == 0) {
         BCH_FormatMessage (1, "Environment variable %s was set to a null string.", "EPBF5305_out");
         BCH_HandleMessage (BCH_ERR_ARCH, __FILE__, "TPM_9500_ProcessEndOfProgram");
      }

      pFileOut = fopen (pszFilePath, "w");
      if(pFileOut == (FILE*) NULL) {
         BCH_FormatMessage (1, TXT_FILE_OPN_ERR);
         BCH_FormatMessage (2, TXT_OUT_FILE, pszFilePath);
         BCH_HandleMessage (BCH_ERR_ABORT, __FILE__, "TPM_9500_ProcessEndOfProgram");
      }

      // creating HeaderRec
      sprintf (RS.EPBF5305_buffer, "%2s%04d%02d%02d%02d%02d%02d%06d% 192s", identHeaderRec, // !!! 192 = 214 - 22
         pTmCurrTime->tm_year + 1900, pTmCurrTime->tm_mon + 1, pTmCurrTime->tm_mday, 
         pTmCurrTime->tm_hour, pTmCurrTime->tm_min, pTmCurrTime->tm_sec, 
         RS.FTI18DNCnt, "");

      RS.EPBF5305_buffer[recSize - 1] = '\0\n';
      fwrite (RS.EPBF5305_buffer, sizeof (char), recSize, pFileOut);

      // creating DetailRecs
      for (recIndx = 0; recIndx < RS.FTI18DNCnt; recIndx++) {
         fwrite (FTI18DN_recs + recSize * recIndx, sizeof (char), recSize, pFileOut);
      }
   
      fclose (pFileOut);
   }

   sprintf (sErrorMessage, "Read = %6d, Dropped = %5d, Processed = %5d, FTI18DN = %5d",
            RS.Read,
            RS.Dropped,
            RS.Processed,
            RS.FTI18DNCnt);

   BCH_FormatMessage (1, TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_FormatMessage (2, TXT_ERR_GENERIC_TXT, sErrorMessage);
   BCH_HandleMessage (BCH_ERR_WARNING, __FILE__, "TPM_9500_ProcessEndOfProgram");

   //BCH_Close (RS.EPBF5305_out);
} 


void TPM_3000_ProcessFileEPBF5305 () {
   int FTI18DNTypeCnt = sizeof (aFTI18DNPassengerTyp) / sizeof (aFTI18DNPassengerTyp[0]);
   int FTI18DNTypeCnt2 = sizeof (aFTI18DNPassengerTyp2) / sizeof (aFTI18DNPassengerTyp2[0]);
   int NrevSrcCdCnt = sizeof (aNrevSrcCd2) / sizeof (aNrevSrcCd2[0]);
   int recSize = sizeof (RS.EPBF5305_buffer);
   int bufferOffset = 0;
   int indxType, indxNrevSrcCd;
   int fToBePriced = 1;
   int prevFTI18DNCnt = RS.FTI18DNCnt;

   memcpy (RS.sETIdentifier, RS.EPBF5305_buffer, sizeof (RS.sETIdentifier));     bufferOffset += sizeof (RS.sETIdentifier);
   memcpy (RS.sTranDate, RS.EPBF5305_buffer + bufferOffset, sizeof (RS.sTranDate));    bufferOffset += sizeof (RS.sTranDate);
   memcpy (RS.sAirlineTktId, RS.EPBF5305_buffer + bufferOffset, sizeof (RS.sAirlineTktId));     bufferOffset += sizeof (RS.sAirlineTktId);
   memcpy (RS.sTktSerialNum1st3, RS.EPBF5305_buffer + bufferOffset, sizeof (RS.sTktSerialNum1st3));      bufferOffset += sizeof (RS.sTktSerialNum1st3);
   memcpy (RS.sTktSerialNumLst7, RS.EPBF5305_buffer + bufferOffset, sizeof (RS.sTktSerialNumLst7));      bufferOffset += sizeof (RS.sTktSerialNumLst7);
   memcpy (RS.sTktCpnNum, RS.EPBF5305_buffer + bufferOffset, sizeof (RS.sTktCpnNum));     bufferOffset += sizeof (RS.sTktCpnNum);
   memcpy (RS.sPassengerTyp, RS.EPBF5305_buffer + bufferOffset, sizeof (RS.sPassengerTyp));     bufferOffset += sizeof (RS.sPassengerTyp);

   if (memcmp (RS.sETIdentifier, identDetailRec, sizeof (identDetailRec)) == 0) {
      for (indxType = 0; indxType < FTI18DNTypeCnt; indxType++) {
         if (memcmp (RS.sPassengerTyp, aFTI18DNPassengerTyp[indxType], sizeof (RS.sPassengerTyp)) == 0) {

            RS.FTI18DNCnt++;
            RS.EPBF5305_buffer[recSize - 1] = '\0\n';

            FTI18DN_recs = (char*) realloc (FTI18DN_recs, recSize * RS.FTI18DNCnt);

            memcpy (FTI18DN_recs + recSize * (RS.FTI18DNCnt - 1), RS.EPBF5305_buffer, recSize);
         }
      }

      for (indxType = 0; prevFTI18DNCnt == RS.FTI18DNCnt && indxType < FTI18DNTypeCnt2; indxType++) {
         if (memcmp (RS.sPassengerTyp, aFTI18DNPassengerTyp2[indxType], sizeof (RS.sPassengerTyp)) == 0) {

            memcpy (R04724.R04724_appl_area.sNrevTypCd, aFTI18DNPassengerTyp2[indxType], sizeof (RS.sPassengerTyp));

            bufferOffset += sizeof (RS.sSegmentTvlCde);
            memcpy (R04724.R04724_appl_area.sNrevLstNm, RS.EPBF5305_buffer + bufferOffset, sizeof (RS.sPasgrLastName));     bufferOffset += sizeof (RS.sPasgrLastName);
            memcpy (R04724.R04724_appl_area.sNrevFrstNm, RS.EPBF5305_buffer + bufferOffset, sizeof (RS.sPasgrFirstName));     bufferOffset += sizeof (RS.sPasgrFirstName);
            
            bufferOffset += 26;
            memcpy (R04724.R04724_appl_area.sNwEmplNb, RS.EPBF5305_buffer + bufferOffset, sizeof (RS.sEmpNum));     bufferOffset += sizeof (RS.sEmpNum);
            memset (&A04724,LOW_VALUES, sizeof(A04724));

            nSvcRtnCd = BCH_InvokeService (EPBINQ0, &R04724, &A04724, SERVICE_ID_04724, 1, sizeof (R04724.R04724_appl_area));

            switch (nSvcRtnCd) {
               case ARC_SUCCESS:
                  for (indxNrevSrcCd = 0; indxNrevSrcCd < NrevSrcCdCnt; indxNrevSrcCd++) {
                     if (memcmp (A04724.A04724_appl_area.sNrevSrcCd, aNrevSrcCd2[indxNrevSrcCd], sizeof (A04724.A04724_appl_area.sNrevSrcCd)) == 0) {
                        fToBePriced = 0;
                     }
                  }
                  break;

               case ARC_ROW_NOT_FOUND:
                  sprintf (sErrorMessage, "Invalid NW employee number: %s\n", RS.sEmpNum);
                  BCH_FormatMessage (1, sErrorMessage);
                  BCH_HandleMessage (BCH_ERR_ARCH, __FILE__, "TPM_3000_ProcessFileEPBF5305");

                  fToBePriced = 0;
                  break;
   
               default:
                  BCH_FormatMessage (1, TXT_SVC_UNSUCC);
                  BCH_FormatMessage (2, TXT_SVC, "FYS04724");
                  
                  sprintf (sErrorMessage, "Ppr = %s, Nrev = %s",
                     R04724.R04724_appl_area.sNwEmplNb,
                     R04724.R04724_appl_area.sNrevTypCd,
                     R04724.R04724_appl_area.sNrevFrstNm,
                     R04724.R04724_appl_area.sNrevLstNm
                  );
                  
                  BCH_FormatMessage (3, TXT_ERR_GENERIC_TXT, sErrorMessage);
                  BCH_HandleMessage (BCH_ERR_ABORT, __FILE__, "TPM_3000_ProcessFileEPBF5305");

                  fToBePriced = 0;
                  break;
            }

            if (fToBePriced) {
               RS.FTI18DNCnt++;
               RS.EPBF5305_buffer[recSize - 1] = '\0\n';

               FTI18DN_recs = (char*) realloc (FTI18DN_recs, recSize * RS.FTI18DNCnt);

               memcpy (FTI18DN_recs + recSize * (RS.FTI18DNCnt - 1), RS.EPBF5305_buffer, recSize);
            }
         }
      }

      RS.Processed++;
   } else {
      RS.Dropped++;
   }

   BCH_ReadRec (RS.EPBF5305, RS.EPBF5305_buffer, recSize);
}
