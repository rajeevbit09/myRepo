/****************************************************************************
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         **
** Sub-System :     Pass Accounting                                        **
**                                                                         **
** Program Name:    EPB71402.c                                             **
**                                                                         **
** Shell Used:      <shldpmc.c>                                            **
**                                                                         **
** Program Type:    Database Driven Process Module                         **
**                                                                         **
** Author :         Lorenzo Scott                                          **
**                                                                         **
** Date Written:    May 08, 1998                                           **
**                                                                         **
** Description:     This module extracts imputed flight leg information for**
**                  German non-revenue passengers whose records have not   **
**                  been processed and then formats records for the        **
**                  German Employee NonRevenue Travel Report.  The         **
**                  matched indicator on the Imputed Trip and Imputed      **
**                  Flight Legs tables is updated to 'P' (processed        **
**                  status) for these records.                             **  
**                                                                         **
** Revision Trail:                                                         **
**                                                                         **
** Date       Revised by         SIR #    Description                      **
** ----       ----------         -----    -----------                      **
**                                                                         **
** 5/26/98    SKM (Dev)                   Corrected the report sort order  **
**                                        problem.                         **
**                                                                         **
****************************************************************************/
#include "epb71402.h"

main()
{
   BCH_Init("EPB71402", NUMBER_OF_THREADS);
   DPM_1000_Initialize();
   DPM_2000_Mainline();
}

/******************************************************************
**                                                               **
** Function Name:   DPM_1000_Initialize                          **
**                                                               **
** Description:     Initializes variables, performs RSAM_start,  **
**                  opens all input and output files, and        **
**                  makes priming read.                          **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_1000_Initialize()
{
   short   nRptIndex,                 /* Report index */
           nReqRptInd1 = FALSE;       /* Required report #1 indicator */

   char   *pEffDt;                    /* Pointer to reporting end date */


   /**** Initialize RSAM Save fields with space ****/
   strcpy(RS.sPprNbr, "         ");
   strcpy(RS.sNrevNbr, "  ");
   /**** Assign report ending date to variables ****/
   pEffDt = (char *) getenv("DATE1");
   strcpy(RS.sEffDt, pEffDt);

   /**** Initialize record counters ****/
   RS.EPB71413_record_cntr = 0;
 
   /**** Initialize architecture area of service answer and request blocks ****/
   memset(&A04589, LOW_VALUES, sizeof(_A04589));
   memset(&R04589, LOW_VALUES, sizeof(_R04589)); 
   memset(&A04590, LOW_VALUES, sizeof(_A04590));
   memset(&R04590, LOW_VALUES, sizeof(_R04590)); 
   memset(&A04591, LOW_VALUES, sizeof(_A04591));
   memset(&R04591, LOW_VALUES, sizeof(_R04591)); 
   memset(&A04592, LOW_VALUES, sizeof(_A04592));
   memset(&R04592, LOW_VALUES, sizeof(_R04592)); 

   /**** Log program start ****/
   BCH_FormatMessage(1,TXT_PROG_STRT);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_1000_Initialize");
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2000_Mainline                            **
**                                                               **
** Description:     Mainline Processing.                         **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2000_Mainline()
{
   short     nSvcRtnCd;      /* Service return code */

   /****** Initialize request and answer blocks *****/
   memset(&R04591.R04591_appl_area, LOW_VALUES, sizeof(_R04591_APPL_AREA));
   memset(&A04591.A04591_appl_area, LOW_VALUES, sizeof(_A04591_APPL_AREA));

   /****** Format R04591 keys for initial DB Read *****/
   strcpy(R04591.R04591_appl_area.sPprNbr, RS.sPprNbr);
   strcpy(R04591.R04591_appl_area.sNrevNbr, RS.sNrevNbr);

   /**** Open the DB cursor ****/
   R04591.R04591_appl_area.cArchCursorOpTxt = OPEN_AND_FETCH;

   /****** Execute service to retrieve Imputed Flight Leg records for all German employees
           having Matched Indicator of 'N' (notified) or 'C' (corrected) ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04591,&A04591,SERVICE_ID_04591,1,sizeof(_R04591_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;

      case ARC_ROW_NOT_FOUND: 
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2000_Mainline");
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS4591");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
   }  

   /**** Process driving database rows ****/
   while (nSvcRtnCd != ARC_ROW_NOT_FOUND)
   {
      DPM_2500_ProcessRows();

      memset(&A04591, LOW_VALUES, sizeof(_A04591));
      R04591.R04591_appl_area.cArchCursorOpTxt = FETCH_ROW;

      /**** Execute service to obtain next DB row ****/
      nSvcRtnCd = BCH_InvokeService(EPBINQ0,&R04591,&A04591,SERVICE_ID_04591,1,sizeof(_R04591_APPL_AREA));

      /**** Service return code processing ****/
      switch (nSvcRtnCd)
      {
         case ARC_SUCCESS:
            break;

         case ARC_ROW_NOT_FOUND:
            break;

         default:
            BCH_FormatMessage(1,TXT_SVC_UNSUCC);
            BCH_FormatMessage(2,TXT_SVC, "FYS4591");
            BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2000_Mainline");
       }  
   }

   /**** Control report is not generated ****/
   DPM_2600_UpdateMatchInd();

   /**** Exit program ****/   
   DPM_9500_ProcessEndOfProgram();
   BCH_Terminate();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2500_ProcessRows                         **
**                                                               **
** Description:     Process input until end of rows              **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2500_ProcessRows()
{
   /****** Initialize request and answer Blocks *****/
   memset(&R04589.R04589_appl_area, LOW_VALUES, sizeof(_R04589_APPL_AREA));
   memset(&A04589.A04589_appl_area, LOW_VALUES, sizeof(_A04589_APPL_AREA));

   /****** Format request block *****/
   strcpy(R04589.R04589_appl_area.sPprNbr, A04591.A04591_appl_area.sPprNbr);
   strcpy(R04589.R04589_appl_area.sNrevNbr, A04591.A04591_appl_area.sNrevNbr);
   strcpy(R04589.R04589_appl_area.sFltNbr, A04591.A04591_appl_area.sFltNbr);
   strcpy(R04589.R04589_appl_area.sFltDprtDt, A04591.A04591_appl_area.sFltDprtDt);
   strcpy(R04589.R04589_appl_area.sFltOrigCtyId, A04591.A04591_appl_area.sFltOrigCtyId);
   strcpy(R04589.R04589_appl_area.sFltDestCtyId, A04591.A04591_appl_area.sFltDestCtyId);

   /****** Initialize request and answer Blocks *****/
   memset(&R04590.R04590_appl_area, LOW_VALUES, sizeof(_R04590_APPL_AREA));
   memset(&A04590.A04590_appl_area, LOW_VALUES, sizeof(_A04590_APPL_AREA));

   /****** Format request block *****/
   strcpy(R04590.R04590_appl_area.sPprNbr, A04591.A04591_appl_area.sPprNbr); 
   strcpy(R04590.R04590_appl_area.sNrevNbr, A04591.A04591_appl_area.sNrevNbr);
   strcpy(R04590.R04590_appl_area.sFltNbr, A04591.A04591_appl_area.sFltNbr);
   strcpy(R04590.R04590_appl_area.sFltDprtDt, A04591.A04591_appl_area.sFltDprtDt);
   strcpy(R04590.R04590_appl_area.sFltOrigCtyId, A04591.A04591_appl_area.sFltOrigCtyId);
   strcpy(R04590.R04590_appl_area.sFltDestCtyId, A04591.A04591_appl_area.sFltDestCtyId);

   /****** Execute service to retrieve total fares from Charges table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04590,&A04590,SERVICE_ID_04590,1,sizeof(_R04590_APPL_AREA));

   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         /**** currency ****/
         fDemFareAmt = (float)A04590.A04590_appl_area.dCostChrgAmt;
         break;

      case ARC_ROW_NOT_FOUND: 
         fDemFareAmt = 0;
         break;

      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04590");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
   }  
 

   /****** Execute service to retrieve total service charges from Charges table ****/
   nSvcRtnCd = BCH_InvokeService(EPBINQ1,&R04589,&A04589,SERVICE_ID_04589,1,sizeof(_R04589_APPL_AREA));
 
   /****** Service Return Code Processing  ****/
   switch (nSvcRtnCd)
   {  
      case ARC_SUCCESS:
         fDemNrevPmtAmt = (float)A04589.A04589_appl_area.dCostChrgAmt;
         break;
 
      case ARC_ROW_NOT_FOUND:
         BCH_FormatMessage(1,TXT_NO_ROWS_RTN);
         BCH_HandleMessage(BCH_ERR_WARNING, __FILE__, "DPM_2500_ProcessRows");
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04589");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2500_ProcessRows");
   }  

   /*** A report extract record is not generated. ***/
   /*** To generate a report extract record, perform the function                ***/
   /*** at the appropriate place in the program!                                 ***/

   DPM_5010_GenerateEPB71413();                                          
}

/******************************************************************
**                                                               **
** Function Name:   DPM_2600_UpdateMatchInd                      **
**                                                               **
** Description:     Update Match Indicator to 'P' for processed  **
**                  status on the Imputed Flight Leg Table.      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_2600_UpdateMatchInd()
{
   memset(&R04592, LOW_VALUES, sizeof(_R04592));
   memset(&A04592, LOW_VALUES, sizeof(_A04592));

   /**** Format Request block with specifics ****/

   /**** Execute service to update match indicator to 'P' for processed status on the Imputed Flight Leg table ****/
   nSvcRtnCd = BCH_InvokeService(EPBUPD0,&R04592,&A04592,SERVICE_ID_04592,1,sizeof(_R04592));
 
   /**** Service return code processing ****/
   switch (nSvcRtnCd)
   {
      case ARC_SUCCESS:
         break;
 
      default:
         BCH_FormatMessage(1,TXT_SVC_UNSUCC);
         BCH_FormatMessage(2,TXT_SVC, "FYS04592");
         BCH_HandleMessage(BCH_ERR_ABORT, __FILE__, "DPM_2600_UpdateMatchInd");
   }
}
 
/******************************************************************
**                                                               **
** Function Name:   DPM_5010_GenerateEPB71413                    **
**                                                               **
** Description:     Write report records for Imputed Wage        **
**                  Payroll Detail Report.                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_5010_GenerateEPB71413()
{
   short     nRptIndex;                 /* Report control table index */
  
   /**** Initialize report sort and data copybooks ****/
   memset(&EPRF7143.F7143_RptDataStruct, LOW_VALUES, sizeof(_F7143_RPTDATASTRUCT));
   memset(&EPRS7143.S7143_RptDataStruct, LOW_VALUES, sizeof(_S7143_RPTDATASTRUCT));

   /**** Format report fields in sort and data layouts ****/
   strcpy(EPRF7143.F7143_RptDataStruct.sPprNbr, A04591.A04591_appl_area.sPprNbr);
   strcpy(EPRF7143.F7143_RptDataStruct.sNrevNbr, A04591.A04591_appl_area.sNrevNbr);
   strcpy(EPRF7143.F7143_RptDataStruct.sPprInttxNbr, A04591.A04591_appl_area.sPprInttxNbr);
   strcpy(EPRF7143.F7143_RptDataStruct.sNrevNm, A04591.A04591_appl_area.sNrevNm);
   strcpy(EPRF7143.F7143_RptDataStruct.sFltDprtDt, UTL_ConvertDate(A04591.A04591_appl_area.sFltDprtDt,CNV_DB_TO_DD_MMM_YYYY));
   strcpy(EPRF7143.F7143_RptDataStruct.sFltArrDt, UTL_ConvertDate(A04591.A04591_appl_area.sFltArrDt,CNV_DB_TO_DD_MMM_YYYY));
   
   //EPRF7143.F7143_RptDataStruct.nFltDprtTm, A04591.A04591_appl_area.nFltDprtTm;

   /*** Shridev Makim (5/29/98): If flight number is '*****' print ticket ***/
   /*** number instead. Note: Variable Ticket number is used for ticket   ***/
   /*** number and flight number as well.                                 ***/
   if (strncmp(A04591.A04591_appl_area.sFltNbr, "*****", 5) != 0)
        strcpy(EPRF7143.F7143_RptDataStruct.sTktNbr, A04591.A04591_appl_area.sFltNbr);
   else
        strcpy(EPRF7143.F7143_RptDataStruct.sTktNbr, A04591.A04591_appl_area.sTktNbr);
   strcpy(EPRF7143.F7143_RptDataStruct.sFltOrigCtyId, A04591.A04591_appl_area.sFltOrigCtyId);
   strcpy(EPRF7143.F7143_RptDataStruct.sFltDestCtyId, A04591.A04591_appl_area.sFltDestCtyId);
   
   //EPRF7143.F7143_RptDataStruct.fNrevPmtAmt = fDemNrevPmtAmt - fDemFareAmt;
   sprintf(EPRF7143.F7143_RptDataStruct.sNrevPmtAmt, "% 11.2f", (fDemNrevPmtAmt - fDemFareAmt) );

   EPRF7143.F7143_RptDataStruct.cRecEndLineTxt = ENDLINE_CHAR;

   strcpy(EPRS7143.S7143_RptDataStruct.sPprNbr, A04591.A04591_appl_area.sPprNbr);
   strcpy(EPRS7143.S7143_RptDataStruct.sNrevNbr, A04591.A04591_appl_area.sNrevNbr);
   strcpy(EPRS7143.S7143_RptDataStruct.sFltArrDt,UTL_ConvertDate(A04591.A04591_appl_area.sFltArrDt,CNV_DB_TO_YYYYMMDD));
   
   //EPRS7143.S7143_RptDataStruct.nFltDprtTm, A04591.A04591_appl_area.nFltDprtTm;
   sprintf(EPRS7143.S7143_RptDataStruct.sFltDprtTm, "%d", A04591.A04591_appl_area.nFltDprtTm );

   /*** Shridev Makim (5/29/98): If flight number is '*****' print ticket ***/
   /*** number instead. Note: Variable Ticket number is used for ticket   ***/
   /*** number and flight number as well.                                 ***/
   if (strncmp(A04591.A04591_appl_area.sFltNbr, "*****", 5) != 0)
        strcpy(EPRS7143.S7143_RptDataStruct.sTktNbr, A04591.A04591_appl_area.sFltNbr);
   else
        strcpy(EPRS7143.S7143_RptDataStruct.sTktNbr, A04591.A04591_appl_area.sTktNbr);
   strcpy(EPRS7143.S7143_RptDataStruct.sFltOrigCtyId, A04591.A04591_appl_area.sFltOrigCtyId);

   BCH_WriteRptRec("EPB71413",&EPRS7143,sizeof(EPRS7143),&EPRF7143,sizeof(EPRF7143));  
   /**** Increment record counter ****/
   RS.EPB71413_record_cntr++;
}

/******************************************************************
**                                                               **
** Function Name:   DPM_9500_ProcessEndOfProgram                 **
**                                                               **
** Description:     Close files and end program                  **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
void DPM_9500_ProcessEndOfProgram()
{
   /**** Write control totals ****/
   BCH_FormatMessage(1,TXT_OUT_FILE, "EPB71413");
   BCH_FormatMessage(2,TXT_REC_TTL, RS.EPB71413_record_cntr);
   BCH_HandleMessage(BCH_ERR_INFORMATION, __FILE__, "DPM_9500_ProcessEndOfProgram");
}

