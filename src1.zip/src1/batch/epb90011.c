/**************************************************************************** 
**                      Delta Air Lines Inc.                               **
**                                                                         **
** System :         Finance Reengineering and Automation                   **
**                                                                         ** 
** Sub-System :     Pass Accounting                                        **
**                                                                         ** 
** Program Name:    EPB90011.c                                             **
**                                                                         **
** Shell Used:      <shlrfmc0.c>                                           **
**                                                                         **
** Program Type:    Batch Report Format Module with zero control breaks    **
**                                                                         **
** Author :         TransQuest Inc.                                        **
**                  Faith Ammons                                           **
**                                                                         **
** Date Written:    10/30/1996                                             **
**                                                                         **
** Description:     This program reads the sort record created by program  **
**                  EPB90001 and formats the "MONTHLY PASS USAGE SUMMARY"  **
**                  report.                                                **
**                                                                         **
** Revision Trail:                                                         ** 
**                                                                         ** 
** Date       Revised by         SIR #    Description                      ** 
** ----       ----------         -----    -----------                      ** 
**                                                                         ** 
****************************************************************************/ 
#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "epb90011.h"
#include "bchrfmcd.h"
#include "epbcmncd.h"

main()
{
   RFM_1000_InitializeFlds();
   while ((feof(stdin)) == 0)
      {
      RFM_3000_ProcessDetail();  
      }
   RFM_4000_ProcessEndOfJob();
   exit(0);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1000_InitializeFlds                      **
**                                                               **
** Description:     Initialize fields, read initial record,      **
**                  zero accumulators                            **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1000_InitializeFlds()
{
   char   sCurrentDate[13],      /* current date in mm/dd/yy format */
          sBegDt[11],
          sEndDt[11];
   char  *pBegDate,              /* pointers to reporting dates */
         *pEndDate;

   rfm_ReadNextRecord();
   
   cEndOfRpt = 'N';
   strcpy(sSavePassGrpDs, rpt_data.F9001_RptDataStruct.sPassGrpDs);
   strcpy(sSavePassTypDs, rpt_data.F9001_RptDataStruct.sPassTypDs);

   /* Initialize the totals for the pass groups */
   RFM_1300_Initialize_SubTotals();

   /* Initialize the Grand totals */
   lGrandTotFltDyCnt = 0;
   lGrandTotFltLegCnt = 0;
   lGrandTotSvcChgCnt = 0;
   dGrandTotSvcChgAmt = 0.00;
   dGrandTotPenaltyAmt = 0.00;
   dGrandTotIntlFeeAmt = 0.00;
   dGrandTotChgAmt = 0.00;

   /* Get system date and time */
   current = time((time_t *)0);
   strcpy(tu.t_str, ctime(&current));
   strftime(sCurrentDate,12,"%m/%d/%y",localtime(&current));

   tu.t_str[7] = tu.t_str[10]=tu.t_str[19]=tu.t_str[24]='\0';
 
   /* Assign report beginning and ending dates to variables */
   pBegDate = (char *) getenv("DATE1");
   pEndDate = (char *) getenv("DATE2");
   strcpy(sBegDt, UTL_ConvertDate(pBegDate,CNV_DB_TO_MM_DD_YY));
   strcpy(sEndDt, UTL_ConvertDate(pEndDate,CNV_DB_TO_MM_DD_YY));

   /* If report has an as of date, format the as of date here   */
   nCurrentLineCount = NEW_PAGE;
   memset(print_line,' ',PAGE_WIDTH);
   strcpy(sRequestId, input_area.rqst_id);

   /* Format and save standard headings */

   /* standard heading 1 */
   PRINT_SETUP(1,"CSR #:");
   PRINT_SETUP(11,"7905");
   PRINT_SETUP(56,STD_RPT_TITLE);
   PRINT_SETUP(115,"PAGE:");
   memcpy(std_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 2 */
   PRINT_SETUP(1,"REPORT:");
   PRINT_SETUP(11, "EPB90011");
   PRINT_SETUP(53, "MONTHLY PASS USAGE SUMMARY");
   PRINT_SETUP(115,"DATE:");
   PRINT_SETUP(123, sCurrentDate);
   memcpy(std_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* standard heading 3 */
   sprintf(sInputFld, "PERIOD %s TO %s", sBegDt, sEndDt);
   PRINT_SETUP(51, sInputFld);
   PRINT_SETUP(115,"TIME:");
   PRINT_SETUP(123,tu.ts.hh_mm_ss);
   memcpy(std_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 1 */
   PRINT_SETUP(62, "TOTAL NBR");
   memcpy(appl_heading_1,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);
 
   /* application heading 2 */
   PRINT_SETUP(33, "TOTAL FLIGHT");
   PRINT_SETUP(47, "TOTAL FLIGHT");
   PRINT_SETUP(62, "OF SERVICE");
   PRINT_SETUP(75, "TOTAL SERVICE");
   PRINT_SETUP(92, "TOTAL");
   PRINT_SETUP(101, "LANDING FEES/");
   PRINT_SETUP(121, "TOTAL");
   memcpy(appl_heading_2,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 3 */
   PRINT_SETUP(6, "PASS GROUP / PASS TYPE");
   PRINT_SETUP(34, "DAYS FLOWN");
   PRINT_SETUP(48, "LEGS FLOWN");
   PRINT_SETUP(63, "CHARGES");
   PRINT_SETUP(76, "CHARGE AMT");
   PRINT_SETUP(90, "PENALTIES");
   PRINT_SETUP(105, "TAXES");
   PRINT_SETUP(120, "CHARGES");
   memcpy(appl_heading_3,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /* application heading 4 */
   PRINT_SETUP(3, "____________________________");
   PRINT_SETUP(33, "____________");
   PRINT_SETUP(47, "____________");
   PRINT_SETUP(61, "____________");
   PRINT_SETUP(75, "_____________");
   PRINT_SETUP(90, "_________");
   PRINT_SETUP(101, "_____________");
   PRINT_SETUP(116, "_______________");
   memcpy(appl_heading_4,print_line,PAGE_WIDTH);
   memset(print_line,' ',PAGE_WIDTH);

   /*** Print first pass group line ***/
   RFM_3200_ProcessPassGroup();
}

/******************************************************************
**                                                               **
** Function Name:   RFM_1300_Initialize_SubTotals                **
**                                                               **
** Description:     Initialize the Pass Group Subtotal fields    **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_1300_Initialize_SubTotals()
{

   lSubTotFltDyCnt = 0;
   lSubTotFltLegCnt = 0;
   lSubTotSvcChgCnt = 0;
   dSubTotSvcChgAmt = 0.00;
   dSubTotPenaltyAmt = 0.00;
   dSubTotIntlFeeAmt = 0.00;
   dSubTotChgAmt = 0.00;

}

/******************************************************************
**                                                               **
** Function Name:   RFM_3000_ProcessDetail                       **
**                                                               **
** Description:     Process detail line, read next record and    **
**                  determine if there was a control break       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3000_ProcessDetail()
{
    RFM_3100_ProcessReportRecord();
    rfm_ReadNextRecord();
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3100_ProcessReportRecord                 **
**                                                               **
** Description:     Format detail line, add amounts to control   **
**                  totals.                                      **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3100_ProcessReportRecord()
{

   /*  if there is a new Pass Group, or end of data, print subtotals  ***/
      if (strcmp(rpt_data.F9001_RptDataStruct.sPassGrpDs, sSavePassGrpDs) != 0   ||
          cEndOfRpt == 'Y')
         {
         /*** Print subtotal line     ***/
         PRINT_SETUP(5, "SUB TOTAL");
         sprintf(sInputFld, "% 12ld", lSubTotFltDyCnt);
         PRINT_SETUP(33, sInputFld);
         sprintf(sInputFld, "% 12ld", lSubTotFltLegCnt);
         PRINT_SETUP(47, sInputFld);
         sprintf(sInputFld, "% 12ld", lSubTotSvcChgCnt);
         PRINT_SETUP(61, sInputFld);
         sprintf(sInputFld, "% 13.2f", dSubTotSvcChgAmt);
         PRINT_SETUP(75, sInputFld);
         sprintf(sInputFld, "% 9.2f", dSubTotPenaltyAmt);
         PRINT_SETUP(90, sInputFld);
         sprintf(sInputFld, "% 13.2f", dSubTotIntlFeeAmt);
         PRINT_SETUP(101, sInputFld);
         sprintf(sInputFld, "% 15.2f", dSubTotChgAmt);
         PRINT_SETUP(116, sInputFld);
         rfm_ControlPrint(SINGLE_SPACE, print_line);

         /*** Next, add sub totals to grand totals   ***/
         lGrandTotFltDyCnt += lSubTotFltDyCnt;
         lGrandTotFltLegCnt += lSubTotFltLegCnt;
         lGrandTotSvcChgCnt += lSubTotSvcChgCnt;
         dGrandTotSvcChgAmt += dSubTotSvcChgAmt;
         dGrandTotPenaltyAmt += dSubTotPenaltyAmt;
         dGrandTotIntlFeeAmt += dSubTotIntlFeeAmt;
         dGrandTotChgAmt += dSubTotChgAmt;

         if (cEndOfRpt == 'Y')
            return;

         /*** Initialize sub totals ***/
         RFM_1300_Initialize_SubTotals();

         /*** Save the pass grp description   ***/
         strcpy(sSavePassGrpDs, rpt_data.F9001_RptDataStruct.sPassGrpDs);

         /*** print new pass group line ***/
         RFM_3200_ProcessPassGroup();
         }
         /*** Print pass type detail  line     ***/
   PRINT_SETUP(6, rpt_data.F9001_RptDataStruct.sPassTypDs);
   //sprintf(sInputFld, "% 12ld", rpt_data.F9001_RptDataStruct.lFltDyCnt);
   //PRINT_SETUP(33, sInputFld);
   PRINT_SETUP(33, rpt_data.F9001_RptDataStruct.sFltDyCnt );
   
   //sprintf(sInputFld, "% 12ld", rpt_data.F9001_RptDataStruct.lFltLegCnt);
   //PRINT_SETUP(47, sInputFld);
   PRINT_SETUP(47, rpt_data.F9001_RptDataStruct.sFltLegCnt );
   
   //sprintf(sInputFld, "% 12ld", rpt_data.F9001_RptDataStruct.lSvcChgCnt);
   //PRINT_SETUP(61, sInputFld);
   PRINT_SETUP(61, rpt_data.F9001_RptDataStruct.sSvcChgCnt );
   
   //sprintf(sInputFld, "% 13.2f", rpt_data.F9001_RptDataStruct.dTotSvcChgAmt);
   //PRINT_SETUP(75, sInputFld);
   PRINT_SETUP(75, rpt_data.F9001_RptDataStruct.sTotSvcChgAmt);

   //sprintf(sInputFld, "% 9.2f", rpt_data.F9001_RptDataStruct.dTotPenaltyAmt);
   //PRINT_SETUP(90, sInputFld);
   PRINT_SETUP(90, rpt_data.F9001_RptDataStruct.sTotPenaltyAmt);

   //sprintf(sInputFld, "% 13.2f", rpt_data.F9001_RptDataStruct.dTotIntlFeeAmt);
   //PRINT_SETUP(101, sInputFld);
   PRINT_SETUP(101, rpt_data.F9001_RptDataStruct.sTotIntlFeeAmt);

   //sprintf(sInputFld, "% 15.2f", rpt_data.F9001_RptDataStruct.dTotChgAmt);
   //PRINT_SETUP(116, sInputFld);
   PRINT_SETUP(116, rpt_data.F9001_RptDataStruct.sTotChgAmt);

   rfm_ControlPrint(SINGLE_SPACE, print_line);

   /*** Finally, add input  pass type totals to sub totals   ***/
   lSubTotFltDyCnt += atof(rpt_data.F9001_RptDataStruct.sFltDyCnt);
   lSubTotFltLegCnt += atof(rpt_data.F9001_RptDataStruct.sFltLegCnt);
   lSubTotSvcChgCnt += atof(rpt_data.F9001_RptDataStruct.sSvcChgCnt);
   dSubTotSvcChgAmt += atof(rpt_data.F9001_RptDataStruct.sTotSvcChgAmt);
   dSubTotPenaltyAmt += atof(rpt_data.F9001_RptDataStruct.sTotPenaltyAmt);
   dSubTotIntlFeeAmt += atof(rpt_data.F9001_RptDataStruct.sTotIntlFeeAmt);
   dSubTotChgAmt += atof(rpt_data.F9001_RptDataStruct.sTotChgAmt);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_3200_ProcessPassGroup                    **
**                                                               **
** Description:     Print pass group description                 **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_3200_ProcessPassGroup()
{

  /* Start a new page if there is not enough room for new group line */
   if (nCurrentLineCount > (LINES_PER_PAGE - 4))
       nCurrentLineCount = NEW_PAGE;

   /*** Set up the pass group description line ***/
   PRINT_SETUP(3, rpt_data.F9001_RptDataStruct.sPassGrpDs);   

   /* Skip no lines if at beginning of page; otherwise skip two lines if not */
   if (nCurrentLineCount == 10)
      rfm_ControlPrint(SINGLE_SPACE, print_line);
   else
      rfm_ControlPrint(TRIPLE_SPACE, print_line);

}

/******************************************************************
**                                                               **
** Function Name:   RFM_4000_ProcessEndOfJob                     **
**                                                               **
** Description:     Format grand total line, print end of report **
**                  line, close input file                       **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/

void RFM_4000_ProcessEndOfJob()
{
   /* Set end of report indicator to yes */
   cEndOfRpt = 'Y';

   /*** Print remaining pass type totals and subtotals ***/
   RFM_3100_ProcessReportRecord();

   /* Format grand total lines */
   PRINT_SETUP(33, "____________");
   PRINT_SETUP(47, "____________");
   PRINT_SETUP(61, "____________");
   PRINT_SETUP(75, "_____________");
   PRINT_SETUP(90, "_________");
   PRINT_SETUP(101, "_____________");
   PRINT_SETUP(116, "_______________");
   rfm_ControlPrint(DOUBLE_SPACE, print_line);

   PRINT_SETUP(3,"GRAND TOTAL");
   sprintf(sInputFld, "% 12ld", lGrandTotFltDyCnt);
   PRINT_SETUP(33,sInputFld);
   sprintf(sInputFld, "% 12ld", lGrandTotFltLegCnt);
   PRINT_SETUP(47,sInputFld);
   sprintf(sInputFld, "% 12ld", lGrandTotSvcChgCnt);
   PRINT_SETUP(61,sInputFld);
   sprintf(sInputFld, "$% 12.2f", dGrandTotSvcChgAmt);
   PRINT_SETUP(75,sInputFld);
   sprintf(sInputFld, "$% 8.2f", dGrandTotPenaltyAmt);
   PRINT_SETUP(90,sInputFld);
   sprintf(sInputFld, "$% 12.2f", dGrandTotIntlFeeAmt);
   PRINT_SETUP(101,sInputFld);
   sprintf(sInputFld, "$% 14.2f", dGrandTotChgAmt);
   PRINT_SETUP(116,sInputFld);
   rfm_ControlPrint(SINGLE_SPACE, print_line);

   PRINT_SETUP(33, "____________");
   PRINT_SETUP(47, "____________");
   PRINT_SETUP(61, "____________");
   PRINT_SETUP(75, "_____________");
   PRINT_SETUP(90, "_________");
   PRINT_SETUP(101, "_____________");
   PRINT_SETUP(116, "_______________");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   rfm_ControlPrint(DOUBLE_SPACE, print_line);

  /* Start a new page if there is not enough room for new group line */
   if (nCurrentLineCount > (LINES_PER_PAGE - 4))
       nCurrentLineCount = NEW_PAGE;

   /* Format footnote */
   PRINT_SETUP(9,"** Service charges include domestic and transoceanic service");
   PRINT_SETUP(70,"charges, flat fees, handling fees, and upgrade/premium charges.");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
   PRINT_SETUP(12,"Penalties include honor roll transoceanic penalties and flight");
   PRINT_SETUP(75,"abuse penalties for emergency, priority, honor roll,");
   rfm_ControlPrint(SINGLE_SPACE, print_line);
   PRINT_SETUP(12,"transoceanic, and domestic pass abuse.");
   rfm_ControlPrint(SINGLE_SPACE, print_line);

   /* Format end of report line */
   PRINT_SETUP(3, "END OF REPORT");
   rfm_ControlPrint(TRIPLE_SPACE, print_line);
}

/******************************************************************
**                                                               **
** Function Name:   RFM_5000_PageHeadings                        **
**                                                               **
** Description:     Format and print heading line                **
**                                                               **
** Arguments:       None                                         **
**                                                               **
** Return Values:   None                                         **
**                                                               **
**                                                               **
******************************************************************/
 
void RFM_5000_PageHeadings()
{
   char sNbrOfReportPages[4];  /* Number of report pages written */
 
   nRptPagesWritten++;
 
   /* Format first heading line */
   memcpy(print_line,std_heading_1,PAGE_WIDTH);
   sprintf(sNbrOfReportPages,"%3i",nRptPagesWritten);
   PRINT_SETUP(128,sNbrOfReportPages);
   rfm_PrintLine(NEW_PAGE,print_line);
 
   /* Format second heading line */
   memcpy(print_line,std_heading_2,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE,print_line);
 
   /* Format third heading line */
   memcpy(print_line,std_heading_3,PAGE_WIDTH);
   rfm_PrintLine(SINGLE_SPACE, print_line);
   rfm_PrintLine(DOUBLE_SPACE, print_line);
 
   /* Print application headings if end of report indicator is no */
   if (cEndOfRpt == 'N')
      {
      /* Format application headings */
      memcpy(print_line,appl_heading_1,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_2,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_3,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);

      memcpy(print_line,appl_heading_4,PAGE_WIDTH);
      rfm_PrintLine(SINGLE_SPACE, print_line);
 
      /* Use the next line if you want a blank line between the last */
      /* application heading line and the first detail line          */
      rfm_PrintLine(SINGLE_SPACE, print_line);
      }
}
