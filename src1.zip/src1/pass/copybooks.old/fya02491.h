/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02491                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/16/95                                                */
/*              Time: 10:42:19                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02491                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02491_APPL_AREA_z                                                     
#define _A02491_APPL_AREA_z                                                     
typedef struct __A02491_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02491_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02491_z                                                               
#define _A02491_z                                                               
                                                                                
   typedef struct __A02491                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02491_APPL_AREA A02491_appl_area;                                       
   }  _A02491;                                                                  
#endif                                                                          
                                                                                



#ifndef FYA02491_FMT
#define FYA02491_FMT     "k88s27"
#endif
