/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02652                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 01/24/96                                                */
/*              Time: 10:04:44                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02652                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY003582_LEN                                                          
#define   FY003582_LEN                         27                               
#endif                                                                          
#ifndef   FY002495_LEN                                                          
#define   FY002495_LEN                         3                                
#endif                                                                          
#ifndef   FY002556_LEN                                                          
#define   FY002556_LEN                         1                                
#endif                                                                          
#ifndef   FY002492_LEN                                                          
#define   FY002492_LEN                         1                                
#endif                                                                          
#ifndef   FY002535_LEN                                                          
#define   FY002535_LEN                         3                                
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef _A02652_APPL_AREA_z                                                     
#define _A02652_APPL_AREA_z                                                     
typedef struct __A02652_appl_area                                               
{                                                                               
   char                sNrevBdayDt[FY003582_LEN];                               
   char                sNrevTypCd[FY002495_LEN];                                
   char                cNrevDyMiInd;                                            
   char                cPassImptInd;                                            
   char                sPassStsCd[FY002535_LEN];                                
   char                sPassGrpCd[FY002488_LEN];                                
   short               nFltMoSvcNbr;                                            
   char                sPprStnId[FY002711_LEN];                                 
   short               nPassAnsRowsNbr;                                         
}  _A02652_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02652_z                                                               
#define _A02652_z                                                               
                                                                                
   typedef struct __A02652                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02652_APPL_AREA A02652_appl_area;                                       
   }  _A02652;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02652_FMT
#define FYA02652_FMT     "k88s27s3ccs3s3nw4s6nw3"
#endif
