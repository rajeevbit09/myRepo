/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02665                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/31/98                                                */
/*              Time: 09:44:36                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02665                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef   FY002868_LEN                                                          
#define   FY002868_LEN                         27                               
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002636_LEN                                                          
#define   FY002636_LEN                         16                               
#endif                                                                          
#ifndef   FY002635_LEN                                                          
#define   FY002635_LEN                         3                                
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002495_LEN                                                          
#define   FY002495_LEN                         3                                
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002831_LEN                                                          
#define   FY002831_LEN                         3                                
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef _A02665_APPL_AREA_z                                                     
#define _A02665_APPL_AREA_z                                                     
typedef struct __A02665_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltDprtDt[FY003584_LEN];                                
   char                sPassRptSortDt[FY003821_LEN];                            
   char                sPassDtTmTs[FY002868_LEN];                               
   char                sFltOrigCtyId[FY002521_LEN];                             
   char                sFltDestCtyId[FY002522_LEN];                             
   char                sSvcChrgDs[FY002636_LEN];                                
   char                sSvcChrgCd[FY002635_LEN];                                
   double              dCostChrgAmt;                                            
   char                sFltNbr[FY002553_LEN];                                   
   char                sNrevTypCd[FY002495_LEN];                                
   char                sNrevNm[FY002531_LEN];                                   
   char                sNrevSrcCd[FY002831_LEN];                                
   char                sPassGrpCd[FY002488_LEN];                                
}  _A02665_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02665_z                                                               
#define _A02665_z                                                               
                                                                                
   typedef struct __A02665                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02665_APPL_AREA A02665_appl_area;                                       
   }  _A02665;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02665_FMT
#define FYA02665_FMT     "k88s10s3s27s27s27s6s6s16s3dw7.2s6s3s31s3s3"
#endif
