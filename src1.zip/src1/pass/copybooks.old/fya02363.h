/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02363                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 02/26/97                                                */
/*              Time: 11:38:10                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02363                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002495_LEN                                                          
#define   FY002495_LEN                         3                                
#endif                                                                          
#ifndef   FY002535_LEN                                                          
#define   FY002535_LEN                         3                                
#endif                                                                          
#ifndef   FY003582_LEN                                                          
#define   FY003582_LEN                         27                               
#endif                                                                          
#ifndef   FY002531_LEN                                                          
#define   FY002531_LEN                         31                               
#endif                                                                          
#ifndef   FY002532_LEN                                                          
#define   FY002532_LEN                         16                               
#endif                                                                          
#ifndef   FY002533_LEN                                                          
#define   FY002533_LEN                         15                               
#endif                                                                          
#ifndef   FY002832_LEN                                                          
#define   FY002832_LEN                         1                                
#endif                                                                          
#ifndef   FY002556_LEN                                                          
#define   FY002556_LEN                         1                                
#endif                                                                          
#ifndef   FY002534_LEN                                                          
#define   FY002534_LEN                         1                                
#endif                                                                          
#ifndef   FY002831_LEN                                                          
#define   FY002831_LEN                         3                                
#endif                                                                          
#ifndef   FY002779_LEN                                                          
#define   FY002779_LEN                         10                               
#endif                                                                          
#ifndef   FY002481_LEN                                                          
#define   FY002481_LEN                         16                               
#endif                                                                          
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef   FY002704_LEN                                                          
#define   FY002704_LEN                         6                                
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY003592_LEN                                                          
#define   FY003592_LEN                         27                               
#endif                                                                          
#ifndef   FY002794_LEN                                                          
#define   FY002794_LEN                         9                                
#endif                                                                          
#ifndef   FY002475_LEN                                                          
#define   FY002475_LEN                         25                               
#endif                                                                          
#ifndef   FY002476_LEN                                                          
#define   FY002476_LEN                         25                               
#endif                                                                          
#ifndef   FY002477_LEN                                                          
#define   FY002477_LEN                         25                               
#endif                                                                          
#ifndef   FY002482_LEN                                                          
#define   FY002482_LEN                         3                                
#endif                                                                          
#ifndef   FY002518_LEN                                                          
#define   FY002518_LEN                         10                               
#endif                                                                          
#ifndef   FY002478_LEN                                                          
#define   FY002478_LEN                         4                                
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY003744_LEN                                                          
#define   FY003744_LEN                         4                                
#endif                                                                          
#ifndef   FY003745_LEN                                                          
#define   FY003745_LEN                         3                                
#endif                                                                          
#ifndef   FY003590_LEN                                                          
#define   FY003590_LEN                         27                               
#endif                                                                          
#ifndef   _A02363_APPL_AREA__PSGRINFO_SIZE                                      
#define   _A02363_APPL_AREA__PSGRINFO_SIZE     50                               
#endif                                                                          
#ifndef   _A02363_APPL_AREA__REMNALLOT_SIZE                                     
#define   _A02363_APPL_AREA__REMNALLOT_SIZE    200                              
#endif                                                                          
#ifndef _MISC_INFO_z                                                            
#define _MISC_INFO_z                                                            
typedef struct __Misc_info                                                      
{                                                                               
   short               nPassAnsRowsNbr;                                         
}  _MISC_INFO;                                                                  
#endif                                                                          
#ifndef _REMNALLOT_z                                                            
#define _REMNALLOT_z                                                            
typedef struct __RemnAllot                                                      
{                                                                               
   char                sPassTypCd[FY002496_LEN];                                
   short               nNrevRemnDyQty;                                          
   long                lNrevRemnMiQty;                                          
}  _REMNALLOT;                                                                  
#endif                                                                          
#ifndef _PSGRINFO_z                                                             
#define _PSGRINFO_z                                                             
typedef struct __PsgrInfo                                                       
{                                                                               
   char                sNrevNbr[FY002516_LEN];                                  
   char                sNrevTypCd[FY002495_LEN];                                
   char                sPassStsCd[FY002535_LEN];                                
   char                sNrevBdayDt[FY003582_LEN];                               
   char                sNrevNm[FY002531_LEN];                                   
   char                sNrevLstNm[FY002532_LEN];                                
   char                sNrevFrstNm[FY002533_LEN];                               
   char                cNrevDyMiNxtInd;                                         
   char                cNrevDyMiInd;                                            
   char                cNrevMidNm;                                              
   char                sNrevSrcCd[FY002831_LEN];                                
}  _PSGRINFO;                                                                   
#endif                                                                          
#ifndef _PPRINFO_z                                                              
#define _PPRINFO_z                                                              
typedef struct __PprInfo                                                        
{                                                                               
   char                sPprSocSecNbr[FY002779_LEN];                             
   char                sPprPhNbr[FY002481_LEN];                                 
   char                sPprStnId[FY002711_LEN];                                 
   char                sPprDeptNbr[FY002704_LEN];                               
   char                sPassGrpCd[FY002488_LEN];                                
   char                sPprStrtDt[FY003592_LEN];                                
   short               nFltMoSvcNbr;                                            
   char                sPprInttxNbr[FY002794_LEN];                              
   char                sPpr1Addr[FY002475_LEN];                                 
   char                sPpr2Addr[FY002476_LEN];                                 
   char                sPprCtyAddr[FY002477_LEN];                               
   char                sPprStCd[FY002482_LEN];                                  
   char                sPprZipAddr[FY002518_LEN];                               
   char                sPprCtryCd[FY002478_LEN];                                
   char                sPprNm[FY002480_LEN];                                    
   char                sCtryCtznpCd[FY003744_LEN];                              
   char                sPprRsdncyStsCd[FY003745_LEN];                           
   char                sPprRvkDt[FY003590_LEN];                                 
}  _PPRINFO;                                                                    
#endif                                                                          
#ifndef _A02363_APPL_AREA_z                                                     
#define _A02363_APPL_AREA_z                                                     
typedef struct __A02363_appl_area                                               
{                                                                               
   _PPRINFO PprInfo;                                                            
   _PSGRINFO PsgrInfo[_A02363_APPL_AREA__PSGRINFO_SIZE];                        
   _REMNALLOT RemnAllot[_A02363_APPL_AREA__REMNALLOT_SIZE];                     
   _MISC_INFO misc_info;                                                        
}  _A02363_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02363_z                                                               
#define _A02363_z                                                               
                                                                                
   typedef struct __A02363                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02363_APPL_AREA A02363_appl_area;                                       
   }  _A02363;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02363_FMT
#define FYA02363_FMT     "k88r18/1s10s16s6s6s3s27nw4s9s25s25s25s3s10s4s31s4s"\
                         "3s27r11/50s3s3s3s27s31s16s15cccs3r3/200s3nw3lw7r1/"\
                         "1nw3"
#endif
