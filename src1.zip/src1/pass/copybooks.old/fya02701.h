/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02701                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/28/96                                                */
/*              Time: 13:13:05                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02701                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02701__A02701_APPL_AREA_SIZE                                        
#define   _A02701__A02701_APPL_AREA_SIZE       100                              
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002489_LEN                                                          
#define   FY002489_LEN                         26                               
#endif                                                                          
#ifndef   FY002641_LEN                                                          
#define   FY002641_LEN                         10                               
#endif                                                                          
#ifndef   FY002492_LEN                                                          
#define   FY002492_LEN                         1                                
#endif                                                                          
#ifndef   FY003113_LEN                                                          
#define   FY003113_LEN                         1                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02701_APPL_AREA_z                                                     
#define _A02701_APPL_AREA_z                                                     
typedef struct __A02701_appl_area                                               
{                                                                               
   char                sPassGrpCd[FY002488_LEN];                                
   char                sPassGrpDs[FY002489_LEN];                                
   char                sFltFeeAcctNbr[FY002641_LEN];                            
   char                cPassImptInd;                                            
   char                cPassManlInd;                                            
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02701_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02701_z                                                               
#define _A02701_z                                                               
                                                                                
   typedef struct __A02701                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02701_APPL_AREA A02701_appl_area[_A02701__A02701_APPL_AREA_SIZE];       
   }  _A02701;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02701_FMT
#define FYA02701_FMT     "k88r6/100s3s26s10ccs27"
#endif
