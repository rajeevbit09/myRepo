/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02499                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/11/95                                                */
/*              Time: 15:43:02                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02499                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002838_LEN                                                          
#define   FY002838_LEN                         6                                
#endif                                                                          
#ifndef   FY002839_LEN                                                          
#define   FY002839_LEN                         6                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY003581_LEN                                                          
#define   FY003581_LEN                         27                               
#endif                                                                          
#ifndef   FY003580_LEN                                                          
#define   FY003580_LEN                         27                               
#endif                                                                          
#ifndef   FY003587_LEN                                                          
#define   FY003587_LEN                         27                               
#endif                                                                          
#ifndef   FY002631_LEN                                                          
#define   FY002631_LEN                         1                                
#endif                                                                          
#ifndef   FY002897_LEN                                                          
#define   FY002897_LEN                         1                                
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02499_APPL_AREA_z                                                     
#define _A02499_APPL_AREA_z                                                     
typedef struct __A02499_appl_area                                               
{                                                                               
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPprNbr[FY002479_LEN];                                   
   char                sFltTripOrigId[FY002838_LEN];                            
   char                sFltTripDestId[FY002839_LEN];                            
   char                sFltDprtDt[FY003584_LEN];                                
   char                sFltArrDt[FY003581_LEN];                                 
   double              fFltImptValAmt;                                          
   double              fFltImptWageAmt;                                         
   float               fNrevPmtAmt;                                             
   double              fCurrExchgRatNbr;                                        
   char                sFltAcctEffDt[FY003580_LEN];                             
   char                sFltRptNotfDt[FY003587_LEN];                             
   char                cFltMatchInd;                                            
   char                cFltRptInd;                                              
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02499_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02499_z                                                               
#define _A02499_z                                                               
                                                                                
   typedef struct __A02499                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02499_APPL_AREA A02499_appl_area;                                       
   }  _A02499;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02499_FMT
#define FYA02499_FMT     "k88s3s10s6s6s27s27dw7.2dw7.2fw5.2dw6.6s27s27ccs9s2"\
                         "7"
#endif
