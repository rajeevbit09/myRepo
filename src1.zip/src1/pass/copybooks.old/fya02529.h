/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02529                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 07/26/95                                                */
/*              Time: 14:00:51                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02529                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002494_LEN                                                          
#define   FY002494_LEN                         26                               
#endif                                                                          
#ifndef   FY002492_LEN                                                          
#define   FY002492_LEN                         1                                
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02529_APPL_AREA_z                                                     
#define _A02529_APPL_AREA_z                                                     
typedef struct __A02529_appl_area                                               
{                                                                               
   char                sNrevTypDs[FY002494_LEN];                                
   char                cPassImptInd;                                            
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02529_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02529_z                                                               
#define _A02529_z                                                               
                                                                                
   typedef struct __A02529                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02529_APPL_AREA A02529_appl_area;                                       
   }  _A02529;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02529_FMT
#define FYA02529_FMT     "k88s26cs9s27"
#endif
