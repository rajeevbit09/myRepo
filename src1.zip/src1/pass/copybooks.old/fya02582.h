/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02582                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 03/25/96                                                */
/*              Time: 17:40:44                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02582                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02582__A02582_APPL_AREA_SIZE                                        
#define   _A02582__A02582_APPL_AREA_SIZE       10                               
#endif                                                                          
#ifndef   FY002635_LEN                                                          
#define   FY002635_LEN                         3                                
#endif                                                                          
#ifndef   FY002636_LEN                                                          
#define   FY002636_LEN                         16                               
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY002641_LEN                                                          
#define   FY002641_LEN                         10                               
#endif                                                                          
#ifndef _A02582_APPL_AREA_z                                                     
#define _A02582_APPL_AREA_z                                                     
typedef struct __A02582_appl_area                                               
{                                                                               
   char                sSvcChrgCd[FY002635_LEN];                                
   char                sSvcChrgDs[FY002636_LEN];                                
   char                sPassTypCd[FY002496_LEN];                                
   double              dCostChrgAmt;                                            
   char                sFltFeeAcctNbr[FY002641_LEN];                            
}  _A02582_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02582_z                                                               
#define _A02582_z                                                               
                                                                                
   typedef struct __A02582                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02582_APPL_AREA A02582_appl_area[_A02582__A02582_APPL_AREA_SIZE];       
   }  _A02582;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02582_FMT
#define FYA02582_FMT     "k88r5/10s3s16s3dw7.2s10"
#endif
