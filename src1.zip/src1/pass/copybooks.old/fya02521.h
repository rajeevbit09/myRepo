/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02521                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/25/95                                                */
/*              Time: 12:47:20                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02521                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02521_APPL_AREA_z                                                     
#define _A02521_APPL_AREA_z                                                     
typedef struct __A02521_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02521_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02521_z                                                               
#define _A02521_z                                                               
                                                                                
   typedef struct __A02521                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02521_APPL_AREA A02521_appl_area;                                       
   }  _A02521;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02521_FMT
#define FYA02521_FMT     "k88s27"
#endif
