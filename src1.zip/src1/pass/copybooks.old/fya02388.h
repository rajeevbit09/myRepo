/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02388                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/23/95                                                */
/*              Time: 17:23:50                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02388                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02388_APPL_AREA_z                                                     
#define _A02388_APPL_AREA_z                                                     
typedef struct __A02388_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02388_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02388_z                                                               
#define _A02388_z                                                               
                                                                                
   typedef struct __A02388                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02388_APPL_AREA A02388_appl_area;                                       
   }  _A02388;                                                                  
#endif                                                                          
                                                                                


#ifndef FYA02388_FMT
#define FYA02388_FMT     "k88s27"
#endif
