/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02439                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/22/95                                                */
/*              Time: 17:04:24                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02439                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02439_APPL_AREA_z                                                     
#define _A02439_APPL_AREA_z                                                     
typedef struct __A02439_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02439_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02439_z                                                               
#define _A02439_z                                                               
                                                                                
   typedef struct __A02439                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02439_APPL_AREA A02439_appl_area;                                       
   }  _A02439;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02439_FMT
#define FYA02439_FMT     "k88s27"
#endif
