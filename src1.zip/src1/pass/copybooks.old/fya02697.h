/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02697                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 04/19/96                                                */
/*              Time: 11:38:05                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02697                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _BRDPRIORITYTS_z                                                        
#define _BRDPRIORITYTS_z                                                        
typedef struct __BrdPriorityTs                                                  
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _BRDPRIORITYTS;                                                              
#endif                                                                          
#ifndef _PASSALLOTTS_z                                                          
#define _PASSALLOTTS_z                                                          
typedef struct __PassAllotTs                                                    
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _PASSALLOTTS;                                                                
#endif                                                                          
#ifndef _A02697_APPL_AREA_z                                                     
#define _A02697_APPL_AREA_z                                                     
typedef struct __A02697_Appl_Area                                               
{                                                                               
   _PASSALLOTTS PassAllotTs;                                                    
   _BRDPRIORITYTS BrdPriorityTs;                                                
}  _A02697_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02697_z                                                               
#define _A02697_z                                                               
                                                                                
   typedef struct __A02697                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02697_APPL_AREA A02697_Appl_Area;                                       
   }  _A02697;                                                                  
#endif                                                                          
                                                                                


#ifndef FYA02697_FMT
#define FYA02697_FMT     "k88r1/1s27r1/1s27"
#endif
