/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02512                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/25/95                                                */
/*              Time: 11:41:43                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02512                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02512_APPL_AREA_z                                                     
#define _A02512_APPL_AREA_z                                                     
typedef struct __A02512_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02512_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02512_z                                                               
#define _A02512_z                                                               
                                                                                
   typedef struct __A02512                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02512_APPL_AREA A02512_appl_area;                                       
   }  _A02512;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02512_FMT
#define FYA02512_FMT     "k88s27"
#endif
