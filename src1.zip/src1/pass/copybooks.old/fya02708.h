/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02708                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 11/21/95                                                */
/*              Time: 12:42:41                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02708                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02708__A02708_APPL_AREA_SIZE                                        
#define   _A02708__A02708_APPL_AREA_SIZE       200                              
#endif                                                                          
#ifndef   FY002635_LEN                                                          
#define   FY002635_LEN                         3                                
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY002641_LEN                                                          
#define   FY002641_LEN                         10                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02708_APPL_AREA_z                                                     
#define _A02708_APPL_AREA_z                                                     
typedef struct __A02708_appl_area                                               
{                                                                               
   char                sSvcChrgCd[FY002635_LEN];                                
   char                sPassTypCd[FY002496_LEN];                                
   double              dCostChrgAmt;                                            
   char                sFltFeeAcctNbr[FY002641_LEN];                            
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02708_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02708_z                                                               
#define _A02708_z                                                               
                                                                                
   typedef struct __A02708                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02708_APPL_AREA A02708_appl_area[_A02708__A02708_APPL_AREA_SIZE];       
   }  _A02708;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02708_FMT
#define FYA02708_FMT     "k88r5/200s3s3dw7.2s10s27"
#endif
