/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02566                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/25/95                                                */
/*              Time: 08:36:39                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02566                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002492_LEN                                                          
#define   FY002492_LEN                         1                                
#endif                                                                          
#ifndef _A02566_APPL_AREA_z                                                     
#define _A02566_APPL_AREA_z                                                     
typedef struct __A02566_appl_area                                               
{                                                                               
   char                cPassImptInd;                                            
}  _A02566_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02566_z                                                               
#define _A02566_z                                                               
                                                                                
   typedef struct __A02566                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02566_APPL_AREA A02566_appl_area;                                       
   }  _A02566;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02566_FMT
#define FYA02566_FMT     "k88c"
#endif
