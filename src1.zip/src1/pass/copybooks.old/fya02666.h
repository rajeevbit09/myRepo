/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02666                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/11/97                                                */
/*              Time: 10:36:10                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02666                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002779_LEN                                                          
#define   FY002779_LEN                         10                               
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002475_LEN                                                          
#define   FY002475_LEN                         25                               
#endif                                                                          
#ifndef   FY002476_LEN                                                          
#define   FY002476_LEN                         25                               
#endif                                                                          
#ifndef   FY002477_LEN                                                          
#define   FY002477_LEN                         25                               
#endif                                                                          
#ifndef   FY002482_LEN                                                          
#define   FY002482_LEN                         3                                
#endif                                                                          
#ifndef   FY002518_LEN                                                          
#define   FY002518_LEN                         10                               
#endif                                                                          
#ifndef   FY002478_LEN                                                          
#define   FY002478_LEN                         4                                
#endif                                                                          
#ifndef _A02666_APPL_AREA_z                                                     
#define _A02666_APPL_AREA_z                                                     
typedef struct __A02666_appl_area                                               
{                                                                               
   char                sPprNm[FY002480_LEN];                                    
   char                sPprSocSecNbr[FY002779_LEN];                             
   char                sPassGrpCd[FY002488_LEN];                                
   char                sPpr1Addr[FY002475_LEN];                                 
   char                sPpr2Addr[FY002476_LEN];                                 
   char                sPprCtyAddr[FY002477_LEN];                               
   char                sPprStCd[FY002482_LEN];                                  
   char                sPprZipAddr[FY002518_LEN];                               
   char                sPprCtryCd[FY002478_LEN];                                
}  _A02666_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02666_z                                                               
#define _A02666_z                                                               
                                                                                
   typedef struct __A02666                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02666_APPL_AREA A02666_appl_area;                                       
   }  _A02666;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02666_FMT
#define FYA02666_FMT     "k88s31s10s3s25s25s25s3s10s4"
#endif
