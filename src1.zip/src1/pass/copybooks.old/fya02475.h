/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02475                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 07/21/95                                                */
/*              Time: 10:23:23                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02475                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002489_LEN                                                          
#define   FY002489_LEN                         26                               
#endif                                                                          
#ifndef   FY002492_LEN                                                          
#define   FY002492_LEN                         1                                
#endif                                                                          
#ifndef   FY002641_LEN                                                          
#define   FY002641_LEN                         10                               
#endif                                                                          
#ifndef   FY003113_LEN                                                          
#define   FY003113_LEN                         1                                
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02475_APPL_AREA_z                                                     
#define _A02475_APPL_AREA_z                                                     
typedef struct __A02475_appl_area                                               
{                                                                               
   char                sPassGrpDs[FY002489_LEN];                                
   char                cPassImptInd;                                            
   char                sFltFeeAcctNbr[FY002641_LEN];                            
   char                cPassManlInd;                                            
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02475_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02475_z                                                               
#define _A02475_z                                                               
                                                                                
   typedef struct __A02475                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02475_APPL_AREA A02475_appl_area;                                       
   }  _A02475;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02475_FMT
#define FYA02475_FMT     "k88s26cs10cs9s27"
#endif
