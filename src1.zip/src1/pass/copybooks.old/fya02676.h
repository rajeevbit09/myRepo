/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02676                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 12/19/95                                                */
/*              Time: 11:58:39                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02676                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef _A02676_APPL_AREA_z                                                     
#define _A02676_APPL_AREA_z                                                     
typedef struct __A02676_appl_area                                               
{                                                                               
   double              dCostChrgAmt;                                            
}  _A02676_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02676_z                                                               
#define _A02676_z                                                               
                                                                                
   typedef struct __A02676                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02676_APPL_AREA A02676_appl_area;                                       
   }  _A02676;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02676_FMT
#define FYA02676_FMT     "k88dw7.2"
#endif
