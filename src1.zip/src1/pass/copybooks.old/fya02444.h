/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02444                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/17/95                                                */
/*              Time: 15:13:48                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02444                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02444_APPL_AREA_z                                                     
#define _A02444_APPL_AREA_z                                                     
typedef struct __A02444_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02444_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02444_z                                                               
#define _A02444_z                                                               
                                                                                
   typedef struct __A02444                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02444_APPL_AREA A02444_appl_area;                                       
   }  _A02444;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02444_FMT
#define FYA02444_FMT     "k88s27"
#endif
