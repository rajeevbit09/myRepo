/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02562                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/01/95                                                */
/*              Time: 15:01:43                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02562                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02562_APPL_AREA_z                                                     
#define _A02562_APPL_AREA_z                                                     
typedef struct __A02562_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02562_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02562_z                                                               
#define _A02562_z                                                               
                                                                                
   typedef struct __A02562                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02562_APPL_AREA A02562_appl_area;                                       
   }  _A02562;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02562_FMT
#define FYA02562_FMT     "k88s27"
#endif
