/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02668                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 03/15/96                                                */
/*              Time: 15:28:46                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02668                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002475_LEN                                                          
#define   FY002475_LEN                         25                               
#endif                                                                          
#ifndef   FY002476_LEN                                                          
#define   FY002476_LEN                         25                               
#endif                                                                          
#ifndef   FY002477_LEN                                                          
#define   FY002477_LEN                         25                               
#endif                                                                          
#ifndef   FY002482_LEN                                                          
#define   FY002482_LEN                         3                                
#endif                                                                          
#ifndef   FY002518_LEN                                                          
#define   FY002518_LEN                         10                               
#endif                                                                          
#ifndef   FY002794_LEN                                                          
#define   FY002794_LEN                         9                                
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002478_LEN                                                          
#define   FY002478_LEN                         4                                
#endif                                                                          
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef   FY002704_LEN                                                          
#define   FY002704_LEN                         6                                
#endif                                                                          
#ifndef _A02668_APPL_AREA_z                                                     
#define _A02668_APPL_AREA_z                                                     
typedef struct __A02668_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sPprNm[FY002480_LEN];                                    
   char                sPpr1Addr[FY002475_LEN];                                 
   char                sPpr2Addr[FY002476_LEN];                                 
   char                sPprCtyAddr[FY002477_LEN];                               
   char                sPprStCd[FY002482_LEN];                                  
   char                sPprZipAddr[FY002518_LEN];                               
   char                sPprInttxNbr[FY002794_LEN];                              
   char                sPassGrpCd[FY002488_LEN];                                
   char                sPprCtryCd[FY002478_LEN];                                
   char                sPprStnId[FY002711_LEN];                                 
   char                sPprDeptNbr[FY002704_LEN];                               
}  _A02668_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02668_z                                                               
#define _A02668_z                                                               
                                                                                
   typedef struct __A02668                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02668_APPL_AREA A02668_appl_area;                                       
   }  _A02668;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02668_FMT
#define FYA02668_FMT     "k88s10s31s25s25s25s3s10s9s3s4s6s6"
#endif
