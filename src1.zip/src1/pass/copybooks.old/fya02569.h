/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02569                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 09/26/95                                                */
/*              Time: 10:09:31                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02569                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02569__A02569_APPL_AREA_SIZE                                        
#define   _A02569__A02569_APPL_AREA_SIZE       20                               
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY002864_LEN                                                          
#define   FY002864_LEN                         1                                
#endif                                                                          
#ifndef _A02569_APPL_AREA_z                                                     
#define _A02569_APPL_AREA_z                                                     
typedef struct __A02569_appl_area                                               
{                                                                               
   char                sPassTypCd[FY002496_LEN];                                
   short               nNrevRemnDyQty;                                          
   long                lNrevRemnMiQty;                                          
   short               nFltAllotDyNbr;                                          
   long                lFltAllotMiQty;                                          
   char                cPassAddlInd;                                            
}  _A02569_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02569_z                                                               
#define _A02569_z                                                               
                                                                                
   typedef struct __A02569                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02569_APPL_AREA A02569_appl_area[_A02569__A02569_APPL_AREA_SIZE];       
   }  _A02569;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02569_FMT
#define FYA02569_FMT     "k88r6/20s3nw3lw7nz3lw7c"
#endif
