/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02649                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 11/06/95                                                */
/*              Time: 09:27:59                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02649                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef _A02649_APPL_AREA_z                                                     
#define _A02649_APPL_AREA_z                                                     
typedef struct __A02649_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   double              fFltImptWageAmt;                                         
}  _A02649_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02649_z                                                               
#define _A02649_z                                                               
                                                                                
   typedef struct __A02649                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02649_APPL_AREA A02649_appl_area;                                       
   }  _A02649;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02649_FMT
#define FYA02649_FMT     "k88s10dw7.2"
#endif
