/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02516                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/21/95                                                */
/*              Time: 13:16:01                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02516                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02516_APPL_AREA_z                                                     
#define _A02516_APPL_AREA_z                                                     
typedef struct __A02516_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02516_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02516_z                                                               
#define _A02516_z                                                               
                                                                                
   typedef struct __A02516                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02516_APPL_AREA A02516_appl_area;                                       
   }  _A02516;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02516_FMT
#define FYA02516_FMT     "k88s27"
#endif
