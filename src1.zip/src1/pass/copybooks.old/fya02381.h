/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02381                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/20/98                                                */
/*              Time: 15:46:04                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02381                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002779_LEN                                                          
#define   FY002779_LEN                         10                               
#endif                                                                          
#ifndef   FY002475_LEN                                                          
#define   FY002475_LEN                         25                               
#endif                                                                          
#ifndef   FY002476_LEN                                                          
#define   FY002476_LEN                         25                               
#endif                                                                          
#ifndef   FY002477_LEN                                                          
#define   FY002477_LEN                         25                               
#endif                                                                          
#ifndef   FY002482_LEN                                                          
#define   FY002482_LEN                         3                                
#endif                                                                          
#ifndef   FY002518_LEN                                                          
#define   FY002518_LEN                         10                               
#endif                                                                          
#ifndef   FY002481_LEN                                                          
#define   FY002481_LEN                         16                               
#endif                                                                          
#ifndef   FY002478_LEN                                                          
#define   FY002478_LEN                         4                                
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef   FY002715_LEN                                                          
#define   FY002715_LEN                         16                               
#endif                                                                          
#ifndef   FY002714_LEN                                                          
#define   FY002714_LEN                         15                               
#endif                                                                          
#ifndef   FY002716_LEN                                                          
#define   FY002716_LEN                         1                                
#endif                                                                          
#ifndef   FY002711_LEN                                                          
#define   FY002711_LEN                         6                                
#endif                                                                          
#ifndef   FY002704_LEN                                                          
#define   FY002704_LEN                         6                                
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY003592_LEN                                                          
#define   FY003592_LEN                         27                               
#endif                                                                          
#ifndef   FY002794_LEN                                                          
#define   FY002794_LEN                         9                                
#endif                                                                          
#ifndef   FY003590_LEN                                                          
#define   FY003590_LEN                         27                               
#endif                                                                          
#ifndef   FY003744_LEN                                                          
#define   FY003744_LEN                         4                                
#endif                                                                          
#ifndef   FY003745_LEN                                                          
#define   FY003745_LEN                         3                                
#endif                                                                          
#ifndef   FY004081_LEN                                                          
#define   FY004081_LEN                         1                                
#endif                                                                          
#ifndef   FY004078_LEN                                                          
#define   FY004078_LEN                         1                                
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02381_APPL_AREA_z                                                     
#define _A02381_APPL_AREA_z                                                     
typedef struct __A02381_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                             
   char                sPprSocSecNbr[FY002779_LEN];                             
   char                sPpr1Addr[FY002475_LEN];                                 
   char                sPpr2Addr[FY002476_LEN];                                 
   char                sPprCtyAddr[FY002477_LEN];                               
   char                sPprStCd[FY002482_LEN];                                  
   char                sPprZipAddr[FY002518_LEN];                               
   char                sPprPhNbr[FY002481_LEN];                                 
   char                sPprCtryCd[FY002478_LEN];                                
   char                sPprNm[FY002480_LEN];                                    
   char                sPprLstNm[FY002715_LEN];                                 
   char                sPprFrstNm[FY002714_LEN];                                
   char                cPprMidNm;                                               
   char                sPprStnId[FY002711_LEN];                                 
   char                sPprDeptNbr[FY002704_LEN];                               
   char                sPassGrpCd[FY002488_LEN];                                
   unsigned short      uPprStrtMo;                                              
   unsigned short      uPprStrtDy;                                              
   char                sPprStrtDt[FY003592_LEN];                                
   short               nFltMoSvcNbr;                                            
   char                sPprInttxNbr[FY002794_LEN];                              
   char                sPprRvkDt[FY003590_LEN];                                 
   char                sCtryCtznpCd[FY003744_LEN];                              
   char                sPprRsdncyStsCd[FY003745_LEN];                           
   char                cPprFFInd;                                               
   char                cPprABInd;                                               
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02381_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02381_z                                                               
#define _A02381_z                                                               
                                                                                
   typedef struct __A02381                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02381_APPL_AREA A02381_appl_area;                                       
   }  _A02381;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02381_FMT
#define FYA02381_FMT     "k88s10s10s25s25s25s3s10s16s4s31s16s15cs6s6s3uz2uz2"\
                         "s27nw4s9s27s4s3ccs9s27"
#endif
