/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02709                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/17/95                                                */
/*              Time: 10:09:03                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02709                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02709_APPL_AREA_z                                                     
#define _A02709_APPL_AREA_z                                                     
typedef struct __A02709_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02709_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02709_z                                                               
#define _A02709_z                                                               
                                                                                
   typedef struct __A02709                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02709_APPL_AREA A02709_appl_area;                                       
   }  _A02709;                                                                  
#endif                                                                          
                                                                                


#ifndef FYA02709_FMT
#define FYA02709_FMT     "k88s27"
#endif
