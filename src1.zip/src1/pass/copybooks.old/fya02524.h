/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02524                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/25/95                                                */
/*              Time: 12:49:14                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02524                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002635_LEN                                                          
#define   FY002635_LEN                         3                                
#endif                                                                          
#ifndef   FY002703_LEN                                                          
#define   FY002703_LEN                         3                                
#endif                                                                          
#ifndef   FY003588_LEN                                                          
#define   FY003588_LEN                         27                               
#endif                                                                          
#ifndef   FY002641_LEN                                                          
#define   FY002641_LEN                         10                               
#endif                                                                          
#ifndef   FY003580_LEN                                                          
#define   FY003580_LEN                         27                               
#endif                                                                          
#ifndef   FY002636_LEN                                                          
#define   FY002636_LEN                         16                               
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02524_APPL_AREA_z                                                     
#define _A02524_APPL_AREA_z                                                     
typedef struct __A02524_appl_area                                               
{                                                                               
   char                sFltOrigCtyId[FY002521_LEN];                             
   char                sFltDestCtyId[FY002522_LEN];                             
   char                sFltNbr[FY002553_LEN];                                   
   long                lPassTripNbr;                                            
   char                sSvcChrgCd[FY002635_LEN];                                
   double              dCostChrgAmt;                                            
   char                sFltClsSvcId[FY002703_LEN];                              
   char                sProcDt[FY003588_LEN];                                   
   char                sFltFeeAcctNbr[FY002641_LEN];                            
   char                sFltAcctEffDt[FY003580_LEN];                             
   char                sSvcChrgDs[FY002636_LEN];                                
   long                lFltChrgRfrnDt;                                          
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02524_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02524_z                                                               
#define _A02524_z                                                               
                                                                                
   typedef struct __A02524                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02524_APPL_AREA A02524_appl_area;                                       
   }  _A02524;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02524_FMT
#define FYA02524_FMT     "k88s6s6s6lz6s3dw7.2s3s27s10s27s16lz7s9s27"
#endif
