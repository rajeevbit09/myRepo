/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02360                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 10/11/95                                                */
/*              Time: 15:38:12                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02360                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02360_APPL_AREA_z                                                     
#define _A02360_APPL_AREA_z                                                     
typedef struct __A02360_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02360_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02360_z                                                               
#define _A02360_z                                                               
                                                                                
   typedef struct __A02360                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02360_APPL_AREA A02360_appl_area;                                       
   }  _A02360;                                                                  
#endif                                                                          
                                                                                



#ifndef FYA02360_FMT
#define FYA02360_FMT     "k88s27"
#endif
