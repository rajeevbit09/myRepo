/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02576                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 07/21/95                                                */
/*              Time: 06:40:46                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02576                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef _A02576_APPL_AREA_z                                                     
#define _A02576_APPL_AREA_z                                                     
typedef struct __A02576_appl_area                                               
{                                                                               
   long                lFltArptPrNbr;                                           
}  _A02576_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02576_z                                                               
#define _A02576_z                                                               
                                                                                
   typedef struct __A02576                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02576_APPL_AREA A02576_appl_area;                                       
   }  _A02576;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02576_FMT
#define FYA02576_FMT     "k88lw5"
#endif
