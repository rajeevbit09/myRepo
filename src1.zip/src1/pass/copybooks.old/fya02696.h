/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02696                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 09/27/95                                                */
/*              Time: 09:58:47                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02696                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02696__A02696_APPL_AREA_SIZE                                        
#define   _A02696__A02696_APPL_AREA_SIZE       50                               
#endif                                                                          
#ifndef   FY002864_LEN                                                          
#define   FY002864_LEN                         1                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02696_APPL_AREA_z                                                     
#define _A02696_APPL_AREA_z                                                     
typedef struct __A02696_appl_area                                               
{                                                                               
   short               nFltMoSvcNbr;                                            
   short               nFltAllotDyNbr;                                          
   long                lFltAllotMiQty;                                          
   char                cPassAddlInd;                                            
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02696_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02696_z                                                               
#define _A02696_z                                                               
                                                                                
   typedef struct __A02696                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02696_APPL_AREA A02696_appl_area[_A02696__A02696_APPL_AREA_SIZE];       
   }  _A02696;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02696_FMT
#define FYA02696_FMT     "k88r5/50nw4nz3lw7cs27"
#endif
