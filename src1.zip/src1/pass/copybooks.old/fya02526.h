/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02526                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/25/95                                                */
/*              Time: 12:50:30                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02526                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02526_APPL_AREA_z                                                     
#define _A02526_APPL_AREA_z                                                     
typedef struct __A02526_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02526_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02526_z                                                               
#define _A02526_z                                                               
                                                                                
   typedef struct __A02526                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02526_APPL_AREA A02526_appl_area;                                       
   }  _A02526;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02526_FMT
#define FYA02526_FMT     "k88s27"
#endif
