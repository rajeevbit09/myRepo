/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02532                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 07/26/95                                                */
/*              Time: 14:02:59                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02532                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02532_APPL_AREA_z                                                     
#define _A02532_APPL_AREA_z                                                     
typedef struct __A02532_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02532_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02532_z                                                               
#define _A02532_z                                                               
                                                                                
   typedef struct __A02532                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02532_APPL_AREA A02532_appl_area;                                       
   }  _A02532;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02532_FMT
#define FYA02532_FMT     "k88s27"
#endif
