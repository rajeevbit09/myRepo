/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02688                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 09/19/95                                                */
/*              Time: 14:33:12                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02688                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002864_LEN                                                          
#define   FY002864_LEN                         1                                
#endif                                                                          
#ifndef   FY003588_LEN                                                          
#define   FY003588_LEN                         27                               
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef _A02688_APPL_AREA_z                                                     
#define _A02688_APPL_AREA_z                                                     
typedef struct __A02688_appl_area                                               
{                                                                               
   short               nNrevRemnDyQty;                                          
   long                lNrevRemnMiQty;                                          
   char                cPassAddlInd;                                            
   char                sProcDt[FY003588_LEN];                                   
   char                sPassRptSortDt[FY003821_LEN];                            
}  _A02688_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02688_z                                                               
#define _A02688_z                                                               
                                                                                
   typedef struct __A02688                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02688_APPL_AREA A02688_appl_area;                                       
   }  _A02688;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02688_FMT
#define FYA02688_FMT     "k88nw3lw7cs27s27"
#endif
