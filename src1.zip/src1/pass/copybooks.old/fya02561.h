/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02561                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/01/95                                                */
/*              Time: 15:01:33                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02561                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02561_APPL_AREA_z                                                     
#define _A02561_APPL_AREA_z                                                     
typedef struct __A02561_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02561_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02561_z                                                               
#define _A02561_z                                                               
                                                                                
   typedef struct __A02561                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02561_APPL_AREA A02561_appl_area;                                       
   }  _A02561;                                                                  
#endif                                                                          
                                                                                



#ifndef FYA02561_FMT
#define FYA02561_FMT     "k88s27"
#endif
