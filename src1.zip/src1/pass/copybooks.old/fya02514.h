/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02514                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/21/95                                                */
/*              Time: 13:15:40                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02514                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002864_LEN                                                          
#define   FY002864_LEN                         1                                
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02514_APPL_AREA_z                                                     
#define _A02514_APPL_AREA_z                                                     
typedef struct __A02514_appl_area                                               
{                                                                               
   short               nFltAllotDyNbr;                                          
   long                lFltAllotMiQty;                                          
   char                cPassAddlInd;                                            
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02514_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02514_z                                                               
#define _A02514_z                                                               
                                                                                
   typedef struct __A02514                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02514_APPL_AREA A02514_appl_area;                                       
   }  _A02514;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02514_FMT
#define FYA02514_FMT     "k88nz3lw7cs9s27"
#endif
