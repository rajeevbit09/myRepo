/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02522                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/25/95                                                */
/*              Time: 12:47:58                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02522                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02522_APPL_AREA_z                                                     
#define _A02522_APPL_AREA_z                                                     
typedef struct __A02522_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02522_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02522_z                                                               
#define _A02522_z                                                               
                                                                                
   typedef struct __A02522                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02522_APPL_AREA A02522_appl_area;                                       
   }  _A02522;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02522_FMT
#define FYA02522_FMT     "k88s27"
#endif
