/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02559                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 06/09/95                                                */
/*              Time: 09:55:23                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02559                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002868_LEN                                                          
#define   FY002868_LEN                         27                               
#endif                                                                          
#ifndef   FY003080_LEN                                                          
#define   FY003080_LEN                         7                                
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef   FY002496_LEN                                                          
#define   FY002496_LEN                         3                                
#endif                                                                          
#ifndef   FY003084_LEN                                                          
#define   FY003084_LEN                         26                               
#endif                                                                          
#ifndef   FY003082_LEN                                                          
#define   FY003082_LEN                         31                               
#endif                                                                          
#ifndef   FY003083_LEN                                                          
#define   FY003083_LEN                         31                               
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02559_APPL_AREA_z                                                     
#define _A02559_APPL_AREA_z                                                     
typedef struct __A02559_appl_area                                               
{                                                                               
   char                sPassDtTmTs[FY002868_LEN];                               
   char                sAudtUserId[FY003080_LEN];                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sPassGrpCd[FY002488_LEN];                                
   char                sPassTypCd[FY002496_LEN];                                
   char                sAudtChgTypNm[FY003084_LEN];                             
   char                sAudtChgFrNm[FY003082_LEN];                              
   char                sAudtChgToNm[FY003083_LEN];                              
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02559_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02559_z                                                               
#define _A02559_z                                                               
                                                                                
   typedef struct __A02559                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02559_APPL_AREA A02559_appl_area;                                       
   }  _A02559;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02559_FMT
#define FYA02559_FMT     "k88s27s7s10s3s3s3s26s31s31s9s27"
#endif
