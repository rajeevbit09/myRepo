/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02595                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/30/96                                                */
/*              Time: 13:57:45                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02595                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02595__A02595_APPL_AREA_SIZE                                        
#define   _A02595__A02595_APPL_AREA_SIZE       400                              
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002715_LEN                                                          
#define   FY002715_LEN                         16                               
#endif                                                                          
#ifndef   FY002714_LEN                                                          
#define   FY002714_LEN                         15                               
#endif                                                                          
#ifndef   FY002716_LEN                                                          
#define   FY002716_LEN                         1                                
#endif                                                                          
#ifndef   FY002480_LEN                                                          
#define   FY002480_LEN                         31                               
#endif                                                                          
#ifndef _A02595_APPL_AREA_z                                                     
#define _A02595_APPL_AREA_z                                                     
typedef struct __A02595_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sPprLstNm[FY002715_LEN];                                 
   char                sPprFrstNm[FY002714_LEN];                                
   char                cPprMidNm;                                               
   char                sPprNm[FY002480_LEN];                                    
}  _A02595_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02595_z                                                               
#define _A02595_z                                                               
                                                                                
   typedef struct __A02595                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02595_APPL_AREA A02595_appl_area[_A02595__A02595_APPL_AREA_SIZE];       
   }  _A02595;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02595_FMT
#define FYA02595_FMT     "k88r5/400s10s16s15cs31"
#endif
