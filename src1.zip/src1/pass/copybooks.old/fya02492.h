/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02492                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/16/95                                                */
/*              Time: 10:43:01                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02492                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02492_APPL_AREA_z                                                     
#define _A02492_APPL_AREA_z                                                     
typedef struct __A02492_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02492_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02492_z                                                               
#define _A02492_z                                                               
                                                                                
   typedef struct __A02492                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02492_APPL_AREA A02492_appl_area;                                       
   }  _A02492;                                                                  
#endif                                                                          
                                                                                



#ifndef FYA02492_FMT
#define FYA02492_FMT     "k88s27"
#endif
