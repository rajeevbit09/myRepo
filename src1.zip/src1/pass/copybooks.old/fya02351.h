/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02351                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/03/96                                                */
/*              Time: 12:33:05                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02351                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   _A02351__A02351_APPL_AREA_SIZE                                        
#define   _A02351__A02351_APPL_AREA_SIZE       200                              
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY002553_LEN                                                          
#define   FY002553_LEN                         6                                
#endif                                                                          
#ifndef   FY002521_LEN                                                          
#define   FY002521_LEN                         6                                
#endif                                                                          
#ifndef   FY002522_LEN                                                          
#define   FY002522_LEN                         6                                
#endif                                                                          
#ifndef   FY002867_LEN                                                          
#define   FY002867_LEN                         1                                
#endif                                                                          
#ifndef   FY002778_LEN                                                          
#define   FY002778_LEN                         11                               
#endif                                                                          
#ifndef   FY002631_LEN                                                          
#define   FY002631_LEN                         1                                
#endif                                                                          
#ifndef   FY002838_LEN                                                          
#define   FY002838_LEN                         6                                
#endif                                                                          
#ifndef   FY002839_LEN                                                          
#define   FY002839_LEN                         6                                
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef _A02351_APPL_AREA_z                                                     
#define _A02351_APPL_AREA_z                                                     
typedef struct __A02351_appl_area                                               
{                                                                               
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltDprtDt[FY003584_LEN];                                
   short               nFltDprtTm;                                              
   char                sFltNbr[FY002553_LEN];                                   
   char                sFltOrigCtyId[FY002521_LEN];                             
   char                sFltDestCtyId[FY002522_LEN];                             
   char                cFltLegSrcInd;                                           
   char                sTktNbr[FY002778_LEN];                                   
   long                lPassTripNbr;                                            
   char                cFltMatchInd;                                            
   char                sFltTripOrigId[FY002838_LEN];                            
   char                sFltTripDestId[FY002839_LEN];                            
   double              fFltImptWageAmt;                                         
   float               fNrevPmtAmt;                                             
   double              fCurrExchgRatNbr;                                        
   char                sPassGrpCd[FY002488_LEN];                                
}  _A02351_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02351_z                                                               
#define _A02351_z                                                               
                                                                                
   typedef struct __A02351                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02351_APPL_AREA A02351_appl_area[_A02351__A02351_APPL_AREA_SIZE];       
   }  _A02351;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02351_FMT
#define FYA02351_FMT     "k88r17/200s10s3s27nw4s6s6s6cs11lz6cs6s6dw7.2fw5.2d"\
                         "w6.6s3"
#endif
