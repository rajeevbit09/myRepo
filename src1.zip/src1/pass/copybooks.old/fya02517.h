/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02517                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/21/95                                                */
/*              Time: 13:16:12                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02517                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02517_APPL_AREA_z                                                     
#define _A02517_APPL_AREA_z                                                     
typedef struct __A02517_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02517_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02517_z                                                               
#define _A02517_z                                                               
                                                                                
   typedef struct __A02517                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02517_APPL_AREA A02517_appl_area;                                       
   }  _A02517;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02517_FMT
#define FYA02517_FMT     "k88s27"
#endif
