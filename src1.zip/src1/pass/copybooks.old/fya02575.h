/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02575                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/07/98                                                */
/*              Time: 10:09:53                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02575                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002479_LEN                                                          
#define   FY002479_LEN                         10                               
#endif                                                                          
#ifndef   FY002516_LEN                                                          
#define   FY002516_LEN                         3                                
#endif                                                                          
#ifndef   FY003584_LEN                                                          
#define   FY003584_LEN                         27                               
#endif                                                                          
#ifndef   FY003821_LEN                                                          
#define   FY003821_LEN                         27                               
#endif                                                                          
#ifndef   FY002838_LEN                                                          
#define   FY002838_LEN                         6                                
#endif                                                                          
#ifndef   FY002839_LEN                                                          
#define   FY002839_LEN                         6                                
#endif                                                                          
#ifndef   FY002794_LEN                                                          
#define   FY002794_LEN                         9                                
#endif                                                                          
#ifndef   FY002488_LEN                                                          
#define   FY002488_LEN                         3                                
#endif                                                                          
#ifndef _A02575_APPL_AREA_z                                                     
#define _A02575_APPL_AREA_z                                                     
typedef struct __A02575_appl_area                                               
{                                                                               
   long                lPassTripNbr;                                            
   char                sPprNbr[FY002479_LEN];                                   
   char                sNrevNbr[FY002516_LEN];                                  
   char                sFltDprtDt[FY003584_LEN];                                
   char                sPassRptSortDt[FY003821_LEN];                            
   double              fFltImptValAmt;                                          
   char                sFltTripOrigId[FY002838_LEN];                            
   char                sFltTripDestId[FY002839_LEN];                            
   char                sPprInttxNbr[FY002794_LEN];                              
   char                sPassGrpCd[FY002488_LEN];                                
}  _A02575_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02575_z                                                               
#define _A02575_z                                                               
                                                                                
   typedef struct __A02575                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02575_APPL_AREA A02575_appl_area;                                       
   }  _A02575;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02575_FMT
#define FYA02575_FMT     "k88lz6s10s3s27s27dw7.2s6s6s9s3"
#endif
