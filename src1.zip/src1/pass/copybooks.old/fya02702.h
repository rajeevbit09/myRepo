/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02702                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/11/95                                                */
/*              Time: 10:03:27                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02702                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A2702_APPL_AREA_z                                                      
#define _A2702_APPL_AREA_z                                                      
typedef struct __A2702_appl_area                                                
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A2702_APPL_AREA;                                                            
#endif                                                                          
                                                                                
#ifndef _A02702_z                                                               
#define _A02702_z                                                               
                                                                                
   typedef struct __A02702                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A2702_APPL_AREA a2702_appl_area;                                         
   }  _A02702;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02702_FMT
#define FYA02702_FMT     "k88s27"
#endif
