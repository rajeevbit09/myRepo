/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02579                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 01/04/96                                                */
/*              Time: 09:55:56                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02579                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef _A02579_APPL_AREA_z                                                     
#define _A02579_APPL_AREA_z                                                     
typedef struct __A02579_appl_area                                               
{                                                                               
   double              dCpYieldAmt;                                             
}  _A02579_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02579_z                                                               
#define _A02579_z                                                               
                                                                                
   typedef struct __A02579                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02579_APPL_AREA A02579_appl_area;                                       
   }  _A02579;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02579_FMT
#define FYA02579_FMT     "k88dw4.5"
#endif
