/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02441                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 08/17/95                                                */
/*              Time: 15:11:49                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02441                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002864_LEN                                                          
#define   FY002864_LEN                         1                                
#endif                                                                          
#ifndef   FY003588_LEN                                                          
#define   FY003588_LEN                         27                               
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02441_APPL_AREA_z                                                     
#define _A02441_APPL_AREA_z                                                     
typedef struct __A02441_appl_area                                               
{                                                                               
   short               nNrevRemnDyQty;                                          
   long                lNrevRemnMiQty;                                          
   short               nFltAllotDyNbr;                                          
   long                lFltAllotMiQty;                                          
   char                cPassAddlInd;                                            
   char                sProcDt[FY003588_LEN];                                   
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02441_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02441_z                                                               
#define _A02441_z                                                               
                                                                                
   typedef struct __A02441                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02441_APPL_AREA A02441_appl_area;                                       
   }  _A02441;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02441_FMT
#define FYA02441_FMT     "k88nw3lw7nz3lw7cs27s9s27"
#endif
