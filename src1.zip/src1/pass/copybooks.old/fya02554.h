/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02554                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 06/23/95                                                */
/*              Time: 13:19:54                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02554                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY002969_LEN                                                          
#define   FY002969_LEN                         1                                
#endif                                                                          
#ifndef   FY002898_LEN                                                          
#define   FY002898_LEN                         3                                
#endif                                                                          
#ifndef   FY002970_LEN                                                          
#define   FY002970_LEN                         1                                
#endif                                                                          
#ifndef   FY003126_LEN                                                          
#define   FY003126_LEN                         26                               
#endif                                                                          
#ifndef   FY000014_LEN                                                          
#define   FY000014_LEN                         9                                
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02554_APPL_AREA_z                                                     
#define _A02554_APPL_AREA_z                                                     
typedef struct __A02554_appl_area                                               
{                                                                               
   char                cFltIntlInd;                                             
   char                sFltRgnCd[FY002898_LEN];                                 
   char                cFltHubInd;                                              
   char                sFltArptDs[FY003126_LEN];                                
   char                sArchLastUpdtId[FY000014_LEN];                           
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02554_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02554_z                                                               
#define _A02554_z                                                               
                                                                                
   typedef struct __A02554                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02554_APPL_AREA A02554_appl_area;                                       
   }  _A02554;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02554_FMT
#define FYA02554_FMT     "k88cs3cs26s9s27"
#endif
