/******************************************************************************/
/*                                                                            */
/*   Header name  :   FYA02383                                                */
/*                                                                            */
/*   Description  :                                                           */
/*                                                                            */
/*   Generation Date: 05/20/98                                                */
/*              Time: 15:47:18                                                */
/******************************************************************************/
                                                                                
/******************************************************************************/
/* The following are #DEFINES for typedef _A02383                             */
/******************************************************************************/
                                                                                
#ifndef   FY000830_LEN                                                          
#define   FY000830_LEN                         88                               
#endif                                                                          
#ifndef   FY000001_LEN                                                          
#define   FY000001_LEN                         27                               
#endif                                                                          
#ifndef _A02383_APPL_AREA_z                                                     
#define _A02383_APPL_AREA_z                                                     
typedef struct __A02383_appl_area                                               
{                                                                               
   char                sArchLastUpdtTs[FY000001_LEN];                           
}  _A02383_APPL_AREA;                                                           
#endif                                                                          
                                                                                
#ifndef _A02383_z                                                               
#define _A02383_z                                                               
                                                                                
   typedef struct __A02383                                                      
   {                                                                            
      char                sArchAreaFiller[FY000830_LEN];                        
      _A02383_APPL_AREA A02383_appl_area;                                       
   }  _A02383;                                                                  
#endif                                                                          
                                                                                

#ifndef FYA02383_FMT
#define FYA02383_FMT     "k88s27"
#endif
