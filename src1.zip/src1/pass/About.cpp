// About.cpp :		implementation file
//
// Description:		For displaying Pass 2000 information 
//
// Author:			Joseph Fletcher - DT, Inc.
//
// Date:			4/26/1999

#include "stdafx.h"
#include "pass.h"
#include "About.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog


//CAboutDlg::CAboutDlg() : CFYDialog(CAboutDlg::IDD)
CAboutDlg::CAboutDlg(CWnd* pParent /*=NULL*/)
	: CFYDialog(CAboutDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
	SetVersionInfo();
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CFYDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Text(pDX, IDC_APP_VERSION, m_strAppVersion);
	DDX_Text(pDX, IDC_ARCH_VERSION, m_strArchVersion);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CFYDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_SETWINDOWSTATE, OnSetWindowState)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg message handlers

LRESULT CAboutDlg::OnSetWindowState(WPARAM wParam, LPARAM lParam)
{
	// First call the default handler
	CFYDialog::OnSetWindowState(wParam, lParam);
	
	return 0;
}

BOOL CAboutDlg::OnInitDialog() 
{
	CFYDialog::OnInitDialog();
	
	// Enable/Disable push buttons
	OnSetWindowState(NULL, NULL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg private functions

void CAboutDlg::SetVersionInfo()
{
	char	szVersion[64];      // buffer to contain version string values
	LONG    lVersionLen = 64;   // length of arch version string buffer

	// set Application Version by calling common function
	m_strAppVersion = "Pass 2000 Version " + GetAppVersion();

	// set Architecture Version by calling architecture API
	UTL_GetArchString(UTL_DATA_ARCH_VERSION, // flag indicating which string to return
	                  szVersion,             // buffer to contain string value
	                  lVersionLen);          // length of string buffer
	
	m_strArchVersion = "Architecture Version " + (CString)szVersion;

	return;
}
